import React, { createContext, useContext, useState, useEffect } from 'react';
import { initializeApp, deleteApp } from 'firebase/app';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut as fbSignOut, 
  getAuth,
  signOut as secondarySignOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  updatePassword,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  getDoc 
} from 'firebase/firestore';
import { auth, db, firebaseConfig } from '../lib/firebase';
import { 
  ErpUser, 
  UserRole, 
  UserPermissions, 
  DEFAULT_ADMIN_PERMISSIONS, 
  DEFAULT_MANAGER_PERMISSIONS 
} from '../types/erp';

/**
 * Checks whether an ERP user has permission to access a specific module.
 * Super Admins have unrestricted access to all modules.
 * Admin module/User Management is strictly restricted to role === 'admin'.
 * Managers have granular access controlled by their custom tickmark permissions.
 */
export function hasPermission(user: ErpUser | null, module: keyof UserPermissions): boolean {
  if (!user) return false;
  if (user.role === 'admin') return true;
  // Security guard: Admin module and user management is strictly for super admin only
  if (module === 'admin') return false;
  if (user.permissions && typeof user.permissions[module] === 'boolean') {
    return user.permissions[module];
  }
  return DEFAULT_MANAGER_PERMISSIONS[module] ?? false;
}

export interface AuthContextType {
  currentUser: ErpUser | null;
  users: ErpUser[];
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (loginIdentifier: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>;
  sendPasswordReset: (email: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  addNewUser: (
    userData: Omit<ErpUser, 'uid' | 'createdAt'> & { userId?: string; password?: string; temporaryPassword?: string; permissions?: UserPermissions }, 
    initialPassword?: string
  ) => Promise<{ success: boolean; user?: ErpUser; error?: string }>;
  updateUserRole: (uid: string, newRole: UserRole) => Promise<void>;
  updateUserRoleAndBranch: (uid: string, role: UserRole, branch: string) => Promise<{ success: boolean; error?: string }>;
  updateUserPassword: (uid: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  completeMustChangePassword: (newPassword: string) => Promise<{ success: boolean; error?: string }>;
  updateUserPermissions: (uid: string, permissions: UserPermissions) => Promise<{ success: boolean; error?: string }>;
  toggleUserStatus: (uid: string) => Promise<void>;
  deleteUser: (uid: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_STORAGE_USER_KEY = 'tradecore_active_user_v1';
const LOCAL_STORAGE_USERS_LIST = 'tradecore_users_directory_v1';

/**
 * Maps Firebase Auth error codes to friendly bilingual messages.
 * Enforces strict security: never reveals whether email or password was wrong.
 */
export function formatAuthError(errorCode?: string): string {
  switch (errorCode) {
    case 'auth/invalid-credential':
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-login-credentials':
      return 'Invalid email or password.';
    
    case 'auth/operation-not-allowed':
      return 'Email/Password sign-in provider is disabled in Firebase Console.';

    case 'auth/too-many-requests':
      return 'Too many failed attempts. Access temporarily blocked. Please try again later.';
    
    case 'auth/network-request-failed':
      return 'Network connection error. Please check your internet connection.';
    
    case 'auth/user-disabled':
      return 'This account has been disabled. Please contact your system administrator.';
    
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    
    case 'auth/missing-password':
      return 'Please enter your password.';
    
    case 'auth/missing-email':
      return 'Please enter your email address.';
    
    default:
      return 'Authentication failed. Please verify your credentials.';
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Current user state initialized from local cache if available (stripping any sensitive password keys)
  const [currentUser, setCurrentUser] = useState<ErpUser | null>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          delete parsed.password;
          delete parsed.temporaryPassword;
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to parse cached user', e);
    }
    return null;
  });

  const [users, setUsers] = useState<ErpUser[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_USERS_LIST);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          let hasPlaintextPassword = false;
          const cleaned = parsed.map((u: any) => {
            if (u && (u.password || u.temporaryPassword)) {
              hasPlaintextPassword = true;
              const copy = { ...u };
              delete copy.password;
              delete copy.temporaryPassword;
              return copy;
            }
            return u;
          });
          if (hasPlaintextPassword) {
            localStorage.setItem(LOCAL_STORAGE_USERS_LIST, JSON.stringify(cleaned));
          }
          return cleaned;
        }
      }
    } catch (e) {
      console.error('Failed to parse cached users list', e);
    }
    return [];
  });

  const [isLoading, setIsLoading] = useState(false);

  // Sync users list from Firestore for admin directory (never storing passwords)
  const refreshUsersList = async () => {
    try {
      const usersCol = collection(db, 'users');
      const snapshot = await getDocs(usersCol);
      if (!snapshot.empty) {
        const loaded: ErpUser[] = [];
        snapshot.forEach(docSnap => {
          const profile = docSnap.data() as ErpUser;
          delete (profile as any).password;
          delete (profile as any).temporaryPassword;
          loaded.push(profile);
        });
        setUsers(loaded);
        localStorage.setItem(LOCAL_STORAGE_USERS_LIST, JSON.stringify(loaded));
      }
    } catch (err) {
      console.warn('Firestore users directory sync warning:', err);
    }
  };

  /**
   * Helper to load user profile strictly from Firestore /users/{uid}.
   * Security constraints:
   * 1. If /users/{uid} does not exist: signs user out and displays "Account not provisioned. Contact admin."
   * 2. Never auto-creates a profile and never defaults to role 'admin'.
   * 3. On error, signs out and shows an error (never returns role 'admin').
   */
  const syncUserProfile = async (fbUser: FirebaseUser): Promise<ErpUser | null> => {
    try {
      const userDocRef = doc(db, 'users', fbUser.uid);
      const userSnap = await getDoc(userDocRef);

      if (!userSnap.exists()) {
        console.warn(`[Auth] Document /users/${fbUser.uid} does not exist. Signing user out.`);
        await fbSignOut(auth).catch(() => {});
        setCurrentUser(null);
        localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
        throw new Error('Account not provisioned. Contact admin.');
      }

      const profile = userSnap.data() as ErpUser;
      const isActive = profile.active !== undefined ? profile.active : profile.status === 'active';
      if (!isActive || profile.status === 'suspended') {
        console.warn(`[Auth] User /users/${fbUser.uid} is inactive or suspended.`);
        await fbSignOut(auth).catch(() => {});
        setCurrentUser(null);
        localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
        throw new Error('This account has been disabled. Please contact your system administrator.');
      }

      const updated: ErpUser = {
        ...profile,
        name: profile.name || profile.displayName || fbUser.displayName || '',
        displayName: profile.displayName || profile.name || fbUser.displayName || 'User',
        active: isActive,
        status: isActive ? 'active' : 'suspended',
        mustChangePassword: !!profile.mustChangePassword,
        lastLogin: new Date().toISOString()
      };

      delete (updated as any).password;
      delete (updated as any).temporaryPassword;

      // Fire-and-forget update of lastLogin timestamp
      updateDoc(userDocRef, { lastLogin: updated.lastLogin }).catch(() => {});
      return updated;
    } catch (err: any) {
      console.error('Error syncing user profile with Firestore:', err);
      await fbSignOut(auth).catch(() => {});
      setCurrentUser(null);
      localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
      throw err instanceof Error ? err : new Error('Failed to load user profile. Please contact admin.');
    }
  };

  // Listen for real Firebase Auth state changes
  useEffect(() => {
    let isMounted = true;
    console.log('[Auth] Initializing onAuthStateChanged listener...');

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      console.log('[Auth] onAuthStateChanged triggered:', fbUser ? `User authenticated (${fbUser.email}, UID: ${fbUser.uid})` : 'No active session');
      if (fbUser) {
        try {
          const profile = await syncUserProfile(fbUser);
          if (isMounted && profile) {
            console.log('[Auth] Session restored for profile:', profile.email, 'Role:', profile.role);
            const safe = { ...profile };
            delete (safe as any).password;
            delete (safe as any).temporaryPassword;
            setCurrentUser(safe);
            localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(safe));
            refreshUsersList();
          }
        } catch (err) {
          console.warn('[Auth] Auth state synchronization note:', err);
          if (isMounted) {
            setCurrentUser(null);
            localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
          }
        }
      } else {
        if (isMounted) {
          console.log('[Auth] User signed out or session expired. Cleared local state.');
          setCurrentUser(null);
          localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
        }
      }
    });

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, []);

  const setCurrentUserAndPersist = (user: ErpUser | null) => {
    if (user) {
      const safe = { ...user };
      delete (safe as any).password;
      delete (safe as any).temporaryPassword;
      setCurrentUser(safe);
      localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(safe));
    } else {
      setCurrentUser(null);
      localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
    }
  };

  /**
   * Production Firebase Sign-In (Firebase Auth is the only login method)
   * 1. Only calls signInWithEmailAndPassword (no createUserWithEmailAndPassword fallback).
   * 2. Unknown email or wrong password shows one generic error.
   * 3. No fallback sessions for operation-not-allowed, no candidate password comparison, no plaintext storage.
   */
  const login = async (
    loginIdentifier: string, 
    password: string, 
    rememberMe: boolean = true
  ): Promise<{ success: boolean; error?: string }> => {
    console.group('[Auth] 🔑 Sign-In Attempt Started');
    console.log('[Auth] Timestamp:', new Date().toISOString());

    // 1. Input Validation
    const rawInput = (loginIdentifier || '').trim();
    const hasIdentifier = rawInput.length > 0;
    const hasPassword = Boolean(password && password.length > 0);

    if (!hasIdentifier || !hasPassword) {
      console.warn('[Auth] ❌ Validation Failed: Missing login ID/email or password');
      console.groupEnd();
      setIsLoading(false);
      return { 
        success: false, 
        error: 'Please enter both User ID/Email and password.' 
      };
    }

    // Determine if input is direct email or system User ID
    const isDirectEmail = rawInput.includes('@');
    let cleanEmail = rawInput;

    // Search existing registered ERP users by userId, email, uid, or username
    const matchedUser = users.find(u => 
      (u.userId && u.userId.toLowerCase() === rawInput.toLowerCase()) ||
      (u.email && u.email.toLowerCase() === rawInput.toLowerCase()) ||
      (u.uid && u.uid.toLowerCase() === rawInput.toLowerCase()) ||
      (u.username && u.username.toLowerCase() === rawInput.toLowerCase()) ||
      (u.email && u.email.includes('@') && u.email.split('@')[0].toLowerCase() === rawInput.toLowerCase())
    );

    if (!isDirectEmail && matchedUser) {
      cleanEmail = matchedUser.email;
      console.log(`[Auth] Resolved User ID "${rawInput}" to registered corporate email: "${cleanEmail}"`);
    } else if (!isDirectEmail && !matchedUser) {
      // If user typed an ID without @ that is not registered, synthesize a default domain
      cleanEmail = `${rawInput.toLowerCase()}@tradecore-erp.com`;
    }

    setIsLoading(true);

    try {
      // 2. Persistence Configuration
      const persistenceMode = rememberMe ? browserLocalPersistence : browserSessionPersistence;
      try {
        await setPersistence(auth, persistenceMode);
      } catch (pErr: any) {
        console.warn('[Auth] ⚠️ Warning configuring persistence:', pErr?.code, pErr?.message);
      }

      // 3. Firebase Auth Call - ONLY signInWithEmailAndPassword
      console.log(`[Auth] Calling Firebase signInWithEmailAndPassword for "${cleanEmail}"...`);
      const userCredential = await signInWithEmailAndPassword(auth, cleanEmail, password);
      const fbUser = userCredential.user;

      console.log('[Auth] ✅ Firebase Authentication SUCCESSFUL for UID:', fbUser.uid);

      // 4. Sync ERP Profile from Firestore /users/{uid}
      console.log(`[Auth] Retrieving ERP profile from Firestore /users/${fbUser.uid}...`);
      const erpProfile = await syncUserProfile(fbUser);

      if (!erpProfile) {
        setIsLoading(false);
        console.groupEnd();
        return {
          success: false,
          error: 'Account not provisioned. Contact admin.'
        };
      }

      console.log('[Auth] ✅ ERP Profile loaded successfully:', {
        uid: erpProfile.uid,
        displayName: erpProfile.displayName,
        role: erpProfile.role,
        branch: erpProfile.branch,
        status: erpProfile.status
      });

      setCurrentUserAndPersist(erpProfile);
      refreshUsersList();
      console.log('[Auth] 🎉 Sign-in flow completed successfully.');
      console.groupEnd();

      setIsLoading(false);
      return { success: true };
    } catch (err: any) {
      setIsLoading(false);
      console.groupEnd();

      const errorCode = err?.code;
      const errorMessage = err?.message;

      console.error('[Auth] ❌ Sign-in failed:', errorCode, errorMessage);

      // Specific profile sync messages
      if (errorMessage === 'Account not provisioned. Contact admin.') {
        return {
          success: false,
          error: 'Account not provisioned. Contact admin.'
        };
      }
      if (errorMessage && errorMessage.includes('disabled')) {
        return {
          success: false,
          error: errorMessage
        };
      }

      // Unknown email or wrong password must show one generic error
      if (
        errorCode === 'auth/user-not-found' ||
        errorCode === 'auth/wrong-password' ||
        errorCode === 'auth/invalid-credential' ||
        errorCode === 'auth/invalid-login-credentials'
      ) {
        return {
          success: false,
          error: 'Invalid email or password.'
        };
      }

      return {
        success: false,
        error: formatAuthError(errorCode)
      };
    }
  };

  /**
   * Production Firebase Password Reset via Email
   */
  const sendPasswordReset = async (
    email: string
  ): Promise<{ success: boolean; message?: string; error?: string }> => {
    const cleanEmail = email.trim();
    if (!cleanEmail) {
      return {
        success: false,
        error: 'Please enter your email address to reset password.'
      };
    }

    try {
      await sendPasswordResetEmail(auth, cleanEmail);
      return {
        success: true,
        message: 'Password reset link sent! Please check your email inbox.'
      };
    } catch (err: any) {
      console.warn('Password reset error:', err);
      // For security, even if user is not found, provide standard generic guidance
      if (err?.code === 'auth/invalid-email') {
        return {
          success: false,
          error: 'Invalid email address format.'
        };
      }
      return {
        success: false,
        error: 'Unable to send password reset email. Please verify the email or try again later.'
      };
    }
  };

  /**
   * Admin-Only: Add new user to Firestore Directory & Firebase Auth with ID and Temporary Password
   * Requirements:
   * 1. Creating users must NOT sign out the admin (isolated secondary Firebase app instance).
   * 2. Store profiles in Firestore at users/{uid}: name, email, role, branch, active (boolean), createdAt, mustChangePassword.
   * 3. NEVER store passwords in Firestore.
   * 4. Force a password change on first login for newly created users (mustChangePassword: true).
   */
  const addNewUser = async (
    userData: Omit<ErpUser, 'uid' | 'createdAt'> & { userId?: string; password?: string; temporaryPassword?: string; permissions?: UserPermissions },
    initialPassword?: string
  ): Promise<{ success: boolean; user?: ErpUser; error?: string }> => {
    const tempPassword = (userData.temporaryPassword || userData.password || initialPassword || 'TradeCore@2025').trim();
    const cleanUserId = (userData.userId || '').trim().toUpperCase() || `EMP-${Math.floor(100 + Math.random() * 900)}`;
    let cleanEmail = (userData.email || '').trim().toLowerCase();

    if (!cleanEmail) {
      cleanEmail = `${cleanUserId.toLowerCase()}@tradecore-erp.com`;
    }

    let uid = `user-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;

    // 1. Create in Firebase Auth using isolated secondary Firebase app so admin remains logged in
    try {
      const secAppName = `SecAdminAuth_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const secondaryApp = initializeApp(firebaseConfig, secAppName);
      const secondaryAuth = getAuth(secondaryApp);
      const cred = await createUserWithEmailAndPassword(secondaryAuth, cleanEmail, tempPassword);
      if (cred?.user?.uid) {
        uid = cred.user.uid;
      }
      await secondarySignOut(secondaryAuth);
      await deleteApp(secondaryApp);
      console.log('[Auth] ✓ Registered user in Firebase Auth with UID:', uid);
    } catch (fbAuthErr: any) {
      console.warn('[Auth] Secondary Firebase Auth notice:', fbAuthErr?.code, fbAuthErr?.message);
      if (fbAuthErr?.code === 'auth/email-already-in-use') {
        return { 
          success: false, 
          error: 'Email is already registered in Firebase Auth.' 
        };
      }
    }

    const userRole: UserRole = userData.role === 'admin' ? 'admin' : 'manager';
    const permissions: UserPermissions = userData.permissions || (
      userRole === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : DEFAULT_MANAGER_PERMISSIONS
    );

    const fullName = userData.displayName?.trim() || userData.name?.trim() || 'New User';

    const safeNewUser: ErpUser = {
      uid,
      name: fullName,
      displayName: fullName,
      userId: cleanUserId,
      email: cleanEmail,
      role: userRole,
      branch: userData.branch || 'Corporate Headquarters (Dhaka)',
      phone: userData.phone || '',
      active: true,
      status: 'active',
      mustChangePassword: true,
      createdAt: new Date().toISOString(),
      assignedOffice: userData.assignedOffice || (userData.branch as any),
      permissions
    };

    // 2. Strict Firestore Profile - NEVER save password to Firestore
    const firestoreProfile = {
      uid: safeNewUser.uid,
      name: safeNewUser.name,
      displayName: safeNewUser.displayName,
      email: safeNewUser.email,
      role: safeNewUser.role,
      branch: safeNewUser.branch,
      phone: safeNewUser.phone,
      active: true,
      status: 'active',
      mustChangePassword: true,
      createdAt: safeNewUser.createdAt,
      userId: safeNewUser.userId || '',
      permissions: safeNewUser.permissions
    };

    try {
      await setDoc(doc(db, 'users', uid), firestoreProfile);
      console.log('[Auth] ✓ Successfully persisted user profile in Firestore at /users/' + uid);
    } catch (err) {
      console.warn('Firestore add user error:', err);
    }

    // Do NOT store plaintext passwords or temporary passwords in localStorage or users state
    const updatedList = [safeNewUser, ...users.filter(u => u.uid !== uid && u.email !== cleanEmail)];
    setUsers(updatedList);
    localStorage.setItem(LOCAL_STORAGE_USERS_LIST, JSON.stringify(updatedList));

    // Return temporaryPassword in-memory only for the admin copy dialog
    return { 
      success: true, 
      user: { 
        ...safeNewUser, 
        temporaryPassword: tempPassword 
      } 
    };
  };

  /**
   * Updates user role and assigned branch
   */
  const updateUserRoleAndBranch = async (uid: string, role: UserRole, branch: string): Promise<{ success: boolean; error?: string }> => {
    const permissions = role === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : DEFAULT_MANAGER_PERMISSIONS;
    const updatedList = users.map(u => u.uid === uid ? { ...u, role, branch, permissions } : u);
    setUsers(updatedList);
    localStorage.setItem(LOCAL_STORAGE_USERS_LIST, JSON.stringify(updatedList));

    if (currentUser?.uid === uid) {
      setCurrentUserAndPersist({ ...currentUser, role, branch, permissions });
    }

    try {
      await updateDoc(doc(db, 'users', uid), { role, branch, permissions });
      return { success: true };
    } catch (err: any) {
      console.warn('Firestore update role/branch warning:', err);
      return { success: false, error: err?.message || 'Failed to update user in Firestore' };
    }
  };

  /**
   * Updates or resets a user's password.
   * If updating own password, uses Firebase Auth updatePassword.
   * If updating another user, triggers password reset email.
   * NEVER stores raw password in Firestore.
   */
  const updateUserPassword = async (uid: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    const trimmed = (newPassword || '').trim();
    if (!trimmed || trimmed.length < 6) {
      return { 
        success: false, 
        error: 'Password must be at least 6 characters.' 
      };
    }

    if (auth.currentUser && auth.currentUser.uid === uid) {
      try {
        await updatePassword(auth.currentUser, trimmed);
        return { success: true };
      } catch (err: any) {
        return { success: false, error: err?.message || 'Failed to update password.' };
      }
    } else {
      const target = users.find(u => u.uid === uid);
      if (target?.email) {
        return await sendPasswordReset(target.email);
      }
      return { success: true };
    }
  };

  /**
   * First login password change completion:
   * Sets new password in Firebase Auth and clears mustChangePassword flag in Firestore.
   */
  const completeMustChangePassword = async (newPassword: string): Promise<{ success: boolean; error?: string }> => {
    const trimmed = (newPassword || '').trim();
    if (!trimmed || trimmed.length < 6) {
      return { 
        success: false, 
        error: 'Password must be at least 6 characters.' 
      };
    }
    if (!auth.currentUser) {
      return { success: false, error: 'No active session found.' };
    }
    try {
      await updatePassword(auth.currentUser, trimmed);
      const userDocRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userDocRef, { mustChangePassword: false });
      
      if (currentUser) {
        const updated = { ...currentUser, mustChangePassword: false };
        setCurrentUserAndPersist(updated);
      }
      return { success: true };
    } catch (err: any) {
      console.error('completeMustChangePassword error:', err);
      return { success: false, error: err?.message || 'Failed to change password.' };
    }
  };

  /**
   * Admin-Only: Update module permissions for a user via RBAC Tickmark form
   */
  const updateUserPermissions = async (uid: string, permissions: UserPermissions): Promise<{ success: boolean; error?: string }> => {
    const updatedList = users.map(u => u.uid === uid ? { ...u, permissions } : u);
    setUsers(updatedList);
    localStorage.setItem(LOCAL_STORAGE_USERS_LIST, JSON.stringify(updatedList));

    if (currentUser?.uid === uid) {
      setCurrentUserAndPersist({ ...currentUser, permissions });
    }

    try {
      await updateDoc(doc(db, 'users', uid), { permissions });
      console.log('[Auth] ✓ Updated RBAC permissions in Firestore for user:', uid);
    } catch (err) {
      console.warn('Firestore update permissions error:', err);
    }

    return { success: true };
  };

  /**
   * Admin-Only: Update role
   */
  const updateUserRole = async (uid: string, newRole: UserRole) => {
    const updatedList = users.map(u => {
      if (u.uid === uid) {
        const perms = newRole === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : (u.permissions || DEFAULT_MANAGER_PERMISSIONS);
        return { ...u, role: newRole, permissions: perms };
      }
      return u;
    });
    setUsers(updatedList);
    localStorage.setItem(LOCAL_STORAGE_USERS_LIST, JSON.stringify(updatedList));

    if (currentUser?.uid === uid) {
      const perms = newRole === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : (currentUser.permissions || DEFAULT_MANAGER_PERMISSIONS);
      setCurrentUserAndPersist({ ...currentUser, role: newRole, permissions: perms });
    }

    try {
      const perms = newRole === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : DEFAULT_MANAGER_PERMISSIONS;
      await updateDoc(doc(db, 'users', uid), { role: newRole, permissions: perms });
    } catch (err) {
      console.warn('Firestore update role error:', err);
    }
  };

  /**
   * Admin-Only: Toggle user active / suspended status
   */
  const toggleUserStatus = async (uid: string) => {
    const target = users.find(u => u.uid === uid);
    if (!target) return;
    const currentActive = target.active !== undefined ? target.active : (target.status === 'active');
    const newActive = !currentActive;
    const newStatus: 'active' | 'suspended' = newActive ? 'active' : 'suspended';

    const updatedList = users.map(u => u.uid === uid ? { ...u, active: newActive, status: newStatus } : u);
    setUsers(updatedList);
    localStorage.setItem(LOCAL_STORAGE_USERS_LIST, JSON.stringify(updatedList));

    if (currentUser?.uid === uid) {
      if (!newActive) {
        logout();
        return;
      }
      setCurrentUserAndPersist({ ...currentUser, active: newActive, status: newStatus });
    }

    try {
      await updateDoc(doc(db, 'users', uid), { active: newActive, status: newStatus });
    } catch (err) {
      console.warn('Firestore toggle status error:', err);
    }
  };

  /**
   * Admin-Only: Delete user
   */
  const deleteUser = async (uid: string) => {
    const updatedList = users.filter(u => u.uid !== uid);
    setUsers(updatedList);
    localStorage.setItem(LOCAL_STORAGE_USERS_LIST, JSON.stringify(updatedList));

    try {
      await deleteDoc(doc(db, 'users', uid));
    } catch (err) {
      console.warn('Firestore delete user error:', err);
    }
  };

  /**
   * Production Logout:
   * Clears Firebase Auth session, removes all local/session state, and resets to login.
   */
  const logout = async () => {
    try {
      await fbSignOut(auth);
    } catch (e) {
      console.warn('Firebase signOut error:', e);
    }
    localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
    sessionStorage.clear();
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        users,
        isAuthenticated: !!currentUser,
        isLoading,
        login,
        sendPasswordReset,
        addNewUser,
        updateUserRole,
        updateUserRoleAndBranch,
        updateUserPassword,
        completeMustChangePassword,
        updateUserPermissions,
        toggleUserStatus,
        deleteUser,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
