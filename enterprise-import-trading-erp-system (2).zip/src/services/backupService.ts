import { 
  collection, 
  doc, 
  writeBatch,
  getDoc,
  setDoc
} from 'firebase/firestore';
import { db } from '../lib/firebase';

export interface BackupExportPayload {
  appName: string;
  version: string;
  exportedAt: string;
  totalKeys: number;
  data: Record<string, any>;
}

export interface RestoreResult {
  success: boolean;
  totalCollections: number;
  restoredCounts: Record<string, number>;
  error?: string;
}

/**
 * Downloads one JSON file containing every tradecore_* localStorage key
 */
export function exportAllTradecoreData(): { payload: BackupExportPayload; filename: string } {
  const data: Record<string, any> = {};

  if (typeof window !== 'undefined' && window.localStorage) {
    for (let i = 0; i < window.localStorage.length; i++) {
      const key = window.localStorage.key(i);
      if (key && key.startsWith('tradecore_')) {
        const raw = window.localStorage.getItem(key);
        if (raw) {
          try {
            data[key] = JSON.parse(raw);
          } catch {
            data[key] = raw;
          }
        }
      }
    }
  }

  const payload: BackupExportPayload = {
    appName: 'TradeCore ERP',
    version: '1.0',
    exportedAt: new Date().toISOString(),
    totalKeys: Object.keys(data).length,
    data
  };

  const filename = `tradecore_erp_backup_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '_')}.json`;
  
  if (typeof window !== 'undefined') {
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  return { payload, filename };
}

/**
 * Restores a backup file directly into Cloud Firestore and updates local cache.
 * If any Firestore write fails, throws an error immediately without swallowing.
 */
export async function restoreBackupToFirestore(
  backupJson: any,
  onProgress?: (step: string) => void
): Promise<RestoreResult> {
  if (!backupJson || typeof backupJson !== 'object') {
    throw new Error('Invalid backup file format: Root JSON must be an object.');
  }

  // Handle both { data: { tradecore_... } } and raw { tradecore_... }
  const rawData: Record<string, any> = backupJson.data && typeof backupJson.data === 'object'
    ? backupJson.data
    : backupJson;

  const keys = Object.keys(rawData).filter(k => k.startsWith('tradecore_'));
  if (keys.length === 0) {
    throw new Error('No valid tradecore_* keys found in the provided backup file.');
  }

  const restoredCounts: Record<string, number> = {};

  onProgress?.('Updating local cache with backup records...');
  // 1. Sync localStorage cache first
  for (const key of keys) {
    const val = rawData[key];
    try {
      localStorage.setItem(key, typeof val === 'string' ? val : JSON.stringify(val));
    } catch (e) {
      console.warn(`Failed to cache ${key} locally:`, e);
    }
  }

  // Helper to commit in chunks of max 400 operations (Firestore limit is 500)
  const commitEntities = async (
    collectionName: string, 
    items: any[], 
    getId: (item: any, index: number) => string
  ) => {
    if (!Array.isArray(items) || items.length === 0) return 0;
    
    onProgress?.(`Restoring ${items.length} records into Firestore collection '${collectionName}'...`);
    let count = 0;
    const chunkSize = 400;

    for (let i = 0; i < items.length; i += chunkSize) {
      const chunk = items.slice(i, i + chunkSize);
      const batch = writeBatch(db);

      for (let j = 0; j < chunk.length; j++) {
        const item = chunk[j];
        const docId = getId(item, i + j);
        if (!docId) continue;
        const docRef = doc(db, collectionName, String(docId));
        batch.set(docRef, item, { merge: true });
        count++;
      }

      await batch.commit(); // Throws if Firestore write fails
    }

    return count;
  };

  // 2. Restore Bank Accounts
  if (Array.isArray(rawData['tradecore_bank_accounts_v1'])) {
    const c = await commitEntities(
      'bank_accounts', 
      rawData['tradecore_bank_accounts_v1'], 
      (acc, idx) => acc.id || `bank-${idx + 1}`
    );
    restoredCounts['bank_accounts'] = c;
  }

  // 3. Restore Customers
  if (Array.isArray(rawData['tradecore_customers_v1'])) {
    const c = await commitEntities(
      'customers', 
      rawData['tradecore_customers_v1'], 
      (cust, idx) => cust.id || `cust-${idx + 1}`
    );
    restoredCounts['customers'] = c;
  }

  // 4. Restore Suppliers
  if (Array.isArray(rawData['tradecore_suppliers_v1'])) {
    const c = await commitEntities(
      'suppliers', 
      rawData['tradecore_suppliers_v1'], 
      (supp, idx) => supp.id || `supp-${idx + 1}`
    );
    restoredCounts['suppliers'] = c;
  }

  // 5. Restore Account Heads
  if (Array.isArray(rawData['tradecore_account_heads_v2'])) {
    const c = await commitEntities(
      'account_heads', 
      rawData['tradecore_account_heads_v2'], 
      (head, idx) => head.id || `head-${idx + 1}`
    );
    restoredCounts['account_heads'] = c;
  }

  // 6. Restore Account Transactions
  if (Array.isArray(rawData['tradecore_account_transactions_v2'])) {
    const c = await commitEntities(
      'account_transactions', 
      rawData['tradecore_account_transactions_v2'], 
      (txn, idx) => txn.id || `txn-${idx + 1}`
    );
    restoredCounts['account_transactions'] = c;
  }

  // 7. Restore Account Ledgers
  if (Array.isArray(rawData['tradecore_account_ledgers_v2'])) {
    const c = await commitEntities(
      'account_ledgers', 
      rawData['tradecore_account_ledgers_v2'], 
      (led, idx) => led.id || `led-${idx + 1}`
    );
    restoredCounts['account_ledgers'] = c;
  }

  // 8. Restore Journal Vouchers
  if (Array.isArray(rawData['tradecore_journal_vouchers_v1'])) {
    const c = await commitEntities(
      'journal_vouchers', 
      rawData['tradecore_journal_vouchers_v1'], 
      (jv, idx) => jv.id || `jv-${idx + 1}`
    );
    restoredCounts['journal_vouchers'] = c;
  }

  // 9. Restore Counters
  if (rawData['tradecore_account_counters_v2'] && typeof rawData['tradecore_account_counters_v2'] === 'object') {
    const counters = rawData['tradecore_account_counters_v2'];
    let counterWrites = 0;
    const batch = writeBatch(db);
    for (const [key, val] of Object.entries(counters)) {
      if (val && typeof val === 'object') {
        batch.set(doc(db, 'account_counters', key), val as any, { merge: true });
        counterWrites++;
      }
    }
    if (counterWrites > 0) {
      await batch.commit();
      restoredCounts['account_counters'] = counterWrites;
    }
  }

  onProgress?.('Restoration completed successfully.');

  // Trigger browser custom events so all open tabs refresh their active state
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('tradecore_bank_accounts_changed'));
    window.dispatchEvent(new CustomEvent('tradecore_customers_changed'));
    window.dispatchEvent(new CustomEvent('tradecore_suppliers_changed'));
    window.dispatchEvent(new CustomEvent('tradecore_account_heads_changed'));
    window.dispatchEvent(new CustomEvent('tradecore_account_txns_changed'));
    window.dispatchEvent(new CustomEvent('tradecore_account_ledgers_changed'));
    window.dispatchEvent(new CustomEvent('tradecore_vouchers_updated'));
  }

  return {
    success: true,
    totalCollections: Object.keys(restoredCounts).length,
    restoredCounts
  };
}
