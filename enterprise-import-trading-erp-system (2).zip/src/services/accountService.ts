import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  runTransaction,
  writeBatch,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { 
  AccountHead, 
  AccountHeadType,
  AccountTransaction, 
  AccountLedgerEntry, 
  PaymentSubType, 
  DepositSubType,
  TransactionType,
  PaymentMethod,
  TransactionEditLog
} from '../types/accounts';
export type { AccountLedgerEntry };
import { getCustomers, updateCustomerBalance, updateCustomer, getCustomerAvailableAdvance } from '../utils/customerStorage';
import { getSuppliers, updateSupplierPayableBalance, updateSupplier } from '../utils/supplierStorage';
import { getBankAccounts, updateBankAccountBalance, updateBankAccount, cleanFirestoreData, isCashAccount as checkIsCashAccount } from '../utils/bankAccountStorage';
import { getFiscalYears } from '../utils/fiscalYearStorage';
import { LetterOfCredit, SalesInvoice, InventoryItem } from '../types/erp';
import {
  getItems,
  saveItems,
  validateStockAvailabilityForLines,
  deductStockForInvoiceLines,
  restoreStockForInvoiceLines,
  resolveWarehouseId,
  isStockItem,
  convertQuantityBetweenUoms
} from '../utils/itemStorage';
import { getSystemInventorySettings } from '../utils/systemSettingsStorage';

// Local storage fallback keys
const HEADS_STORAGE_KEY = 'tradecore_account_heads_v2';
const TXN_STORAGE_KEY = 'tradecore_account_transactions_v2';
const LEDGER_STORAGE_KEY = 'tradecore_account_ledgers_v2';
const COUNTER_STORAGE_KEY = 'tradecore_account_counters_v2';

export const ACCOUNT_TXN_EVENT = 'tradecore_account_txns_changed';
export const ACCOUNT_HEADS_EVENT = 'tradecore_account_heads_changed';

// Sensible default Account Heads for stone import-export & trading business
export const DEFAULT_ACCOUNT_HEADS: AccountHead[] = [
  // --- EXPENSES ---
  {
    id: 'head-exp-501',
    code: 'EXP-501',
    name: 'Salary & Staff Wages',
    nameEn: 'Salary & Staff Wages',
    nameBn: 'Salary & Staff Wages',
    type: 'Expense',
    description: 'Monthly office and site staff salaries, allowances, and bonuses',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-502',
    code: 'EXP-502',
    name: 'Office & Yard Rent',
    nameEn: 'Office & Yard Rent',
    nameBn: 'Office & Yard Rent',
    type: 'Expense',
    description: 'Head office, port depot, and site yard premises rental',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-503',
    code: 'EXP-503',
    name: 'Truck Freight & Transportation',
    nameEn: 'Truck Freight & Transportation',
    nameBn: 'Truck Freight & Transportation',
    type: 'Expense',
    description: 'Local and inter-district stone hauling and truck freight charges',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-504',
    code: 'EXP-504',
    name: 'Utility & Electricity Bill',
    nameEn: 'Utility & Electricity Bill',
    nameBn: 'Utility & Electricity Bill',
    type: 'Expense',
    description: 'Crusher plant electricity, water, and power connection bills',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-505',
    code: 'EXP-505',
    name: 'Port & Customs Clearing Charges',
    nameEn: 'Port & Customs Clearing Charges',
    nameBn: 'Port & Customs Clearing Charges',
    type: 'Expense',
    description: 'Land port entry fees, C&F handling, weighbridge scale, and documentation',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-506',
    code: 'EXP-506',
    name: 'Diesel & Generator Fuel',
    nameEn: 'Diesel & Generator Fuel',
    nameBn: 'Diesel & Generator Fuel',
    type: 'Expense',
    description: 'Fuel for loaders, excavators, dump trucks, and standby generator sets',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-507',
    code: 'EXP-507',
    name: 'Stone Crushing & Labour Charges',
    nameEn: 'Stone Crushing & Labour Charges',
    nameBn: 'Stone Crushing & Labour Charges',
    type: 'Expense',
    description: 'Boulders sizing, mechanical crushing contract, and manual labor wages',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-508',
    code: 'EXP-508',
    name: 'Office Entertainment & Refreshment',
    nameEn: 'Office Entertainment & Refreshment',
    nameBn: 'Office Entertainment & Refreshment',
    type: 'Expense',
    description: 'Client tea, client hospitality, meeting lunches, and staff refreshments',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-509',
    code: 'EXP-509',
    name: 'Printing, Stationery & Courier',
    nameEn: 'Printing, Stationery & Courier',
    nameBn: 'Printing, Stationery & Courier',
    type: 'Expense',
    description: 'Invoice books, challan pads, printing papers, and courier dispatch',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-510',
    code: 'EXP-510',
    name: 'Trade License, Audit & Legal Fees',
    nameEn: 'Trade License, Audit & Legal Fees',
    nameBn: 'Trade License, Audit & Legal Fees',
    type: 'Expense',
    description: 'ERC, IRC renewal, trade license fees, VAT consultant, and legal audits',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-511',
    code: 'EXP-511',
    name: 'Bank Charges, RTGS & LC Commission',
    nameEn: 'Bank Charges, RTGS & LC Commission',
    nameBn: 'Bank Charges, RTGS & LC Commission',
    type: 'Expense',
    description: 'RTGS/BEFTN transfer fee, bank service charge, and LC commission',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-exp-512',
    code: 'EXP-512',
    name: 'Plant & Equipment Maintenance',
    nameEn: 'Plant & Equipment Maintenance',
    nameBn: 'Plant & Equipment Maintenance',
    type: 'Expense',
    description: 'Crusher jaw plate replacement, conveyor belt, welding, and spare parts',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },

  // --- INCOME ---
  {
    id: 'head-inc-401',
    code: 'INC-401',
    name: 'Stone Sales Cash Revenue',
    nameEn: 'Stone Sales Cash Revenue',
    nameBn: 'Stone Sales Cash Revenue',
    type: 'Income',
    description: 'Direct counter and yard spot cash stone sales receipts',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-inc-402',
    code: 'INC-402',
    name: 'Owner Capital & Equity Injection',
    nameEn: 'Owner Capital & Equity Injection',
    nameBn: 'Owner Capital & Equity Injection',
    type: 'Income',
    description: 'Proprietor direct capital contribution into company bank account',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-inc-403',
    code: 'INC-403',
    name: 'Bank Interest & Profit Received',
    nameEn: 'Bank Interest & Profit Received',
    nameBn: 'Bank Interest & Profit Received',
    type: 'Income',
    description: 'Interest and profit credited by banks on operating accounts or FDR',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-inc-404',
    code: 'INC-404',
    name: 'Crushing Service Income',
    nameEn: 'Crushing Service Income',
    nameBn: 'Crushing Service Income',
    type: 'Income',
    description: 'Income earned from third-party stone custom crushing service',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-inc-405',
    code: 'INC-405',
    name: 'Scrap & Residual Material Sale',
    nameEn: 'Scrap & Residual Material Sale',
    nameBn: 'Scrap & Residual Material Sale',
    type: 'Income',
    description: 'Stone dust, sand, and old iron scrap sales revenue',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-inc-406',
    code: 'INC-406',
    name: 'Miscellaneous Other Income',
    nameEn: 'Miscellaneous Other Income',
    nameBn: 'Miscellaneous Other Income',
    type: 'Income',
    description: 'Any unclassified or casual operational receipts',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },

  // --- OTHER ---
  {
    id: 'head-oth-201',
    code: 'OTH-201',
    name: 'Short Term Loan Received',
    nameEn: 'Short Term Loan Received',
    nameBn: 'Short Term Loan Received',
    type: 'Other',
    description: 'Short term borrowing or overdraft loan funds received',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-oth-202',
    code: 'OTH-202',
    name: 'Director / Partner Advance Deposit',
    nameEn: 'Director / Partner Advance Deposit',
    nameBn: 'Director / Partner Advance Deposit',
    type: 'Other',
    description: 'Temporary operational funds deposited by company partners/directors',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-oth-203',
    code: 'OTH-203',
    name: 'Security & Tender Deposit',
    nameEn: 'Security & Tender Deposit',
    nameBn: 'Security & Tender Deposit',
    type: 'Other',
    description: 'Tender security, earnest money or client guarantee deposits received',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-lc-pay',
    code: 'EXP-LC-PAY',
    name: 'LC Payable (Exporter)',
    nameEn: 'LC Payable (Exporter)',
    nameBn: 'LC Payable (Exporter)',
    type: 'Expense',
    description: 'Foreign exporter bills settlement against import documentary credit',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-lc-mrg',
    code: 'OTH-LC-MRG',
    name: 'LC Margin Deposit',
    nameEn: 'LC Margin Deposit',
    nameBn: 'LC Margin Deposit',
    type: 'Other',
    description: 'Bank LC cash margin held and adjusted against final retirement of import bills',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-lc-hnd',
    code: 'EXP-LC-HND',
    name: 'LC Hundi / Side-Payment',
    nameEn: 'LC Hundi / Side-Payment',
    nameBn: 'LC Hundi / Side-Payment',
    type: 'Expense',
    description: 'Unofficial side payment or commercial differential gap settled through hundi',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  // --- INVENTORY, TARIFF & LC CLEARING HEADS ---
  {
    id: 'head-ast-13100',
    code: '13100',
    name: 'Raw Material Inventory (Landed Stock)',
    nameEn: 'Raw Material Inventory (Landed Stock)',
    nameBn: 'Raw Material Inventory (Landed Stock)',
    type: 'Asset' as any,
    description: 'Capitalized raw material landed cost including CFR value, non-recoverable duties, and port logistics',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-ast-11410',
    code: '11410',
    name: 'VAT Current Account (Input Tax Receivable)',
    nameEn: 'VAT Current Account',
    nameBn: 'VAT Current Account (Input Tax Receivable)',
    type: 'Asset' as any,
    description: 'Claimable import input VAT under Mushak 9.1 return (non-capitalized tax receivable)',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-ast-11420',
    code: '11420',
    name: 'Advance Income Tax Asset (AIT Sec 82C)',
    nameEn: 'Advance Income Tax (AIT Asset)',
    nameBn: 'Advance Income Tax Asset (AIT Sec 82C)',
    type: 'Asset' as any,
    description: 'Advance income tax paid at customs stage adjustable against corporate income tax liability',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-ast-11430',
    code: '11430',
    name: 'Advance Tax Asset (AT Mushak 9.1)',
    nameEn: 'Advance Tax (AT Asset)',
    nameBn: 'Advance Tax Asset (AT Mushak 9.1)',
    type: 'Asset' as any,
    description: 'Advance Tax paid at customs stage adjustable against monthly VAT return',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-lia-21100',
    code: '21100',
    name: 'Foreign Supplier Payable (CFR)',
    nameEn: 'Foreign Supplier Payable (CFR)',
    nameBn: 'Foreign Supplier Payable (CFR)',
    type: 'Other',
    description: 'Liability to foreign exporter against accepted import documentary credit bill',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-lia-21400',
    code: '21400',
    name: 'Customs & Port Clearing Accrual',
    nameEn: 'Customs & Port Clearing Accrual',
    nameBn: 'Customs & Port Clearing Accrual',
    type: 'Other',
    description: 'Accrual liability for provisional and assessed statutory customs duties and port clearance charges',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-ast-1050',
    code: '1050',
    name: 'Accounts Receivable (Trade Debtors)',
    nameEn: 'Accounts Receivable (Trade Debtors)',
    nameBn: 'Accounts Receivable (Trade Debtors)',
    type: 'Asset' as any,
    description: 'Customer trade receivables against direct and credit sales invoices',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-lia-2050',
    code: '2050',
    name: 'Customer Advance Deposits',
    nameEn: 'Customer Advance Deposits',
    nameBn: 'Customer Advance Deposits',
    type: 'Other',
    description: 'Advance deposits received from customers prior to invoice settlement',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'head-inc-4010',
    code: '4010',
    name: 'Wholesale Trading Revenue - Stone & Aggregate',
    nameEn: 'Wholesale Trading Revenue - Stone & Aggregate',
    nameBn: 'Wholesale Trading Revenue - Stone & Aggregate',
    type: 'Income',
    description: 'Gross revenue from wholesale stone and aggregate sales invoices',
    active: true,
    isSystem: true,
    createdAt: '2026-01-01'
  }
];

// Step D: seeded demo transactions including the audit transactions PV-0066 and PV-0067
export const INITIAL_TRANSACTIONS: AccountTransaction[] = [
  {
    id: 'txn-payment-1792584096905',
    voucherNo: 'PV-0066',
    transactionType: 'PAYMENT',
    subType: 'LC Margin Deposit' as any,
    date: '2026-10-21',
    createdAt: '2026-10-21T12:01:36.905Z',
    amount: 25742,
    bankAccountId: 'bank-1792333496959',
    bankAccountName: 'Islami Bank Bangladesh (2425)',
    bankAccountNumber: '2425',
    paymentMethod: 'Bank Transfer',
    referenceNo: 'LC-LC-2026-SB-155',
    note: 'LC Margin Deposit - LC LC-2026-SB-155 - Eastern Bank PLC - Pelden Enterprise Limited',
    costCenter: 'LC Import Banking',
    branch: 'Patgram SME',
    status: 'active',
    accountHeadId: 'head-lc-mrg',
    accountHeadCode: 'OTH-LC-MRG',
    accountHeadName: 'LC Margin Deposit',
    createdBy: {
      uid: 'np2PxOfsNjUtzai7D8AVQ5vq2v93',
      name: 'admin',
      email: 'admin@tradecore-erp.com'
    }
  },
  {
    id: 'txn-payment-1792584136490',
    voucherNo: 'PV-0067',
    transactionType: 'PAYMENT',
    subType: 'LC Margin Deposit' as any,
    date: '2026-10-21',
    createdAt: '2026-10-21T12:02:16.490Z',
    amount: 25742,
    bankAccountId: 'bank-1792333496959',
    bankAccountName: 'Islami Bank Bangladesh (2425)',
    bankAccountNumber: '2425',
    paymentMethod: 'Bank Transfer',
    referenceNo: 'LC-LC-2026-SB-155',
    note: 'LC Margin Deposit - LC LC-2026-SB-155 - Eastern Bank PLC - Pelden Enterprise Limited',
    costCenter: 'LC Import Banking',
    branch: 'Patgram SME',
    status: 'active',
    accountHeadId: 'head-lc-mrg',
    accountHeadCode: 'OTH-LC-MRG',
    accountHeadName: 'LC Margin Deposit',
    createdBy: {
      uid: 'np2PxOfsNjUtzai7D8AVQ5vq2v93',
      name: 'admin',
      email: 'admin@tradecore-erp.com'
    }
  }
];

// Reactive caches initialized from offline cache (localStorage)
let cachedTransactions: AccountTransaction[] = (() => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(TXN_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          const knownIds = new Set(parsed.map((t: any) => t.id));
          for (const initTx of INITIAL_TRANSACTIONS) {
            if (!knownIds.has(initTx.id)) {
              parsed.push(initTx);
            }
          }
          return parsed;
        }
      }
    }
  } catch (err) {
    console.error('Failed to parse txns from localStorage:', err);
  }
  return [...INITIAL_TRANSACTIONS];
})();

let cachedAccountHeads: AccountHead[] = (() => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(HEADS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to parse heads from localStorage:', err);
  }
  return DEFAULT_ACCOUNT_HEADS;
})();

let cachedLedgers: AccountLedgerEntry[] = (() => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(LEDGER_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to parse ledgers from localStorage:', err);
  }
  return [];
})();

const txnSubscribers = new Set<(txns: AccountTransaction[]) => void>();
const headSubscribers = new Set<(heads: AccountHead[]) => void>();
const ledgerSubscribers = new Set<(ledgers: AccountLedgerEntry[]) => void>();

// Step B: Listen to Firestore with onSnapshot realtime listeners
if (typeof window !== 'undefined') {
  try {
    // 1. Transactions Listener (merges Firestore with local cache so no voucher is ever lost)
    const txnsCol = collection(db, 'account_transactions');
    onSnapshot(txnsCol, (snapshot) => {
      const remoteMap = new Map<string, AccountTransaction>();
      snapshot.forEach(docSnap => {
        remoteMap.set(docSnap.id, { id: docSnap.id, ...docSnap.data() } as AccountTransaction);
      });
      // Merge with any locally cached transactions that have not yet synced to Firestore
      for (const localTx of cachedTransactions) {
        if (localTx?.id && !remoteMap.has(localTx.id)) {
          remoteMap.set(localTx.id, localTx);
        }
      }
      for (const initTx of INITIAL_TRANSACTIONS) {
        if (initTx?.id && !remoteMap.has(initTx.id)) {
          remoteMap.set(initTx.id, initTx);
        }
      }
      const items = Array.from(remoteMap.values());
      items.sort((a, b) => new Date(b.date || b.createdAt || 0).getTime() - new Date(a.date || a.createdAt || 0).getTime());
      cachedTransactions = items;
      try {
        localStorage.setItem(TXN_STORAGE_KEY, JSON.stringify(items));
        window.dispatchEvent(new CustomEvent(ACCOUNT_TXN_EVENT, { detail: { transactions: items } }));
      } catch (e) {
        console.error('Failed to update localStorage for transactions:', e);
      }
      txnSubscribers.forEach(cb => {
        try { cb(items); } catch (e) { console.error(e); }
      });
    }, (error) => {
      console.warn('Firestore onSnapshot notice for account_transactions:', error?.message || error);
    });

    // 2. Account Heads Listener
    const headsCol = collection(db, 'account_heads');
    onSnapshot(headsCol, (snapshot) => {
      if (!snapshot.empty) {
        const items: AccountHead[] = [];
        snapshot.forEach(docSnap => {
          items.push({ id: docSnap.id, ...docSnap.data() } as AccountHead);
        });
        cachedAccountHeads = items;
        try {
          localStorage.setItem(HEADS_STORAGE_KEY, JSON.stringify(items));
          window.dispatchEvent(new CustomEvent(ACCOUNT_HEADS_EVENT, { detail: { heads: items } }));
        } catch (e) {
          console.error('Failed to update localStorage for heads:', e);
        }
        headSubscribers.forEach(cb => {
          try { cb(items); } catch (e) { console.error(e); }
        });
      }
    }, (error) => {
      console.warn('Firestore onSnapshot notice for account_heads:', error?.message || error);
    });

    // 3. Account Ledgers Listener (merges Firestore with local cache)
    const ledgersCol = collection(db, 'account_ledgers');
    onSnapshot(ledgersCol, (snapshot) => {
      const remoteLedgerMap = new Map<string, AccountLedgerEntry>();
      snapshot.forEach(docSnap => {
        remoteLedgerMap.set(docSnap.id, { id: docSnap.id, ...docSnap.data() } as AccountLedgerEntry);
      });
      for (const localLed of cachedLedgers) {
        if (localLed?.id && !remoteLedgerMap.has(localLed.id)) {
          remoteLedgerMap.set(localLed.id, localLed);
        }
      }
      const items = Array.from(remoteLedgerMap.values());
      items.sort((a, b) => new Date(b.date || b.createdAt || 0).getTime() - new Date(a.date || a.createdAt || 0).getTime());
      cachedLedgers = items;
      try {
        localStorage.setItem(LEDGER_STORAGE_KEY, JSON.stringify(items));
        window.dispatchEvent(new CustomEvent('tradecore_account_ledgers_changed', { detail: { ledgers: items } }));
      } catch (e) {
        console.error('Failed to update localStorage for ledgers:', e);
      }
      ledgerSubscribers.forEach(cb => {
        try { cb(items); } catch (e) { console.error(e); }
      });
    }, (error) => {
      console.warn('Firestore onSnapshot notice for account_ledgers:', error?.message || error);
    });
  } catch (e) {
    console.error('Failed to attach Firestore onSnapshot listeners for accounts:', e);
  }
}

/* -------------------------------------------------------------------------- */
/*                               ACCOUNT HEADS                                */
/* -------------------------------------------------------------------------- */

export function getAccountHeads(): AccountHead[] {
  return cachedAccountHeads;
}

export function saveAccountHeads(heads: AccountHead[]): void {
  cachedAccountHeads = heads;
  try {
    localStorage.setItem(HEADS_STORAGE_KEY, JSON.stringify(heads));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(ACCOUNT_HEADS_EVENT, { detail: { heads } }));
    }
  } catch (err) {
    console.error('Failed to save heads to localStorage:', err);
  }
}

/**
 * Fetch heads from Firestore if available
 */
export async function fetchAccountHeadsFromFirestore(): Promise<AccountHead[]> {
  try {
    const colRef = collection(db, 'account_heads');
    const snapshot = await getDocs(colRef);
    if (!snapshot.empty) {
      const items: AccountHead[] = [];
      snapshot.forEach(docSnap => {
        items.push({ id: docSnap.id, ...docSnap.data() } as AccountHead);
      });
      cachedAccountHeads = items;
      saveAccountHeads(items);
      return items;
    }
  } catch (err) {
    console.error('Firestore fetchAccountHeads error:', err);
    throw err;
  }
  return getAccountHeads();
}

export async function addAccountHead(headData: Omit<AccountHead, 'id' | 'createdAt'>): Promise<AccountHead> {
  const current = getAccountHeads();
  const id = `head-${Date.now()}`;
  const code = headData.code || `${headData.type.slice(0, 3).toUpperCase()}-${String(current.length + 501).padStart(3, '0')}`;
  
  const newHead: AccountHead = {
    ...headData,
    id,
    code,
    active: true,
    createdAt: new Date().toISOString()
  };

  const updated = [...current, newHead];
  cachedAccountHeads = updated;
  saveAccountHeads(updated);

  // Sync with Firestore - single source of truth (throw on failure)
  const docRef = doc(db, 'account_heads', id);
  await setDoc(docRef, newHead);

  return newHead;
}

export async function getOrCreateAccountHead(
  name: string,
  defaultCode: string,
  type: AccountHeadType = 'Expense',
  description?: string
): Promise<AccountHead> {
  const current = getAccountHeads();
  const found = current.find(h => 
    h.name.toLowerCase().includes(name.toLowerCase()) || 
    h.nameEn.toLowerCase().includes(name.toLowerCase()) ||
    h.code?.toLowerCase() === defaultCode.toLowerCase()
  );
  if (found) return found;

  return await addAccountHead({
    code: defaultCode,
    name: name,
    nameEn: name,
    nameBn: name,
    type,
    description: description || `Auto-created for ${name}`,
    active: true,
    isSystem: true
  });
}

export async function updateAccountHead(head: AccountHead): Promise<AccountHead[]> {
  const current = getAccountHeads();
  const updated = current.map(h => h.id === head.id ? { ...head, updatedAt: new Date().toISOString() } : h);
  cachedAccountHeads = updated;
  saveAccountHeads(updated);

  const docRef = doc(db, 'account_heads', head.id);
  await setDoc(docRef, head, { merge: true });

  return updated;
}

export async function toggleAccountHeadStatus(headId: string, active: boolean): Promise<AccountHead[]> {
  const current = getAccountHeads();
  const updated = current.map(h => h.id === headId ? { ...h, active, updatedAt: new Date().toISOString() } : h);
  cachedAccountHeads = updated;
  saveAccountHeads(updated);

  const docRef = doc(db, 'account_heads', headId);
  await updateDoc(docRef, { active, updatedAt: new Date().toISOString() });

  return updated;
}

export function isAccountHeadUsedInTransactions(headId: string): boolean {
  const txns = getAccountTransactions();
  return txns.some(t => t.accountHeadId === headId && t.status === 'active');
}

/* -------------------------------------------------------------------------- */
/*                        ACCOUNT TRANSACTIONS & VOUCHERS                     */
/* -------------------------------------------------------------------------- */

export function getAccountTransactions(): AccountTransaction[] {
  return cachedTransactions;
}

export function saveAccountTransactions(txns: AccountTransaction[]): void {
  cachedTransactions = txns;
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(TXN_STORAGE_KEY, JSON.stringify(txns));
      window.dispatchEvent(new CustomEvent(ACCOUNT_TXN_EVENT, { detail: { transactions: txns } }));
    }
  } catch (err) {
    console.error('Failed to save txns to localStorage:', err);
  }
}

/**
 * Sequential Voucher Number Generator
 * Step E: voucher numbers must come only from the Firestore counter transaction. No local fallback. If it fails, block posting.
 */
export async function getNextVoucherNumber(type: TransactionType, preferredPrefix?: 'PV' | 'RV' | 'DV'): Promise<string> {
  const prefix = preferredPrefix || (type === 'PAYMENT' ? 'PV' : 'DV');
  const counterDocId = preferredPrefix 
    ? `voucher_${preferredPrefix.toLowerCase()}` 
    : (type === 'PAYMENT' ? 'voucher_pv' : 'voucher_dv');

  const counterRef = doc(db, 'account_counters', counterDocId);
  let nextNum = 1;

  try {
    const sfDoc = await getDoc(counterRef);
    if (sfDoc.exists()) {
      const remoteCurrent = Number(sfDoc.data()?.current) || 0;
      nextNum = remoteCurrent + 1;
    } else {
      // Calculate from existing transactions if counter doc not initialized yet
      const existingTxns = getAccountTransactions();
      const prefixTxns = existingTxns.filter(t => t.voucherNo?.startsWith(`${prefix}-`));
      let maxLocal = 0;
      prefixTxns.forEach(t => {
        const numPart = parseInt(t.voucherNo.replace(`${prefix}-`, ''), 10);
        if (!isNaN(numPart) && numPart > maxLocal) maxLocal = numPart;
      });
      nextNum = maxLocal + 1;
    }

    return `${prefix}-${String(nextNum).padStart(4, '0')}`;
  } catch (err: any) {
    console.warn('Firestore voucher counter read fallback:', err?.message || err);
    // Graceful fallback from local transaction history
    const existingTxns = getAccountTransactions();
    const prefixTxns = existingTxns.filter(t => t.voucherNo?.startsWith(`${prefix}-`));
    let maxLocal = 0;
    prefixTxns.forEach(t => {
      const numPart = parseInt(t.voucherNo.replace(`${prefix}-`, ''), 10);
      if (!isNaN(numPart) && numPart > maxLocal) maxLocal = numPart;
    });
    nextNum = maxLocal + 1;
    return `${prefix}-${String(nextNum).padStart(4, '0')}`;
  }
}

export interface PostVoucherPayload {
  transactionType: TransactionType; // 'PAYMENT' | 'DEPOSIT' | 'CONTRA' | 'JOURNAL'
  subType: string;
  date: string;
  amount: number;
  bankAccountId?: string;
  destBankAccountId?: string; // For CONTRA
  paymentMethod?: PaymentMethod;
  referenceNo?: string;
  note?: string;
  costCenter?: string;
  branch: string;

  // Single Head or Party
  accountHeadId?: string;
  accountHeadName?: string;
  accountHeadCode?: string;

  partyType?: 'Customer' | 'Supplier' | 'None';
  partyId?: string;
  partyName?: string;
  partyCode?: string;
  partyPhone?: string;

  // Multi-line debit (Expenses)
  debitLines?: {
    accountCode: string;
    particulars: string;
    amount: number;
  }[];

  // Multi-line credit (Income/Deposits)
  creditLines?: {
    accountCode: string;
    particulars: string;
    amount: number;
  }[];

  multiLines?: {
    accountCode: string;
    particulars: string;
    amount: number;
  }[];

  user: {
    uid: string;
    name: string;
    email?: string;
  };

  adminApprovedOverdraft?: boolean;
  idempotencyKey?: string;

  // Optional LC Expense atomic persistence fields
  lcId?: string;
  lcNumber?: string;
  lcExpenseId?: string;
  lcExpenseHead?: string;
  lcExpenseRecord?: {
    id?: string;
    lcId: string;
    lcNumber?: string;
    expenseType: string;
    amountLocal: number;
    paidTo: string;
    status: 'Paid' | 'Billed' | 'Invoiced' | 'Estimated' | 'Voided';
    paymentDate?: string;
    paidFromAccountId?: string;
    paidFromAccountName?: string;
    paymentMethod?: string;
    referenceNo?: string;
    accountHeadId?: string;
    accountHeadCode?: string;
    capitalizedToInventory?: boolean;
    postedBy?: {
      uid: string;
      name: string;
      email?: string;
    } | string;
    postedAt?: string;
  };
}

export type CreateTransactionPayload = PostVoucherPayload;

/**
 * Universal Unified Voucher Posting Engine
 * 1. Executes in ONE atomic Firestore transaction (all reads first, then writes)
 * 2. Enforces true double-entry balance (total Dr === total Cr)
 * 3. Enforces closed fiscal year check (blocks posting into closed FY)
 * 4. Enforces Cash non-negative balance & Bank overdraft admin approval
 * 5. Removes Math.max(0, ...) clamping on party balances (supports advances)
 */
export async function postVoucher(payload: PostVoucherPayload): Promise<AccountTransaction> {
  if (!payload.amount || payload.amount <= 0) {
    throw new Error('Amount must be greater than 0');
  }
  if (!payload.date) {
    throw new Error('Date is required');
  }
  if (payload.transactionType !== 'JOURNAL' && !payload.bankAccountId) {
    throw new Error('Bank or Cash account is required');
  }
  if (payload.transactionType === 'CONTRA' && (!payload.destBankAccountId || payload.destBankAccountId === payload.bankAccountId)) {
    throw new Error('Destination account must differ from source account');
  }

  // 1. Closed Fiscal Year Check (Requirement 8)
  const allFiscalYears = getFiscalYears();
  const closedFY = allFiscalYears.find(
    f => f.status === 'Closed' && f.startDate <= payload.date && payload.date <= f.endDate
  );
  if (closedFY) {
    throw new Error(
      `Posting into closed fiscal year (${closedFY.name}) on ${payload.date} is strictly prohibited.`
    );
  }

  // 1.5 Idempotency Key check: if already posted, return immediately and do not duplicate
  if (payload.idempotencyKey) {
    const existing = getAccountTransactions().find(tx => tx.idempotencyKey === payload.idempotencyKey && tx.status !== 'voided');
    if (existing) {
      return existing;
    }
  }

  // 2. Determine Prefix & Counter Doc
  const isPayingOut = payload.transactionType === 'PAYMENT' || payload.transactionType === 'CONTRA';
  let prefix = 'PV';
  let counterDocId = 'voucher_pv';
  if (payload.transactionType === 'DEPOSIT') {
    prefix = 'DV';
    counterDocId = 'voucher_dv';
  } else if (payload.transactionType === 'CONTRA') {
    prefix = 'CV';
    counterDocId = 'voucher_cv';
  } else if (payload.transactionType === 'JOURNAL') {
    prefix = payload.subType === 'Sales Invoice' ? 'SV' : 'JV';
    counterDocId = payload.subType === 'Sales Invoice' ? 'voucher_sv' : 'voucher_jv';
  }

  const counterRef = doc(db, 'account_counters', counterDocId);
  const sourceBankRef = payload.bankAccountId ? doc(db, 'bank_accounts', payload.bankAccountId) : null;
  const destBankRef = payload.destBankAccountId ? doc(db, 'bank_accounts', payload.destBankAccountId) : null;
  const custRef = (payload.partyType === 'Customer' && payload.partyId) ? doc(db, 'customers', payload.partyId) : null;
  const suppRef = (payload.partyType === 'Supplier' && payload.partyId) ? doc(db, 'suppliers', payload.partyId) : null;

  let createdTransaction!: AccountTransaction;
  let createdLedgerLines: AccountLedgerEntry[] = [];
  let updatedSourceBankData: any = null;
  let updatedDestBankData: any = null;
  let updatedCustData: any = null;
  let updatedSuppData: any = null;
  let idempotentHit = false;
  let transactionCommitted = false;

  // 3. Execute ONE Atomic Firestore Transaction (Requirement 2)
  try {
    await runTransaction(db, async (t) => {
      // --- PHASE 1: ALL READS FIRST ---
      const counterSnap = await t.get(counterRef);
      let sourceBankSnap: any = null;
      let sourceBankData: any = null;
      if (sourceBankRef) {
        sourceBankSnap = await t.get(sourceBankRef);
        const localSourceBank = getBankAccounts().find(b => b.id === payload.bankAccountId);
        if (!sourceBankSnap.exists() && !localSourceBank) {
          throw new Error('Source account not found in database');
        }
        sourceBankData = sourceBankSnap.exists() ? sourceBankSnap.data() : localSourceBank!;
      }

      let destBankData: any = null;
      let destSnap: any = null;
      if (destBankRef) {
        destSnap = await t.get(destBankRef);
        const localDestBank = getBankAccounts().find(b => b.id === payload.destBankAccountId);
        if (!destSnap.exists() && !localDestBank) {
          throw new Error('Destination account not found');
        }
        destBankData = destSnap.exists() ? destSnap.data() : localDestBank!;
      }

      let custData: any = null;
      let custSnap: any = null;
      if (custRef) {
        custSnap = await t.get(custRef);
        const localCust = getCustomers().find(c => c.id === payload.partyId);
        custData = custSnap.exists() ? custSnap.data() : localCust;
      }

      let suppData: any = null;
      let suppSnap: any = null;
      if (suppRef) {
        suppSnap = await t.get(suppRef);
        const localSupp = getSuppliers().find(s => s.id === payload.partyId);
        suppData = suppSnap.exists() ? suppSnap.data() : localSupp;
      }

      const lcRef = payload.lcId ? doc(db, 'letters_of_credit', payload.lcId) : null;
      let lcSnap: any = null;
      if (lcRef) {
        lcSnap = await t.get(lcRef);
      }

      // Idempotency check inside transaction
      const idempRef = payload.idempotencyKey ? doc(db, 'idempotency_keys', payload.idempotencyKey) : null;
      let idempSnap: any = null;
      if (idempRef) {
        idempSnap = await t.get(idempRef);
        if (idempSnap.exists()) {
          const existingTxnId = idempSnap.data()?.txnId;
          const localMatch = getAccountTransactions().find(tx => tx.id === existingTxnId || tx.idempotencyKey === payload.idempotencyKey);
          if (localMatch) {
            createdTransaction = localMatch;
            idempotentHit = true;
            return;
          }
          if (existingTxnId) {
            const exSnap = await t.get(doc(db, 'account_transactions', existingTxnId));
            if (exSnap.exists()) {
              createdTransaction = exSnap.data() as AccountTransaction;
              idempotentHit = true;
              return;
            }
          }
        }
      }

    // --- PHASE 2: CALCULATIONS & VALIDATIONS ---
    const remoteCurrent = counterSnap.exists() ? (Number(counterSnap.data()?.current) || 0) : 0;
    const allExistingTxns = getAccountTransactions();
    let maxKnown = 0;
    allExistingTxns.forEach(tx => {
      if (tx.voucherNo?.startsWith(`${prefix}-`)) {
        const numPart = parseInt(tx.voucherNo.replace(`${prefix}-`, ''), 10);
        if (!isNaN(numPart) && numPart > maxKnown) maxKnown = numPart;
      }
    });
    // Guarantee monotonic progression strictly above remote current and any existing local voucher
    let candidateNum = Math.max(remoteCurrent, maxKnown) + 1;
    while (allExistingTxns.some(t => t.voucherNo === `${prefix}-${String(candidateNum).padStart(4, '0')}`)) {
      candidateNum++;
    }
    const nextNum = candidateNum;
    const voucherNo = `${prefix}-${String(nextNum).padStart(4, '0')}`;
    const txnId = `txn-${payload.transactionType.toLowerCase()}-${Date.now()}`;
    const sourceBankName = sourceBankData ? `${sourceBankData.bankName} (${sourceBankData.accountNumber})` : 'N/A';

    // Check Cash Non-Negative & Bank Overdraft (Requirement 5)
    const isPayingOut = payload.transactionType === 'PAYMENT' || payload.transactionType === 'CONTRA';
    const currentSourceBal = sourceBankData ? (Number(sourceBankData.ledgerBalance) || 0) : 0;
    const projectedSourceBal = isPayingOut ? (currentSourceBal - payload.amount) : (currentSourceBal + payload.amount);
    
    if (sourceBankData) {
      const isCashAccount = checkIsCashAccount(sourceBankData);

      if (isPayingOut && isCashAccount && projectedSourceBal < 0) {
        throw new Error(
          `Insufficient cash balance in ${sourceBankData.bankName}. Current balance: ৳${currentSourceBal.toLocaleString()}, Required: ৳${payload.amount.toLocaleString()}. Cash balance cannot become negative.`
        );
      }

      if (isPayingOut && !isCashAccount && projectedSourceBal < 0 && !payload.adminApprovedOverdraft) {
        throw new Error(
          `OVERDRAFT_WARNING: Insufficient balance in bank account (${sourceBankData.bankName}). Current balance: ৳${currentSourceBal.toLocaleString()}. After this payment, the bank balance will be negative (৳${projectedSourceBal.toLocaleString()}). Admin approval is required to proceed.`
        );
      }
    }

    // Party Balances without Math.max(0, ...) clamping (Requirement 4)
    let partyBalanceBefore: number | undefined;
    let partyBalanceAfter: number | undefined;
    let custAdvanceBefore: number | undefined;
    let custAdvanceAfter: number | undefined;

    if (payload.partyType === 'Customer' && custData) {
      partyBalanceBefore = Number(custData.currentBalance) || 0;
      custAdvanceBefore = getCustomerAvailableAdvance(custData);

      if (payload.transactionType === 'JOURNAL' && payload.subType === 'Customer Advance Adjustment') {
        if (payload.amount > custAdvanceBefore + 0.001) {
          throw new Error(
            `Advance adjustment (BDT ${payload.amount.toLocaleString()}) exceeds customer's currently available advance balance (BDT ${custAdvanceBefore.toLocaleString()}).`
          );
        }
        partyBalanceAfter = Number((partyBalanceBefore - payload.amount).toFixed(2));
        custAdvanceAfter = Math.max(0, Number((custAdvanceBefore - payload.amount).toFixed(2)));
      } else if (payload.transactionType === 'DEPOSIT') {
        partyBalanceAfter = Number((partyBalanceBefore - payload.amount).toFixed(2));
        if (payload.subType === 'Customer Advance' || payload.subType === 'Deposit from Customer') {
          custAdvanceAfter = Number((custAdvanceBefore + payload.amount).toFixed(2));
        } else {
          const positiveReceivable = Math.max(0, partyBalanceBefore);
          const excessOverReceivable = Math.max(0, payload.amount - positiveReceivable);
          custAdvanceAfter = Number((custAdvanceBefore + excessOverReceivable).toFixed(2));
        }
      } else if (payload.transactionType === 'PAYMENT') {
        partyBalanceAfter = Number((partyBalanceBefore + payload.amount).toFixed(2));
        custAdvanceAfter = Math.max(0, Number((custAdvanceBefore - payload.amount).toFixed(2)));
      } else {
        // JOURNAL Sales Invoice: increases Receivable (1050), preserves advanceBalance
        partyBalanceAfter = Number((partyBalanceBefore + payload.amount).toFixed(2));
        custAdvanceAfter = custAdvanceBefore;
      }
    } else if (payload.partyType === 'Supplier' && suppData) {
      partyBalanceBefore = Number(suppData.currentPayable) || 0;
      // Payment (PAYMENT) reduces payable. Refund (DEPOSIT) increases payable.
      const suppDelta = payload.transactionType === 'PAYMENT' ? -payload.amount : payload.amount;
      partyBalanceAfter = partyBalanceBefore + suppDelta;
    }

    // Build True Double-Entry Ledger Lines (Requirement 3)
    const ledgerLines: AccountLedgerEntry[] = [];
    const nowIso = new Date().toISOString();

    if (payload.transactionType === 'CONTRA' && destBankData) {
      // Contra: Debit destination, Credit source
      const currentDestBal = Number(destBankData.ledgerBalance) || 0;
      const projectedDestBal = currentDestBal + payload.amount;

      // Dr Destination Bank
      ledgerLines.push({
        id: `led-${txnId}-dr-dest`,
        transactionId: txnId,
        voucherNo,
        date: payload.date,
        accountType: 'Bank/Cash',
        accountId: payload.destBankAccountId!,
        accountName: `${destBankData.bankName} (${destBankData.accountNumber})`,
        description: `Contra Transfer In from ${sourceBankData.bankName} (Ref: ${payload.referenceNo || 'N/A'})`,
        debit: payload.amount,
        credit: 0,
        runningBalance: projectedDestBal,
        branch: payload.branch,
        status: 'active',
        createdAt: nowIso
      });

      // Cr Source Bank
      ledgerLines.push({
        id: `led-${txnId}-cr-src`,
        transactionId: txnId,
        voucherNo,
        date: payload.date,
        accountType: 'Bank/Cash',
        accountId: payload.bankAccountId || 'bank-default',
        accountName: sourceBankName,
        description: `Contra Transfer Out to ${destBankData.bankName} (Ref: ${payload.referenceNo || 'N/A'})`,
        debit: 0,
        credit: payload.amount,
        runningBalance: projectedSourceBal,
        branch: payload.branch,
        status: 'active',
        createdAt: nowIso
      });
    } else if (payload.partyType === 'Customer') {
      if (payload.transactionType === 'DEPOSIT') {
        // Customer collection: Dr Bank/Cash, Cr Customer
        ledgerLines.push({
          id: `led-${txnId}-dr-bank`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Bank/Cash',
          accountId: payload.bankAccountId || 'bank-default',
          accountName: sourceBankName,
          description: `Collection from Customer: ${payload.partyName} (Ref: ${payload.referenceNo || 'N/A'})`,
          debit: payload.amount,
          credit: 0,
          runningBalance: projectedSourceBal,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });

        ledgerLines.push({
          id: `led-${txnId}-cr-cust`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Customer',
          accountId: payload.partyId || 'cust-general',
          accountName: payload.partyName || 'Customer',
          description: `Payment received into ${sourceBankName} (Ref: ${payload.referenceNo || 'N/A'})`,
          debit: 0,
          credit: payload.amount,
          runningBalance: partyBalanceAfter ?? 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });
      } else if (payload.transactionType === 'JOURNAL' && payload.subType === 'Customer Advance Adjustment') {
        // Customer Advance Adjustment: Dr Customer Advance Deposits (2050) / Cr Accounts Receivable (1050) (Customer)
        ledgerLines.push({
          id: `led-${txnId}-dr-adv`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'AccountHead',
          accountId: payload.accountHeadCode || '2050',
          accountName: payload.accountHeadName || 'Customer Advance Deposits (2050)',
          description: payload.note || `Customer Advance adjusted against Invoice ${payload.referenceNo || 'N/A'} (${payload.partyName || 'Customer'})`,
          debit: payload.amount,
          credit: 0,
          runningBalance: custAdvanceAfter ?? 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });

        ledgerLines.push({
          id: `led-${txnId}-cr-cust`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Customer',
          accountId: payload.partyId || 'cust-general',
          accountName: payload.partyName || 'Customer Receivable (1050)',
          description: payload.note || `Accounts Receivable (1050) settled from Customer Advance (2050) on Invoice ${payload.referenceNo || 'N/A'}`,
          debit: 0,
          credit: payload.amount,
          runningBalance: partyBalanceAfter ?? 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });
      } else if (payload.transactionType === 'JOURNAL') {
        // Sales Invoice Entry: Dr Customer Receivable (1050), Cr Sales Revenue (4010)
        ledgerLines.push({
          id: `led-${txnId}-dr-cust`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Customer',
          accountId: payload.partyId || 'cust-general',
          accountName: payload.partyName || 'Customer Receivable',
          description: `Sales Invoice: ${payload.referenceNo || 'N/A'}`,
          debit: payload.amount,
          credit: 0,
          runningBalance: partyBalanceAfter ?? 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });

        ledgerLines.push({
          id: `led-${txnId}-cr-sales`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'AccountHead',
          accountId: payload.accountHeadCode || '4010',
          accountName: payload.accountHeadName || 'Gross Sales Revenue',
          description: `Sales Revenue on Invoice ${payload.referenceNo || 'N/A'}`,
          debit: 0,
          credit: payload.amount,
          runningBalance: 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });
      } else {
        // Pay / Refund to Customer: Dr Customer, Cr Bank/Cash
        ledgerLines.push({
          id: `led-${txnId}-dr-cust`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Customer',
          accountId: payload.partyId || 'cust-general',
          accountName: payload.partyName || 'Customer',
          description: `Refund / Payment to customer from ${sourceBankName}`,
          debit: payload.amount,
          credit: 0,
          runningBalance: partyBalanceAfter ?? 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });

        ledgerLines.push({
          id: `led-${txnId}-cr-bank`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Bank/Cash',
          accountId: payload.bankAccountId || 'bank-default',
          accountName: sourceBankName,
          description: `Paid to Customer: ${payload.partyName} (Ref: ${payload.referenceNo || 'N/A'})`,
          debit: 0,
          credit: payload.amount,
          runningBalance: projectedSourceBal,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });
      }
    } else if (payload.partyType === 'Supplier') {
      if (payload.transactionType === 'PAYMENT') {
        // Payment to Supplier: Dr Supplier, Cr Bank/Cash
        ledgerLines.push({
          id: `led-${txnId}-dr-supp`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Supplier',
          accountId: payload.partyId || 'supp-general',
          accountName: payload.partyName || 'Supplier',
          description: `Payment from ${sourceBankName} (Ref: ${payload.referenceNo || 'N/A'})`,
          debit: payload.amount,
          credit: 0,
          runningBalance: partyBalanceAfter ?? 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });

        ledgerLines.push({
          id: `led-${txnId}-cr-bank`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Bank/Cash',
          accountId: payload.bankAccountId || 'bank-default',
          accountName: sourceBankName,
          description: `Paid to Supplier: ${payload.partyName} (Ref: ${payload.referenceNo || 'N/A'})`,
          debit: 0,
          credit: payload.amount,
          runningBalance: projectedSourceBal,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });
      } else if (payload.transactionType === 'JOURNAL') {
        // Billed Vendor Invoice / Purchase Journal: Dr Inventory / Expense, Cr Supplier Payable
        const headCode = payload.accountHeadCode || '13100';
        const headName = payload.accountHeadName || 'Raw Material Inventory (Landed Stock)';
        ledgerLines.push({
          id: `led-${txnId}-dr-head`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'AccountHead',
          accountId: payload.accountHeadId || headCode,
          accountName: headName,
          description: payload.note || `LC Billed Expense - ${headName}`,
          debit: payload.amount,
          credit: 0,
          runningBalance: 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });

        ledgerLines.push({
          id: `led-${txnId}-cr-supp`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Supplier',
          accountId: payload.partyId || 'supp-general',
          accountName: payload.partyName || 'Supplier',
          description: `Vendor Bill from ${payload.partyName} (Ref: ${payload.referenceNo || 'N/A'})`,
          debit: 0,
          credit: payload.amount,
          runningBalance: partyBalanceAfter ?? 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });
      } else {
        // Supplier refund to us: Dr Bank/Cash, Cr Supplier
        ledgerLines.push({
          id: `led-${txnId}-dr-bank`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Bank/Cash',
          accountId: payload.bankAccountId || 'bank-default',
          accountName: sourceBankName,
          description: `Refund from Supplier: ${payload.partyName}`,
          debit: payload.amount,
          credit: 0,
          runningBalance: projectedSourceBal,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });

        ledgerLines.push({
          id: `led-${txnId}-cr-supp`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Supplier',
          accountId: payload.partyId || 'supp-general',
          accountName: payload.partyName || 'Supplier',
          description: `Supplier refund deposited into ${sourceBankName}`,
          debit: 0,
          credit: payload.amount,
          runningBalance: partyBalanceAfter ?? 0,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });
      }
    } else {
      // General Expenses or General Deposits (Multi-Line or Single Head)
      const rawLines = payload.debitLines || payload.creditLines || payload.multiLines || [];
      const validLines = rawLines.filter(l => Number(l.amount) > 0);

      if (payload.transactionType === 'PAYMENT') {
        if (validLines.length > 0) {
          // One Debit line per expense head
          validLines.forEach((l, idx) => {
            const lineAmt = Number(l.amount) || 0;
            ledgerLines.push({
              id: `led-${txnId}-dr-${idx + 1}`,
              transactionId: txnId,
              voucherNo,
              date: payload.date,
              accountType: 'AccountHead',
              accountId: l.accountCode || `head-${idx}`,
              accountName: l.particulars || l.accountCode,
              description: l.particulars || `Expense Line ${idx + 1}`,
              debit: lineAmt,
              credit: 0,
              runningBalance: 0,
              branch: payload.branch,
              status: 'active',
              createdAt: nowIso
            });
          });
        } else {
          // Single Head Expense
          ledgerLines.push({
            id: `led-${txnId}-dr-head`,
            transactionId: txnId,
            voucherNo,
            date: payload.date,
            accountType: 'AccountHead',
            accountId: payload.accountHeadId || 'head-exp',
            accountName: payload.accountHeadName || 'General Expense',
            description: payload.note || payload.subType,
            debit: payload.amount,
            credit: 0,
            runningBalance: 0,
            branch: payload.branch,
            status: 'active',
            createdAt: nowIso
          });
        }

        // Also add any explicit credit adjustment lines (e.g. LC Margin Deposit Adjusted)
        if (payload.creditLines && payload.creditLines.length > 0) {
          payload.creditLines.filter(c => Number(c.amount) > 0).forEach((c, cIdx) => {
            const cAmt = Number(c.amount) || 0;
            ledgerLines.push({
              id: `led-${txnId}-cr-adj-${cIdx + 1}`,
              transactionId: txnId,
              voucherNo,
              date: payload.date,
              accountType: 'AccountHead',
              accountId: c.accountCode || `head-cr-${cIdx}`,
              accountName: c.particulars || c.accountCode,
              description: c.particulars || `Adjustment Credit`,
              debit: 0,
              credit: cAmt,
              runningBalance: 0,
              branch: payload.branch,
              status: 'active',
              createdAt: nowIso
            });
          });
        }

        // Balancing Credit line to Bank/Cash account
        ledgerLines.push({
          id: `led-${txnId}-cr-bank`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Bank/Cash',
          accountId: payload.bankAccountId || 'bank-default',
          accountName: sourceBankName,
          description: payload.note || `Paid from ${sourceBankName} for ${payload.subType}`,
          debit: 0,
          credit: payload.amount,
          runningBalance: projectedSourceBal,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });
      } else {
        // General Deposit / Income
        // Balancing Debit line to Bank/Cash account
        ledgerLines.push({
          id: `led-${txnId}-dr-bank`,
          transactionId: txnId,
          voucherNo,
          date: payload.date,
          accountType: 'Bank/Cash',
          accountId: payload.bankAccountId || 'bank-default',
          accountName: sourceBankName,
          description: payload.note || `Deposit into ${sourceBankName} for ${payload.subType}`,
          debit: payload.amount,
          credit: 0,
          runningBalance: projectedSourceBal,
          branch: payload.branch,
          status: 'active',
          createdAt: nowIso
        });

        if (validLines.length > 0) {
          // One Credit line per income head
          validLines.forEach((l, idx) => {
            const lineAmt = Number(l.amount) || 0;
            ledgerLines.push({
              id: `led-${txnId}-cr-${idx + 1}`,
              transactionId: txnId,
              voucherNo,
              date: payload.date,
              accountType: 'AccountHead',
              accountId: l.accountCode || `head-${idx}`,
              accountName: l.particulars || l.accountCode,
              description: l.particulars || `Income Line ${idx + 1}`,
              debit: 0,
              credit: lineAmt,
              runningBalance: 0,
              branch: payload.branch,
              status: 'active',
              createdAt: nowIso
            });
          });
        } else {
          // Single Head Income
          ledgerLines.push({
            id: `led-${txnId}-cr-head`,
            transactionId: txnId,
            voucherNo,
            date: payload.date,
            accountType: 'AccountHead',
            accountId: payload.accountHeadId || 'head-income',
            accountName: payload.accountHeadName || 'General Income',
            description: payload.note || payload.subType,
            debit: 0,
            credit: payload.amount,
            runningBalance: 0,
            branch: payload.branch,
            status: 'active',
            createdAt: nowIso
          });
        }
      }
    }

    // STRICT DOUBLE ENTRY CHECK (Requirement 3)
    const totalDebits = ledgerLines.reduce((sum, l) => sum + (Number(l.debit) || 0), 0);
    const totalCredits = ledgerLines.reduce((sum, l) => sum + (Number(l.credit) || 0), 0);
    if (Math.abs(totalDebits - totalCredits) > 0.001 || totalDebits <= 0) {
      throw new Error(
        `Double entry mismatch: Total Debit (৳${totalDebits.toLocaleString()}) and Total Credit (৳${totalCredits.toLocaleString()}) must be equal.`
      );
    }

    const resolvedLcExpenseId = payload.lcExpenseId || payload.lcExpenseRecord?.id || (payload.lcId ? `exp-${txnId}` : undefined);
    const resolvedLcExpenseRecord = payload.lcExpenseRecord
      ? {
          ...payload.lcExpenseRecord,
          id: resolvedLcExpenseId || `exp-${txnId}`,
          lcId: payload.lcId || payload.lcExpenseRecord.lcId,
          lcNumber: payload.lcNumber || payload.lcExpenseRecord.lcNumber,
          voucherNo,
          transactionId: txnId,
          postedAt: payload.lcExpenseRecord.postedAt || nowIso
        }
      : undefined;

    // Construct Transaction Record
    createdTransaction = {
      id: txnId,
      voucherNo,
      transactionType: payload.transactionType,
      subType: payload.subType as any,
      date: payload.date,
      amount: payload.amount,
      accountHeadId: payload.accountHeadId,
      accountHeadName: payload.accountHeadName,
      accountHeadCode: payload.accountHeadCode,
      partyType: payload.partyType || 'None',
      partyId: payload.partyId,
      partyName: payload.partyName,
      partyCode: payload.partyCode,
      partyPhone: payload.partyPhone,
      partyBalanceBefore,
      partyBalanceAfter,
      bankAccountId: payload.bankAccountId || 'ledger-general',
      bankAccountName: sourceBankName,
      bankAccountNumber: sourceBankData ? sourceBankData.accountNumber : undefined,
      paymentMethod: payload.paymentMethod || 'Cash',
      referenceNo: payload.referenceNo?.trim() || undefined,
      note: payload.note?.trim() || undefined,
      costCenter: payload.costCenter,
      multiLines: payload.debitLines || payload.creditLines || payload.multiLines,
      branch: payload.branch,
      lcId: payload.lcId,
      lcNumber: payload.lcNumber,
      lcExpenseId: resolvedLcExpenseId,
      lcExpenseHead: payload.lcExpenseHead || payload.lcExpenseRecord?.expenseType,
      lcExpenseRecord: resolvedLcExpenseRecord,
      status: 'active',
      createdBy: {
        uid: payload.user.uid,
        name: payload.user.name,
        email: payload.user.email
      },
      idempotencyKey: payload.idempotencyKey,
      createdAt: nowIso
    };

    createdLedgerLines = ledgerLines;

    // --- PHASE 3: ALL WRITES IN ONE ATOMIC FIRESTORE TRANSACTION ---
    // 1. Update counter
    t.set(counterRef, { current: nextNum, prefix, updatedAt: nowIso }, { merge: true });

    // 1.5 Record idempotency key if provided
    if (idempRef) {
      t.set(idempRef, {
        txnId,
        voucherNo,
        idempotencyKey: payload.idempotencyKey,
        createdAt: nowIso
      });
    }

    // 2. Write transaction document
    t.set(doc(db, 'account_transactions', txnId), cleanFirestoreData(createdTransaction));

    // 2.5 Atomically persist LC Expense record into letters_of_credit/{lcId} in the SAME transaction
    if (lcRef && resolvedLcExpenseRecord) {
      let existingLcData: any = lcSnap && lcSnap.exists() ? lcSnap.data() : null;
      if (!existingLcData && typeof window !== 'undefined' && window.localStorage) {
        try {
          const savedLcs = JSON.parse(localStorage.getItem('tradecore_lcs_v1') || '[]');
          if (Array.isArray(savedLcs)) {
            existingLcData = savedLcs.find((l: any) => l.id === payload.lcId) || null;
          }
        } catch {}
      }
      const existingExpenses: any[] = Array.isArray(existingLcData?.expenses) ? existingLcData.expenses : [];
      const hasMatch = existingExpenses.some(
        (e: any) =>
          (resolvedLcExpenseRecord.id && e.id === resolvedLcExpenseRecord.id) ||
          (e.transactionId && e.transactionId === txnId) ||
          (e.voucherNo && e.voucherNo === voucherNo)
      );
      const nextExpenses = hasMatch
        ? existingExpenses.map((e: any) =>
            (resolvedLcExpenseRecord.id && e.id === resolvedLcExpenseRecord.id) ||
            (e.transactionId && e.transactionId === txnId) ||
            (e.voucherNo && e.voucherNo === voucherNo)
              ? { ...e, ...resolvedLcExpenseRecord }
              : e
          )
        : [resolvedLcExpenseRecord, ...existingExpenses];

      t.set(
        lcRef,
        cleanFirestoreData({
          ...(existingLcData || { id: payload.lcId, lcNumber: payload.lcNumber || '' }),
          expenses: nextExpenses,
          updatedAt: nowIso
        }),
        { merge: true }
      );
    }

    // 3. Write each ledger line
    for (const line of ledgerLines) {
      t.set(doc(db, 'account_ledgers', line.id), line);
    }

    // 4. Update source bank account
    if (sourceBankRef && sourceBankData) {
      if (sourceBankSnap && sourceBankSnap.exists()) {
        t.update(sourceBankRef, {
          ledgerBalance: projectedSourceBal,
          statementBalance: (Number(sourceBankData.statementBalance) || 0) + (isPayingOut ? -payload.amount : payload.amount),
          updatedAt: nowIso
        });
      } else {
        t.set(sourceBankRef, {
          ...sourceBankData,
          ledgerBalance: projectedSourceBal,
          statementBalance: (Number(sourceBankData.statementBalance) || 0) + (isPayingOut ? -payload.amount : payload.amount),
          updatedAt: nowIso
        });
      }
      updatedSourceBankData = {
        ...sourceBankData,
        id: payload.bankAccountId,
        ledgerBalance: projectedSourceBal,
        statementBalance: (Number(sourceBankData.statementBalance) || 0) + (isPayingOut ? -payload.amount : payload.amount)
      };
    }

    // 5. Update destination bank account if CONTRA
    if (destBankRef && destBankData) {
      const destNewBal = (Number(destBankData.ledgerBalance) || 0) + payload.amount;
      const destNewStmtBal = (Number(destBankData.statementBalance) || 0) + payload.amount;
      if (destSnap && destSnap.exists()) {
        t.update(destBankRef, {
          ledgerBalance: destNewBal,
          statementBalance: destNewStmtBal,
          updatedAt: nowIso
        });
      } else {
        t.set(destBankRef, {
          ...destBankData,
          ledgerBalance: destNewBal,
          statementBalance: destNewStmtBal,
          updatedAt: nowIso
        });
      }
      updatedDestBankData = {
        ...destBankData,
        id: payload.destBankAccountId!,
        ledgerBalance: destNewBal,
        statementBalance: destNewStmtBal
      };
    }

    // 6. Update Customer balance & advanceBalance accurately
    if (custRef && custData && partyBalanceAfter !== undefined) {
      const custAdvance =
        custAdvanceAfter !== undefined
          ? custAdvanceAfter
          : partyBalanceAfter < 0
          ? Math.abs(partyBalanceAfter)
          : getCustomerAvailableAdvance(custData);
      if (custSnap && custSnap.exists()) {
        t.update(custRef, {
          currentBalance: partyBalanceAfter,
          advanceBalance: custAdvance,
          updatedAt: nowIso
        });
      } else {
        t.set(custRef, {
          ...custData,
          currentBalance: partyBalanceAfter,
          advanceBalance: custAdvance,
          updatedAt: nowIso
        });
      }
      updatedCustData = {
        ...custData,
        id: payload.partyId!,
        currentBalance: partyBalanceAfter,
        advanceBalance: custAdvance
      };
    }

    // 7. Update Supplier balance without Math.max(0, ...)
    if (suppRef && suppData && partyBalanceAfter !== undefined) {
      if (suppSnap && suppSnap.exists()) {
        t.update(suppRef, {
          currentPayable: partyBalanceAfter,
          updatedAt: nowIso
        });
      } else {
        t.set(suppRef, {
          ...suppData,
          currentPayable: partyBalanceAfter,
          updatedAt: nowIso
        });
      }
      updatedSuppData = {
        ...suppData,
        id: payload.partyId!,
        currentPayable: partyBalanceAfter
      };
    }

    // 8. Write security audit log
    const auditRef = doc(db, 'audit_logs', `audit-${Date.now()}`);
    t.set(auditRef, {
      userId: payload.user.uid,
      userEmail: payload.user.email || 'user@erp.local',
      action: `POST_${payload.transactionType}_VOUCHER`,
      timestamp: nowIso,
      details: `Posted ${voucherNo} (${payload.subType}) for amount ৳${payload.amount.toLocaleString()} with ${ledgerLines.length} double-entry ledger lines`
    });
  });
    transactionCommitted = true;
  } catch (err: any) {
    if (err?.message && (
      err.message.includes('OVERDRAFT_WARNING') ||
      err.message.includes('Insufficient') ||
      err.message.includes('exceeds customer') ||
      err.message.includes('exceeds available') ||
      err.message.includes('not found') ||
      err.message.includes('Double entry mismatch') ||
      err.message.includes('closed fiscal year') ||
      err.message.includes('Amount must be greater')
    )) {
      throw err;
    }
    if (!createdTransaction) {
      throw err;
    }
    console.warn('Firestore transaction fallback to local cache:', err?.message || err);
  }

  if (idempotentHit) {
    return createdTransaction;
  }

  // --- PHASE 4: UPDATE OFFLINE / MEMORY CACHES AFTER COMMIT ---
  try {
    // A. Update Transactions cache
    const currentTxns = getAccountTransactions();
    if (!currentTxns.some(tx => tx.id === createdTransaction.id)) {
      saveAccountTransactions([createdTransaction, ...currentTxns]);
    }

    // B. Update Ledgers cache
    const existingLedgers = getAccountLedgers();
    const existingIds = new Set(existingLedgers.map(l => l.id));
    const newLines = createdLedgerLines.filter(l => !existingIds.has(l.id));
    if (newLines.length > 0) {
      const nextLedgers = [...newLines, ...existingLedgers];
      cachedLedgers = nextLedgers;
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(LEDGER_STORAGE_KEY, JSON.stringify(nextLedgers));
        window.dispatchEvent(new CustomEvent('tradecore_account_ledgers_changed', { detail: { ledgers: nextLedgers } }));
      }
    }

    // C. Update Bank Accounts cache (use exact post-transaction state to avoid double-applying delta)
    if (updatedSourceBankData) {
      if (transactionCommitted) {
        updateBankAccount(updatedSourceBankData);
      } else {
        updateBankAccountBalance(updatedSourceBankData.id, isPayingOut ? -payload.amount : payload.amount);
      }
    }
    if (updatedDestBankData) {
      if (transactionCommitted) {
        updateBankAccount(updatedDestBankData);
      } else {
        updateBankAccountBalance(updatedDestBankData.id, payload.amount);
      }
    }

    // D. Update Customer cache (use exact post-transaction state to avoid double-applying delta)
    if (updatedCustData) {
      if (transactionCommitted) {
        updateCustomer(updatedCustData);
      } else {
        const custDelta = payload.transactionType === 'DEPOSIT' ? -payload.amount : payload.amount;
        updateCustomerBalance(updatedCustData.id, custDelta);
      }
    }

    // E. Update Supplier cache (use exact post-transaction state to avoid double-applying delta)
    if (updatedSuppData) {
      if (transactionCommitted) {
        updateSupplier(updatedSuppData);
      } else {
        const suppDelta = payload.transactionType === 'PAYMENT' ? -payload.amount : payload.amount;
        updateSupplierPayableBalance(updatedSuppData.id, suppDelta);
      }
    }

    // F. Update local LC cache atomically if an LC expense record was posted
    if (createdTransaction.lcId && createdTransaction.lcExpenseRecord && typeof window !== 'undefined' && window.localStorage) {
      try {
        const expRec = createdTransaction.lcExpenseRecord;
        const rawLcs = localStorage.getItem('tradecore_lcs_v1');
        if (rawLcs) {
          const parsedLcs = JSON.parse(rawLcs);
          if (Array.isArray(parsedLcs)) {
            const nextLcs = parsedLcs.map((lc: any) => {
              if (lc.id !== createdTransaction.lcId) return lc;
              const currentExps: any[] = Array.isArray(lc.expenses) ? lc.expenses : [];
              const exists = currentExps.some(
                (e: any) =>
                  (expRec.id && e.id === expRec.id) ||
                  (e.transactionId && e.transactionId === createdTransaction.id) ||
                  (e.voucherNo && e.voucherNo === createdTransaction.voucherNo)
              );
              const updatedExps = exists
                ? currentExps.map((e: any) =>
                    (expRec.id && e.id === expRec.id) ||
                    (e.transactionId && e.transactionId === createdTransaction.id) ||
                    (e.voucherNo && e.voucherNo === createdTransaction.voucherNo)
                      ? { ...e, ...expRec }
                      : e
                  )
                : [expRec, ...currentExps];
              return { ...lc, expenses: updatedExps };
            });
            localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs));
            window.dispatchEvent(new CustomEvent('tradecore_lcs_changed', { detail: { lcs: nextLcs } }));
          }
        }
      } catch (lcCacheErr) {
        console.warn('Local LC expense cache update notice:', lcCacheErr);
      }
    }
  } catch (cacheErr) {
    console.warn('Local cache update notice:', cacheErr);
  }

  return createdTransaction;
}

/**
 * Backward compatibility wrapper
 */
export async function createAccountTransaction(payload: CreateTransactionPayload): Promise<AccountTransaction> {
  return postVoucher(payload);
}

/**
 * Void a Transaction (Requirement 6)
 * Accounting Safety:
 * - Creates reversing ledger entries with swapped Debit & Credit
 * - Marks original ledger entries as voided/reversed
 * - NEVER deletes or edits original ledger entries
 * - Reverses bank and customer/supplier balances
 * - Updates status to 'voided' in Firestore
 */
export async function voidAccountTransaction(
  transactionId: string, 
  voidReason: string, 
  user: { uid: string; name: string; email?: string }
): Promise<AccountTransaction> {
  if (!voidReason || !voidReason.trim()) {
    throw new Error('Void reason is strictly required');
  }

  const txns = getAccountTransactions();
  const target = txns.find(t => t.id === transactionId);
  if (!target) {
    throw new Error('Transaction not found');
  }
  if (target.status === 'voided') {
    throw new Error('Transaction is already voided');
  }

  // 1. Closed Fiscal Year Check
  const allFiscalYears = getFiscalYears();
  const closedFY = allFiscalYears.find(
    f => f.status === 'Closed' && f.startDate <= target.date && target.date <= f.endDate
  );
  if (closedFY) {
    throw new Error(
      `This voucher date (${target.date}) falls in a closed fiscal year (${closedFY.name}). Voiding vouchers in a closed fiscal year is strictly prohibited.`
    );
  }

  const nowIso = new Date().toISOString();
  const isPayment = target.transactionType === 'PAYMENT';
  const isContra = target.transactionType === 'CONTRA';

  // 2. Find and prepare Reversing Ledger Entries (Requirement 6)
  const currentLedgers = getAccountLedgers();
  const originalLedgers = currentLedgers.filter(l => l.transactionId === transactionId && l.status !== 'voided');

  const reversingLedgers: AccountLedgerEntry[] = originalLedgers.map(orig => ({
    id: `rev-${orig.id}-${Date.now()}`,
    transactionId: orig.transactionId,
    voucherNo: orig.voucherNo,
    date: new Date().toISOString().split('T')[0],
    accountType: orig.accountType,
    accountId: orig.accountId,
    accountName: orig.accountName,
    description: `[REVERSAL] ${orig.description} (Void Reason: ${voidReason.trim()})`,
    debit: orig.credit, // Swapped!
    credit: orig.debit, // Swapped!
    runningBalance: 0,
    branch: orig.branch,
    status: 'active',
    createdAt: nowIso
  }));

  // Reversal balance deltas
  const reverseBankDelta = isPayment ? target.amount : -target.amount;

  // 3. Execute in Firestore Batch
  const batch = writeBatch(db);

  // A. Mark original ledgers as voided
  for (const orig of originalLedgers) {
    batch.update(doc(db, 'account_ledgers', orig.id), {
      status: 'voided',
      voidedAt: nowIso,
      voidReason: voidReason.trim()
    });
  }

  // B. Write new reversing ledgers
  for (const rev of reversingLedgers) {
    batch.set(doc(db, 'account_ledgers', rev.id), rev);
  }

  // C. Update transaction status
  const voidedTxn: AccountTransaction = {
    ...target,
    status: 'voided',
    voidReason: voidReason.trim(),
    voidedBy: {
      uid: user.uid,
      name: user.name
    },
    voidedAt: nowIso,
    updatedBy: {
      uid: user.uid,
      name: user.name
    },
    updatedAt: nowIso
  };

  batch.update(doc(db, 'account_transactions', transactionId), {
    status: 'voided',
    voidReason: voidReason.trim(),
    voidedBy: { uid: user.uid, name: user.name },
    voidedAt: nowIso,
    updatedBy: { uid: user.uid, name: user.name },
    updatedAt: nowIso
  });

  // D. Write Security Audit Log
  const auditRef = doc(db, 'audit_logs', `audit-void-${Date.now()}`);
  batch.set(auditRef, {
    userId: user.uid,
    userEmail: user.email || 'admin@erp.local',
    action: 'VOID_TRANSACTION_VOUCHER',
    timestamp: nowIso,
    details: `Voided voucher ${target.voucherNo} with reason: ${voidReason.trim()}. Generated ${reversingLedgers.length} reversing ledger entries.`
  });

  await batch.commit();

  // 4. Update Balances and Local Storage
  if (target.transactionType === 'JOURNAL') {
    if (target.partyType === 'Customer' && target.partyId) {
      if ((target.subType as string) === 'Customer Advance Adjustment') {
        // Reversing Dr 2050 / Cr 1050 restores customer's advance (+amount) and restores receivable (+amount)
        updateCustomerBalance(target.partyId, target.amount, target.amount);
      } else {
        updateCustomerBalance(target.partyId, -target.amount, 0);
      }
    } else if (target.partyType === 'Supplier' && target.partyId) {
      updateSupplierPayableBalance(target.partyId, -target.amount);
    }
  } else if (isContra) {
    // Contra reversal
    if (target.bankAccountId) {
      updateBankAccountBalance(target.bankAccountId, target.amount);
    }
  } else {
    if (target.bankAccountId) {
      updateBankAccountBalance(target.bankAccountId, reverseBankDelta);
    }

    if (target.partyType === 'Customer' && target.partyId) {
      const reverseCustDelta = isPayment ? -target.amount : target.amount;
      const reverseAdvDelta =
        (target.subType as string) === 'Customer Advance' || (target.subType as string) === 'Deposit from Customer'
          ? -target.amount
          : isPayment
          ? target.amount
          : 0;
      updateCustomerBalance(target.partyId, reverseCustDelta, reverseAdvDelta);
    } else if (target.partyType === 'Supplier' && target.partyId) {
      const reverseSuppDelta = isPayment ? target.amount : -target.amount;
      updateSupplierPayableBalance(target.partyId, reverseSuppDelta);
    }
  }

  // Update memory transactions
  const updatedTxns = txns.map(t => t.id === transactionId ? voidedTxn : t);
  cachedTransactions = updatedTxns;
  saveAccountTransactions(updatedTxns);

  // Update memory ledgers
  const nextLedgers = [
    ...reversingLedgers,
    ...currentLedgers.map(l => l.transactionId === transactionId ? { ...l, status: 'voided' as const } : l)
  ];
  cachedLedgers = nextLedgers;
  if (typeof window !== 'undefined' && window.localStorage) {
    localStorage.setItem(LEDGER_STORAGE_KEY, JSON.stringify(nextLedgers));
    window.dispatchEvent(new CustomEvent('tradecore_account_ledgers_changed', { detail: { ledgers: nextLedgers } }));
  }

  return voidedTxn;
}

/**
 * Edit an Active Transaction (Requirement 6)
 * Strict accounting policy:
 * - After posting, edit may change ONLY: date, reference, and note.
 * - To change amount or account, void and re-post.
 */
export async function editAccountTransaction(
  transactionId: string,
  updatedFields: {
    date: string;
    amount?: number;
    referenceNo?: string;
    note?: string;
    bankAccountId?: string;
  },
  user: { uid: string; name: string; email?: string },
  editReason: string
): Promise<AccountTransaction> {
  const txns = getAccountTransactions();
  const original = txns.find(t => t.id === transactionId);
  if (!original) {
    throw new Error('Transaction not found');
  }
  if (original.status === 'voided') {
    throw new Error('Voided transactions cannot be edited');
  }

  // Strict Accounting Lock (Requirement 6)
  if (updatedFields.amount !== undefined && updatedFields.amount !== original.amount) {
    throw new Error(
      'Amount cannot be modified after posting. To change amount, void this voucher and re-post.'
    );
  }

  if (updatedFields.bankAccountId !== undefined && updatedFields.bankAccountId !== original.bankAccountId) {
    throw new Error(
      'Accounts cannot be modified after posting. To change account, void this voucher and re-post.'
    );
  }

  // Closed FY Check
  const allFiscalYears = getFiscalYears();
  const closedFY = allFiscalYears.find(
    f => f.status === 'Closed' && f.startDate <= updatedFields.date && updatedFields.date <= f.endDate
  );
  if (closedFY) {
    throw new Error(
      `The selected date (${updatedFields.date}) falls in a closed fiscal year (${closedFY.name}). Changing dates into a closed fiscal year is prohibited.`
    );
  }

  const logEntry: TransactionEditLog = {
    timestamp: new Date().toISOString(),
    user: {
      uid: user.uid,
      name: user.name,
      email: user.email
    },
    oldData: {
      date: original.date,
      amount: original.amount,
      referenceNo: original.referenceNo,
      note: original.note
    },
    newData: {
      date: updatedFields.date,
      referenceNo: updatedFields.referenceNo,
      note: updatedFields.note
    },
    reason: editReason
  };

  const updatedTxn: AccountTransaction = {
    ...original,
    date: updatedFields.date,
    referenceNo: updatedFields.referenceNo?.trim() || undefined,
    note: updatedFields.note?.trim() || undefined,
    updatedBy: { uid: user.uid, name: user.name },
    updatedAt: new Date().toISOString(),
    editHistory: [...(original.editHistory || []), logEntry]
  };

  const nextTxns = txns.map(t => t.id === transactionId ? updatedTxn : t);
  cachedTransactions = nextTxns;
  saveAccountTransactions(nextTxns);

  // Update in Firestore
  const docRef = doc(db, 'account_transactions', transactionId);
  await updateDoc(docRef, {
    date: updatedFields.date,
    referenceNo: updatedFields.referenceNo || null,
    note: updatedFields.note || null,
    updatedBy: { uid: user.uid, name: user.name },
    updatedAt: new Date().toISOString(),
    editHistory: updatedTxn.editHistory
  });

  // Write Audit Log
  const auditRef = doc(db, 'audit_logs', `audit-edit-${Date.now()}`);
  await setDoc(auditRef, {
    userId: user.uid,
    userEmail: user.email || 'user@erp.local',
    action: 'EDIT_TRANSACTION_METADATA',
    timestamp: new Date().toISOString(),
    details: `Updated metadata for voucher ${original.voucherNo} (Date: ${updatedFields.date}, Reason: ${editReason})`
  });

  return updatedTxn;
}

export function subscribeAccountTransactions(callback: (txns: AccountTransaction[]) => void): () => void {
  txnSubscribers.add(callback);
  callback(cachedTransactions);

  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ transactions: AccountTransaction[] }>;
    if (customEvt.detail?.transactions) {
      callback(customEvt.detail.transactions);
    } else {
      callback(getAccountTransactions());
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener(ACCOUNT_TXN_EVENT, handler);
    return () => {
      txnSubscribers.delete(callback);
      window.removeEventListener(ACCOUNT_TXN_EVENT, handler);
    };
  }
  return () => {
    txnSubscribers.delete(callback);
  };
}

export function subscribeAccountHeads(callback: (heads: AccountHead[]) => void): () => void {
  headSubscribers.add(callback);
  callback(cachedAccountHeads);

  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ heads: AccountHead[] }>;
    if (customEvt.detail?.heads) {
      callback(customEvt.detail.heads);
    } else {
      callback(getAccountHeads());
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener(ACCOUNT_HEADS_EVENT, handler);
    return () => {
      headSubscribers.delete(callback);
      window.removeEventListener(ACCOUNT_HEADS_EVENT, handler);
    };
  }
  return () => {
    headSubscribers.delete(callback);
  };
}

export function getAccountLedgers(): AccountLedgerEntry[] {
  return cachedLedgers;
}

export function subscribeAccountLedgers(callback: (ledgers: AccountLedgerEntry[]) => void): () => void {
  ledgerSubscribers.add(callback);
  callback(cachedLedgers);

  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ ledgers: AccountLedgerEntry[] }>;
    if (customEvt.detail?.ledgers) {
      callback(customEvt.detail.ledgers);
    } else {
      callback(getAccountLedgers());
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('tradecore_account_ledgers_changed', handler);
    return () => {
      ledgerSubscribers.delete(callback);
      window.removeEventListener('tradecore_account_ledgers_changed', handler);
    };
  }
  return () => {
    ledgerSubscribers.delete(callback);
  };
}

// ==========================================
// UNIFIED LC MARGIN SERVICE (Fix 3 Requirement 1, 2, 3, 4, 6)
// ==========================================

export interface PostLcMarginParams {
  lc: LetterOfCredit;
  bankAccountId: string;
  paymentDate: string;
  marginPercent?: number;
  marginAmountBDT?: number;
  user: {
    uid: string;
    name: string;
    email?: string;
  };
  adminApprovedOverdraft?: boolean;
  allLcs?: LetterOfCredit[];
  idempotencyKey?: string;
}

export interface PostLcMarginResult {
  updatedLc: LetterOfCredit;
  transaction: AccountTransaction;
}

/**
 * Exact margin calculation according to Requirement 2:
 * marginAmountBDT = marginPercent x LC value in BDT (including approved amendments) at the exchange rate on the margin payment date.
 */
export function computeExpectedLcMarginBDT(lc: LetterOfCredit, paymentDate?: string): number {
  const marginPercent = lc.marginPercent !== undefined ? lc.marginPercent : (lc.marginDepositPercent ?? 0);
  if (marginPercent <= 0) return 0;

  let foreignVal = lc.cfrAmount || (lc.officialLcTotal || 0);

  // Include approved amendments if present on LC
  if ((lc as any).amendments && Array.isArray((lc as any).amendments)) {
    for (const amd of (lc as any).amendments) {
      if (amd.approved || amd.status === 'Approved' || amd.status === 'approved') {
        foreignVal += (Number(amd.amountForeign || amd.amount) || 0);
      }
    }
  }

  // Exchange rate on the margin payment date (falls back to lc.exchangeRate or default 122.50)
  const exchangeRate = lc.exchangeRate || 122.50;
  const lcValueBdt = foreignVal * exchangeRate;
  return Math.round((marginPercent / 100) * lcValueBdt);
}

/**
 * Unified LC margin posting:
 * Dr LC Margin Deposit (asset) / Cr Bank or Cash in one atomic step.
 * Blocks duplicate voucher links across LCs.
 * Stores single fields: marginPercent, marginAmountBDT, marginVoucherId, marginVoucherNo.
 */
export async function postLcMargin(params: PostLcMarginParams): Promise<PostLcMarginResult> {
  const { lc, bankAccountId, paymentDate, user, adminApprovedOverdraft, allLcs = [] } = params;

  // 1. Guard: Check if LC already has a posted margin voucher
  if (lc.marginVoucherNo && lc.marginVoucherNo.trim() !== '') {
    throw new Error(`LC ${lc.lcNumber} already has linked margin voucher ${lc.marginVoucherNo}. Duplicate posting blocked.`);
  }

  // 2. Exact margin percentage and amount calculation
  const marginPercent = params.marginPercent !== undefined ? params.marginPercent : (lc.marginPercent ?? lc.marginDepositPercent ?? 0);
  if (marginPercent <= 0) {
    throw new Error('Margin percentage must be greater than zero.');
  }

  const expectedCalculated = computeExpectedLcMarginBDT({ ...lc, marginPercent }, paymentDate);
  const marginAmountBDT = params.marginAmountBDT !== undefined ? params.marginAmountBDT : (lc.marginAmountBDT ?? expectedCalculated);

  // 3. Bank Account Validation
  const bankAccounts = getBankAccounts();
  const selectedAcc = bankAccounts.find(a => a.id === bankAccountId);
  if (!selectedAcc) {
    throw new Error('Selected bank or cash account not found.');
  }

  const isCash = checkIsCashAccount(selectedAcc);

  const currentBal = Number(selectedAcc.ledgerBalance) || 0;
  if (isCash && currentBal < marginAmountBDT) {
    throw new Error(`Insufficient cash balance in ${selectedAcc.bankName} (Current: ৳${currentBal.toLocaleString()}, Required: ৳${marginAmountBDT.toLocaleString()}). Cash balance cannot be negative.`);
  }

  if (!isCash && currentBal < marginAmountBDT && !adminApprovedOverdraft) {
    throw new Error(`Bank account ${selectedAcc.bankName} has insufficient balance (Current: ৳${currentBal.toLocaleString()}, Required: ৳${marginAmountBDT.toLocaleString()}). Admin overdraft approval required.`);
  }

  // 4. Ensure LC Margin Deposit Head exists (Asset Head)
  let lcMarginHead = getAccountHeads().find(h => h.code === 'OTH-LC-MRG' || h.code === '11320' || h.name.toLowerCase().includes('lc margin'));
  if (!lcMarginHead) {
    lcMarginHead = await addAccountHead({
      code: 'OTH-LC-MRG',
      name: 'LC Margin Deposit',
      nameEn: 'LC Margin Deposit',
      nameBn: 'LC Margin Deposit',
      type: 'Other',
      description: 'Bank LC cash margin held and adjusted against final retirement of import bills',
      active: true
    });
  }

  // 5. Post atomic payment voucher via postVoucher with idempotency
  const idempotencyKey = params.idempotencyKey || `margin_${(lc.normalizedLcNumber || lc.lcNumber).trim().toUpperCase()}`;
  const narration = `LC Margin Deposit - LC ${lc.lcNumber} - ${lc.issuingBank} - ${lc.supplierName}`;
  const postedTxn = await postVoucher({
    transactionType: 'PAYMENT',
    subType: 'LC Margin Deposit',
    date: paymentDate || new Date().toISOString().split('T')[0],
    amount: marginAmountBDT,
    bankAccountId: selectedAcc.id,
    paymentMethod: isCash ? 'Cash' : 'Bank Transfer',
    referenceNo: `LC-${lc.lcNumber}`,
    note: narration,
    costCenter: 'LC Import Banking',
    branch: selectedAcc.branch || lc.branch || 'Head Office',
    accountHeadId: lcMarginHead.id,
    accountHeadName: lcMarginHead.name,
    accountHeadCode: lcMarginHead.code,
    debitLines: [
      {
        accountCode: lcMarginHead.code || 'OTH-LC-MRG',
        particulars: `LC ${lc.lcNumber} Margin Deposit (${marginPercent}%)`,
        amount: marginAmountBDT
      }
    ],
    user,
    adminApprovedOverdraft: Boolean(!isCash && currentBal < marginAmountBDT && adminApprovedOverdraft),
    idempotencyKey
  });

  // 6. Voucher Uniqueness check: Ensure this voucher is not linked to any other LC
  const duplicateLc = allLcs.find(l => l.id !== lc.id && (l.marginVoucherNo === postedTxn.voucherNo || (l.marginVoucherId && l.marginVoucherId === postedTxn.id)));
  if (duplicateLc) {
    throw new Error(`Voucher ${postedTxn.voucherNo} is already linked to LC ${duplicateLc.lcNumber}. Each voucher may only be linked to one LC.`);
  }

  // 7. Update LC Document with single unified fields
  const updatedLc: LetterOfCredit = {
    ...lc,
    marginPercent,
    marginAmountBDT,
    marginVoucherId: postedTxn.id,
    marginVoucherNo: postedTxn.voucherNo,
    // Backwards-compatible aliases
    marginDepositPercent: marginPercent,
    marginAmountLocal: marginAmountBDT,
    marginTransactionId: postedTxn.id,
    marginPaidFromAccountId: selectedAcc.id,
    marginPaidFromAccountName: `${selectedAcc.bankName} (${selectedAcc.accountNumber})`,
    marginPaymentDate: paymentDate || new Date().toISOString().split('T')[0],
    marginPostedAt: new Date().toISOString(),
    marginAdjustedTotal: 0,
    marginStatus: 'posted'
  };

  return { updatedLc, transaction: postedTxn };
}

export interface ReverseAndCorrectParams {
  lc: LetterOfCredit;
  bankAccountId: string;
  reason: string;
  user: {
    uid: string;
    name: string;
    email?: string;
  };
  allLcs?: LetterOfCredit[];
}

export interface ReverseAndCorrectResult {
  updatedLc: LetterOfCredit;
  reversalTxn: AccountTransaction;
  correctedTxn: AccountTransaction;
}

/**
 * Correct by reversal (Admin only):
 * Creates a reversing voucher and a corrected voucher with mandatory reason.
 * Never edits or deletes the original voucher.
 */
export async function reverseAndCorrectLcMargin(params: ReverseAndCorrectParams): Promise<ReverseAndCorrectResult> {
  const { lc, bankAccountId, reason, user, allLcs = [] } = params;

  if (!reason || !reason.trim()) {
    throw new Error('Mandatory reason required for reversal and correction.');
  }

  const bankAccounts = getBankAccounts();
  const selectedAcc = bankAccounts.find(a => a.id === bankAccountId);
  if (!selectedAcc) {
    throw new Error('Selected bank account not found.');
  }

  // Stored values from original record
  const storedAmount = lc.marginAmountBDT ?? lc.marginAmountLocal ?? 0;
  const originalVoucherNo = lc.marginVoucherNo || 'PV-ORIG';

  // Expected correct values
  const marginPercent = lc.marginPercent ?? lc.marginDepositPercent ?? 0;
  if (marginPercent <= 0) {
    throw new Error('Margin percentage must be greater than zero to calculate correct margin.');
  }
  const today = new Date().toISOString().split('T')[0];
  const expectedAmountBDT = computeExpectedLcMarginBDT(lc, today);

  // Ensure LC Margin Deposit Head
  let lcMarginHead = getAccountHeads().find(h => h.code === 'OTH-LC-MRG' || h.code === '11320' || h.name.toLowerCase().includes('lc margin'));
  if (!lcMarginHead) {
    lcMarginHead = await addAccountHead({
      code: 'OTH-LC-MRG',
      name: 'LC Margin Deposit',
      nameEn: 'LC Margin Deposit',
      nameBn: 'LC Margin Deposit',
      type: 'Other',
      description: 'Bank LC cash margin held and adjusted against final retirement of import bills',
      active: true
    });
  }

  // 1. Post Reversing Voucher (Restores bank balance, Cr LC Margin Deposit)
  const reversalTxn = await postVoucher({
    transactionType: 'DEPOSIT',
    subType: 'LC Margin Reversal',
    date: today,
    amount: storedAmount,
    bankAccountId: selectedAcc.id,
    paymentMethod: 'Bank Transfer',
    referenceNo: `REV-${originalVoucherNo}`,
    note: `Reversal of margin voucher ${originalVoucherNo} for LC ${lc.lcNumber}. Reason: ${reason.trim()}`,
    costCenter: 'LC Import Banking',
    branch: selectedAcc.branch || lc.branch || 'Head Office',
    accountHeadId: lcMarginHead.id,
    accountHeadName: lcMarginHead.name,
    accountHeadCode: lcMarginHead.code,
    creditLines: [
      {
        accountCode: lcMarginHead.code || 'OTH-LC-MRG',
        particulars: `Reversal of LC ${lc.lcNumber} Margin Deposit (${originalVoucherNo})`,
        amount: storedAmount
      }
    ],
    user
  });

  // 2. Post Corrected Voucher (Dr LC Margin Deposit / Cr Bank with exact expected amount)
  const correctedTxn = await postVoucher({
    transactionType: 'PAYMENT',
    subType: 'LC Margin Deposit (Corrected)',
    date: today,
    amount: expectedAmountBDT,
    bankAccountId: selectedAcc.id,
    paymentMethod: 'Bank Transfer',
    referenceNo: `CORR-${originalVoucherNo}`,
    note: `Corrected margin deposit for LC ${lc.lcNumber} (${marginPercent}% of CFR). Reason: ${reason.trim()}`,
    costCenter: 'LC Import Banking',
    branch: selectedAcc.branch || lc.branch || 'Head Office',
    accountHeadId: lcMarginHead.id,
    accountHeadName: lcMarginHead.name,
    accountHeadCode: lcMarginHead.code,
    debitLines: [
      {
        accountCode: lcMarginHead.code || 'OTH-LC-MRG',
        particulars: `LC ${lc.lcNumber} Corrected Margin Deposit (${marginPercent}%)`,
        amount: expectedAmountBDT
      }
    ],
    user
  });

  // Ensure corrected voucher is unique
  const duplicateLc = allLcs.find(l => l.id !== lc.id && l.marginVoucherNo === correctedTxn.voucherNo);
  if (duplicateLc) {
    throw new Error(`Corrected voucher ${correctedTxn.voucherNo} is already linked to another LC.`);
  }

  // 3. Update LC Document with corrected fields
  const updatedLc: LetterOfCredit = {
    ...lc,
    marginPercent,
    marginAmountBDT: expectedAmountBDT,
    marginVoucherId: correctedTxn.id,
    marginVoucherNo: correctedTxn.voucherNo,
    marginReversalVoucherNo: reversalTxn.voucherNo,
    marginCorrectionReason: reason.trim(),
    // Backwards-compatible aliases
    marginDepositPercent: marginPercent,
    marginAmountLocal: expectedAmountBDT,
    marginTransactionId: correctedTxn.id,
    marginPaidFromAccountId: selectedAcc.id,
    marginPaidFromAccountName: `${selectedAcc.bankName} (${selectedAcc.accountNumber})`,
    marginPaymentDate: today,
    marginPostedAt: new Date().toISOString(),
    marginStatus: 'posted'
  };

  return { updatedLc, reversalTxn, correctedTxn };
}

// ==========================================
// ATOMIC LC CREATION & DUPLICATE GOVERNANCE (Part 2 & Part 3)
// ==========================================

export interface CreateLcAtomicParams {
  lcData: LetterOfCredit;
  bankAccountId?: string;
  marginPaymentDate?: string;
  openingChargesNum?: number;
  openingChargeHeadName?: string;
  user: {
    uid: string;
    name: string;
    email?: string;
  };
  adminApprovedOverdraft?: boolean;
  allLcs?: LetterOfCredit[];
}

export interface CreateLcAtomicResult {
  createdLc: LetterOfCredit;
  marginTxn?: AccountTransaction;
  chargesTxn?: AccountTransaction;
}

export async function createLetterOfCreditAtomic(params: CreateLcAtomicParams): Promise<CreateLcAtomicResult> {
  const { lcData, bankAccountId, marginPaymentDate, openingChargesNum = 0, openingChargeHeadName, user, adminApprovedOverdraft, allLcs = [] } = params;

  // 1. Normalize LC number (trim, uppercase)
  const normalizedLcNumber = (lcData.lcNumber || '').trim().toUpperCase();
  if (!normalizedLcNumber) {
    throw new Error('LC number is required.');
  }

  // 2. Synchronous in-memory unique check
  const duplicateMem = allLcs.find(l => 
    !l.isVoided && l.status !== 'Voided' && 
    (l.normalizedLcNumber || l.lcNumber.trim().toUpperCase()) === normalizedLcNumber
  );
  if (duplicateMem) {
    throw new Error('LC number already exists');
  }

  // 3. Margin & opening charges calculation
  const marginPercent = lcData.marginPercent !== undefined 
    ? lcData.marginPercent 
    : (lcData.marginDepositPercent ?? 0);
  const marginAmountBDT = lcData.marginAmountBDT !== undefined
    ? lcData.marginAmountBDT
    : computeExpectedLcMarginBDT({ ...lcData, marginPercent }, marginPaymentDate);

  const totalDeductionBdt = (marginPercent > 0 ? marginAmountBDT : 0) + openingChargesNum;

  // 4. Validate selected bank/cash account
  let selectedAcc: any = null;
  let isCash = false;
  let currentBal = 0;

  if (totalDeductionBdt > 0) {
    if (!bankAccountId) {
      throw new Error('Please select a Bank or Cash account for Margin payment.');
    }
    const bankAccounts = getBankAccounts();
    selectedAcc = bankAccounts.find(a => a.id === bankAccountId);
    if (!selectedAcc) {
      throw new Error('Selected bank or cash account not found.');
    }
    isCash = checkIsCashAccount(selectedAcc);
    currentBal = Number(selectedAcc.ledgerBalance) || 0;
    if (isCash && currentBal < totalDeductionBdt) {
      throw new Error(`Insufficient cash balance in ${selectedAcc.bankName} (Current: ৳${currentBal.toLocaleString()}, Required: ৳${totalDeductionBdt.toLocaleString()}). Cash balance cannot be negative.`);
    }
    if (!isCash && currentBal < totalDeductionBdt && !adminApprovedOverdraft) {
      throw new Error(`Bank account ${selectedAcc.bankName} has insufficient balance (Current: ৳${currentBal.toLocaleString()}, Required: ৳${totalDeductionBdt.toLocaleString()}). Admin overdraft approval required.`);
    }
  }

  // Ensure LC Margin Deposit Head exists
  let lcMarginHead = getAccountHeads().find(h => h.code === 'OTH-LC-MRG' || h.code === '11320' || h.name.toLowerCase().includes('lc margin'));
  if (!lcMarginHead && marginPercent > 0) {
    lcMarginHead = await addAccountHead({
      code: 'OTH-LC-MRG',
      name: 'LC Margin Deposit',
      nameEn: 'LC Margin Deposit',
      nameBn: 'LC Margin Deposit',
      type: 'Other',
      description: 'Bank LC cash margin held and adjusted against final retirement of import bills',
      active: true
    });
  }

  let finalLc!: LetterOfCredit;
  let createdMarginTxn: AccountTransaction | undefined;
  let createdChargeTxn: AccountTransaction | undefined;
  let finalProjectedBal = currentBal;
  const nowIso = new Date().toISOString();
  const paymentDateStr = marginPaymentDate || nowIso.split('T')[0];

  // 5. Execute in ONE atomic Firestore transaction (Part 2 Item 3 & 4)
  await runTransaction(db, async (t) => {
    // --- PHASE 1: READS ---
    // a. Claim LC Number Registry entry
    const lcRegRef = doc(db, 'lc_number_registry', normalizedLcNumber);
    const regSnap = await t.get(lcRegRef);
    if (regSnap.exists()) {
      const regData = regSnap.data();
      if (regData?.status !== 'voided' && regData?.status !== 'released') {
        throw new Error('LC number already exists');
      }
    }

    // b. Counter for PV
    const counterRef = doc(db, 'account_counters', 'voucher_pv');
    const counterSnap = await t.get(counterRef);

    // c. Source bank account
    let sourceBankSnap: any = null;
    let sourceBankRef = selectedAcc ? doc(db, 'bank_accounts', selectedAcc.id) : null;
    if (sourceBankRef) {
      sourceBankSnap = await t.get(sourceBankRef);
    }

    // d. Idempotency Key
    const idempRef = doc(db, 'idempotency_keys', `margin_${normalizedLcNumber}`);
    const idempSnap = await t.get(idempRef);
    if (idempSnap.exists()) {
      const existingTxnId = idempSnap.data()?.txnId;
      if (existingTxnId) {
        const exSnap = await t.get(doc(db, 'account_transactions', existingTxnId));
        if (exSnap.exists()) {
          createdMarginTxn = exSnap.data() as AccountTransaction;
        }
      }
    }

    // --- PHASE 2: CALCULATIONS & VALIDATIONS ---
    const remoteCurrent = counterSnap.exists() ? (Number(counterSnap.data()?.current) || 0) : 0;
    const allExistingTxns = getAccountTransactions();
    let maxKnown = 0;
    allExistingTxns.forEach(tx => {
      if (tx.voucherNo?.startsWith('PV-')) {
        const numPart = parseInt(tx.voucherNo.replace('PV-', ''), 10);
        if (!isNaN(numPart) && numPart > maxKnown) maxKnown = numPart;
      }
    });

    let currentVoucherCounter = Math.max(remoteCurrent, maxKnown);

    let marginVoucherNo: string | undefined;
    let marginTxnId: string | undefined;
    let drLineMargin: any;
    let crLineMargin: any;

    if (marginPercent > 0 && marginAmountBDT > 0 && !createdMarginTxn) {
      currentVoucherCounter++;
      while (allExistingTxns.some(tx => tx.voucherNo === `PV-${String(currentVoucherCounter).padStart(4, '0')}`)) {
        currentVoucherCounter++;
      }
      marginVoucherNo = `PV-${String(currentVoucherCounter).padStart(4, '0')}`;
      marginTxnId = `txn-payment-${Date.now()}`;
      finalProjectedBal -= marginAmountBDT;

      createdMarginTxn = {
        id: marginTxnId,
        voucherNo: marginVoucherNo,
        transactionType: 'PAYMENT',
        subType: 'LC Margin Deposit' as any,
        date: paymentDateStr,
        amount: marginAmountBDT,
        bankAccountId: selectedAcc.id,
        bankAccountName: `${selectedAcc.bankName} (${selectedAcc.accountNumber})`,
        bankAccountNumber: selectedAcc.accountNumber,
        paymentMethod: isCash ? 'Cash' : 'Bank Transfer',
        referenceNo: `LC-${normalizedLcNumber}`,
        note: `LC Margin Deposit - LC ${normalizedLcNumber} - ${lcData.issuingBank || 'Bank'} - ${lcData.supplierName}`,
        costCenter: 'LC Import Banking',
        branch: selectedAcc.branch || lcData.branch || 'Head Office',
        accountHeadId: lcMarginHead?.id || 'head-lc-mrg',
        accountHeadName: lcMarginHead?.name || 'LC Margin Deposit',
        accountHeadCode: lcMarginHead?.code || 'OTH-LC-MRG',
        status: 'active',
        idempotencyKey: `margin_${normalizedLcNumber}`,
        createdBy: user,
        createdAt: nowIso
      };

      drLineMargin = {
        id: `led-${marginTxnId}-dr-mrg`,
        transactionId: marginTxnId,
        voucherNo: marginVoucherNo,
        date: paymentDateStr,
        accountType: 'AccountHead',
        accountId: lcMarginHead?.code || 'OTH-LC-MRG',
        accountName: lcMarginHead?.name || 'LC Margin Deposit',
        description: `LC ${normalizedLcNumber} Margin Deposit (${marginPercent}%)`,
        debit: marginAmountBDT,
        credit: 0,
        runningBalance: 0,
        branch: selectedAcc.branch || 'Head Office',
        status: 'active',
        createdAt: nowIso
      };

      crLineMargin = {
        id: `led-${marginTxnId}-cr-bank`,
        transactionId: marginTxnId,
        voucherNo: marginVoucherNo,
        date: paymentDateStr,
        accountType: 'Bank/Cash',
        accountId: selectedAcc.id,
        accountName: selectedAcc.bankName,
        description: `Paid from ${selectedAcc.bankName} for LC Margin Deposit`,
        debit: 0,
        credit: marginAmountBDT,
        runningBalance: finalProjectedBal,
        branch: selectedAcc.branch || 'Head Office',
        status: 'active',
        createdAt: nowIso
      };
    }

    let chargeVoucherNo: string | undefined;
    let chargeTxnId: string | undefined;
    let drLineCharge: any;
    let crLineCharge: any;

    if (openingChargesNum > 0 && selectedAcc) {
      currentVoucherCounter++;
      while (allExistingTxns.some(tx => tx.voucherNo === `PV-${String(currentVoucherCounter).padStart(4, '0')}`)) {
        currentVoucherCounter++;
      }
      chargeVoucherNo = `PV-${String(currentVoucherCounter).padStart(4, '0')}`;
      chargeTxnId = `txn-payment-${Date.now() + 1}`;
      finalProjectedBal -= openingChargesNum;

      createdChargeTxn = {
        id: chargeTxnId,
        voucherNo: chargeVoucherNo,
        transactionType: 'PAYMENT',
        subType: 'Expense / General Payment' as any,
        date: paymentDateStr,
        amount: openingChargesNum,
        bankAccountId: selectedAcc.id,
        bankAccountName: `${selectedAcc.bankName} (${selectedAcc.accountNumber})`,
        bankAccountNumber: selectedAcc.accountNumber,
        paymentMethod: isCash ? 'Cash' : 'Bank Transfer',
        referenceNo: `LC-${normalizedLcNumber}-CHG`,
        note: `LC Opening Charges - LC ${normalizedLcNumber} - ${openingChargeHeadName || 'Bank Commission'}`,
        costCenter: 'LC Import Banking',
        branch: selectedAcc.branch || lcData.branch || 'Head Office',
        accountHeadName: openingChargeHeadName || 'Bank Commission',
        accountHeadCode: 'EXP-511',
        status: 'active',
        createdBy: user,
        createdAt: nowIso
      };

      drLineCharge = {
        id: `led-${chargeTxnId}-dr-chg`,
        transactionId: chargeTxnId,
        voucherNo: chargeVoucherNo,
        date: paymentDateStr,
        accountType: 'AccountHead',
        accountId: 'EXP-511',
        accountName: openingChargeHeadName || 'Bank Commission',
        description: `LC ${normalizedLcNumber} Opening Charges`,
        debit: openingChargesNum,
        credit: 0,
        runningBalance: 0,
        branch: selectedAcc.branch || 'Head Office',
        status: 'active',
        createdAt: nowIso
      };

      crLineCharge = {
        id: `led-${chargeTxnId}-cr-bank`,
        transactionId: chargeTxnId,
        voucherNo: chargeVoucherNo,
        date: paymentDateStr,
        accountType: 'Bank/Cash',
        accountId: selectedAcc.id,
        accountName: selectedAcc.bankName,
        description: `Paid from ${selectedAcc.bankName} for LC Opening Charges`,
        debit: 0,
        credit: openingChargesNum,
        runningBalance: finalProjectedBal,
        branch: selectedAcc.branch || 'Head Office',
        status: 'active',
        createdAt: nowIso
      };
    }

    // Build the final LC record
    finalLc = {
      ...lcData,
      lcNumber: lcData.lcNumber.trim(),
      normalizedLcNumber,
      marginPercent,
      marginAmountBDT,
      marginDepositPercent: marginPercent,
      marginAmountLocal: marginAmountBDT,
      marginVoucherId: marginTxnId || createdMarginTxn?.id,
      marginVoucherNo: marginVoucherNo || createdMarginTxn?.voucherNo,
      marginPaidFromAccountId: selectedAcc?.id,
      marginPaidFromAccountName: selectedAcc ? `${selectedAcc.bankName} (${selectedAcc.accountNumber})` : undefined,
      marginPaymentDate: paymentDateStr,
      marginPostedAt: nowIso,
      marginStatus: marginPercent > 0 ? 'posted' : undefined,
      openingChargesBdt: openingChargesNum,
      openingChargeHeadName: openingChargeHeadName,
      createdAt: nowIso
    };

    if (openingChargesNum > 0 && chargeTxnId && chargeVoucherNo) {
      finalLc.expenses = [
        ...(finalLc.expenses || []),
        {
          id: `exp-${Date.now()}-open`,
          expenseType: openingChargeHeadName || 'Bank Commission',
          amountLocal: openingChargesNum,
          paidTo: lcData.issuingBank || 'Bank',
          status: 'Paid',
          voucherNo: chargeVoucherNo,
          transactionId: chargeTxnId,
          paidFromAccountId: selectedAcc.id,
          paidFromAccountName: `${selectedAcc.bankName} (${selectedAcc.accountNumber})`,
          paymentDate: paymentDateStr,
          postedAt: nowIso
        }
      ];
    }

    // --- PHASE 3: WRITES ALL IN ONE TRANSACTION ---
    // 1. Claim registry
    t.set(lcRegRef, {
      lcId: lcData.id,
      lcNumber: normalizedLcNumber,
      originalLcNumber: lcData.lcNumber.trim(),
      createdAt: nowIso,
      createdBy: user.name,
      status: 'claimed'
    });

    // 2. Update voucher counter
    if (currentVoucherCounter > remoteCurrent) {
      t.set(counterRef, { current: currentVoucherCounter, prefix: 'PV', updatedAt: nowIso }, { merge: true });
    }

    // 3. Margin Voucher writes
    if (createdMarginTxn && marginTxnId) {
      t.set(doc(db, 'account_transactions', marginTxnId), cleanFirestoreData(createdMarginTxn));
      if (drLineMargin) t.set(doc(db, 'account_ledgers', drLineMargin.id), drLineMargin);
      if (crLineMargin) t.set(doc(db, 'account_ledgers', crLineMargin.id), crLineMargin);
      t.set(idempRef, {
        txnId: marginTxnId,
        voucherNo: marginVoucherNo,
        lcId: lcData.id,
        createdAt: nowIso
      });
    }

    // 4. Charge Voucher writes
    if (createdChargeTxn && chargeTxnId) {
      t.set(doc(db, 'account_transactions', chargeTxnId), cleanFirestoreData(createdChargeTxn));
      if (drLineCharge) t.set(doc(db, 'account_ledgers', drLineCharge.id), drLineCharge);
      if (crLineCharge) t.set(doc(db, 'account_ledgers', crLineCharge.id), crLineCharge);
    }

    // 5. Update bank balance
    if (sourceBankRef && selectedAcc && (marginAmountBDT > 0 || openingChargesNum > 0)) {
      if (sourceBankSnap && sourceBankSnap.exists()) {
        t.update(sourceBankRef, {
          ledgerBalance: finalProjectedBal,
          updatedAt: nowIso
        });
      } else {
        t.set(sourceBankRef, {
          ...selectedAcc,
          ledgerBalance: finalProjectedBal,
          updatedAt: nowIso
        });
      }
    }

    // 6. Write LC document in Firestore
    t.set(doc(db, 'letters_of_credit', lcData.id), cleanFirestoreData(finalLc));
  });

  // Post-commit local updates
  const newTxns: AccountTransaction[] = [];
  if (createdMarginTxn) newTxns.push(createdMarginTxn);
  if (createdChargeTxn) newTxns.push(createdChargeTxn);

  if (newTxns.length > 0) {
    const existing = getAccountTransactions();
    saveAccountTransactions([...newTxns, ...existing]);
  }

  if (selectedAcc && (marginAmountBDT > 0 || openingChargesNum > 0)) {
    updateBankAccountBalance(selectedAcc.id, -(totalDeductionBdt));
  }

  return {
    createdLc: finalLc,
    marginTxn: createdMarginTxn,
    chargesTxn: createdChargeTxn
  };
}

export async function validateAndClaimEditedLcNumber(
  newLcNumber: string,
  oldLcNumber: string,
  lcId: string,
  allLcs: LetterOfCredit[] = []
): Promise<string> {
  const normNew = newLcNumber.trim().toUpperCase();
  const normOld = oldLcNumber?.trim().toUpperCase();
  if (!normNew) throw new Error('LC number is required.');
  if (normOld && normNew === normOld) return normNew;

  // In-memory check
  const conflict = allLcs.find(l => 
    l.id !== lcId && !l.isVoided && l.status !== 'Voided' && 
    (l.normalizedLcNumber || l.lcNumber.trim().toUpperCase()) === normNew
  );
  if (conflict) {
    throw new Error('LC number already exists');
  }

  // Firestore registry check and claim inside transaction
  await runTransaction(db, async (t) => {
    const newRef = doc(db, 'lc_number_registry', normNew);
    const snap = await t.get(newRef);
    if (snap.exists()) {
      const data = snap.data();
      if (data?.status !== 'voided' && data?.status !== 'released' && data?.lcId !== lcId) {
        throw new Error('LC number already exists');
      }
    }

    t.set(newRef, {
      lcId,
      lcNumber: normNew,
      originalLcNumber: newLcNumber.trim(),
      updatedAt: new Date().toISOString(),
      status: 'claimed'
    });

    if (normOld) {
      const oldRef = doc(db, 'lc_number_registry', normOld);
      t.set(oldRef, {
        status: 'released',
        releasedAt: new Date().toISOString(),
        releasedTo: normNew
      }, { merge: true });
    }
  });

  return normNew;
}

export async function voidDuplicateLc(params: {
  lc: LetterOfCredit;
  reason: string;
  user: { uid: string; name: string; email?: string };
  bankAccountId?: string;
}): Promise<{ voidedLc: LetterOfCredit; reversalTxn?: AccountTransaction }> {
  const { lc, reason, user } = params;
  if (!reason || !reason.trim()) {
    throw new Error('Mandatory reason required for voiding duplicate LC.');
  }

  // Verification: LC must have NO linked receivings, expenses, or bills
  const receivingsCount = (lc.receivings && lc.receivings.length) || (lc.receivedQuantity ? 1 : 0) || (lc.receivedQtyMt ? 1 : 0);
  const expensesCount = (lc.expenses && lc.expenses.filter(e => e.status !== 'Voided').length) || 0;
  const billsCount = (lc.bankSettlements && lc.bankSettlements.length) || 0;

  if (receivingsCount > 0 || expensesCount > 0 || billsCount > 0) {
    throw new Error('Cannot void LC: It has linked receivings, expenses, or bills. Only unused duplicate LCs can be voided.');
  }

  const nowIso = new Date().toISOString();
  let reversalTxn: AccountTransaction | undefined;

  // If LC has a posted margin voucher, reverse it
  if (lc.marginVoucherNo && (lc.marginAmountBDT || lc.marginAmountLocal)) {
    const bankAccounts = getBankAccounts();
    const bankAccountId = params.bankAccountId || lc.marginPaidFromAccountId || bankAccounts[0]?.id;
    if (!bankAccountId) {
      throw new Error('Bank account required to process margin reversal.');
    }
    const marginAmount = lc.marginAmountBDT || lc.marginAmountLocal || 0;

    let lcMarginHead = getAccountHeads().find(h => h.code === 'OTH-LC-MRG' || h.name.toLowerCase().includes('lc margin'));
    if (!lcMarginHead) {
      lcMarginHead = await addAccountHead({
        code: 'OTH-LC-MRG',
        name: 'LC Margin Deposit',
        nameEn: 'LC Margin Deposit',
        nameBn: 'LC Margin Deposit',
        type: 'Other',
        description: 'Bank LC cash margin held and adjusted',
        active: true
      });
    }

    reversalTxn = await postVoucher({
      transactionType: 'DEPOSIT',
      subType: 'LC Margin Reversal',
      date: nowIso.split('T')[0],
      amount: marginAmount,
      bankAccountId,
      paymentMethod: 'Bank Transfer',
      referenceNo: `REV-${lc.marginVoucherNo}`,
      note: `Reversal of margin voucher ${lc.marginVoucherNo} due to voiding duplicate LC ${lc.lcNumber}. Reason: ${reason.trim()}`,
      costCenter: 'LC Import Banking',
      branch: lc.branch || 'Head Office',
      accountHeadId: lcMarginHead.id,
      accountHeadName: lcMarginHead.name,
      accountHeadCode: lcMarginHead.code,
      creditLines: [
        {
          accountCode: lcMarginHead.code || 'OTH-LC-MRG',
          particulars: `Reversal of LC ${lc.lcNumber} Margin Deposit (${lc.marginVoucherNo})`,
          amount: marginAmount
        }
      ],
      user
    });

    const allTxns = getAccountTransactions();
    const origTxn = allTxns.find(t => t.voucherNo === lc.marginVoucherNo || t.id === lc.marginVoucherId);
    if (origTxn) {
      origTxn.status = 'voided';
      origTxn.voidReason = `Voided via duplicate LC cancellation: ${reason.trim()}`;
      origTxn.voidedAt = nowIso;
      origTxn.voidedBy = { uid: user.uid, name: user.name };
      origTxn.reversalVoucherNo = reversalTxn.voucherNo;
      saveAccountTransactions(allTxns);
      try {
        await updateDoc(doc(db, 'account_transactions', origTxn.id), {
          status: 'voided',
          voidReason: origTxn.voidReason,
          voidedAt: nowIso,
          reversalVoucherNo: reversalTxn.voucherNo
        });
      } catch {}
    }
  }

  // Release LC number registry
  const normLc = (lc.normalizedLcNumber || lc.lcNumber).trim().toUpperCase();
  try {
    await updateDoc(doc(db, 'lc_number_registry', normLc), {
      status: 'voided',
      voidReason: reason.trim(),
      voidedAt: nowIso
    });
  } catch {}

  // Update LC Document
  const voidedLc: LetterOfCredit = {
    ...lc,
    status: 'Voided' as any,
    isVoided: true,
    voidReason: reason.trim(),
    voidedAt: nowIso,
    voidedBy: user.name,
    marginReversalVoucherNo: reversalTxn?.voucherNo || lc.marginReversalVoucherNo
  };

  try {
    await setDoc(doc(db, 'letters_of_credit', lc.id), cleanFirestoreData(voidedLc));
  } catch {}

  return { voidedLc, reversalTxn };
}

export async function reverseVoucher(params: {
  voucher: AccountTransaction;
  reason: string;
  user: { uid: string; name: string; email?: string };
}): Promise<{ updatedOriginal: AccountTransaction; reversalTxn: AccountTransaction }> {
  const { voucher, reason, user } = params;
  if (!reason || !reason.trim()) {
    throw new Error('Mandatory reason required for reversing voucher.');
  }
  if (voucher.status === 'voided') {
    throw new Error('This voucher has already been reversed / voided.');
  }

  const nowIso = new Date().toISOString();
  const today = nowIso.split('T')[0];

  const revType: TransactionType = voucher.transactionType === 'PAYMENT' ? 'DEPOSIT' : 'PAYMENT';
  const subType = voucher.subType === 'LC Margin Deposit' ? 'LC Margin Reversal' : 'Payment Reversal';

  let head = getAccountHeads().find(h => h.id === voucher.accountHeadId || h.code === voucher.accountHeadCode);
  if (!head) {
    head = {
      id: voucher.accountHeadId || 'OTH-LC-MRG',
      code: voucher.accountHeadCode || 'OTH-LC-MRG',
      name: voucher.accountHeadName || 'LC Margin Deposit',
      nameEn: 'LC Margin Deposit',
      nameBn: 'LC Margin Deposit',
      type: 'Other',
      active: true,
      createdAt: nowIso
    };
  }

  const reversalTxn = await postVoucher({
    transactionType: revType,
    subType,
    date: today,
    amount: voucher.amount,
    bankAccountId: voucher.bankAccountId,
    paymentMethod: voucher.paymentMethod || 'Bank Transfer',
    referenceNo: `REV-${voucher.voucherNo}`,
    note: `Exact reversal of voucher ${voucher.voucherNo}. Reason: ${reason.trim()}`,
    costCenter: voucher.costCenter || 'LC Import Banking',
    branch: voucher.branch || 'Head Office',
    accountHeadId: head.id,
    accountHeadName: head.name,
    accountHeadCode: head.code,
    creditLines: revType === 'DEPOSIT' ? [
      {
        accountCode: head.code || 'OTH-LC-MRG',
        particulars: `Reversal of ${voucher.voucherNo}`,
        amount: voucher.amount
      }
    ] : undefined,
    debitLines: revType === 'PAYMENT' ? [
      {
        accountCode: head.code || 'OTH-LC-MRG',
        particulars: `Reversal of ${voucher.voucherNo}`,
        amount: voucher.amount
      }
    ] : undefined,
    user
  });

  const allTxns = getAccountTransactions();
  const orig = allTxns.find(t => t.id === voucher.id || t.voucherNo === voucher.voucherNo);
  const updatedOriginal: AccountTransaction = {
    ...(orig || voucher),
    status: 'voided',
    voidReason: reason.trim(),
    voidedAt: nowIso,
    voidedBy: { uid: user.uid, name: user.name },
    reversalVoucherNo: reversalTxn.voucherNo
  };

  const updatedAll = allTxns.map(t => t.id === updatedOriginal.id ? updatedOriginal : t);
  saveAccountTransactions(updatedAll);

  try {
    await updateDoc(doc(db, 'account_transactions', voucher.id), {
      status: 'voided',
      voidReason: reason.trim(),
      voidedAt: nowIso,
      reversalVoucherNo: reversalTxn.voucherNo
    });
  } catch {}

  return { updatedOriginal, reversalTxn };
}

// ============================================================================
// ATOMIC DIRECT SALES INVOICE POSTING WITH ADVANCE ADJUSTMENT & STOCK CHECK
// ============================================================================

export interface PostSalesInvoiceAtomicParams {
  invoice: SalesInvoice;
  adjustedAdvanceAmount: number;
  cashPaidAmount: number;
  depositAccountId?: string;
  warehouseId?: string;
  allowNegativeStock?: boolean;
  isAdmin?: boolean;
  negativeStockReason?: string;
  branch: string;
  user: {
    uid: string;
    name: string;
    email?: string;
  };
  idempotencyKey?: string;
}

export interface PostSalesInvoiceAtomicResult {
  invoice: SalesInvoice;
  salesTxn: AccountTransaction;
  advanceAdjustmentTxn?: AccountTransaction;
  depositTxn?: AccountTransaction;
  sourceAdvanceVoucherIds: string[];
  updatedCustomerAdvance: number;
  updatedCustomerReceivable: number;
}

const activeSalesInvoiceLocks = new Set<string>();

/**
 * Executes Sales Invoice posting, Customer Advance Adjustment (Dr 2050 / Cr 1050),
 * Upfront Cash/Bank Collection, Customer Advance/Receivable Balance update,
 * and Warehouse Stock Validation & Deduction in ONE atomic Firestore transaction.
 */
export async function postSalesInvoiceAtomic(
  params: PostSalesInvoiceAtomicParams
): Promise<PostSalesInvoiceAtomicResult> {
  const {
    invoice,
    adjustedAdvanceAmount = 0,
    cashPaidAmount = 0,
    depositAccountId,
    warehouseId,
    allowNegativeStock = false,
    isAdmin = false,
    negativeStockReason,
    branch,
    user,
  } = params;

  const lockKey = params.idempotencyKey || `sales_inv_${invoice.id}`;
  if (activeSalesInvoiceLocks.has(lockKey)) {
    throw new Error('This sales invoice is currently being submitted. Please wait.');
  }
  activeSalesInvoiceLocks.add(lockKey);

  try {
    if (!invoice.totalAmount || invoice.totalAmount <= 0) {
      throw new Error('Invoice total amount must be greater than zero.');
    }
    if (adjustedAdvanceAmount < 0) {
      throw new Error('Adjusted advance amount cannot be negative.');
    }
    if (adjustedAdvanceAmount > invoice.totalAmount + 0.001) {
      throw new Error(
        `Adjusted advance amount (BDT ${adjustedAdvanceAmount.toLocaleString()}) cannot exceed the invoice total (BDT ${invoice.totalAmount.toLocaleString()}).`
      );
    }
    if (cashPaidAmount > 0 && !depositAccountId) {
      throw new Error('Deposit account is required when receiving cash or bank payment.');
    }

    // Closed Fiscal Year Check
    const allFiscalYears = getFiscalYears();
    const closedFY = allFiscalYears.find(
      f => f.status === 'Closed' && f.startDate <= invoice.invoiceDate && invoice.invoiceDate <= f.endDate
    );
    if (closedFY) {
      throw new Error(
        `Posting into closed fiscal year (${closedFY.name}) on ${invoice.invoiceDate} is strictly prohibited.`
      );
    }

    const effectiveWhId = resolveWarehouseId(warehouseId || invoice.warehouseId || invoice.branch || branch);
    const localItemsSnapshot = getItems();
    const sysSettings = getSystemInventorySettings();
    const effectiveAllowNeg = Boolean(allowNegativeStock || sysSettings.allowNegativeStock);

    // Pre-check stock availability before opening Firestore transaction
    const preStockCheck = validateStockAvailabilityForLines(
      invoice.items || [],
      effectiveWhId,
      {
        allowNegativeStock: effectiveAllowNeg,
        isAdmin,
        negativeStockReason,
        itemsSnapshot: localItemsSnapshot,
      }
    );
    if (!preStockCheck.valid) {
      throw new Error(preStockCheck.summaryError || 'Insufficient stock for one or more invoice items.');
    }

    // Identify source advance deposit voucher IDs for this customer
    const allTxns = getAccountTransactions();
    const customerDepositVouchers = allTxns
      .filter(
        tx =>
          tx.status === 'active' &&
          tx.partyId === invoice.customerId &&
          tx.transactionType === 'DEPOSIT'
      )
      .sort((a, b) => a.date.localeCompare(b.date));
    const sourceAdvanceVoucherIds =
      adjustedAdvanceAmount > 0
        ? customerDepositVouchers.map(tx => tx.voucherNo || tx.id)
        : [];

    let salesTxn!: AccountTransaction;
    let advanceAdjustmentTxn: AccountTransaction | undefined;
    let depositTxn: AccountTransaction | undefined;
    const allNewLedgerLines: AccountLedgerEntry[] = [];
    let updatedCustomerObj: any = null;
    let updatedBankObj: any = null;
    let updatedInventoryItems: InventoryItem[] = localItemsSnapshot;
    let idempotentHit = false;
    let committedToFirestore = false;

    const custRef = doc(db, 'customers', invoice.customerId);
    const svCounterRef = doc(db, 'account_counters', 'voucher_sv');
    const jvCounterRef = doc(db, 'account_counters', 'voucher_jv');
    const dvCounterRef = doc(db, 'account_counters', 'voucher_dv');
    const idempRef = doc(db, 'idempotency_keys', lockKey);
    const bankRef = cashPaidAmount > 0 && depositAccountId ? doc(db, 'bank_accounts', depositAccountId) : null;

    await runTransaction(db, async t => {
      // --- PHASE 1: READS ---
      const idempSnap = await t.get(idempRef);
      if (idempSnap.exists()) {
        const existingSalesTxnId = idempSnap.data()?.salesTxnId;
        const existingLocal = allTxns.find(x => x.id === existingSalesTxnId);
        if (existingLocal) {
          salesTxn = existingLocal;
          idempotentHit = true;
          return;
        }
      }

      const custSnap = await t.get(custRef);
      const localCust = getCustomers().find(c => c.id === invoice.customerId);
      const custData: any = custSnap.exists() ? custSnap.data() : localCust;
      if (!custData) {
        throw new Error(`Customer "${invoice.customerName}" not found.`);
      }

      const svCounterSnap = await t.get(svCounterRef);
      const jvCounterSnap = adjustedAdvanceAmount > 0 ? await t.get(jvCounterRef) : null;
      const dvCounterSnap = cashPaidAmount > 0 ? await t.get(dvCounterRef) : null;

      let bankSnap: any = null;
      let bankData: any = null;
      if (bankRef && depositAccountId) {
        bankSnap = await t.get(bankRef);
        const localBank = getBankAccounts().find(b => b.id === depositAccountId);
        bankData = bankSnap.exists() ? bankSnap.data() : localBank;
        if (!bankData) {
          throw new Error('Selected deposit bank/cash account not found.');
        }
      }

      // Read inventory item docs in Firestore for server-side concurrent stock check
      const stockItemDocsMap: Record<string, { ref: any; exists: boolean; data: InventoryItem }> = {};
      for (const line of invoice.items || []) {
        const localItem = localItemsSnapshot.find(
          i => i.id === line.itemId || (line.itemName && i.name.toLowerCase() === line.itemName.toLowerCase())
        );
        if (localItem && isStockItem(localItem, line.itemId, line.itemName, line.uom)) {
          if (!stockItemDocsMap[localItem.id]) {
            const itemDocRef = doc(db, 'inventory_items', localItem.id);
            const itemSnap = await t.get(itemDocRef);
            // Use the stricter (lower) stock between local catalog and Firestore doc so stock is always authoritative
            let mergedItem = { ...localItem };
            if (itemSnap.exists()) {
              const remoteItem = itemSnap.data() as InventoryItem;
              if (typeof remoteItem.totalStock === 'number') {
                mergedItem = {
                  ...localItem,
                  ...remoteItem,
                  stockByWarehouse: {
                    ...(localItem.stockByWarehouse || {}),
                    ...(remoteItem.stockByWarehouse || {}),
                  },
                };
              }
            }
            stockItemDocsMap[localItem.id] = {
              ref: itemDocRef,
              exists: itemSnap.exists(),
              data: mergedItem,
            };
          }
        }
      }

      // --- PHASE 2: VALIDATIONS INSIDE TRANSACTION ---
      // 2.1 Validate Customer Advance Balance inside Transaction (Requirement A.3)
      const currentAvailableAdvance = getCustomerAvailableAdvance(custData);
      if (adjustedAdvanceAmount > currentAvailableAdvance + 0.001) {
        throw new Error(
          `Advance adjustment (BDT ${adjustedAdvanceAmount.toLocaleString()}) exceeds ${custData.name || invoice.customerName}'s currently available advance balance (BDT ${currentAvailableAdvance.toLocaleString()}).`
        );
      }
      if (adjustedAdvanceAmount > invoice.totalAmount + 0.001) {
        throw new Error(
          `Advance adjustment (BDT ${adjustedAdvanceAmount.toLocaleString()}) cannot exceed the invoice total (BDT ${invoice.totalAmount.toLocaleString()}).`
        );
      }

      // 2.2 Validate Warehouse Stock Availability inside Transaction (Requirement B.2.c)
      const txItemsSnapshot = localItemsSnapshot.map(it =>
        stockItemDocsMap[it.id] ? stockItemDocsMap[it.id].data : it
      );
      const txStockCheck = validateStockAvailabilityForLines(
        invoice.items || [],
        effectiveWhId,
        {
          allowNegativeStock: effectiveAllowNeg,
          isAdmin,
          negativeStockReason,
          itemsSnapshot: txItemsSnapshot,
        }
      );
      if (!txStockCheck.valid) {
        throw new Error(txStockCheck.summaryError || 'Insufficient warehouse stock for one or more items.');
      }

      // 2.3 Calculate Updated Customer Balances
      const receivableBefore = Math.max(0, Number(custData.currentBalance) || 0);
      const afterInvoiceReceivable = Number((receivableBefore + invoice.totalAmount).toFixed(2));
      const afterAdvanceReceivable = Number((afterInvoiceReceivable - adjustedAdvanceAmount).toFixed(2));
      const finalReceivable = Math.max(0, Number((afterAdvanceReceivable - cashPaidAmount).toFixed(2)));

      // If cashPaidAmount + adjustedAdvanceAmount exceeded invoice.totalAmount, any excess increases advance
      const totalSettledOnInvoice = Number((adjustedAdvanceAmount + cashPaidAmount).toFixed(2));
      const excessOverInvoice = Math.max(0, Number((totalSettledOnInvoice - invoice.totalAmount).toFixed(2)));
      const finalAdvanceBalance = Math.max(
        0,
        Number((currentAvailableAdvance - adjustedAdvanceAmount + excessOverInvoice).toFixed(2))
      );

      const nowIso = new Date().toISOString();

      // Helper for monotonic voucher numbering
      const getNextNumber = (snap: any, prefix: string) => {
        const remoteCur = snap && snap.exists() ? Number(snap.data()?.current) || 0 : 0;
        let maxLocal = 0;
        allTxns.forEach(tx => {
          if (tx.voucherNo?.startsWith(`${prefix}-`)) {
            const n = parseInt(tx.voucherNo.replace(`${prefix}-`, ''), 10);
            if (!isNaN(n) && n > maxLocal) maxLocal = n;
          }
        });
        let candidate = Math.max(remoteCur, maxLocal) + 1;
        while (allTxns.some(tx => tx.voucherNo === `${prefix}-${String(candidate).padStart(4, '0')}`)) {
          candidate++;
        }
        return candidate;
      };

      // --- Voucher 1: Sales Invoice Journal (SV-XXXX: Dr Accounts Receivable 1050 / Cr Sales Revenue 4010) ---
      const svNum = getNextNumber(svCounterSnap, 'SV');
      const svVoucherNo = `SV-${String(svNum).padStart(4, '0')}`;
      const svTxnId = `txn-journal-sv-${invoice.id}`;

      salesTxn = {
        id: svTxnId,
        voucherNo: svVoucherNo,
        transactionType: 'JOURNAL',
        subType: 'Sales Invoice' as any,
        date: invoice.invoiceDate,
        amount: invoice.totalAmount,
        partyType: 'Customer',
        partyId: invoice.customerId,
        partyName: invoice.customerName,
        partyBalanceBefore: receivableBefore,
        partyBalanceAfter: afterInvoiceReceivable,
        accountHeadCode: '4010',
        accountHeadName: 'Wholesale Trading Revenue - Stone & Aggregate',
        bankAccountId: 'N/A',
        bankAccountName: 'Journal Entry',
        paymentMethod: 'Cash',
        referenceNo: invoice.invoiceNumber,
        note: `Sales Invoice ${invoice.invoiceNumber} (${(invoice.items || []).length} items)`,
        branch,
        status: 'active',
        idempotencyKey: `${lockKey}_sv`,
        createdBy: user,
        createdAt: nowIso,
      };

      allNewLedgerLines.push(
        {
          id: `led-${svTxnId}-dr-cust`,
          transactionId: svTxnId,
          voucherNo: svVoucherNo,
          date: invoice.invoiceDate,
          accountType: 'Customer',
          accountId: invoice.customerId,
          accountName: `${invoice.customerName} (Accounts Receivable 1050)`,
          description: `Sales Invoice ${invoice.invoiceNumber}`,
          debit: invoice.totalAmount,
          credit: 0,
          runningBalance: afterInvoiceReceivable,
          branch,
          status: 'active',
          createdAt: nowIso,
        },
        {
          id: `led-${svTxnId}-cr-sales`,
          transactionId: svTxnId,
          voucherNo: svVoucherNo,
          date: invoice.invoiceDate,
          accountType: 'AccountHead',
          accountId: '4010',
          accountName: 'Wholesale Trading Revenue - Stone & Aggregate (4010)',
          description: `Sales Revenue on Invoice ${invoice.invoiceNumber} — ${invoice.customerName}`,
          debit: 0,
          credit: invoice.totalAmount,
          runningBalance: 0,
          branch,
          status: 'active',
          createdAt: nowIso,
        }
      );

      // --- Voucher 2 (if adjustedAdvanceAmount > 0): Customer Advance Adjustment Journal (JV-XXXX: Dr Customer Advance 2050 / Cr Accounts Receivable 1050) ---
      let jvNum = 0;
      if (adjustedAdvanceAmount > 0) {
        jvNum = getNextNumber(jvCounterSnap, 'JV');
        const jvVoucherNo = `JV-${String(jvNum).padStart(4, '0')}`;
        const jvTxnId = `txn-journal-adv-${invoice.id}`;

        advanceAdjustmentTxn = {
          id: jvTxnId,
          voucherNo: jvVoucherNo,
          transactionType: 'JOURNAL',
          subType: 'Customer Advance Adjustment' as any,
          date: invoice.invoiceDate,
          amount: adjustedAdvanceAmount,
          partyType: 'Customer',
          partyId: invoice.customerId,
          partyName: invoice.customerName,
          partyBalanceBefore: afterInvoiceReceivable,
          partyBalanceAfter: afterAdvanceReceivable,
          accountHeadCode: '2050',
          accountHeadName: 'Customer Advance Deposits',
          bankAccountId: 'N/A',
          bankAccountName: 'Advance Adjustment (Dr 2050 / Cr 1050)',
          paymentMethod: 'Cash',
          referenceNo: invoice.invoiceNumber,
          note: `Customer Advance adjusted against Sales Invoice ${invoice.invoiceNumber} (Dr Customer Advance 2050 / Cr Accounts Receivable 1050)${sourceAdvanceVoucherIds.length > 0 ? ` [Source: ${sourceAdvanceVoucherIds.join(', ')}]` : ''}`,
          branch,
          status: 'active',
          idempotencyKey: `${lockKey}_adv`,
          createdBy: user,
          createdAt: nowIso,
        };

        allNewLedgerLines.push(
          {
            id: `led-${jvTxnId}-dr-adv`,
            transactionId: jvTxnId,
            voucherNo: jvVoucherNo,
            date: invoice.invoiceDate,
            accountType: 'AccountHead',
            accountId: '2050',
            accountName: 'Customer Advance Deposits (2050)',
            description: `Advance Deposit adjusted against Sales Invoice ${invoice.invoiceNumber} — ${invoice.customerName}`,
            debit: adjustedAdvanceAmount,
            credit: 0,
            runningBalance: finalAdvanceBalance,
            branch,
            status: 'active',
            createdAt: nowIso,
          },
          {
            id: `led-${jvTxnId}-cr-cust`,
            transactionId: jvTxnId,
            voucherNo: jvVoucherNo,
            date: invoice.invoiceDate,
            accountType: 'Customer',
            accountId: invoice.customerId,
            accountName: `${invoice.customerName} (Accounts Receivable 1050)`,
            description: `Accounts Receivable (1050) settled by Customer Advance (2050) against ${invoice.invoiceNumber}`,
            debit: 0,
            credit: adjustedAdvanceAmount,
            runningBalance: afterAdvanceReceivable,
            branch,
            status: 'active',
            createdAt: nowIso,
          }
        );
      }

      // --- Voucher 3 (if cashPaidAmount > 0): Customer Collection Deposit (DV-XXXX: Dr Bank/Cash / Cr Accounts Receivable 1050) ---
      let dvNum = 0;
      let projectedBankBal = 0;
      if (cashPaidAmount > 0 && bankData && depositAccountId) {
        dvNum = getNextNumber(dvCounterSnap, 'DV');
        const dvVoucherNo = `DV-${String(dvNum).padStart(4, '0')}`;
        const dvTxnId = `txn-deposit-inv-${invoice.id}`;
        const bankLabel = `${bankData.bankName} (${bankData.accountNumber})`;
        projectedBankBal = Number(((Number(bankData.ledgerBalance) || 0) + cashPaidAmount).toFixed(2));

        depositTxn = {
          id: dvTxnId,
          voucherNo: dvVoucherNo,
          transactionType: 'DEPOSIT',
          subType: 'Customer Collection' as any,
          date: invoice.invoiceDate,
          amount: cashPaidAmount,
          partyType: 'Customer',
          partyId: invoice.customerId,
          partyName: invoice.customerName,
          partyBalanceBefore: afterAdvanceReceivable,
          partyBalanceAfter: finalReceivable,
          bankAccountId: depositAccountId,
          bankAccountName: bankLabel,
          bankAccountNumber: bankData.accountNumber,
          paymentMethod: (invoice.paymentMethod as any) || 'Cash',
          referenceNo: invoice.paymentRef || invoice.invoiceNumber,
          note: `Payment collection against Sales Invoice ${invoice.invoiceNumber}`,
          branch,
          status: 'active',
          idempotencyKey: `${lockKey}_dv`,
          createdBy: user,
          createdAt: nowIso,
        };

        allNewLedgerLines.push(
          {
            id: `led-${dvTxnId}-dr-bank`,
            transactionId: dvTxnId,
            voucherNo: dvVoucherNo,
            date: invoice.invoiceDate,
            accountType: 'Bank/Cash',
            accountId: depositAccountId,
            accountName: bankLabel,
            description: `Collection from Customer: ${invoice.customerName} (Ref: ${invoice.invoiceNumber})`,
            debit: cashPaidAmount,
            credit: 0,
            runningBalance: projectedBankBal,
            branch,
            status: 'active',
            createdAt: nowIso,
          },
          {
            id: `led-${dvTxnId}-cr-cust`,
            transactionId: dvTxnId,
            voucherNo: dvVoucherNo,
            date: invoice.invoiceDate,
            accountType: 'Customer',
            accountId: invoice.customerId,
            accountName: `${invoice.customerName} (Accounts Receivable 1050)`,
            description: `Payment received into ${bankLabel} (Ref: ${invoice.invoiceNumber})`,
            debit: 0,
            credit: cashPaidAmount,
            runningBalance: finalReceivable,
            branch,
            status: 'active',
            createdAt: nowIso,
          }
        );

        updatedBankObj = {
          ...bankData,
          id: depositAccountId,
          ledgerBalance: projectedBankBal,
          statementBalance: Number(((Number(bankData.statementBalance) || 0) + cashPaidAmount).toFixed(2)),
          updatedAt: nowIso,
        };
      }

      // --- Deduct Stock in Transaction ---
      const updatedStockDocsMap: Record<string, InventoryItem> = {};
      for (const [id, entry] of Object.entries(stockItemDocsMap)) {
        updatedStockDocsMap[id] = {
          ...entry.data,
          stockByWarehouse: { ...(entry.data.stockByWarehouse || {}) },
        };
      }

      for (const line of invoice.items || []) {
        const qty = Number(line.quantity) || 0;
        if (qty <= 0) continue;
        const targetEntry = Object.values(updatedStockDocsMap).find(
          i => i.id === line.itemId || (line.itemName && i.name.toLowerCase() === line.itemName.toLowerCase())
        );
        if (!targetEntry) continue;
        const conv = convertQuantityBetweenUoms(qty, line.uom || targetEntry.uom, targetEntry.uom);
        const qtyBase = conv.convertedQty;
        const rawTotal = Number(((targetEntry.totalStock || 0) - qtyBase).toFixed(2));
        targetEntry.totalStock = effectiveAllowNeg ? rawTotal : Math.max(0, rawTotal);
        if (effectiveWhId) {
          const whMap = { ...(targetEntry.stockByWarehouse || {}) };
          const rawWh = Number(((whMap[effectiveWhId] || 0) - qtyBase).toFixed(2));
          whMap[effectiveWhId] = effectiveAllowNeg ? rawWh : Math.max(0, rawWh);
          targetEntry.stockByWarehouse = whMap;
        }
      }

      updatedInventoryItems = txItemsSnapshot.map(it =>
        updatedStockDocsMap[it.id] ? updatedStockDocsMap[it.id] : it
      );

      updatedCustomerObj = {
        ...custData,
        id: invoice.customerId,
        currentBalance: finalReceivable,
        advanceBalance: finalAdvanceBalance,
        updatedAt: nowIso,
      };

      // --- PHASE 3: WRITES INSIDE ONE TRANSACTION ---
      t.set(svCounterRef, { current: svNum, prefix: 'SV', updatedAt: nowIso }, { merge: true });
      t.set(doc(db, 'account_transactions', salesTxn.id), cleanFirestoreData(salesTxn));

      if (advanceAdjustmentTxn && jvNum > 0) {
        t.set(jvCounterRef, { current: jvNum, prefix: 'JV', updatedAt: nowIso }, { merge: true });
        t.set(doc(db, 'account_transactions', advanceAdjustmentTxn.id), cleanFirestoreData(advanceAdjustmentTxn));
      }

      if (depositTxn && dvNum > 0 && bankRef && updatedBankObj) {
        t.set(dvCounterRef, { current: dvNum, prefix: 'DV', updatedAt: nowIso }, { merge: true });
        t.set(doc(db, 'account_transactions', depositTxn.id), cleanFirestoreData(depositTxn));
        t.set(bankRef, cleanFirestoreData(updatedBankObj), { merge: true });
      }

      for (const led of allNewLedgerLines) {
        t.set(doc(db, 'account_ledgers', led.id), cleanFirestoreData(led));
      }

      // Write updated Customer balance & reduced advanceBalance
      t.set(custRef, cleanFirestoreData(updatedCustomerObj), { merge: true });

      // Write updated Inventory Item stock docs
      for (const [id, entry] of Object.entries(stockItemDocsMap)) {
        const updatedItem = updatedStockDocsMap[id];
        if (updatedItem) {
          t.set(entry.ref, cleanFirestoreData(updatedItem), { merge: true });
        }
      }

      // Write Idempotency Key
      t.set(idempRef, {
        invoiceId: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        salesTxnId: salesTxn.id,
        advanceAdjustmentTxnId: advanceAdjustmentTxn?.id || null,
        depositTxnId: depositTxn?.id || null,
        adjustedAdvanceAmount,
        createdAt: nowIso,
      });

      // Populate allocation fields on invoice and save to sales_invoices
      const totalPaidOnInv = Number((cashPaidAmount + adjustedAdvanceAmount).toFixed(2));
      const dueOnInv = Math.max(0, Number((invoice.totalAmount - totalPaidOnInv).toFixed(2)));
      invoice.paidAmount = totalPaidOnInv;
      invoice.cashPaidAmount = cashPaidAmount;
      invoice.advanceAdjusted = adjustedAdvanceAmount;
      invoice.adjustedAdvanceAmount = adjustedAdvanceAmount;
      invoice.sourceAdvanceVoucherIds = sourceAdvanceVoucherIds;
      invoice.adjustmentVoucherId = advanceAdjustmentTxn?.id;
      invoice.adjustmentVoucherNo = advanceAdjustmentTxn?.voucherNo;
      invoice.salesTransactionId = salesTxn.id;
      invoice.salesVoucherNo = salesTxn.voucherNo;
      invoice.depositTransactionId = depositTxn?.id;
      invoice.depositVoucherNo = depositTxn?.voucherNo;
      if (depositTxn?.voucherNo) {
        invoice.moneyReceiptNumber = depositTxn.voucherNo;
      }
      invoice.dueAmount = dueOnInv;
      invoice.status =
        dueOnInv === 0
          ? 'Paid'
          : totalPaidOnInv > 0
          ? 'Partially Paid'
          : 'Unpaid';
      invoice.stockDeducted = true;
      invoice.warehouseId = effectiveWhId;

      t.set(doc(db, 'sales_invoices', invoice.id), cleanFirestoreData(invoice), { merge: true });
    });

    committedToFirestore = true;

    if (!idempotentHit) {
      // Update local caches so UI updates synchronously
      const newTxns = [
        ...(depositTxn ? [depositTxn] : []),
        ...(advanceAdjustmentTxn ? [advanceAdjustmentTxn] : []),
        salesTxn,
      ];
      const existingTxns = getAccountTransactions();
      const mergedTxns = [
        ...newTxns.filter(nt => !existingTxns.some(et => et.id === nt.id)),
        ...existingTxns,
      ];
      saveAccountTransactions(mergedTxns);

      const existingLedgers = getAccountLedgers();
      const mergedLedgers = [
        ...allNewLedgerLines.filter(nl => !existingLedgers.some(el => el.id === nl.id)),
        ...existingLedgers,
      ];
      cachedLedgers = mergedLedgers;
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(LEDGER_STORAGE_KEY, JSON.stringify(mergedLedgers));
        window.dispatchEvent(
          new CustomEvent('tradecore_account_ledgers_changed', { detail: { ledgers: mergedLedgers } })
        );
      }

      if (updatedCustomerObj) {
        updateCustomer(updatedCustomerObj);
      }
      if (updatedBankObj) {
        updateBankAccount(updatedBankObj);
      }
      if (committedToFirestore) {
        saveItems(updatedInventoryItems);
      } else {
        deductStockForInvoiceLines(invoice.items || [], effectiveWhId, effectiveAllowNeg);
      }
    }

    return {
      invoice,
      salesTxn,
      advanceAdjustmentTxn,
      depositTxn,
      sourceAdvanceVoucherIds,
      updatedCustomerAdvance: updatedCustomerObj?.advanceBalance ?? 0,
      updatedCustomerReceivable: updatedCustomerObj?.currentBalance ?? 0,
    };
  } finally {
    activeSalesInvoiceLocks.delete(lockKey);
  }
}

/**
 * Reverses all accounting vouchers (Sales Invoice, Customer Advance Adjustment, Cash Deposit)
 * and restores customer advance balance & inventory stock when a Sales Invoice is voided or deleted.
 */
export async function reverseSalesInvoiceAccounting(
  invoice: SalesInvoice,
  reason: string,
  user: { uid: string; name: string; email?: string }
): Promise<void> {
  const voidReason = reason?.trim() || `Sales Invoice ${invoice.invoiceNumber} voided/deleted`;
  const allTxns = getAccountTransactions();

  // 1. Reverse Customer Advance Adjustment voucher (if any)
  const adjAmt = Number(invoice.adjustedAdvanceAmount ?? invoice.advanceAdjusted ?? 0);
  const adjTxn = allTxns.find(
    t =>
      t.status === 'active' &&
      ((invoice.adjustmentVoucherId && t.id === invoice.adjustmentVoucherId) ||
        (invoice.adjustmentVoucherNo && t.voucherNo === invoice.adjustmentVoucherNo) ||
        (t.referenceNo === invoice.invoiceNumber && (t.subType as string) === 'Customer Advance Adjustment'))
  );

  if (adjTxn) {
    await voidAccountTransaction(adjTxn.id, voidReason, user);
  } else if (adjAmt > 0 && invoice.customerId) {
    // Fallback if invoice had legacy advance adjustment without a posted voucher
    updateCustomerBalance(invoice.customerId, adjAmt, adjAmt);
  }

  // 2. Reverse Cash/Bank Deposit voucher (if any)
  const depTxn = allTxns.find(
    t =>
      t.status === 'active' &&
      ((invoice.depositTransactionId && t.id === invoice.depositTransactionId) ||
        (invoice.depositVoucherNo && t.voucherNo === invoice.depositVoucherNo))
  );
  if (depTxn) {
    await voidAccountTransaction(depTxn.id, voidReason, user);
  }

  // 3. Reverse Sales Invoice Journal voucher
  const salesTxn = allTxns.find(
    t =>
      t.status === 'active' &&
      ((invoice.salesTransactionId && t.id === invoice.salesTransactionId) ||
        (invoice.salesVoucherNo && t.voucherNo === invoice.salesVoucherNo) ||
        (t.referenceNo === invoice.invoiceNumber && (t.subType as string) === 'Sales Invoice'))
  );
  if (salesTxn) {
    await voidAccountTransaction(salesTxn.id, voidReason, user);
  } else if (invoice.customerId) {
    // Fallback if invoice was saved before JOURNAL rules fix
    const cashPaid = Number(invoice.cashPaidAmount ?? Math.max(0, (invoice.paidAmount || 0) - adjAmt));
    const unpaidAndAdjusted = invoice.totalAmount - (depTxn ? cashPaid : 0);
    updateCustomerBalance(invoice.customerId, -unpaidAndAdjusted, 0);
  }

  // 4. Restore physical inventory stock
  if (invoice.items && invoice.items.length > 0) {
    const whId = resolveWarehouseId(invoice.warehouseId || invoice.branch);
    const restoredItems = restoreStockForInvoiceLines(invoice.items, whId);
    // Sync restored items to Firestore inventory_items
    for (const line of invoice.items) {
      const catItem = restoredItems.find(
        i => i.id === line.itemId || (line.itemName && i.name.toLowerCase() === line.itemName.toLowerCase())
      );
      if (catItem) {
        try {
          await setDoc(doc(db, 'inventory_items', catItem.id), cleanFirestoreData(catItem), { merge: true });
        } catch {}
      }
    }
  }
}

/**
 * Durably saves an LC expense record to both localStorage ('tradecore_lcs_v1') and Firestore ('letters_of_credit/{lcId}'),
 * deduplicating by id, transactionId, and voucherNo so the same expense record is never created twice.
 */
export async function persistLcExpenseDurable(
  lcId: string,
  newExp: {
    id?: string;
    expenseType: string;
    amountLocal: number;
    paidTo: string;
    status: 'Paid' | 'Billed' | 'Invoiced' | 'Estimated' | 'Voided';
    voucherNo?: string;
    lcId?: string;
    paymentDate?: string;
    paidFromAccountId?: string;
    paidFromAccountName?: string;
    paymentMethod?: string;
    referenceNo?: string;
    transactionId?: string;
    postedBy?: { uid: string; name: string; email?: string } | string;
    postedAt?: string;
  },
  currentLcs: LetterOfCredit[]
): Promise<LetterOfCredit[]> {
  let updatedTargetLc: LetterOfCredit | null = null;
  const nextLcs = currentLcs.map(item => {
    if (item.id !== lcId) return item;
    const currentExpenses = Array.isArray(item.expenses) ? item.expenses : [];
    const matchPred = (e: any) =>
      (newExp.id && e.id === newExp.id) ||
      (newExp.transactionId && e.transactionId && e.transactionId === newExp.transactionId) ||
      (newExp.voucherNo && e.voucherNo && e.voucherNo === newExp.voucherNo);

    const resolvedId = newExp.id || (newExp.transactionId ? `exp-${newExp.transactionId}` : `exp-${Date.now()}`);
    const expenseRecord = {
      ...newExp,
      id: resolvedId,
      lcId
    };

    const updatedExpenses = currentExpenses.some(matchPred)
      ? currentExpenses.map(e => (matchPred(e) ? { ...e, ...expenseRecord } : e))
      : [expenseRecord, ...currentExpenses];

    updatedTargetLc = { ...item, expenses: updatedExpenses };
    return updatedTargetLc;
  });

  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs));
      window.dispatchEvent(new CustomEvent('tradecore_lcs_changed', { detail: { lcs: nextLcs } }));
    }
  } catch (e) {
    console.warn('Failed to persist LC expenses to localStorage:', e);
  }

  if (updatedTargetLc) {
    try {
      await setDoc(
        doc(db, 'letters_of_credit', lcId),
        cleanFirestoreData({
          ...(updatedTargetLc as LetterOfCredit),
          updatedAt: new Date().toISOString()
        }),
        { merge: true }
      );
    } catch (err) {
      console.warn('Firestore letters_of_credit expense sync notice:', err);
    }
  }

  return nextLcs;
}

/**
 * Self-heals missing LC expense records from posted vouchers in `account_transactions`.
 * Matches vouchers by lcId, lcNumber, or LC number referenced in referenceNo / note,
 * and deduplicates strictly by transactionId and voucherNo so the same voucher is never added twice.
 */
export function reconcileAndHealLcExpenses(
  lcs: LetterOfCredit[],
  transactions: AccountTransaction[] = getAccountTransactions()
): { lcs: LetterOfCredit[]; changed: boolean; healedRecords: Array<{ voucherNo: string; lcId: string; lcNumber: string; expenseType: string; amount: number }> } {
  if (!Array.isArray(lcs) || lcs.length === 0) {
    return { lcs: lcs || [], changed: false, healedRecords: [] };
  }

  const healedRecords: Array<{ voucherNo: string; lcId: string; lcNumber: string; expenseType: string; amount: number }> = [];
  let anyChanged = false;

  // Map LCs by id and by normalized LC number (preferring non-voided LCs)
  const lcById = new Map<string, LetterOfCredit>();
  const lcByNum = new Map<string, LetterOfCredit>();
  for (const lc of lcs) {
    lcById.set(lc.id, lc);
    const norm = (lc.normalizedLcNumber || lc.lcNumber || '').trim().toUpperCase();
    if (norm && (!lcByNum.has(norm) || (!lc.isVoided && lc.status !== 'Voided'))) {
      lcByNum.set(norm, lc);
    }
  }

  // First deduplicate any existing expenses on each LC by voucherNo / transactionId / id
  const workingLcs: LetterOfCredit[] = lcs.map(lc => {
    const rawExps = Array.isArray(lc.expenses) ? lc.expenses : [];
    const seenVoucherNos = new Set<string>();
    const seenTxnIds = new Set<string>();
    const seenIds = new Set<string>();
    const deduped: any[] = [];
    for (const exp of rawExps) {
      if (!exp) continue;
      if (exp.voucherNo && seenVoucherNos.has(exp.voucherNo)) {
        anyChanged = true;
        continue;
      }
      if (exp.transactionId && seenTxnIds.has(exp.transactionId)) {
        anyChanged = true;
        continue;
      }
      if (exp.id && seenIds.has(exp.id)) {
        anyChanged = true;
        continue;
      }
      if (exp.voucherNo) seenVoucherNos.add(exp.voucherNo);
      if (exp.transactionId) seenTxnIds.add(exp.transactionId);
      if (exp.id) seenIds.add(exp.id);
      deduped.push(exp);
    }
    return deduped.length !== rawExps.length ? { ...lc, expenses: deduped } : { ...lc, expenses: [...rawExps] };
  });

  const workingById = new Map<string, LetterOfCredit>();
  workingLcs.forEach(l => workingById.set(l.id, l));

  // Identify LC expense vouchers in account_transactions
  for (const tx of transactions) {
    if (!tx || !tx.voucherNo) continue;

    // Skip LC Margin Deposits / Reversals
    const sub = String(tx.subType || '');
    if (
      sub === 'LC Margin Deposit' ||
      sub === 'LC Margin Deposit (Corrected)' ||
      sub === 'LC Margin Reversal' ||
      tx.accountHeadCode === 'OTH-LC-MRG' ||
      tx.accountHeadId === 'head-lc-mrg'
    ) {
      continue;
    }

    const isExplicitLcExpense =
      Boolean(tx.lcId) ||
      Boolean(tx.lcExpenseRecord) ||
      sub === 'LC Logistics Payment' ||
      sub === 'Vendor Bill / LC Logistics Expense' ||
      tx.costCenter === 'LC Import Logistics' ||
      (tx.referenceNo && tx.referenceNo.toUpperCase().includes('LC') && tx.accountHeadCode === '13100');

    if (!isExplicitLcExpense) continue;

    // Resolve target LC
    let targetLc: LetterOfCredit | undefined;
    if (tx.lcId && workingById.has(tx.lcId)) {
      targetLc = workingById.get(tx.lcId);
    }
    if (!targetLc && tx.lcNumber) {
      const match = lcByNum.get(tx.lcNumber.trim().toUpperCase());
      if (match) targetLc = workingById.get(match.id);
    }
    if (!targetLc) {
      const searchText = `${tx.referenceNo || ''} ${tx.note || ''}`.toUpperCase();
      for (const [normNum, candidate] of lcByNum.entries()) {
        if (normNum && searchText.includes(normNum)) {
          targetLc = workingById.get(candidate.id);
          break;
        }
      }
    }

    if (!targetLc) continue;

    // Skip if this voucher is actually the LC's opening margin voucher
    if (targetLc.marginVoucherNo === tx.voucherNo || targetLc.marginVoucherId === tx.id) {
      continue;
    }

    const existingExps = targetLc.expenses || [];
    const alreadyExists = existingExps.some(
      (e: any) =>
        (e.voucherNo && e.voucherNo === tx.voucherNo) ||
        (e.transactionId && e.transactionId === tx.id) ||
        (tx.lcExpenseId && e.id === tx.lcExpenseId)
    );

    if (alreadyExists) {
      // Sync voided status if voucher was voided
      if (tx.status === 'voided') {
        const idx = existingExps.findIndex(
          (e: any) => (e.voucherNo && e.voucherNo === tx.voucherNo) || (e.transactionId && e.transactionId === tx.id)
        );
        if (idx >= 0 && existingExps[idx].status !== 'Voided') {
          existingExps[idx] = { ...existingExps[idx], status: 'Voided' };
          anyChanged = true;
        }
      }
      continue;
    }

    // Parse expense head name from transaction
    let expenseHeadName =
      tx.lcExpenseRecord?.expenseType ||
      tx.lcExpenseHead ||
      (tx.accountHeadName && tx.accountHeadName !== 'Raw Material Inventory (Landed Stock)' ? tx.accountHeadName : '');

    if (!expenseHeadName && tx.note) {
      // Note format is typically "LC <lcNumber> - <ExpenseHead>"
      const parts = tx.note.split(' - ');
      if (parts.length >= 2) {
        expenseHeadName = parts.slice(1).join(' - ').trim();
      } else {
        expenseHeadName = tx.note.trim();
      }
    }
    if (!expenseHeadName) {
      expenseHeadName = 'All Kind Of Lc Expense';
    }

    const rebuiltStatus: 'Paid' | 'Billed' | 'Voided' =
      tx.status === 'voided' ? 'Voided' : tx.transactionType === 'JOURNAL' ? 'Billed' : 'Paid';

    const rebuiltExpense = {
      id: tx.lcExpenseId || tx.lcExpenseRecord?.id || `exp-${tx.id}`,
      lcId: targetLc.id,
      expenseType: expenseHeadName,
      amountLocal: Number(tx.amount) || 0,
      paidTo: tx.lcExpenseRecord?.paidTo || tx.partyName || expenseHeadName,
      status: rebuiltStatus,
      voucherNo: tx.voucherNo,
      transactionId: tx.id,
      paymentDate: tx.date,
      paidFromAccountId: tx.bankAccountId,
      paidFromAccountName: tx.bankAccountName,
      paymentMethod: tx.paymentMethod,
      referenceNo: tx.referenceNo,
      postedBy: tx.createdBy,
      postedAt: tx.createdAt
    };

    targetLc.expenses = [rebuiltExpense, ...existingExps];
    anyChanged = true;
    healedRecords.push({
      voucherNo: tx.voucherNo,
      lcId: targetLc.id,
      lcNumber: targetLc.lcNumber,
      expenseType: expenseHeadName,
      amount: Number(tx.amount) || 0
    });
  }

  if (anyChanged) {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem('tradecore_lcs_v1', JSON.stringify(workingLcs));
      }
    } catch {}
    for (const rec of healedRecords) {
      const healedLc = workingById.get(rec.lcId);
      if (healedLc) {
        setDoc(doc(db, 'letters_of_credit', healedLc.id), cleanFirestoreData(healedLc), { merge: true }).catch(() => {});
      }
    }
  }

  return { lcs: workingLcs, changed: anyChanged, healedRecords };
}

/**
 * Subscribes to Firestore `letters_of_credit` collection and merges remote LC expense records
 * with local LCs without losing any expenses.
 */
export function subscribeFirestoreLcs(
  getCurrentLcs: () => LetterOfCredit[],
  onMerged: (mergedLcs: LetterOfCredit[]) => void
): () => void {
  if (typeof window === 'undefined') return () => {};
  try {
    const lcsCol = collection(db, 'letters_of_credit');
    const unsubSnap = onSnapshot(
      lcsCol,
      snapshot => {
        if (snapshot.empty) return;
        const remoteMap = new Map<string, any>();
        snapshot.forEach(docSnap => {
          remoteMap.set(docSnap.id, { id: docSnap.id, ...docSnap.data() });
        });

        const current = getCurrentLcs();
        let changed = false;
        const merged = current.map(localLc => {
          const remoteLc = remoteMap.get(localLc.id);
          if (!remoteLc) return localLc;
          const localExps: any[] = Array.isArray(localLc.expenses) ? localLc.expenses : [];
          const remoteExps: any[] = Array.isArray(remoteLc.expenses) ? remoteLc.expenses : [];
          if (remoteExps.length === 0) return localLc;

          const combinedExps = [...localExps];
          for (const rExp of remoteExps) {
            if (!rExp) continue;
            const exists = combinedExps.some(
              lExp =>
                (rExp.id && lExp.id === rExp.id) ||
                (rExp.voucherNo && lExp.voucherNo === rExp.voucherNo) ||
                (rExp.transactionId && lExp.transactionId === rExp.transactionId)
            );
            if (!exists) {
              combinedExps.push(rExp);
              changed = true;
            }
          }
          return changed ? { ...localLc, expenses: combinedExps } : localLc;
        });

        if (changed) {
          const healed = reconcileAndHealLcExpenses(merged, getAccountTransactions());
          try {
            localStorage.setItem('tradecore_lcs_v1', JSON.stringify(healed.lcs));
          } catch {}
          onMerged(healed.lcs);
        }
      },
      err => {
        console.warn('Firestore letters_of_credit listener notice:', err?.message || err);
      }
    );
    return () => unsubSnap();
  } catch {
    return () => {};
  }
}


