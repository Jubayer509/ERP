import { ErpUser } from '../types/erp';

// Production configuration: No hardcoded demo users or passwords
export const INITIAL_ERP_USERS: ErpUser[] = [];

export const ROLE_LABELS: Record<string, { title: string; badgeColor: string; description: string }> = {
  admin: {
    title: 'Super Admin / Owner',
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
    description: 'Full unrestricted access to all modules'
  },
  manager: {
    title: 'Manager',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
    description: 'Custom role-based module access'
  },
  // Legacy aliases mapped gracefully
  lc_manager: {
    title: 'Manager (Commercial & LC)',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
    description: 'Manager module access'
  },
  accounts: {
    title: 'Manager (Accounts & Finance)',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    description: 'Manager module access'
  },
  procurement: {
    title: 'Manager (Procurement)',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
    description: 'Manager module access'
  },
  sales: {
    title: 'Manager (Sales & POS)',
    badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    description: 'Manager module access'
  },
  inventory: {
    title: 'Manager (Warehouse & Logistics)',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-200',
    description: 'Manager module access'
  }
};
