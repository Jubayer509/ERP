export interface TechStackOption {
  layer: string;
  recommended: string;
  alternatives: string[];
  reasoning: string;
  scalabilityNotes: string;
}

export interface SchemaTable {
  name: string;
  module: 'LC Import' | 'Procurement' | 'Inventory' | 'Accounts & GL' | 'Sales' | 'HR' | 'System';
  description: string;
  primaryKey: string;
  columns: {
    name: string;
    type: string;
    isNullable: boolean;
    description: string;
    fkRef?: string;
  }[];
  indexes: string[];
}

export interface WorkflowStep {
  stepNumber: number;
  stageName: string;
  triggerEvent: string;
  operationalAction: string;
  requiredDocuments: string[];
  dbEntitiesUpdated: string[];
  accountingImpact: {
    debitAccount: string;
    creditAccount: string;
    nature: string;
    formulaOrExplanation: string;
  };
  sampleCalculation?: string;
}

export interface ModuleSpecification {
  id: string;
  moduleName: string;
  tagline: string;
  coreOperations: string[];
  subFeatures: {
    name: string;
    description: string;
    actions: string[];
    formsAndFields: string[];
    validationsAndRules: string[];
  }[];
  reportingCapabilities: string[];
  securityAndPermissions: string[];
}

export const ARCHITECTURE_GUIDANCE: TechStackOption[] = [
  {
    layer: 'Backend Framework & API Engine',
    recommended: 'Node.js (NestJS with TypeScript) OR Laravel 11 (PHP 8.3+)',
    alternatives: ['Python (FastAPI / Django)', 'Go (Golang)', 'Java Spring Boot'],
    reasoning: 'For ERPs handling high transaction volume, complex business logic, and heavy relational integrity: NestJS provides strong architectural modularity (DDD, Dependency Injection, TypeORM/Prisma, Microservices readiness). For rapid enterprise delivery with robust out-of-the-box queuing, RBAC, and financial job scheduling, Laravel 11 with Eloquent transactions and Horizon is an industry gold standard for trading firms.',
    scalabilityNotes: 'Implement CQRS (Command Query Responsibility Segregation) for financial reporting queries to isolate read-heavy ledger analytics from transactional write bottlenecks.'
  },
  {
    layer: 'Primary Relational Database',
    recommended: 'PostgreSQL 16+ with TimescaleDB extension for Audit/Ledger time-series',
    alternatives: ['MySQL 8.0 / MariaDB', 'Oracle Cloud Database', 'Microsoft SQL Server'],
    reasoning: 'Financial ledgers require strict ACID compliance, MVCC concurrency, native Table Partitioning (by Fiscal Year / Month), and JSONB support for dynamic customs tariff codes and landed cost formula rules. PostgreSQL handles strict precision NUMERIC(18,4) without floating-point drift.',
    scalabilityNotes: 'Partition `stock_ledger_entries` and `journal_voucher_items` by calendar year. Setup 1 Primary Write node with 2 Streaming Read Replicas for BI reports.'
  },
  {
    layer: 'Frontend Application Architecture',
    recommended: 'React 19 + TypeScript + Vite + Tailwind CSS + TanStack Query',
    alternatives: ['Vue 3 (Composition API) + Pinia', 'Next.js App Router (SSR)'],
    reasoning: 'ERP interfaces are state-dense workspaces featuring multi-tab work, high-density data grids, real-time keyboard navigation, inline calculations (e.g., Landed Cost prorating), and live voucher verification. React with TanStack Query provides optimistic caching and zero-flicker UX.',
    scalabilityNotes: 'Virtualize tables rendering over 500+ stock rows using TanStack Virtual. Centralize form schemas with Zod to synchronize validation across client and API.'
  },
  {
    layer: 'Cache, Message Queue & Async Processing',
    recommended: 'Redis 7.2 (Sentinel/Cluster) + RabbitMQ / BullMQ',
    alternatives: ['Apache Kafka', 'Amazon SQS', 'Google Cloud Pub/Sub'],
    reasoning: 'Import trading operations involve asynchronous tasks: automated Landed Cost recalculation across 20+ containers, biometric attendance log ingestion, nightly aging reports, and bank statement reconciliations.',
    scalabilityNotes: 'Use Redis for session store, rate limiting, and real-time inventory reservation locks during Sales Order booking to prevent stock overselling.'
  },
  {
    layer: 'Security, Multi-Tenancy & Audit Trail',
    recommended: 'OAuth2 / OIDC with JWT, HashiCorp Vault for API secrets, and Immutable Audit Log triggers',
    alternatives: ['Keycloak IAM', 'AWS KMS'],
    reasoning: 'Enterprise ERPs must comply with SOX / IFRS auditing requirements. Every insert/update on fiscal vouchers and inventory ledgers writes to a write-only, tamper-proof audit table with previous and new JSON snapshots.',
    scalabilityNotes: 'Enforce database-level Row Level Security (RLS) for multi-branch or multi-subsidiary isolation.'
  }
];

export const WORKFLOW_STEPS: WorkflowStep[] = [
  {
    stepNumber: 1,
    stageName: '1. LC Opening & Margin Booking',
    triggerEvent: 'Procurement selects overseas supplier PI and applies for LC with Issuing Bank.',
    operationalAction: 'Bank issues LC (Sight, Usance, or UPAS). Company deposits 10%-20% cash margin, pays opening commission, and books foreign currency commitment.',
    requiredDocuments: ['Proforma Invoice (PI)', 'Indent / Purchase Agreement', 'LC Application Form', 'Insurance Cover Note'],
    dbEntitiesUpdated: ['lc_masters', 'lc_margin_deposits', 'purchase_orders', 'journal_vouchers'],
    accountingImpact: {
      debitAccount: '1150 - LC Margin Deposit (Asset) & 5210 - LC Opening Commission (Expense)',
      creditAccount: '1020 - Primary Bank Current Account (Asset)',
      nature: 'Asset Reclassification & Bank Charge Expense',
      formulaOrExplanation: 'Dr. LC Margin Deposit = PI Value * Margin% * Bank Exchange Rate. LC commitment is also logged in off-balance-sheet memorandum.'
    },
    sampleCalculation: 'LC Value: $100,000 @ 118.50 BDT/USD = 11,850,000 BDT. 15% Margin: Dr. 1,777,500 BDT; Dr. Bank Charge: 25,000 BDT; Cr. Bank: 1,802,500 BDT.'
  },
  {
    stepNumber: 2,
    stageName: '2. Customs Assessment & Duty Payment',
    triggerEvent: 'Vessel docks at port of discharge; C&F agent submits Bill of Entry (BOE).',
    operationalAction: 'Customs authority assesses tariff value vs invoice value. Customs Duty (CD), Regulatory Duty (RD), Supplementary Duty (SD), VAT, and Advance Tax (AT) are calculated and paid through the bank.',
    requiredDocuments: ['Bill of Entry (BOE)', 'Commercial Invoice', 'Bill of Lading (BL)', 'Packing List', 'Certificate of Origin'],
    dbEntitiesUpdated: ['lc_bill_of_entries', 'lc_assessment_duties', 'lc_expenses', 'journal_vouchers'],
    accountingImpact: {
      debitAccount: '1160 - Goods In-Transit / LC Clearing WIP (Asset) & 1170 - Advance Tax / Recoverable VAT',
      creditAccount: '1020 - Primary Bank Account / Customs Duty Payment Gateway (Asset)',
      nature: 'Capitalization of Import Costs to In-Transit Asset',
      formulaOrExplanation: 'Duty components (CD + RD + SD) capitalize into LC Clearing WIP. Recoverable VAT/AT are routed to Tax Receivable accounts.'
    },
    sampleCalculation: 'Assessment Value: 12,500,000 BDT. CD (25%): 3,125,000; RD (3%): 375,000; SD (20%): 3,200,000 -> Capitalized into WIP. Recoverable VAT (15%): 2,880,000 BDT.'
  },
  {
    stepNumber: 3,
    stageName: '3. Port Demurrage, Freight & C&F Expenses',
    triggerEvent: 'Container released from port yard and loaded onto transport trucks.',
    operationalAction: 'Incur port handling charges, shipping line detention/demurrage fees, C&F agency fees, and transport carriage to central bonded warehouse.',
    requiredDocuments: ['Port Authority Port Dues Bill', 'Shipping Line Delivery Order (DO)', 'C&F Agent Bill', 'Truck Challan'],
    dbEntitiesUpdated: ['lc_expenses', 'accounts_payable_suppliers', 'journal_vouchers'],
    accountingImpact: {
      debitAccount: '1160 - Goods In-Transit / LC Clearing WIP (Asset)',
      creditAccount: '2010 - Accounts Payable (C&F Agent / Shipping Agent)',
      nature: 'Cost Accumulation into Work-in-Progress (WIP)',
      formulaOrExplanation: 'All direct landed overheads are accumulated in LC Clearing WIP before physical warehouse acceptance.'
    },
    sampleCalculation: 'Port Handling: 185,000 BDT + C&F Commission: 65,000 BDT + Local Freight: 140,000 BDT = 390,000 BDT capitalized into LC WIP.'
  },
  {
    stepNumber: 4,
    stageName: '4. Physical GRN Inspection & Warehouse Receipt',
    triggerEvent: 'Consignment arrives at central distribution warehouse or port yard.',
    operationalAction: 'Quality Assurance (QA) inspects seals and tallies received packages against Packing List. Warehouse generates verified Goods Received Note (GRN) / Receive Challan.',
    requiredDocuments: ['Goods Received Note (GRN)', 'Delivery Challan', 'Physical Inspection / Quality Inspection Report'],
    dbEntitiesUpdated: ['grn_masters', 'grn_items', 'warehouse_stock_staging'],
    accountingImpact: {
      debitAccount: 'Pending Final Costing (Items placed in Quarantine / Staging Stock)',
      creditAccount: 'Pending Final Costing',
      nature: 'Physical Quantity Verification Stage',
      formulaOrExplanation: 'GRN verifies actual acceptable quantity (Accepted Qty vs Damaged/Shortage Qty). Quantitative stock is verified prior to financial valuation.'
    },
    sampleCalculation: 'Manifested: 2,000 MT. Discharged & Accepted: 1,996 MT; 4 MT transit loss recorded in debit claim.'
  },
  {
    stepNumber: 5,
    stageName: '5. Automated Landed Cost Allocation Engine',
    triggerEvent: 'All LC expense vouchers and supplier commercial invoices are reconciled.',
    operationalAction: 'ERP Landed Cost Engine prorates accumulated clearing costs (Freight + CD + RD + SD + Port + C&F + Insurance) across line items based on Item Value OR Gross Weight / Volume.',
    requiredDocuments: ['Landed Cost Allocation Sheet', 'Consolidated LC Expense Audit Report'],
    dbEntitiesUpdated: ['landed_cost_batches', 'grn_items', 'inventory_items'],
    accountingImpact: {
      debitAccount: 'Inventory Valuation Base adjustment',
      creditAccount: 'LC In-Transit WIP Cleared',
      nature: 'Cost Allocation Algorithm Execution',
      formulaOrExplanation: 'Landed Unit Cost = (Base FOB Invoice Price) + (Apportioned Customs Duties) + (Apportioned Freight & Port Overhead per unit).'
    },
    sampleCalculation: 'Product A: Base $50/unit (5,925 BDT) + Duty Allocation 1,840 BDT + Port/Freight 315 BDT = Landed Cost 8,080 BDT/unit.'
  },
  {
    stepNumber: 6,
    stageName: '6. Inventory Stock Entry & AVCO Valuation Update',
    triggerEvent: 'Landed Cost Sheet approved by Accounts & Procurement Head.',
    operationalAction: 'Physical stock in staging is committed to Active Stock. The Weighted Average Cost (AVCO) or FIFO lot is permanently updated in the stock ledger.',
    requiredDocuments: ['Approved Stock Valuation Certificate', 'Stock Movement Ledger Entry'],
    dbEntitiesUpdated: ['inventory_items', 'warehouse_stocks', 'stock_ledger_entries'],
    accountingImpact: {
      debitAccount: '1200 - Finished Goods / Merchandise Inventory (Asset)',
      creditAccount: '1160 - Goods In-Transit / LC Clearing WIP (Asset)',
      nature: 'Asset Reclassification from WIP to Available Inventory',
      formulaOrExplanation: 'Dr. Merchandise Inventory (Total Landed Value) | Cr. Goods In-Transit WIP (Zeroes out the clearing pool).'
    },
    sampleCalculation: 'Existing Stock: 500 units @ 7,800 BDT. New Inflow: 2,000 units @ 8,080 BDT. New Weighted Average Cost = (3.9M + 16.16M) / 2500 = 8,024 BDT/unit.'
  },
  {
    stepNumber: 7,
    stageName: '7. Final Accounts Update & Bank Settlement / LTR',
    triggerEvent: 'LC maturity date arrives (Sight or Usance) for supplier payment.',
    operationalAction: 'Bank debits company account or converts usance LC into LTR (Loan against Trust Receipt) financing. Margin deposit is adjusted against principal obligation.',
    requiredDocuments: ['Bank Settlement Advice', 'LTR Agreement (if usance)', 'Supplier Payment Voucher'],
    dbEntitiesUpdated: ['accounts_payable_suppliers', 'bank_accounts', 'journal_vouchers'],
    accountingImpact: {
      debitAccount: '2010 - Overseas Supplier Payable / 2030 - LC Liability',
      creditAccount: '1150 - LC Margin Deposit (Asset Adjustment) & 1020 - Bank Account / 2050 - Bank LTR Loan (Liability)',
      nature: 'Liability Settlement & Margin Realization',
      formulaOrExplanation: 'Dr. Overseas Supplier Liability $100,000 (11.85M BDT) | Cr. LC Margin Deposit 1.777M BDT | Cr. Bank Account / LTR Loan 10.072M BDT.'
    },
    sampleCalculation: 'Total Supplier Bill: 11,850,000 BDT. Less Margin: 1,777,500 BDT. Balance Settled via Bank Overdraft/LTR: 10,072,500 BDT.'
  }
];

export const PRIMARY_SCHEMA_TABLES: SchemaTable[] = [
  {
    name: 'lc_masters',
    module: 'LC Import',
    description: 'Central registry of all commercial Letters of Credit, terms, and bank credit limits.',
    primaryKey: 'id (UUID)',
    columns: [
      { name: 'id', type: 'UUID', isNullable: false, description: 'Primary Key' },
      { name: 'lc_number', type: 'VARCHAR(64)', isNullable: false, description: 'Bank issued official LC number' },
      { name: 'lc_type', type: 'ENUM', isNullable: false, description: 'Sight, Usance 90d, Usance 180d, UPAS, Cash' },
      { name: 'issuing_bank_id', type: 'UUID', isNullable: false, description: 'FK to bank_accounts' },
      { name: 'supplier_id', type: 'UUID', isNullable: false, description: 'FK to suppliers table', fkRef: 'suppliers(id)' },
      { name: 'currency', type: 'VARCHAR(3)', isNullable: false, description: 'USD, EUR, CNY' },
      { name: 'exchange_rate', type: 'NUMERIC(12,4)', isNullable: false, description: 'Bank contract exchange rate to base currency' },
      { name: 'lc_value_foreign', type: 'NUMERIC(18,2)', isNullable: false, description: 'Total foreign currency amount' },
      { name: 'margin_percentage', type: 'NUMERIC(5,2)', isNullable: false, description: 'Bank cash margin deposit percentage' },
      { name: 'margin_amount_base', type: 'NUMERIC(18,2)', isNullable: false, description: 'Actual margin deposited in base currency' },
      { name: 'opening_date', type: 'DATE', isNullable: false, description: 'Date of LC establishment' },
      { name: 'expiry_date', type: 'DATE', isNullable: false, description: 'LC validity expiration date' },
      { name: 'status', type: 'VARCHAR(32)', isNullable: false, description: 'Opened, Shipped, Arrived, Cleared, Closed' },
      { name: 'created_at', type: 'TIMESTAMPTZ', isNullable: false, description: 'Audit creation timestamp' }
    ],
    indexes: ['CREATE UNIQUE INDEX idx_lc_number ON lc_masters(lc_number)', 'CREATE INDEX idx_lc_supplier ON lc_masters(supplier_id)', 'CREATE INDEX idx_lc_status ON lc_masters(status)']
  },
  {
    name: 'lc_bill_of_entries',
    module: 'LC Import',
    description: 'Customs declaration documents, tariff assessments, and duty liability tracking.',
    primaryKey: 'id (UUID)',
    columns: [
      { name: 'id', type: 'UUID', isNullable: false, description: 'Primary Key' },
      { name: 'lc_id', type: 'UUID', isNullable: false, description: 'FK to lc_masters', fkRef: 'lc_masters(id)' },
      { name: 'boe_number', type: 'VARCHAR(64)', isNullable: false, description: 'Official customs document reference' },
      { name: 'customs_station', type: 'VARCHAR(100)', isNullable: false, description: 'Port code (e.g. CGP / DAC)' },
      { name: 'assessment_date', type: 'DATE', isNullable: false, description: 'Date verified by customs inspector' },
      { name: 'assessable_value_base', type: 'NUMERIC(18,2)', isNullable: false, description: 'Customs determined taxable value' },
      { name: 'customs_duty_amount', type: 'NUMERIC(18,2)', isNullable: false, description: 'CD duty component' },
      { name: 'regulatory_duty_amount', type: 'NUMERIC(18,2)', isNullable: false, description: 'RD duty component' },
      { name: 'supplementary_duty_amount', type: 'NUMERIC(18,2)', isNullable: false, description: 'SD duty component' },
      { name: 'vat_amount', type: 'NUMERIC(18,2)', isNullable: false, description: 'Import VAT (recoverable)' },
      { name: 'advance_tax_amount', type: 'NUMERIC(18,2)', isNullable: false, description: 'Advance income tax (AT)' },
      { name: 'total_duty_paid', type: 'NUMERIC(18,2)', isNullable: false, description: 'Net customs clearance charge' },
      { name: 'payment_voucher_id', type: 'UUID', isNullable: true, description: 'FK to journal_vouchers', fkRef: 'journal_vouchers(id)' }
    ],
    indexes: ['CREATE INDEX idx_boe_lc ON lc_bill_of_entries(lc_id)', 'CREATE UNIQUE INDEX idx_boe_no ON lc_bill_of_entries(boe_number)']
  },
  {
    name: 'purchase_orders',
    module: 'Procurement',
    description: 'Commercial agreements with local and foreign suppliers.',
    primaryKey: 'id (UUID)',
    columns: [
      { name: 'id', type: 'UUID', isNullable: false, description: 'Primary Key' },
      { name: 'po_number', type: 'VARCHAR(64)', isNullable: false, description: 'Sequential PO number' },
      { name: 'supplier_id', type: 'UUID', isNullable: false, description: 'FK to suppliers', fkRef: 'suppliers(id)' },
      { name: 'lc_id', type: 'UUID', isNullable: true, description: 'Optional FK to lc_masters for foreign import POs', fkRef: 'lc_masters(id)' },
      { name: 'order_date', type: 'DATE', isNullable: false, description: 'Order submission date' },
      { name: 'delivery_terms', type: 'VARCHAR(32)', isNullable: false, description: 'CFR, FOB, CIF, EXW' },
      { name: 'total_amount_base', type: 'NUMERIC(18,2)', isNullable: false, description: 'Order gross amount in base currency' },
      { name: 'status', type: 'VARCHAR(32)', isNullable: false, description: 'Draft, Approved, Partial GRN, Closed' }
    ],
    indexes: ['CREATE UNIQUE INDEX idx_po_number ON purchase_orders(po_number)', 'CREATE INDEX idx_po_supplier ON purchase_orders(supplier_id)']
  },
  {
    name: 'grn_masters',
    module: 'Procurement',
    description: 'Goods Received Notes for warehouse physical intake and quality gating.',
    primaryKey: 'id (UUID)',
    columns: [
      { name: 'id', type: 'UUID', isNullable: false, description: 'Primary Key' },
      { name: 'grn_number', type: 'VARCHAR(64)', isNullable: false, description: 'GRN serial number' },
      { name: 'po_id', type: 'UUID', isNullable: false, description: 'FK to purchase_orders', fkRef: 'purchase_orders(id)' },
      { name: 'lc_id', type: 'UUID', isNullable: true, description: 'FK to lc_masters', fkRef: 'lc_masters(id)' },
      { name: 'warehouse_id', type: 'UUID', isNullable: false, description: 'FK to warehouses', fkRef: 'warehouses(id)' },
      { name: 'received_date', type: 'DATE', isNullable: false, description: 'Physical unloading date' },
      { name: 'container_numbers', type: 'TEXT', isNullable: true, description: 'Comma-separated 40ft/20ft container identifiers' },
      { name: 'quality_status', type: 'VARCHAR(32)', isNullable: false, description: 'Passed, Rejected, Quarantine' },
      { name: 'is_cost_allocated', type: 'BOOLEAN', isNullable: false, description: 'True once landed costs are distributed' }
    ],
    indexes: ['CREATE UNIQUE INDEX idx_grn_number ON grn_masters(grn_number)', 'CREATE INDEX idx_grn_lc ON grn_masters(lc_id)']
  },
  {
    name: 'inventory_items',
    module: 'Inventory',
    description: 'Item master catalogue with category hierarchy, HS Code, UOM, and valuation.',
    primaryKey: 'id (UUID)',
    columns: [
      { name: 'id', type: 'UUID', isNullable: false, description: 'Primary Key' },
      { name: 'sku', type: 'VARCHAR(64)', isNullable: false, description: 'Unique Stock Keeping Unit' },
      { name: 'name', type: 'VARCHAR(255)', isNullable: false, description: 'Commercial product name' },
      { name: 'category_id', type: 'UUID', isNullable: false, description: 'FK to item_categories' },
      { name: 'hs_code', type: 'VARCHAR(16)', isNullable: false, description: 'Customs Harmonized System code for duty classification' },
      { name: 'uom', type: 'VARCHAR(16)', isNullable: false, description: 'MT, KG, Pcs, Cbm, Box' },
      { name: 'avg_cost_price', type: 'NUMERIC(18,4)', isNullable: false, description: 'Current weighted average landed cost' },
      { name: 'standard_selling_price', type: 'NUMERIC(18,2)', isNullable: false, description: 'Base wholesale selling price' },
      { name: 'reorder_level', type: 'NUMERIC(14,2)', isNullable: false, description: 'Minimum trigger threshold' },
      { name: 'total_physical_stock', type: 'NUMERIC(14,2)', isNullable: false, description: 'Aggregated stock across all warehouses' }
    ],
    indexes: ['CREATE UNIQUE INDEX idx_item_sku ON inventory_items(sku)', 'CREATE INDEX idx_item_hscode ON inventory_items(hs_code)']
  },
  {
    name: 'stock_ledger_entries',
    module: 'Inventory',
    description: 'Immutable, chronological ledger of all physical and financial stock movements.',
    primaryKey: 'id (BIGSERIAL)',
    columns: [
      { name: 'id', type: 'BIGSERIAL', isNullable: false, description: 'Primary Key' },
      { name: 'item_id', type: 'UUID', isNullable: false, description: 'FK to inventory_items', fkRef: 'inventory_items(id)' },
      { name: 'warehouse_id', type: 'UUID', isNullable: false, description: 'FK to warehouses', fkRef: 'warehouses(id)' },
      { name: 'entry_type', type: 'ENUM', isNullable: false, description: 'GRN, Delivery_Order, Transfer_In, Transfer_Out, Stock_Adjustment' },
      { name: 'reference_voucher_no', type: 'VARCHAR(64)', isNullable: false, description: 'GRN or Challan or Transfer ID' },
      { name: 'quantity_change', type: 'NUMERIC(14,4)', isNullable: false, description: 'Signed qty (+ for intake, - for dispatch)' },
      { name: 'unit_landed_cost', type: 'NUMERIC(18,4)', isNullable: false, description: 'Actual unit landed cost applied' },
      { name: 'balance_quantity_after', type: 'NUMERIC(14,4)', isNullable: false, description: 'Running balance after movement' },
      { name: 'created_at', type: 'TIMESTAMPTZ', isNullable: false, description: 'Ledger insertion time' }
    ],
    indexes: ['CREATE INDEX idx_stock_ledger_item_wh ON stock_ledger_entries(item_id, warehouse_id, created_at)']
  },
  {
    name: 'journal_vouchers',
    module: 'Accounts & GL',
    description: 'Double-entry general ledger voucher header record.',
    primaryKey: 'id (UUID)',
    columns: [
      { name: 'id', type: 'UUID', isNullable: false, description: 'Primary Key' },
      { name: 'voucher_number', type: 'VARCHAR(64)', isNullable: false, description: 'e.g. JV-2026-0041, PV-2026-0102' },
      { name: 'voucher_type', type: 'ENUM', isNullable: false, description: 'JV (Journal), PV (Payment), RV (Receipt), Contra' },
      { name: 'voucher_date', type: 'DATE', isNullable: false, description: 'Effective fiscal posting date' },
      { name: 'source_module', type: 'VARCHAR(32)', isNullable: false, description: 'LC, Inventory, Sales, Procurement, Payroll' },
      { name: 'source_reference_id', type: 'VARCHAR(64)', isNullable: true, description: 'LC No, GRN No, or Invoice No' },
      { name: 'total_debit', type: 'NUMERIC(18,2)', isNullable: false, description: 'Sum of debit entries' },
      { name: 'total_credit', type: 'NUMERIC(18,2)', isNullable: false, description: 'Sum of credit entries (must equal debit)' },
      { name: 'narration', type: 'TEXT', isNullable: false, description: 'Detailed accounting explanation' },
      { name: 'is_posted', type: 'BOOLEAN', isNullable: false, description: 'Locked once posted to GL' }
    ],
    indexes: ['CREATE UNIQUE INDEX idx_voucher_no ON journal_vouchers(voucher_number)', 'CREATE INDEX idx_voucher_date ON journal_vouchers(voucher_date)']
  },
  {
    name: 'journal_voucher_items',
    module: 'Accounts & GL',
    description: 'Line-level split debit and credit entries with Chart of Accounts references.',
    primaryKey: 'id (BIGSERIAL)',
    columns: [
      { name: 'id', type: 'BIGSERIAL', isNullable: false, description: 'Primary Key' },
      { name: 'voucher_id', type: 'UUID', isNullable: false, description: 'FK to journal_vouchers', fkRef: 'journal_vouchers(id)' },
      { name: 'account_code', type: 'VARCHAR(32)', isNullable: false, description: 'FK to chart_of_accounts(code)' },
      { name: 'debit_amount', type: 'NUMERIC(18,2)', isNullable: false, description: 'Debit value in base currency' },
      { name: 'credit_amount', type: 'NUMERIC(18,2)', isNullable: false, description: 'Credit value in base currency' },
      { name: 'cost_center_id', type: 'UUID', isNullable: true, description: 'Branch or LC consignment cost center' }
    ],
    indexes: ['CREATE INDEX idx_jvi_account ON journal_voucher_items(account_code)', 'CREATE INDEX idx_jvi_voucher ON journal_voucher_items(voucher_id)']
  }
];

export const MODULE_SPECIFICATIONS: ModuleSpecification[] = [
  {
    id: 'sales',
    moduleName: '1. Sales & Distribution Module',
    tagline: 'Order-to-Cash, credit management, dispatch logistics, and multi-channel collections.',
    coreOperations: ['Direct Sales Invoice', 'Sales Order (SO)', 'Delivery Order (DO) / Challan'],
    subFeatures: [
      {
        name: 'Order-to-Cash Workflow',
        description: 'Enables Sales Orders booking against stock allocation with credit limit validation, progressing to Delivery Challan and Sales Invoice.',
        actions: ['Create Sales Order', 'Approve SO with Credit Check', 'Issue Delivery Challan', 'Generate Sales Invoice', 'Print Tax Invoice'],
        formsAndFields: ['Customer ID, Order Date, Delivery Address, Sales Rep, Payment Terms (Cash/Credit/Cheque), Line items [Item, Batch/Container, Qty, Unit Price, Line Discount, Tax Rate, Total Amount].'],
        validationsAndRules: ['Customer credit balance + new order amount cannot exceed approved credit limit without management override.', 'Stock cannot be over-allocated beyond unreserved warehouse quantity.']
      },
      {
        name: 'Customer Profiling & Credit Due Tracking',
        description: 'Comprehensive 360-degree customer profiling with transaction history, credit days (e.g. 30/60/90 days), and aging reports.',
        actions: ['Create Customer Profile', 'Update Credit Limits', 'View Customer Ledger', 'Run Aging Buckets Report', 'Freeze Delinquent Account'],
        formsAndFields: ['Code, Trade Name, Legal Name, TIN/BIN, Credit Limit, Credit Period (Days), Contact Person, Phone, Email, Billing & Shipping Addresses, Bank Info.'],
        validationsAndRules: ['Unique TIN/BIN validation.', 'Automatic account status update to On-Hold if unpaid invoices exceed 90 days.']
      },
      {
        name: 'Payment Collections & Advance Adjustments',
        description: 'Multi-mode payment settlement via Cash, Cheque, Bank Wire, or Mobile Financial Services (MFS), with advance collection allocation.',
        actions: ['Collect Customer Payment', 'Allocate Payment to Invoices', 'Adjust Advance Deposits', 'Apply Approved Rebate/Discount'],
        formsAndFields: ['Receipt Voucher No, Customer ID, Date, Amount, Payment Channel, Cheque No, Maturity Date, Bank Account, Invoice Settlement Allocation Grid.'],
        validationsAndRules: ['Cheque receipts remain in In-Hand status until clearing date.', 'Double-entry updates Customer Ledger and Cash/Bank accounts automatically.']
      }
    ],
    reportingCapabilities: [
      'Daily Sales Report with cash vs credit breakdown',
      'Item-wise Sales Volume and Margin Analysis',
      'Customer-wise Sales Performance and Trend Graphs',
      'Profitability Report (Gross and Net Margin per invoice/item)',
      'Accounts Receivable Aging Report (Current, 1-30, 31-60, 61-90, 90+ days)'
    ],
    securityAndPermissions: ['Sales Officer: Create SO', 'Sales Manager: Approve SO & Credit Overrides', 'Accounts: Post Invoices and Collections']
  },
  {
    id: 'purchase',
    moduleName: '2. Purchase & Procurement Module',
    tagline: 'Requisition, Direct Purchase Invoices, Goods Received Note, and supplier payables management.',
    coreOperations: ['Purchase Requisition (PR)', 'Direct Purchase Invoice', 'Goods Received Note (GRN) / Receive Challan', 'Purchase Return & Debit Note'],
    subFeatures: [
      {
        name: 'Procurement & Direct Purchase Life Cycle',
        description: 'Facilitates department requisitions, multi-vendor comparative quotes, formal Direct Purchase Invoice generation, and GRN inspection gating.',
        actions: ['Submit PR', 'Approve Requisition', 'Generate Direct Purchase Invoice', 'Record GRN', 'Process Debit Note for Returns'],
        formsAndFields: ['Invoice No, Challan No, Supplier ID, Currency, Payment Terms, Warehouse, Line items [Item, Quantity, Unit Rate, Subtotal].'],
        validationsAndRules: ['Direct invoice updates stock ledger immediately or upon GRN receipt.', 'Prevents duplicate supplier challan/invoice entry.']
      },
      {
        name: 'Supplier Profiling & Payables Aging',
        description: 'Vendor database with performance ratings, lead time tracking, payment terms, and aging breakdown.',
        actions: ['Profile Supplier', 'Review Supplier Statement', 'Analyze Vendor Performance', 'Generate AP Aging'],
        formsAndFields: ['Supplier Code, Trade Name, Country, Category (Overseas / Local / C&F / Freight), Payment Terms, Bank Details, Contact Person.'],
        validationsAndRules: ['Prevents duplicate supplier invoicing via invoice number and date uniqueness checks.']
      },
      {
        name: 'Cost Allocation & Landed Cost Integration',
        description: 'Allocates external purchase costs (local transport, offloading, storage) to local and imported purchase lots.',
        actions: ['Link GRN to PO', 'Enter External Purchase Costs', 'Apportion Costs to Lot Inventory'],
        formsAndFields: ['GRN Reference, Expense Category, Vendor, Amount, Allocation Basis (Quantity / Value / Weight).'],
        validationsAndRules: ['Apportioned expenses debit inventory cost and credit vendor payable.']
      }
    ],
    reportingCapabilities: [
      'Purchase Summary Report (Monthly/Quarterly)',
      'Item-wise Purchase Cost Variance Report',
      'Supplier Outstanding Payables & Aging Analysis',
      'Purchase Return and Debit Note Summary',
      'Pending PO Tracking & Delivery Status'
    ],
    securityAndPermissions: ['Procurement Officer: Create PR/PO', 'Purchase Manager: Approve PO', 'Store Keeper: Generate GRN', 'Finance: Authorize Vendor Payments']
  },
  {
    id: 'lc',
    moduleName: '3. Letter of Credit (LC) Import Module',
    tagline: 'Specialized enterprise module for import financing, customs clearance, and landed costing.',
    coreOperations: ['LC Opening Application', 'LC Type Selection (Sight, Usance, UPAS, Cash)', 'LC Amendment Tracking', 'Margin Deposit Management'],
    subFeatures: [
      {
        name: 'LC Life Cycle & Banking Management',
        description: 'Handles complete LC issuance from bank application, margin deposit booking, amendment tracking, and foreign currency commitment.',
        actions: ['Open LC', 'Record Bank Margin Deposit', 'File LC Amendment', 'Log Shipment Advice', 'Settle LC / Convert to LTR'],
        formsAndFields: ['LC No, Issuing Bank, Advising Bank, Supplier PI, LC Type (Sight, Usance 90d, Usance 180d, UPAS, Cash LC), Currency, Exchange Rate, Value, Margin %, Expiry Date, Port of Loading/Discharge.'],
        validationsAndRules: ['Margin deposit must be posted to GL account 1150 before LC can transition to Opened status.', 'Amendment value changes trigger proportional margin adjustment.']
      },
      {
        name: 'Import Documentation & Port Clearance',
        description: 'Tracks Bill of Entry (BOE), Bill of Lading (BL), customs duty calculations, and port logistical expenses.',
        actions: ['Record Bill of Entry', 'Compute Customs Assessment Duties', 'Book Port Demurrage & C&F Agent Fees', 'Track Container Clearance'],
        formsAndFields: ['BOE No, Customs Station, Assessment Value, CD (Customs Duty), RD (Regulatory Duty), SD (Supplementary Duty), VAT, AT (Advance Tax), Demurrage Bills, Clearing Agency Invoices.'],
        validationsAndRules: ['Differentiates capitalized duties (CD/RD/SD) from tax-deductible/recoverable VAT and Advance Tax (AT).']
      },
      {
        name: 'Automated Landed Cost Calculation Engine',
        description: 'Prorates all accumulated import expenses across received line items to calculate the true Landed Unit Cost before inventory valuation.',
        actions: ['Run Landed Cost Apportionment', 'Select Apportionment Method (By Value / By Gross Weight / By Volume)', 'Approve Landed Cost Sheet', 'Post Stock Valuation Voucher'],
        formsAndFields: ['LC Number, Container Reference, Base FOB Price, Prorated Freight, Prorated Customs Duty, Prorated Port/Handling, Computed Landed Cost per UOM.'],
        validationsAndRules: ['Total allocated cost must exactly equal the total LC Clearing WIP balance down to 2 decimal places.']
      }
    ],
    reportingCapabilities: [
      'LC Status & Life Cycle Pipeline Tracker',
      'Consolidated LC Expenses Summary by Category',
      'Landed Cost Sheet per Container / Consignment',
      'Bank LTR (Loan against Trust Receipt) & Latent Duty Liability Report',
      'Import Variance Analysis: Estimated vs Actual Landed Cost'
    ],
    securityAndPermissions: ['LC Executive: Create Application & Expenses', 'Commercial Head: Approve LC & Amendments', 'Chief Accountant: Approve Landed Cost Sheet & Journal Voucher']
  },
  {
    id: 'inventory',
    moduleName: '4. Item & Inventory Management Module',
    tagline: 'Multi-warehouse stock, location transfers, FIFO/AVCO valuation, and stock audits.',
    coreOperations: ['Multi-level Categories & UOM', 'Inventory Location Transfers', 'Stock Adjustments (Damage, Loss, Surplus)', 'Physical Stock Reconciliation'],
    subFeatures: [
      {
        name: 'Master Data & Stock Categorization',
        description: 'Maintains SKU master data, HS codes, multi-level hierarchy, units of measurement (UOM), and re-order thresholds.',
        actions: ['Create Inventory Item', 'Set Reorder Points', 'Configure Multi-UOM Conversions', 'Assign HS Code'],
        formsAndFields: ['SKU, Commercial Name, Category, Sub-Category, HS Code, Primary UOM, Packaging UOM, Min Stock, Max Stock, Reorder Point, Standard Cost.'],
        validationsAndRules: ['SKU must be globally unique.', 'HS Code format validated for customs compliance.']
      },
      {
        name: 'Location Transfers & In-Transit Tracking',
        description: 'Transfers stock between Central Port Bonded Yard, Regional Warehouses, and Retail Distribution Depots with in-transit status.',
        actions: ['Initiate Transfer Order', 'Dispatch Transfer with Vehicle Challan', 'Receive & Reconcile Transfer', 'Log Transit Discrepancy'],
        formsAndFields: ['Transfer No, Date, Source Warehouse, Destination Warehouse, Item, Transfer Qty, Vehicle No, Driver, Expected Arrival.'],
        validationsAndRules: ['Transferred items move to In-Transit stage until destination warehouse physically confirms receipt.']
      },
      {
        name: 'Stock Adjustment & Valuation Methods',
        description: 'Physical audit reconciliation, scrap/damage write-offs, and Weighted Average Cost (AVCO) or FIFO lot valuation.',
        actions: ['Enter Physical Count', 'Generate Stock Reconciliation', 'Post Damage/Loss Adjustment', 'Compute Inventory Valuation'],
        formsAndFields: ['Adjustment No, Date, Warehouse, Item, System Qty, Physical Count, Difference, Unit Cost, Reason Code, GL Expense Account.'],
        validationsAndRules: ['Surplus adjustments credit Inventory Adjustment Gain; Losses debit Stock Damage Expense with dual manager sign-off.']
      }
    ],
    reportingCapabilities: [
      'Real-time Stock Summary by Warehouse & Central Pool',
      'Low Stock & Reorder Point Alert Report',
      'Fast-moving vs Slow-moving ABC Analysis',
      'Inventory Valuation Report (Weighted Average / FIFO)',
      'Item Movement Ledger (Detailed transaction chronology)'
    ],
    securityAndPermissions: ['Store Officer: Request Transfer & Count', 'Warehouse Manager: Approve Transfer & Adjustment', 'Auditor: Perform Physical Audit']
  },
  {
    id: 'accounts',
    moduleName: '5. Accounts, Banking & General Ledger (GL)',
    tagline: 'Multi-layer Chart of Accounts, Vouchers, Cheque Clearing, BRS, and IFRS Financials.',
    coreOperations: ['Chart of Accounts', 'Journal, Payment, Receipt & Contra Vouchers', 'Cheque Management', 'Bank Reconciliation Statement (BRS)'],
    subFeatures: [
      {
        name: 'Chart of Accounts & Multi-layer Ledger',
        description: '5-tier Chart of Accounts (Assets 1000, Liabilities 2000, Equity 3000, Revenue 4000, Expenses 5000) with cost centers.',
        actions: ['Create Account Head', 'Define Cost Centers', 'View Account Ledger', 'Lock Fiscal Period'],
        formsAndFields: ['Account Code, Account Name, Group, Category, Normal Balance (Debit/Credit), Parent Code, Currency.'],
        validationsAndRules: ['Parent accounts cannot directly hold transaction postings; postings occur on terminal leaf accounts only.']
      },
      {
        name: 'Voucher Processing & Validation',
        description: 'Double-entry bookkeeping vouchers (JV, PV, RV, Contra) with real-time debit and credit equality enforcement.',
        actions: ['Create Journal Voucher', 'Issue Payment Voucher', 'Record Receipt Voucher', 'Transfer Contra', 'Post & Lock Voucher'],
        formsAndFields: ['Voucher No, Date, Type, Source Reference, Narration, Line Items [Account Head, Debit, Credit, Cost Center/LC Ref].'],
        validationsAndRules: ['Sum(Debit) MUST equal Sum(Credit) exactly. Posted vouchers are immutable and require formal reversal vouchers to modify.']
      },
      {
        name: 'Banking, Cheque Clearing & Automated BRS',
        description: 'Tracks multiple corporate bank accounts, cheque book registers, maturity dates, dishonor tracking, and monthly Bank Reconciliation Statements.',
        actions: ['Register Cheque Book', 'Update Cheque Status (Deposited / Cleared / Dishonored)', 'Import Bank Statement', 'Execute Bank Reconciliation'],
        formsAndFields: ['Bank Account, Cheque No, Party, Amount, Cheque Date, Maturity Date, Clearing Date, Statement Balance vs Ledger Balance Reconciliation Grid.'],
        validationsAndRules: ['BRS accounts for unpresented cheques and deposits in transit to produce zero variance.']
      }
    ],
    reportingCapabilities: [
      'Real-time Trial Balance (Summary and Detailed)',
      'Income Statement / Profit & Loss Statement (Monthly & YTD)',
      'Balance Sheet (Assets, Liabilities & Equity)',
      'Cash Flow Statement (Operating, Investing, Financing)',
      'Tax & VAT Deducted at Source (TDS/VDS) Statutory Statement'
    ],
    securityAndPermissions: ['Accountant: Create Vouchers', 'Finance Manager: Review Vouchers', 'CFO / Controller: Post & Finalize Financial Statements']
  },
  {
    id: 'hr',
    moduleName: '6. HR & Payroll Management Module',
    tagline: 'Employee master data, biometric attendance, leave workflows, and monthly salary disbursement.',
    coreOperations: ['Employee Master Profile', 'Attendance & Shift Tracking', 'Leave Workflow', 'Monthly Payroll & Payslip Generation'],
    subFeatures: [
      {
        name: 'Employee Master & Document Filing',
        description: 'Complete employee lifecycle management, department assignments, salary structures, and document compliance.',
        actions: ['Onboard Employee', 'Update Salary Structure', 'Upload Credentials', 'Manage Contracts'],
        formsAndFields: ['Emp Code, Full Name, Department, Designation, Joining Date, Basic Salary, House Rent, Medical, Conveyance, Bank Account, Emergency Contact.'],
        validationsAndRules: ['Automatic computation of Gross Salary from component formulas.']
      },
      {
        name: 'Attendance & Leave Approval Workflow',
        description: 'Biometric time-clock integration, shift rules, late-in/early-out deduction policies, and multi-tier leave approval.',
        actions: ['Sync Biometric Logs', 'Submit Leave Request', 'Approve/Reject Leave', 'Calculate Working Days'],
        formsAndFields: ['Employee ID, Leave Type (Casual, Sick, Earned), Start Date, End Date, Reason, Backup Personnel, Approval Status.'],
        validationsAndRules: ['Leave cannot exceed available quota balance. Late-in policy applies 1 day leave deduction for every 3 unexcused late attendances.']
      },
      {
        name: 'Payroll Engine & Statutory Deductions',
        description: 'Monthly salary calculation factoring in basic pay, allowances, overtime hours, bonuses, Provident Fund (PF), Tax TDS, and loan advances.',
        actions: ['Run Monthly Payroll', 'Approve Salary Sheet', 'Generate Bank Advice Sheet', 'Print Individual Payslips', 'Disburse Salaries'],
        formsAndFields: ['Month/Year, Gross Salary, Overtime Pay, Festival Bonus, PF Deduction (e.g. 10%), Tax TDS, Advance Deduction, Net Payable.'],
        validationsAndRules: ['Approved salary sheet automatically generates Accounts General Ledger Payment Voucher (Dr. Salary Expense, Cr. PF Payable, Cr. Bank).']
      }
    ],
    reportingCapabilities: [
      'Comprehensive Monthly Salary Sheet by Department',
      'Employee Payslip Generation (Printable / PDF preview)',
      'Bank Advice Sheet for Electronic Fund Transfer (EFT)',
      'Monthly Attendance and Punctuality Summary',
      'Statutory Provident Fund (PF) & Gratuity Statement'
    ],
    securityAndPermissions: ['HR Officer: Log Attendance & Leave', 'HR Manager: Run Payroll Sheet', 'Accounts: Verify & Disburse Payments']
  },
  {
    id: 'admin',
    moduleName: '7. System Setup, Administration & Security Module',
    tagline: 'Multi-branch configurations, granular RBAC, numbering engines, and immutable audit logs.',
    coreOperations: ['Multi-Branch & Fiscal Year Setup', 'Role-Based Access Control (RBAC)', 'Auto-Numbering Sequences', 'Audit Trail & Data Safety'],
    subFeatures: [
      {
        name: 'Multi-Company & Fiscal Configuration',
        description: 'Configures multiple operating branches, fiscal calendar periods, default currency, and live foreign exchange rates.',
        actions: ['Add Company Branch', 'Set Active Fiscal Year', 'Update Daily Forex Rates', 'Configure Tax/VAT Rates'],
        formsAndFields: ['Company Name, Branch Name, Port Facility Tag, Fiscal Year Start/End, Base Currency, Active Currencies (USD, EUR, CNY, BDT).'],
        validationsAndRules: ['Closed fiscal years prevent historical voucher alterations.']
      },
      {
        name: 'Granular Role-Based Access Control (RBAC)',
        description: 'Defines roles with page and action-level permissions (Create, Read, Update, Delete, Approve) per module.',
        actions: ['Create User Role', 'Assign Granular Permissions', 'Bind User to Role & Branch', 'Enforce Password Policies'],
        formsAndFields: ['Role Name, Description, Permission Matrix [Module, Can Create, Can Read, Can Update, Can Delete, Can Approve].'],
        validationsAndRules: ['Financial approval permissions reserved strictly for Manager and Executive roles.']
      },
      {
        name: 'Audit Trail & Automated Numbering Sequences',
        description: 'Configures custom prefixes for invoices and vouchers, alongside an append-only audit trail logging all user actions.',
        actions: ['Define Voucher Prefix Templates', 'View Real-time Audit Trail', 'Configure Database Backup Schedules', 'Export Audit Records'],
        formsAndFields: ['Entity Type, Prefix Template (e.g. INV-{YYYY}-{SEQ:5}), Next Sequence No, Audit Logs [User, Timestamp, Action, Old/New State].'],
        validationsAndRules: ['Audit logs cannot be edited or deleted by any user, including Super Admin.']
      }
    ],
    reportingCapabilities: [
      'System User Activity & Access Audit Log',
      'Permission Matrix Summary Report by Role',
      'Database Backup and Integrity Verification Log',
      'Exchange Rate History and Variance Analysis'
    ],
    securityAndPermissions: ['System Administrator: Full system configuration', 'Auditor: Read-only access to Audit Trail']
  },
  {
    id: 'dashboard',
    moduleName: '8. Business Intelligence & Executive Dashboard Module',
    tagline: 'Real-time KPIs, financial trends, LC pipeline status, and executive approval command center.',
    coreOperations: ['Real-time KPI Cards', 'Visual Sales & Revenue Analytics', 'LC Progress Timeline', 'Actionable Pending Approvals'],
    subFeatures: [
      {
        name: 'Executive KPI Metrics Engine',
        description: 'Real-time calculation of key trading metrics: Today Sales, Total Receivables, Total Payables, Cash & Bank Reserves, and Inventory Asset Value.',
        actions: ['View Real-time KPI Cards', 'Filter by Branch / Timeframe', 'Drill-down to Sub-ledgers'],
        formsAndFields: ['Date Range Filter, Branch Selector, Currency Toggle.'],
        validationsAndRules: ['Metrics refresh asynchronously from indexed materialized views or Redis cache.']
      },
      {
        name: 'Visual Analytics & Trend Visualizers',
        description: 'Interactive graphical charts for Monthly Revenue vs Expenses, Top Selling Imported Commodities, and LC Pipeline distribution.',
        actions: ['View Monthly Sales Bar Graph', 'Inspect LC Pipeline Stage Funnel', 'Analyze Product Gross Margins'],
        formsAndFields: ['Chart Type Selectors, Dimension Filters (Item / Category / Customer Group).'],
        validationsAndRules: ['Aggregations run on read-replica database to eliminate operational lockups.']
      },
      {
        name: 'Actionable Executive Command Center',
        description: 'Centralized queue for pending approvals: Sales Orders over credit limit, Direct Purchase Invoices, Leave Requests, and High-Value Vouchers.',
        actions: ['Review Pending Order', 'One-Click Approve / Reject', 'Review Cheque Maturity Alerts', 'Inspect Low Stock Notifications'],
        formsAndFields: ['Approval Queue Item [Type, Requester, Amount, Due Date, Action Buttons Approve/Reject with Remark].'],
        validationsAndRules: ['All approvals trigger notifications and write to the audit trail immediately.']
      }
    ],
    reportingCapabilities: [
      'Executive Flash Report (Single page snapshot)',
      'Cash Flow Forecast for next 30/60/90 days',
      'LC Maturation and Bank Obligation Schedule',
      'Inventory Stock Turnover & Holding Cost Analysis'
    ],
    securityAndPermissions: ['Directors & C-Suite: Unrestricted view', 'Department Heads: Departmental KPI drill-down']
  }
];
