export type ModuleTab = 
  | 'dashboard'
  | 'pos'
  | 'sales'
  | 'purchase'
  | 'lc'
  | 'inventory'
  | 'accounts'
  | 'hr'
  | 'hrm'
  | 'admin'
  | 'reports'
  | 'truck_report'
  | 'blueprint_arch'
  | 'blueprint_schema'
  | 'blueprint_workflow'
  | 'blueprint_specs';

export type UserRole = 
  | 'admin'      // Super Admin / Owner
  | 'manager'    // Manager (Controlled by RBAC)
  | 'lc_manager' // legacy fallback
  | 'accounts'   // legacy fallback
  | 'procurement'// legacy fallback
  | 'sales'      // legacy fallback
  | 'inventory'; // legacy fallback

export interface UserPermissions {
  dashboard: boolean; // Dashboard & Executive KPI
  sales: boolean;     // Sales, Invoices & POS
  purchase: boolean;  // Purchase & Vendor Management
  lc: boolean;        // Commercial & LC Import Hub
  inventory: boolean; // Item & Warehouse Inventory
  accounts: boolean;  // Accounting, Ledger & Banking
  hrm: boolean;       // HRM & Payroll
  reports: boolean;   // Reports & Statements
  admin: boolean;     // System Setup & RBAC
}

export const DEFAULT_ADMIN_PERMISSIONS: UserPermissions = {
  dashboard: true,
  sales: true,
  purchase: true,
  lc: true,
  inventory: true,
  accounts: true,
  hrm: true,
  reports: true,
  admin: true,
};

export const DEFAULT_MANAGER_PERMISSIONS: UserPermissions = {
  dashboard: true,
  sales: true,
  purchase: true,
  lc: false,
  inventory: true,
  accounts: true,
  hrm: false,
  reports: true,
  admin: false,
};

export interface ErpUser {
  uid: string;
  name?: string; // Standard profile name
  userId?: string; // Custom System User ID / Login ID (e.g. 'BUR-01', 'EMP-102')
  username?: string; // Username alias
  email: string;
  displayName: string;
  role: UserRole;
  branch: string; // 'All Branches' | 'Burimari Office' | 'Sonahat Office' | etc.
  phone?: string;
  avatarUrl?: string;
  status: 'active' | 'suspended';
  active?: boolean; // Firestore boolean flag for active status
  mustChangePassword?: boolean; // Flag forcing password change upon first login
  temporaryPassword?: string; // Ephemeral for copy dialog only, never stored in DB
  createdAt: string;
  lastLogin?: string;
  password?: string;
  assignedOffice?: 'Burimari Office' | 'Sonahat Office' | 'All Branches' | string;
  permissions?: UserPermissions;
}

export interface POSSale {
  id: string;
  invoiceNo: string; // e.g. POS-BUR-08812, POS-SON-09142
  challanNo: string; // Delivery / Gate Pass Challan e.g. CH-8901
  date: string;
  time: string;
  branch: 'Burimari Office' | 'Sonahat Office' | string;
  cashierUid: string;
  cashierName: string;
  customerName: string;
  customerPhone?: string;
  truckNo?: string; // e.g. DHAKA METRO-TA 11-5678
  driverName?: string;
  driverPhone?: string;
  weighbridgeSlipNo?: string;
  netWeightMt?: number;
  items: {
    itemId: string;
    itemName: string;
    quantity: number;
    unitPrice: number;
    uom: string;
    total: number;
  }[];
  subtotal: number;
  discount: number;
  taxAmount: number;
  grandTotal: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: 'Cash' | 'bKash / Nagad' | 'Bank Cheque' | 'Credit' | string;
  status: 'Completed' | 'Pending Due';
  notes?: string;
}

export type LCType = 'Sight' | 'Usance 90 Days' | 'Usance 180 Days' | 'UPAS' | 'Cash LC';
export type LCStatus = 'Draft' | 'Confirmed' | 'Discrepant' | 'Bank Applied' | 'Opened / Margin Paid' | 'Shipment In-Transit' | 'Port Arrived / BOE Filed' | 'Customs Cleared' | 'GRN Received' | 'Costed & Closed' | 'Accepted' | 'Matured' | 'Cancelled' | 'Voided';

export interface Customer {
  id: string;
  code: string;
  name: string;
  tradeName: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  creditDays: number;
  currentBalance: number;
  advanceBalance?: number;
  status: 'Active' | 'On Hold' | 'Blacklisted' | 'Inactive';
  companyName?: string;
  mobile?: string;
  paymentTerms?: string;
  customTermsDays?: string | number;
  openingBalance?: number;
  balanceType?: 'DR' | 'CR';
  isActive?: boolean;
}

export interface Supplier {
  id: string;
  code: string;
  name: string;
  tradeName?: string;
  companyOwner?: string; // Company Owner / Exporter Owner
  country: string;
  category: 
    | 'Overseas Manufacturer' 
    | 'Local Distributor' 
    | 'Freight Forwarder' 
    | 'C&F Agent'
    | 'Stone & Boulder Quarry'
    | 'River Boulder Exporter'
    | 'Stone Exporter'
    | 'Crushed Stone Manufacturer'
    | 'Fertilizer & Chemical Manufacturer'
    | string;
  supplierType?: 'Local' | 'Exporter';
  phoneCode?: string;
  mobile?: string;
  paymentTerms: string;
  customTermsDays?: string | number;
  currency?: 'BDT' | 'USD' | 'RS' | string;
  bankDetails: string;
  currentPayable: number;
  status: 'Active' | 'Inactive';
  isActive?: boolean;
  openingBalance?: number;
  balanceType?: 'CR' | 'DR';
  city?: string;
  phone?: string;
  contactPerson?: string;
  email?: string;
  address?: string;
  borderLandPort?: string;
}

export interface ItemCategoryRecord {
  id: string;
  name: string;
  description?: string;
  status: 'Active' | 'Inactive';
  isDefault?: boolean;
}

export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  category: string;
  hsCode?: string;
  uom: 'CFT' | 'Ton' | 'MT' | 'KG' | 'Pcs' | 'Cbm' | 'Drums' | string;
  minStock?: number;
  reorderPoint?: number;
  totalStock: number;
  avgUnitCost?: number; // In base currency (e.g., BDT or USD)
  sellingPrice?: number;
  stockByWarehouse?: { [warehouseId: string]: number };
  status?: 'Active' | 'Inactive';
  description?: string;
}

export interface Warehouse {
  id: string;
  code: string;
  name: string;
  location: string;
  type: 'Bonded Port Yard' | 'Central Warehouse' | 'Regional Hub' | 'Retail Depot';
  managerName?: string;
  contactPhone?: string;
  capacity?: string;
  status?: 'Active' | 'Inactive';
}

export interface SalesOrder {
  id: string;
  soNumber: string;
  customerId: string;
  customerName: string;
  orderDate: string;
  invoiceDate?: string;
  deliveryDate: string;
  paymentTerm: string;
  salesType: 'Paid' | 'Partial' | 'Due';
  paidAmount?: number;
  dueAmount?: number;
  paymentMethod?: 'Cash' | 'Cheque' | 'Bank Transfer' | 'Mobile Banking';
  items: {
    itemId: string;
    itemName: string;
    sku: string;
    quantity: number;
    uom?: string;
    unitPrice: number;
    discountPercent: number;
    totalAmount: number;
  }[];
  subtotal: number;
  taxAmount: number;
  grandTotal: number;
  status: 'Pending Approval' | 'Approved' | 'Partially Delivered' | 'Delivered' | 'Invoiced' | 'Cancelled';
  branch?: string; // 'Burimari Office' | 'Sonahat Office' | 'All Branches'
  cashierName?: string;
}

export interface SalesInvoice {
  id: string;
  invoiceNumber: string;
  soNumber?: string;
  customerId: string;
  customerName: string;
  invoiceDate: string;
  dueDate: string;
  branch?: string;
  cashierName?: string;
  // Transport & Stone Measurement
  truckNo?: string;
  driverName?: string;
  driverPhone?: string;
  measurementLength?: number; // ft (e.g. 18)
  measurementLengthInches?: number; // in (e.g. 2 or 2.5)
  measurementWidth?: number;  // ft (e.g. 6)
  measurementWidthInches?: number; // in (e.g. 9 or 9.5)
  measurementHeight?: number; // ft (e.g. 3) - original truck height ft
  measurementHeightInches?: number; // in (e.g. 9) - original truck height in
  measurementLengthEffective?: number; // e.g. 18.17 (or 18.21 for 2.5")
  measurementWidthEffective?: number;  // e.g. 6.75 (or 6.79 for 9.5")
  measurementHeightEffective?: number; // e.g. 3.75
  measurementCft?: number;    // CFT (cu ft)
  exactCft?: number;          // unrounded or 1 decimal (e.g. 450.1 or 459.9)
  billedCft?: number;         // rounded billing CFT (e.g. 451 or 460)
  formulaDisplay?: string;    // e.g. "18.17 × 6.75 × 3.67 = 451 CFT"
  // Down option (1 Inch Down, 2 Inch Down, 3 Inch Down)
  downInches?: number;        // 0, 1, 2, 3
  downLabel?: string;         // 'Full Load' | '1" Down' | '2" Down' | '3" Down'
  originalHeightFeet?: number;   // Original truck size before down
  originalHeightInches?: number; // Original truck size before down
  originalBilledCft?: number;    // Original full truck capacity (e.g. 460)
  effectiveHeightFeet?: number;  // Loaded height after down (e.g. 3)
  effectiveHeightInches?: number;// Loaded height after down (e.g. 8)
  netWeightMt?: number;
  weighbridgeSlipNo?: string;
  items: {
    itemId: string;
    itemName: string;
    quantity: number;
    uom?: string;
    unitPrice: number;
    amount: number;
  }[];
  totalAmount: number;
  paidAmount: number;
  cashPaidAmount?: number;
  advanceAdjusted?: number;
  adjustedAdvanceAmount?: number;
  sourceAdvanceVoucherIds?: string[];
  adjustmentVoucherId?: string;
  adjustmentVoucherNo?: string;
  warehouseId?: string;
  warehouseName?: string;
  negativeStockReason?: string;
  negativeStockApprovedBy?: string;
  stockDeducted?: boolean;
  dueAmount: number;
  paymentMethod?: 'Cash' | 'Cheque' | 'Bank Transfer' | 'Mobile Banking' | string;
  depositAccountId?: string;
  depositAccountName?: string;
  depositVoucherNo?: string;
  depositTransactionId?: string;
  salesVoucherNo?: string;
  salesTransactionId?: string;
  paymentRef?: string;
  moneyReceiptNumber?: string;
  status: 'Unpaid' | 'Partially Paid' | 'Paid' | 'Overdue';
}

export interface DeliveryChallan {
  id: string;
  challanNumber: string;
  soNumber: string;
  customerId: string;
  customerName: string;
  dispatchDate: string;
  vehicleNo: string;
  driverName: string;
  driverPhone?: string;
  measurementLength?: number;
  measurementWidth?: number;
  measurementHeight?: number;
  measurementCft?: number;
  warehouseId: string;
  items: {
    itemId: string;
    itemName: string;
    dispatchedQty: number;
    uom: string;
  }[];
  status: 'Dispatched' | 'In-Transit' | 'Delivered' | 'Returned';
}

export interface TruckMeasurementRecord {
  id: string;
  truckNo: string;
  driverName: string;
  driverPhone?: string;
  date: string;
  time?: string;
  challanNo: string;
  invoiceNo?: string;
  customerName: string;
  destination?: string;
  itemName: string; // e.g. 20MM Crushed Stone
  measurementLength: number; // Length in feet (e.g. 18)
  measurementLengthInches?: number; // Length inches (e.g. 2)
  measurementWidth: number;  // Width in feet (e.g. 6)
  measurementWidthInches?: number; // Width inches (e.g. 9)
  measurementHeight: number; // Height in feet (e.g. 3)
  measurementHeightInches?: number; // Height inches (e.g. 9)
  measurementLengthEffective?: number; // Effective feet (e.g. 18.17)
  measurementWidthEffective?: number;  // Effective feet (e.g. 6.75)
  measurementHeightEffective?: number; // Effective feet (e.g. 3.75)
  exactCft?: number;         // Unrounded 1 decimal CFT (e.g. 450.1 or 459.9)
  volumeCft: number;         // Billed rounded CFT (e.g. 451 or 460)
  formulaDisplay?: string;   // e.g. "18.17 × 6.75 × 3.67"
  // Down option (1 Inch Down, 2 Inch Down, 3 Inch Down)
  downInches?: number;        // 0, 1, 2, 3
  downLabel?: string;         // 'Full Load' | '1" Down' | '2" Down' | '3" Down'
  originalHeightFeet?: number;   // Original truck size before down
  originalHeightInches?: number; // Original truck size before down
  originalVolumeCft?: number;    // Original full truck capacity (e.g. 460)
  effectiveHeightFeet?: number;  // Loaded height after down (e.g. 3)
  effectiveHeightInches?: number;// Loaded height after down (e.g. 8)
  netWeightMt?: number;      // Metric tons (if weighed)
  ratePerCftOrMt: number;    // BDT rate
  uom: 'CFT' | 'MT' | string;
  totalAmount: number;       // BDT total
  status: 'Dispatched' | 'Delivered' | 'In-Transit';
  branch?: string;
  notes?: string;
}

export interface CustomerTransactionItem {
  itemId?: string;
  itemName: string;
  quantity: number;
  uom: string;
  unitPrice: number;
  total: number;
}

export interface CustomerTransaction {
  id: string;
  customerId: string;
  date: string;
  refNo: string;
  type: 'Opening' | 'Invoice' | 'Payment' | 'CreditNote' | 'Adjustment';
  description: string;
  memoNo?: string;
  challanNo?: string;
  truckNo?: string;
  measurementFormula?: string;
  downLabel?: string;
  salesPerson?: string; // e.g. "jubayer", "admin"
  site?: string;        // e.g. "Burimari", "Sonahat", loading site
  uom?: string;
  quantity?: number;
  unitPrice?: number;
  items?: CustomerTransactionItem[];
  shippingCost?: number;
  discountAmount?: number;
  totalInvoiceAmount?: number;
  debit: number;
  credit: number;
  balance?: number;
  paymentMethod?: string;
  chequeNo?: string;
  chequeDate?: string;
  bankName?: string;
  notes?: string;
}

export interface CustomerPayment {
  id: string;
  receiptNumber: string; // e.g. MR-2026-0041
  customerId: string;
  customerName: string;
  customerTradeName?: string;
  paymentDate: string;
  amount: number;
  paymentMethod: 'Cash' | 'Cheque' | 'Bank Transfer' | 'Mobile Banking';
  paymentType?: 'Invoice Payment' | 'Advance Payment';
  bankName?: string;
  branchName?: string;
  bankAccountId?: string;
  bankAccountName?: string;
  voucherNo?: string;
  transactionId?: string;
  chequeNo?: string;
  refNumber?: string;
  note?: string;
  invoiceNumber?: string;
  status: 'Cleared' | 'In-Deposit' | 'Pending';
  collectedBy?: string;
}

export interface SoilClaimRecord {
  id: string;
  lcNumber: string;
  claimMt: number;
  ratePerMtBdt: number;
  totalAmountBdt: number;
  date: string;
  note?: string;
}

export interface KhataPaymentRecord {
  id: string;
  lcNumber?: string;
  date: string;
  paidBy: string; // e.g. Rabbi, Jubayer (A/C 3609) IBBL
  paymentType: 'BDT' | 'IC_RS' | 'USD';
  amountBdt?: number;
  amountRs?: number;
  bataRate?: number; // e.g. 75.30% or 1.27
  convertedBdt?: number;
  status: 'Paid' | 'Received' | 'Adjusted';
  note?: string;
}

export interface DifferentialPaymentRecord {
  id: string;
  date: string;
  amount: number;
  currency: 'BDT' | 'INR' | 'USD';
  equivalentBdt?: number;
  paymentMethod: 'Hundi / Hawala' | 'Cash (BDT)' | 'Cash (INR)' | 'Local Agent / Bank' | 'Other';
  recipientAgent?: string;
  referenceNo?: string;
  notes?: string;
}

export interface LCRateBatch {
  id: string;
  batchName: string; // e.g. '১ম লট (৪০০ টন - পুরানো রেট)'
  quantity: number; // e.g. 400 MT
  uom?: string; // e.g. 'MT'
  actualRate: number; // e.g. $18.00 USD / MT (Agreed Commercial Rate)
  officialRate: number; // e.g. $14.00 USD / MT (Bank LC Rate)
  rateDifference: number; // actualRate - officialRate = $4.00
  totalCommercialAmount: number; // quantity * actualRate = $7,200
  totalOfficialAmount: number; // quantity * officialRate = $5,600
  differentialAmount: number; // quantity * rateDifference = $1,600
  notes?: string;
  date?: string;
  isAuto?: boolean;
}

export interface LCBankSettlement {
  id: string;
  settlementDate: string;
  bankName: string;
  branch?: string;
  debitAccount?: string;
  bankAccountId?: string;
  bankAccountName?: string;
  amountForeign: number; // Foreign currency settled by bank (e.g. $14,000 USD)
  currency: string; // USD / INR
  exchangeRate: number; // Bank conversion rate (e.g. 122.50)
  amountLocalBdt: number; // Foreign * exchangeRate
  marginAdjustedBdt?: number;
  netPaidBdt?: number;
  swiftRef?: string;
  voucherNumber?: string;
  voucherNo?: string;
  transactionId?: string;
  postedBy?: string | { uid: string; name: string; email?: string };
  postedAt?: string;
  notes?: string;
  status: 'Settled' | 'Processing' | 'Voided';
  voidReason?: string;
  voidedBy?: string;
  voidedAt?: string;
}

export interface LCHundiPayment {
  id: string;
  paymentDate: string;
  amountBdt: number; // বাংলা টাকা (BDT) e.g. ৳490,000
  hundiRateBdtToInr: number; // হুন্ডি কনভার্সন রেট (যেমন: ১.৪৫ টাকা = ১ রুপি)
  amountInr: number; // ইন্ডিয়ান রুপি / IC RS e.g. ₹337,931
  usdDifferentialEquivalent?: number; // Equivalent USD gap covered (e.g. $4,000)
  hundiBroker: string; // হুন্ডি এজেন্ট / মাধ্যম
  recipientParty: string; // ভারতীয়/ভুটানি এক্সপোর্টার
  paymentMode: 'Cash (BDT)' | 'Bank Transfer (BDT)' | 'Angadia / Hawala';
  paidFromAccountId?: string;
  paidFromAccountName?: string;
  receiptToken?: string;
  voucherNo?: string;
  transactionId?: string;
  postedBy?: string | { uid: string; name: string; email?: string };
  postedAt?: string;
  notes?: string;
  status?: 'Paid' | 'Voided';
  voidReason?: string;
  voidedBy?: string;
  voidedAt?: string;
}

export interface LetterOfCredit {
  id: string;
  lcNumber: string;
  bankReference: string;
  issuingBank: string;
  branch: string;
  supplierId: string;
  reopenLogs?: {
    reopenedAt: string;
    reopenedBy: string;
    reason: string;
  }[];
  supplierName: string;
  beneficiaryCountry: string; // Bhutan, India, China
  lcType: LCType;
  currency: 'USD' | 'EUR' | 'GBP' | 'CNY' | 'INR' | string;
  exchangeRate: number; // e.g. 118.50 or 122.50 to Local BDT
  fobAmount: number; // Foreign currency
  cfrAmount: number; // Foreign currency total (Official Bank LC Value)
  marginDepositPercent: number;
  marginAmountLocal: number;
  // Unified single margin fields (Fix 3 Requirement 1)
  marginPercent?: number;
  marginAmountBDT?: number;
  marginVoucherId?: string;
  marginVoucherNo?: string;
  marginReversalVoucherNo?: string;
  marginCorrectionReason?: string;
  normalizedLcNumber?: string;
  isVoided?: boolean;
  voidReason?: string;
  voidedAt?: string;
  voidedBy?: string;
  createdAt?: string;
  openingDate: string;
  shipmentExpiryDate: string;
  lcExpiryDate: string;
  maturityDate?: string;
  piNumber: string;
  boeNumber?: string;
  blNumber?: string;
  portOfLoading: string;
  portOfDischarge: string;
  status: LCStatus;
  
  // Custom stone/fertilizer import fields from user's Excel / PDF sheets
  companyOwner?: string; // e.g. 'Edu', 'Sanad', 'Munna Khan', 'Gawtom'
  importerName?: string; // e.g. 'Amir Hamza', 'Ariful Islam', 'Jubayer'
  borderLandPort?: string; // e.g. 'Burimari', 'Tamabil', 'Sonamasjid', 'Chittagong Port'
  boulderCategory?: 'Boulder Stone' | 'River Stone Boulder' | '20MM Crush Stone' | '20MM Crush/Black' | 'Torsha Stone' | 'Fertilizer (GA-3)' | 'Chemical Fertilizer' | string;
  originQuarryItem?: string; // e.g. 'Phuentsholing', 'Samtse', 'Torsha', 'River Stone Boulder', 'GA-3'
  
  // Dual-Pricing & Under-invoicing (Hundi/Unofficial settlement) fields
  quantity?: number; // Total Import Quantity (e.g. 1000)
  uom?: string; // 'MT' | 'Ton' | 'CFT'
  officialLcRate?: number; // Official Bank LC Unit Rate (e.g. $14 / MT or ₹1150)
  actualRate?: number; // Actual Agreed Commercial Unit Rate (e.g. $18 / MT or ₹1480)
  contractRateUsd?: number; // Actual Invoice Rate USD / Commercial Rate (e.g. $18)
  lcBankRateUsd?: number; // LC Application Rate USD / Bank Rate (e.g. $14)
  rateDifference?: number; // actualRate - officialLcRate (e.g. $4 / MT)
  
  officialLcTotal?: number; // Qty * officialLcRate = cfrAmount ($14,000)
  actualTotalAmount?: number; // Qty * actualRate ($18,000)
  differentialAmount?: number; // Qty * rateDifference ($4,000 Hundi/Unofficial Gap)
  differentialAmountBdt?: number; // Differential in BDT (e.g. ৳490,000)
  differentialAmountInr?: number; // Differential in INR
  differentialSettledAmount?: number; // Total settled so far
  differentialSettlementStatus?: 'Unsettled' | 'Partially Settled' | 'Fully Settled';
  differentialPayments?: DifferentialPaymentRecord[];
  rateBatches?: LCRateBatch[];
  bankSettlements?: LCBankSettlement[];
  hundiPayments?: LCHundiPayment[];
  
  receivedQtyMt?: number; // Received MT weighed at border weighbridge
  receivedQuantity?: number; // Total MT received so far at border
  remainingQuantity?: number; // Total MT remaining to be received
  receivings?: StockReceivingRecord[]; // Daily border receiving logs
  totalBillUsd?: number; // Actual bill based on Received MT * LC/Invoice rate
  rateBdt?: number; // Exchange rate applied in balance sheet (e.g. 124)
  usdBalance?: number; // Total USD - LC Rate USD
  bdtBalanceAmount?: number; // Balance in BDT
  remarkStatus?: 'LC Closed' | 'On Loading' | 'Not Started' | 'In Transit';
  soilClaims?: SoilClaimRecord[];
  khataPayments?: KhataPaymentRecord[];

  // Over-receipt & Billing Settings
  bankBillForExtraQty?: 'follow_received' | 'cap_at_lc'; // Default: 'follow_received'
  allowedTolerancePercent?: number; // Default: 5%
  
  // Short Receiving Completion (Admin)
  isReceivingCompleted?: boolean;
  receivingCompletedReason?: string;
  receivingCompletedBy?: string;
  receivingCompletedAt?: string;

  // Audit Logs
  auditLogs?: {
    id: string;
    timestamp: string;
    user: string;
    action: string;
    details: string;
  }[];

  items: {
    itemId: string;
    itemName: string;
    hsCode: string;
    quantity: number;
    uom: string;
    unitPriceForeign: number;
    totalForeign: number;
    assessmentValueUnit?: number;
    dutyRatePercent?: number;
    calculatedLandedCost?: number;
  }[];
  expenses: {
    id: string;
    expenseType: string;
    amountLocal: number;
    paidTo: string;
    status: 'Estimated' | 'Billed' | 'Invoiced' | 'Paid' | 'Voided';
    voucherNo?: string;
    lcId?: string;
    paymentDate?: string;
    paidFromAccountId?: string;
    paidFromAccountName?: string;
    paymentMethod?: string;
    referenceNo?: string;
    transactionId?: string;
    postedBy?: {
      uid: string;
      name: string;
      email?: string;
    } | string;
    postedAt?: string;
  }[];

  // Bank Cash Margin Voucher & Payment Tracking
  marginPaidFromAccountId?: string;
  marginPaidFromAccountName?: string;
  marginPaymentDate?: string;
  marginTransactionId?: string;
  marginPostedAt?: string;
  marginAdjustedTotal?: number;
  marginStatus?: 'posted' | 'unposted' | 'accounted_earlier' | 'external';
  marginManualReason?: string;
  marginPostedBy?: { uid: string; name: string } | string;
  openingChargesBdt?: number;
  openingChargeHeadId?: string;
  openingChargeHeadName?: string;

  // LC Cancellation
  isCancelled?: boolean;
  cancelledAt?: string;
  cancelledBy?: { uid: string; name: string } | string;
  cancelReason?: string;
  cancelVoucherNo?: string;
  cancelTransactionId?: string;
}

export interface DirectPurchaseInvoice {
  id: string;
  invoiceNumber: string; // e.g. DPI-2026-0112
  challanNumber: string; // Delivery / Port Challan e.g. CH-88912
  supplierBillNumber?: string; // Vendor's invoice/bill no
  supplierId: string;
  supplierName: string;
  lcNumber?: string; // Linked LC (if import consignment)
  invoiceDate: string;
  dueDate: string;
  currency: 'BDT' | 'USD';
  items: {
    itemId: string;
    itemName: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
    uom?: string;
  }[];
  subTotal: number;
  taxVatRate: number; // e.g. 5%
  taxVatAmount: number;
  discountAmount?: number;
  grandTotal: number;
  paidAmount: number;
  dueAmount: number;
  paymentType?: 'Due 30 Days' | 'Cash Only' | 'Payment 10 Days' | 'Partial Payment';
  paymentMethod: 'Cash' | 'Bank Transfer / Cheque' | 'Credit' | 'LC Settlement' | string;
  paymentStatus: 'Paid' | 'Partial' | 'Unpaid' | 'Voided';
  warehouseName: string; // Receiving Yard / Depot
  branch?: string; // 'Burimari Office' | 'Sonahat Office' | 'All Branches'
  truckNo?: string; // e.g. Truck / Vehicle Number
  createdBy?: string;
  status: 'Draft' | 'Posted & In Stock' | 'Payment Pending' | 'Closed' | 'Voided';
  notes?: string;
  // Accounting voucher & account links
  purchaseVoucherId?: string;
  purchaseVoucherNumber?: string;
  paymentVoucherId?: string;
  paymentVoucherNumber?: string;
  paidFromAccountId?: string;
  paidFromAccountName?: string;
  // Void & reversal audit metadata
  isVoided?: boolean;
  voidReason?: string;
  voidedAt?: string;
  voidedBy?: string;
  reversalVoucherNo?: string;
}

export interface SupplierPaymentRecord {
  id: string;
  paymentNumber: string; // e.g. SP-2026-0081
  paymentDate: string; // YYYY-MM-DD
  supplierId: string;
  supplierName: string;
  invoiceId?: string;
  invoiceNumber?: string;
  amount: number;
  paymentMethod: 'Cash' | 'Bank Transfer' | 'Cheque' | 'LC Settlement';
  bankAccountId?: string;
  bankName?: string;
  chequeNumber?: string;
  chequeDate?: string;
  voucherId?: string; // Linked AccountTransaction ID
  voucherNumber?: string; // Debit Voucher / Money Receipt Ref
  notes?: string;
  branch?: string;
  status?: 'Cleared' | 'Pending' | 'Bounced' | 'Voided';
  recordedBy?: string;
  // Void & reversal audit metadata
  isVoided?: boolean;
  voidReason?: string;
  voidedAt?: string;
  voidedBy?: string;
  reversalVoucherNo?: string;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierId: string;
  supplierName: string;
  lcNumber?: string;
  poDate: string;
  expectedDelivery: string;
  currency: string;
  items: {
    itemId: string;
    itemName: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
  }[];
  totalAmount: number;
  status: 'Draft' | 'Submitted' | 'Approved' | 'GRN Received' | 'Closed';
}

export interface GRN {
  id: string;
  grnNumber: string;
  poNumber: string;
  lcNumber?: string;
  supplierName: string;
  receivedDate: string;
  warehouseId: string;
  warehouseName: string;
  containerNo?: string;
  challanNo: string;
  items: {
    itemId: string;
    itemName: string;
    orderedQty: number;
    receivedQty: number;
    acceptedQty: number;
    rejectedQty: number;
    baseUnitCost: number;
    landedUnitCost: number;
    totalLandedCost: number;
  }[];
  qualityCheckStatus: 'Passed' | 'Conditional Approval' | 'Rejected';
  status: 'Draft' | 'Stock Posted' | 'Cost Apportioned';
}

export interface AccountCOA {
  code: string;
  name: string;
  category: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  subCategory: string;
  balance: number;
  normalBalance: 'Debit' | 'Credit';
  isParent: boolean;
}

export interface JournalVoucher {
  id: string;
  voucherNumber: string;
  voucherType: 'JV' | 'PV' | 'RV' | 'Contra';
  voucherDate: string;
  referenceType?: 'LC' | 'Sales' | 'Purchase' | 'Payroll' | 'Manual' | 'POS';
  referenceNo?: string;
  narration: string;
  items: {
    accountCode: string;
    accountName: string;
    debit: number;
    credit: number;
    costCenter?: string;
  }[];
  totalDebit: number;
  totalCredit: number;
  postedBy: string;
  status: 'Draft' | 'Pending Review' | 'Approved & Posted';
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  branch: string;
  accountType: 'Current' | 'Overdraft/LTR' | 'Foreign Currency (USD)' | 'Margin Deposit' | 'Savings' | 'Petty Cash' | 'POS Cash';
  ledgerBalance: number;
  statementBalance: number;
  currency: string;
  type?: 'cash' | 'bank';
  accountCategory?: 'Bank' | 'Cash';
  linkedPosLocation?: string;
  coaCode?: string;
  custodianName?: string;
  routingNumber?: string;
}

export interface ChequeRecord {
  id: string;
  chequeNumber: string;
  bankName: string;
  partyName: string;
  type: 'Inward (Received)' | 'Outward (Issued)';
  amount: number;
  chequeDate: string;
  maturityDate: string;
  status: 'In-Hand' | 'Deposited' | 'Cleared' | 'Dishonored' | 'Cancelled';
}

export interface Employee {
  id: string;
  empCode: string;
  name: string;
  department: 'Management' | 'Sales & Distribution' | 'Import & Logistics' | 'Accounts & Finance' | 'Warehouse' | 'HR & Admin';
  designation: string;
  joiningDate: string;
  branch?: string;
  phone?: string;
  basicSalary: number;
  houseRent: number;
  conveyance: number;
  medicalAllowance: number;
  grossSalary: number;
  pfDeduction: number;
  taxDeduction: number;
  bankAccount: string;
  status: 'Active' | 'On Leave' | 'Probation';
}

export interface SalarySheetItem {
  empId: string;
  empCode: string;
  name: string;
  department: string;
  designation: string;
  grossSalary: number;
  overtimeHours: number;
  overtimePay: number;
  bonus: number;
  totalAdditions: number;
  pfDeduction: number;
  taxDeduction: number;
  advanceSalaryDeduction: number;
  totalDeductions: number;
  netPayable: number;
  status: 'Calculated' | 'Approved' | 'Disbursed';
}

export interface StockTransfer {
  id: string;
  transferNumber: string;
  transferDate: string;
  sourceWarehouseId: string;
  sourceWarehouseName: string;
  destWarehouseId: string;
  destWarehouseName: string;
  itemId: string;
  itemName: string;
  sku: string;
  quantity: number;
  uom: string;
  status: 'Initiated' | 'In-Transit' | 'Received & Reconciled';
  trackingVehicle?: string;
}

export interface StockAdjustment {
  id: string;
  adjustmentNumber: string;
  adjustmentDate: string;
  warehouseId: string;
  warehouseName: string;
  itemId: string;
  itemName: string;
  type: 'Damage' | 'Loss / Shrinkage' | 'Surplus' | 'Annual Audit Reconcile';
  quantity: number; // positive for surplus, negative for loss
  unitCost: number;
  totalValue: number;
  reason: string;
  approvedBy: string;
}

export interface RBACRole {
  roleName: string;
  description: string;
  usersAssigned: number;
  permissions: {
    module: string;
    canRead: boolean;
    canCreate: boolean;
    canUpdate: boolean;
    canDelete: boolean;
    canApprove: boolean;
  }[];
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  user: string;
  ipAddress: string;
  action: 'CREATE' | 'UPDATE' | 'APPROVE' | 'DELETE' | 'LOGIN' | 'RECONCILE';
  module: string;
  details: string;
}

export type InventorySubTab = 
  | 'items'
  | 'locations'
  | 'stock_receivings'
  | 'stock_transfers'
  | 'sales_dispatches'
  | 'stock_adjustments'
  | 'inventory_ledgers'
  | 'inventory_movement'
  | 'stone_crushing';

export interface DailyLCExpenseBreakdown {
  customsTaxDuty: number;      // Tax & Customs Duty
  portHandlingBill: number;    // Port Handling Bill
  laborLoadingUnloading: number; // Loading, Unloading & Labor
  weighbridgeScaleFee: number; // Weighbridge Scale Fee
  cfAgentClearing: number;     // C&F Agent Clearing Cost
  localCarriageMisc: number;   // Local Carriage & Misc
  totalDailyExpense: number;   // Total Daily Expense
  expenseVoucherNo?: string;   // Expense Voucher No
  expenseStatus?: 'Paid' | 'Invoiced' | 'Estimated';
  paymentMethod?: 'Cash' | 'Bank Account' | 'C&F Ledger' | 'Mobile Banking';
}

export interface StockReceivingRecord {
  id: string;
  grnNo: string;
  date: string;
  time?: string;
  supplierId: string;
  supplierName: string;
  lcNumber?: string;
  portOrBorder: string;
  vehicleNo: string;
  truckCount?: number;
  driverName?: string;
  driverPhone?: string;
  weighbridgeSlipNo: string;
  grossWeightMt: number;
  tareWeightMt: number;
  netWeightMt: number;
  itemId: string;
  itemName: string;
  receivedQty: number; // MT or CFT
  uom: string;
  cftEquivalent?: number;
  unitCostBdt: number;
  totalCostBdt: number;
  warehouseId: string;
  warehouseName: string;
  dailyExpenses?: DailyLCExpenseBreakdown;
  remarks?: string;
  receivedBy: string;
  status: 'Received & Stock Added' | 'Pending Inspection';
}

export interface SalesDispatchRecord {
  id: string;
  challanNo: string;
  dispatchDate: string;
  invoiceNo?: string;
  soNumber?: string;
  customerId: string;
  customerName: string;
  destination: string;
  vehicleNo: string;
  driverName: string;
  driverPhone?: string;
  measurementLength?: number;
  measurementWidth?: number;
  measurementHeight?: number;
  measurementCft?: number;
  netWeightMt?: number;
  weighbridgeSlipNo?: string;
  itemId: string;
  itemName: string;
  dispatchedQty: number;
  uom: string;
  warehouseId: string;
  warehouseName: string;
  dispatchedBy: string;
  status: 'Dispatched' | 'Delivered' | 'Returned';
}

export interface InventoryLedgerEntry {
  id: string;
  date: string;
  time?: string;
  itemId: string;
  itemName: string;
  sku?: string;
  warehouseId: string;
  warehouseName: string;
  txnType: 'GRN Receiving' | 'Sales Dispatch' | 'Transfer In' | 'Transfer Out' | 'Crushing Input' | 'Crushing Output' | 'Stock Adjustment';
  refNo: string;
  inQty: number;
  outQty: number;
  balanceQty: number;
  uom: string;
  unitRate: number;
  balanceValue: number;
  partyOrVehicle?: string;
  notes?: string;
}

export interface StoneCrushingConversionBatch {
  id: string;
  batchNo: string;
  date: string;
  plantWarehouseId: string;
  plantWarehouseName: string;
  inputBoulderItemId: string;
  inputBoulderItemName: string;
  inputBoulderQtyTon: number;
  inputBoulderQtyMt?: number; // For backward compatibility
  inputUnitCostBdt: number;
  totalInputCostBdt: number;
  crushingExpenseBdt: number;
  cftPerTonRatio?: number;
  outputs: {
    itemId: string;
    itemName: string;
    fractionSize: string;
    cftPerTon?: number;
    quantityCft: number;
    quantityMt?: number;
    percentage: number;
    allocatedUnitCostBdt: number;
    totalValueBdt: number;
  }[];
  totalOutputQtyCft: number;
  totalOutputQtyMt?: number;
  dustWastageQtyCft: number;
  dustWastageQtyMt?: number;
  dustWastagePercent: number;
  lossVarianceCft?: number;
  lossVarianceMt?: number;
  operatorName: string;
  status: 'Completed & Posted' | 'Draft';
  remarks?: string;
}

export type FiscalYearStatus = 'Active' | 'Closed' | 'Upcoming';

export interface FiscalYear {
  id: string;
  name: string;
  bengaliName?: string;
  startDate: string;
  endDate: string;
  status: FiscalYearStatus;
  isDefault: boolean;
  description?: string;
  closedDate?: string;
  closedBy?: string;
  totalVouchers?: number;
  totalTransactions?: number;
}
