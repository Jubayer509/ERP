export type PaymentSubType = 
  | 'Expense / General Payment'
  | 'Pay to Customer'
  | 'Pay to Supplier'
  | 'LC Margin Deposit'
  | 'LC Opening Charges'
  | 'LC Logistics Payment'
  | 'Payment Reversal';

export type DepositSubType = 
  | 'General Deposit'
  | 'Deposit from Customer'
  | 'Deposit from Supplier'
  | 'LC Margin Reversal'
  | 'Deposit Reversal';

export type TransactionType = 'PAYMENT' | 'DEPOSIT' | 'CONTRA' | 'JOURNAL';

export type PaymentMethod = 
  | 'Cash' 
  | 'Bank Transfer' 
  | 'Cheque' 
  | 'Mobile Banking' 
  | 'Deposit Slip' 
  | 'BEFTN / RTGS' 
  | 'Cheque Transfer' 
  | 'Cash Deposit / Float' 
  | 'Online Banking / App' 
  | 'Online';

export type AccountHeadType = 'Expense' | 'Income' | 'Other';

export interface AccountHead {
  id: string;
  code?: string;
  name: string;
  nameEn: string;
  nameBn: string;
  type: AccountHeadType;
  description?: string;
  active: boolean;
  isSystem?: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface TransactionEditLog {
  timestamp: string;
  user: {
    uid: string;
    name: string;
    email?: string;
  };
  oldData: Partial<AccountTransaction>;
  newData: Partial<AccountTransaction>;
  reason?: string;
}

export interface AccountTransaction {
  id: string;
  voucherNo: string; // PV-0001, DV-0001
  transactionType: TransactionType;
  subType: PaymentSubType | DepositSubType;
  date: string; // YYYY-MM-DD
  amount: number; // > 0

  // For General Expense / General Deposit
  accountHeadId?: string;
  accountHeadName?: string;
  accountHeadCode?: string;

  // For Customer / Supplier
  partyType?: 'Customer' | 'Supplier' | 'None';
  partyId?: string;
  partyName?: string;
  partyCode?: string;
  partyPhone?: string;
  partyBalanceBefore?: number;
  partyBalanceAfter?: number;

  // Cash / Bank Account
  bankAccountId: string;
  bankAccountName: string;
  bankAccountNumber?: string;
  paymentMethod: PaymentMethod;
  referenceNo?: string;
  note?: string;
  costCenter?: string;
  multiLines?: { accountCode: string; particulars: string; amount: number }[];
  branch: string;

  // LC Expense linkage for atomic persistence and self-healing
  lcId?: string;
  lcNumber?: string;
  lcExpenseId?: string;
  lcExpenseHead?: string;
  lcExpenseRecord?: {
    id: string;
    lcId: string;
    lcNumber?: string;
    expenseType: string;
    amountLocal: number;
    paidTo: string;
    status: 'Paid' | 'Billed' | 'Invoiced' | 'Estimated' | 'Voided';
    voucherNo?: string;
    transactionId?: string;
    paymentDate?: string;
    paidFromAccountId?: string;
    paidFromAccountName?: string;
    paymentMethod?: string;
    referenceNo?: string;
    accountHeadId?: string;
    accountHeadCode?: string;
    capitalizedToInventory?: boolean;
    postedBy?: {
      uid: string;
      name: string;
      email?: string;
    } | string;
    postedAt?: string;
  };

  // Status & Safety (Soft-Delete / Void only)
  status: 'active' | 'voided';
  voidReason?: string;
  voidedBy?: {
    uid: string;
    name: string;
  };
  voidedAt?: string;
  reversalVoucherNo?: string;
  idempotencyKey?: string;

  // Audit
  createdBy: {
    uid: string;
    name: string;
    email?: string;
  };
  createdAt: string;
  updatedBy?: {
    uid: string;
    name: string;
  };
  updatedAt?: string;
  editHistory?: TransactionEditLog[];
}

export interface AccountLedgerEntry {
  id: string;
  transactionId: string;
  voucherNo: string;
  date: string;
  accountType: 'Bank/Cash' | 'Customer' | 'Supplier' | 'AccountHead';
  accountId: string;
  accountName: string;
  description: string;
  debit: number;
  credit: number;
  runningBalance: number;
  branch: string;
  status: 'active' | 'voided';
  createdAt: string;
}

export interface VoucherCounter {
  id: string;
  current: number;
  prefix: string;
  updatedAt: string;
}
