import React, { useState, useEffect, useRef } from 'react';
import { ModuleTab, InventorySubTab } from './types/erp';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard';
import { SalesModule } from './components/sales/SalesModule';
import { PurchaseModule } from './components/purchase/PurchaseModule';
import { InventoryModule } from './components/inventory/InventoryModule';
import { AccountsModule } from './components/accounts/AccountsModule';
import { HRMModule } from './components/hr/HRMModule';
import { AdminModule } from './components/admin/AdminModule';
import { ReportsModule } from './components/reports/ReportsModule';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginPage } from './components/auth/LoginPage';
import { InactivitySessionManager } from './components/auth/InactivitySessionManager';
import { ForcePasswordChangeModal } from './components/auth/ForcePasswordChangeModal';

function MainErpShell() {
  const { currentUser, isAuthenticated } = useAuth();
  const [currentTab, setCurrentTab] = useState<ModuleTab>(() => {
    const saved = sessionStorage.getItem('starline_active_tab') as ModuleTab | null;
    return saved || 'dashboard';
  });
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [salesSubTab, setSalesSubTab] = useState<string>('overview');
  const [purchaseSubTab, setPurchaseSubTab] = useState<string>('overview');
  const [inventorySubTab, setInventorySubTab] = useState<InventorySubTab>('items');
  const [reportsSubTab, setReportsSubTab] = useState<string>('sales_reports');
  const [accountsSubTab, setAccountsSubTab] = useState<string>('payment');
  const [hrmSubTab, setHrmSubTab] = useState<string>('employees');
  const [adminSubTab, setAdminSubTab] = useState<string>('users');
  const [branch, setBranch] = useState<string>('All Branches');
  const [currency, setCurrency] = useState<string>('BDT');
  const [moduleKey, setModuleKey] = useState<number>(0);
  const mainScrollRef = useRef<HTMLElement>(null);

  // Reset all sub-tabs to default when navigating between modules
  const resetAllSubTabs = () => {
    setSalesSubTab('overview');
    setPurchaseSubTab('overview');
    setInventorySubTab('items');
    setReportsSubTab('sales_reports');
    setAccountsSubTab('payment');
    setHrmSubTab('employees');
    setAdminSubTab('users');
  };

  const handleSelectTab = (newTab: ModuleTab) => {
    setIsMobileNavOpen(false);
    if (newTab !== currentTab) {
      resetAllSubTabs();
      if (newTab === 'lc') {
        setPurchaseSubTab('lc_status_summary');
      }
      setModuleKey(prev => prev + 1);
      setCurrentTab(newTab);
      sessionStorage.setItem('starline_active_tab', newTab);
    }
  };

  // Scroll the main content area back to the top when navigating to another page/sub-tab
  useEffect(() => {
    if (mainScrollRef.current) {
      mainScrollRef.current.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
    }
  }, [
    currentTab,
    salesSubTab,
    purchaseSubTab,
    inventorySubTab,
    reportsSubTab,
    accountsSubTab,
    hrmSubTab,
    adminSubTab,
  ]);

  // Sync user's assigned branch upon login / role switch (do NOT redirect away from dashboard)
  useEffect(() => {
    if (currentUser?.branch) {
      setBranch(currentUser.branch);
    }
  }, [currentUser?.uid, currentUser?.branch]);

  // Ensure fresh login always lands on dashboard if session was fresh
  useEffect(() => {
    if (isAuthenticated) {
      const saved = sessionStorage.getItem('starline_active_tab') as ModuleTab | null;
      if (!saved) {
        setCurrentTab('dashboard');
        sessionStorage.setItem('starline_active_tab', 'dashboard');
      }
    }
  }, [isAuthenticated]);

  if (!isAuthenticated || !currentUser) {
    return (
      <div className="h-screen h-[100dvh] overflow-y-auto">
        <LoginPage />
      </div>
    );
  }

  const renderActiveModule = () => {
    switch (currentTab) {
      case 'dashboard':
        return <ExecutiveDashboard onNavigate={handleSelectTab} currency={currency} />;
      case 'pos':
      case 'sales':
        return (
          <SalesModule 
            key={`sales-${moduleKey}`}
            activeSubTab={salesSubTab as any} 
            onSubTabChange={(tab) => setSalesSubTab(tab)} 
          />
        );
      case 'purchase':
        return (
          <PurchaseModule 
            key={`purchase-${moduleKey}`}
            activeSubTab={(purchaseSubTab && !purchaseSubTab.startsWith('lc_') ? purchaseSubTab : 'overview') as any}
            onSubTabChange={(tab) => setPurchaseSubTab(tab)}
            currentBranch={branch} 
          />
        );
      case 'lc':
        return (
          <PurchaseModule 
            key={`lc-${moduleKey}`}
            initialTab={(purchaseSubTab && purchaseSubTab.startsWith('lc_') ? purchaseSubTab : 'lc_status_summary') as any} 
            activeSubTab={(purchaseSubTab && purchaseSubTab.startsWith('lc_') ? purchaseSubTab : 'lc_status_summary') as any}
            onSubTabChange={(tab) => setPurchaseSubTab(tab)}
            currentBranch={branch} 
          />
        );
      case 'inventory':
        return (
          <InventoryModule 
            key={`inventory-${moduleKey}-${inventorySubTab}`}
            initialSubTab={inventorySubTab}
            activeSubTab={inventorySubTab}
            onSubTabChange={setInventorySubTab}
            currentBranch={branch} 
            currency={currency} 
          />
        );
      case 'accounts':
        return (
          <AccountsModule 
            key={`accounts-${moduleKey}`}
            currency={currency}
            activeSubTab={accountsSubTab as any}
            onSubTabChange={(tab) => setAccountsSubTab(tab)}
          />
        );
      case 'hrm':
      case 'hr':
        return (
          <HRMModule 
            key={`hrm-${moduleKey}`}
            activeSubTab={hrmSubTab as any}
            onSubTabChange={(tab) => setHrmSubTab(tab)}
            currentBranch={branch} 
            currency={currency} 
          />
        );
      case 'reports':
        return (
          <ReportsModule 
            key={`reports-${moduleKey}`}
            currentBranch={branch} 
            currency={currency} 
            initialReport={reportsSubTab as any}
            activeSubTab={reportsSubTab as any}
            onSubTabChange={(tab) => setReportsSubTab(tab)}
            onNavigateTab={handleSelectTab}
          />
        );
      case 'truck_report':
        return (
          <ReportsModule 
            key={`truck-report-${moduleKey}`}
            currentBranch={branch} 
            currency={currency} 
            initialReport="sales_reports"
            activeSubTab="sales_reports"
            onSubTabChange={(tab) => setReportsSubTab(tab)}
            onNavigateTab={handleSelectTab}
          />
        );
      case 'admin':
        return (
          <AdminModule 
            key={`admin-${moduleKey}`}
            activeSubTab={adminSubTab as any}
            onSubTabChange={(tab) => setAdminSubTab(tab)}
          />
        );
      default:
        return <ExecutiveDashboard onNavigate={handleSelectTab} currency={currency} />;
    }
  };

  return (
    <div className="erp-app-shell flex flex-col bg-[#dfe3e8] text-slate-900 p-3 sm:p-5 lg:p-6 font-sans antialiased selection:bg-[#def645] selection:text-slate-950">
      <div className="erp-shell-inner max-w-[1720px] w-full mx-auto flex-1 min-h-0 h-full flex flex-col md:flex-row gap-5 items-stretch">
        {/* Left Sidebar Navigation */}
        <Sidebar 
          currentTab={currentTab} 
          onSelectTab={handleSelectTab}
          activeSalesSubTab={salesSubTab}
          onSelectSalesSubTab={(sub) => {
            if (currentTab !== 'sales') {
              resetAllSubTabs();
              setModuleKey(prev => prev + 1);
              setCurrentTab('sales');
            }
            setSalesSubTab(sub);
          }}
          activePurchaseSubTab={purchaseSubTab}
          onSelectPurchaseSubTab={(sub) => {
            const targetModule = sub.startsWith('lc_') ? 'lc' : 'purchase';
            if (currentTab !== targetModule) {
              resetAllSubTabs();
              setModuleKey(prev => prev + 1);
              setCurrentTab(targetModule);
            }
            setPurchaseSubTab(sub);
          }}
          activeInventorySubTab={inventorySubTab}
          onSelectInventorySubTab={(subTab) => {
            if (currentTab !== 'inventory') {
              resetAllSubTabs();
              setModuleKey(prev => prev + 1);
              setCurrentTab('inventory');
            }
            setInventorySubTab(subTab);
          }}
          activeReportsSubTab={reportsSubTab}
          onSelectReportsSubTab={(sub) => {
            if (currentTab !== 'reports' && currentTab !== 'truck_report') {
              resetAllSubTabs();
              setModuleKey(prev => prev + 1);
              setCurrentTab('reports');
            }
            setReportsSubTab(sub);
          }}
          activeAccountsSubTab={accountsSubTab}
          onSelectAccountsSubTab={(sub) => {
            if (currentTab !== 'accounts') {
              resetAllSubTabs();
              setModuleKey(prev => prev + 1);
              setCurrentTab('accounts');
            }
            setAccountsSubTab(sub);
          }}
          activeHrmSubTab={hrmSubTab}
          onSelectHrmSubTab={(sub) => {
            if (currentTab !== 'hrm' && currentTab !== 'hr') {
              resetAllSubTabs();
              setModuleKey(prev => prev + 1);
              setCurrentTab('hrm');
            }
            setHrmSubTab(sub);
          }}
          activeAdminSubTab={adminSubTab}
          onSelectAdminSubTab={(sub) => {
            if (currentTab !== 'admin') {
              resetAllSubTabs();
              setModuleKey(prev => prev + 1);
              setCurrentTab('admin');
            }
            setAdminSubTab(sub);
          }}
          isMobileOpen={isMobileNavOpen}
          onCloseMobile={() => setIsMobileNavOpen(false)}
        />

        {/* Right Main Content Area */}
        <div className="erp-main-column flex-1 min-w-0 min-h-0 h-full w-full flex flex-col">
          <div className="erp-header-wrapper shrink-0 relative z-30">
            <Header
              currentTab={currentTab}
              onSelectTab={handleSelectTab}
              branch={branch}
              setBranch={setBranch}
              currency={currency}
              setCurrency={setCurrency}
              onToggleMobileMenu={() => setIsMobileNavOpen(prev => !prev)}
            />
          </div>

          <main
            ref={mainScrollRef}
            className={`erp-main-scroll flex-1 min-h-0 h-full overflow-x-hidden pr-0.5 animate-in fade-in duration-200 ${
              isMobileNavOpen ? 'overflow-y-hidden md:overflow-y-auto' : 'overflow-y-auto'
            }`}
          >
            {renderActiveModule()}
          </main>
        </div>
      </div>

      {/* Global Inactivity Auto-Logout Manager (60m inactivity, 1m warning) */}
      <InactivitySessionManager />

      {/* Mandatory First-Login Password Change Modal */}
      <ForcePasswordChangeModal />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainErpShell />
    </AuthProvider>
  );
}
