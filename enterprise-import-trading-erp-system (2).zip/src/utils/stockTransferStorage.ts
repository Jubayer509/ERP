import { StockTransfer } from '../types/erp';

const TRANSFERS_STORAGE_KEY = 'tradecore_stock_transfers_v1';
export const TRANSFERS_EVENT_NAME = 'tradecore_stock_transfers_changed';

export const INITIAL_STOCK_TRANSFERS: StockTransfer[] = [
  {
    id: 'tr-stn-01',
    transferNumber: 'TR-2026-0045',
    transferDate: '2026-10-02',
    sourceWarehouseId: 'wh-burimari-crush',
    sourceWarehouseName: 'Burimari Crushing Yard',
    destWarehouseId: 'wh-sonahat-border',
    destWarehouseName: 'Sonahat Land Port Yard',
    itemId: 'item-stn-03',
    itemName: '3/4" Down / 20MM Crush Stone',
    sku: 'STN-CRUSH-20MM',
    quantity: 2800,
    uom: 'CFT',
    status: 'In-Transit',
    trackingVehicle: 'Dhaka Metro-Ta 15-8974 (Driver: Rafiqul)'
  },
  {
    id: 'tr-stn-02',
    transferNumber: 'TR-2026-0046',
    transferDate: '2026-09-29',
    sourceWarehouseId: 'wh-burimari-crush',
    sourceWarehouseName: 'Burimari Crushing Yard',
    destWarehouseId: 'wh-dhk',
    destWarehouseName: 'Dhaka Central Distribution Center',
    itemId: 'item-stn-07',
    itemName: '3/4" Crush Stone',
    sku: 'STN-CRUSH-3-4',
    quantity: 1500,
    uom: 'CFT',
    status: 'Received & Reconciled',
    trackingVehicle: 'Dhaka Metro-U 14-9921 (Driver: Selim)'
  },
  {
    id: 'tr-01',
    transferNumber: 'TR-2026-0044',
    transferDate: '2026-09-18',
    sourceWarehouseId: 'wh-cgp',
    sourceWarehouseName: 'Chittagong Port Bonded Yard',
    destWarehouseId: 'wh-dhk',
    destWarehouseName: 'Dhaka Central Distribution Center',
    itemId: 'item-301',
    itemName: 'Hot Rolled Prime Steel Coils',
    sku: 'STL-HR-COIL-01',
    quantity: 60,
    uom: 'MT',
    status: 'In-Transit',
    trackingVehicle: 'Prime Mover Trailer CTG-DA-1102'
  },
  {
    id: 'tr-stn-03',
    transferNumber: 'TR-2026-0042',
    transferDate: '2026-09-12',
    sourceWarehouseId: 'wh-sonahat-border',
    sourceWarehouseName: 'Sonahat Land Port Yard',
    destWarehouseId: 'wh-burimari-crush',
    destWarehouseName: 'Burimari Crushing Yard',
    itemId: 'item-stn-01',
    itemName: 'Boulder Stone - Phuentsholing Quarry',
    sku: 'STN-BOULDER-PHU',
    quantity: 45,
    uom: 'Ton',
    status: 'Received & Reconciled',
    trackingVehicle: 'Bogura-Ta 11-4512 (Driver: Kalam)'
  }
];

export function getStockTransfers(): StockTransfer[] {
  try {
    const raw = localStorage.getItem(TRANSFERS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load stock transfers from storage', err);
  }
  return INITIAL_STOCK_TRANSFERS;
}

export function saveStockTransfers(transfers: StockTransfer[]): void {
  try {
    localStorage.setItem(TRANSFERS_STORAGE_KEY, JSON.stringify(transfers));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(TRANSFERS_EVENT_NAME, { detail: transfers }));
    }
  } catch (err) {
    console.error('Failed to save stock transfers to storage', err);
  }
}

export function addStockTransfer(transfer: StockTransfer): void {
  const current = getStockTransfers();
  const next = [transfer, ...current];
  saveStockTransfers(next);
}

export function updateStockTransfer(updated: StockTransfer): void {
  const current = getStockTransfers();
  const next = current.map(t => t.id === updated.id ? updated : t);
  saveStockTransfers(next);
}

export function subscribeStockTransfers(callback: (transfers: StockTransfer[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvent = e as CustomEvent<StockTransfer[]>;
    if (customEvent.detail) {
      callback(customEvent.detail);
    } else {
      callback(getStockTransfers());
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener(TRANSFERS_EVENT_NAME, handler);
  }

  return () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener(TRANSFERS_EVENT_NAME, handler);
    }
  };
}
