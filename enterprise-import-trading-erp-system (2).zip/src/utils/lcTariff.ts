export interface DutyHeadConfig {
  code: 'CD' | 'RD' | 'SD' | 'VAT' | 'AIT' | 'AT';
  name: string;
  ratePercent: number;
  baseFormula: string;
  capitalizeToInventory: boolean;
  accountHeadCode: string;
  accountHeadName: string;
}

export interface CustomsTariffConfig {
  hsCode: string;
  description: string;
  landingPercent: number;
  heads: DutyHeadConfig[];
}

export interface TariffCalculationLine {
  code: 'CD' | 'RD' | 'SD' | 'VAT' | 'AIT' | 'AT';
  name: string;
  ratePercent: number;
  baseAmountBdt: number;
  dutyAmountBdt: number;
  capitalizeToInventory: boolean;
  accountHeadCode: string;
  accountHeadName: string;
}

export interface TariffCalculationResult {
  hsCode: string;
  cfrBdt: number;
  landingPercent: number;
  landingAmountBdt: number;
  assessableValueBdt: number;
  lines: TariffCalculationLine[];
  cdAmount: number;
  rdAmount: number;
  sdAmount: number;
  vatAmount: number;
  aitAmount: number;
  atAmount: number;
  totalDutiesBdt: number;
  capitalizableDutiesBdt: number;
  recoverableTaxesBdt: number;
}

const TARIFF_STORAGE_KEY = 'tradecore_lc_tariffs_v2';

export const DEFAULT_TARIFF_CONFIGS: CustomsTariffConfig[] = [
  {
    hsCode: '2517.10.00',
    description: 'Pebbles, gravel, broken or crushed stone (Boulder Stone)',
    landingPercent: 1.0,
    heads: [
      { code: 'CD', name: 'Customs Duty (CD)', ratePercent: 25, baseFormula: 'AV', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'RD', name: 'Regulatory Duty (RD)', ratePercent: 3, baseFormula: 'AV', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'SD', name: 'Supplementary Duty (SD)', ratePercent: 20, baseFormula: 'AV + CD + RD', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'VAT', name: 'Value Added Tax (VAT)', ratePercent: 15, baseFormula: 'AV + CD + RD + SD', capitalizeToInventory: false, accountHeadCode: '11410', accountHeadName: 'VAT Current Account' },
      { code: 'AIT', name: 'Advance Income Tax (AIT)', ratePercent: 5, baseFormula: 'AV', capitalizeToInventory: false, accountHeadCode: '11420', accountHeadName: 'Advance Income Tax Asset' },
      { code: 'AT', name: 'Advance Tax (AT)', ratePercent: 5, baseFormula: 'AV + CD + RD + SD', capitalizeToInventory: false, accountHeadCode: '11430', accountHeadName: 'Advance Tax Asset' }
    ]
  }
];

export function getAllTariffConfigs(): CustomsTariffConfig[] {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(TARIFF_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to parse tariff configs:', e);
  }
  return DEFAULT_TARIFF_CONFIGS;
}

export function getTariffConfig(hsCode?: string): CustomsTariffConfig {
  const all = getAllTariffConfigs();
  if (hsCode) {
    const cleanHs = hsCode.trim();
    const found = all.find(t => t.hsCode === cleanHs || cleanHs.startsWith(t.hsCode.slice(0, 4)));
    if (found) return found;
  }
  return all[0] || DEFAULT_TARIFF_CONFIGS[0];
}

export function saveTariffConfig(config: CustomsTariffConfig): void {
  const all = getAllTariffConfigs();
  const index = all.findIndex(t => t.hsCode === config.hsCode);
  let next: CustomsTariffConfig[];
  if (index >= 0) {
    next = [...all];
    next[index] = config;
  } else {
    next = [...all, config];
  }
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(TARIFF_STORAGE_KEY, JSON.stringify(next));
      window.dispatchEvent(new CustomEvent('tradecore_tariff_changed', { detail: { configs: next } }));
    }
  } catch (e) {
    console.error('Failed to save tariff configs:', e);
  }
}

export function updateDutyHeadCapitalize(hsCode: string, headCode: string, capitalize: boolean): void {
  const current = getTariffConfig(hsCode);
  const updatedHeads = current.heads.map(h => 
    h.code === headCode ? { ...h, capitalizeToInventory: capitalize } : h
  );
  saveTariffConfig({ ...current, heads: updatedHeads });
}

export function updateDutyHeadRate(hsCode: string, headCode: string, rate: number): void {
  const current = getTariffConfig(hsCode);
  const updatedHeads = current.heads.map(h => 
    h.code === headCode ? { ...h, ratePercent: Math.max(0, rate) } : h
  );
  saveTariffConfig({ ...current, heads: updatedHeads });
}

export function calculateLcTariff(cfrBdt: number, hsCode?: string): TariffCalculationResult {
  const tariff = getTariffConfig(hsCode);
  const landingPercent = tariff.landingPercent ?? 1.0;
  
  // AV = CFR BDT x (1 + landing%)
  const landingAmountBdt = Math.round((cfrBdt * landingPercent) / 100);
  const assessableValueBdt = cfrBdt + landingAmountBdt;

  const getHead = (code: 'CD' | 'RD' | 'SD' | 'VAT' | 'AIT' | 'AT'): DutyHeadConfig => {
    const found = tariff.heads.find(h => h.code === code);
    if (found) return found;
    return {
      code,
      name: code,
      ratePercent: code === 'CD' ? 25 : code === 'RD' ? 3 : code === 'SD' ? 20 : code === 'VAT' ? 15 : 5,
      baseFormula: code === 'SD' || code === 'VAT' || code === 'AT' ? 'AV + CD + RD' : 'AV',
      capitalizeToInventory: code === 'CD' || code === 'RD' || code === 'SD',
      accountHeadCode: code === 'VAT' ? '11410' : code === 'AIT' ? '11420' : code === 'AT' ? '11430' : '13100',
      accountHeadName: code
    };
  };

  const cdHead = getHead('CD');
  const rdHead = getHead('RD');
  const sdHead = getHead('SD');
  const vatHead = getHead('VAT');
  const aitHead = getHead('AIT');
  const atHead = getHead('AT');

  // Bases per prompt specifications:
  // AV = CFR BDT x (1 + landing)
  // CD, RD, AIT on AV
  const cdBase = assessableValueBdt;
  const cdAmount = Math.round((cdBase * cdHead.ratePercent) / 100);

  const rdBase = assessableValueBdt;
  const rdAmount = Math.round((rdBase * rdHead.ratePercent) / 100);

  // SD on AV + CD + RD
  const sdBase = assessableValueBdt + cdAmount + rdAmount;
  const sdAmount = Math.round((sdBase * sdHead.ratePercent) / 100);

  // VAT and AT on AV + CD + RD + SD
  const vatBase = assessableValueBdt + cdAmount + rdAmount + sdAmount;
  const vatAmount = Math.round((vatBase * vatHead.ratePercent) / 100);

  // AIT on AV
  const aitBase = assessableValueBdt;
  const aitAmount = Math.round((aitBase * aitHead.ratePercent) / 100);

  // AT on AV + CD + RD + SD
  const atBase = assessableValueBdt + cdAmount + rdAmount + sdAmount;
  const atAmount = Math.round((atBase * atHead.ratePercent) / 100);

  const lines: TariffCalculationLine[] = [
    { code: 'CD', name: cdHead.name, ratePercent: cdHead.ratePercent, baseAmountBdt: cdBase, dutyAmountBdt: cdAmount, capitalizeToInventory: cdHead.capitalizeToInventory, accountHeadCode: cdHead.accountHeadCode, accountHeadName: cdHead.accountHeadName },
    { code: 'RD', name: rdHead.name, ratePercent: rdHead.ratePercent, baseAmountBdt: rdBase, dutyAmountBdt: rdAmount, capitalizeToInventory: rdHead.capitalizeToInventory, accountHeadCode: rdHead.accountHeadCode, accountHeadName: rdHead.accountHeadName },
    { code: 'SD', name: sdHead.name, ratePercent: sdHead.ratePercent, baseAmountBdt: sdBase, dutyAmountBdt: sdAmount, capitalizeToInventory: sdHead.capitalizeToInventory, accountHeadCode: sdHead.accountHeadCode, accountHeadName: sdHead.accountHeadName },
    { code: 'VAT', name: vatHead.name, ratePercent: vatHead.ratePercent, baseAmountBdt: vatBase, dutyAmountBdt: vatAmount, capitalizeToInventory: vatHead.capitalizeToInventory, accountHeadCode: vatHead.accountHeadCode, accountHeadName: vatHead.accountHeadName },
    { code: 'AIT', name: aitHead.name, ratePercent: aitHead.ratePercent, baseAmountBdt: aitBase, dutyAmountBdt: aitAmount, capitalizeToInventory: aitHead.capitalizeToInventory, accountHeadCode: aitHead.accountHeadCode, accountHeadName: aitHead.accountHeadName },
    { code: 'AT', name: atHead.name, ratePercent: atHead.ratePercent, baseAmountBdt: atBase, dutyAmountBdt: atAmount, capitalizeToInventory: atHead.capitalizeToInventory, accountHeadCode: atHead.accountHeadCode, accountHeadName: atHead.accountHeadName }
  ];

  const totalDutiesBdt = cdAmount + rdAmount + sdAmount + vatAmount + aitAmount + atAmount;
  const capitalizableDutiesBdt = lines.filter(l => l.capitalizeToInventory).reduce((sum, l) => sum + l.dutyAmountBdt, 0);
  const recoverableTaxesBdt = lines.filter(l => !l.capitalizeToInventory).reduce((sum, l) => sum + l.dutyAmountBdt, 0);

  return {
    hsCode: tariff.hsCode,
    cfrBdt,
    landingPercent,
    landingAmountBdt,
    assessableValueBdt,
    lines,
    cdAmount,
    rdAmount,
    sdAmount,
    vatAmount,
    aitAmount,
    atAmount,
    totalDutiesBdt,
    capitalizableDutiesBdt,
    recoverableTaxesBdt
  };
}
