import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  writeBatch 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { BankAccount } from '../types/erp';
import { addAccountHead } from './coaStorage';

const STORAGE_KEY = 'tradecore_bank_accounts_v1';
export const BANK_ACCOUNTS_EVENT = 'tradecore_bank_accounts_changed';

// Step D: remove all seeded demo data. A new installation must start empty.
export const INITIAL_BANK_ACCOUNTS: BankAccount[] = [];

/**
 * Sanitizes an object by removing any fields with 'undefined' values before passing to Firestore.
 * Firestore throws a FirebaseError if any field value is undefined.
 */
export function cleanFirestoreData<T extends Record<string, any>>(data: T): Partial<T> {
  const cleaned: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value !== undefined) {
      if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
        cleaned[key] = cleanFirestoreData(value);
      } else {
        cleaned[key] = value;
      }
    }
  }
  return cleaned as Partial<T>;
}

/**
 * Ensures a list of BankAccount objects contains only unique accounts by ID.
 * Prevents React duplicate key errors across subscriptions and snapshots.
 */
export function deduplicateAccounts(accounts: BankAccount[]): BankAccount[] {
  const seen = new Set<string>();
  const result: BankAccount[] = [];
  for (const acc of accounts) {
    if (acc && acc.id && !seen.has(acc.id)) {
      seen.add(acc.id);
      result.push(acc);
    }
  }
  return result;
}

// In-memory cache loaded from offline cache (localStorage) for synchronous rendering
let cachedBankAccounts: BankAccount[] = (() => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return deduplicateAccounts(parsed);
      }
    }
  } catch (err) {
    console.error('Failed to parse bank accounts from localStorage:', err);
  }
  return INITIAL_BANK_ACCOUNTS;
})();

const subscribers = new Set<(accounts: BankAccount[]) => void>();

function notifySubscribers(accounts: BankAccount[]) {
  const uniqueAccounts = deduplicateAccounts(accounts);
  cachedBankAccounts = uniqueAccounts;
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(uniqueAccounts));
      window.dispatchEvent(new CustomEvent(BANK_ACCOUNTS_EVENT, { detail: { accounts: uniqueAccounts } }));
    }
  } catch (e) {
    console.error('Failed to update local storage cache for bank accounts:', e);
  }
  subscribers.forEach(cb => {
    try {
      cb(uniqueAccounts);
    } catch (e) {
      console.error('Subscriber callback error:', e);
    }
  });
}

// Step B: Listen to Firestore with onSnapshot realtime listener
if (typeof window !== 'undefined') {
  try {
    const colRef = collection(db, 'bank_accounts');
    onSnapshot(colRef, (snapshot) => {
      const items: BankAccount[] = [];
      snapshot.forEach(docSnap => {
        items.push({ id: docSnap.id, ...docSnap.data() } as BankAccount);
      });
      notifySubscribers(deduplicateAccounts(items));
    }, (error) => {
      console.error('Firestore onSnapshot error for bank_accounts:', error);
    });
  } catch (e) {
    console.error('Failed to attach onSnapshot to bank_accounts:', e);
  }
}

/**
 * Returns currently cached bank accounts (guaranteed unique by id)
 */
export function getBankAccounts(): BankAccount[] {
  return deduplicateAccounts(cachedBankAccounts);
}

/**
 * Save bank accounts batch to Firestore and update cache.
 * Throws if Firestore write fails.
 */
export function saveBankAccounts(accounts: BankAccount[]): void {
  const unique = deduplicateAccounts(accounts);
  notifySubscribers(unique);

  // Write batch to Firestore with cleaned data
  const batch = writeBatch(db);
  unique.forEach(acc => {
    const ref = doc(db, 'bank_accounts', acc.id);
    batch.set(ref, cleanFirestoreData(acc));
  });
  batch.commit().catch(err => {
    console.warn('Firestore batch write notice for bank_accounts:', err?.message || err);
  });
}

/**
 * Determines whether a bank_accounts record is a cash account ('cash') or bank account ('bank').
 * Reads the explicit `type` field first, then `accountCategory` / `accountType` / `coaCode`,
 * and falls back to a case-insensitive check for "cash" in `bankName` for legacy saved records.
 */
export function isCashAccount(acc?: Partial<BankAccount> | null): boolean {
  if (!acc) return false;
  if (acc.type === 'cash' || acc.type === 'bank') {
    return acc.type === 'cash';
  }
  if (acc.accountCategory === 'Cash' || acc.accountCategory === 'Bank') {
    return acc.accountCategory === 'Cash';
  }
  if (
    acc.accountType === 'Petty Cash' ||
    acc.accountType === 'POS Cash' ||
    (acc.accountType as string) === 'Cash'
  ) {
    return true;
  }
  if (acc.coaCode === '1010' || (acc.coaCode && acc.coaCode.startsWith('101'))) {
    return true;
  }
  if (
    acc.accountType === 'Current' ||
    acc.accountType === 'Savings' ||
    acc.accountType === 'Overdraft/LTR' ||
    acc.accountType === 'Foreign Currency (USD)' ||
    acc.accountType === 'Margin Deposit'
  ) {
    return false;
  }
  return Boolean(acc.bankName && acc.bankName.toLowerCase().includes('cash'));
}

/**
 * Add a new bank account to Firestore. Throws if write fails.
 */
export function addBankAccount(newAccount: BankAccount): BankAccount[] {
  const current = getBankAccounts();
  if (current.some(a => a.id === newAccount.id || (newAccount.accountNumber && a.accountNumber === newAccount.accountNumber))) {
    return current;
  }
  const normalizedAccount: BankAccount = {
    ...newAccount,
    type: newAccount.type || (isCashAccount(newAccount) ? 'cash' : 'bank')
  };
  const next = deduplicateAccounts([...current, normalizedAccount]);
  notifySubscribers(next);

  // Sync with Firestore with sanitized data (no undefined fields)
  const docRef = doc(db, 'bank_accounts', normalizedAccount.id);
  setDoc(docRef, cleanFirestoreData(normalizedAccount)).catch(err => {
    console.error('Failed to create bank account in Firestore:', err);
    throw err;
  });

  // Automatically register in Chart of Accounts (COA) under Cash & Bank
  try {
    addAccountHead({
      code: normalizedAccount.coaCode || (isCashAccount(normalizedAccount) ? `101${next.length}` : `102${next.length}`),
      name: normalizedAccount.bankName,
      category: 'Asset',
      subCategory: 'Cash & Bank',
      balance: normalizedAccount.ledgerBalance,
      normalBalance: 'Debit',
      isParent: false
    });
  } catch (e) {
    console.warn('COA auto-sync note:', e);
  }

  return next;
}

/**
 * Update an existing bank account in Firestore.
 */
export function updateBankAccount(updated: BankAccount): BankAccount[] {
  const current = getBankAccounts();
  const next = deduplicateAccounts(current.map(a => a.id === updated.id ? updated : a));
  notifySubscribers(next);

  const docRef = doc(db, 'bank_accounts', updated.id);
  setDoc(docRef, cleanFirestoreData(updated), { merge: true }).catch(err => {
    console.error('Failed to update bank account in Firestore:', err);
    throw err;
  });

  return next;
}

/**
 * Delete a bank account from Firestore.
 */
export function deleteBankAccount(id: string): BankAccount[] {
  const current = getBankAccounts();
  const next = current.filter(a => a.id !== id);
  notifySubscribers(next);

  const docRef = doc(db, 'bank_accounts', id);
  deleteDoc(docRef).catch(err => {
    console.error('Failed to delete bank account in Firestore:', err);
    throw err;
  });

  return next;
}

/**
 * Update bank account balance in Firestore.
 */
export function updateBankAccountBalance(
  accountId: string, 
  balanceDelta: number
): { updatedAccount?: BankAccount; allAccounts: BankAccount[] } {
  const current = getBankAccounts();
  let updatedAcc: BankAccount | undefined;

  const next = current.map(acc => {
    if (acc.id === accountId) {
      const newLedger = (acc.ledgerBalance || 0) + balanceDelta;
      const newStatement = (acc.statementBalance || 0) + balanceDelta;
      updatedAcc = {
        ...acc,
        ledgerBalance: newLedger,
        statementBalance: newStatement
      };
      return updatedAcc;
    }
    return acc;
  });

  notifySubscribers(next);

  if (updatedAcc) {
    const docRef = doc(db, 'bank_accounts', accountId);
    updateDoc(docRef, {
      ledgerBalance: updatedAcc.ledgerBalance,
      statementBalance: updatedAcc.statementBalance
    }).catch(err => {
      console.error('Failed to update bank account balance in Firestore:', err);
      throw err;
    });
  }

  return { updatedAccount: updatedAcc, allAccounts: next };
}

/**
 * Subscribe to bank accounts with real-time updates
 */
export function subscribeBankAccounts(callback: (accounts: BankAccount[]) => void): () => void {
  subscribers.add(callback);
  callback(deduplicateAccounts(cachedBankAccounts));

  return () => {
    subscribers.delete(callback);
  };
}
