// Dynamic Unit of Measure (UOM) Management
// Connects directly across Inventory (Items), Direct Sales Invoices, and Purchase Invoices

const STORAGE_KEY = 'tradecore_uoms_v1';
export const UOM_EVENT_NAME = 'tradecore_uoms_changed';

export const DEFAULT_UOMS = [
  'CFT',
  'Ton',
  'MT',
  'Kg',
  'Pcs',
  'Bag',
  'Truck',
  'Cbm',
  'Drums',
  'Sqft',
  'Trip'
];

/**
 * Get all available UOMs (defaults + custom added)
 */
export function getUOMs(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure defaults are present while keeping user additions
        const combined = Array.from(new Set([...parsed, ...DEFAULT_UOMS]));
        return combined;
      }
    }
  } catch (err) {
    console.error('Failed to load UOMs from storage', err);
  }
  return [...DEFAULT_UOMS];
}

/**
 * Save UOMs to storage and dispatch event
 */
export function saveUOMs(uoms: string[]): void {
  try {
    const unique = Array.from(new Set(uoms.map(u => u.trim()).filter(Boolean)));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(unique));
    window.dispatchEvent(new CustomEvent(UOM_EVENT_NAME, { detail: { uoms: unique } }));
  } catch (err) {
    console.error('Failed to save UOMs to storage', err);
  }
}

/**
 * Add a new custom UOM on demand (connected across Sales, Purchase, Inventory)
 */
export function addUOM(newUom: string): string[] {
  const trimmed = newUom.trim();
  if (!trimmed) return getUOMs();
  
  const current = getUOMs();
  if (!current.some(u => u.toLowerCase() === trimmed.toLowerCase())) {
    const updated = [...current, trimmed];
    saveUOMs(updated);
    return updated;
  }
  return current;
}

/**
 * Delete a custom UOM
 */
export function deleteUOM(uomToDelete: string): string[] {
  const current = getUOMs();
  // Don't allow deleting CFT and Ton as core defaults, but can delete others
  const updated = current.filter(u => u.toLowerCase() !== uomToDelete.toLowerCase());
  saveUOMs(updated);
  return updated;
}

/**
 * Subscribe to UOM changes across modules
 */
export function subscribeUOMs(callback: (uoms: string[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ uoms: string[] }>;
    if (customEvt.detail?.uoms) {
      callback(customEvt.detail.uoms);
    } else {
      callback(getUOMs());
    }
  };

  window.addEventListener(UOM_EVENT_NAME, handler);
  return () => window.removeEventListener(UOM_EVENT_NAME, handler);
}
