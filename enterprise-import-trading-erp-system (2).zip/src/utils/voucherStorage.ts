import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { JournalVoucher } from '../types/erp';

const VOUCHER_STORAGE_KEY = 'tradecore_journal_vouchers_v1';
export const VOUCHER_EVENT_NAME = 'tradecore_vouchers_updated';

// Step D: remove all seeded demo data. A new installation must start empty.
export const INITIAL_VOUCHERS: JournalVoucher[] = [];

// In-memory cache loaded from offline cache (localStorage)
let cachedVouchers: JournalVoucher[] = (() => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(VOUCHER_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed.filter((v: JournalVoucher) => v.voucherType !== 'JV' && !v.voucherNumber.startsWith('JV'));
        }
      }
    }
  } catch (err) {
    console.error('Failed to parse vouchers from storage:', err);
  }
  return INITIAL_VOUCHERS;
})();

const subscribers = new Set<(vouchers: JournalVoucher[]) => void>();

function notifySubscribers(vouchers: JournalVoucher[]) {
  const filtered = vouchers.filter(v => v.voucherType !== 'JV' && !v.voucherNumber.startsWith('JV'));
  cachedVouchers = filtered;
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(VOUCHER_STORAGE_KEY, JSON.stringify(filtered));
      window.dispatchEvent(new CustomEvent(VOUCHER_EVENT_NAME, { detail: filtered }));
    }
  } catch (err) {
    console.error('Failed to save vouchers to storage:', err);
  }
  subscribers.forEach(cb => {
    try { cb(filtered); } catch (e) { console.error(e); }
  });
}

// Attach realtime onSnapshot listener for journal_vouchers
if (typeof window !== 'undefined') {
  try {
    const colRef = collection(db, 'journal_vouchers');
    onSnapshot(colRef, (snapshot) => {
      const items: JournalVoucher[] = [];
      snapshot.forEach(docSnap => {
        items.push({ id: docSnap.id, ...docSnap.data() } as JournalVoucher);
      });
      // Sort newest first
      items.sort((a, b) => new Date(b.voucherDate || 0).getTime() - new Date(a.voucherDate || 0).getTime());
      notifySubscribers(items);
    }, (error) => {
      console.warn('Firestore onSnapshot notice for journal_vouchers:', error?.message || error);
    });
  } catch (e) {
    console.error('Failed to attach onSnapshot to journal_vouchers:', e);
  }
}

/**
 * Get all vouchers from storage
 */
export function getVouchers(): JournalVoucher[] {
  return cachedVouchers;
}

/**
 * Save vouchers to storage and notify all listeners
 */
export function saveVouchers(vouchers: JournalVoucher[]): void {
  notifySubscribers(vouchers);
}

/**
 * Sanitizes an object by removing any fields with 'undefined' values before passing to Firestore.
 * Firestore throws a FirebaseError if any field value is undefined.
 */
function cleanFirestoreData<T extends Record<string, any>>(data: T): Partial<T> {
  const cleaned: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value !== undefined) {
      if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
        cleaned[key] = cleanFirestoreData(value);
      } else if (Array.isArray(value)) {
        cleaned[key] = value.map(item => (item !== null && typeof item === 'object') ? cleanFirestoreData(item) : item);
      } else {
        cleaned[key] = value;
      }
    }
  }
  return cleaned as Partial<T>;
}

/**
 * Add a new voucher and sync to Firestore
 */
export function addVoucher(voucher: JournalVoucher): void {
  const current = getVouchers();
  const updated = [voucher, ...current];
  notifySubscribers(updated);

  const docRef = doc(db, 'journal_vouchers', voucher.id);
  const sanitized = cleanFirestoreData(voucher);
  setDoc(docRef, sanitized).catch(err => {
    console.error('Failed to write journal voucher to Firestore:', err);
    throw err;
  });
}

/**
 * Update an existing voucher in Firestore
 */
export function updateVoucher(updatedVoucher: JournalVoucher): void {
  const current = getVouchers();
  const updated = current.map(v => v.id === updatedVoucher.id ? updatedVoucher : v);
  notifySubscribers(updated);

  const docRef = doc(db, 'journal_vouchers', updatedVoucher.id);
  const sanitized = cleanFirestoreData(updatedVoucher);
  setDoc(docRef, sanitized, { merge: true }).catch(err => {
    console.error('Failed to update journal voucher in Firestore:', err);
    throw err;
  });
}

/**
 * Delete a voucher from Firestore
 */
export function deleteVoucher(id: string): void {
  const current = getVouchers();
  const updated = current.filter(v => v.id !== id);
  notifySubscribers(updated);

  const docRef = doc(db, 'journal_vouchers', id);
  deleteDoc(docRef).catch(err => {
    console.error('Failed to delete journal voucher in Firestore:', err);
    throw err;
  });
}

/**
 * Subscribe to voucher changes
 */
export function subscribeVouchers(callback: (vouchers: JournalVoucher[]) => void): () => void {
  subscribers.add(callback);
  callback(cachedVouchers);

  const handler = (e: Event) => {
    const customEvent = e as CustomEvent<JournalVoucher[]>;
    if (customEvent.detail) {
      callback(customEvent.detail);
    } else {
      callback(getVouchers());
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener(VOUCHER_EVENT_NAME, handler);
    return () => {
      subscribers.delete(callback);
      window.removeEventListener(VOUCHER_EVENT_NAME, handler);
    };
  }
  return () => {
    subscribers.delete(callback);
  };
}
