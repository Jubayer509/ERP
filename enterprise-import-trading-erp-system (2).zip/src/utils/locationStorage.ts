import { Warehouse } from '../types/erp';
import { MOCK_WAREHOUSES } from '../data/mockErpData';

const WAREHOUSES_STORAGE_KEY = 'tradecore_warehouses_v1';
export const WAREHOUSES_EVENT_NAME = 'tradecore_warehouses_changed';

/**
 * Load Warehouses / Locations from storage or fallback to defaults
 */
export function getWarehouses(): Warehouse[] {
  try {
    const raw = localStorage.getItem(WAREHOUSES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load warehouses from storage', err);
  }
  return MOCK_WAREHOUSES;
}

/**
 * Save Warehouses and broadcast change event
 */
export function saveWarehouses(list: Warehouse[]): void {
  try {
    localStorage.setItem(WAREHOUSES_STORAGE_KEY, JSON.stringify(list));
    window.dispatchEvent(new CustomEvent(WAREHOUSES_EVENT_NAME, { detail: { warehouses: list } }));
  } catch (err) {
    console.error('Failed to save warehouses to storage', err);
  }
}

/**
 * Add a new Warehouse / Storage Yard
 */
export function addWarehouse(newWh: Warehouse): Warehouse[] {
  const current = getWarehouses();
  const updated = [newWh, ...current];
  saveWarehouses(updated);
  return updated;
}

/**
 * Update an existing Warehouse / Location
 */
export function updateWarehouse(updatedWh: Warehouse): Warehouse[] {
  const current = getWarehouses();
  const updated = current.map(item => (item.id === updatedWh.id ? updatedWh : item));
  saveWarehouses(updated);
  return updated;
}

/**
 * Delete a Warehouse / Location
 */
export function deleteWarehouse(id: string): Warehouse[] {
  const current = getWarehouses();
  const updated = current.filter(item => item.id !== id);
  saveWarehouses(updated);
  return updated;
}

/**
 * Subscribe to Warehouse / Location changes
 */
export function subscribeWarehouses(callback: (list: Warehouse[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ warehouses: Warehouse[] }>;
    if (customEvt.detail?.warehouses) {
      callback(customEvt.detail.warehouses);
    } else {
      callback(getWarehouses());
    }
  };

  window.addEventListener(WAREHOUSES_EVENT_NAME, handler);
  return () => window.removeEventListener(WAREHOUSES_EVENT_NAME, handler);
}
