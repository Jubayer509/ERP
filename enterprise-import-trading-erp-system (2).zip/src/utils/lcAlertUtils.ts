import { LetterOfCredit, LCStatus } from '../types/erp';

export type AlertSeverity = 'expired' | 'critical' | 'warning' | 'normal';
export type AlertCategory = 'shipment' | 'lc_expiry' | 'maturity';

export interface LCExpiryAlert {
  id: string;
  lcId: string;
  lcNumber: string;
  bankReference: string;
  issuingBank: string;
  supplierName: string;
  cfrAmount: number;
  currency: string;
  commodity: string;
  category: AlertCategory;
  categoryLabel: string;
  targetDate: string;
  daysRemaining: number;
  severity: AlertSeverity;
  title: string;
  description: string;
  recommendedAction: string;
  status: LCStatus;
  acknowledged?: boolean;
}

// Current reference date (anchor to ERP system date: 2026-09-22)
export const ERP_SYSTEM_DATE = '2026-09-22';

/**
 * Calculates days difference from reference date to target date.
 * Positive = days in future, Negative = overdue / lapsed days
 */
export function getDaysRemaining(targetDateStr: string, referenceDateStr: string = ERP_SYSTEM_DATE): number {
  if (!targetDateStr) return 999;
  const target = new Date(targetDateStr).getTime();
  const ref = new Date(referenceDateStr).getTime();
  const diffTime = target - ref;
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Maps days remaining to severity level
 */
export function getAlertSeverity(days: number): AlertSeverity {
  if (days < 0) return 'expired';
  if (days <= 7) return 'critical';
  if (days <= 21) return 'warning';
  return 'normal';
}

/**
 * Evaluates all active LCs and extracts all relevant expiry alerts:
 * 1. Latest Shipment Expiry
 * 2. LC Negotiation / Presentation Expiry
 * 3. Payment Acceptance / Settlement Maturity
 */
export function generateLCExpiryAlerts(
  lcs: LetterOfCredit[],
  acknowledgedIds: string[] = []
): LCExpiryAlert[] {
  const alerts: LCExpiryAlert[] = [];

  lcs.forEach(lc => {
    // Skip closed or cancelled LCs
    if (lc.status === 'Costed & Closed') return;

    const commodity = lc.items[0]?.itemName || 'Industrial Cargo';

    // 1. Shipment Expiry Alert (unless already arrived/cleared/received)
    const shipmentExemptStatuses: LCStatus[] = ['Customs Cleared', 'GRN Received', 'Costed & Closed'];
    const isShipmentRelevant = !shipmentExemptStatuses.includes(lc.status) || lc.status === 'Shipment In-Transit';

    if (lc.shipmentExpiryDate) {
      const days = getDaysRemaining(lc.shipmentExpiryDate);
      const severity = getAlertSeverity(days);

      // Only generate alert if within 30 days or expired, or if in-transit
      if (days <= 30) {
        let action = 'Contact shipping line & foreign exporter to confirm on-board Bill of Lading (BL) issue date.';
        if (days < 0) {
          action = 'URGENT: Request Bank Amendment (Swift MT707) to extend latest shipment date to cure late shipment discrepancy.';
        } else if (days <= 7) {
          action = 'CRITICAL: Shipper must complete loading and obtain signed BL within 7 days to avoid presentation discrepancy.';
        }

        alerts.push({
          id: `${lc.id}-shipment`,
          lcId: lc.id,
          lcNumber: lc.lcNumber,
          bankReference: lc.bankReference,
          issuingBank: lc.issuingBank,
          supplierName: lc.supplierName,
          cfrAmount: lc.cfrAmount,
          currency: lc.currency,
          commodity,
          category: 'shipment',
          categoryLabel: 'Latest Shipment Date',
          targetDate: lc.shipmentExpiryDate,
          daysRemaining: days,
          severity,
          title: days < 0 
            ? `Shipment Date Lapsed for ${lc.lcNumber}` 
            : `Shipment Window Closing (${days} Days Left)`,
          description: `Latest shipment date was ${lc.shipmentExpiryDate}. Consignment of ${commodity} ($${lc.cfrAmount.toLocaleString()}) must be loaded on vessel.`,
          recommendedAction: action,
          status: lc.status,
          acknowledged: acknowledgedIds.includes(`${lc.id}-shipment`)
        });
      }
    }

    // 2. LC Negotiation / Presentation Expiry Alert
    if (lc.lcExpiryDate) {
      const days = getDaysRemaining(lc.lcExpiryDate);
      const severity = getAlertSeverity(days);

      if (days <= 30) {
        let action = 'Negotiate clean documents with advising bank before presentation validity expires.';
        if (days < 0) {
          action = 'CRITICAL: LC validity expired. Apply for bank validation extension or letter of credit renewal.';
        } else if (days <= 7) {
          action = 'URGENT: Documents must be formally lodged at bank counters within 7 days. Expedite courier dispatch.';
        }

        alerts.push({
          id: `${lc.id}-lcexpiry`,
          lcId: lc.id,
          lcNumber: lc.lcNumber,
          bankReference: lc.bankReference,
          issuingBank: lc.issuingBank,
          supplierName: lc.supplierName,
          cfrAmount: lc.cfrAmount,
          currency: lc.currency,
          commodity,
          category: 'lc_expiry',
          categoryLabel: 'LC Presentation Validity',
          targetDate: lc.lcExpiryDate,
          daysRemaining: days,
          severity,
          title: days < 0 
            ? `LC Validity Expired for ${lc.lcNumber}` 
            : `LC Instrument Expiring (${days} Days Left)`,
          description: `Instrument expiry date at bank counters is ${lc.lcExpiryDate}. Value: $${lc.cfrAmount.toLocaleString()} USD via ${lc.issuingBank}.`,
          recommendedAction: action,
          status: lc.status,
          acknowledged: acknowledgedIds.includes(`${lc.id}-lcexpiry`)
        });
      }
    }

    // 3. Payment Acceptance / Usance / PAD Maturity Alert
    const maturityDate = lc.maturityDate || lc.lcExpiryDate;
    if (maturityDate) {
      const days = getDaysRemaining(maturityDate);
      const severity = getAlertSeverity(days);

      if (days <= 30) {
        let action = 'Ensure foreign exchange availability and fund treasury account to settle bill without penal interest.';
        if (days < 0) {
          action = 'OVERDUE: Sight / Usance bill matured. Authorize bank remittance immediately to avoid late payment penalty.';
        } else if (days <= 7) {
          action = 'Arrange spot USD booking or utilize PAD credit facility to retire exporter bill on maturity date.';
        }

        alerts.push({
          id: `${lc.id}-maturity`,
          lcId: lc.id,
          lcNumber: lc.lcNumber,
          bankReference: lc.bankReference,
          issuingBank: lc.issuingBank,
          supplierName: lc.supplierName,
          cfrAmount: lc.cfrAmount,
          currency: lc.currency,
          commodity,
          category: 'maturity',
          categoryLabel: 'Bill Settlement Maturity',
          targetDate: maturityDate,
          daysRemaining: days,
          severity,
          title: days < 0 
            ? `Exporter Bill Matured & Overdue: ${lc.lcNumber}` 
            : `Bill Maturity Approaching (${days} Days Left)`,
          description: `Tenor: ${lc.lcType}. Payment due on ${maturityDate}. Net payable: $${lc.cfrAmount.toLocaleString()} USD.`,
          recommendedAction: action,
          status: lc.status,
          acknowledged: acknowledgedIds.includes(`${lc.id}-maturity`)
        });
      }
    }
  });

  // Sort by urgency: expired first, then critical, warning, normal
  return alerts.sort((a, b) => a.daysRemaining - b.daysRemaining);
}

/**
 * Generates an official Swift MT707 LC Amendment Request Letter template
 */
export function generateMT707AmendmentDraft(lc: LetterOfCredit, extensionDays: number = 30): {
  subject: string;
  reference: string;
  letterBody: string;
  newShipmentDate: string;
  newExpiryDate: string;
} {
  const currentShipment = new Date(lc.shipmentExpiryDate || ERP_SYSTEM_DATE);
  const currentExpiry = new Date(lc.lcExpiryDate || ERP_SYSTEM_DATE);

  const newShipmentDateObj = new Date(currentShipment);
  newShipmentDateObj.setDate(newShipmentDateObj.getDate() + extensionDays);
  const newShipmentDate = newShipmentDateObj.toISOString().split('T')[0];

  const newExpiryDateObj = new Date(currentExpiry);
  newExpiryDateObj.setDate(newExpiryDateObj.getDate() + extensionDays);
  const newExpiryDate = newExpiryDateObj.toISOString().split('T')[0];

  const subject = `Application for Amendment of Irrevocable Documentary Credit No. ${lc.lcNumber}`;
  const reference = `REF: TC/IMP/AMD/2026/${lc.lcNumber.replace('LC-', '')}`;

  const letterBody = `To:
The Head of Trade Operations / Manager
${lc.issuingBank}
${lc.branch}

Dear Sir/Madam,

RE: AMENDMENT TO LETTER OF CREDIT NO: ${lc.lcNumber} (Bank Ref: ${lc.bankReference})
BENEFICIARY: ${lc.supplierName}, ${lc.beneficiaryCountry}
COMMODITY: ${lc.items[0]?.itemName || 'Industrial Cargo'}
CFR VALUE: ${lc.currency} ${lc.cfrAmount.toLocaleString()}

With reference to the captioned Letter of Credit opened through your branch, we hereby request you to kindly transmit an Amendment via SWIFT MT707 to the Advising Bank with the following modifications:

1. FIELD 44C (LATEST DATE OF SHIPMENT):
   Existing: ${lc.shipmentExpiryDate}
   Amended To: ${newShipmentDate} (Extended by ${extensionDays} days)

2. FIELD 31D (DATE & PLACE OF EXPIRY):
   Existing: ${lc.lcExpiryDate} in Beneficiary Country
   Amended To: ${newExpiryDate} in Beneficiary Country

3. FIELD 71B (CHARGES):
   All amendment charges outside Bangladesh are on Beneficiary's account. Local bank amendment charges are to be debited to our Current CD Account No: 0102-0921820.

All other terms and conditions of the original Documentary Credit remain unaltered.

Kindly transmit the Swift MT707 amendment immediately and provide us with a certified copy of the Swift acknowledgement.

Yours faithfully,

For TradeCore Industrial Trading Ltd.
Authorized Signatory / CFO`;

  return {
    subject,
    reference,
    letterBody,
    newShipmentDate,
    newExpiryDate
  };
}
