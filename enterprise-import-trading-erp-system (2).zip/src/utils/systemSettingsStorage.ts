import { db } from '../lib/firebase';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';

export interface SystemInventorySettings {
  allowNegativeStock: boolean;
  updatedAt?: string;
  updatedBy?: string;
}

export interface CompanyProfileSettings {
  companyName: string;
  address: string;
  mobile: string;
  fiscalYearDuration: string;
  updatedAt?: string;
  updatedBy?: string;
}

const SETTINGS_STORAGE_KEY = 'tradecore_system_inventory_settings_v1';
const SETTINGS_DOC_PATH = doc(db, 'system_settings', 'inventory');

const COMPANY_PROFILE_STORAGE_KEY = 'tradecore_company_profile_v1';
const COMPANY_PROFILE_DOC_PATH = doc(db, 'system_settings', 'company_profile');

const DEFAULT_SETTINGS: SystemInventorySettings = {
  allowNegativeStock: false,
};

export const DEFAULT_COMPANY_PROFILE: CompanyProfileSettings = {
  companyName: 'M/S JUBAYER OVERSEAS',
  address: 'Thana Road Patgram, Lalmonirhat',
  mobile: '01701562509',
  fiscalYearDuration: 'July 01 to June 30',
};

const LEGACY_COMPANY_NAMES = new Set([
  'apex global trading & distribution ltd.',
  'apex global trading & distribution',
  'bengal industrial imports & commodities plc',
  'bengal overseas trading consortium',
  'starline trading & exports ltd.',
  'starline trading ltd.',
]);

function normalizeCompanyProfile(raw: Partial<CompanyProfileSettings> | null | undefined): CompanyProfileSettings {
  if (!raw || typeof raw !== 'object') {
    return { ...DEFAULT_COMPANY_PROFILE };
  }
  const rawName = (raw.companyName || '').trim();
  const isLegacyName = !rawName || LEGACY_COMPANY_NAMES.has(rawName.toLowerCase());

  return {
    companyName: isLegacyName ? DEFAULT_COMPANY_PROFILE.companyName : rawName,
    address: (raw.address || '').trim() || DEFAULT_COMPANY_PROFILE.address,
    mobile: (raw.mobile || '').trim() || DEFAULT_COMPANY_PROFILE.mobile,
    fiscalYearDuration: (raw.fiscalYearDuration || '').trim() || DEFAULT_COMPANY_PROFILE.fiscalYearDuration,
    updatedAt: raw.updatedAt,
    updatedBy: raw.updatedBy,
  };
}

let firestoreSettingsSubscribed = false;

function initSystemSettingsSync() {
  if (firestoreSettingsSubscribed || typeof window === 'undefined') return;
  firestoreSettingsSubscribed = true;

  onSnapshot(
    SETTINGS_DOC_PATH,
    (snap) => {
      if (snap.exists()) {
        const data = snap.data() as SystemInventorySettings;
        const normalized: SystemInventorySettings = {
          allowNegativeStock: Boolean(data.allowNegativeStock),
          updatedAt: data.updatedAt,
          updatedBy: data.updatedBy,
        };
        localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(normalized));
        window.dispatchEvent(new Event('systemSettingsUpdated'));
      }
    },
    (err) => {
      console.error('Error syncing system inventory settings:', err);
    }
  );

  onSnapshot(
    COMPANY_PROFILE_DOC_PATH,
    (snap) => {
      if (snap.exists()) {
        const data = snap.data() as Partial<CompanyProfileSettings>;
        const normalized = normalizeCompanyProfile(data);
        localStorage.setItem(COMPANY_PROFILE_STORAGE_KEY, JSON.stringify(normalized));
        window.dispatchEvent(new Event('companyProfileUpdated'));
      }
    },
    (err) => {
      console.error('Error syncing company profile settings:', err);
    }
  );
}

initSystemSettingsSync();

export function getCompanyProfile(): CompanyProfileSettings {
  try {
    const raw = localStorage.getItem(COMPANY_PROFILE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return normalizeCompanyProfile(parsed);
    }
  } catch (e) {
    console.error('Failed to read company profile settings:', e);
  }
  return { ...DEFAULT_COMPANY_PROFILE };
}

export function saveCompanyProfile(
  settings: Partial<CompanyProfileSettings>,
  updatedBy?: string
): CompanyProfileSettings {
  const current = getCompanyProfile();
  const normalized: CompanyProfileSettings = {
    companyName: (settings.companyName ?? current.companyName).trim() || DEFAULT_COMPANY_PROFILE.companyName,
    address: (settings.address ?? current.address).trim() || DEFAULT_COMPANY_PROFILE.address,
    mobile: (settings.mobile ?? current.mobile).trim() || DEFAULT_COMPANY_PROFILE.mobile,
    fiscalYearDuration: (settings.fiscalYearDuration ?? current.fiscalYearDuration).trim() || DEFAULT_COMPANY_PROFILE.fiscalYearDuration,
    updatedAt: new Date().toISOString(),
    updatedBy: updatedBy || settings.updatedBy || 'Admin',
  };
  try {
    localStorage.setItem(COMPANY_PROFILE_STORAGE_KEY, JSON.stringify(normalized));
    window.dispatchEvent(new Event('companyProfileUpdated'));
    setDoc(COMPANY_PROFILE_DOC_PATH, normalized, { merge: true }).catch((err) => {
      console.error('Failed to sync company profile settings to Firestore:', err);
    });
  } catch (e) {
    console.error('Failed to save company profile settings:', e);
  }
  return normalized;
}

export function subscribeCompanyProfile(
  callback: (profile: CompanyProfileSettings) => void
): () => void {
  const handler = () => {
    callback(getCompanyProfile());
  };
  window.addEventListener('companyProfileUpdated', handler);
  return () => {
    window.removeEventListener('companyProfileUpdated', handler);
  };
}

export function getSystemInventorySettings(): SystemInventorySettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        allowNegativeStock: Boolean(parsed.allowNegativeStock),
        updatedAt: parsed.updatedAt,
        updatedBy: parsed.updatedBy,
      };
    }
  } catch (e) {
    console.error('Failed to read system inventory settings:', e);
  }
  return { ...DEFAULT_SETTINGS };
}

export function saveSystemInventorySettings(
  settings: Partial<SystemInventorySettings>,
  updatedBy?: string
): SystemInventorySettings {
  const current = getSystemInventorySettings();
  const normalized: SystemInventorySettings = {
    allowNegativeStock: Boolean(settings.allowNegativeStock ?? current.allowNegativeStock),
    updatedAt: new Date().toISOString(),
    updatedBy: updatedBy || settings.updatedBy || 'Admin',
  };
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(normalized));
    window.dispatchEvent(new Event('systemSettingsUpdated'));
    setDoc(SETTINGS_DOC_PATH, normalized, { merge: true }).catch((err) => {
      console.error('Failed to sync system inventory settings to Firestore:', err);
    });
  } catch (e) {
    console.error('Failed to save system inventory settings:', e);
  }
  return normalized;
}

export function subscribeSystemInventorySettings(
  callback: (settings: SystemInventorySettings) => void
): () => void {
  const handler = () => {
    callback(getSystemInventorySettings());
  };
  window.addEventListener('systemSettingsUpdated', handler);
  return () => {
    window.removeEventListener('systemSettingsUpdated', handler);
  };
}

export async function fetchSystemInventorySettingsFromServer(): Promise<SystemInventorySettings> {
  try {
    const snap = await getDoc(SETTINGS_DOC_PATH);
    if (snap.exists()) {
      const data = snap.data() as SystemInventorySettings;
      const normalized: SystemInventorySettings = {
        allowNegativeStock: Boolean(data.allowNegativeStock),
        updatedAt: data.updatedAt,
        updatedBy: data.updatedBy,
      };
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(normalized));
      return normalized;
    }
  } catch (e) {
    console.error('Failed to fetch system inventory settings from server:', e);
  }
  return getSystemInventorySettings();
}
