export interface BankTransferRecord {
  id: string;
  transferNumber: string;
  transferDate: string;
  fromAccountCode: string;
  fromAccountName: string;
  toAccountCode: string;
  toAccountName: string;
  amount: number;
  transferMethod: 'BEFTN / RTGS' | 'Cheque Transfer' | 'Online Banking / App' | 'Cash Deposit / Float';
  referenceNumber: string;
  narration: string;
  voucherNumber: string;
  status: 'Completed' | 'Pending Clearing';
  timestamp: string;
}

const STORAGE_KEY = 'tradecore_bank_transfers_v1';
export const BANK_TRANSFERS_EVENT = 'tradecore_bank_transfers_changed';

export const INITIAL_BANK_TRANSFERS: BankTransferRecord[] = [
  {
    id: 'trf-101',
    transferNumber: 'TRF-2026-0042',
    transferDate: '2026-09-20',
    fromAccountCode: '1020',
    fromAccountName: 'Eastern Bank PLC - Current A/C',
    toAccountCode: '1010',
    toAccountName: 'Cash in Hand (Petty Cash Float)',
    amount: 150000,
    transferMethod: 'Cheque Transfer',
    referenceNumber: 'CHQ-771249',
    narration: 'Petty cash withdrawal for Sonahat crushing site labor and daily operational expenses',
    voucherNumber: 'Contra-2026-00088',
    status: 'Completed',
    timestamp: new Date().toISOString()
  },
  {
    id: 'trf-102',
    transferNumber: 'TRF-2026-0043',
    transferDate: '2026-09-24',
    fromAccountCode: '1025',
    fromAccountName: 'City Bank PLC - Principal Branch',
    toAccountCode: '1020',
    toAccountName: 'Eastern Bank PLC - Current A/C',
    amount: 2500000,
    transferMethod: 'BEFTN / RTGS',
    referenceNumber: 'RTGS-EBL-889102',
    narration: 'Fund transfer from City Bank to Eastern Bank for stone import LC and supplier bill settlement',
    voucherNumber: 'Contra-2026-00089',
    status: 'Completed',
    timestamp: new Date().toISOString()
  }
];

export function getBankTransfers(): BankTransferRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load bank transfers from storage', err);
  }
  return INITIAL_BANK_TRANSFERS;
}

export function saveBankTransfers(transfers: BankTransferRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(transfers));
    window.dispatchEvent(new CustomEvent(BANK_TRANSFERS_EVENT, { detail: { transfers } }));
  } catch (err) {
    console.error('Failed to save bank transfers', err);
  }
}

export function addBankTransfer(record: BankTransferRecord): void {
  const current = getBankTransfers();
  const next = [record, ...current];
  saveBankTransfers(next);
}

export function subscribeBankTransfers(callback: (transfers: BankTransferRecord[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ transfers: BankTransferRecord[] }>;
    if (customEvt.detail?.transfers) {
      callback(customEvt.detail.transfers);
    } else {
      callback(getBankTransfers());
    }
  };

  window.addEventListener(BANK_TRANSFERS_EVENT, handler);
  return () => window.removeEventListener(BANK_TRANSFERS_EVENT, handler);
}
