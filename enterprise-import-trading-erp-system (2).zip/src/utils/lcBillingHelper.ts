import { LetterOfCredit, LCRateBatch } from '../types/erp';

export interface LcBillCalculation {
  contractQty: number;
  receivedQty: number;
  excessQty: number;
  excessPercent: number;
  isOverReceived: boolean;
  remainingQty: number;
  hasReceiving: boolean;
  billableQty: number;

  // Rates
  exchangeRate: number;
  weightedOfficialRate: number;
  weightedActualRate: number;
  weightedAverageCommercialRate: number;
  weightedAverageOfficialRate: number;
  weightedAverageActualRate: number;
  weightedAverageExchangeRate: number;

  // Bill totals
  officialBillForeign: number;
  officialBillBdt: number;
  commercialBillForeign: number;
  commercialBillBdt: number;
  hundiGapForeign: number;
  hundiGapBdt: number;

  // Settlements & Payments (non-voided)
  totalBankSettledForeign: number;
  totalBankSettledBdt: number;
  remainingBankDueForeign: number;
  remainingBankDueBdt: number;

  totalHundiPaidBdt: number;
  totalHundiPaidForeign: number;
  remainingHundiDueBdt: number;
  remainingHundiDueForeign: number;

  // Total balance due
  totalAdditionalDueBdt: number;

  // Flags
  isGoodsReceived: boolean;
  isBankSettled: boolean;
  isHundiSettled: boolean;
  isClosed: boolean;
  isReceivingCompleted: boolean;
}

/**
 * Computes the LC Bill from receivings and rate batches.
 * billableQty = receivedQty once any non-deleted receiving exists, otherwise contractQty.
 * If bankBillForExtraQty === 'cap_at_lc', official bill is capped at contractQty * official rate,
 * and excess quantity flows purely into the commercial bill (widening the hundi gap).
 */
export function computeLcBill(lc: LetterOfCredit): LcBillCalculation {
  const contractQty = Number(lc.quantity) || 0;

  // 1. Calculate received quantity strictly from non-deleted receiving records
  const receivingsList = (lc.receivings || (lc as any).receivingRecords || []).filter(
    (r: any) => !r.isDeleted && !r.voided && !r.isVoid && r.status !== 'Voided'
  );
  const hasReceiving = receivingsList.length > 0;

  const rawReceived = receivingsList.reduce((sum: number, r: any) => {
    const q = Number(r.netReceivedMt ?? r.netWeightMt ?? r.receivedQuantity ?? r.quantityReceived ?? r.receivedQty ?? 0);
    return sum + (isNaN(q) ? 0 : q);
  }, 0);

  const receivedQty = Math.round(rawReceived * 1000) / 1000;
  const excessQty = Math.max(0, Math.round((receivedQty - contractQty) * 1000) / 1000);
  const excessPercent = contractQty > 0 ? (excessQty / contractQty) * 100 : 0;
  const isOverReceived = excessQty > 0;
  const remainingQty = Math.round((contractQty - receivedQty) * 1000) / 1000;

  // billableQty = receivedQty once any receiving exists (or if marked completed with short receiving), otherwise contractQty
  let billableQty = hasReceiving ? receivedQty : contractQty;
  if (lc.isReceivingCompleted && !hasReceiving) {
    billableQty = 0;
  }
  billableQty = Math.max(0, Math.round(billableQty * 1000) / 1000);

  // Exchange rate fallback: prioritize LC's own rateBdt or exchangeRate, never hardcoded 122.50
  const exchangeRate = Number(lc.rateBdt || lc.exchangeRate || 1);

  // 2. Compute batches & rates
  const batches = (lc.rateBatches || []).filter((b: any) => !b.isDeleted && !b.isVoid);

  let weightedOfficialRate = 0;
  let weightedActualRate = 0;
  let totalCommercialBillForeign = 0;
  let totalOfficialBillForeign = 0;

  const defaultOfficialRate = Number(lc.officialLcRate || lc.lcBankRateUsd || (lc as any).rate || 0);
  const defaultActualRate = Number(lc.actualRate || lc.contractRateUsd || (lc as any).rate || 0);

  if (batches.length > 0) {
    let sumOfficialAmount = 0;
    let sumCommercialAmount = 0;
    let sumBatchQty = 0;

    for (const batch of batches) {
      const bQty = Number(batch.quantity) || 0;
      const bOfficial = Number(batch.officialRate) || 0;
      const bActual = Number(batch.actualRate) || 0;

      sumBatchQty += bQty;
      sumOfficialAmount += bQty * bOfficial;
      sumCommercialAmount += bQty * bActual;
    }

    if (sumBatchQty > 0) {
      weightedOfficialRate = sumOfficialAmount / sumBatchQty;
      weightedActualRate = sumCommercialAmount / sumBatchQty;
    } else {
      weightedOfficialRate = defaultOfficialRate;
      weightedActualRate = defaultActualRate;
    }

    // If batches sum matches billableQty (or batches are maintained), use batch totals directly,
    // otherwise scale by billableQty / sumBatchQty if needed or use weighted rates * billableQty.
    if (Math.abs(sumBatchQty - billableQty) < 0.001) {
      totalOfficialBillForeign = sumOfficialAmount;
      totalCommercialBillForeign = sumCommercialAmount;
    } else {
      totalOfficialBillForeign = billableQty * weightedOfficialRate;
      totalCommercialBillForeign = billableQty * weightedActualRate;
    }
  } else {
    weightedOfficialRate = defaultOfficialRate;
    weightedActualRate = defaultActualRate;
    totalOfficialBillForeign = billableQty * weightedOfficialRate;
    totalCommercialBillForeign = billableQty * weightedActualRate;
  }

  // 3. Official Bank Bill Switch
  // 'cap_at_lc': officialBill is capped at contractQty * official rate, extra quantity is shifted to commercial bill only.
  const bankBillSetting = lc.bankBillForExtraQty || 'follow_received';
  let officialBillForeign = totalOfficialBillForeign;
  let commercialBillForeign = totalCommercialBillForeign;

  if (bankBillSetting === 'cap_at_lc' && billableQty > contractQty) {
    // Official bill stays at contractQty * weightedOfficialRate
    officialBillForeign = contractQty * weightedOfficialRate;
    // Commercial bill remains total commercial bill
  }

  const officialBillBdt = officialBillForeign * exchangeRate;
  const commercialBillBdt = commercialBillForeign * exchangeRate;
  const hundiGapForeign = Math.max(0, commercialBillForeign - officialBillForeign);
  const hundiGapBdt = hundiGapForeign * exchangeRate;

  // 4. Non-voided Bank Settlements
  const settlements = (lc.bankSettlements || []).filter(
    (s: any) => !s.isDeleted && !s.isVoid && !s.voided && s.status !== 'Voided'
  );
  const totalBankSettledForeign = settlements.reduce(
    (acc, s: any) => acc + (Number(s.amountForeign ?? s.foreignAmountSettled) || 0),
    0
  );
  const totalBankSettledBdt = settlements.reduce((acc, s: any) => {
    const bdt = Number(s.amountLocalBdt ?? s.bdtAmountDebited ?? ((Number(s.amountForeign ?? s.foreignAmountSettled) || 0) * (Number(s.exchangeRate ?? s.appliedExchangeRate) || exchangeRate)));
    return acc + bdt;
  }, 0);

  const remainingBankDueForeign = Math.max(
    0,
    Math.round((officialBillForeign - totalBankSettledForeign) * 100) / 100
  );
  const remainingBankDueBdt = Math.round(remainingBankDueForeign * exchangeRate * 100) / 100;

  // 5. Non-voided Hundi Payments
  const hundiPayments = (lc.hundiPayments || []).filter(
    (h: any) => !h.isDeleted && !h.isVoid && !h.voided && h.status !== 'Voided'
  );
  const totalHundiPaidBdt = hundiPayments.reduce(
    (acc, h: any) => acc + (Number(h.amountBdt ?? h.paymentAmountBdt) || 0),
    0
  );
  const totalHundiPaidForeign = exchangeRate > 0 ? totalHundiPaidBdt / exchangeRate : 0;

  const remainingHundiDueBdt = Math.max(
    0,
    Math.round((hundiGapBdt - totalHundiPaidBdt) * 100) / 100
  );
  const remainingHundiDueForeign = exchangeRate > 0 ? remainingHundiDueBdt / exchangeRate : 0;

  const totalAdditionalDueBdt = remainingBankDueBdt + remainingHundiDueBdt;

  // 6. Milestone Flags
  const isGoodsReceived = hasReceiving && (lc.isReceivingCompleted ? true : receivedQty >= contractQty * 0.99);
  const isBankSettled = officialBillForeign > 0 && remainingBankDueForeign <= 0.05;
  const isHundiSettled = hundiGapBdt <= 0.05 || remainingHundiDueBdt <= 5.0; // small rounding tolerance
  const isClosed = isGoodsReceived && isBankSettled && isHundiSettled;

  return {
    contractQty,
    receivedQty,
    excessQty,
    excessPercent,
    isOverReceived,
    remainingQty,
    hasReceiving,
    billableQty,

    exchangeRate,
    weightedOfficialRate,
    weightedActualRate,
    weightedAverageCommercialRate: weightedActualRate,
    weightedAverageOfficialRate: weightedOfficialRate,
    weightedAverageActualRate: weightedActualRate,
    weightedAverageExchangeRate: exchangeRate,

    officialBillForeign,
    officialBillBdt,
    commercialBillForeign,
    commercialBillBdt,
    hundiGapForeign,
    hundiGapBdt,

    totalBankSettledForeign,
    totalBankSettledBdt,
    remainingBankDueForeign,
    remainingBankDueBdt,

    totalHundiPaidBdt,
    totalHundiPaidForeign,
    remainingHundiDueBdt,
    remainingHundiDueForeign,

    totalAdditionalDueBdt,

    isGoodsReceived,
    isBankSettled,
    isHundiSettled,
    isClosed,
    isReceivingCompleted: !!lc.isReceivingCompleted
  };
}

/**
 * Ensures rate batches sum to billableQty.
 * When receivedQty is more than the sum of user batches, automatically creates or updates
 * an auto system batch named "অতিরিক্ত রিসিভ (Extra Received)" holding the difference.
 * Starts with official and actual rate of the last batch (or LC default), and user can edit it.
 * Marked with isAuto: true.
 * When receiving is reduced, shrinks or removes the auto batch.
 */
export function ensureRateBatchesForBillableQty(
  lc: LetterOfCredit,
  billableQty: number
): LCRateBatch[] {
  const currentBatches: LCRateBatch[] = (lc.rateBatches || []).filter(
    (b: any) => !b.isVoid && !b.isDeleted
  );

  if (billableQty <= 0) {
    return currentBatches;
  }

  const manualBatches = currentBatches.filter((b) => !b.isAuto);
  const existingAutoBatch = currentBatches.find((b) => b.isAuto);

  const manualSum = manualBatches.reduce((acc, b) => acc + (Number(b.quantity) || 0), 0);

  // If no manual batches exist, generate a primary batch
  if (manualBatches.length === 0) {
    const defaultOfficial = Number(lc.officialLcRate || lc.lcBankRateUsd || (lc as any).rate || 0);
    const defaultActual = Number(lc.actualRate || lc.contractRateUsd || (lc as any).rate || defaultOfficial);
    const rateDiff = Math.max(0, defaultActual - defaultOfficial);

    return [
      {
        id: `batch-${Date.now()}-1`,
        batchName: '১ম লট (মূল চুক্তি)',
        quantity: billableQty,
        uom: lc.uom || 'MT',
        officialRate: defaultOfficial,
        actualRate: defaultActual,
        rateDifference: rateDiff,
        totalOfficialAmount: billableQty * defaultOfficial,
        totalCommercialAmount: billableQty * defaultActual,
        differentialAmount: billableQty * rateDiff,
        date: lc.openingDate || new Date().toISOString().split('T')[0],
        notes: 'মূল চুক্তি পরিমাণ'
      }
    ];
  }

  const difference = Math.round((billableQty - manualSum) * 1000) / 1000;

  if (difference <= 0.0001) {
    // No extra quantity needed; remove auto batch if it exists
    return manualBatches;
  }

  // We have excess quantity beyond manual batches!
  // Pick default rates from last manual batch or existing auto batch
  const lastBatch = manualBatches[manualBatches.length - 1];
  const officialRate = existingAutoBatch?.officialRate ?? lastBatch.officialRate;
  const actualRate = existingAutoBatch?.actualRate ?? lastBatch.actualRate;
  const rateDifference = actualRate - officialRate;

  const autoBatch: LCRateBatch = {
    id: existingAutoBatch?.id || `batch-auto-extra-${Date.now()}`,
    batchName: 'অতিরিক্ত রিসিভ (Extra Received)',
    quantity: difference,
    uom: lc.uom || 'MT',
    officialRate,
    actualRate,
    rateDifference,
    totalOfficialAmount: difference * officialRate,
    totalCommercialAmount: difference * actualRate,
    differentialAmount: difference * rateDifference,
    date: existingAutoBatch?.date || new Date().toISOString().split('T')[0],
    notes: 'অতিরিক্ত রিসিভকৃত মালের জন্য স্বয়ংক্রিয় ব্যাচ (রেট পরিবর্তনযোগ্য)',
    isAuto: true
  };

  return [...manualBatches, autoBatch];
}
