import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  onSnapshot, 
  writeBatch 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Customer } from '../types/erp';

const CUSTOMERS_STORAGE_KEY = 'tradecore_customers_v1';
export const CUSTOMERS_EVENT_NAME = 'tradecore_customers_changed';

// Step D: remove all seeded demo data. A new installation must start empty.
export const INITIAL_CUSTOMERS: Customer[] = [];

// In-memory cache initialized from offline cache (localStorage)
let cachedCustomers: Customer[] = (() => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(CUSTOMERS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to parse customers from localStorage:', err);
  }
  return INITIAL_CUSTOMERS;
})();

const subscribers = new Set<(customers: Customer[]) => void>();

function notifySubscribers(customers: Customer[]) {
  cachedCustomers = customers;
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(CUSTOMERS_STORAGE_KEY, JSON.stringify(customers));
      window.dispatchEvent(new CustomEvent(CUSTOMERS_EVENT_NAME, { detail: { customers } }));
    }
  } catch (e) {
    console.error('Failed to update localStorage for customers:', e);
  }
  subscribers.forEach(cb => {
    try {
      cb(customers);
    } catch (e) {
      console.error('Subscriber callback error in customers:', e);
    }
  });
}

// Step B: Real-time listener using onSnapshot from Firestore
if (typeof window !== 'undefined') {
  try {
    const colRef = collection(db, 'customers');
    onSnapshot(colRef, (snapshot) => {
      const items: Customer[] = [];
      snapshot.forEach(docSnap => {
        items.push({ id: docSnap.id, ...docSnap.data() } as Customer);
      });
      notifySubscribers(items);
    }, (error) => {
      console.error('Firestore onSnapshot error for customers:', error);
    });
  } catch (e) {
    console.error('Failed to attach onSnapshot to customers:', e);
  }
}

/**
 * Returns currently cached customers
 */
export function getCustomers(): Customer[] {
  return cachedCustomers;
}

/**
 * Strips undefined properties before writing to Firestore.
 */
function sanitizeCustomerForFirestore(c: Customer): Record<string, any> {
  const result: Record<string, any> = {};
  Object.entries(c).forEach(([key, value]) => {
    if (value !== undefined) {
      result[key] = value;
    }
  });
  return result;
}

/**
 * Save customers batch to Firestore and update cache.
 */
export function saveCustomers(customers: Customer[]): void {
  notifySubscribers(customers);

  const batch = writeBatch(db);
  customers.forEach(c => {
    const ref = doc(db, 'customers', c.id);
    batch.set(ref, sanitizeCustomerForFirestore(c), { merge: true });
  });
  batch.commit().catch(err => {
    console.error('Firestore batch write failed for customers:', err);
    throw err;
  });
}

/**
 * Update a customer in Firestore.
 */
export function updateCustomer(updated: Customer): Customer[] {
  const current = getCustomers();
  const next = current.map(c => c.id === updated.id ? updated : c);
  notifySubscribers(next);

  const docRef = doc(db, 'customers', updated.id);
  setDoc(docRef, sanitizeCustomerForFirestore(updated), { merge: true }).catch(err => {
    console.error('Failed to update customer in Firestore:', err);
    throw err;
  });

  return next;
}

/**
 * Get the customer's currently available advance balance.
 */
export function getCustomerAvailableAdvance(c?: Partial<Customer> | null): number {
  if (!c) return 0;
  if (typeof c.advanceBalance === 'number' && !isNaN(c.advanceBalance)) {
    return Math.max(0, Number(c.advanceBalance));
  }
  const curBal = Number(c.currentBalance) || 0;
  return curBal < 0 ? Math.abs(curBal) : 0;
}

/**
 * Adjust a customer's running balance in Firestore.
 */
export function updateCustomerBalance(
  customerId: string, 
  delta: number, 
  advanceDelta: number = 0
): { updatedCustomer?: Customer; allCustomers: Customer[] } {
  const current = getCustomers();
  let updatedCust: Customer | undefined;

  const next = current.map(c => {
    if (c.id === customerId) {
      const prevBal = Number(c.currentBalance) || 0;
      const prevAdv = getCustomerAvailableAdvance(c);
      const newBalance = prevBal + delta;
      const newAdvance =
        advanceDelta !== 0
          ? Math.max(0, Number((prevAdv + advanceDelta).toFixed(2)))
          : newBalance < 0
          ? Math.abs(newBalance)
          : prevAdv;
      updatedCust = {
        ...c,
        currentBalance: newBalance,
        advanceBalance: newAdvance
      };
      return updatedCust;
    }
    return c;
  });

  notifySubscribers(next);

  if (updatedCust) {
    const docRef = doc(db, 'customers', customerId);
    updateDoc(docRef, {
      currentBalance: updatedCust.currentBalance,
      advanceBalance: updatedCust.advanceBalance
    }).catch(err => {
      console.error('Failed to update customer balance in Firestore:', err);
      throw err;
    });
  }

  return { updatedCustomer: updatedCust, allCustomers: next };
}

/**
 * Subscribe to customers with real-time updates
 */
export function subscribeCustomers(callback: (customers: Customer[]) => void): () => void {
  subscribers.add(callback);
  callback(cachedCustomers);

  return () => {
    subscribers.delete(callback);
  };
}

/**
 * Formats customer balance with explicit Advance display for negative values
 */
export function formatCustomerBalance(balance: number, currency: string = 'BDT'): {
  text: string;
  isAdvance: boolean;
  isDue: boolean;
  amountText: string;
} {
  const absVal = Math.abs(balance);
  const formatted = currency === 'USD' 
    ? `$${(absVal / 122.5).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` 
    : `৳${absVal.toLocaleString('en-IN')}`;

  if (balance < 0) {
    return {
      text: `Advance: ${formatted}`,
      isAdvance: true,
      isDue: false,
      amountText: formatted
    };
  } else if (balance > 0) {
    return {
      text: `Due: ${formatted}`,
      isAdvance: false,
      isDue: true,
      amountText: formatted
    };
  }
  return {
    text: `Settled`,
    isAdvance: false,
    isDue: false,
    amountText: currency === 'USD' ? '$0' : '৳0'
  };
}
