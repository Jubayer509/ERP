import { AccountCOA, JournalVoucher } from '../types/erp';
import { MOCK_COA } from '../data/mockErpData';

const COA_STORAGE_KEY = 'tradecore_coa_v1';
export const COA_EVENT_NAME = 'tradecore_coa_changed';

// Default Chart of Accounts with specialized stone crushing and operations heads
export const DEFAULT_COA_LIST: AccountCOA[] = [
  ...MOCK_COA.filter(a => !['5200', '5210', '5220', '5100', '5120'].includes(a.code)),
  // 1011 Burimari Petty Cash
  {
    code: '1011',
    name: 'Burimari Petty Cash',
    category: 'Asset',
    subCategory: 'Cash & Bank',
    balance: 350000,
    normalBalance: 'Debit',
    isParent: false
  },
  // 1012 Sonahat Petty Cash
  {
    code: '1012',
    name: 'Sonahat Petty Cash',
    category: 'Asset',
    subCategory: 'Cash & Bank',
    balance: 450000,
    normalBalance: 'Debit',
    isParent: false
  },
  // 1022 Dutch-Bangla Bank (DBBL)
  {
    code: '1022',
    name: 'Dutch-Bangla Bank (DBBL) - Corporate',
    category: 'Asset',
    subCategory: 'Cash & Bank',
    balance: 4500000,
    normalBalance: 'Debit',
    isParent: false
  },
  // 5200 Stone Crushing Cost
  {
    code: '5200',
    name: 'Stone Crushing Cost',
    category: 'Expense',
    subCategory: 'Direct Crushing Cost',
    balance: 245000,
    normalBalance: 'Debit',
    isParent: false
  },
  // 5210 Crushing Labour Bill
  {
    code: '5210',
    name: 'Crushing Labour Bill',
    category: 'Expense',
    subCategory: 'Direct Crushing Cost',
    balance: 120000,
    normalBalance: 'Debit',
    isParent: false
  },
  // 5220 Crushing Electricity Bill
  {
    code: '5220',
    name: 'Crushing Electricity Bill',
    category: 'Expense',
    subCategory: 'Direct Crushing Cost',
    balance: 85000,
    normalBalance: 'Debit',
    isParent: false
  },
  // 5100 Office & Administrative Expense
  {
    code: '5100',
    name: 'Office & Admin Expense',
    category: 'Expense',
    subCategory: 'Administrative Expenses',
    balance: 45000,
    normalBalance: 'Debit',
    isParent: false
  },
  // 5120 Fuel & Generator Cost
  {
    code: '5120',
    name: 'Fuel & Generator Cost',
    category: 'Expense',
    subCategory: 'Direct Crushing Cost',
    balance: 35000,
    normalBalance: 'Debit',
    isParent: false
  }
];

/**
 * Load Chart of Accounts from storage or fallback to defaults
 */
export function getCOA(): AccountCOA[] {
  try {
    const raw = localStorage.getItem(COA_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure standard heads exist (5200, 5210, 5220, 5100, 5120)
        let needsSave = false;
        const currentList = [...parsed];

        const requiredHeads = [
          { code: '1011', name: 'Burimari Petty Cash', category: 'Asset' as const, subCategory: 'Cash & Bank', balance: 350000 },
          { code: '1012', name: 'Sonahat Petty Cash', category: 'Asset' as const, subCategory: 'Cash & Bank', balance: 450000 },
          { code: '1022', name: 'Dutch-Bangla Bank (DBBL) - Corporate', category: 'Asset' as const, subCategory: 'Cash & Bank', balance: 4500000 },
          { code: '5200', name: 'Stone Crushing Cost', category: 'Expense' as const, subCategory: 'Direct Crushing Cost', balance: 245000 },
          { code: '5210', name: 'Crushing Labour Bill', category: 'Expense' as const, subCategory: 'Direct Crushing Cost', balance: 120000 },
          { code: '5220', name: 'Crushing Electricity Bill', category: 'Expense' as const, subCategory: 'Direct Crushing Cost', balance: 85000 },
          { code: '5100', name: 'Office & Admin Expense', category: 'Expense' as const, subCategory: 'Administrative Expenses', balance: 45000 },
          { code: '5120', name: 'Fuel & Generator Cost', category: 'Expense' as const, subCategory: 'Direct Crushing Cost', balance: 35000 }
        ];

        for (const req of requiredHeads) {
          if (!currentList.some(a => a.code === req.code)) {
            currentList.push({
              code: req.code,
              name: req.name,
              category: req.category,
              subCategory: req.subCategory,
              balance: req.balance,
              normalBalance: req.category === 'Asset' ? 'Debit' : 'Debit',
              isParent: false
            });
            needsSave = true;
          }
        }

        if (needsSave) {
          saveCOA(currentList);
        }
        return currentList;
      }
    }
  } catch (err) {
    console.error('Failed to load COA from storage', err);
  }
  return DEFAULT_COA_LIST;
}

/**
 * Save COA and broadcast change event
 */
export function saveCOA(list: AccountCOA[]): void {
  try {
    localStorage.setItem(COA_STORAGE_KEY, JSON.stringify(list));
    window.dispatchEvent(new CustomEvent(COA_EVENT_NAME, { detail: { coa: list } }));
  } catch (err) {
    console.error('Failed to save COA to storage', err);
  }
}

/**
 * Add a new Account Head to COA
 */
export function addAccountHead(newHead: AccountCOA): AccountCOA[] {
  const current = getCOA();
  if (current.some(c => c.code === newHead.code)) {
    return current;
  }
  const updated = [...current, newHead].sort((a, b) => a.code.localeCompare(b.code));
  saveCOA(updated);
  return updated;
}

/**
 * Update an existing Account Head
 */
export function updateAccountHead(updatedHead: AccountCOA): AccountCOA[] {
  const current = getCOA();
  const updated = current.map(item => (item.code === updatedHead.code ? updatedHead : item));
  saveCOA(updated);
  return updated;
}

/**
 * Delete an Account Head
 */
export function deleteAccountHead(code: string): AccountCOA[] {
  const current = getCOA();
  const updated = current.filter(item => item.code !== code);
  saveCOA(updated);
  return updated;
}

/**
 * Subscribe to COA changes
 */
export function subscribeCOA(callback: (list: AccountCOA[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ coa: AccountCOA[] }>;
    if (customEvt.detail?.coa) {
      callback(customEvt.detail.coa);
    } else {
      callback(getCOA());
    }
  };

  window.addEventListener(COA_EVENT_NAME, handler);
  return () => window.removeEventListener(COA_EVENT_NAME, handler);
}

/**
 * Get the single consolidated account under Stone Crushing Cost
 */
export function getStoneCrushingCostAccounts(): AccountCOA[] {
  return getCOA().filter(a => a.code === '5200');
}
