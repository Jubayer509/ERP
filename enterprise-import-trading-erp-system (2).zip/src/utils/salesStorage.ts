import { SalesInvoice, SalesOrder, CustomerPayment } from '../types/erp';
import { MOCK_SALES_INVOICES, MOCK_SALES_ORDERS, MOCK_CUSTOMER_PAYMENTS } from '../data/mockErpData';

const SALES_STORAGE_KEY = 'tradecore_sales_invoices_v1';
export const SALES_EVENT_NAME = 'tradecore_sales_invoices_updated';

const ORDERS_STORAGE_KEY = 'tradecore_sales_orders_v1';
export const ORDERS_EVENT_NAME = 'tradecore_sales_orders_updated';

const PAYMENTS_STORAGE_KEY = 'tradecore_customer_payments_v1';
export const PAYMENTS_EVENT_NAME = 'tradecore_customer_payments_updated';

/**
 * Get all sales invoices from storage or fallback to mock data
 */
export function getSalesInvoices(): SalesInvoice[] {
  try {
    const raw = localStorage.getItem(SALES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to parse sales invoices from storage:', err);
  }
  return MOCK_SALES_INVOICES;
}

/**
 * Save sales invoices to storage and notify all listeners
 */
export function saveSalesInvoices(invoices: SalesInvoice[]): void {
  try {
    localStorage.setItem(SALES_STORAGE_KEY, JSON.stringify(invoices));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(SALES_EVENT_NAME, { detail: invoices }));
    }
  } catch (err) {
    console.error('Failed to save sales invoices to storage:', err);
  }
}

/**
 * Add a new sales invoice
 */
export function addSalesInvoice(invoice: SalesInvoice): void {
  const current = getSalesInvoices();
  const updated = [invoice, ...current];
  saveSalesInvoices(updated);
}

/**
 * Update an existing sales invoice
 */
export function updateSalesInvoice(updatedInvoice: SalesInvoice): void {
  const current = getSalesInvoices();
  const updated = current.map(inv => inv.id === updatedInvoice.id ? updatedInvoice : inv);
  saveSalesInvoices(updated);
}

/**
 * Delete a sales invoice
 */
export function deleteSalesInvoice(id: string): void {
  const current = getSalesInvoices();
  const updated = current.filter(inv => inv.id !== id);
  saveSalesInvoices(updated);
}

/**
 * Subscribe to sales invoice changes
 */
export function subscribeSalesInvoices(callback: (invoices: SalesInvoice[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvent = e as CustomEvent<SalesInvoice[]>;
    if (customEvent.detail) {
      callback(customEvent.detail);
    } else {
      callback(getSalesInvoices());
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener(SALES_EVENT_NAME, handler);
  }

  return () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener(SALES_EVENT_NAME, handler);
    }
  };
}

/**
 * Get all sales orders from storage or fallback to mock data
 */
export function getSalesOrders(): SalesOrder[] {
  try {
    const raw = localStorage.getItem(ORDERS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to parse sales orders from storage:', err);
  }
  return MOCK_SALES_ORDERS;
}

/**
 * Save sales orders to storage and notify all listeners
 */
export function saveSalesOrders(orders: SalesOrder[]): void {
  try {
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(ORDERS_EVENT_NAME, { detail: orders }));
    }
  } catch (err) {
    console.error('Failed to save sales orders to storage:', err);
  }
}

/**
 * Subscribe to sales orders changes
 */
export function subscribeSalesOrders(callback: (orders: SalesOrder[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvent = e as CustomEvent<SalesOrder[]>;
    if (customEvent.detail) {
      callback(customEvent.detail);
    } else {
      callback(getSalesOrders());
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener(ORDERS_EVENT_NAME, handler);
  }

  return () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener(ORDERS_EVENT_NAME, handler);
    }
  };
}

/**
 * Get all customer payments from storage or fallback to mock data
 */
export function getCustomerPayments(): CustomerPayment[] {
  try {
    const raw = localStorage.getItem(PAYMENTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to parse customer payments from storage:', err);
  }
  return MOCK_CUSTOMER_PAYMENTS;
}

/**
 * Save customer payments to storage and notify all listeners
 */
export function saveCustomerPayments(payments: CustomerPayment[]): void {
  try {
    localStorage.setItem(PAYMENTS_STORAGE_KEY, JSON.stringify(payments));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(PAYMENTS_EVENT_NAME, { detail: payments }));
    }
  } catch (err) {
    console.error('Failed to save customer payments to storage:', err);
  }
}

/**
 * Subscribe to customer payments changes
 */
export function subscribeCustomerPayments(callback: (payments: CustomerPayment[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvent = e as CustomEvent<CustomerPayment[]>;
    if (customEvent.detail) {
      callback(customEvent.detail);
    } else {
      callback(getCustomerPayments());
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener(PAYMENTS_EVENT_NAME, handler);
  }

  return () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener(PAYMENTS_EVENT_NAME, handler);
    }
  };
}
