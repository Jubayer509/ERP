import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  writeBatch 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Supplier, LetterOfCredit } from '../types/erp';

const STORAGE_KEY = 'tradecore_suppliers_v1';
const EVENT_NAME = 'tradecore_suppliers_changed';

// Step D: remove all seeded demo data. A new installation must start empty.
export const INITIAL_SUPPLIERS: Supplier[] = [];

// In-memory cache initialized from offline cache (localStorage)
let cachedSuppliers: Supplier[] = (() => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to parse suppliers from localStorage:', err);
  }
  return INITIAL_SUPPLIERS;
})();

const subscribers = new Set<(suppliers: Supplier[]) => void>();

function notifySubscribers(suppliers: Supplier[]) {
  cachedSuppliers = suppliers;
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(suppliers));
      window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { suppliers } }));
    }
  } catch (e) {
    console.error('Failed to update localStorage for suppliers:', e);
  }
  subscribers.forEach(cb => {
    try {
      cb(suppliers);
    } catch (e) {
      console.error('Subscriber callback error in suppliers:', e);
    }
  });
}

// Step B: Real-time listener using onSnapshot from Firestore
if (typeof window !== 'undefined') {
  try {
    const colRef = collection(db, 'suppliers');
    onSnapshot(colRef, (snapshot) => {
      const items: Supplier[] = [];
      snapshot.forEach(docSnap => {
        items.push({ id: docSnap.id, ...docSnap.data() } as Supplier);
      });
      notifySubscribers(items);
    }, (error) => {
      console.error('Firestore onSnapshot error for suppliers:', error);
    });
  } catch (e) {
    console.error('Failed to attach onSnapshot to suppliers:', e);
  }
}

/**
 * Returns currently cached suppliers
 */
export function getSuppliers(): Supplier[] {
  return cachedSuppliers;
}

/**
 * Strips undefined properties before writing to Firestore.
 */
function sanitizeSupplierForFirestore(s: Supplier): Record<string, any> {
  const result: Record<string, any> = {};
  Object.entries(s).forEach(([key, value]) => {
    if (value !== undefined) {
      result[key] = value;
    }
  });
  return result;
}

/**
 * Save suppliers batch to Firestore and update cache.
 */
export function saveSuppliers(suppliers: Supplier[]): void {
  notifySubscribers(suppliers);

  const batch = writeBatch(db);
  suppliers.forEach(s => {
    const ref = doc(db, 'suppliers', s.id);
    batch.set(ref, sanitizeSupplierForFirestore(s), { merge: true });
  });
  batch.commit().catch(err => {
    console.error('Firestore batch write failed for suppliers:', err);
    throw err;
  });
}

/**
 * Add a new supplier to Firestore.
 */
export function addSupplier(newSuppData: Omit<Supplier, 'id'> & { id?: string }): Supplier {
  const all = getSuppliers();
  const id = newSuppData.id || `supp-${Date.now()}`;
  const code = newSuppData.code || `SUPP-${(newSuppData.country || 'EX').slice(0, 2).toUpperCase()}-${String(all.length + 1).padStart(2, '0')}`;
  
  const created: Supplier = {
    ...newSuppData,
    id,
    code
  };

  const updated = [created, ...all];
  notifySubscribers(updated);

  const docRef = doc(db, 'suppliers', id);
  setDoc(docRef, sanitizeSupplierForFirestore(created)).catch(err => {
    console.error('Failed to create supplier in Firestore:', err);
    throw err;
  });

  return created;
}

/**
 * Update an existing supplier in Firestore.
 */
export function updateSupplier(updatedSupp: Supplier): Supplier[] {
  const all = getSuppliers();
  const updated = all.map(s => s.id === updatedSupp.id ? updatedSupp : s);
  notifySubscribers(updated);

  const docRef = doc(db, 'suppliers', updatedSupp.id);
  setDoc(docRef, sanitizeSupplierForFirestore(updatedSupp), { merge: true }).catch(err => {
    console.error('Failed to update supplier in Firestore:', err);
    throw err;
  });

  return updated;
}

/**
 * Delete a supplier from Firestore.
 */
export function deleteSupplier(id: string): Supplier[] {
  const all = getSuppliers();
  const updated = all.filter(s => s.id !== id);
  notifySubscribers(updated);

  const docRef = doc(db, 'suppliers', id);
  deleteDoc(docRef).catch(err => {
    console.error('Failed to delete supplier in Firestore:', err);
    throw err;
  });

  return updated;
}

/**
 * Update supplier payable balance in Firestore.
 */
export function updateSupplierPayableBalance(
  supplierId: string, 
  payableDelta: number
): { updatedSupplier?: Supplier; allSuppliers: Supplier[] } {
  const all = getSuppliers();
  let updatedSupp: Supplier | undefined;

  const next = all.map(s => {
    if (s.id === supplierId) {
      const newPayable = (s.currentPayable || 0) + payableDelta;
      updatedSupp = {
        ...s,
        currentPayable: newPayable
      };
      return updatedSupp;
    }
    return s;
  });

  notifySubscribers(next);

  if (updatedSupp) {
    const docRef = doc(db, 'suppliers', supplierId);
    updateDoc(docRef, {
      currentPayable: updatedSupp.currentPayable
    }).catch(err => {
      console.error('Failed to update supplier payable balance in Firestore:', err);
      throw err;
    });
  }

  return { updatedSupplier: updatedSupp, allSuppliers: next };
}

/**
 * Subscribe to suppliers with real-time updates
 */
export function subscribeSuppliers(callback: (suppliers: Supplier[]) => void): () => void {
  subscribers.add(callback);
  callback(cachedSuppliers);

  return () => {
    subscribers.delete(callback);
  };
}

export function getUniqueCompanyOwners(suppliers?: Supplier[], lcs?: LetterOfCredit[]): string[] {
  const suppList = suppliers || getSuppliers();
  const ownerSet = new Set<string>();

  ['Edu', 'Sanad', 'Munna Khan', 'Gawtom', 'Tashi Namgyal'].forEach(o => ownerSet.add(o));

  suppList.forEach(s => {
    if (s.companyOwner && s.companyOwner.trim()) {
      ownerSet.add(s.companyOwner.trim());
    }
  });

  if (lcs && Array.isArray(lcs)) {
    lcs.forEach(l => {
      if (l.companyOwner && l.companyOwner.trim()) {
        ownerSet.add(l.companyOwner.trim());
      }
    });
  }

  return Array.from(ownerSet);
}

/**
 * Formats supplier balance with explicit Advance display for negative values
 */
export function formatSupplierBalance(payable: number, currency: string = 'BDT'): {
  text: string;
  isAdvance: boolean;
  isPayable: boolean;
  amountText: string;
} {
  const absVal = Math.abs(payable);
  const formatted = currency === 'USD' 
    ? `$${(absVal / 122.5).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` 
    : `৳${absVal.toLocaleString('en-IN')}`;

  if (payable < 0) {
    return {
      text: `Advance: ${formatted}`,
      isAdvance: true,
      isPayable: false,
      amountText: formatted
    };
  } else if (payable > 0) {
    return {
      text: `Payable: ${formatted}`,
      isAdvance: false,
      isPayable: true,
      amountText: formatted
    };
  }
  return {
    text: `Settled`,
    isAdvance: false,
    isPayable: false,
    amountText: currency === 'USD' ? '$0' : '৳0'
  };
}
