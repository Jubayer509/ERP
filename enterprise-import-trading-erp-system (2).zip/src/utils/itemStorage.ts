import { InventoryItem, ItemCategoryRecord } from '../types/erp';
import { MOCK_ITEMS } from '../data/mockErpData';
import { getWarehouses } from './locationStorage';

const ITEMS_STORAGE_KEY = 'tradecore_inventory_items_v1';
const CATEGORIES_STORAGE_KEY = 'tradecore_item_categories_v1';

export const ITEMS_EVENT_NAME = 'tradecore_items_changed';
export const CATEGORIES_EVENT_NAME = 'tradecore_categories_changed';

export const DEFAULT_CATEGORIES: ItemCategoryRecord[] = [
  {
    id: 'cat-boulder',
    name: 'Boulder',
    description: 'Imported Boulder Stone (Bhutan, Indian & River Boulder)',
    status: 'Active',
    isDefault: true
  },
  {
    id: 'cat-crushed',
    name: 'Crushed Stone',
    description: 'Crushing Mill Graded Crushed Stone & Dust',
    status: 'Active',
    isDefault: true
  }
];

// Helper to normalize items with status
const normalizeItems = (items: InventoryItem[]): InventoryItem[] => {
  return items.map(item => ({
    ...item,
    status: item.status || 'Active'
  }));
};

/**
 * Load items from storage or fallback to MOCK_ITEMS
 */
export function getItems(): InventoryItem[] {
  try {
    const raw = localStorage.getItem(ITEMS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return normalizeItems(parsed);
      }
    }
  } catch (err) {
    console.error('Failed to load inventory items from storage', err);
  }
  return normalizeItems(MOCK_ITEMS);
}

/**
 * Load ONLY active items (excludes Inactive and Deleted items)
 * Used by Sales and Purchase Invoices
 */
export function getActiveItems(): InventoryItem[] {
  return getItems().filter(item => (item.status || 'Active') === 'Active');
}

/**
 * Save items and broadcast event
 */
export function saveItems(items: InventoryItem[]): void {
  try {
    const normalized = normalizeItems(items);
    localStorage.setItem(ITEMS_STORAGE_KEY, JSON.stringify(normalized));
    window.dispatchEvent(new CustomEvent(ITEMS_EVENT_NAME, { detail: { items: normalized } }));
  } catch (err) {
    console.error('Failed to save inventory items to storage', err);
  }
}

/**
 * Add a new item to inventory
 */
export function addItem(newItem: InventoryItem): InventoryItem[] {
  const current = getItems();
  const created: InventoryItem = {
    ...newItem,
    status: newItem.status || 'Active'
  };
  const updated = [created, ...current];
  saveItems(updated);
  return updated;
}

/**
 * Update an existing item
 */
export function updateItem(updatedItem: InventoryItem): InventoryItem[] {
  const current = getItems();
  const updated = current.map(item => (item.id === updatedItem.id ? updatedItem : item));
  saveItems(updated);
  return updated;
}

export function resolveWarehouseId(warehouseNameOrId?: string): string | undefined {
  if (!warehouseNameOrId) return undefined;
  const warehouses = getWarehouses();
  const exactId = warehouses.find(w => w.id === warehouseNameOrId);
  if (exactId) return exactId.id;
  const lower = warehouseNameOrId.toLowerCase().trim();
  if (lower.includes('sonahat') || lower.includes('সোনাহাট')) {
    const son = warehouses.find(w => w.id === 'wh-son' || w.name.toLowerCase().includes('sonahat'));
    return son ? son.id : 'wh-son';
  }
  if (lower.includes('burimari') || lower.includes('বুড়িমারী') || lower.includes('বুড়িমারী')) {
    const bur = warehouses.find(w => w.id === 'wh-bur' || w.name.toLowerCase().includes('burimari'));
    return bur ? bur.id : 'wh-bur';
  }
  if (lower.includes('chittagong') || lower.includes('চট্টগ্রাম') || lower.includes('ctg')) {
    return 'wh-cgp';
  }
  if (lower.includes('dhaka') || lower.includes('ঢাকা') || lower.includes('tejgaon')) {
    return 'wh-dhk';
  }
  if (lower.includes('bogra') || lower.includes('বগুড়া') || lower.includes('northern')) {
    return 'wh-bgr';
  }
  const exactName = warehouses.find(
    w => w.name.toLowerCase().trim() === lower || w.code.toLowerCase().trim() === lower
  );
  if (exactName) return exactName.id;
  const keywordMatch = warehouses.find(w => {
    const firstWord = w.name.toLowerCase().split(' ')[0];
    return firstWord && lower.includes(firstWord);
  });
  return keywordMatch ? keywordMatch.id : warehouseNameOrId;
}

export type CanonicalUom = 'Ton' | 'KG' | 'CFT' | 'Bags' | 'PCS' | 'Barrels' | 'Job' | string;

/**
 * Normalize UOM strings (including legacy Bengali and synonyms like Ton / MT)
 */
export function normalizeUom(uom?: string): CanonicalUom {
  if (!uom) return 'Ton';
  const raw = uom.trim().toLowerCase();
  if (
    raw === 'ton' ||
    raw === 'tons' ||
    raw === 'mt' ||
    raw === 'm.t' ||
    raw === 'm.t.' ||
    raw === 'metric ton' ||
    raw === 'metric tons' ||
    raw === 't' ||
    raw === 'টন' ||
    raw === 'মেট্রিক টন' ||
    raw.includes('metric ton') ||
    raw.includes('টন')
  ) {
    return 'Ton';
  }
  if (
    raw === 'kg' ||
    raw === 'kgs' ||
    raw === 'kilogram' ||
    raw === 'kilograms' ||
    raw === 'কেজি' ||
    raw.includes('কেজি')
  ) {
    return 'KG';
  }
  if (
    raw === 'cft' ||
    raw === 'cu.ft' ||
    raw === 'cu ft' ||
    raw === 'cubic feet' ||
    raw === 'cuft' ||
    raw === 'সিএফটি' ||
    raw === 'ঘনফুট' ||
    raw.includes('সিএফটি')
  ) {
    return 'CFT';
  }
  if (raw === 'bag' || raw === 'bags' || raw === 'ব্যাগ' || raw === 'বস্তা') {
    return 'Bags';
  }
  if (raw === 'pcs' || raw === 'pc' || raw === 'piece' || raw === 'pieces' || raw === 'পিস' || raw === 'টি') {
    return 'PCS';
  }
  if (raw === 'barrel' || raw === 'barrels' || raw === 'drum' || raw === 'drums' || raw === 'ড্রাম') {
    return 'Barrels';
  }
  if (raw === 'job' || raw === 'service') {
    return 'Job';
  }
  return uom.trim();
}

/**
 * Convert quantity from lineUom to itemBaseUom.
 * Standard conversion:
 * - Ton <-> MT: 1 : 1
 * - Ton <-> KG: 1 Ton = 1000 KG
 * - Ton <-> CFT (Boulder/Crushed Stone): 1 Ton = 35 CFT
 */
export function convertQuantityBetweenUoms(
  quantity: number,
  fromUom?: string,
  toUom?: string
): { convertedQty: number; factor: number; compatible: boolean; error?: string } {
  const qty = Number(quantity) || 0;
  const fromNorm = normalizeUom(fromUom);
  const toNorm = normalizeUom(toUom || fromUom);

  if (fromNorm === toNorm) {
    return { convertedQty: qty, factor: 1, compatible: true };
  }

  // Weight / Aggregate Volume conversions (via Ton base)
  const toTonFactor: Record<string, number> = {
    Ton: 1,
    KG: 0.001,
    CFT: 1 / 35, // 35 CFT = 1 Ton
  };

  if (toTonFactor[fromNorm] !== undefined && toTonFactor[toNorm] !== undefined) {
    const qtyInTons = qty * toTonFactor[fromNorm];
    const converted = qtyInTons / toTonFactor[toNorm];
    const factor = toTonFactor[fromNorm] / toTonFactor[toNorm];
    return {
      convertedQty: Number(converted.toFixed(4)),
      factor,
      compatible: true,
    };
  }

  return {
    convertedQty: qty,
    factor: 1,
    compatible: false,
    error: `Unit "${fromUom || 'N/A'}" cannot be converted to item base unit "${toUom || 'N/A'}".`,
  };
}

/**
 * Check if an item or invoice line represents a physical stock item (exempts Service / non-stock items)
 */
export function isStockItem(item?: InventoryItem | null, itemId?: string, itemName?: string, uom?: string): boolean {
  if (itemId && (itemId.startsWith('srv-') || itemId.startsWith('service-'))) return false;
  if (normalizeUom(uom) === 'Job') return false;
  if (item) {
    if (item.id.startsWith('srv-') || item.id.startsWith('service-')) return false;
    if (normalizeUom(item.uom) === 'Job') return false;
    const catLower = (item.category || '').toLowerCase();
    if (catLower.includes('service') || catLower.includes('non-stock') || catLower.includes('charge')) {
      return false;
    }
    return true;
  }
  const nameLower = (itemName || '').toLowerCase();
  if (nameLower.includes('service') || nameLower.includes('clearance') || nameLower.includes('handling fee')) {
    return false;
  }
  return Boolean(itemId);
}

/**
 * Get available stock for an item in a specific warehouse (or total stock if no warehouse specified).
 * Returns quantity in the item's base UOM as well as converted to targetUom if requested.
 */
export function getAvailableStockForWarehouse(
  item?: InventoryItem | null,
  warehouseNameOrId?: string,
  targetUom?: string
): {
  availableInBaseUom: number;
  baseUom: string;
  availableInTargetUom: number;
  targetUom: string;
  warehouseId?: string;
} {
  if (!item) {
    const normTarget = targetUom || 'Ton';
    return {
      availableInBaseUom: 0,
      baseUom: normTarget,
      availableInTargetUom: 0,
      targetUom: normTarget,
    };
  }

  const baseUom = item.uom || 'Ton';
  const resolvedWh = resolveWarehouseId(warehouseNameOrId);
  const whMap = item.stockByWarehouse || {};
  const hasWarehouseBreakdown = Object.keys(whMap).length > 0;

  let availableInBase = 0;
  if ((item.totalStock || 0) <= 0) {
    availableInBase = 0;
  } else if (resolvedWh && hasWarehouseBreakdown) {
    availableInBase = Number(whMap[resolvedWh]) || 0;
  } else {
    availableInBase = Number(item.totalStock) || 0;
  }

  const effectiveTargetUom = targetUom || baseUom;
  const conv = convertQuantityBetweenUoms(availableInBase, baseUom, effectiveTargetUom);

  return {
    availableInBaseUom: Number(availableInBase.toFixed(4)),
    baseUom,
    availableInTargetUom: Number(conv.convertedQty.toFixed(4)),
    targetUom: effectiveTargetUom,
    warehouseId: resolvedWh,
  };
}

export interface StockValidationLineInput {
  itemId: string;
  itemName: string;
  quantity: number;
  uom?: string;
}

export interface LineStockValidationError {
  lineIndex: number;
  itemId: string;
  itemName: string;
  requestedQty: number;
  requestedUom: string;
  requestedInBaseUom: number;
  availableInBaseUom: number;
  availableInRequestedUom: number;
  baseUom: string;
  warehouseName: string;
  message: string;
}

export interface StockValidationResult {
  valid: boolean;
  requiresNegativeStockApproval: boolean;
  lineErrors: Record<number, LineStockValidationError>;
  summaryError?: string;
}

/**
 * Validate stock availability across all stock-type lines for a warehouse.
 * Supports edit mode (originalLines) where only the net increase over originalLines is checked.
 */
export function validateStockAvailabilityForLines(
  lines: StockValidationLineInput[],
  warehouseNameOrId?: string,
  options?: {
    originalLines?: StockValidationLineInput[];
    originalWarehouseId?: string;
    allowNegativeStock?: boolean;
    isAdmin?: boolean;
    negativeStockReason?: string;
    itemsSnapshot?: InventoryItem[];
  }
): StockValidationResult {
  const allItems = options?.itemsSnapshot || getItems();
  const warehouses = getWarehouses();
  const resolvedWhId = resolveWarehouseId(warehouseNameOrId);
  const whObj = warehouses.find(w => w.id === resolvedWhId);
  const warehouseLabel = whObj ? whObj.name : warehouseNameOrId || 'All Warehouses';

  // Calculate original quantities in item base UOM if editing an existing invoice in the same warehouse
  const origBaseQtyByItemId: Record<string, number> = {};
  const resolvedOrigWhId = resolveWarehouseId(options?.originalWarehouseId || warehouseNameOrId);
  const sameWarehouseAsOriginal = !options?.originalWarehouseId || resolvedOrigWhId === resolvedWhId;

  if (options?.originalLines && sameWarehouseAsOriginal) {
    for (const orig of options.originalLines) {
      const catItem = allItems.find(
        i => i.id === orig.itemId || i.name.toLowerCase() === (orig.itemName || '').toLowerCase()
      );
      if (!isStockItem(catItem, orig.itemId, orig.itemName, orig.uom)) continue;
      const baseUom = catItem?.uom || orig.uom || 'Ton';
      const conv = convertQuantityBetweenUoms(Number(orig.quantity) || 0, orig.uom || baseUom, baseUom);
      const key = catItem ? catItem.id : orig.itemId;
      origBaseQtyByItemId[key] = (origBaseQtyByItemId[key] || 0) + conv.convertedQty;
    }
  }

  const cumulativeRequestedBaseByItem: Record<string, number> = {};
  const lineErrors: Record<number, LineStockValidationError> = {};

  lines.forEach((line, idx) => {
    const qty = Number(line.quantity) || 0;
    if (qty <= 0 && !line.itemId) return;

    const catItem = allItems.find(
      i => i.id === line.itemId || (line.itemName && i.name.toLowerCase() === line.itemName.toLowerCase())
    );

    if (!isStockItem(catItem, line.itemId, line.itemName, line.uom)) {
      return; // Service or non-stock item is exempt
    }

    if (!catItem) {
      lineErrors[idx] = {
        lineIndex: idx,
        itemId: line.itemId || '',
        itemName: line.itemName || 'Unknown Item',
        requestedQty: qty,
        requestedUom: line.uom || 'Ton',
        requestedInBaseUom: qty,
        availableInBaseUom: 0,
        availableInRequestedUom: 0,
        baseUom: line.uom || 'Ton',
        warehouseName: warehouseLabel,
        message: `Please select a valid stock item from the inventory catalog on line #${idx + 1}.`,
      };
      return;
    }

    const lineUom = line.uom || catItem.uom || 'Ton';
    const conv = convertQuantityBetweenUoms(qty, lineUom, catItem.uom);
    if (!conv.compatible) {
      lineErrors[idx] = {
        lineIndex: idx,
        itemId: catItem.id,
        itemName: catItem.name,
        requestedQty: qty,
        requestedUom: lineUom,
        requestedInBaseUom: qty,
        availableInBaseUom: 0,
        availableInRequestedUom: 0,
        baseUom: catItem.uom,
        warehouseName: warehouseLabel,
        message: conv.error || `Incompatible UOM "${lineUom}" for item "${catItem.name}" (base UOM: ${catItem.uom}).`,
      };
      return;
    }

    const stockInfo = getAvailableStockForWarehouse(catItem, resolvedWhId, lineUom);
    const prevCumulative = cumulativeRequestedBaseByItem[catItem.id] || 0;
    const newCumulativeBase = Number((prevCumulative + conv.convertedQty).toFixed(4));
    cumulativeRequestedBaseByItem[catItem.id] = newCumulativeBase;

    const originalQtyBase = origBaseQtyByItemId[catItem.id] || 0;
    // In edit mode, only the net increase over the original invoice quantity is checked against current available stock
    const netIncreaseBase = Number((newCumulativeBase - originalQtyBase).toFixed(4));
    const effectiveAvailableBase = stockInfo.availableInBaseUom;

    // When creating a new invoice (originalQtyBase === 0), netIncreaseBase === newCumulativeBase.
    // When editing an invoice (originalQtyBase > 0), only check if netIncreaseBase > 0 and exceeds effectiveAvailableBase.
    const isEditingThisItem = originalQtyBase > 0;
    const exceedsAvailable = isEditingThisItem
      ? netIncreaseBase > 0 && netIncreaseBase > effectiveAvailableBase + 0.0001
      : newCumulativeBase > effectiveAvailableBase + 0.0001 || effectiveAvailableBase <= 0;

    if (exceedsAvailable) {
      const maxAllowedInLineUom = convertQuantityBetweenUoms(
        effectiveAvailableBase + originalQtyBase,
        catItem.uom,
        lineUom
      ).convertedQty;

      const errMsg =
        effectiveAvailableBase <= 0 && originalQtyBase === 0
          ? `"${catItem.name}" is Out of stock (Available: 0 ${catItem.uom} in ${warehouseLabel}).`
          : isEditingThisItem
          ? `Quantity increase (+${netIncreaseBase} ${catItem.uom}) for "${catItem.name}" exceeds available stock (${effectiveAvailableBase} ${catItem.uom}, max total allowed: ${Number(maxAllowedInLineUom.toFixed(2))} ${lineUom}) in ${warehouseLabel}.`
          : `Requested quantity (${qty} ${lineUom}${conv.factor !== 1 ? ` = ${Number(conv.convertedQty.toFixed(2))} ${catItem.uom}` : ''}) for "${catItem.name}" exceeds available stock (${stockInfo.availableInTargetUom} ${lineUom} / ${effectiveAvailableBase} ${catItem.uom}) in ${warehouseLabel}.`;

      lineErrors[idx] = {
        lineIndex: idx,
        itemId: catItem.id,
        itemName: catItem.name,
        requestedQty: qty,
        requestedUom: lineUom,
        requestedInBaseUom: conv.convertedQty,
        availableInBaseUom: effectiveAvailableBase,
        availableInRequestedUom: stockInfo.availableInTargetUom,
        baseUom: catItem.uom,
        warehouseName: warehouseLabel,
        message: errMsg,
      };
    }
  });

  const errorList = Object.values(lineErrors);
  if (errorList.length === 0) {
    return {
      valid: true,
      requiresNegativeStockApproval: false,
      lineErrors: {},
    };
  }

  const canUseNegativeStock = Boolean(options?.allowNegativeStock && options?.isAdmin);
  if (canUseNegativeStock) {
    const hasReason = Boolean(options?.negativeStockReason && options.negativeStockReason.trim().length > 0);
    if (hasReason) {
      return {
        valid: true,
        requiresNegativeStockApproval: true,
        lineErrors,
      };
    }
    return {
      valid: false,
      requiresNegativeStockApproval: true,
      lineErrors,
      summaryError: `Negative stock is enabled for Admin, but a mandatory reason is required to sell above available stock (${errorList[0].message})`,
    };
  }

  return {
    valid: false,
    requiresNegativeStockApproval: false,
    lineErrors,
    summaryError: errorList[0].message,
  };
}

/**
 * Automatically add stock to an item upon Direct Purchase Invoice creation or receiving
 */
export function addStockToItem(
  itemId: string,
  quantity: number,
  unitCost?: number,
  warehouseNameOrId?: string,
  lineUom?: string
): InventoryItem[] {
  const current = getItems();
  const resolvedWhKey = resolveWarehouseId(warehouseNameOrId);
  const updated = current.map(item => {
    if (item.id === itemId || item.name.toLowerCase() === itemId.toLowerCase()) {
      const conv = convertQuantityBetweenUoms(quantity, lineUom || item.uom, item.uom);
      const qtyBase = conv.convertedQty;
      const prevStock = item.totalStock || 0;
      const newStock = Number((prevStock + qtyBase).toFixed(2));

      let newAvgCost = item.avgUnitCost || 0;
      if (unitCost !== undefined && unitCost > 0 && (prevStock + qtyBase) > 0) {
        newAvgCost = Number((((prevStock * newAvgCost) + (qtyBase * unitCost)) / (prevStock + qtyBase)).toFixed(2));
      }

      const stockByWh = { ...(item.stockByWarehouse || {}) };
      if (resolvedWhKey) {
        stockByWh[resolvedWhKey] = Number(((stockByWh[resolvedWhKey] || 0) + qtyBase).toFixed(2));
      }

      return {
        ...item,
        totalStock: newStock,
        avgUnitCost: newAvgCost > 0 ? newAvgCost : item.avgUnitCost,
        stockByWarehouse: stockByWh
      };
    }
    return item;
  });

  saveItems(updated);
  return updated;
}

/**
 * Deduct stock from an item (supports UOM conversion and negative stock when authorized)
 */
export function deductStockFromItem(
  itemId: string,
  quantity: number,
  warehouseNameOrId?: string,
  lineUom?: string,
  allowNegative?: boolean
): InventoryItem[] {
  const current = getItems();
  const resolvedWhKey = resolveWarehouseId(warehouseNameOrId);
  const updated = current.map(item => {
    if (item.id === itemId || item.name.toLowerCase() === itemId.toLowerCase()) {
      const conv = convertQuantityBetweenUoms(quantity, lineUom || item.uom, item.uom);
      const qtyBase = conv.convertedQty;
      const prevStock = item.totalStock || 0;
      const rawNewStock = Number((prevStock - qtyBase).toFixed(2));
      const newStock = allowNegative ? rawNewStock : Math.max(0, rawNewStock);

      const stockByWh = { ...(item.stockByWarehouse || {}) };
      if (resolvedWhKey) {
        const rawWh = Number(((stockByWh[resolvedWhKey] || 0) - qtyBase).toFixed(2));
        stockByWh[resolvedWhKey] = allowNegative ? rawWh : Math.max(0, rawWh);
      }

      return {
        ...item,
        totalStock: newStock,
        stockByWarehouse: stockByWh
      };
    }
    return item;
  });

  saveItems(updated);
  return updated;
}

/**
 * Restore stock for all stock lines of an invoice (when an invoice is voided, deleted, or before applying edited lines)
 */
export function restoreStockForInvoiceLines(
  lines: StockValidationLineInput[],
  warehouseNameOrId?: string
): InventoryItem[] {
  let current = getItems();
  const resolvedWhKey = resolveWarehouseId(warehouseNameOrId);

  lines.forEach(line => {
    const qty = Number(line.quantity) || 0;
    if (qty <= 0) return;
    current = current.map(item => {
      if (
        item.id === line.itemId ||
        (line.itemName && item.name.toLowerCase() === line.itemName.toLowerCase())
      ) {
        if (!isStockItem(item, line.itemId, line.itemName, line.uom)) return item;
        const conv = convertQuantityBetweenUoms(qty, line.uom || item.uom, item.uom);
        const qtyBase = conv.convertedQty;
        const nextTotal = Number(((item.totalStock || 0) + qtyBase).toFixed(2));
        const stockByWh = { ...(item.stockByWarehouse || {}) };
        if (resolvedWhKey) {
          stockByWh[resolvedWhKey] = Number(((stockByWh[resolvedWhKey] || 0) + qtyBase).toFixed(2));
        }
        return {
          ...item,
          totalStock: nextTotal,
          stockByWarehouse: stockByWh,
        };
      }
      return item;
    });
  });

  saveItems(current);
  return current;
}

/**
 * Deduct stock for all stock lines of an invoice in one atomic batch after validation
 */
export function deductStockForInvoiceLines(
  lines: StockValidationLineInput[],
  warehouseNameOrId?: string,
  allowNegative?: boolean
): InventoryItem[] {
  let current = getItems();
  const resolvedWhKey = resolveWarehouseId(warehouseNameOrId);

  lines.forEach(line => {
    const qty = Number(line.quantity) || 0;
    if (qty <= 0) return;
    current = current.map(item => {
      if (
        item.id === line.itemId ||
        (line.itemName && item.name.toLowerCase() === line.itemName.toLowerCase())
      ) {
        if (!isStockItem(item, line.itemId, line.itemName, line.uom)) return item;
        const conv = convertQuantityBetweenUoms(qty, line.uom || item.uom, item.uom);
        const qtyBase = conv.convertedQty;
        const rawTotal = Number(((item.totalStock || 0) - qtyBase).toFixed(2));
        const nextTotal = allowNegative ? rawTotal : Math.max(0, rawTotal);
        const stockByWh = { ...(item.stockByWarehouse || {}) };
        if (resolvedWhKey) {
          const rawWh = Number(((stockByWh[resolvedWhKey] || 0) - qtyBase).toFixed(2));
          stockByWh[resolvedWhKey] = allowNegative ? rawWh : Math.max(0, rawWh);
        }
        return {
          ...item,
          totalStock: nextTotal,
          stockByWarehouse: stockByWh,
        };
      }
      return item;
    });
  });

  saveItems(current);
  return current;
}

/**
 * Delete an item from inventory
 */
export function deleteItem(id: string): InventoryItem[] {
  const current = getItems();
  const updated = current.filter(item => item.id !== id);
  saveItems(updated);
  return updated;
}

/**
 * Toggle Active / Inactive status of an item
 */
export function toggleItemStatus(id: string): InventoryItem[] {
  const current = getItems();
  const updated = current.map(item => {
    if (item.id === id) {
      const nextStatus: 'Active' | 'Inactive' = item.status === 'Inactive' ? 'Active' : 'Inactive';
      return { ...item, status: nextStatus };
    }
    return item;
  });
  saveItems(updated);
  return updated;
}

/**
 * Subscribe to item changes
 */
export function subscribeItems(callback: (items: InventoryItem[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ items: InventoryItem[] }>;
    if (customEvt.detail?.items) {
      callback(customEvt.detail.items);
    } else {
      callback(getItems());
    }
  };

  window.addEventListener(ITEMS_EVENT_NAME, handler);
  return () => window.removeEventListener(ITEMS_EVENT_NAME, handler);
}

// ================= CATEGORY MANAGEMENT =================

/**
 * Load categories from storage or initialize with defaults + categories from items
 */
export function getCategories(): ItemCategoryRecord[] {
  try {
    const raw = localStorage.getItem(CATEGORIES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load item categories from storage', err);
  }

  // Derive categories from items if available
  const items = getItems();
  const itemCats = Array.from(new Set(items.map(i => i.category).filter(Boolean)));
  const initial = [...DEFAULT_CATEGORIES];

  itemCats.forEach(catName => {
    if (!initial.some(c => c.name.toLowerCase() === catName.toLowerCase())) {
      initial.push({
        id: `cat-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        name: catName,
        status: 'Active',
        isDefault: false
      });
    }
  });

  return initial;
}

/**
 * Save categories and broadcast event
 */
export function saveCategories(categories: ItemCategoryRecord[]): void {
  try {
    localStorage.setItem(CATEGORIES_STORAGE_KEY, JSON.stringify(categories));
    window.dispatchEvent(new CustomEvent(CATEGORIES_EVENT_NAME, { detail: { categories } }));
  } catch (err) {
    console.error('Failed to save item categories to storage', err);
  }
}

/**
 * Add a new category
 */
export function addCategory(data: { name: string; description?: string; status?: 'Active' | 'Inactive' }): ItemCategoryRecord[] {
  const trimmed = data.name.trim();
  if (!trimmed) return getCategories();

  const current = getCategories();
  const existing = current.find(c => c.name.toLowerCase() === trimmed.toLowerCase());
  if (existing) {
    // If existing, reactivate if inactive
    if (existing.status === 'Inactive') {
      return toggleCategoryStatus(existing.id);
    }
    return current;
  }

  const newCat: ItemCategoryRecord = {
    id: `cat-${Date.now()}`,
    name: trimmed,
    description: data.description?.trim(),
    status: data.status || 'Active',
    isDefault: false
  };

  const updated = [...current, newCat];
  saveCategories(updated);
  return updated;
}

/**
 * Edit an existing category and automatically update all items in that category if name changed
 */
export function updateCategory(id: string, updatedFields: Partial<ItemCategoryRecord>): ItemCategoryRecord[] {
  const current = getCategories();
  const target = current.find(c => c.id === id);
  if (!target) return current;

  const oldName = target.name;
  const newName = updatedFields.name ? updatedFields.name.trim() : oldName;

  const updatedCategories = current.map(c => {
    if (c.id === id) {
      return {
        ...c,
        ...updatedFields,
        name: newName
      };
    }
    return c;
  });

  saveCategories(updatedCategories);

  // If name changed, also update all items that had this category
  if (newName !== oldName) {
    const allItems = getItems();
    let hasChanges = false;
    const updatedItems = allItems.map(item => {
      if (item.category === oldName) {
        hasChanges = true;
        return { ...item, category: newName };
      }
      return item;
    });

    if (hasChanges) {
      saveItems(updatedItems);
    }
  }

  return updatedCategories;
}

/**
 * Delete a category
 */
export function deleteCategory(id: string, reassignCategoryTo?: string): ItemCategoryRecord[] {
  const current = getCategories();
  const target = current.find(c => c.id === id);
  if (!target) return current;

  const updatedCategories = current.filter(c => c.id !== id);
  saveCategories(updatedCategories);

  // Reassign items that belonged to this category
  const targetCategoryName = target.name;
  const fallbackCat = reassignCategoryTo || 'Boulder';
  const allItems = getItems();
  let hasChanges = false;

  const updatedItems = allItems.map(item => {
    if (item.category === targetCategoryName) {
      hasChanges = true;
      return { ...item, category: fallbackCat };
    }
    return item;
  });

  if (hasChanges) {
    saveItems(updatedItems);
  }

  return updatedCategories;
}

/**
 * Toggle Active / Inactive status of a category
 */
export function toggleCategoryStatus(id: string): ItemCategoryRecord[] {
  const current = getCategories();
  const updated = current.map(cat => {
    if (cat.id === id) {
      const nextStatus: 'Active' | 'Inactive' = cat.status === 'Inactive' ? 'Active' : 'Inactive';
      return { ...cat, status: nextStatus };
    }
    return cat;
  });
  saveCategories(updated);
  return updated;
}

/**
 * Subscribe to category changes
 */
export function subscribeCategories(callback: (categories: ItemCategoryRecord[]) => void): () => void {
  const handler = (e: Event) => {
    const customEvt = e as CustomEvent<{ categories: ItemCategoryRecord[] }>;
    if (customEvt.detail?.categories) {
      callback(customEvt.detail.categories);
    } else {
      callback(getCategories());
    }
  };

  window.addEventListener(CATEGORIES_EVENT_NAME, handler);
  return () => window.removeEventListener(CATEGORIES_EVENT_NAME, handler);
}
