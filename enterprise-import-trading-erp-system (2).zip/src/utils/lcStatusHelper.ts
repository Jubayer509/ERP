import { LetterOfCredit, LCStatus } from '../types/erp';

export interface LCProgressStatus {
  isGoodsReceived: boolean;
  isBankSettled: boolean;
  isHundiSettled: boolean;
  totalQuantity: number;
  receivedQuantity: number;
  officialBankLcTotalForeign: number;
  totalBankSettledForeign: number;
  remainingBankDueForeign: number;
  totalDifferentialGapBdt: number;
  totalHundiPaidBdt: number;
  remainingHundiDueBdt: number;
  computedStatus: LCStatus;
  isClosed: boolean;
}

export function computeLCProgressAndStatus(lc: LetterOfCredit): LCProgressStatus {
  const totalQuantity = lc.quantity || 1000;
  // Received quantity
  const receivedQuantity = 
    lc.receivedQuantity || 
    lc.receivedQtyMt || 
    (lc.receivings || []).reduce((acc, r) => acc + (r.receivedQty || 0), 0) || 
    0;
  const isGoodsReceived = receivedQuantity >= totalQuantity;

  // Bank settlement
  const officialLcRate = lc.officialLcRate || lc.lcBankRateUsd || 14.00;
  const officialBankLcTotalForeign = totalQuantity * officialLcRate;
  const activeBankSettlements = (lc.bankSettlements || []).filter(b => b.status !== 'Voided');
  const totalBankSettledForeign = activeBankSettlements.reduce((acc, b) => acc + (b.amountForeign || 0), 0);
  const remainingBankDueForeign = Math.max(0, officialBankLcTotalForeign - totalBankSettledForeign);
  const isBankSettled = remainingBankDueForeign <= 0.001;

  // Hundi settlement
  const exchangeRate = lc.exchangeRate || 122.50;
  const activeRateBatches = lc.rateBatches && lc.rateBatches.length > 0
    ? lc.rateBatches
    : [
        {
          quantity: totalQuantity,
          actualRate: lc.actualRate || 18,
          officialRate: officialLcRate,
          totalCommercialAmount: totalQuantity * (lc.actualRate || 18)
        }
      ];
  const totalCommercialBillForeign = activeRateBatches.reduce(
    (acc: number, b: any) => acc + (b.totalCommercialAmount || (b.quantity * (b.actualRate || 18))), 
    0
  );
  const totalDifferentialGapForeign = Math.max(0, totalCommercialBillForeign - officialBankLcTotalForeign);
  const totalDifferentialGapBdt = totalDifferentialGapForeign * exchangeRate;

  const activeHundiPayments = (lc.hundiPayments || []).filter(h => h.status !== 'Voided');
  const totalHundiPaidBdt = activeHundiPayments.reduce((acc, h) => acc + (h.amountBdt || 0), 0);
  const remainingHundiDueBdt = Math.max(0, totalDifferentialGapBdt - totalHundiPaidBdt);
  // If no gap exists, hundi is considered settled
  const isHundiSettled = totalDifferentialGapBdt <= 1 || remainingHundiDueBdt <= 1;

  // Is all three completed?
  const allComplete = isGoodsReceived && isBankSettled && isHundiSettled;

  let computedStatus: LCStatus;
  if (allComplete) {
    computedStatus = 'Costed & Closed';
  } else if (lc.status === 'Costed & Closed') {
    // If it was marked closed previously but now has pending items (e.g. after a void), revert to closest status
    computedStatus = isGoodsReceived ? 'GRN Received' : (receivedQuantity > 0 ? 'Customs Cleared' : 'Opened / Margin Paid');
  } else if (isGoodsReceived) {
    computedStatus = 'GRN Received';
  } else if (receivedQuantity > 0) {
    computedStatus = 'Customs Cleared';
  } else {
    computedStatus = lc.status || 'Opened / Margin Paid';
  }

  return {
    isGoodsReceived,
    isBankSettled,
    isHundiSettled,
    totalQuantity,
    receivedQuantity,
    officialBankLcTotalForeign,
    totalBankSettledForeign,
    remainingBankDueForeign,
    totalDifferentialGapBdt,
    totalHundiPaidBdt,
    remainingHundiDueBdt,
    computedStatus,
    isClosed: computedStatus === 'Costed & Closed'
  };
}
