import { FiscalYear } from '../types/erp';

export const SEED_FISCAL_YEARS: FiscalYear[] = [
  {
    id: 'fy-2023-2024',
    name: 'FY 2023-2024',
    bengaliName: 'Fiscal Year 2023-2024',
    startDate: '2023-07-01',
    endDate: '2024-06-30',
    status: 'Closed',
    isDefault: false,
    description: 'Statutory audit completed and tax accounts closed.',
    closedDate: '2024-09-30',
    closedBy: 'Head of Accounts',
    totalVouchers: 842,
    totalTransactions: 1980
  },
  {
    id: 'fy-2024-2025',
    name: 'FY 2024-2025',
    bengaliName: 'Fiscal Year 2024-2025',
    startDate: '2024-07-01',
    endDate: '2025-06-30',
    status: 'Closed',
    isDefault: false,
    description: 'Year-end reconciliation finalized. Retained earnings transferred.',
    closedDate: '2025-09-28',
    closedBy: 'Managing Director',
    totalVouchers: 1420,
    totalTransactions: 3640
  },
  {
    id: 'fy-2025-2026',
    name: 'FY 2025-2026',
    bengaliName: 'Fiscal Year 2025-2026',
    startDate: '2025-07-01',
    endDate: '2026-06-30',
    status: 'Active',
    isDefault: true,
    description: 'Current active operational financial year for invoicing, procurement and banking.',
    totalVouchers: 915,
    totalTransactions: 2480
  },
  {
    id: 'fy-2026-2027',
    name: 'FY 2026-2027',
    bengaliName: 'Fiscal Year 2026-2027',
    startDate: '2026-07-01',
    endDate: '2027-06-30',
    status: 'Upcoming',
    isDefault: false,
    description: 'Planned import budgetary fiscal cycle.',
    totalVouchers: 0,
    totalTransactions: 0
  }
];

const STORAGE_KEY = 'tradecore_fiscal_years_v1';
const EVENT_NAME = 'tradecore_fiscal_years_changed';

export function getFiscalYears(): FiscalYear[] {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    }
  } catch (err) {
    console.error('Failed to read fiscal years from localStorage', err);
  }
  return SEED_FISCAL_YEARS;
}

export function saveFiscalYears(list: FiscalYear[]): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
      window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { fiscalYears: list } }));
    }
  } catch (err) {
    console.error('Failed to save fiscal years', err);
  }
}

export function getActiveFiscalYear(): FiscalYear {
  const all = getFiscalYears();
  const active = all.find(f => f.status === 'Active') || all.find(f => f.isDefault) || all[0] || SEED_FISCAL_YEARS[2];
  return active;
}

export function setActiveFiscalYear(id: string): FiscalYear[] {
  const all = getFiscalYears();
  const updated = all.map(f => {
    if (f.id === id) {
      return { ...f, status: 'Active' as const, isDefault: true };
    }
    // If it was active previously, mark it Closed if it ended, or keep its non-active state
    return {
      ...f,
      status: f.status === 'Active' ? ('Closed' as const) : f.status,
      isDefault: false
    };
  });
  saveFiscalYears(updated);
  return updated;
}

export function closeFiscalYear(id: string, closedBy = 'Managing Director'): FiscalYear[] {
  const all = getFiscalYears();
  const updated = all.map(f => {
    if (f.id === id) {
      return {
        ...f,
        status: 'Closed' as const,
        isDefault: false,
        closedDate: new Date().toISOString().split('T')[0],
        closedBy
      };
    }
    return f;
  });
  saveFiscalYears(updated);
  return updated;
}

export function reopenFiscalYear(id: string): FiscalYear[] {
  const all = getFiscalYears();
  const updated = all.map(f => {
    if (f.id === id) {
      return {
        ...f,
        status: 'Active' as const,
        closedDate: undefined,
        closedBy: undefined
      };
    }
    return f;
  });
  saveFiscalYears(updated);
  return updated;
}

export function addFiscalYear(newYear: Omit<FiscalYear, 'id'>): FiscalYear[] {
  const all = getFiscalYears();
  const id = `fy-${newYear.startDate.split('-')[0]}-${newYear.endDate.split('-')[0]}-${Date.now().toString().slice(-4)}`;
  const item: FiscalYear = { ...newYear, id };
  const updated = [...all, item];
  saveFiscalYears(updated);
  return updated;
}

export function deleteFiscalYear(id: string): FiscalYear[] {
  const all = getFiscalYears();
  const updated = all.filter(f => f.id !== id);
  saveFiscalYears(updated);
  return updated;
}

export function formatFiscalYearDisplay(fy?: FiscalYear | null): string {
  if (!fy) return '01/07/2025 - 30/06/2026 (Active)';
  const [sY, sM, sD] = fy.startDate.split('-');
  const [eY, eM, eD] = fy.endDate.split('-');
  const startStr = `${sD}/${sM}/${sY}`;
  const endStr = `${eD}/${eM}/${eY}`;
  return `${startStr} - ${endStr} (${fy.status})`;
}

export function subscribeFiscalYears(callback: (years: FiscalYear[]) => void): () => void {
  const handler = (e: any) => {
    if (e.detail && e.detail.fiscalYears) {
      callback(e.detail.fiscalYears);
    } else {
      callback(getFiscalYears());
    }
  };
  window.addEventListener(EVENT_NAME, handler);
  return () => window.removeEventListener(EVENT_NAME, handler);
}
