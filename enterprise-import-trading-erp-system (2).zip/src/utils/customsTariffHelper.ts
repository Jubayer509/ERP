export interface DutyHeadConfig {
  code: 'CD' | 'RD' | 'SD' | 'VAT' | 'AIT' | 'AT';
  name: string;
  ratePercent: number;
  baseFormula: string;
  capitalizeToInventory: boolean;
  accountHeadCode: string;
  accountHeadName: string;
}

export interface CustomsTariffConfig {
  hsCode: string;
  description: string;
  landingPercent: number;
  heads: DutyHeadConfig[];
}

export interface DutyAssessmentLine {
  code: 'CD' | 'RD' | 'SD' | 'VAT' | 'AIT' | 'AT';
  name: string;
  ratePercent: number;
  baseAmountBdt: number;
  dutyAmountBdt: number;
  capitalizeToInventory: boolean;
  accountHeadCode: string;
  accountHeadName: string;
}

export interface DutyAssessmentResult {
  hsCode: string;
  cfrBdt: number;
  landingPercent: number;
  landingAmountBdt: number;
  assessableValueBdt: number;
  lines: DutyAssessmentLine[];
  totalStatutoryDutiesBdt: number;
  capitalizableDutiesBdt: number;
  recoverableTaxesBdt: number;
}

const TARIFF_STORAGE_KEY = 'tradecore_customs_tariffs_v1';

export const DEFAULT_TARIFF_CONFIGS: CustomsTariffConfig[] = [
  {
    hsCode: '2517.10.00',
    description: 'Pebbles, gravel, broken or crushed stone (Boulder Stone)',
    landingPercent: 1.0,
    heads: [
      { code: 'CD', name: 'Customs Duty (CD)', ratePercent: 25, baseFormula: 'AV', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'RD', name: 'Regulatory Duty (RD)', ratePercent: 3, baseFormula: 'AV', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'SD', name: 'Supplementary Duty (SD)', ratePercent: 0, baseFormula: 'AV + CD + RD', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'VAT', name: 'Value Added Tax (VAT)', ratePercent: 15, baseFormula: 'AV + CD + RD + SD', capitalizeToInventory: false, accountHeadCode: '11410', accountHeadName: 'Input VAT Receivable' },
      { code: 'AIT', name: 'Advance Income Tax (AIT)', ratePercent: 5, baseFormula: 'AV', capitalizeToInventory: false, accountHeadCode: '11420', accountHeadName: 'Advance Income Tax (Sec 82C)' },
      { code: 'AT', name: 'Advance Tax (AT)', ratePercent: 5, baseFormula: 'AV + CD + RD + SD', capitalizeToInventory: false, accountHeadCode: '11430', accountHeadName: 'Advance Tax Receivable' }
    ]
  },
  {
    hsCode: '7208.38.00',
    description: 'Flat-rolled products of iron or non-alloy steel (Prime Coils)',
    landingPercent: 1.0,
    heads: [
      { code: 'CD', name: 'Customs Duty (CD)', ratePercent: 25, baseFormula: 'AV', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'RD', name: 'Regulatory Duty (RD)', ratePercent: 3, baseFormula: 'AV', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'SD', name: 'Supplementary Duty (SD)', ratePercent: 20, baseFormula: 'AV + CD + RD', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'VAT', name: 'Value Added Tax (VAT)', ratePercent: 15, baseFormula: 'AV + CD + RD + SD', capitalizeToInventory: false, accountHeadCode: '11410', accountHeadName: 'Input VAT Receivable' },
      { code: 'AIT', name: 'Advance Income Tax (AIT)', ratePercent: 5, baseFormula: 'AV', capitalizeToInventory: false, accountHeadCode: '11420', accountHeadName: 'Advance Income Tax (Sec 82C)' },
      { code: 'AT', name: 'Advance Tax (AT)', ratePercent: 5, baseFormula: 'AV + CD + RD + SD', capitalizeToInventory: false, accountHeadCode: '11430', accountHeadName: 'Advance Tax Receivable' }
    ]
  },
  {
    hsCode: '3105.90.00',
    description: 'Mineral or chemical fertilisers (Fertilizer GA-3)',
    landingPercent: 1.0,
    heads: [
      { code: 'CD', name: 'Customs Duty (CD)', ratePercent: 5, baseFormula: 'AV', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'RD', name: 'Regulatory Duty (RD)', ratePercent: 0, baseFormula: 'AV', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'SD', name: 'Supplementary Duty (SD)', ratePercent: 0, baseFormula: 'AV + CD + RD', capitalizeToInventory: true, accountHeadCode: '13100', accountHeadName: 'Raw Material Inventory' },
      { code: 'VAT', name: 'Value Added Tax (VAT)', ratePercent: 0, baseFormula: 'AV + CD + RD + SD', capitalizeToInventory: false, accountHeadCode: '11410', accountHeadName: 'Input VAT Receivable' },
      { code: 'AIT', name: 'Advance Income Tax (AIT)', ratePercent: 5, baseFormula: 'AV', capitalizeToInventory: false, accountHeadCode: '11420', accountHeadName: 'Advance Income Tax (Sec 82C)' },
      { code: 'AT', name: 'Advance Tax (AT)', ratePercent: 0, baseFormula: 'AV + CD + RD + SD', capitalizeToInventory: false, accountHeadCode: '11430', accountHeadName: 'Advance Tax Receivable' }
    ]
  }
];

export function getAllTariffConfigs(): CustomsTariffConfig[] {
  try {
    const raw = localStorage.getItem(TARIFF_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('Failed to parse tariff configs:', e);
  }
  return DEFAULT_TARIFF_CONFIGS;
}

export function getTariffConfig(hsCode?: string): CustomsTariffConfig {
  const all = getAllTariffConfigs();
  if (hsCode) {
    const cleanHs = hsCode.trim();
    const found = all.find(t => t.hsCode === cleanHs || cleanHs.startsWith(t.hsCode.slice(0, 4)));
    if (found) return found;
  }
  return all[0] || DEFAULT_TARIFF_CONFIGS[0];
}

export function saveTariffConfig(config: CustomsTariffConfig): void {
  const all = getAllTariffConfigs();
  const index = all.findIndex(t => t.hsCode === config.hsCode);
  let next: CustomsTariffConfig[];
  if (index >= 0) {
    next = [...all];
    next[index] = config;
  } else {
    next = [...all, config];
  }
  try {
    localStorage.setItem(TARIFF_STORAGE_KEY, JSON.stringify(next));
    window.dispatchEvent(new CustomEvent('tradecore_tariff_changed', { detail: { configs: next } }));
  } catch (e) {
    console.error('Failed to save tariff configs:', e);
  }
}

export function updateDutyHeadCapitalize(hsCode: string, headCode: string, capitalize: boolean): void {
  const current = getTariffConfig(hsCode);
  const updatedHeads = current.heads.map(h => 
    h.code === headCode ? { ...h, capitalizeToInventory: capitalize } : h
  );
  saveTariffConfig({ ...current, heads: updatedHeads });
}

export function updateDutyHeadRate(hsCode: string, headCode: string, rate: number): void {
  const current = getTariffConfig(hsCode);
  const updatedHeads = current.heads.map(h => 
    h.code === headCode ? { ...h, ratePercent: Math.max(0, rate) } : h
  );
  saveTariffConfig({ ...current, heads: updatedHeads });
}

export function calculateDutyAssessment(cfrBdt: number, hsCode?: string): DutyAssessmentResult {
  const tariff = getTariffConfig(hsCode);
  const landingPercent = tariff.landingPercent ?? 1.0;
  const landingAmountBdt = Math.round((cfrBdt * landingPercent) / 100);
  const assessableValueBdt = cfrBdt + landingAmountBdt;

  const getHead = (code: 'CD' | 'RD' | 'SD' | 'VAT' | 'AIT' | 'AT') => 
    tariff.heads.find(h => h.code === code) || {
      code,
      name: code,
      ratePercent: 0,
      baseFormula: 'AV',
      capitalizeToInventory: code === 'CD' || code === 'RD' || code === 'SD',
      accountHeadCode: code === 'VAT' ? '11410' : (code === 'AIT' ? '11420' : (code === 'AT' ? '11430' : '13100')),
      accountHeadName: 'Duty'
    };

  const cdHead = getHead('CD');
  const rdHead = getHead('RD');
  const sdHead = getHead('SD');
  const vatHead = getHead('VAT');
  const aitHead = getHead('AIT');
  const atHead = getHead('AT');

  // 1. CD = AV * rate
  const cdBase = assessableValueBdt;
  const cdAmount = Math.round((cdBase * cdHead.ratePercent) / 100);

  // 2. RD = AV * rate
  const rdBase = assessableValueBdt;
  const rdAmount = Math.round((rdBase * rdHead.ratePercent) / 100);

  // 3. SD = (AV + CD + RD) * rate
  const sdBase = assessableValueBdt + cdAmount + rdAmount;
  const sdAmount = Math.round((sdBase * sdHead.ratePercent) / 100);

  // 4. VAT = (AV + CD + RD + SD) * rate
  const vatBase = assessableValueBdt + cdAmount + rdAmount + sdAmount;
  const vatAmount = Math.round((vatBase * vatHead.ratePercent) / 100);

  // 5. AIT = AV * rate
  const aitBase = assessableValueBdt;
  const aitAmount = Math.round((aitBase * aitHead.ratePercent) / 100);

  // 6. AT = (AV + CD + RD + SD) * rate
  const atBase = assessableValueBdt + cdAmount + rdAmount + sdAmount;
  const atAmount = Math.round((atBase * atHead.ratePercent) / 100);

  const lines: DutyAssessmentLine[] = [
    { code: 'CD', name: cdHead.name, ratePercent: cdHead.ratePercent, baseAmountBdt: cdBase, dutyAmountBdt: cdAmount, capitalizeToInventory: cdHead.capitalizeToInventory, accountHeadCode: cdHead.accountHeadCode, accountHeadName: cdHead.accountHeadName },
    { code: 'RD', name: rdHead.name, ratePercent: rdHead.ratePercent, baseAmountBdt: rdBase, dutyAmountBdt: rdAmount, capitalizeToInventory: rdHead.capitalizeToInventory, accountHeadCode: rdHead.accountHeadCode, accountHeadName: rdHead.accountHeadName },
    { code: 'SD', name: sdHead.name, ratePercent: sdHead.ratePercent, baseAmountBdt: sdBase, dutyAmountBdt: sdAmount, capitalizeToInventory: sdHead.capitalizeToInventory, accountHeadCode: sdHead.accountHeadCode, accountHeadName: sdHead.accountHeadName },
    { code: 'VAT', name: vatHead.name, ratePercent: vatHead.ratePercent, baseAmountBdt: vatBase, dutyAmountBdt: vatAmount, capitalizeToInventory: vatHead.capitalizeToInventory, accountHeadCode: vatHead.accountHeadCode, accountHeadName: vatHead.accountHeadName },
    { code: 'AIT', name: aitHead.name, ratePercent: aitHead.ratePercent, baseAmountBdt: aitBase, dutyAmountBdt: aitAmount, capitalizeToInventory: aitHead.capitalizeToInventory, accountHeadCode: aitHead.accountHeadCode, accountHeadName: aitHead.accountHeadName },
    { code: 'AT', name: atHead.name, ratePercent: atHead.ratePercent, baseAmountBdt: atBase, dutyAmountBdt: atAmount, capitalizeToInventory: atHead.capitalizeToInventory, accountHeadCode: atHead.accountHeadCode, accountHeadName: atHead.accountHeadName }
  ];

  const totalStatutoryDutiesBdt = lines.reduce((sum, l) => sum + l.dutyAmountBdt, 0);
  const capitalizableDutiesBdt = lines.filter(l => l.capitalizeToInventory).reduce((sum, l) => sum + l.dutyAmountBdt, 0);
  const recoverableTaxesBdt = lines.filter(l => !l.capitalizeToInventory).reduce((sum, l) => sum + l.dutyAmountBdt, 0);

  return {
    hsCode: tariff.hsCode,
    cfrBdt,
    landingPercent,
    landingAmountBdt,
    assessableValueBdt,
    lines,
    totalStatutoryDutiesBdt,
    capitalizableDutiesBdt,
    recoverableTaxesBdt
  };
}
