// Storage and audit trail for Deleted / Restorable ERP Records
export type DeletedRecordType = 
  | 'sales_invoice' 
  | 'purchase_invoice' 
  | 'customer_payment' 
  | 'supplier_payment' 
  | 'journal_voucher';

export interface DeletedRecord {
  id: string;
  recordType: DeletedRecordType;
  originalId: string;
  referenceNumber: string;
  title: string;
  partyName: string;
  amount: number;
  date: string;
  deletedAt: string;
  deletedBy: string;
  reason?: string;
  data: any; // Raw object snapshot
}

const STORAGE_KEY = 'tradecore_recycle_bin_v1';
const EVENT_NAME = 'tradecore_recycle_bin_changed';

export const getDeletedRecords = (): DeletedRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Failed to load recycle bin records', err);
  }
  return [];
};

export const saveDeletedRecord = (
  payload: Omit<DeletedRecord, 'id' | 'deletedAt'>
): DeletedRecord => {
  const current = getDeletedRecords();
  const newRecord: DeletedRecord = {
    ...payload,
    id: `trash-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    deletedAt: new Date().toISOString()
  };

  const updated = [newRecord, ...current];
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { action: 'delete', record: newRecord } }));
  } catch (e) {
    console.error('Failed to persist deleted record to recycle bin', e);
  }
  return newRecord;
};

export const restoreDeletedRecord = (trashId: string): DeletedRecord | null => {
  const current = getDeletedRecords();
  const target = current.find(r => r.id === trashId);
  if (!target) return null;

  const remaining = current.filter(r => r.id !== trashId);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(remaining));
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { action: 'restore', record: target } }));
  } catch (e) {
    console.error('Failed to update recycle bin after restore', e);
  }
  return target;
};

export const permanentlyDeleteRecord = (trashId: string): boolean => {
  const current = getDeletedRecords();
  const remaining = current.filter(r => r.id !== trashId);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(remaining));
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { action: 'permanent_delete', trashId } }));
    return true;
  } catch (e) {
    console.error('Failed to delete permanently from recycle bin', e);
    return false;
  }
};

export const clearRecycleBin = (type?: DeletedRecordType): void => {
  const current = getDeletedRecords();
  const remaining = type ? current.filter(r => r.recordType !== type) : [];
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(remaining));
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { action: 'clear', type } }));
  } catch (e) {
    console.error('Failed to clear recycle bin', e);
  }
};

export const subscribeRecycleBin = (callback: () => void): (() => void) => {
  const listener = () => callback();
  window.addEventListener(EVENT_NAME, listener);
  window.addEventListener('storage', listener);
  return () => {
    window.removeEventListener(EVENT_NAME, listener);
    window.removeEventListener('storage', listener);
  };
};
