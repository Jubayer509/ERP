import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Clock, 
  Calendar, 
  ChevronRight, 
  Bell, 
  ShieldAlert, 
  FileText, 
  CheckCircle2, 
  X,
  Filter,
  ArrowUpRight,
  Sparkles
} from 'lucide-react';
import { LCExpiryAlert, AlertSeverity } from '../../utils/lcAlertUtils';

interface LCExpiryAlertBannerProps {
  alerts: LCExpiryAlert[];
  onOpenAlertModal: () => void;
  onSelectAlert?: (alert: LCExpiryAlert) => void;
  onFilterUrgent?: () => void;
  isUrgentFiltered?: boolean;
}

export const LCExpiryAlertBanner: React.FC<LCExpiryAlertBannerProps> = ({
  alerts,
  onOpenAlertModal,
  onSelectAlert,
  onFilterUrgent,
  isUrgentFiltered = false
}) => {
  const [isMinimized, setIsMinimized] = useState(false);

  // Group alerts by severity
  const expiredAlerts = alerts.filter(a => a.severity === 'expired');
  const criticalAlerts = alerts.filter(a => a.severity === 'critical');
  const warningAlerts = alerts.filter(a => a.severity === 'warning');

  const totalUrgent = expiredAlerts.length + criticalAlerts.length;

  if (alerts.length === 0) {
    return (
      <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-3 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-emerald-800">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold">All Active Letters of Credit (LC) have valid shipment & expiry schedules.</span>
        </div>
        <span className="text-[11px] font-mono text-emerald-700 font-bold bg-white px-2 py-0.5 rounded-lg border border-emerald-200">
          UCP 600 Compliant
        </span>
      </div>
    );
  }

  // The most critical upcoming alert
  const topAlert = expiredAlerts[0] || criticalAlerts[0] || warningAlerts[0] || alerts[0];

  return (
    <div className={`transition-all duration-200 rounded-2xl border ${
      expiredAlerts.length > 0
        ? 'bg-gradient-to-r from-rose-50 via-amber-50 to-orange-50 border-rose-300 shadow-xs'
        : criticalAlerts.length > 0
        ? 'bg-gradient-to-r from-amber-50 via-orange-50 to-yellow-50 border-amber-300 shadow-xs'
        : 'bg-blue-50/70 border-blue-200 shadow-xs'
    }`}>
      {/* Banner Main Row */}
      <div className="p-3.5 sm:p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Left: Icon & Alert Summary */}
          <div className="flex items-start sm:items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${
              expiredAlerts.length > 0 
                ? 'bg-rose-600 text-white animate-pulse' 
                : criticalAlerts.length > 0
                ? 'bg-amber-600 text-white'
                : 'bg-blue-600 text-white'
            }`}>
              <Bell className="w-5 h-5" />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md font-mono ${
                  expiredAlerts.length > 0 
                    ? 'bg-rose-600 text-white' 
                    : criticalAlerts.length > 0
                    ? 'bg-amber-600 text-white'
                    : 'bg-blue-600 text-white'
                }`}>
                  {expiredAlerts.length > 0 ? 'Urgent Expiry Alert' : 'LC Expiry Schedule'}
                </span>

                <div className="flex items-center gap-1.5 text-xs font-mono font-bold">
                  {expiredAlerts.length > 0 && (
                    <span className="bg-rose-100 text-rose-800 px-2 py-0.5 rounded-md border border-rose-200">
                      {expiredAlerts.length} Expired / Lapsed
                    </span>
                  )}
                  {criticalAlerts.length > 0 && (
                    <span className="bg-amber-100 text-amber-900 px-2 py-0.5 rounded-md border border-amber-200">
                      {criticalAlerts.length} Critical (≤ 7 Days)
                    </span>
                  )}
                  {warningAlerts.length > 0 && (
                    <span className="bg-blue-100 text-blue-900 px-2 py-0.5 rounded-md border border-blue-200">
                      {warningAlerts.length} Upcoming (≤ 30 Days)
                    </span>
                  )}
                </div>
              </div>

              {/* Ticker / Top Alert Highlight */}
              <div className="mt-1 flex items-center gap-2 text-xs">
                <span className="font-bold text-slate-900 font-mono">{topAlert.lcNumber}</span>
                <span className="text-slate-400">•</span>
                <span className="text-slate-700 font-medium">
                  {topAlert.categoryLabel}: <strong className="font-mono text-slate-900">{topAlert.targetDate}</strong>
                </span>
                <span className={`font-mono font-bold px-1.5 py-0.2 rounded text-[11px] ${
                  topAlert.daysRemaining < 0 
                    ? 'bg-rose-200 text-rose-900' 
                    : topAlert.daysRemaining <= 7
                    ? 'bg-amber-200 text-amber-900'
                    : 'bg-blue-200 text-blue-900'
                }`}>
                  {topAlert.daysRemaining < 0 
                    ? `Lapsed by ${Math.abs(topAlert.daysRemaining)} days` 
                    : `${topAlert.daysRemaining} days left`}
                </span>
              </div>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
            {onFilterUrgent && (
              <button
                type="button"
                onClick={onFilterUrgent}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  isUrgentFiltered
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-white hover:bg-slate-100 text-slate-800 border border-slate-300/80 shadow-2xs'
                }`}
              >
                <Filter className="w-3.5 h-3.5" />
                <span>{isUrgentFiltered ? 'Showing Critical Only' : 'Filter Expiring LCs'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={onOpenAlertModal}
              className={`px-3.5 py-1.5 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 ${
                expiredAlerts.length > 0 
                  ? 'bg-rose-600 hover:bg-rose-700' 
                  : criticalAlerts.length > 0
                  ? 'bg-amber-600 hover:bg-amber-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              <span>View All Alerts ({alerts.length})</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
