import React, { useState, useMemo, useEffect } from 'react';
import { 
  FileText, 
  Search, 
  Plus, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Building2, 
  Calendar, 
  ExternalLink, 
  Edit3, 
  Filter, 
  ShieldAlert, 
  Sparkles,
  ArrowUpDown,
  Tag,
  DollarSign,
  Coins,
  Zap,
  Landmark,
  Calculator,
  Receipt,
  MapPin,
  ArrowDownToLine,
  Lock
} from 'lucide-react';
import { LetterOfCredit, LCStatus, LCType } from '../../types/erp';
import { ModalWrapper } from '../common/ModalWrapper';

interface DocumentaryCreditTrackerProps {
  lcs: LetterOfCredit[];
  onAddLc: (newLcData: {
    lcNumber: string;
    issuingBank: string;
    maturityDate: string;
    status: LCStatus;
    supplierName: string;
    lcType: LCType;
    cfrAmount: number;
    commodity: string;
    borderLandPort?: string;
    quantity?: number;
    uom?: string;
    currency?: string;
    exchangeRate?: number;
    officialLcRate?: number;
    actualRate?: number;
    rateDifference?: number;
    differentialAmount?: number;
    differentialAmountBdt?: number;
  }) => void;
  onUpdateLc: (lcId: string, updatedFields: Partial<LetterOfCredit>) => void;
  onSelectLcForCosting: (lc: LetterOfCredit) => void;
  onSelectLcForReceiving?: (lc: LetterOfCredit) => void;
  onNavigateToReceiving?: () => void;
}

export const DocumentaryCreditTracker: React.FC<DocumentaryCreditTrackerProps> = ({
  lcs,
  onAddLc,
  onUpdateLc,
  onSelectLcForCosting,
  onSelectLcForReceiving,
  onNavigateToReceiving,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [bankFilter, setBankFilter] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingLc, setEditingLc] = useState<LetterOfCredit | null>(null);

  // Prevent background scroll and cursor freeze when modal is open
  useEffect(() => {
    if (showAddModal) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow || 'unset';
      };
    }
  }, [showAddModal]);

  // Form states for Create / Edit
  const [formLcNumber, setFormLcNumber] = useState('');
  const [formIssuingBank, setFormIssuingBank] = useState('');
  const [formOpeningDate, setFormOpeningDate] = useState(new Date().toISOString().split('T')[0]);
  const [formMaturityDate, setFormMaturityDate] = useState('');
  const [formStatus, setFormStatus] = useState<LCStatus>('' as any);
  const [formSupplier, setFormSupplier] = useState('');
  const [formLcType, setFormLcType] = useState<LCType>('' as any);
  const [formCfrAmount, setFormCfrAmount] = useState<number>(0);
  const [formCommodity, setFormCommodity] = useState('');
  const [formBorderLandPort, setFormBorderLandPort] = useState('');

  // Quantity, Currency, Dual-Pricing
  const [formQuantity, setFormQuantity] = useState<number>(0);
  const [formUom, setFormUom] = useState<string>('');
  const [formCurrency, setFormCurrency] = useState<'USD' | 'INR'>('' as any);
  const [formExchangeRate, setFormExchangeRate] = useState<number>(0);
  const [formOfficialRate, setFormOfficialRate] = useState<number>('' as any);
  const [formActualRate, setFormActualRate] = useState<number>('' as any);

  const resetForm = () => {
    setFormLcNumber('');
    setFormIssuingBank('');
    setFormOpeningDate(new Date().toISOString().split('T')[0]);
    setFormMaturityDate('');
    setFormStatus('' as any);
    setFormSupplier('');
    setFormLcType('' as any);
    setFormCfrAmount(0);
    setFormCommodity('');
    setFormBorderLandPort('');
    setFormQuantity(0);
    setFormUom('');
    setFormCurrency('' as any);
    setFormExchangeRate(0);
    setFormOfficialRate('' as any);
    setFormActualRate('' as any);
  };

  const handleCloseModal = () => {
    resetForm();
    setEditingLc(null);
    setShowAddModal(false);
  };

  const isFormDirty = editingLc
    ? (
        formIssuingBank !== editingLc.issuingBank ||
        formOpeningDate !== (editingLc.openingDate || new Date().toISOString().split('T')[0]) ||
        formMaturityDate !== (editingLc.maturityDate || editingLc.lcExpiryDate || '') ||
        formStatus !== editingLc.status ||
        formSupplier !== editingLc.supplierName ||
        formLcType !== editingLc.lcType ||
        formBorderLandPort !== (editingLc.borderLandPort || 'Burimari')
      )
    : (
        formLcNumber.trim() !== '' ||
        formIssuingBank !== '' ||
        formMaturityDate !== '' ||
        Boolean(formStatus) ||
        formSupplier !== '' ||
        Boolean(formLcType) ||
        formCommodity !== '' ||
        formBorderLandPort !== '' ||
        formQuantity !== 0 ||
        formUom !== '' ||
        Boolean(formCurrency) ||
        formExchangeRate !== 0 ||
        Boolean(formOfficialRate) ||
        Boolean(formActualRate)
      );

  // Open modal for creating new LC (Requirement 5: forwards to real New LC form)
  const handleOpenAddModal = () => {
    setEditingLc(null);
    const randomSuffix = Math.floor(Math.random() * 899 + 100);
    const d = new Date();
    d.setDate(d.getDate() + 90);
    onAddLc({
      lcNumber: `LC-2026-SB-${randomSuffix}`,
      issuingBank: 'Eastern Bank PLC',
      maturityDate: d.toISOString().split('T')[0],
      status: 'Confirmed',
      supplierName: 'Pelden Enterprise Limited (Bhutan)',
      lcType: 'Usance 90 Days',
      cfrAmount: 14000,
      commodity: 'S-Samtse Boulder',
      borderLandPort: 'Burimari',
      quantity: 1000,
      uom: 'MT',
      currency: 'USD',
      exchangeRate: 122.50,
      officialLcRate: 14.00,
      actualRate: 18.00
    });
  };

  // Open modal for editing an existing LC
  const handleOpenEditModal = (lc: LetterOfCredit) => {
    setEditingLc(lc);
    setFormLcNumber(lc.lcNumber);
    setFormIssuingBank(lc.issuingBank);
    setFormOpeningDate(lc.openingDate || new Date().toISOString().split('T')[0]);
    setFormMaturityDate(lc.maturityDate || lc.lcExpiryDate || '');
    setFormStatus(lc.status);
    setFormSupplier(lc.supplierName);
    setFormLcType(lc.lcType);
    setFormCfrAmount(lc.cfrAmount);
    setFormCommodity(lc.items[0]?.itemName || lc.originQuarryItem || 'S-Samtse Boulder');
    setFormBorderLandPort(lc.borderLandPort || 'Burimari');
    setFormQuantity(lc.quantity || lc.items[0]?.quantity || 1000);
    setFormUom(lc.uom || lc.items[0]?.uom || 'MT');
    setFormCurrency((lc.currency === 'INR' ? 'INR' : 'USD'));
    setFormExchangeRate(lc.exchangeRate || 122.50);
    setFormOfficialRate(lc.officialLcRate || lc.lcBankRateUsd || lc.items[0]?.unitPriceForeign || 14.00);
    setFormActualRate(lc.actualRate || lc.contractRateUsd || 18.00);
    setShowAddModal(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formLcNumber.trim() || !formIssuingBank.trim() || !formMaturityDate) {
      return;
    }

    const calculatedOfficialTotal = formQuantity * formOfficialRate;
    const calculatedActualTotal = formQuantity * formActualRate;
    const rateDiff = Math.max(0, formActualRate - formOfficialRate);
    const calculatedDiffAmount = formQuantity * rateDiff;
    const calculatedDiffBdt = calculatedDiffAmount * formExchangeRate;

    if (editingLc) {
      // Requirement 3: After LC is created, value, quantity, rate, exchange rate and margin are read-only
      onUpdateLc(editingLc.id, {
        issuingBank: formIssuingBank.trim(),
        openingDate: formOpeningDate,
        maturityDate: formMaturityDate,
        status: formStatus,
        supplierName: formSupplier.trim(),
        lcType: formLcType,
        lcExpiryDate: formMaturityDate,
        borderLandPort: formBorderLandPort,
        portOfDischarge: `${formBorderLandPort} Land Port, Bangladesh`
      });
    } else {
      onAddLc({
        lcNumber: formLcNumber.trim(),
        issuingBank: formIssuingBank.trim(),
        maturityDate: formMaturityDate,
        status: formStatus,
        supplierName: formSupplier.trim() || 'Pelden Enterprise Limited',
        lcType: formLcType,
        cfrAmount: calculatedOfficialTotal,
        commodity: formCommodity.trim() || 'S-Samtse Boulder',
        borderLandPort: formBorderLandPort,
        quantity: formQuantity,
        uom: formUom,
        currency: formCurrency,
        exchangeRate: formExchangeRate,
        officialLcRate: formOfficialRate,
        actualRate: formActualRate,
        rateDifference: rateDiff,
        differentialAmount: calculatedDiffAmount,
        differentialAmountBdt: calculatedDiffBdt
      });
    }

    setShowAddModal(false);
    setEditingLc(null);
  };

  // Unique banks for filter
  const uniqueBanks = useMemo(() => {
    const banks = new Set<string>();
    lcs.forEach(lc => {
      if (lc.issuingBank) banks.add(lc.issuingBank);
    });
    return Array.from(banks);
  }, [lcs]);

  // Filtered LCs
  const filteredLcs = useMemo(() => {
    return lcs.filter(lc => {
      const q = searchTerm.toLowerCase();
      const matchSearch = 
        lc.lcNumber.toLowerCase().includes(q) ||
        lc.issuingBank.toLowerCase().includes(q) ||
        lc.supplierName.toLowerCase().includes(q) ||
        lc.items.some(i => i.itemName.toLowerCase().includes(q));

      const matchStatus = statusFilter === 'ALL' || lc.status === statusFilter;
      const matchBank = bankFilter === 'ALL' || lc.issuingBank === bankFilter;

      return matchSearch && matchStatus && matchBank;
    });
  }, [lcs, searchTerm, statusFilter, bankFilter]);

  // Statistics (Exclude Cancelled LCs - Requirement 3)
  const stats = useMemo(() => {
    const activeLcs = lcs.filter(l => l.status !== 'Cancelled' && !l.isCancelled);
    const total = activeLcs.length;
    const confirmed = activeLcs.filter(l => l.status === 'Confirmed').length;
    const discrepant = activeLcs.filter(l => l.status === 'Discrepant').length;
    const draft = activeLcs.filter(l => l.status === 'Draft').length;
    const totalValueUSD = activeLcs.reduce((acc, l) => acc + (l.cfrAmount || 0), 0);
    return { total, confirmed, discrepant, draft, totalValueUSD };
  }, [lcs]);

  const getStatusBadge = (status: LCStatus) => {
    switch (status) {
      case 'Confirmed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Confirmed
          </span>
        );
      case 'Discrepant':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-300">
            <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
            Discrepant
          </span>
        );
      case 'Draft':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            Draft
          </span>
        );
      case 'Cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-300">
            <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
            Cancelled
          </span>
        );
      case 'Shipment In-Transit':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">
            In-Transit
          </span>
        );
      case 'Customs Cleared':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-teal-100 text-teal-800 border border-teal-200">
            Customs Cleared
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800 border border-indigo-200">
            {status}
          </span>
        );
    }
  };

  const calculateDaysToMaturity = (dateStr?: string) => {
    if (!dateStr) return null;
    const maturity = new Date(dateStr);
    const today = new Date();
    const diffTime = maturity.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-5">
      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Total Documentary Credits</span>
            <FileText className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono">{stats.total}</span>
            <span className="text-xs text-slate-500">LCs Recorded</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Exposure: ${stats.totalValueUSD.toLocaleString()} USD
          </div>
        </div>

        <div className="bg-white border border-emerald-200 rounded-xl p-4 shadow-2xs bg-emerald-50/20">
          <div className="flex items-center justify-between text-emerald-800 text-xs font-medium">
            <span>Confirmed LCs</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-emerald-700 font-mono">{stats.confirmed}</span>
            <span className="text-xs text-emerald-600">Compliant</span>
          </div>
          <div className="text-[11px] text-emerald-600 mt-1">
            Confirmed by overseas bank
          </div>
        </div>

        <div className="bg-white border border-rose-200 rounded-xl p-4 shadow-2xs bg-rose-50/20">
          <div className="flex items-center justify-between text-rose-800 text-xs font-medium">
            <span>Discrepant LCs</span>
            <ShieldAlert className="w-4 h-4 text-rose-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-rose-700 font-mono">{stats.discrepant}</span>
            <span className="text-xs text-rose-600 font-semibold">Requires Action</span>
          </div>
          <div className="text-[11px] text-rose-600 mt-1">
            Document discrepancies noted
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Draft Applications</span>
            <Clock className="w-4 h-4 text-slate-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-800 font-mono">{stats.draft}</span>
            <span className="text-xs text-slate-500">In Preparation</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Pending bank transmission
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-900 to-indigo-950 text-white rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-blue-200 text-xs font-medium">
            <span>Trade Facility</span>
            <Sparkles className="w-4 h-4 text-blue-300" />
          </div>
          <div className="mt-2">
            <span className="text-xl font-black font-mono tracking-tight">
              ${(stats.totalValueUSD / 1000000).toFixed(2)}M
            </span>
          </div>
          <div className="text-[11px] text-blue-200/80 mt-1">
            Total active trade commitment
          </div>
        </div>
      </div>

      {/* Main Filter & Action Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by LC number, issuing bank, supplier, or commodity..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={bankFilter}
              onChange={(e) => setBankFilter(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:ring-1 focus:ring-blue-500 outline-none"
            >
              <option value="ALL">All Issuing Banks</option>
              {uniqueBanks.map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>

            {onNavigateToReceiving && (
              <button
                type="button"
                onClick={onNavigateToReceiving}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-2xs transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
                title="Go to LC Product Receiving & Daily Stock Entry"
              >
                <ArrowDownToLine className="w-4 h-4" />
                <span>LC Product Receiving</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleOpenAddModal}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-2xs transition-colors flex items-center gap-1.5 shrink-0"
            >
              <Plus className="w-4 h-4" />
              New Documentary Credit
            </button>
          </div>
        </div>

        {/* Status Filter Badges */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1 border-t border-slate-100 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">Status:</span>
          {(['ALL', 'Draft', 'Confirmed', 'Discrepant', 'Shipment In-Transit', 'Customs Cleared'] as const).map((st) => {
            const isActive = statusFilter === st;
            const count = st === 'ALL' ? lcs.length : lcs.filter(l => l.status === st).length;
            return (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-lg font-medium text-xs transition-colors flex items-center gap-1.5 shrink-0 ${
                  isActive
                    ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>{st === 'ALL' ? 'All Credits' : st}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  isActive ? 'bg-blue-700 text-blue-100' : 'bg-slate-200 text-slate-700'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Table of Documentary Credits */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-3.5">LC Number & Instrument</th>
                <th className="py-3 px-3">Issuing Bank & Branch</th>
                <th className="py-3 px-3">Beneficiary / Supplier</th>
                <th className="py-3 px-3">Maturity Date</th>
                <th className="py-3 px-3.5 text-right">LC Value & Dual Rate</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredLcs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    <FileText className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-xs text-slate-600">No documentary credits match the selected filter</p>
                    <button
                      type="button"
                      onClick={handleOpenAddModal}
                      className="mt-2.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1 shadow-2xs"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add New LC Record
                    </button>
                  </td>
                </tr>
              ) : (
                filteredLcs.map((lc) => {
                  const maturity = lc.maturityDate || lc.lcExpiryDate;
                  const daysToMaturity = calculateDaysToMaturity(maturity);
                  const isDiscrepant = lc.status === 'Discrepant';

                  return (
                    <tr 
                      key={lc.id} 
                      className={`hover:bg-slate-50/80 transition-colors ${isDiscrepant ? 'bg-rose-50/20' : ''}`}
                    >
                      {/* LC Number */}
                      <td className="py-3 px-3.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-mono font-bold text-blue-700 text-xs">
                            {lc.lcNumber}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-slate-100 text-slate-700">
                            {lc.lcType}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-rose-50 text-rose-700 border border-rose-200/80 flex items-center gap-0.5">
                            <MapPin className="w-2.5 h-2.5 text-rose-500" />
                            {lc.borderLandPort ? `${lc.borderLandPort} Port` : 'Burimari Port'}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5 truncate max-w-xs">
                          {lc.items.map(i => i.itemName).join(', ') || 'General Commodity'}
                        </div>
                      </td>

                      {/* Issuing Bank */}
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-900 flex items-center gap-1">
                          <Building2 className="w-3.5 h-3.5 text-slate-400" />
                          {lc.issuingBank}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate max-w-[200px]">
                          {lc.branch || 'Principal Corporate Branch'}
                        </div>
                      </td>

                      {/* Beneficiary */}
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-800">
                          {lc.supplierName}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {lc.beneficiaryCountry || 'Foreign Trade'}
                        </div>
                      </td>

                      {/* Maturity Date */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1 font-mono font-bold text-slate-800 text-xs">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          {maturity || 'N/A'}
                        </div>
                        {daysToMaturity !== null && (
                          <div className={`text-[10px] font-medium mt-0.5 ${
                            daysToMaturity < 0 
                              ? 'text-rose-600 font-bold' 
                              : daysToMaturity <= 15 
                              ? 'text-amber-600 font-bold' 
                              : 'text-slate-500'
                          }`}>
                            {daysToMaturity < 0 
                              ? `Matured ${Math.abs(daysToMaturity)} days ago` 
                              : `${daysToMaturity} days remaining`}
                          </div>
                        )}
                      </td>

                      {/* Amount & Dual Pricing */}
                      <td className="py-3 px-3.5 text-right font-mono">
                        {(() => {
                          const currSym = lc.currency === 'INR' ? '₹' : '$';
                          const offRate = lc.officialLcRate || lc.lcBankRateUsd || 14.00;
                          const actRate = lc.actualRate || lc.contractRateUsd || offRate;
                          const rateDiff = Math.max(0, actRate - offRate);
                          const qty = lc.quantity || lc.receivedQtyMt || lc.items[0]?.quantity || 1000;
                          const diffAmount = lc.differentialAmount ?? (qty * rateDiff);
                          const diffBdt = lc.differentialAmountBdt ?? (diffAmount * (lc.exchangeRate || 122.50));

                          return (
                            <div>
                              <div className="font-bold text-slate-900 text-xs">
                                {currSym}{lc.cfrAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {lc.currency || 'USD'}
                              </div>
                              <div className="text-[10px] text-slate-500">
                                ৳ {((lc.cfrAmount * (lc.exchangeRate || 122.50)) / 1000000).toFixed(2)}M BDT
                              </div>
                              <div className="mt-1 flex flex-col items-end gap-0.5">
                                <span className="inline-flex items-center gap-1 text-[9px] font-sans px-1.5 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                                  ব্যাংক: {currSym}{offRate} | আসল: {currSym}{actRate}
                                </span>
                                {diffAmount > 0 && (
                                  <span className="inline-flex items-center gap-1 text-[9px] font-sans font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-900 border border-amber-300">
                                    <Zap className="w-2.5 h-2.5 text-amber-600" />
                                    হুন্ডি বকেয়া: {currSym}{diffAmount.toLocaleString()} (৳{diffBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })})
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })()}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center">
                        <div className="inline-block">
                          {getStatusBadge(lc.status)}
                        </div>
                        {/* Quick Status Dropdown toggle */}
                        <div className="mt-1">
                          <select
                            value={lc.status}
                            onChange={(e) => onUpdateLc(lc.id, { status: e.target.value as LCStatus })}
                            className="text-[10px] py-0.5 px-1 bg-white border border-slate-200 rounded text-slate-600 cursor-pointer focus:ring-1 focus:ring-blue-500 outline-none"
                          >
                            <option value="Draft">Draft</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Discrepant">Discrepant</option>
                            <option value="Bank Applied">Bank Applied</option>
                            <option value="Opened / Margin Paid">Opened / Margin Paid</option>
                            <option value="Shipment In-Transit">Shipment In-Transit</option>
                            <option value="Customs Cleared">Customs Cleared</option>
                          </select>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {onSelectLcForReceiving && (
                            <button
                              type="button"
                              onClick={() => onSelectLcForReceiving(lc)}
                              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded text-[11px] font-bold transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
                              title="Receive goods & stock entry under this LC"
                            >
                              <ArrowDownToLine className="w-3.5 h-3.5 text-emerald-600" />
                              Receive (Stock)
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleOpenEditModal(lc)}
                            className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-medium transition-colors flex items-center gap-1"
                            title="Edit LC Details"
                          >
                            <Edit3 className="w-3 h-3" />
                            Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => onSelectLcForCosting(lc)}
                            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded text-[11px] font-semibold transition-colors flex items-center gap-1"
                            title="Open Landed Cost Engine"
                          >
                            Costing Engine →
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Create or Edit Documentary Credit (LC) */}
      {showAddModal && (
        <ModalWrapper
          isOpen={showAddModal}
          onClose={handleCloseModal}
          isDirty={isFormDirty}
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs overflow-y-auto overscroll-contain flex min-h-full items-center justify-center p-4 animate-in fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-5 space-y-4 max-h-[85vh] overflow-y-auto overscroll-contain my-auto border border-slate-200"
          >
            <div className="sticky top-0 z-20 bg-white -mx-5 -mt-5 px-5 pt-4 pb-3 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-sm text-slate-900">
                  {editingLc ? 'Edit Documentary Credit (LC)' : 'New Documentary Credit (LC)'}
                </h3>
              </div>
              <button 
                type="button"
                data-modal-close="true"
                onClick={handleCloseModal} 
                className="text-slate-400 hover:text-slate-600 text-xs font-bold p-1 rounded hover:bg-slate-100 shrink-0 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* 1: Quick Import Presets */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">1</span>
                  Quick Import Presets:
                </span>
                <span className="text-[10px] text-slate-500 font-medium">
                  {formCommodity ? `Selected: ${formCommodity}` : 'Select Preset'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const r = Math.floor(Math.random() * 899 + 100);
                    setFormCommodity('S-Samtse Boulder');
                    setFormLcNumber(`LC-2026-SB-${r}`);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all shadow-2xs group cursor-pointer ${
                    formCommodity === 'S-Samtse Boulder'
                      ? 'bg-indigo-50 border-indigo-500 ring-2 ring-indigo-500/20 shadow-xs'
                      : 'bg-white hover:bg-indigo-50/50 hover:border-indigo-300 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-mono font-black text-xs flex items-center justify-center shrink-0 shadow-xs">
                      S
                    </span>
                    <span className="font-bold text-slate-900 text-xs truncate group-hover:text-indigo-700">
                      S-Samtse Boulder
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block pl-8 truncate font-medium">
                    Samtse Boulder Stone
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const r = Math.floor(Math.random() * 899 + 100);
                    setFormCommodity('P-Phuentsholing Boulder');
                    setFormLcNumber(`LC-2026-PB-${r}`);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all shadow-2xs group cursor-pointer ${
                    formCommodity === 'P-Phuentsholing Boulder'
                      ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'bg-white hover:bg-emerald-50/50 hover:border-emerald-300 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white font-mono font-black text-xs flex items-center justify-center shrink-0 shadow-xs">
                      P
                    </span>
                    <span className="font-bold text-slate-900 text-xs truncate group-hover:text-emerald-700">
                      P-Phuentsholing Boulder
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block pl-8 truncate font-medium">
                    Phuentsholing Boulder Stone
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const r = Math.floor(Math.random() * 899 + 100);
                    setFormCommodity('R-Indian River Stone Boulder');
                    setFormLcNumber(`LC-2026-IR-${r}`);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all shadow-2xs group cursor-pointer ${
                    formCommodity === 'R-Indian River Stone Boulder'
                      ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-500/20 shadow-xs'
                      : 'bg-white hover:bg-amber-50/50 hover:border-amber-300 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-6 h-6 rounded-lg bg-amber-600 text-white font-mono font-black text-xs flex items-center justify-center shrink-0 shadow-xs">
                      R
                    </span>
                    <span className="font-bold text-slate-900 text-xs truncate group-hover:text-amber-700">
                      R-Indian River Stone Boulder
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block pl-8 truncate font-medium">
                    Indian River Boulder
                  </span>
                </button>
              </div>
            </div>

            <form onSubmit={handleFormSubmit} autoComplete="off" className="space-y-3.5 text-xs">
              {/* Row 1: LC Number & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    LC Number <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formLcNumber}
                    onChange={(e) => setFormLcNumber(e.target.value)}
                    placeholder="e.g. LC-2026-SB-105"
                    className="w-full p-2 border border-slate-200 rounded font-mono font-bold focus:ring-1 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Status <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as LCStatus)}
                    className="w-full p-2 border border-slate-200 rounded font-semibold focus:ring-1 focus:ring-blue-500 outline-none"
                  >
                    <option value="">-- Select Status --</option>
                    <option value="Draft">Draft</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Discrepant">Discrepant</option>
                    <option value="Bank Applied">Bank Applied</option>
                    <option value="Opened / Margin Paid">Opened / Margin Paid</option>
                    <option value="Shipment In-Transit">Shipment In-Transit</option>
                    <option value="Customs Cleared">Customs Cleared</option>
                  </select>
                </div>
              </div>

              {/* 2: Supplier & Item Section */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center gap-1.5 pb-1 border-b border-slate-200/80">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">2</span>
                  <span className="text-xs font-bold text-slate-800">Supplier & Item Selection</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Beneficiary / Supplier <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={formSupplier}
                      onChange={(e) => setFormSupplier(e.target.value)}
                      required
                      className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-white font-medium"
                    >
                      <option value="">-- Select Supplier / Beneficiary --</option>
                      <option value="Pelden Enterprise Limited (Bhutan)">Pelden Enterprise Limited (Bhutan)</option>
                      <option value="M/S Sawdagar Enterprise (India)">M/S Sawdagar Enterprise (India)</option>
                      <option value="Druk Stone Quarry & Minerals (Bhutan)">Druk Stone Quarry & Minerals (Bhutan)</option>
                      <option value="Singye Stone Export (Bhutan)">Singye Stone Export (Bhutan)</option>
                      <option value="Baosteel International Trading Corp">Baosteel International Trading Corp (China)</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Commodity / Product <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={formCommodity}
                      onChange={(e) => setFormCommodity(e.target.value)}
                      required
                      className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-white font-bold"
                    >
                      <option value="">-- Select Import Item / Commodity --</option>
                      <optgroup label="⭐ Featured Boulder Products">
                        <option value="S-Samtse Boulder">S-Samtse Boulder</option>
                        <option value="P-Phuentsholing Boulder">P-Phuentsholing Boulder</option>
                        <option value="R-Indian River Stone Boulder">R-Indian River Stone Boulder</option>
                      </optgroup>
                      <optgroup label="🪨 Aggregates & Stone Items">
                        <option value="Boulder Stone - Phuentsholing Quarry">Boulder Stone - Phuentsholing Quarry</option>
                        <option value="River Stone Boulder - India Torsha">River Stone Boulder - India Torsha</option>
                        <option value="Boulder Stone (Samtse River Boulder)">Boulder Stone (Samtse River Boulder)</option>
                        <option value="3/4 Down / 20MM Crush Stone">3/4" Down / 20MM Crush Stone</option>
                        <option value="1/2 Crush Stone">1/2" Crush Stone</option>
                        <option value="5/8 Crush Stone">5/8" Crush Stone</option>
                      </optgroup>
                    </select>
                  </div>

                  {/* Border Land Port Selection */}
                  <div className="col-span-1 sm:col-span-2">
                    <label className="font-bold text-slate-700 block mb-1 flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-blue-900">
                        <MapPin className="w-3.5 h-3.5 text-rose-500" />
                        Border / Land Port Entry <span className="text-rose-500">*</span>
                      </span>
                      <span className="text-[10px] text-slate-500 font-normal">
                        Border port of entry into Bangladesh
                      </span>
                    </label>
                    <select
                      value={formBorderLandPort}
                      onChange={(e) => setFormBorderLandPort(e.target.value)}
                      required
                      className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-blue-50/20 font-bold text-slate-900"
                    >
                      <option value="">-- Select Border / Land Port --</option>
                      <option value="Burimari">Burimari Land Port - Lalmonirhat (Bhutan & Changrabandha)</option>
                      <option value="Sonahat">Sonahat Land Port - Kurigram (Assam & Bhutan Border)</option>
                      <option value="Banglabandha">Banglabandha Land Port - Panchagarh (Siliguri & Bhutan)</option>
                      <option value="Tamabil">Tamabil Land Port - Sylhet (Dawki & Meghalaya Border)</option>
                      <option value="Hili">Hili Land Port - Dinajpur (India Border)</option>
                      <option value="Sonamasjid">Sonamasjid Land Port - Chapainawabganj (India Border)</option>
                      <option value="Benapole">Benapole Land Port - Jessore (Petrapole Border)</option>
                      <option value="Bhomra">Bhomra Land Port - Satkhira (Ghojadanga Border)</option>
                      <option value="Chittagong Port">Chittagong Sea Port - Bulk Cargo</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Row: Issuing Bank & LC Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Issuing Bank <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formIssuingBank}
                    onChange={(e) => setFormIssuingBank(e.target.value)}
                    placeholder="e.g. Eastern Bank PLC"
                    className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Instrument Type
                  </label>
                  <select
                    value={formLcType}
                    onChange={(e) => setFormLcType(e.target.value as LCType)}
                    className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none"
                  >
                    <option value="">-- Select Instrument Type --</option>
                    <option value="Sight">Irrevocable Sight LC</option>
                    <option value="Usance 90 Days">Usance 90 Days LC</option>
                    <option value="Usance 180 Days">Usance 180 Days LC</option>
                    <option value="UPAS">UPAS LC (Buyer Credit)</option>
                    <option value="Cash LC">Cash LC</option>
                  </select>
                </div>
              </div>

              {/* 3: Date Details */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center gap-1.5 pb-1 border-b border-slate-200/80">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">3</span>
                  <span className="text-xs font-bold text-slate-800">Date Details</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Opening Date <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={formOpeningDate}
                      onChange={(e) => setFormOpeningDate(e.target.value)}
                      className="w-full p-2 border border-slate-200 rounded font-mono focus:ring-1 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Expiry Date <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={formMaturityDate}
                      onChange={(e) => setFormMaturityDate(e.target.value)}
                      className="w-full p-2 border border-slate-200 rounded font-mono focus:ring-1 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Established LC Locked Note (Requirement 3) */}
              {Boolean(editingLc) && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl flex items-center gap-2 text-[11px] font-semibold">
                  <Lock className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Established LC: Value, quantity, unit rate, and currency are read-only.</span>
                </div>
              )}

              {/* Quantity, UOM, Currency & Rate */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-slate-200/80">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Coins className="w-3.5 h-3.5 text-blue-600" />
                    Quantity & Currency
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    1 {formCurrency} = {formExchangeRate} BDT
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="col-span-1 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">
                      Quantity <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="number"
                      disabled={Boolean(editingLc)}
                      value={formQuantity || ''}
                      onChange={(e) => {
                        const q = e.target.value === '' ? 0 : Math.max(1, Number(e.target.value));
                        setFormQuantity(q);
                        setFormCfrAmount(q * (Number(formOfficialRate) || 0));
                      }}
                      min={1}
                      required
                      placeholder="e.g. 1000"
                      className={`w-full border rounded-xl p-2 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none ${
                        Boolean(editingLc) ? 'bg-slate-100 text-slate-500 border-slate-200 cursor-not-allowed' : 'bg-white border-slate-300'
                      }`}
                    />
                  </div>

                  <div className="col-span-1 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">
                      UOM
                    </label>
                    <select
                      disabled={Boolean(editingLc)}
                      value={formUom}
                      onChange={(e) => setFormUom(e.target.value)}
                      className={`w-full border rounded-xl p-2 font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none ${
                        Boolean(editingLc) ? 'bg-slate-100 text-slate-500 border-slate-200 cursor-not-allowed' : 'bg-white border-slate-300'
                      }`}
                    >
                      <option value="">Select UOM...</option>
                      <option value="MT">MT (Metric Ton)</option>
                      <option value="CFT">CFT (Cubic Feet)</option>
                      <option value="Ton">Ton</option>
                    </select>
                  </div>

                  <div className="col-span-1 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">
                      Currency <span className="text-rose-500">*</span>
                    </label>
                    <select
                      disabled={Boolean(editingLc)}
                      value={formCurrency}
                      onChange={(e) => {
                        const cur = e.target.value as 'USD' | 'INR';
                        setFormCurrency(cur);
                      }}
                      className={`w-full border rounded-xl p-2 font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none ${
                        Boolean(editingLc) ? 'bg-slate-100 text-slate-500 border-slate-200 cursor-not-allowed' : 'bg-white border-slate-300'
                      }`}
                    >
                      <option value="">Select Currency...</option>
                      <option value="USD">USD ($ US Dollar)</option>
                      <option value="INR">INR (₹ Indian Rupee)</option>
                    </select>
                  </div>

                  <div className="col-span-1 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">
                      BDT Exchange Rate
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      disabled={Boolean(editingLc)}
                      value={formExchangeRate || ''}
                      onChange={(e) => setFormExchangeRate(Number(e.target.value))}
                      required
                      className={`w-full border rounded-xl p-2 font-mono font-medium text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none ${
                        Boolean(editingLc) ? 'bg-slate-100 text-slate-500 border-slate-200 cursor-not-allowed' : 'bg-white border-slate-300'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* ডুয়াল প্রাইসিং সেকশন: ব্যাংক এলসি রেট বনাম প্রোডাক্টের আসল রেট */}
              <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200/90 space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-amber-200">
                  <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-amber-600" />
                    ডুয়াল প্রাইসিং ইউনিট রেট (Bank LC Rate vs Actual Commercial Rate)
                  </span>
                  <span className="text-[10px] text-amber-800 font-semibold bg-amber-100 px-2 py-0.5 rounded-md">
                    পার্থক্য: {formCurrency === 'INR' ? '₹' : '$'}{Math.max(0, formActualRate - formOfficialRate).toFixed(2)} / {formUom}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="bg-white p-2.5 rounded-xl border border-blue-200 shadow-2xs">
                    <label className="block font-bold text-blue-900 mb-0.5">
                      ১. ব্যাংক এলসি রেট / ইউনিট প্রাইস ({formCurrency === 'INR' ? '₹' : '$'}) <span className="text-rose-500">*</span>
                    </label>
                    <p className="text-[10px] text-blue-600 mb-1.5">
                      ব্যাংকে যে রেট দিয়ে এলসি খোলা হচ্ছে (অফিসিয়াল ব্যাংক পেমেন্ট)
                    </p>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono font-bold text-slate-400">
                        {formCurrency === 'INR' ? '₹' : '$'}
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        disabled={Boolean(editingLc)}
                        value={formOfficialRate}
                        onChange={(e) => {
                          const r = Number(e.target.value);
                          setFormOfficialRate(r);
                          setFormCfrAmount(formQuantity * r);
                        }}
                        min={0.01}
                        required
                        placeholder="e.g. 14.00"
                        className={`w-full pl-7 pr-3 py-2 border rounded-lg font-mono font-bold text-sm text-blue-900 focus:ring-2 focus:ring-blue-500 focus:outline-none ${
                          Boolean(editingLc) ? 'bg-slate-100 text-slate-500 border-slate-200 cursor-not-allowed' : 'bg-blue-50/30 border-slate-300'
                        }`}
                      />
                    </div>
                  </div>

                  <div className="bg-white p-2.5 rounded-xl border border-amber-300 shadow-2xs">
                    <label className="block font-bold text-amber-950 mb-0.5">
                      ২. প্রোডাক্টের আসল রেট ({formCurrency === 'INR' ? '₹' : '$'}) <span className="text-rose-500">*</span>
                    </label>
                    <p className="text-[10px] text-amber-700 mb-1.5">
                      এক্সপোর্টারের সাথে নির্ধারিত মূল চুক্তি রেট (প্রকৃত খরচ)
                    </p>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono font-bold text-slate-400">
                        {formCurrency === 'INR' ? '₹' : '$'}
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        disabled={Boolean(editingLc)}
                        value={formActualRate}
                        onChange={(e) => setFormActualRate(Number(e.target.value))}
                        min={0.01}
                        required
                        placeholder="e.g. 18.00"
                        className={`w-full pl-7 pr-3 py-2 border rounded-lg font-mono font-bold text-sm text-amber-950 focus:ring-2 focus:ring-amber-500 focus:outline-none ${
                          Boolean(editingLc) ? 'bg-slate-100 text-slate-500 border-slate-200 cursor-not-allowed' : 'bg-amber-50/30 border-slate-300'
                        }`}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* স্বয়ংক্রিয় পেমেন্ট ও হুন্ডি বিভাজন লাইভ কার্ড */}
              {(() => {
                const currSym = formCurrency === 'INR' ? '₹' : '$';
                const officialLcTotal = formQuantity * formOfficialRate;
                const actualTotalAmount = formQuantity * formActualRate;
                const rateDiff = Math.max(0, formActualRate - formOfficialRate);
                const differentialAmount = formQuantity * rateDiff;
                const officialLcTotalBdt = officialLcTotal * formExchangeRate;
                const actualTotalAmountBdt = actualTotalAmount * formExchangeRate;
                const differentialAmountBdt = differentialAmount * formExchangeRate;

                return (
                  <div className="p-3 bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 text-white rounded-2xl border border-slate-700 shadow-md space-y-2.5">
                    <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
                      <span className="text-xs font-bold flex items-center gap-1.5 text-indigo-300">
                        <Calculator className="w-3.5 h-3.5 text-amber-400" />
                        স্বয়ংক্রিয় পেমেন্ট ও হুন্ডি ডিফারেন্সিয়াল বিভাজন হিসাব
                      </span>
                      <span className="text-[10px] font-mono text-emerald-400 font-bold px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-700/60">
                        মোট পরিমাণ: {formQuantity.toLocaleString()} {formUom}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                      {/* Box 1: Official Bank LC Total */}
                      <div className="bg-slate-800/90 rounded-xl p-2.5 border border-blue-500/40">
                        <div className="text-[10px] text-blue-300 font-bold uppercase tracking-wider flex items-center gap-1">
                          <Landmark className="w-3 h-3 text-blue-400" />
                          ১. ব্যাংক এলসি মোট মূল্য:
                        </div>
                        <div className="text-base font-black font-mono text-white mt-0.5">
                          {currSym}{officialLcTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-blue-200 font-mono">
                          ৳ {officialLcTotalBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                        </div>
                        <span className="inline-block mt-1 text-[9px] text-blue-300 font-semibold bg-blue-900/60 px-1.5 py-0.5 rounded">
                          🏦 ব্যাংকের মাধ্যমে এলসি পেমেন্ট
                        </span>
                      </div>

                      {/* Box 2: Actual Commercial Total */}
                      <div className="bg-slate-800/90 rounded-xl p-2.5 border border-indigo-500/40">
                        <div className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider flex items-center gap-1">
                          <Receipt className="w-3 h-3 text-indigo-400" />
                          ২. প্রোডাক্টের আসল মোট মূল্য:
                        </div>
                        <div className="text-base font-black font-mono text-white mt-0.5">
                          {currSym}{actualTotalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-indigo-200 font-mono">
                          ৳ {actualTotalAmountBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                        </div>
                        <span className="inline-block mt-1 text-[9px] text-indigo-300 font-semibold bg-indigo-900/60 px-1.5 py-0.5 rounded">
                          📦 এক্সপোর্টারের প্রকৃত মোট পাওনা
                        </span>
                      </div>

                      {/* Box 3: Hundi / Unofficial Payment Difference */}
                      <div className="bg-amber-950/50 rounded-xl p-2.5 border border-amber-500/60">
                        <div className="text-[10px] text-amber-300 font-bold uppercase tracking-wider flex items-center gap-1">
                          <Zap className="w-3 h-3 text-amber-400" />
                          ৩. হুন্ডি / আন-অফিসিয়াল বকেয়া:
                        </div>
                        <div className="text-base font-black font-mono text-amber-300 mt-0.5">
                          {currSym}{differentialAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-amber-200 font-mono font-bold">
                          ৳ {differentialAmountBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                          {formCurrency === 'USD' && ` (₹${(differentialAmount * 83.5).toLocaleString('en-US', { maximumFractionDigits: 0 })} INR)`}
                        </div>
                        <span className="inline-block mt-1 text-[9px] text-amber-300 font-semibold bg-amber-900/70 px-1.5 py-0.5 rounded">
                          ⚡ হুন্ডি বা ক্যাশ টাকায় পরিশোধ
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Status Note / Guidance */}
              {formStatus === 'Discrepant' && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Discrepancy Notice:</span> This LC will be flagged in the tracker as requiring bank document amendments or discrepancy clearance before negotiation.
                  </div>
                </div>
              )}

              {formStatus === 'Confirmed' && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Confirmation Confirmed:</span> Advising/Confirming bank guarantees payment upon compliant presentation.
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleCloseModal}
                  className="px-3.5 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg shadow-2xs transition-colors cursor-pointer"
                >
                  {editingLc ? 'Save LC Changes' : 'Record Documentary Credit'}
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
