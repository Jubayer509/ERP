/**
 * LC & Import Hub Design System Tokens (TypeScript definitions)
 * Matches tokens.css exactly
 */

export const LC_TOKENS = {
  colors: {
    bgPage: '#F8FAFC',
    surface: '#FFFFFF',
    border: '#E5E7EB',
    borderSubtle: '#F1F5F9',
    textPrimary: '#0F172A',
    textMuted: '#64748B',
    textSubtle: '#94A3B8',
    // ONE Accent Color
    accent: '#2563EB',
    accentHover: '#1D4ED8',
    accentActive: '#1E40AF',
    accentSubtle: '#EFF6FF',
    accentText: '#1E40AF',
    // Status
    success: '#059669',
    successSubtle: '#ECFDF5',
    warning: '#D97706',
    warningSubtle: '#FFFBEB',
    danger: '#DC2626',
    dangerSubtle: '#FEF2F2',
    neutral: '#64748B',
    neutralSubtle: '#F1F5F9',
  },
  typography: {
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    fontSize: {
      body: '14px',
      label: '13px',
      helper: '12px',
      section: '15px',
      title: '20px',
    },
    fontWeight: {
      regular: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
    },
  },
  radius: {
    input: '8px',
    button: '8px',
    card: '12px',
    modal: '12px',
  },
  heights: {
    input: '40px',
    buttonMd: '40px',
    buttonSm: '32px',
  },
  spacing: {
    1: '4px',
    2: '8px',
    3: '12px',
    4: '16px',
    5: '20px',
    6: '24px',
    8: '32px',
  },
} as const;

export type LcColorVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
export type LcStatusVariant = 'success' | 'warning' | 'danger' | 'neutral' | 'info';
export type LcSize = 'sm' | 'md' | 'lg';
