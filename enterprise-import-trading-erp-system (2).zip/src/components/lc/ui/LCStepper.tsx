import React from 'react';
import { Check } from 'lucide-react';
import { LCButton } from './LCButton';

export interface LCStep {
  id: string | number;
  label: string;
  description?: string;
}

export interface LCStepperProps {
  steps: LCStep[];
  currentStep: number; // 0-indexed
  onStepClick?: (stepIndex: number) => void;
  onNext?: () => void;
  onPrev?: () => void;
  isNextDisabled?: boolean;
  isPrevDisabled?: boolean;
  nextLabel?: string;
  prevLabel?: string;
  isSubmitting?: boolean;
  showNavButtons?: boolean;
  className?: string;
}

export const LCStepper: React.FC<LCStepperProps> = ({
  steps,
  currentStep,
  onStepClick,
  onNext,
  onPrev,
  isNextDisabled = false,
  isPrevDisabled = false,
  nextLabel = 'Next',
  prevLabel = 'Back',
  isSubmitting = false,
  showNavButtons = true,
  className = '',
}) => {
  const isFirstStep = currentStep === 0;
  const isLastStep = currentStep === steps.length - 1;
  const activeStep = steps[currentStep] || steps[0];

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Mobile Stepper Header: Collapses to "Step X of Y: Step Name" */}
      <div className="block sm:hidden pb-3 border-b border-[#E5E7EB] dark:border-slate-800">
        <div className="flex items-center justify-between text-[12px] text-slate-500 mb-1">
          <span>Step {currentStep + 1} of {steps.length}</span>
          <span className="font-medium text-[#2563EB] dark:text-blue-400">
            {Math.round(((currentStep + 1) / steps.length) * 100)}%
          </span>
        </div>
        <div className="text-[14px] font-semibold text-[#0F172A] dark:text-slate-100">
          {activeStep.label}
        </div>
        <div className="w-full bg-slate-100 dark:bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
          <div
            className="bg-[#2563EB] h-full transition-all duration-300"
            style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Desktop Stepper Header: Clean horizontal wizard header with checkmarks and underline */}
      <div className="hidden sm:flex items-center justify-between border-b border-[#E5E7EB] dark:border-slate-800 pb-3">
        {steps.map((step, idx) => {
          const isCompleted = idx < currentStep;
          const isActive = idx === currentStep;
          const isClickable = Boolean(onStepClick && idx <= currentStep);

          return (
            <React.Fragment key={step.id}>
              <button
                type="button"
                disabled={!isClickable}
                onClick={() => onStepClick && onStepClick(idx)}
                className={`relative flex items-center gap-2.5 pb-2 text-left transition-colors focus:outline-none ${
                  isClickable ? 'cursor-pointer' : 'cursor-default'
                } ${
                  isActive
                    ? 'text-[#2563EB] dark:text-blue-400 font-semibold'
                    : isCompleted
                    ? 'text-[#0F172A] dark:text-slate-200 font-medium'
                    : 'text-slate-400 font-normal'
                }`}
              >
                {/* Step Circle / Check */}
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[12px] font-semibold shrink-0 transition-colors ${
                    isCompleted
                      ? 'bg-[#059669] text-white'
                      : isActive
                      ? 'bg-[#2563EB] text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                  }`}
                >
                  {isCompleted ? <Check className="w-3.5 h-3.5" /> : idx + 1}
                </div>

                <div className="truncate">
                  <div className="text-[13px] leading-tight truncate">{step.label}</div>
                  {step.description && (
                    <div className="text-[11px] text-slate-400 font-normal truncate">
                      {step.description}
                    </div>
                  )}
                </div>

                {/* Active step bottom underline */}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#2563EB] dark:bg-blue-400" />
                )}
              </button>

              {idx < steps.length - 1 && (
                <div className="flex-1 mx-3 h-[1px] bg-[#E5E7EB] dark:bg-slate-800 self-center" />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Navigation Buttons at bottom if enabled */}
      {showNavButtons && (
        <div className="flex items-center justify-between pt-4 border-t border-[#E5E7EB] dark:border-slate-800">
          <LCButton
            variant="ghost"
            size="md"
            onClick={onPrev}
            disabled={isFirstStep || isPrevDisabled || isSubmitting}
          >
            {prevLabel}
          </LCButton>

          <LCButton
            variant="primary"
            size="md"
            onClick={onNext}
            isLoading={isSubmitting}
            disabled={isNextDisabled}
          >
            {nextLabel}
          </LCButton>
        </div>
      )}
    </div>
  );
};
