import React from 'react';

export interface LCSectionProps {
  title?: string;
  description?: string;
  divider?: boolean;
  columns?: 1 | 2;
  children: React.ReactNode;
  className?: string;
}

export const LCSection: React.FC<LCSectionProps> = ({
  title,
  description,
  divider = false,
  columns = 2,
  children,
  className = '',
}) => {
  const gridClass = columns === 2 ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : 'space-y-4';

  return (
    <div className={`space-y-3 ${divider ? 'pt-4 border-t border-[#E5E7EB] dark:border-slate-800' : ''} ${className}`}>
      {title && (
        <div className="space-y-0.5">
          <h4 className="text-[15px] font-semibold text-[#0F172A] dark:text-slate-100">
            {title}
          </h4>
          {description && (
            <p className="text-[12px] text-slate-500 dark:text-slate-400">
              {description}
            </p>
          )}
        </div>
      )}

      <div className={gridClass}>
        {children}
      </div>
    </div>
  );
};
