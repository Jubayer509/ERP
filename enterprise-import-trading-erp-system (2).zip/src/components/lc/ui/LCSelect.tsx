import React from 'react';
import { ChevronDown, Lock } from 'lucide-react';

export interface LCSelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface LCSelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  options?: LCSelectOption[];
  hasError?: boolean;
  locked?: boolean;
}

export const LCSelect = React.forwardRef<HTMLSelectElement, LCSelectProps>(({
  options,
  hasError = false,
  locked = false,
  disabled,
  children,
  className = '',
  ...props
}, ref) => {
  const isActuallyDisabled = disabled || locked;

  const baseStyles = 'w-full h-10 pl-3 pr-9 text-[14px] rounded-[8px] border transition-colors bg-white dark:bg-slate-800 text-[#0F172A] dark:text-slate-100 appearance-none focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent';

  const borderStyles = hasError
    ? 'border-[#DC2626] focus:ring-[#DC2626]'
    : 'border-[#E5E7EB] dark:border-slate-700';

  const disabledStyles = isActuallyDisabled
    ? 'bg-slate-50 dark:bg-slate-900 text-slate-500 dark:text-slate-400 cursor-not-allowed border-slate-200 dark:border-slate-800'
    : 'cursor-pointer';

  return (
    <div className="relative flex items-center">
      <select
        ref={ref}
        disabled={isActuallyDisabled}
        {...props}
        className={`${baseStyles} ${borderStyles} ${disabledStyles} ${className}`}
      >
        {options
          ? options.map(opt => (
              <option key={opt.value} value={opt.value} disabled={opt.disabled}>
                {opt.label}
              </option>
            ))
          : children}
      </select>

      <div className="absolute right-3 pointer-events-none text-slate-400 flex items-center">
        {locked ? <Lock className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </div>
    </div>
  );
});

LCSelect.displayName = 'LCSelect';
