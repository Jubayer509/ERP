import React from 'react';

export interface LCEmptyStateProps {
  message: string;
  action?: React.ReactNode;
  className?: string;
}

export const LCEmptyState: React.FC<LCEmptyStateProps> = ({
  message,
  action,
  className = '',
}) => {
  return (
    <div className={`py-8 text-center space-y-3 ${className}`}>
      <p className="text-[14px] text-slate-500 dark:text-slate-400">
        {message}
      </p>
      {action && <div>{action}</div>}
    </div>
  );
};
