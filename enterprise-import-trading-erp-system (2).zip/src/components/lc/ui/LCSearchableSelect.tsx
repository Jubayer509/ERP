import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Search, X } from 'lucide-react';

export interface LCSearchableOption {
  value: string;
  label: string;
  subLabel?: string;
  meta?: string;
  badge?: string;
  disabled?: boolean;
}

export interface LCSearchableSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: LCSearchableOption[];
  placeholder?: string;
  searchPlaceholder?: string;
  emptyMessage?: string;
  disabled?: boolean;
  hasError?: boolean;
  className?: string;
  renderOption?: (option: LCSearchableOption) => React.ReactNode;
  renderSelected?: (selectedOption: LCSearchableOption) => React.ReactNode;
}

export const LCSearchableSelect: React.FC<LCSearchableSelectProps> = ({
  value,
  onChange,
  options,
  placeholder = 'Select an option...',
  searchPlaceholder = 'Search...',
  emptyMessage = 'No matching options',
  disabled = false,
  hasError = false,
  className = '',
  renderOption,
  renderSelected,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const selectedOption = options.find(o => o.value === value);

  const filteredOptions = options.filter(opt => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      opt.label.toLowerCase().includes(term) ||
      (opt.subLabel && opt.subLabel.toLowerCase().includes(term)) ||
      (opt.meta && opt.meta.toLowerCase().includes(term))
    );
  });

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearchTerm('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen]);

  const baseStyles = 'w-full h-10 px-3 text-[14px] rounded-[8px] border transition-colors bg-white dark:bg-slate-800 text-[#0F172A] dark:text-slate-100 flex items-center justify-between';
  const borderStyles = hasError
    ? 'border-[#DC2626] focus:ring-[#DC2626]'
    : isOpen
    ? 'border-[#2563EB] ring-2 ring-[#2563EB]/25'
    : 'border-[#E5E7EB] dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600';
  const disabledStyles = disabled
    ? 'bg-slate-50 dark:bg-slate-900 text-slate-400 cursor-not-allowed border-slate-200 dark:border-slate-800'
    : 'cursor-pointer';

  return (
    <div ref={containerRef} className={`relative ${className}`}>
      <div
        onClick={() => !disabled && setIsOpen(!isOpen)}
        className={`${baseStyles} ${borderStyles} ${disabledStyles}`}
      >
        <div className="truncate flex-1 mr-2 text-left">
          {selectedOption ? (
            renderSelected ? (
              renderSelected(selectedOption)
            ) : (
              <span className="font-medium text-slate-900 dark:text-slate-100">
                {selectedOption.label}
              </span>
            )
          ) : (
            <span className="text-slate-400">{placeholder}</span>
          )}
        </div>
        <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
      </div>

      {isOpen && !disabled && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-[8px] shadow-lg z-50 p-2 max-h-64 overflow-hidden flex flex-col">
          <div className="relative mb-2 shrink-0">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={searchPlaceholder}
              className="w-full pl-8 pr-7 py-1.5 text-[13px] border border-[#E5E7EB] dark:border-slate-700 rounded-[6px] bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-[#2563EB]"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-2 top-2 text-slate-400 hover:text-slate-600 p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          <div className="overflow-y-auto space-y-0.5 max-h-48 pr-1">
            {filteredOptions.length === 0 ? (
              <div className="text-center py-3 text-[13px] text-slate-400">
                {emptyMessage}
              </div>
            ) : (
              filteredOptions.map((opt) => (
                <div
                  key={opt.value}
                  onClick={() => {
                    if (opt.disabled) return;
                    onChange(opt.value);
                    setIsOpen(false);
                    setSearchTerm('');
                  }}
                  className={`p-2 rounded-[6px] text-[13px] transition-colors flex items-center justify-between ${
                    opt.disabled
                      ? 'opacity-40 cursor-not-allowed'
                      : value === opt.value
                      ? 'bg-[#EFF6FF] dark:bg-blue-900/30 text-[#1E40AF] dark:text-blue-300 font-medium cursor-pointer'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-700 dark:text-slate-200 cursor-pointer'
                  }`}
                >
                  {renderOption ? (
                    renderOption(opt)
                  ) : (
                    <div className="flex-1 truncate">
                      <div className="font-medium truncate">{opt.label}</div>
                      {opt.subLabel && (
                        <div className="text-[11px] text-slate-400 truncate">
                          {opt.subLabel}
                        </div>
                      )}
                    </div>
                  )}
                  {opt.meta && (
                    <span className="text-[12px] font-mono tabular-nums text-slate-500 shrink-0 ml-2">
                      {opt.meta}
                    </span>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
