import React from 'react';
import { Loader2 } from 'lucide-react';
import { LcColorVariant } from './tokens';

export interface LCButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: LcColorVariant;
  size?: 'sm' | 'md';
  isLoading?: boolean;
  loadingText?: string;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

export const LCButton: React.FC<LCButtonProps> = ({
  variant = 'primary',
  size = 'md',
  isLoading = false,
  loadingText,
  icon,
  iconPosition = 'left',
  fullWidth = false,
  children,
  className = '',
  disabled,
  ...props
}) => {
  const isDisabled = disabled || isLoading;

  const baseStyles = 'inline-flex items-center justify-center font-medium transition-colors select-none rounded-[8px] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:ring-offset-1 dark:focus:ring-offset-slate-900';

  const sizeStyles = {
    sm: 'h-8 px-3 text-[12px] gap-1.5',
    md: 'h-10 px-4 text-[13px] gap-2',
  }[size];

  const variantStyles = {
    primary: 'bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white disabled:bg-slate-300 dark:disabled:bg-slate-700 disabled:text-slate-500 dark:disabled:text-slate-400',
    secondary: 'bg-white dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 text-[#0F172A] dark:text-slate-100 hover:bg-[#F8FAFC] dark:hover:bg-slate-700/60 active:bg-slate-100 disabled:border-slate-200 disabled:text-slate-400',
    ghost: 'bg-transparent text-[#0F172A] dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 active:bg-slate-200/60 disabled:text-slate-400',
    danger: 'bg-[#DC2626] hover:bg-[#B91C1C] active:bg-[#991B1B] text-white disabled:bg-slate-300 dark:disabled:bg-slate-700 disabled:text-slate-400',
  }[variant];

  const widthStyle = fullWidth ? 'w-full' : '';
  const disabledStyle = isDisabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer';

  return (
    <button
      {...props}
      disabled={isDisabled}
      className={`${baseStyles} ${sizeStyles} ${variantStyles} ${widthStyle} ${disabledStyle} ${className}`}
    >
      {isLoading ? (
        <>
          <Loader2 className={`${size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4'} animate-spin`} />
          <span>{loadingText || children}</span>
        </>
      ) : (
        <>
          {icon && iconPosition === 'left' && <span className="shrink-0">{icon}</span>}
          {children && <span>{children}</span>}
          {icon && iconPosition === 'right' && <span className="shrink-0">{icon}</span>}
        </>
      )}
    </button>
  );
};
