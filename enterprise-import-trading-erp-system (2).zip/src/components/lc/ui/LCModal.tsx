import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { LCButton } from './LCButton';

export interface LCModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: React.ReactNode;
  subtitle?: string;
  size?: 'sm' | 'md' | 'lg';
  isDirty?: boolean;
  isSaving?: boolean;
  children: React.ReactNode;
  footer?: React.ReactNode;
  showCancelButton?: boolean;
  cancelLabel?: string;
  onCancel?: () => void;
  primaryAction?: React.ReactNode;
  className?: string;
}

export const LCModal: React.FC<LCModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  size = 'md',
  isDirty = false,
  isSaving = false,
  children,
  footer,
  showCancelButton = true,
  cancelLabel = 'Cancel',
  onCancel,
  primaryAction,
  className = '',
}) => {
  const [showDiscardConfirm, setShowDiscardConfirm] = useState(false);

  // Handle Close Attempt (checks dirty state)
  const attemptClose = () => {
    if (isSaving) return; // Close strictly disabled while saving
    if (isDirty) {
      setShowDiscardConfirm(true);
    } else {
      onClose();
    }
  };

  const confirmDiscard = () => {
    setShowDiscardConfirm(false);
    onClose();
  };

  const cancelDiscard = () => {
    setShowDiscardConfirm(false);
  };

  // Keyboard navigation: Escape key closes or shows confirmation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showDiscardConfirm) {
          setShowDiscardConfirm(false);
        } else {
          attemptClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isDirty, isSaving, showDiscardConfirm]);

  // Prevent background scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      setShowDiscardConfirm(false);
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const sizeClass = {
    sm: 'max-w-[480px]',
    md: 'max-w-[640px]',
    lg: 'max-w-[880px]',
  }[size];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/40 backdrop-blur-xs lc-scope">
      {/* Modal Dialog Card */}
      <div
        role="dialog"
        aria-modal="true"
        className={`relative w-full ${sizeClass} bg-white dark:bg-slate-900 rounded-[12px] border border-[#E5E7EB] dark:border-slate-800 shadow-[var(--lc-shadow-modal)] flex flex-col max-h-[92vh] overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150 ${className}`}
      >
        {/* Header with Title and X */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5E7EB] dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
          <div>
            <h3 className="text-[16px] font-semibold text-[#0F172A] dark:text-slate-100 leading-tight">
              {title}
            </h3>
            {subtitle && (
              <p className="text-[12px] text-slate-500 dark:text-slate-400 mt-0.5">
                {subtitle}
              </p>
            )}
          </div>
          <button
            type="button"
            disabled={isSaving}
            onClick={attemptClose}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-[6px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="px-6 py-4 overflow-y-auto flex-1 space-y-4 text-[14px]">
          {children}
        </div>

        {/* Sticky Footer */}
        {(footer || showCancelButton || primaryAction) && (
          <div className="flex items-center justify-between px-6 py-3.5 border-t border-[#E5E7EB] dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
            {footer ? (
              footer
            ) : (
              <>
                <div>
                  {showCancelButton && (
                    <LCButton
                      type="button"
                      variant="ghost"
                      size="md"
                      disabled={isSaving}
                      onClick={onCancel || attemptClose}
                    >
                      {cancelLabel}
                    </LCButton>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {primaryAction}
                </div>
              </>
            )}
          </div>
        )}

        {/* Discard Changes Confirmation Sub-Modal */}
        {showDiscardConfirm && (
          <div className="absolute inset-0 z-20 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-100">
            <div className="bg-white dark:bg-slate-800 rounded-[12px] border border-[#E5E7EB] dark:border-slate-700 p-5 max-w-sm w-full space-y-4 shadow-xl">
              <div>
                <h4 className="text-[15px] font-semibold text-[#0F172A] dark:text-slate-100">
                  Discard changes?
                </h4>
                <p className="text-[13px] text-slate-500 dark:text-slate-400 mt-1">
                  You have unsaved input in this form. If you close now, your changes will be lost.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <LCButton
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={cancelDiscard}
                >
                  Continue Editing
                </LCButton>
                <LCButton
                  type="button"
                  variant="danger"
                  size="sm"
                  onClick={confirmDiscard}
                >
                  Discard
                </LCButton>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
