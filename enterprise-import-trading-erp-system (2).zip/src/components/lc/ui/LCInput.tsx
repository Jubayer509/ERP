import React from 'react';
import { Lock } from 'lucide-react';

export interface LCInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  suffixText?: string;
  suffixIcon?: React.ReactNode;
  prefixIcon?: React.ReactNode;
  isNumber?: boolean;
  hasError?: boolean;
  locked?: boolean;
}

export const LCInput = React.forwardRef<HTMLInputElement, LCInputProps>(({
  suffixText,
  suffixIcon,
  prefixIcon,
  isNumber = false,
  hasError = false,
  locked = false,
  disabled,
  className = '',
  type = 'text',
  ...props
}, ref) => {
  const isActuallyDisabled = disabled || locked;
  const isNumeric = isNumber || type === 'number';

  const baseStyles = 'w-full h-10 px-3 text-[14px] rounded-[8px] border transition-colors bg-white dark:bg-slate-800 text-[#0F172A] dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent';
  
  const borderStyles = hasError
    ? 'border-[#DC2626] focus:ring-[#DC2626]'
    : 'border-[#E5E7EB] dark:border-slate-700';

  const disabledStyles = isActuallyDisabled
    ? 'bg-slate-50 dark:bg-slate-900 text-slate-500 dark:text-slate-400 cursor-not-allowed border-slate-200 dark:border-slate-800'
    : '';

  const alignStyles = isNumeric ? 'text-right font-mono tabular-nums pr-12' : '';
  const prefixPadding = prefixIcon ? 'pl-9' : '';
  const suffixPadding = (suffixText || suffixIcon || locked) ? 'pr-11' : '';

  return (
    <div className="relative flex items-center">
      {prefixIcon && (
        <span className="absolute left-3 text-slate-400 pointer-events-none shrink-0">
          {prefixIcon}
        </span>
      )}

      <input
        ref={ref}
        type={type}
        disabled={isActuallyDisabled}
        {...props}
        className={`${baseStyles} ${borderStyles} ${disabledStyles} ${alignStyles} ${prefixPadding} ${suffixPadding} ${className}`}
      />

      {suffixText && (
        <span className="absolute right-3 text-[12px] font-medium text-slate-400 select-none pointer-events-none">
          {suffixText}
        </span>
      )}

      {suffixIcon && !suffixText && (
        <span className="absolute right-3 text-slate-400 pointer-events-none shrink-0">
          {suffixIcon}
        </span>
      )}

      {locked && !suffixIcon && !suffixText && (
        <span className="absolute right-3 text-slate-400 pointer-events-none shrink-0">
          <Lock className="w-4 h-4" />
        </span>
      )}
    </div>
  );
});

LCInput.displayName = 'LCInput';
