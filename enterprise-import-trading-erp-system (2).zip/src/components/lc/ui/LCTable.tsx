import React from 'react';

export interface LCTableColumn<T = any> {
  key: string;
  header: React.ReactNode;
  align?: 'left' | 'center' | 'right';
  width?: string;
  isNumeric?: boolean;
  render?: (row: T, index: number) => React.ReactNode;
}

export interface LCTableProps<T = any> {
  columns: LCTableColumn<T>[];
  data?: T[];
  children?: React.ReactNode;
  className?: string;
  emptyMessage?: string;
}

export const LCTable = <T,>({
  columns,
  data,
  children,
  className = '',
  emptyMessage = 'No records found',
}: LCTableProps<T>) => {
  return (
    <div className={`w-full overflow-x-auto border border-[#E5E7EB] dark:border-slate-800 rounded-[12px] bg-white dark:bg-slate-900 ${className}`}>
      <table className="w-full text-left border-collapse text-[13px]">
        <thead>
          <tr className="sticky top-0 bg-[#F8FAFC] dark:bg-slate-800/80 border-b border-[#E5E7EB] dark:border-slate-800 z-10 text-slate-600 dark:text-slate-300">
            {columns.map((col) => {
              const alignClass = col.align === 'right' || col.isNumeric
                ? 'text-right'
                : col.align === 'center'
                ? 'text-center'
                : 'text-left';
              return (
                <th
                  key={col.key}
                  style={col.width ? { width: col.width } : undefined}
                  className={`py-2.5 px-3 font-semibold select-none ${alignClass}`}
                >
                  {col.header}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody className="divide-y divide-[#E5E7EB] dark:divide-slate-800 text-[#0F172A] dark:text-slate-200">
          {children ? (
            children
          ) : data && data.length > 0 ? (
            data.map((row, idx) => (
              <tr
                key={`row-${idx}`}
                className="hover:bg-[#F8FAFC] dark:hover:bg-slate-800/50 transition-colors"
              >
                {columns.map((col) => {
                  const alignClass = col.align === 'right' || col.isNumeric
                    ? 'text-right font-mono tabular-nums'
                    : col.align === 'center'
                    ? 'text-center'
                    : 'text-left';
                  const content = col.render
                    ? col.render(row, idx)
                    : (row as any)[col.key];
                  return (
                    <td key={col.key} className={`py-2.5 px-3 ${alignClass}`}>
                      {content}
                    </td>
                  );
                })}
              </tr>
            ))
          ) : (
            <tr>
              <td
                colSpan={columns.length}
                className="py-8 text-center text-slate-400 text-[13px]"
              >
                {emptyMessage}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
