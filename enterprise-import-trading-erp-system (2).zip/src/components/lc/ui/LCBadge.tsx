import React from 'react';
import { LcStatusVariant } from './tokens';

export interface LCBadgeProps {
  variant?: LcStatusVariant;
  children: React.ReactNode;
  className?: string;
}

export const LCBadge: React.FC<LCBadgeProps> = ({
  variant = 'neutral',
  children,
  className = '',
}) => {
  const variantStyles = {
    success: 'bg-[#ECFDF5] text-[#059669] dark:bg-emerald-950/40 dark:text-[#10B981]',
    warning: 'bg-[#FFFBEB] text-[#D97706] dark:bg-amber-950/40 dark:text-[#F59E0B]',
    danger: 'bg-[#FEF2F2] text-[#DC2626] dark:bg-rose-950/40 dark:text-[#EF4444]',
    neutral: 'bg-[#F1F5F9] text-[#64748B] dark:bg-slate-800 dark:text-[#94A3B8]',
    info: 'bg-[#EFF6FF] text-[#2563EB] dark:bg-blue-950/40 dark:text-[#3B82F6]',
  }[variant];

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-[8px] text-[12px] font-medium leading-none select-none ${variantStyles} ${className}`}
    >
      {children}
    </span>
  );
};
