import React from 'react';

export interface LCFormFieldProps {
  label?: string;
  required?: boolean;
  error?: string;
  helperText?: string;
  subLabel?: React.ReactNode;
  locked?: boolean;
  children: React.ReactNode;
  className?: string;
  htmlFor?: string;
}

export const LCFormField: React.FC<LCFormFieldProps> = ({
  label,
  required = false,
  error,
  helperText,
  subLabel,
  locked = false,
  children,
  className = '',
  htmlFor,
}) => {
  return (
    <div className={`space-y-1.5 ${className}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label
            htmlFor={htmlFor}
            className="block text-[13px] font-medium text-slate-700 dark:text-slate-300"
          >
            {label}
            {required && <span className="text-[#DC2626] ml-0.5">*</span>}
            {locked && (
              <span className="text-[11px] text-slate-400 font-normal ml-1.5">
                (Locked)
              </span>
            )}
          </label>
          {subLabel && <div className="text-[12px] text-slate-500">{subLabel}</div>}
        </div>
      )}

      {children}

      {error ? (
        <p className="text-[12px] text-[#DC2626] font-medium mt-1">
          {error}
        </p>
      ) : helperText ? (
        <p className="text-[12px] text-slate-500 dark:text-slate-400 mt-1">
          {helperText}
        </p>
      ) : null}
    </div>
  );
};
