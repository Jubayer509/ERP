import React from 'react';

export interface LCSummaryItem {
  label: string;
  value: string | number;
  isTotal?: boolean;
  isNumeric?: boolean;
}

export interface LCSummaryRowProps {
  items: LCSummaryItem[];
  className?: string;
}

export const LCSummaryRow: React.FC<LCSummaryRowProps> = ({
  items,
  className = '',
}) => {
  return (
    <div
      className={`flex flex-wrap items-center justify-end gap-6 pt-3 border-t border-[#E5E7EB] dark:border-slate-800 text-[13px] ${className}`}
    >
      {items.map((item, idx) => {
        const isTotal = item.isTotal;
        return (
          <div key={`summary-${idx}`} className="flex items-center gap-2">
            <span
              className={
                isTotal
                  ? 'font-semibold text-[#0F172A] dark:text-slate-100'
                  : 'text-slate-500 dark:text-slate-400'
              }
            >
              {item.label}:
            </span>
            <span
              className={`font-mono tabular-nums ${
                isTotal
                  ? 'font-bold text-[15px] text-[#2563EB] dark:text-blue-400'
                  : 'font-medium text-slate-800 dark:text-slate-200'
              }`}
            >
              {typeof item.value === 'number' ? item.value.toLocaleString() : item.value}
            </span>
          </div>
        );
      })}
    </div>
  );
};
