import React, { useState, useMemo, useRef, useEffect } from 'react';
import * as d3 from 'd3';
import {
  Search,
  Filter,
  RotateCcw,
  ArrowUpRight,
  Layers,
  BarChart3,
  Building2,
  Ship,
  FileCheck,
  CheckCircle2,
  Clock,
  ArrowDownToLine,
  Calculator,
  Receipt
} from 'lucide-react';
import { LetterOfCredit } from '../../types/erp';
import { computeLCProgressAndStatus } from '../../utils/lcStatusHelper';

export type LifecycleStage = 'Opened' | 'Received' | 'Customs Cleared' | 'Settled';

export const LIFECYCLE_STAGES: LifecycleStage[] = [
  'Opened',
  'Received',
  'Customs Cleared',
  'Settled'
];

export const STAGE_COLORS: Record<LifecycleStage, string> = {
  'Opened': '#2563EB',          // Blue 600
  'Received': '#D97706',        // Amber 600
  'Customs Cleared': '#0D9488', // Teal 600
  'Settled': '#16A34A'          // Green 600
};

export const STAGE_DESCRIPTIONS: Record<LifecycleStage, string> = {
  'Opened': 'LC issued & margin posted, awaiting border arrival',
  'Received': 'Consignment weighed & received at border yard',
  'Customs Cleared': 'Bill of Entry (BOE) assessed & customs duty cleared',
  'Settled': 'Bank & exporter bills settled, landed cost closed'
};

type MetricMode = 'count' | 'valueBdt' | 'valueUsd' | 'quantityMt';
type ChartLayoutMode = 'grouped' | 'stacked';
type BranchDimension = 'bank_branch' | 'port_branch' | 'combined';

export interface LCStatusSummaryDashboardProps {
  lcs: LetterOfCredit[];
  currentBranch?: string;
  onSelectLc?: (lc: LetterOfCredit) => void;
  onNavigateToReceiving?: (lc: LetterOfCredit) => void;
  onNavigateToExpenses?: (lc: LetterOfCredit) => void;
  onNavigateToBills?: (lc: LetterOfCredit) => void;
  onOpenNewLcModal?: () => void;
}

interface EnrichedLC {
  lc: LetterOfCredit;
  stage: LifecycleStage;
  branchName: string;
  portName: string;
  valueUsd: number;
  valueBdt: number;
  totalQtyMt: number;
  receivedQtyMt: number;
  receivingPct: number;
}

export function classifyLcLifecycleStage(lc: LetterOfCredit): LifecycleStage {
  const progress = computeLCProgressAndStatus(lc);

  // 1. Settled: Fully closed, matured, or all bank + hundi + goods completed
  if (
    progress.isClosed ||
    lc.status === 'Costed & Closed' ||
    lc.status === 'Matured' ||
    lc.remarkStatus === 'LC Closed'
  ) {
    return 'Settled';
  }

  // 2. Customs Cleared: Explicitly marked Customs Cleared / Port Arrived / BOE Filed, or has paid customs duty
  const hasPaidCustomsDuty = (lc.expenses || []).some(
    e => e.status === 'Paid' && /customs|duty|boe|tariff/i.test(e.expenseType)
  );
  const hasValidBoe =
    Boolean(lc.boeNumber) &&
    lc.boeNumber !== 'BOE-PENDING' &&
    lc.boeNumber !== 'BOE-CGP-PENDING';

  if (
    lc.status === 'Customs Cleared' ||
    lc.status === 'Port Arrived / BOE Filed' ||
    hasPaidCustomsDuty ||
    hasValidBoe
  ) {
    return 'Customs Cleared';
  }

  // 3. Received: Goods partially or fully received at border / GRN received / On Loading with received weight
  if (
    lc.status === 'GRN Received' ||
    progress.receivedQuantity > 0 ||
    (lc.receivedQtyMt && lc.receivedQtyMt > 0) ||
    (lc.receivings && lc.receivings.length > 0)
  ) {
    return 'Received';
  }

  // 4. Opened: Draft, Confirmed, Bank Applied, Opened / Margin Paid, Shipment In-Transit (prior to receiving/clearance)
  return 'Opened';
}

function resolveBranchLabel(lc: LetterOfCredit, dimension: BranchDimension): string {
  const rawBranch = (lc.branch || 'Principal Branch').trim();
  const normalizedBankBranch =
    rawBranch === 'Principal Branch' ? 'Principal Branch, Dhaka' : rawBranch;

  const rawPort = (
    lc.borderLandPort ||
    (lc.portOfDischarge ? lc.portOfDischarge.split(',')[0].replace(/Land Port|Sea Port/gi, '').trim() : '') ||
    'Burimari'
  ).trim();

  const portLabel = rawPort.includes('Port') ? rawPort : `${rawPort} Port`;

  if (dimension === 'bank_branch') {
    return normalizedBankBranch;
  }
  if (dimension === 'port_branch') {
    return `${portLabel} Office`;
  }
  return `${portLabel} · ${normalizedBankBranch.replace(', Dhaka', '')}`;
}

export const LCStatusSummaryDashboard: React.FC<LCStatusSummaryDashboardProps> = ({
  lcs,
  onSelectLc,
  onNavigateToReceiving,
  onNavigateToExpenses,
  onNavigateToBills,
  onOpenNewLcModal
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStage, setSelectedStage] = useState<LifecycleStage | 'ALL'>('ALL');
  const [selectedBranch, setSelectedBranch] = useState<string>('ALL');
  const [metricMode, setMetricMode] = useState<MetricMode>('count');
  const [chartLayout, setChartLayout] = useState<ChartLayoutMode>('grouped');
  const [branchDimension, setBranchDimension] = useState<BranchDimension>('combined');
  const [includeCancelled, setIncludeCancelled] = useState(false);

  // Tooltip state for D3 charts
  const [tooltip, setTooltip] = useState<{
    visible: boolean;
    x: number;
    y: number;
    title: string;
    subtitle: string;
    lines: { label: string; value: string; color?: string }[];
  } | null>(null);

  // Refs for D3 SVG containers
  const barChartContainerRef = useRef<HTMLDivElement>(null);
  const barChartSvgRef = useRef<SVGSVGElement>(null);
  const donutSvgRef = useRef<SVGSVGElement>(null);
  const heatmapContainerRef = useRef<HTMLDivElement>(null);
  const heatmapSvgRef = useRef<SVGSVGElement>(null);

  const [barChartWidth, setBarChartWidth] = useState<number>(720);
  const [heatmapWidth, setHeatmapWidth] = useState<number>(640);

  // Observe container widths for responsive D3 rendering
  useEffect(() => {
    const updateWidths = () => {
      if (barChartContainerRef.current) {
        setBarChartWidth(Math.max(320, barChartContainerRef.current.clientWidth));
      }
      if (heatmapContainerRef.current) {
        setHeatmapWidth(Math.max(320, heatmapContainerRef.current.clientWidth));
      }
    };
    updateWidths();

    const observer = new ResizeObserver(updateWidths);
    if (barChartContainerRef.current) observer.observe(barChartContainerRef.current);
    if (heatmapContainerRef.current) observer.observe(heatmapContainerRef.current);
    window.addEventListener('resize', updateWidths);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updateWidths);
    };
  }, []);

  // Enrich LCs with lifecycle stage and normalized branch
  const enrichedLcs = useMemo<EnrichedLC[]>(() => {
    const validLcs = lcs.filter(lc => {
      if (includeCancelled) return true;
      return !lc.isVoided && !lc.isCancelled && lc.status !== 'Voided' && lc.status !== 'Cancelled';
    });

    return validLcs.map(lc => {
      const progress = computeLCProgressAndStatus(lc);
      const stage = classifyLcLifecycleStage(lc);
      const branchName = resolveBranchLabel(lc, branchDimension);
      const portName = lc.borderLandPort || 'Burimari';
      const valueUsd = Number(lc.cfrAmount || lc.officialLcTotal || 0);
      const exRate = Number(lc.exchangeRate || lc.rateBdt || 124);
      const valueBdt = valueUsd * exRate;
      const totalQtyMt = Number(lc.quantity || lc.items?.[0]?.quantity || 0);
      const receivedQtyMt = Number(progress.receivedQuantity || 0);
      const receivingPct = totalQtyMt > 0 ? Math.min(100, Math.round((receivedQtyMt / totalQtyMt) * 100)) : 0;

      return {
        lc,
        stage,
        branchName,
        portName,
        valueUsd,
        valueBdt,
        totalQtyMt,
        receivedQtyMt,
        receivingPct
      };
    });
  }, [lcs, branchDimension, includeCancelled]);

  // Available branches
  const allBranches = useMemo(() => {
    const set = new Set<string>();
    enrichedLcs.forEach(item => set.add(item.branchName));
    return Array.from(set).sort();
  }, [enrichedLcs]);

  // Reset selectedBranch if dimension changes and selectedBranch is no longer in list
  useEffect(() => {
    if (selectedBranch !== 'ALL' && !allBranches.includes(selectedBranch)) {
      setSelectedBranch('ALL');
    }
  }, [allBranches, selectedBranch]);

  // Filtered LCs for KPIs & Table
  const filteredLcs = useMemo(() => {
    return enrichedLcs.filter(item => {
      if (selectedStage !== 'ALL' && item.stage !== selectedStage) return false;
      if (selectedBranch !== 'ALL' && item.branchName !== selectedBranch) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchNumber = item.lc.lcNumber.toLowerCase().includes(q);
        const matchSupplier = (item.lc.supplierName || '').toLowerCase().includes(q);
        const matchBank = (item.lc.issuingBank || '').toLowerCase().includes(q);
        const matchBranch = item.branchName.toLowerCase().includes(q);
        if (!matchNumber && !matchSupplier && !matchBank && !matchBranch) return false;
      }
      return true;
    });
  }, [enrichedLcs, selectedStage, selectedBranch, searchQuery]);

  // Stage-level aggregates (respecting search & branch filter so stage cards stay contextual)
  const stageSummaries = useMemo(() => {
    const baseList = enrichedLcs.filter(item => {
      if (selectedBranch !== 'ALL' && item.branchName !== selectedBranch) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchNumber = item.lc.lcNumber.toLowerCase().includes(q);
        const matchSupplier = (item.lc.supplierName || '').toLowerCase().includes(q);
        const matchBank = (item.lc.issuingBank || '').toLowerCase().includes(q);
        const matchBranch = item.branchName.toLowerCase().includes(q);
        if (!matchNumber && !matchSupplier && !matchBank && !matchBranch) return false;
      }
      return true;
    });

    const totalCount = baseList.length || 1;

    return LIFECYCLE_STAGES.map(stage => {
      const matching = baseList.filter(i => i.stage === stage);
      const count = matching.length;
      const valueUsd = matching.reduce((sum, i) => sum + i.valueUsd, 0);
      const valueBdt = matching.reduce((sum, i) => sum + i.valueBdt, 0);
      const quantityMt = matching.reduce((sum, i) => sum + i.totalQtyMt, 0);
      const receivedMt = matching.reduce((sum, i) => sum + i.receivedQtyMt, 0);
      const sharePct = baseList.length > 0 ? Math.round((count / totalCount) * 100) : 0;

      return {
        stage,
        count,
        valueUsd,
        valueBdt,
        quantityMt,
        receivedMt,
        sharePct
      };
    });
  }, [enrichedLcs, selectedBranch, searchQuery]);

  // Branch × Stage matrix data for D3 Bar Chart & Heatmap
  const branchStageMatrix = useMemo(() => {
    const searchFiltered = enrichedLcs.filter(item => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        item.lc.lcNumber.toLowerCase().includes(q) ||
        (item.lc.supplierName || '').toLowerCase().includes(q) ||
        (item.lc.issuingBank || '').toLowerCase().includes(q) ||
        item.branchName.toLowerCase().includes(q)
      );
    });

    const branches = Array.from(new Set(searchFiltered.map(i => i.branchName))).sort();

    return branches.map(branch => {
      const branchItems = searchFiltered.filter(i => i.branchName === branch);
      const stageData: Record<LifecycleStage, { count: number; valueBdt: number; valueUsd: number; quantityMt: number }> = {
        'Opened': { count: 0, valueBdt: 0, valueUsd: 0, quantityMt: 0 },
        'Received': { count: 0, valueBdt: 0, valueUsd: 0, quantityMt: 0 },
        'Customs Cleared': { count: 0, valueBdt: 0, valueUsd: 0, quantityMt: 0 },
        'Settled': { count: 0, valueBdt: 0, valueUsd: 0, quantityMt: 0 }
      };

      branchItems.forEach(item => {
        const bucket = stageData[item.stage];
        bucket.count += 1;
        bucket.valueBdt += item.valueBdt;
        bucket.valueUsd += item.valueUsd;
        bucket.quantityMt += item.totalQtyMt;
      });

      const totalCount = branchItems.length;
      const totalValueBdt = branchItems.reduce((s, i) => s + i.valueBdt, 0);
      const totalValueUsd = branchItems.reduce((s, i) => s + i.valueUsd, 0);
      const totalQuantityMt = branchItems.reduce((s, i) => s + i.totalQtyMt, 0);

      return {
        branch,
        stages: stageData,
        totalCount,
        totalValueBdt,
        totalValueUsd,
        totalQuantityMt
      };
    });
  }, [enrichedLcs, searchQuery]);

  const formatMetricValue = (val: number, mode: MetricMode): string => {
    if (mode === 'count') return `${Math.round(val)} LCs`;
    if (mode === 'valueBdt') {
      if (val >= 1000000) return `৳${(val / 1000000).toFixed(2)}M`;
      if (val >= 1000) return `৳${(val / 1000).toFixed(0)}k`;
      return `৳${Math.round(val).toLocaleString('en-US')}`;
    }
    if (mode === 'valueUsd') {
      if (val >= 1000) return `$${(val / 1000).toFixed(1)}k`;
      return `$${Math.round(val).toLocaleString('en-US')}`;
    }
    return `${Math.round(val).toLocaleString('en-US')} MT`;
  };

  // ============================================================================
  // D3.js CHART 1: Grouped / Stacked Bar Chart of Lifecycle Stages by Branch
  // ============================================================================
  useEffect(() => {
    const svgEl = barChartSvgRef.current;
    if (!svgEl) return;

    const svg = d3.select(svgEl);
    svg.selectAll('*').remove();

    const height = 340;
    const margin = { top: 24, right: 24, bottom: 64, left: 68 };
    const innerWidth = Math.max(200, barChartWidth - margin.left - margin.right);
    const innerHeight = height - margin.top - margin.bottom;

    svg.attr('width', barChartWidth).attr('height', height);

    if (branchStageMatrix.length === 0) return;

    const g = svg
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const branches = branchStageMatrix.map(d => d.branch);

    // X0 scale: branches
    const x0 = d3
      .scaleBand<string>()
      .domain(branches)
      .range([0, innerWidth])
      .paddingInner(0.28)
      .paddingOuter(0.14);

    // Determine Y max based on layout and metric
    const getMetric = (
      stageObj: { count: number; valueBdt: number; valueUsd: number; quantityMt: number }
    ) => stageObj[metricMode];

    const maxVal =
      chartLayout === 'stacked'
        ? d3.max(branchStageMatrix, d =>
            d3.sum(LIFECYCLE_STAGES, st => getMetric(d.stages[st]))
          ) || 1
        : d3.max(branchStageMatrix, d =>
            d3.max(LIFECYCLE_STAGES, st => getMetric(d.stages[st]))
          ) || 1;

    const y = d3
      .scaleLinear()
      .domain([0, maxVal * 1.15])
      .nice()
      .range([innerHeight, 0]);

    // Horizontal gridlines
    const yTicks = y.ticks(5);
    g.append('g')
      .attr('class', 'grid-lines')
      .selectAll('line')
      .data(yTicks)
      .join('line')
      .attr('x1', 0)
      .attr('x2', innerWidth)
      .attr('y1', d => y(d))
      .attr('y2', d => y(d))
      .attr('stroke', '#E2E8F0')
      .attr('stroke-dasharray', d => (d === 0 ? 'none' : '3,3'))
      .attr('stroke-width', 1);

    // Y Axis
    const yAxis = d3
      .axisLeft(y)
      .ticks(5)
      .tickSize(0)
      .tickPadding(10)
      .tickFormat(d => {
        const num = Number(d);
        if (metricMode === 'count') return `${Math.round(num)}`;
        if (metricMode === 'valueBdt') {
          return num >= 1000000
            ? `৳${(num / 1000000).toFixed(1)}M`
            : num >= 1000
            ? `৳${(num / 1000).toFixed(0)}k`
            : `৳${num}`;
        }
        if (metricMode === 'valueUsd') {
          return num >= 1000 ? `$${(num / 1000).toFixed(0)}k` : `$${num}`;
        }
        return `${num} MT`;
      });

    const yAxisGroup = g.append('g').call(yAxis);
    yAxisGroup.select('.domain').remove();
    yAxisGroup
      .selectAll('text')
      .attr('fill', '#64748B')
      .attr('font-size', '11px')
      .attr('font-family', 'JetBrains Mono, monospace');

    // X Axis
    const xAxis = d3
      .axisBottom(x0)
      .tickSize(0)
      .tickPadding(12);

    const xAxisGroup = g
      .append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis);

    xAxisGroup.select('.domain').attr('stroke', '#CBD5E1');
    xAxisGroup
      .selectAll('text')
      .attr('fill', d => (selectedBranch === d ? '#0F172A' : '#475569'))
      .attr('font-weight', d => (selectedBranch === d ? '700' : '600'))
      .attr('font-size', '11px')
      .style('cursor', 'pointer')
      .text(d => {
        const str = String(d);
        return str.length > 24 ? `${str.slice(0, 22)}…` : str;
      })
      .on('click', (_, branchName) => {
        setSelectedBranch(prev => (prev === branchName ? 'ALL' : String(branchName)));
      });

    // Active branch highlight backdrop
    if (selectedBranch !== 'ALL') {
      const bx = x0(selectedBranch);
      if (bx !== undefined) {
        g.insert('rect', ':first-child')
          .attr('x', bx - 6)
          .attr('y', 0)
          .attr('width', x0.bandwidth() + 12)
          .attr('height', innerHeight)
          .attr('rx', 8)
          .attr('fill', '#F1F5F9');
      }
    }

    if (chartLayout === 'grouped') {
      const x1 = d3
        .scaleBand<LifecycleStage>()
        .domain(LIFECYCLE_STAGES)
        .range([0, x0.bandwidth()])
        .padding(0.12);

      const branchGroups = g
        .selectAll('.branch-group')
        .data(branchStageMatrix)
        .join('g')
        .attr('class', 'branch-group')
        .attr('transform', d => `translate(${x0(d.branch) || 0},0)`);

      branchGroups
        .selectAll('rect')
        .data(d =>
          LIFECYCLE_STAGES.map(stage => ({
            branch: d.branch,
            stage,
            metrics: d.stages[stage],
            value: getMetric(d.stages[stage])
          }))
        )
        .join('rect')
        .attr('x', d => x1(d.stage) || 0)
        .attr('y', d => y(d.value))
        .attr('width', x1.bandwidth())
        .attr('height', d => Math.max(0, innerHeight - y(d.value)))
        .attr('rx', 4)
        .attr('fill', d => STAGE_COLORS[d.stage])
        .attr('opacity', d => {
          const stageMatch = selectedStage === 'ALL' || selectedStage === d.stage;
          const branchMatch = selectedBranch === 'ALL' || selectedBranch === d.branch;
          return stageMatch && branchMatch ? 1 : 0.28;
        })
        .style('cursor', 'pointer')
        .on('mouseenter', (event, d) => {
          const rect = svgEl.getBoundingClientRect();
          setTooltip({
            visible: true,
            x: event.clientX - rect.left,
            y: event.clientY - rect.top - 12,
            title: d.branch,
            subtitle: `Stage: ${d.stage}`,
            lines: [
              { label: 'LC Count', value: `${d.metrics.count} LCs`, color: STAGE_COLORS[d.stage] },
              { label: 'CFR Value (USD)', value: `$${d.metrics.valueUsd.toLocaleString('en-US', { maximumFractionDigits: 0 })}` },
              { label: 'Value (BDT)', value: `৳${Math.round(d.metrics.valueBdt).toLocaleString('en-US')}` },
              { label: 'Quantity', value: `${d.metrics.quantityMt.toLocaleString('en-US')} MT` }
            ]
          });
        })
        .on('mousemove', event => {
          const rect = svgEl.getBoundingClientRect();
          setTooltip(prev =>
            prev
              ? {
                  ...prev,
                  x: event.clientX - rect.left,
                  y: event.clientY - rect.top - 12
                }
              : null
          );
        })
        .on('mouseleave', () => setTooltip(null))
        .on('click', (_, d) => {
          const isSameSelection = selectedBranch === d.branch && selectedStage === d.stage;
          if (isSameSelection) {
            setSelectedBranch('ALL');
            setSelectedStage('ALL');
          } else {
            setSelectedBranch(d.branch);
            setSelectedStage(d.stage);
          }
        });

      // Value labels above non-zero bars
      branchGroups
        .selectAll('.bar-label')
        .data(d =>
          LIFECYCLE_STAGES.map(stage => ({
            branch: d.branch,
            stage,
            value: getMetric(d.stages[stage])
          })).filter(item => item.value > 0)
        )
        .join('text')
        .attr('class', 'bar-label')
        .attr('x', d => (x1(d.stage) || 0) + x1.bandwidth() / 2)
        .attr('y', d => y(d.value) - 5)
        .attr('text-anchor', 'middle')
        .attr('fill', '#334155')
        .attr('font-size', '10px')
        .attr('font-weight', '600')
        .attr('font-family', 'JetBrains Mono, monospace')
        .text(d => {
          if (metricMode === 'count') return `${d.value}`;
          if (metricMode === 'valueBdt') return `${(d.value / 1000000).toFixed(1)}M`;
          if (metricMode === 'valueUsd') return `$${(d.value / 1000).toFixed(0)}k`;
          return `${Math.round(d.value)}`;
        });
    } else {
      // Stacked Bars using d3.stack
      const stackData = branchStageMatrix.map(row => ({
        branch: row.branch,
        Opened: getMetric(row.stages['Opened']),
        Received: getMetric(row.stages['Received']),
        'Customs Cleared': getMetric(row.stages['Customs Cleared']),
        Settled: getMetric(row.stages['Settled']),
        rawStages: row.stages
      }));

      const stackGenerator = d3.stack<any, LifecycleStage>().keys(LIFECYCLE_STAGES);
      const layers = stackGenerator(stackData);

      const layerGroups = g
        .selectAll('.stack-layer')
        .data(layers)
        .join('g')
        .attr('class', 'stack-layer')
        .attr('fill', d => STAGE_COLORS[d.key]);

      layerGroups
        .selectAll('rect')
        .data(d =>
          d.map(segment => ({
            key: d.key,
            branch: segment.data.branch as string,
            y0: segment[0],
            y1: segment[1],
            metrics: segment.data.rawStages[d.key]
          }))
        )
        .join('rect')
        .attr('x', d => (x0(d.branch) || 0) + x0.bandwidth() * 0.15)
        .attr('y', d => y(d.y1))
        .attr('height', d => Math.max(0, y(d.y0) - y(d.y1)))
        .attr('width', x0.bandwidth() * 0.7)
        .attr('rx', 3)
        .attr('opacity', d => {
          const stageMatch = selectedStage === 'ALL' || selectedStage === d.key;
          const branchMatch = selectedBranch === 'ALL' || selectedBranch === d.branch;
          return stageMatch && branchMatch ? 1 : 0.28;
        })
        .style('cursor', 'pointer')
        .on('mouseenter', (event, d) => {
          const rect = svgEl.getBoundingClientRect();
          setTooltip({
            visible: true,
            x: event.clientX - rect.left,
            y: event.clientY - rect.top - 12,
            title: d.branch,
            subtitle: `Stage: ${d.key}`,
            lines: [
              { label: 'LC Count', value: `${d.metrics.count} LCs`, color: STAGE_COLORS[d.key] },
              { label: 'CFR Value (USD)', value: `$${d.metrics.valueUsd.toLocaleString('en-US', { maximumFractionDigits: 0 })}` },
              { label: 'Value (BDT)', value: `৳${Math.round(d.metrics.valueBdt).toLocaleString('en-US')}` },
              { label: 'Quantity', value: `${d.metrics.quantityMt.toLocaleString('en-US')} MT` }
            ]
          });
        })
        .on('mousemove', event => {
          const rect = svgEl.getBoundingClientRect();
          setTooltip(prev =>
            prev
              ? {
                  ...prev,
                  x: event.clientX - rect.left,
                  y: event.clientY - rect.top - 12
                }
              : null
          );
        })
        .on('mouseleave', () => setTooltip(null))
        .on('click', (_, d) => {
          const isSameSelection = selectedBranch === d.branch && selectedStage === d.key;
          if (isSameSelection) {
            setSelectedBranch('ALL');
            setSelectedStage('ALL');
          } else {
            setSelectedBranch(d.branch);
            setSelectedStage(d.key);
          }
        });
    }
  }, [branchStageMatrix, barChartWidth, metricMode, chartLayout, selectedStage, selectedBranch]);

  // ============================================================================
  // D3.js CHART 2: Lifecycle Distribution Arc / Donut Chart
  // ============================================================================
  useEffect(() => {
    const svgEl = donutSvgRef.current;
    if (!svgEl) return;

    const svg = d3.select(svgEl);
    svg.selectAll('*').remove();

    const size = 210;
    const radius = size / 2;
    const innerRadius = radius * 0.62;
    const outerRadius = radius - 8;

    svg.attr('width', size).attr('height', size);

    const g = svg
      .append('g')
      .attr('transform', `translate(${radius},${radius})`);

    const getVal = (s: typeof stageSummaries[number]) => {
      if (metricMode === 'count') return s.count;
      if (metricMode === 'valueBdt') return s.valueBdt;
      if (metricMode === 'valueUsd') return s.valueUsd;
      return s.quantityMt;
    };

    const totalMetricValue = d3.sum(stageSummaries, getVal);

    if (totalMetricValue <= 0) {
      g.append('circle')
        .attr('r', (innerRadius + outerRadius) / 2)
        .attr('fill', 'none')
        .attr('stroke', '#E2E8F0')
        .attr('stroke-width', outerRadius - innerRadius);
      return;
    }

    const pie = d3
      .pie<typeof stageSummaries[number]>()
      .sort(null)
      .value(d => getVal(d))
      .padAngle(0.025);

    const arc = d3
      .arc<d3.PieArcDatum<typeof stageSummaries[number]>>()
      .innerRadius(innerRadius)
      .outerRadius(d =>
        selectedStage === d.data.stage ? outerRadius + 4 : outerRadius
      )
      .cornerRadius(4);

    const arcs = g
      .selectAll('path')
      .data(pie(stageSummaries.filter(s => getVal(s) > 0)))
      .join('path')
      .attr('d', arc)
      .attr('fill', d => STAGE_COLORS[d.data.stage])
      .attr('opacity', d =>
        selectedStage === 'ALL' || selectedStage === d.data.stage ? 1 : 0.3
      )
      .style('cursor', 'pointer')
      .on('click', (_, d) => {
        setSelectedStage(prev => (prev === d.data.stage ? 'ALL' : d.data.stage));
      });

    arcs.append('title').text(
      d => `${d.data.stage}: ${d.data.count} LCs ($${d.data.valueUsd.toLocaleString()})`
    );

    // Center label
    const activeStageObj =
      selectedStage !== 'ALL'
        ? stageSummaries.find(s => s.stage === selectedStage)
        : null;

    g.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '-0.35em')
      .attr('fill', '#64748B')
      .attr('font-size', '10px')
      .attr('font-weight', '600')
      .text(activeStageObj ? activeStageObj.stage : 'Total Active');

    g.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '0.95em')
      .attr('fill', '#0F172A')
      .attr('font-size', '15px')
      .attr('font-weight', '700')
      .attr('font-family', 'JetBrains Mono, monospace')
      .text(
        activeStageObj
          ? formatMetricValue(getVal(activeStageObj), metricMode)
          : formatMetricValue(totalMetricValue, metricMode)
      );
  }, [stageSummaries, metricMode, selectedStage]);

  // ============================================================================
  // D3.js CHART 3: Branch × Lifecycle Stage Matrix Heatmap
  // ============================================================================
  useEffect(() => {
    const svgEl = heatmapSvgRef.current;
    if (!svgEl) return;

    const svg = d3.select(svgEl);
    svg.selectAll('*').remove();

    if (branchStageMatrix.length === 0) return;

    const rowHeight = 46;
    const margin = { top: 36, right: 20, bottom: 16, left: 190 };
    const height = margin.top + branchStageMatrix.length * rowHeight + margin.bottom;
    const innerWidth = Math.max(220, heatmapWidth - margin.left - margin.right);
    const innerHeight = branchStageMatrix.length * rowHeight;

    svg.attr('width', heatmapWidth).attr('height', height);

    const g = svg
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const x = d3
      .scaleBand<LifecycleStage>()
      .domain(LIFECYCLE_STAGES)
      .range([0, innerWidth])
      .padding(0.08);

    const y = d3
      .scaleBand<string>()
      .domain(branchStageMatrix.map(d => d.branch))
      .range([0, innerHeight])
      .padding(0.14);

    const getVal = (cell: { count: number; valueBdt: number; valueUsd: number; quantityMt: number }) =>
      cell[metricMode];

    const maxCellVal =
      d3.max(branchStageMatrix, row =>
        d3.max(LIFECYCLE_STAGES, st => getVal(row.stages[st]))
      ) || 1;

    const colorScale = d3
      .scaleSequential(d3.interpolateBlues)
      .domain([0, maxCellVal * 1.15]);

    // Top Stage Column Headers
    const xAxisGroup = g.append('g').call(
      d3.axisTop(x).tickSize(0).tickPadding(10)
    );
    xAxisGroup.select('.domain').remove();
    xAxisGroup
      .selectAll('text')
      .attr('fill', d => (selectedStage === d ? '#1D4ED8' : '#334155'))
      .attr('font-size', '11px')
      .attr('font-weight', '700')
      .style('cursor', 'pointer')
      .on('click', (_, st) => {
        setSelectedStage(prev => (prev === st ? 'ALL' : (st as LifecycleStage)));
      });

    // Left Branch Row Headers
    const yAxisGroup = g.append('g').call(
      d3.axisLeft(y).tickSize(0).tickPadding(10)
    );
    yAxisGroup.select('.domain').remove();
    yAxisGroup
      .selectAll('text')
      .attr('fill', d => (selectedBranch === d ? '#1D4ED8' : '#334155'))
      .attr('font-size', '11px')
      .attr('font-weight', d => (selectedBranch === d ? '700' : '600'))
      .style('cursor', 'pointer')
      .text(d => {
        const s = String(d);
        return s.length > 26 ? `${s.slice(0, 24)}…` : s;
      })
      .on('click', (_, br) => {
        setSelectedBranch(prev => (prev === br ? 'ALL' : String(br)));
      });

    // Flatten cells
    const cells = branchStageMatrix.flatMap(row =>
      LIFECYCLE_STAGES.map(stage => ({
        branch: row.branch,
        stage,
        metrics: row.stages[stage],
        value: getVal(row.stages[stage])
      }))
    );

    const cellGroups = g
      .selectAll('.heatmap-cell')
      .data(cells)
      .join('g')
      .attr('class', 'heatmap-cell')
      .attr('transform', d => `translate(${x(d.stage) || 0},${y(d.branch) || 0})`)
      .style('cursor', 'pointer')
      .on('click', (_, d) => {
        const isSame = selectedBranch === d.branch && selectedStage === d.stage;
        if (isSame) {
          setSelectedBranch('ALL');
          setSelectedStage('ALL');
        } else {
          setSelectedBranch(d.branch);
          setSelectedStage(d.stage);
        }
      });

    cellGroups
      .append('rect')
      .attr('width', x.bandwidth())
      .attr('height', y.bandwidth())
      .attr('rx', 6)
      .attr('fill', d => (d.value === 0 ? '#F8FAFC' : colorScale(d.value)))
      .attr('stroke', d => {
        const isActive = selectedBranch === d.branch && selectedStage === d.stage;
        if (isActive) return '#1D4ED8';
        return d.value === 0 ? '#E2E8F0' : '#BFDBFE';
      })
      .attr('stroke-width', d =>
        selectedBranch === d.branch && selectedStage === d.stage ? 2 : 1
      );

    cellGroups
      .append('text')
      .attr('x', x.bandwidth() / 2)
      .attr('y', y.bandwidth() / 2 + 4)
      .attr('text-anchor', 'middle')
      .attr('font-size', '11px')
      .attr('font-weight', '700')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('fill', d => {
        if (d.value === 0) return '#94A3B8';
        return d.value > maxCellVal * 0.55 ? '#FFFFFF' : '#0F172A';
      })
      .text(d => formatMetricValue(d.value, metricMode));
  }, [branchStageMatrix, heatmapWidth, metricMode, selectedBranch, selectedStage]);

  const hasActiveFilters =
    selectedStage !== 'ALL' || selectedBranch !== 'ALL' || searchQuery.trim() !== '';

  const resetFilters = () => {
    setSelectedStage('ALL');
    setSelectedBranch('ALL');
    setSearchQuery('');
  };

  return (
    <div className="space-y-6">
      {/* Top Filter & Control Toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Left: Search & Branch Selector */}
          <div className="flex flex-wrap items-center gap-3 flex-1">
            <div className="relative min-w-[240px] flex-1 max-w-xs">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search LC #, supplier, bank, or branch..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-blue-600 focus:outline-none transition-colors"
              />
            </div>

            {/* Branch Dimension Switcher */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setBranchDimension('combined')}
                className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  branchDimension === 'combined'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Port &amp; Bank Branch
              </button>
              <button
                type="button"
                onClick={() => setBranchDimension('bank_branch')}
                className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  branchDimension === 'bank_branch'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Bank Branch
              </button>
              <button
                type="button"
                onClick={() => setBranchDimension('port_branch')}
                className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  branchDimension === 'port_branch'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Port Office
              </button>
            </div>

            {/* Branch Filter Dropdown */}
            <select
              value={selectedBranch}
              onChange={e => setSelectedBranch(e.target.value)}
              className="px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:bg-white focus:border-blue-600 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Branches ({allBranches.length})</option>
              {allBranches.map(b => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>

            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="px-3 py-2 text-xs font-semibold text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Filters
              </button>
            )}
          </div>

          {/* Right: Metric Selector & Chart Layout Toggle */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {(
                [
                  { id: 'count', label: 'LC Count' },
                  { id: 'valueBdt', label: 'Value (BDT)' },
                  { id: 'valueUsd', label: 'Value (USD)' },
                  { id: 'quantityMt', label: 'Volume (MT)' }
                ] as { id: MetricMode; label: string }[]
              ).map(m => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMetricMode(m.id)}
                  className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    metricMode === m.id
                      ? 'bg-white text-blue-600 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setChartLayout('grouped')}
                className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  chartLayout === 'grouped'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Grouped
              </button>
              <button
                type="button"
                onClick={() => setChartLayout('stacked')}
                className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  chartLayout === 'stacked'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Stacked
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4-Stage Lifecycle Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stageSummaries.map((item, idx) => {
          const isSelected = selectedStage === item.stage;
          const color = STAGE_COLORS[item.stage];
          return (
            <button
              key={item.stage}
              type="button"
              onClick={() =>
                setSelectedStage(prev => (prev === item.stage ? 'ALL' : item.stage))
              }
              className={`text-left bg-white rounded-xl p-4 border transition-all cursor-pointer ${
                isSelected
                  ? 'border-blue-600 ring-2 ring-blue-600/15'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">
                  0{idx + 1}. {item.stage}
                </span>
                <span
                  className="text-xs font-mono font-bold tabular-nums"
                  style={{ color }}
                >
                  {item.sharePct}% of LCs
                </span>
              </div>

              <div className="flex items-baseline justify-between gap-2 my-1">
                <span className="text-2xl font-bold text-slate-900 font-mono tabular-nums">
                  {item.count}
                </span>
                <span className="text-xs font-mono font-semibold text-slate-700 tabular-nums">
                  ${item.valueUsd.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                </span>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono tabular-nums pt-2 mt-2 border-t border-slate-100">
                <span>৳{(item.valueBdt / 1000000).toFixed(2)}M BDT</span>
                <span>·</span>
                <span>{item.quantityMt.toLocaleString('en-US')} MT</span>
              </div>

              <p className="text-[11px] text-slate-500 mt-1.5 truncate">
                {STAGE_DESCRIPTIONS[item.stage]}
              </p>
            </button>
          );
        })}
      </div>

      {/* Primary D3 Visualizations Row: Left 8 Cols Bar Chart + Right 4 Cols Donut & Stage Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* D3 Chart 1: Branch Lifecycle Stage Comparison */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between relative">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  LC Lifecycle Stages by Branch
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Click any bar or branch axis label to filter LCs by lifecycle stage and branch
                </p>
              </div>

              {/* Stage Legend */}
              <div className="flex flex-wrap items-center gap-3 text-xs">
                {LIFECYCLE_STAGES.map(stage => (
                  <button
                    key={stage}
                    type="button"
                    onClick={() =>
                      setSelectedStage(prev => (prev === stage ? 'ALL' : stage))
                    }
                    className={`flex items-center gap-1.5 transition-opacity cursor-pointer ${
                      selectedStage === 'ALL' || selectedStage === stage
                        ? 'opacity-100 font-semibold text-slate-800'
                        : 'opacity-40 text-slate-500'
                    }`}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-xs shrink-0"
                      style={{ backgroundColor: STAGE_COLORS[stage] }}
                    />
                    <span className="whitespace-nowrap">{stage}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* SVG Container */}
            <div ref={barChartContainerRef} className="w-full pt-3 relative">
              {branchStageMatrix.length === 0 ? (
                <div className="h-[320px] flex flex-col items-center justify-center text-center">
                  <p className="text-sm font-semibold text-slate-700">
                    No LC records match the current filter criteria
                  </p>
                  <button
                    type="button"
                    onClick={resetFilters}
                    className="mt-2 px-3 py-1.5 text-xs font-semibold text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer"
                  >
                    Clear Filters
                  </button>
                </div>
              ) : (
                <svg ref={barChartSvgRef} className="w-full overflow-visible" />
              )}

              {/* Floating Tooltip */}
              {tooltip && tooltip.visible && (
                <div
                  style={{
                    left: Math.min(Math.max(16, tooltip.x - 90), barChartWidth - 210),
                    top: Math.max(8, tooltip.y - 125)
                  }}
                  className="pointer-events-none absolute z-30 bg-slate-900 text-white rounded-lg p-3 shadow-lg border border-slate-700 text-xs w-52"
                >
                  <div className="font-bold text-white truncate">{tooltip.title}</div>
                  <div className="text-[11px] text-slate-300 pb-1.5 mb-1.5 border-b border-slate-700">
                    {tooltip.subtitle}
                  </div>
                  <div className="space-y-1 font-mono tabular-nums text-[11px]">
                    {tooltip.lines.map(line => (
                      <div key={line.label} className="flex items-center justify-between">
                        <span className="text-slate-400 font-sans">{line.label}:</span>
                        <span className="font-bold text-white">{line.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
            <span>
              Showing <strong className="font-mono text-slate-800">{filteredLcs.length}</strong> of{' '}
              <strong className="font-mono text-slate-800">{enrichedLcs.length}</strong> active Letters of Credit across{' '}
              <strong className="font-mono text-slate-800">{branchStageMatrix.length}</strong> branches
            </span>
            <label className="inline-flex items-center gap-1.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={includeCancelled}
                onChange={e => setIncludeCancelled(e.target.checked)}
                className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
              <span>Include cancelled / voided LCs</span>
            </label>
          </div>
        </div>

        {/* D3 Chart 2: Portfolio Stage Share & Cumulative Flow */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="pb-4 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900">
                Lifecycle Stage Distribution
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Proportional breakdown across the 4 LC stages
              </p>
            </div>

            <div className="flex justify-center py-4">
              <svg ref={donutSvgRef} />
            </div>

            {/* Stage Progression Breakdown List */}
            <div className="space-y-3 pt-2">
              {stageSummaries.map(s => {
                const isSelected = selectedStage === s.stage;
                return (
                  <button
                    key={s.stage}
                    type="button"
                    onClick={() =>
                      setSelectedStage(prev => (prev === s.stage ? 'ALL' : s.stage))
                    }
                    className={`w-full text-left p-2.5 rounded-lg border transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50/50 border-blue-600'
                        : 'border-slate-100 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-semibold text-slate-800 flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-xs shrink-0"
                          style={{ backgroundColor: STAGE_COLORS[s.stage] }}
                        />
                        {s.stage}
                      </span>
                      <span className="font-mono font-bold text-slate-900 tabular-nums">
                        {s.count} LCs · {s.sharePct}%
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-200"
                        style={{
                          width: `${Math.max(s.count > 0 ? 4 : 0, s.sharePct)}%`,
                          backgroundColor: STAGE_COLORS[s.stage]
                        }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-3 mt-4 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between font-mono tabular-nums">
            <span>Total Portfolio CFR:</span>
            <strong className="text-slate-900">
              ${stageSummaries.reduce((acc, s) => acc + s.valueUsd, 0).toLocaleString('en-US', { maximumFractionDigits: 0 })} USD
            </strong>
          </div>
        </div>
      </div>

      {/* D3 Chart 3: Branch × Lifecycle Stage Matrix Heatmap */}
      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Branch × Lifecycle Stage Matrix
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              D3 density matrix comparing {metricMode === 'count' ? 'LC count' : metricMode === 'valueBdt' ? 'BDT value' : metricMode === 'valueUsd' ? 'USD value' : 'import tonnage (MT)'} across branches and lifecycle stages
            </p>
          </div>
          <span className="text-xs text-slate-500 font-mono tabular-nums">
            Click any cell to isolate branch &amp; stage
          </span>
        </div>

        <div ref={heatmapContainerRef} className="w-full pt-3 overflow-x-auto">
          <svg ref={heatmapSvgRef} className="w-full min-w-[540px]" />
        </div>
      </div>

      {/* Filtered LC Lifecycle Register Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              LC Lifecycle Breakdown ({filteredLcs.length})
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span>Stage: <strong className="text-slate-800">{selectedStage === 'ALL' ? 'All Lifecycle Stages' : selectedStage}</strong></span>
              <span>·</span>
              <span>Branch: <strong className="text-slate-800">{selectedBranch === 'ALL' ? 'All Branches' : selectedBranch}</strong></span>
            </div>
          </div>

          {onOpenNewLcModal && (
            <button
              type="button"
              onClick={onOpenNewLcModal}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              + Open Import LC
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                <th className="py-3 px-4">LC Number</th>
                <th className="py-3 px-4">Branch &amp; Port</th>
                <th className="py-3 px-4">Beneficiary / Exporter</th>
                <th className="py-3 px-4">Lifecycle Stage</th>
                <th className="py-3 px-4 text-right">Receiving (MT)</th>
                <th className="py-3 px-4 text-right">CFR Value (USD)</th>
                <th className="py-3 px-4 text-right">Value (BDT)</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredLcs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-500">
                    No Letters of Credit match the selected branch and stage filters.
                  </td>
                </tr>
              ) : (
                filteredLcs.map(item => {
                  const stageColor = STAGE_COLORS[item.stage];
                  return (
                    <tr
                      key={item.lc.id}
                      className="hover:bg-slate-50/80 transition-colors"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                        <div>{item.lc.lcNumber}</div>
                        <div className="text-[11px] font-normal text-slate-500">
                          Opened: {item.lc.openingDate || 'N/A'}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-800">{item.branchName}</div>
                        <div className="text-[11px] text-slate-500">
                          {item.lc.issuingBank} · {item.portName}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-800 truncate max-w-[220px]">
                          {item.lc.supplierName}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate max-w-[220px]">
                          {item.lc.originQuarryItem || item.lc.items?.[0]?.itemName || 'Import Commodity'}
                        </div>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <div
                          className="font-semibold text-xs"
                          style={{ color: stageColor }}
                        >
                          {item.stage}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Status: {item.lc.status}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono tabular-nums whitespace-nowrap">
                        <div className="font-semibold text-slate-800">
                          {item.receivedQtyMt.toLocaleString('en-US')} / {item.totalQtyMt.toLocaleString('en-US')} MT
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {item.receivingPct}% received
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums whitespace-nowrap">
                        ${item.valueUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-semibold text-slate-800 tabular-nums whitespace-nowrap">
                        ৳{Math.round(item.valueBdt).toLocaleString('en-US')}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center justify-end gap-1.5">
                          {onNavigateToReceiving && (
                            <button
                              type="button"
                              onClick={() => onNavigateToReceiving(item.lc)}
                              title="Open Border Product Receiving"
                              className="px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:text-blue-600 bg-slate-100 hover:bg-blue-50 rounded-md transition-colors cursor-pointer"
                            >
                              Receive
                            </button>
                          )}
                          {onNavigateToExpenses && (
                            <button
                              type="button"
                              onClick={() => onNavigateToExpenses(item.lc)}
                              title="Open Customs & Landed Cost"
                              className="px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:text-teal-700 bg-slate-100 hover:bg-teal-50 rounded-md transition-colors cursor-pointer"
                            >
                              Customs / Cost
                            </button>
                          )}
                          {onNavigateToBills && (
                            <button
                              type="button"
                              onClick={() => onNavigateToBills(item.lc)}
                              title="Open Exporter Bills & Settlement"
                              className="px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:text-emerald-700 bg-slate-100 hover:bg-emerald-50 rounded-md transition-colors cursor-pointer"
                            >
                              Settle
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
