import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  ArrowDownToLine, 
  Truck, 
  Scale, 
  Receipt, 
  Calculator, 
  Building, 
  Calendar, 
  CheckCircle2, 
  Search, 
  Plus, 
  Printer, 
  Trash2, 
  AlertCircle, 
  ArrowRight, 
  Coins, 
  Ship, 
  DollarSign, 
  FileText, 
  Layers, 
  X, 
  Check, 
  Filter, 
  TrendingUp, 
  Eye, 
  ShieldCheck,
  MapPin,
  Clock,
  Warehouse as WarehouseIcon,
  AlertTriangle,
  ShieldAlert,
  Edit3,
  Unlock,
  Sliders,
  Info,
  Loader2
} from 'lucide-react';
import { LetterOfCredit, StockReceivingRecord, DailyLCExpenseBreakdown, InventoryItem, Warehouse, Supplier } from '../../types/erp';
import { MOCK_ITEMS, MOCK_WAREHOUSES, MOCK_SUPPLIERS, MOCK_STOCK_RECEIVINGS } from '../../data/mockErpData';
import { computeLCProgressAndStatus } from '../../utils/lcStatusHelper';
import { computeLcBill, ensureRateBatchesForBillableQty } from '../../utils/lcBillingHelper';
import { useAuth } from '../../contexts/AuthContext';
import { ModalWrapper } from '../common/ModalWrapper';

interface LCProductReceivingSectorProps {
  lcs: LetterOfCredit[];
  selectedLc?: LetterOfCredit;
  onSelectLc?: (lc: LetterOfCredit) => void;
  onUpdateLc?: (updatedLc: LetterOfCredit) => void;
  onAddStockReceiving?: (record: StockReceivingRecord) => void;
  onDeleteStockReceiving?: (id: string) => void;
  currentBranch?: string;
}

export const LCProductReceivingSector: React.FC<LCProductReceivingSectorProps> = ({
  lcs,
  selectedLc,
  onSelectLc,
  onUpdateLc,
  onAddStockReceiving,
  onDeleteStockReceiving,
  currentBranch
}) => {
  // Local storage synced receivings
  const [receivings, setReceivings] = useState<StockReceivingRecord[]>(() => {
    try {
      const saved = localStorage.getItem('tradecore_lc_receivings_v1');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error(e);
    }
    return MOCK_STOCK_RECEIVINGS;
  });

  // Modals
  const [showAddReceivingModal, setShowAddReceivingModal] = useState(false);
  const [showPrintSlipModal, setShowPrintSlipModal] = useState(false);
  const [showExpenseDetailsModal, setShowExpenseDetailsModal] = useState(false);
  const [selectedReceivingForView, setSelectedReceivingForView] = useState<StockReceivingRecord | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Auth context
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  // Over-tolerance admin approval & Short receiving modals
  const [adminApprovalReason, setAdminApprovalReason] = useState('');
  const [showShortReceivingModal, setShowShortReceivingModal] = useState(false);
  const [shortReceivingTargetLc, setShortReceivingTargetLc] = useState<LetterOfCredit | null>(null);
  const [shortReceivingReason, setShortReceivingReason] = useState('');
  const [showEditToleranceModal, setShowEditToleranceModal] = useState(false);
  const [editToleranceTargetLc, setEditToleranceTargetLc] = useState<LetterOfCredit | null>(null);
  const [toleranceInput, setToleranceInput] = useState<number>(5);

  // Filters
  const [filterLcId, setFilterLcId] = useState<string>(selectedLc ? selectedLc.id : 'all');
  const [filterPort, setFilterPort] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  // Lock body scroll when modals open
  useEffect(() => {
    const isAnyModalOpen = 
      showAddReceivingModal || 
      showPrintSlipModal || 
      showExpenseDetailsModal || 
      showShortReceivingModal || 
      showEditToleranceModal;
    if (isAnyModalOpen) {
      const original = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = original || 'unset';
      };
    }
  }, [showAddReceivingModal, showPrintSlipModal, showExpenseDetailsModal, showShortReceivingModal, showEditToleranceModal]);

  // Form State for New Receiving
  const [targetLcId, setTargetLcId] = useState<string>('');
  const activeFormLc = lcs.find(l => l.id === targetLcId);

  const [receiveDate, setReceiveDate] = useState(new Date().toISOString().split('T')[0]);
  const [borderLandPort, setBorderLandPort] = useState('');
  
  // Truck & Transport State (All user-entered fields start BLANK per user instructions)
  const [truckCount, setTruckCount] = useState<number | ''>('');
  const [truckNo, setTruckNo] = useState('');
  const [driverName, setDriverName] = useState('');
  const [scaleSlipNo, setScaleSlipNo] = useState('');
  
  // Weight & Measurement (Starts BLANK per user instructions)
  const [calcMode, setCalcMode] = useState<'weighbridge' | 'direct_net'>('weighbridge');
  const [grossWeightMt, setGrossWeightMt] = useState<number | ''>('');
  const [tareWeightMt, setTareWeightMt] = useState<number | ''>('');
  const [directNetWeightMt, setDirectNetWeightMt] = useState<number | ''>('');
  
  // Warehouse Yard & Remarks (Remarks starts BLANK)
  const [destinationYard, setDestinationYard] = useState('');
  const [yardId, setYardId] = useState('');
  const [remarks, setRemarks] = useState('');
  const [isSavingReceiving, setIsSavingReceiving] = useState(false);
  const isSavingReceivingRef = useRef(false);

  // Reset receiving form so all user fields are clean and blank
  const resetReceivingForm = () => {
    setTargetLcId('');
    setReceiveDate(new Date().toISOString().split('T')[0]);
    setBorderLandPort('');
    setTruckCount('');
    setTruckNo('');
    setDriverName('');
    setScaleSlipNo('');
    setGrossWeightMt('');
    setTareWeightMt('');
    setDirectNetWeightMt('');
    setDestinationYard('');
    setYardId('');
    setRemarks('');
    setAdminApprovalReason('');
    isSavingReceivingRef.current = false;
    setIsSavingReceiving(false);
  };

  const handleCloseReceivingModal = () => {
    resetReceivingForm();
    setShowAddReceivingModal(false);
  };

  const isReceivingFormDirty =
    targetLcId !== '' ||
    borderLandPort !== '' ||
    truckCount !== '' ||
    truckNo.trim() !== '' ||
    driverName.trim() !== '' ||
    scaleSlipNo.trim() !== '' ||
    grossWeightMt !== '' ||
    tareWeightMt !== '' ||
    directNetWeightMt !== '' ||
    destinationYard !== '' ||
    remarks.trim() !== '' ||
    adminApprovalReason.trim() !== '';

  const handleCloseShortReceivingModal = () => {
    setShortReceivingReason('');
    setShortReceivingTargetLc(null);
    setShowShortReceivingModal(false);
  };

  const handleCloseEditToleranceModal = () => {
    setEditToleranceTargetLc(null);
    setShowEditToleranceModal(false);
  };

  // Update form defaults when target LC changes
  const handleTargetLcChange = (lcId: string) => {
    setTargetLcId(lcId);
    setAdminApprovalReason('');
    const chosen = lcs.find(l => l.id === lcId);
    if (chosen) {
      if (chosen.borderLandPort) {
        setBorderLandPort(chosen.borderLandPort.includes('Port') ? chosen.borderLandPort : `${chosen.borderLandPort} Land Port`);
      }
    }
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Multiple trucks check
  const isMultipleTrucks = typeof truckCount === 'number' ? truckCount > 1 : (Number(truckCount) > 1);

  // Calculated Net Weight
  const netReceivedMt = useMemo(() => {
    if (isMultipleTrucks) {
      return typeof directNetWeightMt === 'number' ? Math.max(0, directNetWeightMt) : (Number(directNetWeightMt) || 0);
    }
    if (calcMode === 'weighbridge') {
      const g = typeof grossWeightMt === 'number' ? grossWeightMt : (Number(grossWeightMt) || 0);
      const t = typeof tareWeightMt === 'number' ? tareWeightMt : (Number(tareWeightMt) || 0);
      return (g > 0 && t > 0) ? Math.max(0, Number((g - t).toFixed(2))) : 0;
    }
    return typeof directNetWeightMt === 'number' ? Math.max(0, directNetWeightMt) : (Number(directNetWeightMt) || 0);
  }, [isMultipleTrucks, calcMode, grossWeightMt, tareWeightMt, directNetWeightMt]);

  // CFT Equivalent (1 MT ≈ 20.2 CFT for boulder stone)
  const cftEquivalent = Math.round(netReceivedMt * 20.2);

  // Aggregated LC Stats using computeLcBill (Requirement 1, 4, 7)
  const activeLcStats = useMemo(() => {
    return lcs.map(lc => {
      // Get all non-deleted receivings for this LC
      const lcRecs = receivings.filter(r => r.lcNumber === lc.lcNumber);
      const lcWithRecs: LetterOfCredit = {
        ...lc,
        receivings: lcRecs
      };
      const bill = computeLcBill(lcWithRecs);
      const progressPercent = bill.contractQty > 0
        ? Math.round((bill.receivedQty / bill.contractQty) * 100)
        : 100;
      const totalDailyExpenses = lcRecs.reduce((sum, r) => sum + (r.dailyExpenses?.totalDailyExpense || 0), 0);
      const truckCount = lcRecs.reduce((sum, r) => sum + (r.truckCount || 1), 0);

      return {
        lc: lcWithRecs,
        bill,
        contractedQty: bill.contractQty,
        totalRecMt: Number(bill.receivedQty.toFixed(2)),
        remainingMt: Number(bill.remainingQty.toFixed(2)), // negative if excess!
        excessQty: Number(bill.excessQty.toFixed(2)),
        isOverReceived: bill.isOverReceived,
        isReceivingCompleted: bill.isReceivingCompleted,
        progressPercent,
        totalDailyExpenses,
        truckCount,
        receivingsCount: lcRecs.length,
        allowedTolerancePercent: lc.allowedTolerancePercent ?? 5
      };
    });
  }, [lcs, receivings]);

  // Global KPIs (Negative remaining shown as Excess per Requirement 4)
  const globalContractedMt = activeLcStats.reduce((sum, s) => sum + s.contractedQty, 0);
  const globalReceivedMt = activeLcStats.reduce((sum, s) => sum + s.totalRecMt, 0);
  const globalRemainingMt = globalContractedMt - globalReceivedMt;
  const globalExcessMt = Math.max(0, globalReceivedMt - globalContractedMt);
  const globalTotalExpenses = activeLcStats.reduce((sum, s) => sum + s.totalDailyExpenses, 0);
  const globalTrucksCount = activeLcStats.reduce((sum, s) => sum + s.truckCount, 0);

  // Filtered Receivings
  const filteredReceivings = useMemo(() => {
    return receivings.filter(rec => {
      if (filterLcId !== 'all') {
        const matchingLc = lcs.find(l => l.id === filterLcId);
        if (matchingLc && rec.lcNumber !== matchingLc.lcNumber) {
          return false;
        }
      }
      if (filterPort !== 'all') {
        if (!rec.portOrBorder.toLowerCase().includes(filterPort.toLowerCase())) {
          return false;
        }
      }
      if (dateFilter && rec.date !== dateFilter) {
        return false;
      }
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const match = 
          (rec.grnNo && rec.grnNo.toLowerCase().includes(q)) ||
          (rec.lcNumber && rec.lcNumber.toLowerCase().includes(q)) ||
          (rec.vehicleNo && rec.vehicleNo.toLowerCase().includes(q)) ||
          (rec.weighbridgeSlipNo && rec.weighbridgeSlipNo.toLowerCase().includes(q)) ||
          (rec.supplierName && rec.supplierName.toLowerCase().includes(q)) ||
          (rec.itemName && rec.itemName.toLowerCase().includes(q));
        if (!match) return false;
      }
      return true;
    });
  }, [receivings, filterLcId, filterPort, dateFilter, searchTerm, lcs]);

  // Handle Form Submission: Create Receiving & Auto-post to LC Expenses and Stock
  const handleSaveReceiving = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeFormLc) return;
    if (isSavingReceivingRef.current) return;

    if (netReceivedMt <= 0) {
      alert('Net received weight (MT) must be greater than zero.');
      return;
    }

    if (isMultipleTrucks && (!truckCount || Number(truckCount) < 2)) {
      alert('For multiple truck lot entries, truck count must be at least 2.');
      return;
    }

    const activeLcContractQty = Number(activeFormLc.quantity) || 0;
    const activeLcReceivedSoFar = (activeFormLc.receivings || [])
      .filter(r => (r as any).status !== 'Voided')
      .reduce((acc, r) => acc + (Number(r.receivedQty || r.netWeightMt) || 0), 0);
    const projectedTotalReceived = activeLcReceivedSoFar + netReceivedMt;
    const allowedTolerance = activeFormLc.allowedTolerancePercent ?? 5;
    const toleranceThresholdQty = activeLcContractQty * (1 + allowedTolerance / 100);
    const isOverTolerance = projectedTotalReceived > toleranceThresholdQty;

    // Tolerance validation (Requirement 4)
    if (isOverTolerance) {
      if (!isAdmin) {
        alert(`Admin approval required: receiving ${projectedTotalReceived} MT exceeds contractual tolerance of ${allowedTolerance}% (${toleranceThresholdQty.toFixed(1)} MT).`);
        return;
      }
      if (!adminApprovalReason.trim()) {
        alert(`Mandatory admin approval reason is required because contractual tolerance (${allowedTolerance}%) is exceeded.`);
        return;
      }
    }

    isSavingReceivingRef.current = true;
    setIsSavingReceiving(true);

    try {
      const commodityName = activeFormLc.items?.[0]?.itemName || activeFormLc.originQuarryItem || activeFormLc.boulderCategory || 'Boulder Stone';
      const itemId = activeFormLc.items?.[0]?.itemId || 'item-stn-01';

      const newRecId = `grn-${Date.now()}`;
      const newGrnNo = `GRN-${(activeFormLc.borderLandPort || 'BUR').slice(0, 3).toUpperCase()}-${new Date().getFullYear()}-${String(receivings.length + 101).padStart(3, '0')}`;

      // Unit cost and total cost of the receiving record
      const currentLcBill = computeLcBill(activeFormLc);
      const billedCommercialRate = currentLcBill.weightedAverageCommercialRate;
      const currentExchangeRate = currentLcBill.exchangeRate;
      const unitCostBdt = Math.round(billedCommercialRate * currentExchangeRate);
      const totalCostBdt = Math.round(netReceivedMt * unitCostBdt);

      const newReceiving: StockReceivingRecord = {
        id: newRecId,
        grnNo: newGrnNo,
        date: receiveDate,
        time: '',
        supplierId: activeFormLc.supplierId || 'supp-direct',
        supplierName: activeFormLc.supplierName,
        lcNumber: activeFormLc.lcNumber,
        portOrBorder: borderLandPort,
        vehicleNo: isMultipleTrucks 
          ? `${truckCount} Trucks Lot` 
          : (truckNo.trim() || '1 Truck'),
        truckCount: Number(truckCount) || 1,
        driverName: isMultipleTrucks ? '' : driverName.trim(),
        driverPhone: '',
        weighbridgeSlipNo: isMultipleTrucks ? '' : scaleSlipNo.trim(),
        grossWeightMt: isMultipleTrucks ? netReceivedMt : (calcMode === 'weighbridge' ? (Number(grossWeightMt) || netReceivedMt) : netReceivedMt),
        tareWeightMt: isMultipleTrucks ? 0 : (calcMode === 'weighbridge' ? (Number(tareWeightMt) || 0) : 0),
        netWeightMt: netReceivedMt,
        itemId,
        itemName: commodityName,
        receivedQty: netReceivedMt,
        uom: activeFormLc.uom || 'MT',
        cftEquivalent,
        unitCostBdt,
        totalCostBdt,
        warehouseId: yardId,
        warehouseName: destinationYard,
        dailyExpenses: undefined,
        remarks: remarks.trim(),
        receivedBy: currentUser?.name || 'Yard In-Charge',
        status: 'Received & Stock Added'
      };

      // 1. Add to receivings state & localStorage
      const updatedReceivings = [newReceiving, ...receivings];
      setReceivings(updatedReceivings);
      try {
        localStorage.setItem('tradecore_lc_receivings_v1', JSON.stringify(updatedReceivings));
      } catch (err) {
        console.error(err);
      }
      if (onAddStockReceiving) {
        onAddStockReceiving(newReceiving);
      }

      // 2. Update LC receivings and recalculate bill/progress
      if (onUpdateLc) {
        const currentExpenses = activeFormLc.expenses || [];
        const updatedLcReceivings = [newReceiving, ...(activeFormLc.receivings || [])];

        const baseUpdatedLc: LetterOfCredit = {
          ...activeFormLc,
          expenses: currentExpenses,
          receivings: updatedLcReceivings,
          auditLogs: (isOverTolerance && adminApprovalReason) ? [
            ...(activeFormLc.auditLogs || []),
            {
              id: `audit-${Date.now()}`,
              timestamp: new Date().toISOString(),
              user: currentUser?.name || 'Admin',
              action: 'Over-Tolerance Receiving Approved',
              details: `Receiving ${netReceivedMt} MT (total ${projectedTotalReceived} MT, tolerance ${allowedTolerance}%) approved with reason: ${adminApprovalReason}`
            }
          ] : activeFormLc.auditLogs
        };

        const newBill = computeLcBill(baseUpdatedLc);
        const synchronizedBatches = ensureRateBatchesForBillableQty(baseUpdatedLc, newBill.billableQty);
        const progress = computeLCProgressAndStatus({
          ...baseUpdatedLc,
          rateBatches: synchronizedBatches
        });

        const updatedLc: LetterOfCredit = {
          ...baseUpdatedLc,
          receivedQuantity: newBill.receivedQty,
          receivedQtyMt: newBill.receivedQty,
          remainingQuantity: newBill.remainingQty,
          rateBatches: synchronizedBatches,
          status: progress.computedStatus
        };

        onUpdateLc(updatedLc);
        try {
          const storedLcs = JSON.parse(localStorage.getItem('tradecore_lcs_v1') || '[]');
          if (Array.isArray(storedLcs) && storedLcs.length > 0) {
            const next = storedLcs.map(l => l.id === updatedLc.id ? updatedLc : l);
            localStorage.setItem('tradecore_lcs_v1', JSON.stringify(next));
          }
        } catch (err) {}
      }

      setShowAddReceivingModal(false);
      resetReceivingForm();
      triggerToast(`✓ LC ${activeFormLc.lcNumber}: ${netReceivedMt} MT successfully received and added to inventory!`);
    } finally {
      isSavingReceivingRef.current = false;
      setIsSavingReceiving(false);
    }
  };

  // Handle Deleting / Reverting a Receiving (Requirement 5: Deleting a receiving that would make bill smaller than amount settled must be blocked)
  const handleDeleteReceiving = (rec: StockReceivingRecord) => {
    const target = lcs.find(l => l.lcNumber === rec.lcNumber);
    if (target) {
      const simulatedReceivings = (target.receivings || []).filter(r => r.id !== rec.id);
      const simulatedLc: LetterOfCredit = {
        ...target,
        receivings: simulatedReceivings
      };
      const simulatedBill = computeLcBill(simulatedLc);

      if (simulatedBill.officialBillForeign < simulatedBill.totalBankSettledForeign) {
        alert(`Cannot delete challan: Deleting this challan would reduce official bank bill to $${simulatedBill.officialBillForeign.toLocaleString()}, but $${simulatedBill.totalBankSettledForeign.toLocaleString()} has already been settled with the bank. Settlements cannot exceed bill amount. Please void the excess bank settlement voucher first.`);
        return;
      }
      if (simulatedBill.hundiGapBdt < simulatedBill.totalHundiPaidBdt) {
        alert(`চালানটি মুছে ফেলা যাবে না: এই চালান ডিলিট করলে হুন্ডি গ্যাপ দাঁড়াবে ৳${simulatedBill.hundiGapBdt.toLocaleString()}, কিন্তু ইতিমধ্যে হুন্ডিতে ৳${simulatedBill.totalHundiPaidBdt.toLocaleString()} পরিশোধ করা হয়েছে। অনুগ্রহ করে প্রথমে অতিরিক্ত হুন্ডি পেমেন্ট ভাউচারটি ভয়েড (Void) করুন।`);
        return;
      }
    }

    if (!window.confirm(`Are you sure you want to delete challan ${rec.grnNo} (${rec.netWeightMt} MT)? This will adjust stock and LC expenses.`)) {
      return;
    }

    const updated = receivings.filter(r => r.id !== rec.id);
    setReceivings(updated);
    try {
      localStorage.setItem('tradecore_lc_receivings_v1', JSON.stringify(updated));
    } catch (err) {}

    if (onDeleteStockReceiving) {
      onDeleteStockReceiving(rec.id);
    }

    // Revert LC received total
    if (target && onUpdateLc) {
      const simulatedReceivings = (target.receivings || []).filter(r => r.id !== rec.id);
      const simulatedLc: LetterOfCredit = {
        ...target,
        receivings: simulatedReceivings
      };
      const simulatedBill = computeLcBill(simulatedLc);

      // Filter out auto-generated expenses with matching voucher
      const vchPrefix = rec.dailyExpenses?.expenseVoucherNo;
      const filteredExpenses = (target.expenses || []).filter(e => {
        if (vchPrefix && e.voucherNo && e.voucherNo.startsWith(vchPrefix)) {
          return false;
        }
        return true;
      });

      // Requirement 2: When a receiving entry is deleted or reduced, shrink or remove the auto batch accordingly
      const synchronizedBatches = ensureRateBatchesForBillableQty(simulatedLc, simulatedBill.billableQty);
      const progress = computeLCProgressAndStatus({
        ...simulatedLc,
        rateBatches: synchronizedBatches
      });

      const updatedLc: LetterOfCredit = {
        ...target,
        receivedQuantity: simulatedBill.receivedQty,
        remainingQuantity: simulatedBill.remainingQty, // negative if excess!
        receivedQtyMt: simulatedBill.receivedQty,
        expenses: filteredExpenses,
        receivings: simulatedReceivings,
        rateBatches: synchronizedBatches,
        status: progress.computedStatus
      };

      onUpdateLc(updatedLc);
      try {
        const storedLcs = JSON.parse(localStorage.getItem('tradecore_lcs_v1') || '[]');
        if (Array.isArray(storedLcs) && storedLcs.length > 0) {
          const next = storedLcs.map(l => l.id === updatedLc.id ? updatedLc : l);
          localStorage.setItem('tradecore_lcs_v1', JSON.stringify(next));
        }
      } catch (err) {}
    }

    triggerToast(`✓ Challan ${rec.grnNo} successfully deleted and rolled back!`);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner & Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              LC Product Receiving Sector
            </h1>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => {
                resetReceivingForm();
                setShowAddReceivingModal(true);
              }}
              className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Receive Product & Stock In</span>
            </button>
          </div>
        </div>

        {/* Global Summary KPI Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5 pt-4">
          {/* Card 1: Total Contracted */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
            <span className="text-[10px] font-bold uppercase text-slate-500 block flex items-center gap-1">
              <Ship className="w-3 h-3 text-blue-600" />
              Total Contracted
            </span>
            <div className="text-xl font-black font-mono text-slate-900">
              {globalContractedMt.toLocaleString()} <span className="text-xs font-normal text-slate-500">MT</span>
            </div>
            <span className="text-[10px] text-slate-400 block font-mono">
              {lcs.length} Active LCs
            </span>
          </div>

          {/* Card 2: Total Received So Far */}
          <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-1">
            <span className="text-[10px] font-bold uppercase text-emerald-700 block flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              Total Received to Date
            </span>
            <div className="text-xl font-black font-mono text-emerald-950">
              {globalReceivedMt.toLocaleString()} <span className="text-xs font-normal text-emerald-700">MT</span>
            </div>
            <span className="text-[10px] text-emerald-700 block font-mono font-bold">
              {globalContractedMt > 0 ? ((globalReceivedMt / globalContractedMt) * 100).toFixed(1) : 0}% Completed
            </span>
          </div>

          {/* Card 3: Pending Balance or Excess */}
          <div className={`p-3.5 border rounded-xl space-y-1 ${
            globalRemainingMt < 0 
              ? 'bg-amber-100/70 border-amber-300' 
              : 'bg-amber-50/70 border-amber-200'
          }`}>
            <span className={`text-[10px] font-bold uppercase block flex items-center gap-1 ${
              globalRemainingMt < 0 ? 'text-amber-900' : 'text-amber-700'
            }`}>
              <Clock className="w-3 h-3 text-amber-600" />
              {globalRemainingMt < 0 ? 'Total Excess' : 'Pending Balance'}
            </span>
            <div className={`text-xl font-black font-mono ${
              globalRemainingMt < 0 ? 'text-amber-950' : 'text-amber-950'
            }`}>
              {globalRemainingMt < 0 
                ? `-${Math.abs(globalRemainingMt).toLocaleString()} MT` 
                : `${globalRemainingMt.toLocaleString()} MT`}
            </div>
            <span className="text-[10px] text-amber-800 block font-mono font-bold">
              {globalRemainingMt < 0 ? `+${globalExcessMt.toLocaleString()} MT Excess Billed` : 'In-Transit / Unloading'}
            </span>
          </div>

          {/* Card 4: Total Trucks Cleared */}
          <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl space-y-1">
            <span className="text-[10px] font-bold uppercase text-blue-700 block flex items-center gap-1">
              <Truck className="w-3 h-3 text-blue-600" />
              Total Cleared Trucks
            </span>
            <div className="text-xl font-black font-mono text-blue-950">
              {globalTrucksCount} <span className="text-xs font-normal text-blue-700">Trucks</span>
            </div>
            <span className="text-[10px] text-blue-700 block font-mono">
              {receivings.length} Receiving Challans
            </span>
          </div>

          {/* Card 5: Daily Expenses Accrued */}
          <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-1 col-span-2 md:col-span-1">
            <span className="text-[10px] font-bold uppercase text-indigo-700 block flex items-center gap-1">
              <Coins className="w-3 h-3 text-indigo-600" />
              Border Expenses
            </span>
            <div className="text-xl font-black font-mono text-indigo-950">
              ৳{(globalTotalExpenses / 100000).toFixed(2)} <span className="text-xs font-normal text-indigo-700">Lakh</span>
            </div>
            <span className="text-[10px] text-indigo-700 block font-mono">
              Total: ৳{globalTotalExpenses.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* LC Tonnage Receiving Progress Cards */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-slate-900 text-sm">
              Active LCs Border Receiving Progress
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {lcs.length} Active LCs Tracked
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-1">
          {activeLcStats.map(stat => {
            const isSelected = selectedLc?.id === stat.lc.id;
            return (
              <div 
                key={stat.lc.id}
                className={`p-4 rounded-xl border transition-all space-y-3 ${
                  isSelected 
                    ? 'bg-emerald-50/40 border-emerald-500 shadow-xs ring-1 ring-emerald-400' 
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-mono font-black text-xs text-blue-900 block">
                        {stat.lc.lcNumber}
                      </span>
                      {/* Excess Badge (Requirement 4) */}
                      {stat.excessQty > 0 && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black font-mono bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                          +{stat.excessQty} MT Excess
                        </span>
                      )}
                      {stat.isReceivingCompleted && (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold font-mono bg-purple-100 text-purple-900 border border-purple-200" title={stat.lc.receivingCompletedReason}>
                          Short Closed
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-600 font-medium truncate max-w-[200px] block mt-0.5">
                      {stat.lc.supplierName}
                    </span>
                  </div>

                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono shrink-0 ${
                    stat.progressPercent >= 100 
                      ? 'bg-emerald-100 text-emerald-800' 
                      : stat.progressPercent > 0 
                        ? 'bg-blue-100 text-blue-800' 
                        : 'bg-amber-100 text-amber-800'
                  }`}>
                    {stat.progressPercent}%
                  </span>
                </div>

                {/* Quantitative Metrics (Requirement 4: Remaining box shows negative figure as Excess, never 0) */}
                <div className="flex items-center justify-between text-xs font-mono bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <div>
                    <span className="text-slate-400 text-[10px] block font-sans">Contracted:</span>
                    <span className="font-bold text-slate-900">{stat.contractedQty.toLocaleString()} MT</span>
                  </div>
                  <div className="text-center">
                    <span className="text-emerald-600 text-[10px] block font-sans">Received:</span>
                    <span className="font-bold text-emerald-800">{stat.totalRecMt.toLocaleString()} MT</span>
                  </div>
                  <div className="text-right">
                    <span className={`text-[10px] block font-sans ${stat.remainingMt < 0 ? 'text-amber-800 font-bold' : 'text-amber-600'}`}>
                      {stat.remainingMt < 0 ? 'Excess:' : 'Remaining:'}
                    </span>
                    <span className={`font-bold font-mono ${
                      stat.remainingMt < 0 ? 'text-amber-900 bg-amber-100 px-1.5 py-0.5 rounded' : 'text-amber-900'
                    }`}>
                      {stat.remainingMt < 0 ? `-${stat.excessQty.toLocaleString()} MT` : `${stat.remainingMt.toLocaleString()} MT`}
                    </span>
                  </div>
                </div>

                {/* Progress Bar & Tolerance */}
                <div className="space-y-1">
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden border border-slate-200">
                    <div 
                      className={`h-full transition-all duration-500 ${
                        stat.progressPercent >= 100 
                          ? 'bg-emerald-500' 
                          : 'bg-gradient-to-r from-blue-500 to-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, stat.progressPercent)}%` }}
                    />
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                    <span>Port: {stat.lc.borderLandPort || 'Burimari'}</span>
                    <div className="flex items-center gap-1">
                      <span>Tolerance: {stat.allowedTolerancePercent}%</span>
                      {isAdmin && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditToleranceTargetLc(stat.lc);
                            setToleranceInput(stat.allowedTolerancePercent);
                            setShowEditToleranceModal(true);
                          }}
                          className="text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
                          title="Edit Tolerance"
                        >
                          <Edit3 className="w-2.5 h-2.5 inline" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions & Short Receiving (Requirement 7) */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (onSelectLc) onSelectLc(stat.lc);
                        setFilterLcId(stat.lc.id);
                      }}
                      className="text-xs text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <span>Challans</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>

                    {/* Admin Short Receiving Action */}
                    {isAdmin && stat.totalRecMt < stat.contractedQty && stat.totalRecMt > 0 && !stat.isReceivingCompleted && (
                      <button
                        type="button"
                        onClick={() => {
                          setShortReceivingTargetLc(stat.lc);
                          setShortReceivingReason('');
                          setShowShortReceivingModal(true);
                        }}
                        className="text-[10px] px-2 py-0.5 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded font-bold transition-all cursor-pointer"
                        title="Mark receiving complete on short quantity"
                      >
                        Mark receiving complete
                      </button>
                    )}

                    {isAdmin && stat.isReceivingCompleted && (
                      <button
                        type="button"
                        onClick={() => {
                          const updatedLc: LetterOfCredit = {
                            ...stat.lc,
                            isReceivingCompleted: false,
                            receivingCompletedReason: undefined
                          };
                          const bill = computeLcBill(updatedLc);
                          const synchronizedBatches = ensureRateBatchesForBillableQty(updatedLc, bill.billableQty);
                          const progress = computeLCProgressAndStatus({
                            ...updatedLc,
                            rateBatches: synchronizedBatches
                          });
                          const finalLc: LetterOfCredit = {
                            ...updatedLc,
                            rateBatches: synchronizedBatches,
                            status: progress.computedStatus
                          };
                          if (onUpdateLc) onUpdateLc(finalLc);
                          triggerToast(`✓ LC ${finalLc.lcNumber}: Receiving re-opened.`);
                        }}
                        className="text-[10px] text-amber-700 hover:underline font-bold cursor-pointer"
                      >
                        Reopen Receiving
                      </button>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      resetReceivingForm();
                      setTargetLcId(stat.lc.id);
                      if (stat.lc.borderLandPort) {
                        setBorderLandPort(stat.lc.borderLandPort.includes('Port') ? stat.lc.borderLandPort : `${stat.lc.borderLandPort} Land Port`);
                      }
                      setShowAddReceivingModal(true);
                    }}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-2xs"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ Receive</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filter and Search Bar for Daily Receiving Logs */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Filter by LC */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <Ship className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <select
                value={filterLcId}
                onChange={(e) => setFilterLcId(e.target.value)}
                className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none cursor-pointer"
              >
                <option value="all">All Active LCs</option>
                {lcs.map(l => (
                  <option key={l.id} value={l.id}>
                    {l.lcNumber} - {l.supplierName} ({l.borderLandPort || 'Burimari'})
                  </option>
                ))}
              </select>
            </div>

            {/* Filter by Border Port */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <select
                value={filterPort}
                onChange={(e) => setFilterPort(e.target.value)}
                className="bg-transparent text-xs font-medium text-slate-800 focus:outline-none cursor-pointer"
              >
                <option value="all">All Borders</option>
                <option value="Burimari">Burimari Land Port</option>
                <option value="Sonahat">Sonahat Land Port</option>
                <option value="Hili">Hili Land Port</option>
                <option value="Tamabil">Tamabil Land Port</option>
                <option value="Benapole">Benapole Land Port</option>
                <option value="Bhomra">Bhomra Land Port</option>
              </select>
            </div>

            {/* Filter by Date */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <Calendar className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="bg-transparent text-xs font-mono font-medium text-slate-800 focus:outline-none cursor-pointer"
              />
              {dateFilter && (
                <button
                  type="button"
                  onClick={() => setDateFilter('')}
                  className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                  title="Clear Date"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search truck #, slip, challan..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white transition-all font-medium"
            />
          </div>
        </div>
      </div>

      {/* Main Table: Daily Border Receiving & Stock Entries */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <ArrowDownToLine className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900">
              Daily Border Stock In Logs
            </h2>
            <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
              {filteredReceivings.length} Records
            </span>
          </div>

          <div className="text-xs text-slate-500 font-mono">
            Filtered Total: <strong>{filteredReceivings.reduce((sum, r) => sum + (r.netWeightMt || 0), 0).toFixed(2)} MT</strong> | Expenses: <strong>৳{filteredReceivings.reduce((sum, r) => sum + (r.dailyExpenses?.totalDailyExpense || 0), 0).toLocaleString()}</strong>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 text-slate-600 font-bold border-b border-slate-200 uppercase text-[10px] tracking-wider font-mono">
                <th className="py-3 px-3.5">Challan No & Date</th>
                <th className="py-3 px-3">LC Number & Supplier</th>
                <th className="py-3 px-3">Border Port & Yard</th>
                <th className="py-3 px-3">Truck No & Slip</th>
                <th className="py-3 px-3 text-right">Received Net Weight (MT)</th>
                <th className="py-3 px-3.5">Daily Landed Expenses</th>
                <th className="py-3 px-3 text-center">Stock Status</th>
                <th className="py-3 px-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredReceivings.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <ArrowDownToLine className="w-10 h-10 mx-auto text-slate-300 mb-2 opacity-50" />
                    <p className="font-bold text-slate-600">No receiving records found</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Click "+ Receive Product & Stock In" above to record today's challans.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredReceivings.map((rec) => {
                  const dailyExp = rec.dailyExpenses;
                  const expSum = dailyExp?.totalDailyExpense || 0;
                  const perTonExp = rec.netWeightMt > 0 ? Math.round(expSum / rec.netWeightMt) : 0;

                  return (
                    <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* GRN & Date */}
                      <td className="py-3 px-3.5">
                        <span className="font-mono font-bold text-blue-900 block text-xs">
                          {rec.grnNo}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono flex items-center gap-1 mt-0.5">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          {rec.date} {rec.time ? `• ${rec.time}` : ''}
                        </span>
                      </td>

                      {/* LC & Supplier */}
                      <td className="py-3 px-3">
                        <span className="font-mono font-bold text-slate-900 block">
                          {rec.lcNumber || 'N/A'}
                        </span>
                        <span className="text-[11px] text-slate-500 truncate max-w-[170px] block" title={rec.supplierName}>
                          {rec.supplierName}
                        </span>
                        <span className="text-[10px] text-indigo-700 font-medium block truncate max-w-[170px]">
                          {rec.itemName}
                        </span>
                      </td>

                      {/* Border & Destination Yard */}
                      <td className="py-3 px-3">
                        <span className="font-semibold text-slate-800 flex items-center gap-1 text-[11px]">
                          <MapPin className="w-3 h-3 text-emerald-600 shrink-0" />
                          {rec.portOrBorder}
                        </span>
                        <span className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <WarehouseIcon className="w-3 h-3 text-slate-400 shrink-0" />
                          {rec.warehouseName}
                        </span>
                      </td>

                      {/* Truck & Slip */}
                      <td className="py-3 px-3 font-mono">
                        <span className="font-bold text-slate-900 block text-[11px] flex items-center gap-1">
                          <Truck className="w-3 h-3 text-indigo-600" />
                          {rec.vehicleNo}
                        </span>
                        {rec.weighbridgeSlipNo ? (
                          <span className="text-[10px] text-slate-500 block">
                            Slip: {rec.weighbridgeSlipNo}
                          </span>
                        ) : null}
                        {rec.driverName && (
                          <span className="text-[10px] text-slate-400 block truncate max-w-[130px]">
                            {rec.driverName}
                          </span>
                        )}
                      </td>

                      {/* Received Net Tonnage */}
                      <td className="py-3 px-3 text-right font-mono">
                        <span className="text-sm font-black text-emerald-950 block">
                          {rec.netWeightMt} {rec.uom || 'MT'}
                        </span>
                        <span className="text-[10px] text-slate-400 block">
                          ≈ {rec.cftEquivalent ? rec.cftEquivalent.toLocaleString() : Math.round(rec.netWeightMt * 20.2)} CFT
                        </span>
                        {rec.truckCount && rec.truckCount > 1 && (
                          <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-sans inline-block mt-0.5">
                            {rec.truckCount} Trucks
                          </span>
                        )}
                      </td>

                      {/* Daily Associated Expenses */}
                      <td className="py-3 px-3.5">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-indigo-950 text-xs">
                              ৳{expSum.toLocaleString()}
                            </span>
                            <span className="text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.2 rounded font-mono">
                              @ ৳{perTonExp}/MT
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-500 flex flex-wrap gap-1 font-mono">
                            {dailyExp?.customsTaxDuty ? <span>Tax: ৳{dailyExp.customsTaxDuty.toLocaleString()}</span> : null}
                            {dailyExp?.portHandlingBill ? <span>• Port: ৳{dailyExp.portHandlingBill.toLocaleString()}</span> : null}
                            {dailyExp?.laborLoadingUnloading ? <span>• Labor: ৳{dailyExp.laborLoadingUnloading.toLocaleString()}</span> : null}
                          </div>
                        </div>
                      </td>

                      {/* Stock Status */}
                      <td className="py-3 px-3 text-center">
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          In Stock
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3.5 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedReceivingForView(rec);
                            setShowExpenseDetailsModal(true);
                          }}
                          className="p-1.5 text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 rounded-lg cursor-pointer"
                          title="View daily expenses breakdown"
                        >
                          <Receipt className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setSelectedReceivingForView(rec);
                            setShowPrintSlipModal(true);
                          }}
                          className="p-1.5 text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-lg cursor-pointer"
                          title="Print gate pass and receiving challan"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteReceiving(rec)}
                          className="p-1.5 text-rose-500 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg cursor-pointer"
                          title="Delete and rollback challan"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: NEW DAILY LC PRODUCT RECEIVING & STOCK ENTRY FORM                */}
      {/* ========================================================================= */}
      {showAddReceivingModal && (
        <ModalWrapper
          isOpen={showAddReceivingModal}
          onClose={handleCloseReceivingModal}
          isDirty={isReceivingFormDirty}
          isSaving={isSavingReceiving}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain"
        >
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-6 animate-in fade-in zoom-in-95 space-y-4 max-h-[92vh] overflow-y-auto overscroll-contain my-auto"
          >
            {/* Modal Header */}
            <div className="sticky top-0 z-20 bg-white -mx-6 -mt-6 px-6 pt-5 pb-3 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
                  <ArrowDownToLine className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">New LC Product Receiving & Stock Entry</h3>
                  <p className="text-[11px] text-slate-500">Border Weighbridge Arrival & Stock In</p>
                </div>
              </div>
              <button
                type="button"
                disabled={isSavingReceiving}
                data-modal-close="true"
                onClick={handleCloseReceivingModal}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer disabled:opacity-50 shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form 
              onSubmit={handleSaveReceiving} 
              autoComplete="off"
              onKeyDown={(e) => { if (e.key === 'Enter' && (isSavingReceiving || isSavingReceivingRef.current)) e.preventDefault(); }}
              className="space-y-4 text-xs"
            >
              {/* 1. LC Selection Banner with Live Tonnage Balance */}
              <div className="p-3.5 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="font-bold text-blue-950 flex items-center gap-1.5">
                    <Ship className="w-4 h-4 text-blue-600" />
                    <span>Select LC: <span className="text-rose-500">*</span></span>
                  </label>
                  <select
                    value={targetLcId}
                    onChange={(e) => handleTargetLcChange(e.target.value)}
                    required
                    className="border border-blue-300 rounded-xl px-3 py-1.5 font-bold text-xs bg-white text-blue-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="">Select LC...</option>
                    {lcs.map(l => (
                      <option key={l.id} value={l.id}>
                        {l.lcNumber} - {l.supplierName} ({l.borderLandPort || 'Burimari'})
                      </option>
                    ))}
                  </select>
                </div>

                {activeFormLc && (() => {
                  const contracted = activeFormLc.quantity || 1000;
                  const alreadyRec = activeFormLc.receivedQuantity || 0;
                  const rem = Math.max(0, contracted - alreadyRec);
                  return (
                    <div className="grid grid-cols-3 gap-2 pt-1 font-mono text-[11px]">
                      <div className="bg-white/80 p-2 rounded-xl border border-blue-100">
                        <span className="text-[10px] text-slate-500 block font-sans">Contracted:</span>
                        <span className="font-bold text-slate-900">{contracted.toLocaleString()} {activeFormLc.uom || 'MT'}</span>
                      </div>
                      <div className="bg-white/80 p-2 rounded-xl border border-blue-100">
                        <span className="text-[10px] text-emerald-600 block font-sans">Already Received:</span>
                        <span className="font-bold text-emerald-800">{alreadyRec.toLocaleString()} MT</span>
                      </div>
                      <div className="bg-white/80 p-2 rounded-xl border border-blue-100">
                        <span className="text-[10px] text-amber-600 block font-sans">Remaining:</span>
                        <span className="font-bold text-amber-900">{rem.toLocaleString()} MT</span>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* 2. Date & Border Land Port */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Receiving Date <span className="text-rose-500">*</span></label>
                  <input
                    type="date"
                    value={receiveDate}
                    onChange={(e) => setReceiveDate(e.target.value)}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Border Land Port <span className="text-rose-500">*</span></label>
                  <select
                    value={borderLandPort}
                    onChange={(e) => setBorderLandPort(e.target.value)}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                  >
                    <option value="">Select Border Land Port...</option>
                    <option value="Burimari Land Port">Burimari Land Port</option>
                    <option value="Sonahat Land Port">Sonahat Land Port</option>
                    <option value="Hili Land Port">Hili Land Port</option>
                    <option value="Tamabil Land Port">Tamabil Land Port</option>
                    <option value="Benapole Land Port">Benapole Land Port</option>
                    <option value="Bhomra Land Port">Bhomra Land Port</option>
                  </select>
                </div>
              </div>

              {/* 3. Transport & Weight Entry (Single Truck vs Multiple Trucks) */}
              <div className="p-4 bg-slate-50/80 border border-slate-200 rounded-2xl space-y-3.5">
                {/* Switcher: Single Truck vs Multiple Trucks */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span className="font-bold text-slate-900">Consignment Type / Truck Count</span>
                  </div>

                  <div className="inline-flex items-center p-1 bg-white border border-slate-200 rounded-xl gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setTruckCount(1);
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        !isMultipleTrucks
                          ? 'bg-indigo-600 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <span>Single Truck</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!isMultipleTrucks) {
                          setTruckCount(2);
                        }
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        isMultipleTrucks
                          ? 'bg-indigo-600 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <span>Multiple Trucks</span>
                    </button>
                  </div>
                </div>

                {/* MULTIPLE TRUCKS: Only Total Trucks & Total Weight in Tons */}
                {isMultipleTrucks ? (
                  <div className="space-y-3">
                    <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl text-indigo-900 text-xs flex items-center gap-2">
                      <Info className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span>
                        For multiple trucks, enter the total number of trucks and total net weight received in metric tons.
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Total Truck Count <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="number"
                          min={2}
                          value={truckCount}
                          onChange={(e) => setTruckCount(e.target.value === '' ? '' : Math.max(1, Number(e.target.value)))}
                          placeholder="e.g. 5"
                          required
                          className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-emerald-800 mb-1">
                          Total Net Weight (MT) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          value={directNetWeightMt}
                          onChange={(e) => setDirectNetWeightMt(e.target.value === '' ? '' : Number(e.target.value))}
                          placeholder="e.g. 150.00"
                          required
                          className="w-full border border-emerald-400 rounded-xl p-2.5 font-mono font-black text-lg text-emerald-950 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                    </div>

                    {netReceivedMt > 0 && (
                      <div className="flex justify-between items-center text-[11px] text-slate-600 bg-white p-2.5 rounded-xl border border-slate-200 font-mono">
                        <span>CFT Equivalent (≈): <strong>{cftEquivalent.toLocaleString()} CFT</strong> (@ 20.2 CFT/MT)</span>
                        <span className="text-emerald-700 font-bold">Stock In: {netReceivedMt} MT</span>
                      </div>
                    )}
                  </div>
                ) : (
                  /* SINGLE TRUCK: Truck Number, Driver Name, Scale Slip, Weight (NO Driver Phone) */
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Truck / Vehicle No
                        </label>
                        <input
                          type="text"
                          value={truckNo}
                          onChange={(e) => setTruckNo(e.target.value)}
                          placeholder="e.g. BP-2-A-9102"
                          className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-medium text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Driver Name
                        </label>
                        <input
                          type="text"
                          value={driverName}
                          onChange={(e) => setDriverName(e.target.value)}
                          placeholder="e.g. Tenzing Dorji"
                          className="w-full border border-slate-300 rounded-xl p-2.5 font-medium text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Scale Slip / Challan No
                        </label>
                        <input
                          type="text"
                          value={scaleSlipNo}
                          onChange={(e) => setScaleSlipNo(e.target.value)}
                          placeholder="e.g. WB-BUR-9912"
                          className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-medium text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white"
                        />
                      </div>
                    </div>

                    {/* Weight Measurement */}
                    <div className="pt-2 border-t border-slate-200 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                          <Scale className="w-3.5 h-3.5 text-blue-600" />
                          <span>Weight Measurement Mode</span>
                        </span>
                        <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 text-[11px]">
                          <button
                            type="button"
                            onClick={() => setCalcMode('weighbridge')}
                            className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                              calcMode === 'weighbridge' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            Gross - Tare
                          </button>
                          <button
                            type="button"
                            onClick={() => setCalcMode('direct_net')}
                            className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                              calcMode === 'direct_net' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            Direct Net
                          </button>
                        </div>
                      </div>

                      {calcMode === 'weighbridge' ? (
                        <div className="grid grid-cols-3 gap-3">
                          <div>
                            <label className="block text-slate-600 text-[11px] font-bold mb-1">Gross Weight (Loaded Truck MT)</label>
                            <input
                              type="number"
                              step="0.01"
                              value={grossWeightMt}
                              onChange={(e) => setGrossWeightMt(e.target.value === '' ? '' : Number(e.target.value))}
                              placeholder="0.00"
                              className="w-full border border-slate-300 rounded-xl p-2 font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-600 text-[11px] font-bold mb-1">Tare Weight (Empty Truck MT)</label>
                            <input
                              type="number"
                              step="0.01"
                              value={tareWeightMt}
                              onChange={(e) => setTareWeightMt(e.target.value === '' ? '' : Number(e.target.value))}
                              placeholder="0.00"
                              className="w-full border border-slate-300 rounded-xl p-2 font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                            />
                          </div>
                          <div>
                            <label className="block text-emerald-800 text-[11px] font-black mb-1">Received Net Weight (MT)</label>
                            <div className="w-full p-2 bg-emerald-100/70 border border-emerald-300 rounded-xl font-mono font-black text-emerald-950 text-base text-center">
                              {netReceivedMt > 0 ? `${netReceivedMt} MT` : '0.00 MT'}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <label className="block text-slate-700 font-bold mb-1">Received Net Weight (MT) <span className="text-rose-500">*</span></label>
                          <input
                            type="number"
                            step="0.01"
                            value={directNetWeightMt}
                            onChange={(e) => setDirectNetWeightMt(e.target.value === '' ? '' : Number(e.target.value))}
                            placeholder="0.00"
                            className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-black text-lg text-emerald-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                      )}

                      {netReceivedMt > 0 && (
                        <div className="flex justify-between text-[11px] text-slate-500 font-mono pt-1">
                          <span>CFT Equivalent (≈): <strong>{cftEquivalent.toLocaleString()} CFT</strong> (@ 20.2 CFT/MT)</span>
                          <span>Stock In: <strong>{netReceivedMt} MT</strong></span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* 4. Destination Warehouse Yard & Remarks */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Destination Stock Yard / Depot <span className="text-rose-500">*</span></label>
                  <select
                    value={destinationYard}
                    onChange={(e) => {
                      setDestinationYard(e.target.value);
                      if (e.target.value.includes('Burimari')) setYardId('wh-bur');
                      else if (e.target.value.includes('Sonahat')) setYardId('wh-snt');
                      else if (e.target.value) setYardId('wh-crush');
                      else setYardId('');
                    }}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                  >
                    <option value="">Select Destination Yard...</option>
                    <option value="Burimari Central Yard - 1">Burimari Central Yard - 1</option>
                    <option value="Sonahat Crushing Point Depot">Sonahat Crushing Point Depot</option>
                    <option value="Lalmonirhat Buffer Yard">Lalmonirhat Buffer Yard</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Inspection Notes / Remarks</label>
                  <input
                    type="text"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Quality, size, or consignment notes..."
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-medium text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                  />
                </div>
              </div>

              {/* Over-receipt & Tolerance Banner (Requirement 4) */}
              {(() => {
                const activeLcContractQty = Number(activeFormLc?.quantity) || 0;
                const activeLcReceivedSoFar = (activeFormLc?.receivings || [])
                  .filter(r => (r as any).status !== 'Voided')
                  .reduce((acc, r) => acc + (Number(r.receivedQty || r.netWeightMt) || 0), 0);
                const projectedTotal = activeLcReceivedSoFar + netReceivedMt;
                const excessQty = Math.max(0, projectedTotal - activeLcContractQty);
                const excessPct = activeLcContractQty > 0 ? (excessQty / activeLcContractQty) * 100 : 0;
                const tolerancePct = activeFormLc?.allowedTolerancePercent ?? 5;
                const toleranceMaxQty = activeLcContractQty * (1 + tolerancePct / 100);
                const isOverContract = projectedTotal > activeLcContractQty;
                const isOverTolerance = projectedTotal > toleranceMaxQty;

                if (!isOverContract) return null;

                return (
                  <div className="space-y-3 pt-1">
                    {/* Amber Banner per Requirement 4 */}
                    <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs space-y-1">
                      <div className="flex items-center gap-2 font-bold text-amber-950">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>Over-Receipt Detected</span>
                      </div>
                      <p className="text-[11px] leading-relaxed">
                        Contract <strong>{activeLcContractQty.toLocaleString()} MT</strong>, already received <strong>{activeLcReceivedSoFar.toLocaleString()} MT</strong>, this entry makes <strong>{projectedTotal.toLocaleString()} MT</strong>: <strong className="text-amber-950 font-mono">extra +{excessQty.toLocaleString()} MT (+{excessPct.toFixed(1)}%)</strong>. Extra will be added to the bill.
                      </p>
                    </div>

                    {/* Tolerance Validation (Requirement 4) */}
                    {isOverTolerance && (
                      isAdmin ? (
                        <div className="p-3 bg-amber-100/70 border border-amber-400 rounded-xl space-y-2 text-xs">
                          <div className="flex items-center gap-1.5 font-bold text-amber-950">
                            <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
                            <span>Allowed tolerance ({tolerancePct}%) exceeded — Admin approval required:</span>
                          </div>
                          <p className="text-[11px] text-amber-800">
                            Contract tolerance limit ({toleranceMaxQty.toFixed(1)} MT) exceeded. Enter reason for admin approval:
                          </p>
                          <input
                            type="text"
                            required
                            value={adminApprovalReason}
                            onChange={(e) => setAdminApprovalReason(e.target.value)}
                            placeholder="Enter approval reason for over-receipt..."
                            className="w-full bg-white border border-amber-400 rounded-lg p-2 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-600"
                          />
                        </div>
                      ) : (
                        <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl space-y-1 text-xs text-rose-900">
                          <div className="flex items-center gap-1.5 font-bold">
                            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                            <span>Admin Approval Required</span>
                          </div>
                          <p className="text-[11px] text-rose-700">
                            Saving this entry makes total receiving {projectedTotal.toLocaleString()} MT, exceeding the allowed contract tolerance of {tolerancePct}% ({toleranceMaxQty.toFixed(1)} MT). Admin approval is required.
                          </p>
                        </div>
                      )
                    )}
                  </div>
                );
              })()}

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  disabled={isSavingReceiving}
                  data-modal-close="true"
                  onClick={handleCloseReceivingModal}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                {(() => {
                  const activeLcContractQty = Number(activeFormLc?.quantity) || 0;
                  const activeLcReceivedSoFar = (activeFormLc?.receivings || [])
                    .filter(r => (r as any).status !== 'Voided')
                    .reduce((acc, r) => acc + (Number(r.receivedQty || r.netWeightMt) || 0), 0);
                  const projectedTotal = activeLcReceivedSoFar + netReceivedMt;
                  const tolerancePct = activeFormLc?.allowedTolerancePercent ?? 5;
                  const toleranceMaxQty = activeLcContractQty * (1 + tolerancePct / 100);
                  const isOverTolerance = projectedTotal > toleranceMaxQty;
                  const isDisabled = (isOverTolerance && !isAdmin) || (isOverTolerance && isAdmin && !adminApprovalReason.trim());

                  return (
                    <button
                      type="submit"
                      disabled={isDisabled || isSavingReceiving}
                      className={`px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all shadow-2xs flex items-center gap-2 ${
                        isDisabled || isSavingReceiving ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
                      }`}
                      title={isDisabled ? (isOverTolerance && !isAdmin ? 'Admin approval required' : 'Enter approval reason') : undefined}
                    >
                      {isSavingReceiving ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Saving Receiving...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Confirm Receiving & Stock Entry</span>
                        </>
                      )}
                    </button>
                  );
                })()}
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: VIEW DAILY EXPENSE BREAKDOWN DETAILS                             */}
      {/* ========================================================================= */}
      {showExpenseDetailsModal && selectedReceivingForView && (
        <ModalWrapper
          isOpen={showExpenseDetailsModal && Boolean(selectedReceivingForView)}
          onClose={() => setShowExpenseDetailsModal(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain"
        >
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-indigo-600" />
                <h3 className="font-black text-slate-900 text-sm">Daily Import Expense Breakdown</h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setShowExpenseDetailsModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans">Challan No:</span>
                  <span className="font-bold text-slate-900">{selectedReceivingForView.grnNo}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans">LC Number:</span>
                  <span className="font-bold text-blue-900">{selectedReceivingForView.lcNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans">Received Weight:</span>
                  <span className="font-bold text-emerald-800">{selectedReceivingForView.netWeightMt} MT</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans">Date:</span>
                  <span className="text-slate-800">{selectedReceivingForView.date}</span>
                </div>
              </div>

              {/* Itemized Table */}
              <div className="space-y-2 border border-slate-200 rounded-xl p-3 bg-white">
                <h4 className="font-bold text-slate-800 text-[11px] pb-1 border-b border-slate-100">
                  Expense Breakdown for Received Tonnage
                </h4>
                {selectedReceivingForView.dailyExpenses ? (
                  <div className="space-y-1.5 font-mono text-[11px]">
                    <div className="flex justify-between text-slate-700">
                      <span className="font-sans">1. Customs Tax & Duty:</span>
                      <span className="font-bold">৳{selectedReceivingForView.dailyExpenses.customsTaxDuty.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span className="font-sans">2. Port Handling & Port Bill:</span>
                      <span className="font-bold">৳{selectedReceivingForView.dailyExpenses.portHandlingBill.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span className="font-sans">3. Loading, Unloading & Labor:</span>
                      <span className="font-bold">৳{selectedReceivingForView.dailyExpenses.laborLoadingUnloading.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span className="font-sans">4. Scale Weighbridge Slip Fee:</span>
                      <span className="font-bold">৳{selectedReceivingForView.dailyExpenses.weighbridgeScaleFee.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span className="font-sans">5. C&F Agent Clearing Fee:</span>
                      <span className="font-bold">৳{selectedReceivingForView.dailyExpenses.cfAgentClearing.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span className="font-sans">6. Local Transport & Misc:</span>
                      <span className="font-bold">৳{selectedReceivingForView.dailyExpenses.localCarriageMisc.toLocaleString()}</span>
                    </div>

                    <div className="flex justify-between text-indigo-950 font-black pt-2 border-t border-slate-200 text-xs">
                      <span className="font-sans">Total Daily Expense:</span>
                      <span>৳{selectedReceivingForView.dailyExpenses.totalDailyExpense.toLocaleString()}</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-slate-400 italic">No detailed expense log found.</p>
                )}
              </div>

              <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl flex items-center justify-between font-mono text-[11px]">
                <span className="text-indigo-900 font-sans font-bold">Landed Cost per Ton:</span>
                <span className="font-black text-indigo-950">
                  ৳{selectedReceivingForView.netWeightMt > 0 && selectedReceivingForView.dailyExpenses ? Math.round(selectedReceivingForView.dailyExpenses.totalDailyExpense / selectedReceivingForView.netWeightMt) : 0} / MT
                </span>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={() => setShowExpenseDetailsModal(false)}
                  className="px-4 py-1.5 bg-slate-900 text-white rounded-xl font-bold cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: PRINTABLE BORDER GOODS RECEIVING CHALLAN / GATE PASS            */}
      {/* ========================================================================= */}
      {showPrintSlipModal && selectedReceivingForView && (
        <ModalWrapper
          isOpen={showPrintSlipModal && Boolean(selectedReceivingForView)}
          onClose={() => setShowPrintSlipModal(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain"
        >
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-xl w-full p-6 animate-in fade-in zoom-in-95 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-blue-600" />
                <h3 className="font-black text-slate-900 text-sm">Border Goods Receiving Challan & Gate Pass</h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setShowPrintSlipModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Print Document Paper */}
            <div className="p-6 border border-slate-300 rounded-2xl bg-white space-y-4 text-xs font-sans text-slate-900 print:border-none">
              <div className="text-center pb-3 border-b border-slate-300">
                <h2 className="text-lg font-black text-slate-950 uppercase tracking-tight">
                  BORDER GOODS RECEIVING CHALLAN & WEIGHBRIDGE SLIP
                </h2>
                <p className="text-[11px] text-slate-600">Cross-Border Land Port Inward Material Gate Pass</p>
                <div className="flex justify-center gap-4 text-xs font-mono mt-1 text-slate-600">
                  <span>GRN: <strong>{selectedReceivingForView.grnNo}</strong></span>
                  <span>DATE: <strong>{selectedReceivingForView.date}</strong></span>
                  <span>PORT: <strong>{selectedReceivingForView.portOrBorder}</strong></span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pb-3 border-b border-slate-200">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Letter of Credit (LC)</span>
                  <p className="font-mono font-bold text-blue-900">{selectedReceivingForView.lcNumber}</p>
                  <p className="text-slate-600">Supplier: {selectedReceivingForView.supplierName}</p>
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Receiving Stock Yard</span>
                  <p className="font-bold text-slate-900">{selectedReceivingForView.warehouseName}</p>
                  <p className="text-slate-600">In-Charge: {selectedReceivingForView.receivedBy}</p>
                </div>
              </div>

              {/* Weight Details */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 text-xs block">Weighbridge & Truck Details</span>
                <div className="grid grid-cols-3 gap-2 font-mono text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Vehicle No:</span>
                    <span className="font-bold text-slate-900">{selectedReceivingForView.vehicleNo}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Scale Slip No:</span>
                    <span className="font-bold text-slate-900">{selectedReceivingForView.weighbridgeSlipNo || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Received Net Weight:</span>
                    <span className="font-black text-emerald-800 text-sm">{selectedReceivingForView.netWeightMt} MT</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 font-mono text-[10px] text-slate-600 pt-1 border-t border-slate-200">
                  <span>Gross Weight: {selectedReceivingForView.grossWeightMt} MT</span>
                  <span>Tare Weight: {selectedReceivingForView.tareWeightMt} MT</span>
                  <span>CFT: ≈ {selectedReceivingForView.cftEquivalent || Math.round(selectedReceivingForView.netWeightMt * 20.2)} CFT</span>
                </div>
              </div>

              {/* Associated Expenses */}
              {selectedReceivingForView.dailyExpenses && (
                <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-200 text-[11px] font-mono space-y-1">
                  <div className="flex justify-between font-bold text-amber-950 font-sans">
                    <span>Total Border Expense for this Tonnage:</span>
                    <span>৳{selectedReceivingForView.dailyExpenses.totalDailyExpense.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 text-[10px]">
                    <span>Tax & Duty: ৳{selectedReceivingForView.dailyExpenses.customsTaxDuty.toLocaleString()} | Port Bill: ৳{selectedReceivingForView.dailyExpenses.portHandlingBill.toLocaleString()}</span>
                    <span>Labor: ৳{selectedReceivingForView.dailyExpenses.laborLoadingUnloading.toLocaleString()}</span>
                  </div>
                </div>
              )}

              {/* Signatures */}
              <div className="pt-8 grid grid-cols-3 gap-4 text-center text-[10px] text-slate-500 font-mono">
                <div className="border-t border-slate-300 pt-1">Driver Signature</div>
                <div className="border-t border-slate-300 pt-1">Scale Operator Stamp</div>
                <div className="border-t border-slate-300 pt-1 font-bold text-slate-800">Yard In-Charge / Receiver</div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setShowPrintSlipModal(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold hover:bg-slate-50 cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-2xs flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Challan</span>
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: SHORT RECEIVING COMPLETION (Admin Only - Requirement 7)          */}
      {/* ========================================================================= */}
      {showShortReceivingModal && shortReceivingTargetLc && (
        <ModalWrapper
          isOpen={showShortReceivingModal && Boolean(shortReceivingTargetLc)}
          onClose={handleCloseShortReceivingModal}
          isDirty={shortReceivingReason.trim() !== ''}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-purple-600" />
                <h3 className="font-bold text-slate-900 text-sm">Mark Receiving Complete (Short Quantity)</h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={handleCloseShortReceivingModal}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600 leading-relaxed">
                LC <strong>{shortReceivingTargetLc.lcNumber}</strong> contracted quantity was <strong>{(shortReceivingTargetLc.quantity || 1000).toLocaleString()} MT</strong>, but received quantity to date is <strong>{((shortReceivingTargetLc.receivings || []).reduce((sum, r) => sum + (Number(r.receivedQty || r.netWeightMt) || 0), 0)).toLocaleString()} MT</strong>.
              </p>
              <div className="p-3 bg-purple-50 text-purple-900 rounded-xl border border-purple-200 leading-relaxed">
                Finalizing receiving will base LC billing on this received quantity and allow closing the LC.
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Reason for Completion <span className="text-rose-500">*</span></label>
                <textarea
                  required
                  rows={3}
                  value={shortReceivingReason}
                  onChange={(e) => setShortReceivingReason(e.target.value)}
                  placeholder="e.g. Exporter quota completed / supply finished..."
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-slate-900 text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                data-modal-close="true"
                onClick={handleCloseShortReceivingModal}
                className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 font-bold hover:bg-slate-50 cursor-pointer text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!shortReceivingReason.trim()}
                onClick={() => {
                  const updatedLc: LetterOfCredit = {
                    ...shortReceivingTargetLc,
                    isReceivingCompleted: true,
                    receivingCompletedReason: shortReceivingReason.trim(),
                    receivingCompletedBy: currentUser?.name || 'Admin',
                    receivingCompletedAt: new Date().toISOString(),
                    auditLogs: [
                      ...(shortReceivingTargetLc.auditLogs || []),
                      {
                        id: `audit-${Date.now()}`,
                        timestamp: new Date().toISOString(),
                        user: currentUser?.name || 'Admin',
                        action: 'Mark Receiving Complete',
                        details: `Receiving marked complete with reason: ${shortReceivingReason.trim()}`
                      }
                    ]
                  };
                  const bill = computeLcBill(updatedLc);
                  const synchronizedBatches = ensureRateBatchesForBillableQty(updatedLc, bill.billableQty);
                  const progress = computeLCProgressAndStatus({
                    ...updatedLc,
                    rateBatches: synchronizedBatches
                  });
                  const finalLc: LetterOfCredit = {
                    ...updatedLc,
                    rateBatches: synchronizedBatches,
                    status: progress.computedStatus
                  };
                  if (onUpdateLc) onUpdateLc(finalLc);
                  handleCloseShortReceivingModal();
                  triggerToast(`✓ LC ${finalLc.lcNumber}: Short receiving marked complete (${bill.billableQty} MT billable)!`);
                }}
                className={`px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold transition-all text-xs cursor-pointer ${
                  !shortReceivingReason.trim() ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                Confirm Completion
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: EDIT ALLOWED TOLERANCE % (Admin Only - Requirement 4)             */}
      {/* ========================================================================= */}
      {showEditToleranceModal && editToleranceTargetLc && (
        <ModalWrapper
          isOpen={showEditToleranceModal && Boolean(editToleranceTargetLc)}
          onClose={handleCloseEditToleranceModal}
          isDirty={toleranceInput !== (editToleranceTargetLc.allowedTolerancePercent ?? 5)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full p-6 animate-in fade-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm">Change Allowed Tolerance %</h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={handleCloseEditToleranceModal}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600">
                Set allowed tolerance percentage for LC <strong>{editToleranceTargetLc.lcNumber}</strong> (Default 5%):
              </p>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Allowed Tolerance (%)</label>
                <input
                  type="number"
                  min={0}
                  max={50}
                  step={0.5}
                  value={toleranceInput}
                  onChange={(e) => setToleranceInput(Math.max(0, Number(e.target.value)))}
                  className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                data-modal-close="true"
                onClick={handleCloseEditToleranceModal}
                className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 font-bold hover:bg-slate-50 cursor-pointer text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  const updatedLc: LetterOfCredit = {
                    ...editToleranceTargetLc,
                    allowedTolerancePercent: toleranceInput,
                    auditLogs: [
                      ...(editToleranceTargetLc.auditLogs || []),
                      {
                        id: `audit-${Date.now()}`,
                        timestamp: new Date().toISOString(),
                        user: currentUser?.name || 'Admin',
                        action: 'Allowed Tolerance % Updated',
                        details: `Tolerance updated to ${toleranceInput}%`
                      }
                    ]
                  };
                  if (onUpdateLc) onUpdateLc(updatedLc);
                  handleCloseEditToleranceModal();
                  triggerToast(`✓ LC ${updatedLc.lcNumber}: Allowed tolerance set to ${toleranceInput}%!`);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-all text-xs cursor-pointer"
              >
                Save Tolerance
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
