import React, { useState, useMemo, useEffect } from 'react';
import { 
  Ship, 
  FileText, 
  Calculator, 
  DollarSign, 
  Anchor, 
  Building, 
  CheckCircle2, 
  Plus, 
  Search, 
  Clock, 
  Layers, 
  ArrowRight, 
  TrendingUp, 
  Percent, 
  Receipt, 
  FileCheck, 
  AlertCircle,
  Bell,
  Coins,
  Zap,
  Landmark,
  MapPin,
  ArrowDownToLine
} from 'lucide-react';
import { MOCK_LCS, MOCK_ITEMS } from '../../data/mockErpData';
import { LetterOfCredit, LCStatus, LCType } from '../../types/erp';
import { DocumentaryCreditTracker } from './DocumentaryCreditTracker';
import { LCExpiryAlertBanner } from './LCExpiryAlertBanner';
import { LCExpiryAlertModal } from './LCExpiryAlertModal';
import { LCExporterBillsView } from '../purchase/LCExporterBillsView';
import { LCProductReceivingSector } from './LCProductReceivingSector';
import { LCStatusSummaryDashboard } from './LCStatusSummaryDashboard';
import { generateLCExpiryAlerts, LCExpiryAlert } from '../../utils/lcAlertUtils';
import { ModalWrapper } from '../common/ModalWrapper';

export const LCModule: React.FC = () => {
  const [lcs, setLcs] = useState<LetterOfCredit[]>(MOCK_LCS);
  const [selectedLc, setSelectedLc] = useState<LetterOfCredit>(MOCK_LCS[0]);
  const [moduleView, setModuleView] = useState<'status_summary' | 'tracker' | 'costing' | 'product_receiving'>('status_summary');
  const [activeTab, setActiveTab] = useState<'details' | 'costing' | 'duties' | 'documents' | 'settlement' | 'dual_pricing' | 'exporter_bills' | 'product_receiving'>('product_receiving');
  const [showNewLcModal, setShowNewLcModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Expiry Alert Engine State
  const [showExpiryModal, setShowExpiryModal] = useState(false);
  const [acknowledgedAlertIds, setAcknowledgedAlertIds] = useState<string[]>([]);

  // Prevent background scroll and cursor freeze when modal is open
  useEffect(() => {
    if (showNewLcModal || showExpiryModal) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow || 'unset';
      };
    }
  }, [showNewLcModal, showExpiryModal]);

  const lcExpiryAlerts = useMemo(() => {
    return generateLCExpiryAlerts(lcs, acknowledgedAlertIds);
  }, [lcs, acknowledgedAlertIds]);

  const criticalAlertsCount = lcExpiryAlerts.filter(a => a.severity === 'critical' || a.severity === 'expired').length;

  const handleAcknowledgeAlert = (alertId: string) => {
    setAcknowledgedAlertIds(prev => [...prev, alertId]);
    triggerToast('✓ Alert acknowledged.');
  };

  const handleApplyAmendment = (lcId: string, newShipmentDate: string, newExpiryDate: string) => {
    setLcs(prevLcs => prevLcs.map(item => {
      if (item.id === lcId) {
        return {
          ...item,
          shipmentExpiryDate: newShipmentDate,
          lcExpiryDate: newExpiryDate,
          status: item.status === 'Discrepant' ? 'Confirmed' : item.status
        };
      }
      return item;
    }));
    triggerToast(`✓ Swift MT707 Amendment applied: Shipment extended to ${newShipmentDate}, LC Expiry extended to ${newExpiryDate}`);
  };

  const handleUpdateFullLc = (updatedLc: LetterOfCredit) => {
    setLcs(prev => prev.map(item => item.id === updatedLc.id ? updatedLc : item));
    setSelectedLc(updatedLc);
    try {
      localStorage.setItem('tradecore_lcs_v1', JSON.stringify(lcs.map(item => item.id === updatedLc.id ? updatedLc : item)));
    } catch (e) {}
    triggerToast(`✓ LC ${updatedLc.lcNumber} updated successfully.`);
  };

  // New LC Form state
  const [newLcNumber, setNewLcNumber] = useState('');
  const [newLcSupplier, setNewLcSupplier] = useState('');
  const [newLcBank, setNewLcBank] = useState('');
  const [newLcOpeningDate, setNewLcOpeningDate] = useState(new Date().toISOString().split('T')[0]);
  const [newLcMaturityDate, setNewLcMaturityDate] = useState('');
  const [newLcStatus, setNewLcStatus] = useState<LCStatus>('' as any);
  const [newLcType, setNewLcType] = useState<LCType>('' as any);
  const [newLcCfr, setNewLcCfr] = useState(0);
  const [newLcMargin, setNewLcMargin] = useState(0);
  const [newLcCommodity, setNewLcCommodity] = useState('');
  const [newLcBorderLandPort, setNewLcBorderLandPort] = useState('');

  // Quantity, Currency, Dual-Pricing states (Bank LC Rate vs Actual Rate & Hundi Gap)
  const [newLcQuantity, setNewLcQuantity] = useState<number>(0);
  const [newLcUom, setNewLcUom] = useState<string>('');
  const [newLcCurrency, setNewLcCurrency] = useState<'USD' | 'INR'>('' as any);
  const [newLcExchangeRate, setNewLcExchangeRate] = useState<number>(0);
  const [newLcOfficialRate, setNewLcOfficialRate] = useState<number>('' as any);
  const [newLcActualRate, setNewLcActualRate] = useState<number>('' as any);

  const resetNewLcForm = () => {
    setNewLcNumber('');
    setNewLcSupplier('');
    setNewLcBank('');
    setNewLcOpeningDate(new Date().toISOString().split('T')[0]);
    setNewLcMaturityDate('');
    setNewLcStatus('' as any);
    setNewLcType('' as any);
    setNewLcCfr(0);
    setNewLcMargin(0);
    setNewLcCommodity('');
    setNewLcBorderLandPort('');
    setNewLcQuantity(0);
    setNewLcUom('');
    setNewLcCurrency('' as any);
    setNewLcExchangeRate(0);
    setNewLcOfficialRate('' as any);
    setNewLcActualRate('' as any);
  };

  const handleCloseNewLcModal = () => {
    resetNewLcForm();
    setShowNewLcModal(false);
  };

  const isNewLcDirty =
    newLcNumber !== '' ||
    newLcSupplier !== '' ||
    newLcBank !== '' ||
    newLcMaturityDate !== '' ||
    Boolean(newLcStatus) ||
    Boolean(newLcType) ||
    newLcMargin !== 0 ||
    newLcCommodity !== '' ||
    newLcBorderLandPort !== '' ||
    newLcQuantity !== 0 ||
    newLcUom !== '' ||
    Boolean(newLcCurrency) ||
    newLcExchangeRate !== 0 ||
    Boolean(newLcOfficialRate) ||
    Boolean(newLcActualRate);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleCreateLC = (e: React.FormEvent) => {
    e.preventDefault();
    const calculatedOfficialTotal = newLcQuantity * newLcOfficialRate;
    const calculatedActualTotal = newLcQuantity * newLcActualRate;
    const diffRate = Math.max(0, newLcActualRate - newLcOfficialRate);
    const calculatedDiffAmount = newLcQuantity * diffRate;
    const calculatedDiffBdt = calculatedDiffAmount * newLcExchangeRate;
    const isIndia = newLcSupplier.includes('India');

    const newRecord: LetterOfCredit = {
      id: `lc-${Date.now()}`,
      lcNumber: newLcNumber,
      bankReference: `EBL/CGP/IMP/2026/0${lcs.length + 90}`,
      issuingBank: newLcBank,
      branch: 'Corporate Principal Branch',
      supplierId: 'supp-201',
      supplierName: newLcSupplier,
      beneficiaryCountry: isIndia ? 'India' : 'Bhutan',
      borderLandPort: newLcBorderLandPort,
      boulderCategory: 'Boulder Stone',
      originQuarryItem: newLcCommodity,
      lcType: newLcType,
      currency: newLcCurrency,
      exchangeRate: newLcExchangeRate,
      quantity: newLcQuantity,
      uom: newLcUom,
      officialLcRate: newLcOfficialRate,
      actualRate: newLcActualRate,
      contractRateUsd: newLcActualRate,
      lcBankRateUsd: newLcOfficialRate,
      rateDifference: diffRate,
      officialLcTotal: calculatedOfficialTotal,
      actualTotalAmount: calculatedActualTotal,
      differentialAmount: calculatedDiffAmount,
      differentialAmountBdt: calculatedDiffBdt,
      differentialSettledAmount: 0,
      differentialSettlementStatus: calculatedDiffAmount > 0 ? 'Unsettled' : 'Fully Settled',
      differentialPayments: [],
      rateBatches: [
        {
          id: `rb-${Date.now()}-1`,
          batchName: 'Lot 1 (Initial Contract)',
          quantity: newLcQuantity,
          uom: newLcUom,
          officialRate: newLcOfficialRate,
          actualRate: newLcActualRate,
          rateDifference: diffRate,
          totalCommercialAmount: calculatedActualTotal,
          totalOfficialAmount: calculatedOfficialTotal,
          differentialAmount: calculatedDiffAmount,
          notes: 'Initial agreed contract rate',
          date: newLcOpeningDate
        }
      ],
      bankSettlements: [],
      hundiPayments: [],
      receivedQtyMt: newLcQuantity,
      totalBillUsd: calculatedActualTotal,
      rateBdt: newLcExchangeRate,
      usdBalance: calculatedDiffAmount,
      bdtBalanceAmount: calculatedDiffBdt,
      fobAmount: calculatedOfficialTotal * 0.95,
      cfrAmount: calculatedOfficialTotal,
      marginDepositPercent: newLcMargin,
      marginAmountLocal: (calculatedOfficialTotal * newLcExchangeRate) * (newLcMargin / 100),
      openingDate: newLcOpeningDate || new Date().toISOString().split('T')[0],
      shipmentExpiryDate: '2026-11-20',
      lcExpiryDate: newLcMaturityDate || '2026-12-15',
      maturityDate: newLcMaturityDate || '2026-12-15',
      piNumber: `PI-${Math.floor(Math.random() * 90000 + 10000)}`,
      boeNumber: 'BOE-CGP-PENDING',
      blNumber: 'BL-MAEU-PENDING',
      portOfLoading: isIndia ? 'Fulbari / Kolkata, India' : 'Phuentsholing / Samtse, Bhutan',
      portOfDischarge: `${newLcBorderLandPort} Land Port, Bangladesh`,
      status: newLcStatus,
      items: [
        {
          itemId: 'item-301',
          itemName: newLcCommodity,
          hsCode: '2517.10.00',
          quantity: newLcQuantity,
          uom: newLcUom,
          unitPriceForeign: newLcOfficialRate,
          totalForeign: calculatedOfficialTotal,
          assessmentValueUnit: newLcOfficialRate * newLcExchangeRate
        }
      ],
      expenses: [
        { id: 'exp-1', expenseType: 'Bank Commission', amountLocal: 65000, paidTo: newLcBank, status: 'Paid' },
        { id: 'exp-2', expenseType: 'Customs Duty (CD+RD+SD+VAT+AT)', amountLocal: (calculatedOfficialTotal * newLcExchangeRate) * 0.28, paidTo: 'Customs House CTG', status: 'Estimated' },
        { id: 'exp-3', expenseType: 'Port Demurrage/Handling', amountLocal: 42000, paidTo: 'Burimari Land Port Authority', status: 'Estimated' },
        { id: 'exp-4', expenseType: 'C&F Agent Fee', amountLocal: 25000, paidTo: 'Karnaphuli C&F', status: 'Estimated' },
        { id: 'exp-5', expenseType: 'Local Freight/Transport', amountLocal: 60000, paidTo: 'Bengal Logistics', status: 'Estimated' }
      ]
    };

    setLcs([newRecord, ...lcs]);
    setSelectedLc(newRecord);
    setShowNewLcModal(false);
    triggerToast(`✓ Letter of Credit ${newRecord.lcNumber} successfully established (${newRecord.status})!`);
  };

  const handleAddLcFromTracker = (data: {
    lcNumber: string;
    issuingBank: string;
    maturityDate: string;
    status: LCStatus;
    supplierName: string;
    lcType: LCType;
    cfrAmount: number;
    commodity: string;
  }) => {
    const newRecord: LetterOfCredit = {
      id: `lc-${Date.now()}`,
      lcNumber: data.lcNumber,
      bankReference: `REF/IMP/2026/0${lcs.length + 90}`,
      issuingBank: data.issuingBank,
      branch: 'Corporate Principal Branch',
      supplierId: 'supp-201',
      supplierName: data.supplierName,
      beneficiaryCountry: 'Overseas',
      lcType: data.lcType,
      currency: 'USD',
      exchangeRate: 118.50,
      fobAmount: data.cfrAmount * 0.95,
      cfrAmount: data.cfrAmount,
      marginDepositPercent: 15,
      marginAmountLocal: (data.cfrAmount * 118.50) * 0.15,
      openingDate: new Date().toISOString().split('T')[0],
      shipmentExpiryDate: '2026-11-20',
      lcExpiryDate: data.maturityDate,
      maturityDate: data.maturityDate,
      piNumber: `PI-${Math.floor(Math.random() * 90000 + 10000)}`,
      boeNumber: 'BOE-PENDING',
      blNumber: 'BL-PENDING',
      portOfLoading: 'Port of Origin',
      portOfDischarge: 'Chittagong Port (CTG), Bangladesh',
      status: data.status,
      items: [
        {
          itemId: 'item-301',
          itemName: data.commodity,
          hsCode: '7208.38.00',
          quantity: Math.max(1, Math.round(data.cfrAmount / 700)),
          uom: 'MT',
          unitPriceForeign: 700,
          totalForeign: data.cfrAmount,
          assessmentValueUnit: 82000
        }
      ],
      expenses: [
        { id: 'exp-1', expenseType: 'Bank Commission', amountLocal: 65000, paidTo: data.issuingBank, status: 'Paid' },
        { id: 'exp-2', expenseType: 'Customs Duty (CD+RD+SD+VAT+AT)', amountLocal: (data.cfrAmount * 118.50) * 0.28, paidTo: 'Customs House CTG', status: 'Estimated' },
        { id: 'exp-3', expenseType: 'Port Demurrage/Handling', amountLocal: 120000, paidTo: 'Chittagong Port Authority', status: 'Estimated' },
        { id: 'exp-4', expenseType: 'C&F Agent Fee', amountLocal: 45000, paidTo: 'C&F Logistics', status: 'Estimated' },
        { id: 'exp-5', expenseType: 'Local Freight/Transport', amountLocal: 90000, paidTo: 'Prime Transport', status: 'Estimated' }
      ]
    };

    setLcs([newRecord, ...lcs]);
    setSelectedLc(newRecord);
    triggerToast(`✓ Documentary Credit ${data.lcNumber} recorded with status "${data.status}"!`);
  };

  const handleUpdateLc = (lcId: string, updatedFields: Partial<LetterOfCredit>) => {
    setLcs(prev => prev.map(item => {
      if (item.id === lcId) {
        const updated = { ...item, ...updatedFields };
        if (selectedLc.id === lcId) {
          setSelectedLc(updated);
        }
        return updated;
      }
      return item;
    }));
    triggerToast(`✓ LC details updated successfully!`);
  };

  const handleSelectLcForCosting = (lc: LetterOfCredit) => {
    setSelectedLc(lc);
    setModuleView('costing');
    triggerToast(`Switched to Landed Cost & Customs Engine for ${lc.lcNumber}`);
  };

  // Landed Cost calculations for selected LC
  const customsDutyBDT = selectedLc.expenses.find(e => e.expenseType.includes('Customs Duty'))?.amountLocal || 5180000;
  const portDemurrageBDT = selectedLc.expenses.find(e => e.expenseType.includes('Port Demurrage'))?.amountLocal || 185000;
  const cfCommissionBDT = selectedLc.expenses.find(e => e.expenseType.includes('C&F Agent'))?.amountLocal || 120000;
  const localCarriageBDT = selectedLc.expenses.find(e => e.expenseType.includes('Local Freight'))?.amountLocal || 180000;
  const bankCommissionBDT = selectedLc.expenses.find(e => e.expenseType.includes('Bank Commission'))?.amountLocal || 65000;
  const totalClearanceLogistics = customsDutyBDT + portDemurrageBDT + cfCommissionBDT + localCarriageBDT;
  const baseFobBdt = selectedLc.cfrAmount * selectedLc.exchangeRate;
  const totalLandedCostBDT = baseFobBdt + totalClearanceLogistics + bankCommissionBDT;
  const totalQty = selectedLc.items.reduce((acc, itm) => acc + itm.quantity, 0) || 1;
  const unitLandedCostBDT = Math.round(totalLandedCostBDT / totalQty);
  const commodityDescription = selectedLc.items.map(i => i.itemName).join(', ');
  const landedCostVariance = totalLandedCostBDT - (baseFobBdt * 1.25);

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-xl border border-slate-700 flex items-center gap-2">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-blue-900/40 rounded-xl p-6 text-white shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded border border-blue-500/30">
                Module 03
              </span>
              <span className="text-xs text-slate-400 font-mono">International Trade & Customs Clearance</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Letter of Credit (LC) & Landed Cost Engine
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
              End-to-end import lifecycle management: Margin deposits, Bill of Lading, Customs Duty assessment (CD, RD, SD, VAT, AT),
              and automated landed cost apportioning directly into inventory stock ledgers.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                resetNewLcForm();
                setShowNewLcModal(true);
              }}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              Open Import LC
            </button>
          </div>
        </div>
      </div>

      {/* Module Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setModuleView('status_summary')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              moduleView === 'status_summary'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            Status Summary
          </button>

          <button
            type="button"
            onClick={() => setModuleView('tracker')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              moduleView === 'tracker'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <FileText className="w-4 h-4" />
            Documentary Credit (LC) Tracker
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
              moduleView === 'tracker' ? 'bg-blue-700 text-white' : 'bg-slate-100 text-slate-700'
            }`}>
              {lcs.length} LCs
            </span>
          </button>

          <button
            type="button"
            onClick={() => setModuleView('product_receiving')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              moduleView === 'product_receiving'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <ArrowDownToLine className="w-4 h-4" />
            LC Product Receiving
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
              moduleView === 'product_receiving' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'
            }`}>
              Stock In
            </span>
          </button>

          <button
            type="button"
            onClick={() => setModuleView('costing')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              moduleView === 'costing'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Calculator className="w-4 h-4" />
            Landed Cost & Customs Engine
            <span className="text-[10px] px-2 py-0.5 rounded font-mono font-normal bg-slate-100 text-slate-600">
              Active: {selectedLc.lcNumber}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowExpiryModal(true)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs ${
              criticalAlertsCount > 0
                ? 'bg-rose-600 text-white animate-pulse'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>LC Expiry Alerts</span>
            <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full font-bold ${
              criticalAlertsCount > 0 ? 'bg-rose-800 text-white' : 'bg-slate-100 text-slate-700'
            }`}>
              {lcExpiryAlerts.length}
            </span>
          </button>
        </div>

        {moduleView === 'costing' && (
          <button
            type="button"
            onClick={() => setModuleView('tracker')}
            className="text-xs text-blue-600 font-semibold hover:underline flex items-center gap-1"
          >
            ← Back to Documentary Credit Tracker
          </button>
        )}
      </div>

      {/* LC Expiry Alert Notification Ribbon */}
      <LCExpiryAlertBanner
        alerts={lcExpiryAlerts}
        onOpenAlertModal={() => setShowExpiryModal(true)}
      />

      {moduleView === 'status_summary' ? (
        <LCStatusSummaryDashboard
          lcs={lcs}
          onSelectLc={(lc) => setSelectedLc(lc)}
          onNavigateToReceiving={(lc) => {
            setSelectedLc(lc);
            setModuleView('product_receiving');
          }}
          onNavigateToExpenses={(lc) => {
            setSelectedLc(lc);
            setModuleView('costing');
          }}
          onOpenNewLcModal={() => {
            resetNewLcForm();
            setShowNewLcModal(true);
          }}
        />
      ) : moduleView === 'product_receiving' ? (
        <LCProductReceivingSector
          lcs={lcs}
          selectedLc={selectedLc}
          onSelectLc={(lc) => setSelectedLc(lc)}
          onUpdateLc={handleUpdateFullLc}
        />
      ) : moduleView === 'tracker' ? (
        <DocumentaryCreditTracker
          lcs={lcs}
          onAddLc={handleAddLcFromTracker}
          onUpdateLc={handleUpdateLc}
          onSelectLcForCosting={handleSelectLcForCosting}
        />
      ) : (
        /* Main Grid: LC List on Left, Active LC Deep Dive on Right */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: LC Selector List */}
          <div className="lg:col-span-4 space-y-3">
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Active Import LCs ({lcs.length})
              </span>
              <span className="text-[11px] text-slate-500 font-mono">Bank Margin Active</span>
            </div>

            <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
              {lcs.map((item) => {
                const isSelected = selectedLc.id === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedLc(item)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                      isSelected
                        ? 'bg-blue-50/80 border-blue-600 shadow-xs ring-1 ring-blue-500'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-xs text-slate-900">
                        {item.lcNumber}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-blue-100 text-blue-800">
                        {item.lcType}
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-slate-800 mt-1 truncate">
                      {item.supplierName}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">{item.items.map(i => i.itemName).join(', ')}</p>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 text-[11px] font-mono">
                      <div>
                        <span className="text-slate-700 font-bold block">
                          ${item.cfrAmount.toLocaleString()} USD
                        </span>
                        <span className="text-[10px] text-slate-400">
                          Mat: {item.maturityDate || item.lcExpiryDate}
                        </span>
                      </div>
                      <span className={`font-semibold text-[10px] px-2 py-0.5 rounded-full ${
                        item.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-800' :
                        item.status === 'Discrepant' ? 'bg-rose-100 text-rose-800 font-bold' :
                        item.status === 'Draft' ? 'bg-slate-100 text-slate-700' :
                        item.status === 'Customs Cleared' ? 'bg-teal-100 text-teal-800' :
                        item.status === 'Shipment In-Transit' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {item.status}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Column: Selected LC Operations Dashboard */}
          <div className="lg:col-span-8 space-y-4">
            {/* Header of Active LC */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div>
                  <div className="flex items-center gap-2">
                    <Ship className="w-5 h-5 text-blue-600" />
                    <h2 className="text-lg font-bold text-slate-900 font-mono">{selectedLc.lcNumber}</h2>
                    <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                      selectedLc.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-800' :
                      selectedLc.status === 'Discrepant' ? 'bg-rose-100 text-rose-800' :
                      selectedLc.status === 'Draft' ? 'bg-slate-100 text-slate-700' :
                      selectedLc.status === 'Customs Cleared' ? 'bg-teal-100 text-teal-800' :
                      selectedLc.status === 'Shipment In-Transit' ? 'bg-blue-100 text-blue-800' : 'bg-indigo-100 text-indigo-800'
                    }`}>
                      {selectedLc.status}
                    </span>
                  </div>
                <p className="text-xs text-slate-600 mt-0.5">
                  Commodity: <strong>{commodityDescription}</strong> | Supplier: {selectedLc.supplierName}
                </p>
              </div>

              <div className="text-right">
                <span className="text-xs text-slate-400 block font-mono">CFR Value (USD):</span>
                <span className="text-lg font-mono font-bold text-slate-900">
                  ${selectedLc.cfrAmount.toLocaleString()}
                </span>
                <span className="text-[11px] font-mono text-slate-500 block">
                  BDT {(baseFobBdt / 1000000).toFixed(2)}M (@ {selectedLc.exchangeRate})
                </span>
              </div>
            </div>

            {/* Sub Tabs */}
            <div className="flex items-center gap-2 pt-3 text-xs font-semibold overflow-x-auto">
              <button
                type="button"
                onClick={() => setActiveTab('product_receiving')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'product_receiving' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-emerald-50 text-emerald-900 border border-emerald-200 hover:bg-emerald-100'
                }`}
              >
                <ArrowDownToLine className="w-3.5 h-3.5" />
                Product Receiving & Stock
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('exporter_bills')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'exporter_bills' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-indigo-50 text-indigo-900 border border-indigo-200 hover:bg-indigo-100'
                }`}
              >
                <Landmark className="w-3.5 h-3.5" />
                Exporter Bills (ব্যাংক ও হুন্ডি পেমেন্ট)
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('dual_pricing')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'dual_pricing' ? 'bg-amber-600 text-white shadow-xs' : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
                }`}
              >
                <Zap className="w-3.5 h-3.5 text-amber-300" />
                ডুয়াল রেট ও হুন্ডি হিসাব
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('costing')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'costing' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                }`}
              >
                <Calculator className="w-3.5 h-3.5" />
                Landed Cost Sheet
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('duties')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'duties' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                Customs Duties & BOE
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('details')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'details' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                Bank & Shipping Terms
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('settlement')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'settlement' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                }`}
              >
                <DollarSign className="w-3.5 h-3.5" />
                Settlement & GL Entries
              </button>
            </div>
          </div>

          {/* Tab: Product Receiving & Border Stock Sector */}
          {activeTab === 'product_receiving' && (
            <LCProductReceivingSector
              lcs={lcs}
              selectedLc={selectedLc}
              onSelectLc={(lc) => setSelectedLc(lc)}
              onUpdateLc={handleUpdateFullLc}
            />
          )}

          {/* Tab: Exporter Bills & Dual Settlement Engine */}
          {activeTab === 'exporter_bills' && (
            <LCExporterBillsView
              lcs={lcs}
              selectedLc={selectedLc}
              onSelectLc={(lc) => setSelectedLc(lc)}
              onUpdateLc={handleUpdateFullLc}
              onNavigateToExpenses={() => setActiveTab('costing')}
            />
          )}

          {/* Tab 0: Dual Pricing & Hundi Settlement Analysis */}
          {activeTab === 'dual_pricing' && (() => {
            const currSym = selectedLc.currency === 'INR' ? '₹' : '$';
            const offRate = selectedLc.officialLcRate || selectedLc.lcBankRateUsd || 14.00;
            const actRate = selectedLc.actualRate || selectedLc.contractRateUsd || 18.00;
            const qty = selectedLc.quantity || selectedLc.receivedQtyMt || selectedLc.items[0]?.quantity || 1000;
            const uom = selectedLc.uom || selectedLc.items[0]?.uom || 'MT';
            const rateDiff = Math.max(0, actRate - offRate);
            const officialTotal = selectedLc.officialLcTotal ?? (qty * offRate);
            const actualTotal = selectedLc.actualTotalAmount ?? (qty * actRate);
            const diffTotal = selectedLc.differentialAmount ?? (qty * rateDiff);
            const exRate = selectedLc.exchangeRate || 122.50;
            const officialTotalBdt = officialTotal * exRate;
            const actualTotalBdt = actualTotal * exRate;
            const diffTotalBdt = diffTotal * exRate;
            const inrDiffTotal = selectedLc.currency === 'USD' ? diffTotal * 83.5 : diffTotal;

            return (
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-600" />
                      ডুয়াল প্রাইসিং ও আন-অফিসিয়াল হুন্ডি/ক্যাশ সেটেলমেন্ট বিশ্লেষণ
                    </h3>
                    <p className="text-xs text-slate-500">
                      ব্যাংক এলসি রেট (অফিসিয়াল) বনাম এক্সপোর্টার কন্ট্রাক্ট রেট (আসল) এবং হুন্ডি ডিফারেন্সিয়াল ট্র্যাকিং
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2.5 py-1 rounded-full font-bold bg-amber-100 text-amber-900 border border-amber-300">
                      পার্থক্য রেট: {currSym}{rateDiff.toFixed(2)} / {uom}
                    </span>
                  </div>
                </div>

                {/* 3 Metric Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="bg-blue-50/60 p-3.5 rounded-xl border border-blue-200">
                    <div className="text-[10px] font-bold text-blue-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Landmark className="w-3.5 h-3.5 text-blue-600" />
                      ১. ব্যাংক এলসি (অফিসিয়াল)
                    </div>
                    <div className="mt-2">
                      <div className="text-xs text-slate-600">
                        ব্যাংক রেট: <span className="font-mono font-bold text-blue-900">{currSym}{offRate.toFixed(2)}</span> / {uom}
                      </div>
                      <div className="text-lg font-black font-mono text-blue-950 mt-0.5">
                        {currSym}{officialTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <div className="text-xs font-mono text-blue-700 mt-0.5 font-bold">
                        ৳ {officialTotalBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                      </div>
                    </div>
                    <div className="mt-2 pt-2 border-t border-blue-200/80 text-[10px] text-blue-800">
                      🏦 ব্যাংকের মাধ্যমে এলসি সিস্টেমে পরিশোধ
                    </div>
                  </div>

                  <div className="bg-indigo-50/60 p-3.5 rounded-xl border border-indigo-200">
                    <div className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Receipt className="w-3.5 h-3.5 text-indigo-600" />
                      ২. প্রোডাক্টের আসল মোট মূল্য
                    </div>
                    <div className="mt-2">
                      <div className="text-xs text-slate-600">
                        আসল রেট: <span className="font-mono font-bold text-indigo-900">{currSym}{actRate.toFixed(2)}</span> / {uom}
                      </div>
                      <div className="text-lg font-black font-mono text-indigo-950 mt-0.5">
                        {currSym}{actualTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <div className="text-xs font-mono text-indigo-700 mt-0.5 font-bold">
                        ৳ {actualTotalBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                      </div>
                    </div>
                    <div className="mt-2 pt-2 border-t border-indigo-200/80 text-[10px] text-indigo-800">
                      📦 এক্সপোর্টারের প্রকৃত চুক্তি পাওনা ({qty.toLocaleString()} {uom})
                    </div>
                  </div>

                  <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-300">
                    <div className="text-[10px] font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-amber-600" />
                      ৩. হুন্ডি / ক্যাশ বকেয়া পার্থক্য
                    </div>
                    <div className="mt-2">
                      <div className="text-xs text-slate-600">
                        ঘাটতি রেট: <span className="font-mono font-bold text-amber-900">{currSym}{rateDiff.toFixed(2)}</span> / {uom}
                      </div>
                      <div className="text-lg font-black font-mono text-amber-950 mt-0.5">
                        {currSym}{diffTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <div className="text-xs font-mono text-amber-800 mt-0.5 font-bold">
                        ৳ {diffTotalBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                        {selectedLc.currency === 'USD' && ` (₹${inrDiffTotal.toLocaleString('en-US', { maximumFractionDigits: 0 })} INR)`}
                      </div>
                    </div>
                    <div className="mt-2 pt-2 border-t border-amber-300/80 text-[10px] text-amber-900 font-semibold">
                      ⚡ হুন্ডি বা আন-অফিসিয়াল ক্যাশ টাকায় পরিশোধ
                    </div>
                  </div>
                </div>

                {/* Practical Trade Explainer Box */}
                <div className="p-4 bg-slate-900 text-white rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-amber-400 border-b border-slate-800 pb-1.5">
                    <span>💡 আমদানি ট্রেড প্রসেস যেভাবে সম্পন্ন হয় (Dual Pricing Workflow):</span>
                    <span className="font-mono text-slate-400">LC: {selectedLc.lcNumber}</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300">
                    <div className="space-y-1">
                      <div className="font-bold text-blue-300">১. অফিসিয়াল এলসি অংশ (ব্যাংকের মাধ্যমে):</div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        ব্যাংকে এলসি আবেদন ও ইনভয়েস রেট সাবমিট হয়েছে <strong className="text-white">{currSym}{offRate}</strong> / {uom} হিসেবে। ব্যাংক থেকে এক্সপোর্টারের ব্যাংক অ্যাকাউন্টে মোট <strong className="text-white">{currSym}{officialTotal.toLocaleString()}</strong> পরিশোধ হবে।
                      </p>
                    </div>
                    <div className="space-y-1">
                      <div className="font-bold text-amber-300">২. আন-অফিসিয়াল অংশ (হুন্ডি বা ক্যাশ সেটেলমেন্ট):</div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        এক্সপোর্টারের সাথে প্রকৃত রেট ঠিক হয়েছে <strong className="text-white">{currSym}{actRate}</strong> / {uom}। ফলে বাকী <strong className="text-white">{currSym}{rateDiff}</strong> / {uom} বা সর্বমোট <strong className="text-amber-300 font-mono font-bold">৳{diffTotalBdt.toLocaleString()} BDT</strong> (বা <strong className="text-amber-300 font-mono font-bold">₹{inrDiffTotal.toLocaleString()} INR</strong>) হুন্ডি বা লোকাল এজেন্ট ক্যাশের মাধ্যমে সেটেল করা হয়।
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Tab 1: Landed Cost Sheet */}
          {activeTab === 'costing' && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Comprehensive Landed Cost Sheet</h3>
                  <p className="text-xs text-slate-500">Capitalized inventory valuation breakdown per MT</p>
                </div>
                <span className="text-xs font-mono font-bold bg-blue-50 text-blue-800 border border-blue-200 px-3 py-1 rounded">
                  Landed Unit Cost: BDT {unitLandedCostBDT.toLocaleString()} / MT
                </span>
              </div>

              {/* Breakdown Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
                  <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Cost Component Head</th>
                      <th className="py-2.5 px-3">Calculation Basis</th>
                      <th className="py-2.5 px-3 text-right">Amount (BDT)</th>
                      <th className="py-2.5 px-3 text-right">% of Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-mono text-slate-800">
                    <tr>
                      <td className="py-2.5 px-3 font-sans font-medium text-slate-900">
                        1. Base Invoice (CFR / FOB) Value
                      </td>
                      <td className="py-2.5 px-3 font-sans text-slate-500">
                        ${selectedLc.cfrAmount.toLocaleString()} @ {selectedLc.exchangeRate}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold">
                        {baseFobBdt.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-500">
                        {((baseFobBdt / totalLandedCostBDT) * 100).toFixed(1)}%
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-sans font-medium text-slate-900">
                        2. Customs Duties & Tariff Taxes (BOE)
                      </td>
                      <td className="py-2.5 px-3 font-sans text-slate-500">
                        Assessment CD, RD, SD, VAT, AT
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-amber-600">
                        {customsDutyBDT.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-500">
                        {((customsDutyBDT / totalLandedCostBDT) * 100).toFixed(1)}%
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-sans font-medium text-slate-900">
                        3. Port Demurrage & Container Storage
                      </td>
                      <td className="py-2.5 px-3 font-sans text-slate-500">
                        Port Yard holding penalty
                      </td>
                      <td className="py-2.5 px-3 text-right text-rose-600 font-semibold">
                        {portDemurrageBDT.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-500">
                        {((portDemurrageBDT / totalLandedCostBDT) * 100).toFixed(1)}%
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-sans font-medium text-slate-900">
                        4. C&F Agency Commission & Handling
                      </td>
                      <td className="py-2.5 px-3 font-sans text-slate-500">
                        Port clearance service fee
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {cfCommissionBDT.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-500">
                        {((cfCommissionBDT / totalLandedCostBDT) * 100).toFixed(1)}%
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-sans font-medium text-slate-900">
                        5. Local Trailer & Inland Transport
                      </td>
                      <td className="py-2.5 px-3 font-sans text-slate-500">
                        Port to Warehouse Trucking
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {localCarriageBDT.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-500">
                        {((localCarriageBDT / totalLandedCostBDT) * 100).toFixed(1)}%
                      </td>
                    </tr>
                  </tbody>
                  <tfoot className="bg-slate-900 text-white font-mono font-bold">
                    <tr>
                      <td colSpan={2} className="py-3 px-3 font-sans">
                        TOTAL CAPITALIZED INVENTORY LANDED COST:
                      </td>
                      <td className="py-3 px-3 text-right text-emerald-400 text-sm">
                        BDT {totalLandedCostBDT.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right">100.0%</td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Capitalization Rule Notice */}
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-900 flex items-start gap-2">
                <FileCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <p>
                  <strong>IAS 2 / Accounting Standard Compliance:</strong> All customs duties, port handling, inland transport, and clearing fees 
                  are directly apportioned to product inventory balance (Account 1200), rather than expensed to P&L period expenses, ensuring precise gross margins upon sale.
                </p>
              </div>
            </div>
          )}

          {/* Tab 2: Customs Duties & BOE */}
          {activeTab === 'duties' && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Bill of Entry (BOE) Customs Assessment</h3>
                  <p className="text-xs text-slate-500">Detailed tax and tariff breakdown from Bangladesh National Board of Revenue (NBR)</p>
                </div>
                <span className="text-xs font-mono font-bold bg-slate-100 text-slate-700 px-3 py-1 rounded">
                  BOE No: {selectedLc.boeNumber || 'Pending Submission'}
                </span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Customs Duty (CD 25%):</span>
                  <span className="font-mono font-bold text-slate-900">BDT 4,850,000</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Regulatory Duty (RD 3%):</span>
                  <span className="font-mono font-bold text-slate-900">BDT 582,000</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Supplementary Duty (SD):</span>
                  <span className="font-mono font-bold text-slate-900">BDT 0 (Exempt)</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Advance Tax (AT 5%):</span>
                  <span className="font-mono font-bold text-slate-900">BDT 970,000</span>
                </div>
              </div>

              <div className="p-4 bg-slate-900 rounded-xl text-white font-mono text-xs space-y-2">
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span>Customs Assessment Station:</span>
                  <span className="text-emerald-400">Custom House, Chittagong (CTG)</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span>Customs HS Code:</span>
                  <span className="text-emerald-400">7208.38.00 (Flat-Rolled Carbon Iron)</span>
                </div>
                <div className="flex justify-between font-bold">
                  <span>Total Government Duties & Taxes Paid:</span>
                  <span className="text-amber-400">BDT {customsDutyBDT.toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Bank & Shipping Details */}
          {activeTab === 'details' && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">Commercial Banking & Logistics Details</h3>
                <span className="text-xs text-slate-500 font-mono">SWIFT MT700 Confirmed</span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Issuing Bank:</span>
                  <span className="font-semibold text-slate-900">{selectedLc.issuingBank}</span>
                  <span className="text-[10px] text-slate-500 block">{selectedLc.branch}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Margin Percentage:</span>
                  <span className="font-mono font-bold text-blue-700">{selectedLc.marginDepositPercent}%</span>
                  <span className="text-[10px] text-slate-500 block">BDT {selectedLc.marginAmountLocal.toLocaleString()}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Bill of Lading (B/L):</span>
                  <span className="font-mono font-bold text-slate-900">{selectedLc.blNumber || 'BL-PENDING'}</span>
                  <span className="text-[10px] text-slate-500 block">Vessel: MAERSK MC-KINNEY MOLLER</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Port of Loading:</span>
                  <span className="font-semibold text-slate-900">{selectedLc.portOfLoading}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Port of Discharge:</span>
                  <span className="font-semibold text-slate-900">{selectedLc.portOfDischarge}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Latest Shipment Date:</span>
                  <span className="font-mono font-semibold text-slate-900">{selectedLc.shipmentExpiryDate}</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 4: Settlement & GL Entries */}
          {activeTab === 'settlement' && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">LC Financial Settlement & GL Integration</h3>
                <span className="text-xs font-mono text-emerald-700 font-bold">Auto-Reconciled</span>
              </div>

              <div className="space-y-3 font-mono text-xs">
                <div className="p-3 bg-slate-900 text-slate-200 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex justify-between text-white font-bold border-b border-slate-800 pb-1">
                    <span>1. LC Opening Voucher (Margin & Bank Commission)</span>
                    <span className="text-emerald-400">Posted</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span>Dr. 1150 - LC Margin Deposit with Bank</span>
                    <span className="text-emerald-400">BDT {selectedLc.marginAmountLocal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span>Dr. 5310 - Bank Charges & LC Commission</span>
                    <span className="text-emerald-400">BDT {bankCommissionBDT.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-rose-400">
                    <span>Cr. 1110 - Eastern Bank Principal Current A/C</span>
                    <span>BDT {(selectedLc.marginAmountLocal + bankCommissionBDT).toLocaleString()}</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-900 text-slate-200 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex justify-between text-white font-bold border-b border-slate-800 pb-1">
                    <span>2. Inventory Capitalization on Warehouse GRN Receipt</span>
                    <span className="text-emerald-400">Posted</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span>Dr. 1200 - Merchandise Inventory</span>
                    <span className="text-emerald-400">BDT {totalLandedCostBDT.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-rose-400">
                    <span>Cr. 1160 - Goods In-Transit / LC Clearing Account</span>
                    <span>BDT {totalLandedCostBDT.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      )}

      {/* Modal: Open Import LC */}
      {showNewLcModal && (
        <ModalWrapper
          isOpen={showNewLcModal}
          onClose={handleCloseNewLcModal}
          isDirty={isNewLcDirty}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in overflow-y-auto overscroll-contain"
        >
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-5 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto"
          >
            <div className="sticky top-0 z-20 bg-white -mx-5 -mt-5 px-5 pt-4 pb-3 border-b border-slate-200 flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900">Open New Import Letter of Credit (LC)</h3>
              <button
                type="button"
                data-modal-close="true"
                onClick={handleCloseNewLcModal}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold p-1 shrink-0 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Box 1: Quick Import Presets */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">1</span>
                  Quick Import Presets:
                </span>
                <span className="text-[10px] text-slate-500 font-medium">
                  {newLcCommodity ? `Selected: ${newLcCommodity}` : 'Select a product preset'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const r = Math.floor(Math.random() * 899 + 100);
                    setNewLcCommodity('S-Samtse Boulder');
                    setNewLcNumber(`LC-2026-SB-${r}`);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all shadow-2xs group cursor-pointer ${
                    newLcCommodity === 'S-Samtse Boulder'
                      ? 'bg-indigo-50 border-indigo-500 ring-2 ring-indigo-500/20 shadow-xs'
                      : 'bg-white hover:bg-indigo-50/50 hover:border-indigo-300 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-mono font-black text-xs flex items-center justify-center shrink-0 shadow-xs">
                      S
                    </span>
                    <span className="font-bold text-slate-900 text-xs truncate group-hover:text-indigo-700">
                      S-Samtse Boulder
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block pl-8 truncate font-medium">
                    Samtse Boulder Stone
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const r = Math.floor(Math.random() * 899 + 100);
                    setNewLcCommodity('P-Phuentsholing Boulder');
                    setNewLcNumber(`LC-2026-PB-${r}`);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all shadow-2xs group cursor-pointer ${
                    newLcCommodity === 'P-Phuentsholing Boulder'
                      ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'bg-white hover:bg-emerald-50/50 hover:border-emerald-300 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white font-mono font-black text-xs flex items-center justify-center shrink-0 shadow-xs">
                      P
                    </span>
                    <span className="font-bold text-slate-900 text-xs truncate group-hover:text-emerald-700">
                      P-Phuentsholing Boulder
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block pl-8 truncate font-medium">
                    Phuentsholing Boulder Stone
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const r = Math.floor(Math.random() * 899 + 100);
                    setNewLcCommodity('R-Indian River Stone Boulder');
                    setNewLcNumber(`LC-2026-IR-${r}`);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all shadow-2xs group cursor-pointer ${
                    newLcCommodity === 'R-Indian River Stone Boulder'
                      ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-500/20 shadow-xs'
                      : 'bg-white hover:bg-amber-50/50 hover:border-amber-300 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-6 h-6 rounded-lg bg-amber-600 text-white font-mono font-black text-xs flex items-center justify-center shrink-0 shadow-xs">
                      R
                    </span>
                    <span className="font-bold text-slate-900 text-xs truncate group-hover:text-amber-700">
                      R-Indian River Stone Boulder
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block pl-8 truncate font-medium">
                    Indian River Boulder
                  </span>
                </button>
              </div>
            </div>

            <form onSubmit={handleCreateLC} autoComplete="off" className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">LC Reference Number</label>
                  <input
                    type="text"
                    value={newLcNumber}
                    onChange={(e) => setNewLcNumber(e.target.value)}
                    className="w-full p-2 border border-slate-200 rounded font-mono font-bold focus:ring-1 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">LC Instrument Type</label>
                  <select
                    value={newLcType}
                    onChange={(e) => setNewLcType(e.target.value as any)}
                    className="w-full p-2 border border-slate-200 rounded font-medium focus:ring-1 focus:ring-blue-500 outline-none"
                  >
                    <option value="">-- Select LC Type --</option>
                    <option value="Sight LC">Irrevocable Sight LC</option>
                    <option value="Usance 90 Days">Usance 90 Days LC</option>
                    <option value="Usance 180 Days">Usance 180 Days LC</option>
                    <option value="UPAS LC">UPAS LC (Buyer Credit)</option>
                    <option value="Cash LC">Cash LC</option>
                  </select>
                </div>
              </div>

              {/* Supplier & Item Section */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center gap-1.5 pb-1 border-b border-slate-200/80">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">2</span>
                  <span className="text-xs font-bold text-slate-800">Supplier & Item Selection</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Beneficiary / Supplier <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={newLcSupplier}
                      onChange={(e) => setNewLcSupplier(e.target.value)}
                      required
                      className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-white font-medium"
                    >
                      <option value="">-- Select Supplier / Beneficiary --</option>
                      <option value="Pelden Enterprise Limited (Bhutan)">Pelden Enterprise Limited (Bhutan)</option>
                      <option value="M/S Sawdagar Enterprise (India)">M/S Sawdagar Enterprise (India)</option>
                      <option value="Druk Stone Quarry & Minerals (Bhutan)">Druk Stone Quarry & Minerals (Bhutan)</option>
                      <option value="Singye Stone Export (Bhutan)">Singye Stone Export (Bhutan)</option>
                      <option value="Baosteel International Trading Corp">Baosteel International Trading Corp (China)</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Import Commodity / Item <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={newLcCommodity}
                      onChange={(e) => setNewLcCommodity(e.target.value)}
                      required
                      className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-white font-bold"
                    >
                      <option value="">-- Select Import Item / Commodity --</option>
                      <optgroup label="Featured Boulder Products">
                        <option value="S-Samtse Boulder">S-Samtse Boulder (Samtse Boulder Stone)</option>
                        <option value="P-Phuentsholing Boulder">P-Phuentsholing Boulder (Phuentsholing Boulder Stone)</option>
                        <option value="R-Indian River Stone Boulder">R-Indian River Stone Boulder (Indian River Boulder)</option>
                      </optgroup>
                      <optgroup label="Aggregates & Stone Items">
                        <option value="Boulder Stone - Phuentsholing Quarry">Boulder Stone - Phuentsholing Quarry</option>
                        <option value="River Stone Boulder - India Torsha">River Stone Boulder - India Torsha</option>
                        <option value="Boulder Stone (Samtse River Boulder)">Boulder Stone (Samtse River Boulder)</option>
                        <option value="3/4 Down / 20MM Crush Stone">3/4" Down / 20MM Crush Stone</option>
                        <option value="1/2 Crush Stone">1/2" Crush Stone</option>
                        <option value="5/8 Crush Stone">5/8" Crush Stone</option>
                      </optgroup>
                    </select>
                  </div>

                  {/* Border / Land Port Entry */}
                  <div className="col-span-1 sm:col-span-2">
                    <label className="font-bold text-slate-700 block mb-1 flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-blue-900">
                        <MapPin className="w-3.5 h-3.5 text-rose-500" />
                        Border / Land Port Entry <span className="text-rose-500">*</span>
                      </span>
                    </label>
                    <select
                      value={newLcBorderLandPort}
                      onChange={(e) => setNewLcBorderLandPort(e.target.value)}
                      required
                      className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-blue-50/20 font-bold text-slate-900"
                    >
                      <option value="">-- Select Border / Land Port --</option>
                      <option value="Burimari">Burimari Land Port - Lalmonirhat (Bhutan & Changrabandha Border)</option>
                      <option value="Sonahat">Sonahat Land Port - Kurigram (Assam & Bhutan Border)</option>
                      <option value="Banglabandha">Banglabandha Land Port - Panchagarh (Siliguri & Bhutan Border)</option>
                      <option value="Tamabil">Tamabil Land Port - Sylhet (Dawki & Meghalaya Border)</option>
                      <option value="Hili">Hili Land Port - Dinajpur (India Border)</option>
                      <option value="Sonamasjid">Sonamasjid Land Port - Chapainawabganj (India Border)</option>
                      <option value="Benapole">Benapole Land Port - Jashore (Petrapole Border)</option>
                      <option value="Bhomra">Bhomra Land Port - Satkhira (Ghojadanga Border)</option>
                      <option value="Chittagong Port">Chittagong Sea Port - Bulk Cargo</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Issuing Bank</label>
                <select
                  value={newLcBank}
                  onChange={(e) => setNewLcBank(e.target.value)}
                  className="w-full p-2 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-white font-medium"
                >
                  <option value="">-- Select Issuing Bank --</option>
                  <option value="Eastern Bank PLC">Eastern Bank PLC</option>
                  <option value="The City Bank Ltd">The City Bank Ltd</option>
                  <option value="Standard Chartered Bank">Standard Chartered Bank</option>
                  <option value="BRAC Bank PLC">BRAC Bank PLC</option>
                  <option value="Dutch-Bangla Bank">Dutch-Bangla Bank</option>
                  <option value="HSBC Bangladesh">HSBC Bangladesh</option>
                </select>
              </div>

              {/* Date Details */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center gap-1.5 pb-1 border-b border-slate-200/80">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">3</span>
                  <span className="text-xs font-bold text-slate-800">Date Details</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Opening Date <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={newLcOpeningDate}
                      onChange={(e) => setNewLcOpeningDate(e.target.value)}
                      className="w-full p-2 border border-slate-200 rounded font-mono focus:ring-1 focus:ring-blue-500 outline-none bg-white"
                      required
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Expiry Date <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={newLcMaturityDate}
                      onChange={(e) => setNewLcMaturityDate(e.target.value)}
                      className="w-full p-2 border border-slate-200 rounded font-mono focus:ring-1 focus:ring-blue-500 outline-none bg-white"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Quantity, UOM & Currency Selection */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-slate-200/80">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Coins className="w-3.5 h-3.5 text-blue-600" />
                    Quantity, UOM & Currency
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    1 {newLcCurrency} = {newLcExchangeRate} BDT
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="col-span-1 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">
                      Quantity <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={newLcQuantity || ''}
                      onChange={(e) => {
                        const q = e.target.value === '' ? 0 : Math.max(1, Number(e.target.value));
                        setNewLcQuantity(q);
                        setNewLcCfr(q * (Number(newLcOfficialRate) || 0));
                      }}
                      min={1}
                      required
                      placeholder="e.g. 1000"
                      className="w-full border border-slate-300 rounded-xl p-2 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                    />
                  </div>

                  <div className="col-span-1 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">
                      UOM
                    </label>
                    <select
                      value={newLcUom}
                      onChange={(e) => setNewLcUom(e.target.value)}
                      className="w-full border border-slate-300 rounded-xl p-2 font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                    >
                      <option value="">Select UOM...</option>
                      <option value="MT">MT (Metric Ton)</option>
                      <option value="CFT">CFT (Cubic Feet)</option>
                      <option value="Ton">Ton</option>
                    </select>
                  </div>

                  <div className="col-span-1 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">
                      Currency <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={newLcCurrency}
                      onChange={(e) => {
                        const cur = e.target.value as 'USD' | 'INR';
                        setNewLcCurrency(cur);
                      }}
                      className="w-full border border-slate-300 rounded-xl p-2 font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                    >
                      <option value="">Select Currency...</option>
                      <option value="USD">USD ($ US Dollar)</option>
                      <option value="INR">INR (₹ Indian Rupee)</option>
                    </select>
                  </div>

                  <div className="col-span-1 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">
                      Exchange Rate (BDT)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={newLcExchangeRate || ''}
                      onChange={(e) => setNewLcExchangeRate(Number(e.target.value))}
                      required
                      className="w-full border border-slate-300 rounded-xl p-2 font-mono font-medium text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* ডুয়াল প্রাইসিং সেকশন: ব্যাংক এলসি রেট বনাম প্রোডাক্টের আসল রেট */}
              <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200/90 space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-amber-200">
                  <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-amber-600" />
                    ডুয়াল প্রাইসিং ইউনিট রেট (Bank LC Rate vs Actual Commercial Rate)
                  </span>
                  <span className="text-[10px] text-amber-800 font-semibold bg-amber-100 px-2 py-0.5 rounded-md">
                    পার্থক্য: {newLcCurrency === 'INR' ? '₹' : '$'}{Math.max(0, newLcActualRate - newLcOfficialRate).toFixed(2)} / {newLcUom}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="bg-white p-2.5 rounded-xl border border-blue-200 shadow-2xs">
                    <label className="block font-bold text-blue-900 mb-0.5">
                      ১. ব্যাংক এলসি রেট / ইউনিট প্রাইস ({newLcCurrency === 'INR' ? '₹' : '$'}) <span className="text-rose-500">*</span>
                    </label>
                    <p className="text-[10px] text-blue-600 mb-1.5">
                      ব্যাংকে যে রেট দিয়ে এলসি খোলা হচ্ছে (অফিসিয়াল ব্যাংক পেমেন্ট)
                    </p>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono font-bold text-slate-400">
                        {newLcCurrency === 'INR' ? '₹' : '$'}
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        value={newLcOfficialRate}
                        onChange={(e) => {
                          const r = Number(e.target.value);
                          setNewLcOfficialRate(r);
                          setNewLcCfr(newLcQuantity * r);
                        }}
                        min={0.01}
                        required
                        placeholder="e.g. 14.00"
                        className="w-full pl-7 pr-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-sm text-blue-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-blue-50/30"
                      />
                    </div>
                  </div>

                  <div className="bg-white p-2.5 rounded-xl border border-amber-300 shadow-2xs">
                    <label className="block font-bold text-amber-950 mb-0.5">
                      ২. প্রোডাক্টের আসল রেট ({newLcCurrency === 'INR' ? '₹' : '$'}) <span className="text-rose-500">*</span>
                    </label>
                    <p className="text-[10px] text-amber-700 mb-1.5">
                      এক্সপোর্টারের সাথে নির্ধারিত মূল চুক্তি রেট (প্রকৃত খরচ)
                    </p>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono font-bold text-slate-400">
                        {newLcCurrency === 'INR' ? '₹' : '$'}
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        value={newLcActualRate}
                        onChange={(e) => setNewLcActualRate(Number(e.target.value))}
                        min={0.01}
                        required
                        placeholder="e.g. 18.00"
                        className="w-full pl-7 pr-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-sm text-amber-950 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-amber-50/30"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* স্বয়ংক্রিয় পেমেন্ট ও হুন্ডি বিভাজন লাইভ কার্ড */}
              {(() => {
                const currSym = newLcCurrency === 'INR' ? '₹' : '$';
                const officialLcTotal = newLcQuantity * newLcOfficialRate;
                const actualTotalAmount = newLcQuantity * newLcActualRate;
                const rateDiff = Math.max(0, newLcActualRate - newLcOfficialRate);
                const differentialAmount = newLcQuantity * rateDiff;
                const officialLcTotalBdt = officialLcTotal * newLcExchangeRate;
                const actualTotalAmountBdt = actualTotalAmount * newLcExchangeRate;
                const differentialAmountBdt = differentialAmount * newLcExchangeRate;

                return (
                  <div className="p-3 bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 text-white rounded-2xl border border-slate-700 shadow-md space-y-2.5">
                    <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
                      <span className="text-xs font-bold flex items-center gap-1.5 text-indigo-300">
                        <Calculator className="w-3.5 h-3.5 text-amber-400" />
                        স্বয়ংক্রিয় পেমেন্ট ও হুন্ডি ডিফারেন্সিয়াল বিভাজন হিসাব
                      </span>
                      <span className="text-[10px] font-mono text-emerald-400 font-bold px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-700/60">
                        মোট পরিমাণ: {newLcQuantity.toLocaleString()} {newLcUom}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                      {/* Box 1: Official Bank LC Total */}
                      <div className="bg-slate-800/90 rounded-xl p-2.5 border border-blue-500/40">
                        <div className="text-[10px] text-blue-300 font-bold uppercase tracking-wider flex items-center gap-1">
                          <Landmark className="w-3 h-3 text-blue-400" />
                          ১. ব্যাংক এলসি মোট মূল্য:
                        </div>
                        <div className="text-base font-black font-mono text-white mt-0.5">
                          {currSym}{officialLcTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-blue-200 font-mono">
                          ৳ {officialLcTotalBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                        </div>
                        <span className="inline-block mt-1 text-[9px] text-blue-300 font-semibold bg-blue-900/60 px-1.5 py-0.5 rounded">
                          🏦 ব্যাংকের মাধ্যমে এলসি পেমেন্ট
                        </span>
                      </div>

                      {/* Box 2: Actual Commercial Total */}
                      <div className="bg-slate-800/90 rounded-xl p-2.5 border border-indigo-500/40">
                        <div className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider flex items-center gap-1">
                          <Receipt className="w-3 h-3 text-indigo-400" />
                          ২. প্রোডাক্টের আসল মোট মূল্য:
                        </div>
                        <div className="text-base font-black font-mono text-white mt-0.5">
                          {currSym}{actualTotalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-indigo-200 font-mono">
                          ৳ {actualTotalAmountBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                        </div>
                        <span className="inline-block mt-1 text-[9px] text-indigo-300 font-semibold bg-indigo-900/60 px-1.5 py-0.5 rounded">
                          📦 এক্সপোর্টারের প্রকৃত মোট পাওনা
                        </span>
                      </div>

                      {/* Box 3: Hundi / Unofficial Payment Difference */}
                      <div className="bg-amber-950/50 rounded-xl p-2.5 border border-amber-500/60">
                        <div className="text-[10px] text-amber-300 font-bold uppercase tracking-wider flex items-center gap-1">
                          <Zap className="w-3 h-3 text-amber-400" />
                          ৩. হুন্ডি / আন-অফিসিয়াল বকেয়া:
                        </div>
                        <div className="text-base font-black font-mono text-amber-300 mt-0.5">
                          {currSym}{differentialAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-amber-200 font-mono font-bold">
                          ৳ {differentialAmountBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })} BDT
                          {newLcCurrency === 'USD' && ` (₹${(differentialAmount * 83.5).toLocaleString('en-US', { maximumFractionDigits: 0 })} INR)`}
                        </div>
                        <span className="inline-block mt-1 text-[9px] text-amber-300 font-semibold bg-amber-900/70 px-1.5 py-0.5 rounded">
                          ⚡ হুন্ডি বা ক্যাশ টাকায় পরিশোধ
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">LC Status</label>
                  <select
                    value={newLcStatus}
                    onChange={(e) => setNewLcStatus(e.target.value as any)}
                    className="w-full p-2 border border-slate-200 rounded font-semibold focus:ring-1 focus:ring-blue-500 outline-none bg-white"
                  >
                    <option value="">-- Select LC Status --</option>
                    <option value="Draft">Draft</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Discrepant">Discrepant</option>
                    <option value="Bank Applied">Bank Applied</option>
                    <option value="Opened / Margin Paid">Opened / Margin Paid</option>
                    <option value="Shipment In-Transit">Shipment In-Transit</option>
                    <option value="Customs Cleared">Customs Cleared</option>
                    <option value="Accepted">Accepted</option>
                    <option value="Matured">Matured</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Bank Margin Required (%)</label>
                  <input
                    type="number"
                    value={newLcMargin || ''}
                    onChange={(e) => setNewLcMargin(Number(e.target.value))}
                    className="w-full p-2 border border-slate-200 rounded font-mono focus:ring-1 focus:ring-blue-500 outline-none bg-white"
                    required
                  />
                </div>
              </div>

              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-xs space-y-1 font-mono">
                <div className="flex justify-between items-center text-blue-900 font-bold">
                  <span>Bank LC Cash Margin ({newLcMargin}%):</span>
                  <span className="text-blue-950 text-sm">
                    BDT {(((newLcQuantity * newLcOfficialRate * newLcExchangeRate) * newLcMargin) / 100).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                  </span>
                </div>
                <div className="flex justify-between text-blue-700 text-[11px] font-sans">
                  <span>Exchange Rate:</span>
                  <span className="font-mono">1 {newLcCurrency} = {newLcExchangeRate} BDT</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleCloseNewLcModal}
                  className="px-3 py-1.5 border border-slate-200 rounded text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded shadow-xs cursor-pointer"
                >
                  Issue LC Application
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* LC Expiry & Maturity Alert Center Modal */}
      <LCExpiryAlertModal
        isOpen={showExpiryModal}
        onClose={() => setShowExpiryModal(false)}
        alerts={lcExpiryAlerts}
        lcs={lcs}
        onAcknowledgeAlert={handleAcknowledgeAlert}
        onApplyAmendment={handleApplyAmendment}
        onNavigateToLC={(lcId, view) => {
          const target = lcs.find(l => l.id === lcId);
          if (target) {
            setSelectedLc(target);
            if (view === 'expenses' || view === 'bills') {
              setModuleView('costing');
            } else {
              setModuleView('tracker');
            }
          }
        }}
      />
    </div>
  );
};
