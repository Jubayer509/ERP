import React, { useState } from 'react';
import { 
  Bell, 
  X, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  Ship, 
  FileText, 
  Receipt, 
  Building2, 
  ArrowRight, 
  DollarSign, 
  Send, 
  Copy, 
  Check, 
  ExternalLink,
  Search,
  Filter,
  Layers,
  ShieldAlert
} from 'lucide-react';
import { LetterOfCredit } from '../../types/erp';
import { 
  LCExpiryAlert, 
  AlertSeverity, 
  AlertCategory, 
  generateMT707AmendmentDraft 
} from '../../utils/lcAlertUtils';
import { ModalWrapper } from '../common/ModalWrapper';

interface LCExpiryAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: LCExpiryAlert[];
  lcs: LetterOfCredit[];
  onAcknowledgeAlert: (alertId: string) => void;
  onApplyAmendment: (lcId: string, newShipmentDate: string, newExpiryDate: string) => void;
  onNavigateToLC: (lcId: string, view: 'register' | 'expenses' | 'bills') => void;
}

export const LCExpiryAlertModal: React.FC<LCExpiryAlertModalProps> = ({
  isOpen,
  onClose,
  alerts,
  lcs,
  onAcknowledgeAlert,
  onApplyAmendment,
  onNavigateToLC
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'expired' | 'critical' | 'shipment' | 'lc_expiry' | 'maturity'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Amendment Letter Modal State
  const [amendmentLc, setAmendmentLc] = useState<LetterOfCredit | null>(null);
  const [extensionDays, setExtensionDays] = useState<number>(0);
  const [copiedDraft, setCopiedDraft] = useState(false);

  if (!isOpen) return null;

  // Filter alerts
  const filteredAlerts = alerts.filter(alert => {
    // Filter by tab
    if (activeFilter === 'expired' && alert.severity !== 'expired') return false;
    if (activeFilter === 'critical' && alert.severity !== 'critical') return false;
    if (activeFilter === 'shipment' && alert.category !== 'shipment') return false;
    if (activeFilter === 'lc_expiry' && alert.category !== 'lc_expiry') return false;
    if (activeFilter === 'maturity' && alert.category !== 'maturity') return false;

    // Search query
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const match = 
        alert.lcNumber.toLowerCase().includes(q) ||
        alert.supplierName.toLowerCase().includes(q) ||
        alert.issuingBank.toLowerCase().includes(q) ||
        alert.commodity.toLowerCase().includes(q);
      if (!match) return false;
    }

    return true;
  });

  const expiredCount = alerts.filter(a => a.severity === 'expired').length;
  const criticalCount = alerts.filter(a => a.severity === 'critical').length;
  const warningCount = alerts.filter(a => a.severity === 'warning').length;

  const handleOpenAmendment = (lcId: string) => {
    const target = lcs.find(l => l.id === lcId);
    if (target) {
      setAmendmentLc(target);
      setExtensionDays(0);
      setCopiedDraft(false);
    }
  };

  const amendmentDetails = amendmentLc 
    ? generateMT707AmendmentDraft(amendmentLc, extensionDays)
    : null;

  const handleCopyAmendment = () => {
    if (amendmentDetails) {
      navigator.clipboard.writeText(amendmentDetails.letterBody);
      setCopiedDraft(true);
      setTimeout(() => setCopiedDraft(false), 3000);
    }
  };

  const handleConfirmApplyAmendment = () => {
    if (amendmentLc && amendmentDetails) {
      onApplyAmendment(amendmentLc.id, amendmentDetails.newShipmentDate, amendmentDetails.newExpiryDate);
      setAmendmentLc(null);
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5"
    >
      <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 border border-slate-200">
        
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-start justify-between gap-4 shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-bold uppercase tracking-wider bg-rose-100 text-rose-800 px-2.5 py-0.5 rounded-full font-mono flex items-center gap-1">
                <Bell className="w-3 h-3 text-rose-600" />
                Active LC Alert Engine
              </span>
              <span className="text-xs text-slate-500 font-medium">UCP 600 Compliance & Operational Deadlines</span>
            </div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              Letter of Credit Expiry & Maturity Alert Center
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Live monitoring of latest shipment dates, negotiation/presentation expiries, and foreign exporter bill maturities.
            </p>
          </div>

          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-xl transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Filter Counts Bar */}
        <div className="px-5 py-3 border-b border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Severity & Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-0.5 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 ${
                activeFilter === 'all' 
                  ? 'bg-slate-900 text-white font-bold' 
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span>All Alerts</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 bg-slate-700 text-slate-200 rounded-full">
                {alerts.length}
              </span>
            </button>

            {expiredCount > 0 && (
              <button
                type="button"
                onClick={() => setActiveFilter('expired')}
                className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 ${
                  activeFilter === 'expired' 
                    ? 'bg-rose-600 text-white font-bold' 
                    : 'text-rose-700 bg-rose-50 hover:bg-rose-100'
                }`}
              >
                <span>Expired / Lapsed</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 bg-rose-800 text-white rounded-full">
                  {expiredCount}
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setActiveFilter('critical')}
              className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 ${
                activeFilter === 'critical' 
                  ? 'bg-amber-600 text-white font-bold' 
                  : 'text-amber-800 bg-amber-50 hover:bg-amber-100'
              }`}
            >
              <span>Critical (≤ 7 Days)</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 bg-amber-800 text-white rounded-full">
                {criticalCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveFilter('shipment')}
              className={`px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                activeFilter === 'shipment' 
                  ? 'bg-blue-600 text-white font-bold' 
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Shipment Expiries
            </button>

            <button
              type="button"
              onClick={() => setActiveFilter('lc_expiry')}
              className={`px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                activeFilter === 'lc_expiry' 
                  ? 'bg-blue-600 text-white font-bold' 
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              LC Presentation Expiry
            </button>

            <button
              type="button"
              onClick={() => setActiveFilter('maturity')}
              className={`px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                activeFilter === 'maturity' 
                  ? 'bg-indigo-600 text-white font-bold' 
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Bill Maturities
            </button>
          </div>

          {/* Search Box */}
          <div className="relative shrink-0 w-full sm:w-56">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search LC #, supplier, bank..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Alerts List Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
          {filteredAlerts.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-80" />
              <p className="font-semibold text-slate-800">No alerts match the selected criteria.</p>
              <p className="text-slate-400 mt-0.5">All active documentary credits are operating within safe date thresholds.</p>
            </div>
          ) : (
            filteredAlerts.map((alert) => {
              const targetLc = lcs.find(l => l.id === alert.lcId);
              const isExpired = alert.daysRemaining < 0;
              const isCritical = alert.daysRemaining >= 0 && alert.daysRemaining <= 7;

              return (
                <div 
                  key={alert.id}
                  className={`bg-white rounded-2xl border p-4 shadow-2xs transition-all hover:shadow-xs ${
                    isExpired 
                      ? 'border-rose-300 ring-1 ring-rose-200' 
                      : isCritical
                      ? 'border-amber-300 ring-1 ring-amber-200'
                      : 'border-slate-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="font-mono font-bold text-slate-900 text-sm">
                          {alert.lcNumber}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {alert.bankReference}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-mono ${
                          alert.category === 'shipment' ? 'bg-blue-100 text-blue-800' :
                          alert.category === 'lc_expiry' ? 'bg-purple-100 text-purple-800' :
                          'bg-indigo-100 text-indigo-800'
                        }`}>
                          {alert.categoryLabel}
                        </span>
                        {alert.acknowledged && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                            ✓ Acknowledged
                          </span>
                        )}
                      </div>

                      <h3 className="text-xs font-bold text-slate-800">
                        {alert.title}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        <strong>Beneficiary:</strong> {alert.supplierName} • <strong>Issuing Bank:</strong> {alert.issuingBank}
                      </p>
                    </div>

                    {/* Expiry Countdown Tag */}
                    <div className="shrink-0 text-right">
                      <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-mono text-xs font-bold ${
                        isExpired 
                          ? 'bg-rose-600 text-white shadow-xs' 
                          : isCritical
                          ? 'bg-amber-500 text-white shadow-xs'
                          : 'bg-blue-100 text-blue-900'
                      }`}>
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          {isExpired 
                            ? `EXPIRED (${Math.abs(alert.daysRemaining)} Days Ago)` 
                            : alert.daysRemaining === 0
                            ? 'EXPIRES TODAY'
                            : `${alert.daysRemaining} Days Left`}
                        </span>
                      </div>
                      <span className="block text-[10px] text-slate-400 font-mono mt-1">
                        Target Date: <strong>{alert.targetDate}</strong>
                      </span>
                    </div>
                  </div>

                  {/* Cargo & Financial Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 my-3 bg-slate-50 p-2.5 rounded-xl text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-bold">Consignment</span>
                      <span className="font-semibold text-slate-800 truncate block">{alert.commodity}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-bold">CFR Value</span>
                      <span className="font-mono font-bold text-slate-900">
                        ${alert.cfrAmount.toLocaleString()} USD (~৳{((alert.cfrAmount * 118.5) / 1000000).toFixed(2)}M)
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-bold">Instrument Status</span>
                      <span className="font-semibold text-blue-700">{alert.status}</span>
                    </div>
                  </div>

                  {/* Recommended Action Box */}
                  <div className={`p-2.5 rounded-xl text-xs border flex items-start gap-2 ${
                    isExpired 
                      ? 'bg-rose-50/60 border-rose-200 text-rose-900' 
                      : isCritical
                      ? 'bg-amber-50/60 border-amber-200 text-amber-900'
                      : 'bg-blue-50/60 border-blue-200 text-blue-900'
                  }`}>
                    <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block text-[11px] font-bold">Recommended Commercial Action:</strong>
                      <span>{alert.recommendedAction}</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-2.5 border-t border-slate-100 text-xs">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleOpenAmendment(alert.lcId)}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-colors shadow-2xs flex items-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Draft MT707 Amendment</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onNavigateToLC(alert.lcId, alert.category === 'maturity' ? 'bills' : 'expenses');
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition-colors flex items-center gap-1"
                      >
                        <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                        <span>{alert.category === 'maturity' ? 'Open Bill Settlement' : 'View Landed Cost'}</span>
                      </button>
                    </div>

                    {!alert.acknowledged && (
                      <button
                        type="button"
                        onClick={() => onAcknowledgeAlert(alert.id)}
                        className="px-2.5 py-1 text-slate-500 hover:text-slate-800 text-[11px] font-medium transition-colors"
                      >
                        Mark as Acknowledged
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Standard reference date: <strong>2026-09-22</strong> (International Trade Protocol)</span>
          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold transition-colors cursor-pointer"
          >
            Close Alert Center
          </button>
        </div>
      </div>

      {/* SWIFT MT707 LC Amendment Generator Modal */}
      {amendmentLc && amendmentDetails && (
        <ModalWrapper
          isOpen={Boolean(amendmentLc && amendmentDetails)}
          onClose={() => setAmendmentLc(null)}
          isDirty={extensionDays !== 30}
          className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-300">
            <div className="p-5 border-b border-slate-200 bg-blue-50/70 flex items-center justify-between shrink-0">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-blue-600 text-white px-2 py-0.5 rounded">
                  Swift MT707 Generator
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  Bank LC Amendment Application ({amendmentLc.lcNumber})
                </h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setAmendmentLc(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg shrink-0 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
              {/* Extension Duration Selector */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="font-bold text-slate-800 block">Requested Extension Period:</span>
                  <span className="text-[11px] text-slate-500">
                    Applies to Field 44C (Latest Shipment) and Field 31D (LC Expiry).
                  </span>
                </div>

                <div className="flex items-center gap-1.5 font-mono font-bold">
                  {[15, 30, 45, 60].map((days) => (
                    <button
                      key={days}
                      type="button"
                      onClick={() => setExtensionDays(days)}
                      className={`px-3 py-1.5 rounded-xl text-xs transition-colors ${
                        extensionDays === days
                          ? 'bg-blue-600 text-white shadow-2xs'
                          : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      +{days} Days
                    </button>
                  ))}
                </div>
              </div>

              {/* Updated Dates Summary */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-blue-50/50 p-3 rounded-xl border border-blue-200">
                <div>
                  <span className="text-slate-500 text-[11px] block">New Latest Shipment Date:</span>
                  <span className="font-mono font-bold text-blue-900 text-sm">
                    {amendmentDetails.newShipmentDate}
                  </span>
                  <span className="text-[10px] text-slate-400 block">Previous: {amendmentLc.shipmentExpiryDate}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">New LC Expiry Date:</span>
                  <span className="font-mono font-bold text-blue-900 text-sm">
                    {amendmentDetails.newExpiryDate}
                  </span>
                  <span className="text-[10px] text-slate-400 block">Previous: {amendmentLc.lcExpiryDate}</span>
                </div>
              </div>

              {/* Formatted Letter Body */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-slate-700">Official Bank Swift MT707 Letter Draft:</span>
                  <button
                    type="button"
                    onClick={handleCopyAmendment}
                    className="flex items-center gap-1 text-[11px] font-bold text-blue-700 hover:text-blue-800"
                  >
                    {copiedDraft ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedDraft ? 'Copied to Clipboard!' : 'Copy Letter Text'}</span>
                  </button>
                </div>
                <pre className="p-3.5 bg-slate-900 text-slate-200 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto whitespace-pre-wrap max-h-64 border border-slate-800">
                  {amendmentDetails.letterBody}
                </pre>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setAmendmentLc(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-semibold hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleConfirmApplyAmendment}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Apply Amendment & Update LC Schedule</span>
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}
    </ModalWrapper>
  );
};
