import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  X, 
  Printer, 
  Search, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Landmark, 
  Wallet, 
  MapPin, 
  Download, 
  AlertCircle, 
  RotateCcw,
  ArrowUpDown,
  AlertTriangle
} from 'lucide-react';
import { BankAccount, JournalVoucher } from '../../types/erp';
import { AccountLedgerEntry } from '../../types/accounts';
import { getAccountTransactions, getAccountLedgers } from '../../services/accountService';
import { getCOA } from '../../utils/coaStorage';
import { isCashAccount } from '../../utils/bankAccountStorage';
import { getBankTransfers } from '../../utils/bankTransferStorage';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface AccountLedgerModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedAccount: BankAccount | null;
  allAccounts?: BankAccount[];
  vouchers?: JournalVoucher[];
  onSelectAccount: (account: BankAccount) => void;
}

interface NormalizedLedgerItem {
  id: string;
  voucherNumber: string;
  voucherType: string;
  voucherDate: string; // YYYY-MM-DD
  narration: string;
  debit: number;
  credit: number;
  counterparty: string;
  costCenter?: string;
  timestamp: number;
  runningBalance: number;
}

export const AccountLedgerModal: React.FC<AccountLedgerModalProps> = ({
  isOpen,
  onClose,
  selectedAccount,
  allAccounts = [],
  vouchers = [],
  onSelectAccount
}) => {
  // 1. Clean, minimalist state (From Date and To Date)
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'INFLOW' | 'OUTFLOW'>('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc'); // Default chronological (ascending)
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  React.useEffect(() => {
    return subscribeCompanyProfile(setCompanyProfile);
  }, []);

  // 2. Resolve Account Code intelligently with full safety
  const resolvedAccountCode = useMemo(() => {
    if (!selectedAccount) return '1020';
    try {
      if (selectedAccount.coaCode) return String(selectedAccount.coaCode);
      const nameLower = (selectedAccount.bankName || '').toLowerCase();
      
      const coaList = getCOA() || [];
      const exactMatch = coaList.find(c => 
        (c.name || '').toLowerCase() === nameLower || 
        (c.code && selectedAccount.accountNumber && c.code === selectedAccount.accountNumber)
      );
      if (exactMatch) return exactMatch.code;

      if (nameLower.includes('eastern')) return '1020';
      if (nameLower.includes('city bank')) return '1025';
      if (nameLower.includes('dutch') || nameLower.includes('dbbl')) return '1022';
      if (nameLower.includes('islami bank')) return '1026';
      if (nameLower.includes('standard chartered') || nameLower.includes('scb')) return '1028';
      if (nameLower.includes('burimari')) return '1011';
      if (nameLower.includes('sonahat')) return '1012';
      if (nameLower.includes('bholaganj')) return '1015';
      if (isCashAccount(selectedAccount)) return '1010';
      
      if (selectedAccount.accountNumber && selectedAccount.accountNumber.length === 4) {
        return selectedAccount.accountNumber;
      }
      return '1020';
    } catch {
      return '1020';
    }
  }, [selectedAccount]);

  // 3. Determine Normal Balance (Debit for Cash/Bank/Asset/Expense, Credit for Liability/Equity/Revenue)
  const isDebitNormal = useMemo(() => {
    try {
      const coaList = getCOA() || [];
      const head = coaList.find(c => c.code === resolvedAccountCode);
      if (head) return head.normalBalance !== 'Credit';
    } catch {
      // fallback
    }
    return true; // Cash & Bank default to Debit
  }, [resolvedAccountCode]);

  // 4. Extract and Aggregate all Ledger Transactions from Vouchers + Account Transactions + Ledgers
  const ledgerTransactions = useMemo(() => {
    if (!selectedAccount) {
      return {
        openingBalance: 0,
        totalDebits: 0,
        totalCredits: 0,
        closingBalance: 0,
        chronologicalList: [] as NormalizedLedgerItem[]
      };
    }

    const itemsMap = new Map<string, NormalizedLedgerItem>();
    const bankNameLower = (selectedAccount?.bankName || '').toLowerCase();

    // A. Extract from Journal Vouchers
    try {
      const safeVouchers = Array.isArray(vouchers) ? vouchers : [];
      safeVouchers.forEach(vch => {
        if (!vch || !Array.isArray(vch.items)) return;

        const matchedItems = vch.items.filter(it => {
          if (!it) return false;
          if (it.accountCode === resolvedAccountCode) return true;
          const itNameLower = (it.accountName || '').toLowerCase();
          if (bankNameLower && (itNameLower === bankNameLower || itNameLower.includes(bankNameLower) || bankNameLower.includes(itNameLower))) {
            return true;
          }
          if (selectedAccount?.accountCategory === 'Cash' && resolvedAccountCode.startsWith('101')) {
            return it.accountCode === resolvedAccountCode;
          }
          return false;
        });

        if (matchedItems.length > 0) {
          const otherItems = vch.items.filter(it => it && !matchedItems.includes(it));
          const counterparties = otherItems
            .map(it => it.accountName || it.accountCode || '')
            .filter(Boolean)
            .join(', ') || 'Offset Account';

          matchedItems.forEach((mItem, idx) => {
            const itemKey = `${vch.voucherNumber || vch.id || 'vch'}-${idx}`;
            const dateVal = vch.voucherDate ? vch.voucherDate.slice(0, 10) : new Date().toISOString().split('T')[0];
            const dVal = Number(mItem.debit) || 0;
            const cVal = Number(mItem.credit) || 0;
            itemsMap.set(itemKey, {
              id: `${vch.id || 'vch'}-${idx}`,
              voucherNumber: vch.voucherNumber || `VCH-${idx}`,
              voucherType: vch.voucherType || 'JV',
              voucherDate: dateVal,
              narration: vch.narration || '',
              debit: dVal,
              credit: cVal,
              counterparty: counterparties,
              costCenter: mItem.costCenter,
              timestamp: new Date(dateVal + 'T00:00:00').getTime() || 0,
              runningBalance: 0
            });
          });
        }
      });
    } catch (err) {
      console.warn('Ledger voucher parse note:', err);
    }

    // B. Extract from Account Transactions (Payment / Deposit)
    try {
      const allTxns = getAccountTransactions();
      if (Array.isArray(allTxns)) {
        allTxns.forEach(txn => {
          if (!txn) return;
          const isMatchedBank = (selectedAccount?.id && txn.bankAccountId === selectedAccount.id) || 
                                (bankNameLower && (txn.bankAccountName || '').toLowerCase().includes(bankNameLower)) ||
                                (txn.bankAccountNumber && selectedAccount?.accountNumber && txn.bankAccountNumber === selectedAccount.accountNumber);
          
          if (isMatchedBank && (txn.status as string) !== 'voided') {
            const alreadyExists = Array.from(itemsMap.values()).some(i => i.voucherNumber === txn.voucherNo);
            if (!alreadyExists) {
              const isPayment = txn.transactionType === 'PAYMENT';
              const dateVal = txn.date ? txn.date.slice(0, 10) : new Date().toISOString().split('T')[0];
              const amt = Number(txn.amount) || 0;
              itemsMap.set(txn.id || `txn-${Date.now()}`, {
                id: txn.id || `txn-${Date.now()}`,
                voucherNumber: txn.voucherNo || `TXN-${txn.id}`,
                voucherType: isPayment ? 'PV' : 'RV',
                voucherDate: dateVal,
                narration: txn.note || `${txn.subType || txn.transactionType}: ${txn.partyName || txn.accountHeadName || ''}`,
                debit: isPayment ? 0 : amt,
                credit: isPayment ? amt : 0,
                counterparty: txn.partyName || txn.accountHeadName || (isPayment ? 'Expense/Party' : 'Customer/Deposit'),
                costCenter: txn.costCenter,
                timestamp: new Date(dateVal + 'T00:00:00').getTime() || 0,
                runningBalance: 0
              });
            }
          }
        });
      }
    } catch (e) {
      console.warn('Error reading account transactions in ledger:', e);
    }

    // C. Extract from Account Ledgers
    try {
      const ledgers = getAccountLedgers();
      if (Array.isArray(ledgers)) {
        ledgers.forEach((led: AccountLedgerEntry) => {
            if (!led) return;
            const isMatch = (selectedAccount?.id && led.accountId === selectedAccount.id) || 
                            (bankNameLower && (led.accountName || '').toLowerCase().includes(bankNameLower));
            if (isMatch && led.accountType === 'Bank/Cash') {
              const alreadyExists = Array.from(itemsMap.values()).some(i => i.voucherNumber === led.voucherNo);
              if (!alreadyExists) {
                const dateVal = led.date ? led.date.slice(0, 10) : new Date().toISOString().split('T')[0];
                const dVal = Number(led.debit) || 0;
                const cVal = Number(led.credit) || 0;
                itemsMap.set(led.id || `led-${Date.now()}`, {
                  id: led.id || `led-${Date.now()}`,
                  voucherNumber: led.voucherNo || `LED-${led.id}`,
                  voucherType: dVal > 0 ? 'RV' : 'PV',
                  voucherDate: dateVal,
                  narration: led.description || '',
                  debit: dVal,
                  credit: cVal,
                  counterparty: 'General Offset',
                  timestamp: new Date(dateVal + 'T00:00:00').getTime() || 0,
                  runningBalance: 0
                });
              }
            }
          });
        }
    } catch (e) {
      console.warn('Error reading account ledger records:', e);
    }

    // D. Extract from Bank Transfers
    try {
      const transfers = getBankTransfers();
      if (Array.isArray(transfers)) {
        transfers.forEach(trf => {
          if (!trf) return;
          const fromName = (trf.fromAccountName || '').toLowerCase();
          const toName = (trf.toAccountName || '').toLowerCase();
          const isOutflow = trf.fromAccountCode === resolvedAccountCode || (bankNameLower && fromName.includes(bankNameLower));
          const isInflow = trf.toAccountCode === resolvedAccountCode || (bankNameLower && toName.includes(bankNameLower));
          
          if ((isOutflow || isInflow) && trf.status === 'Completed') {
            const alreadyExists = Array.from(itemsMap.values()).some(i => 
              i.voucherNumber === trf.voucherNumber || i.voucherNumber === trf.transferNumber
            );
            if (!alreadyExists) {
              const dateVal = trf.transferDate ? trf.transferDate.slice(0, 10) : new Date().toISOString().split('T')[0];
              const amt = Number(trf.amount) || 0;
              itemsMap.set(`trf-${trf.id}`, {
                id: trf.id,
                voucherNumber: trf.voucherNumber || trf.transferNumber || `TRF-${trf.id}`,
                voucherType: 'Contra',
                voucherDate: dateVal,
                narration: `Fund Transfer: ${trf.fromAccountName || ''} ➔ ${trf.toAccountName || ''} (${trf.transferMethod || 'Transfer'})`,
                debit: isInflow ? amt : 0,
                credit: isOutflow ? amt : 0,
                counterparty: isInflow ? (trf.fromAccountName || 'Sender A/C') : (trf.toAccountName || 'Receiver A/C'),
                timestamp: new Date(dateVal + 'T00:00:00').getTime() || 0,
                runningBalance: 0
              });
            }
          }
        });
      }
    } catch (e) {
      console.warn('Error reading bank transfers:', e);
    }

    // Convert to array and sort chronologically ascending
    const list = Array.from(itemsMap.values());
    list.sort((a, b) => {
      if (a.voucherDate !== b.voucherDate) {
        return a.voucherDate.localeCompare(b.voucherDate);
      }
      return a.timestamp - b.timestamp;
    });

    // Compute totals
    const totalDebits = list.reduce((sum, t) => sum + (Number(t.debit) || 0), 0);
    const totalCredits = list.reduce((sum, t) => sum + (Number(t.credit) || 0), 0);

    const currentBalance = Number(selectedAccount?.ledgerBalance) || 0;
    const computedOpeningBalance = isDebitNormal
      ? (currentBalance - totalDebits + totalCredits)
      : (currentBalance - totalCredits + totalDebits);

    let running = isNaN(computedOpeningBalance) ? 0 : computedOpeningBalance;
    const itemsWithRunning = list.map(item => {
      const d = Number(item.debit) || 0;
      const c = Number(item.credit) || 0;
      if (isDebitNormal) {
        running = running + d - c;
      } else {
        running = running + c - d;
      }
      return {
        ...item,
        runningBalance: isNaN(running) ? 0 : running
      };
    });

    return {
      openingBalance: isNaN(computedOpeningBalance) ? 0 : computedOpeningBalance,
      totalDebits,
      totalCredits,
      closingBalance: currentBalance,
      chronologicalList: itemsWithRunning
    };
  }, [vouchers, selectedAccount, resolvedAccountCode, isDebitNormal]);

  // 5. Date Range Summary Label
  const effectiveDateRangeLabel = useMemo(() => {
    if (startDate && endDate) {
      return `${startDate} to ${endDate}`;
    }
    if (startDate) {
      return `${startDate} to Present`;
    }
    if (endDate) {
      return `Beginning to ${endDate}`;
    }
    return 'All Time';
  }, [startDate, endDate]);

  // 6. Apply Filters (Type, Search, From Date, To Date)
  const filteredTransactions = useMemo(() => {
    const list = ledgerTransactions.chronologicalList.filter(t => {
      // Type filter
      if (filterType === 'INFLOW' && t.debit <= 0) return false;
      if (filterType === 'OUTFLOW' && t.credit <= 0) return false;

      // Pure string comparison on YYYY-MM-DD
      if (startDate && t.voucherDate < startDate) return false;
      if (endDate && t.voucherDate > endDate) return false;

      // Search filter
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchVch = (t.voucherNumber || '').toLowerCase().includes(q);
        const matchNar = (t.narration || '').toLowerCase().includes(q);
        const matchParty = (t.counterparty || '').toLowerCase().includes(q);
        const matchCostCenter = (t.costCenter || '').toLowerCase().includes(q);
        if (!matchVch && !matchNar && !matchParty && !matchCostCenter) return false;
      }

      return true;
    });

    if (sortOrder === 'desc') {
      return [...list].reverse();
    }
    return list;
  }, [ledgerTransactions, filterType, startDate, endDate, searchTerm, sortOrder]);

  // 7. Compute Period Specific Metrics (Opening Balance, Inflows, Outflows, Closing Balance)
  const periodMetrics = useMemo(() => {
    const chronological = ledgerTransactions.chronologicalList || [];

    // Calculate Opening Balance immediately prior to startDate
    let periodOpening = ledgerTransactions.openingBalance;
    if (startDate) {
      const priors = chronological.filter(t => t.voucherDate < startDate);
      if (priors.length > 0) {
        periodOpening = priors[priors.length - 1].runningBalance;
      }
    }

    // Period Inflows and Outflows
    const periodDebits = filteredTransactions.reduce((s, t) => s + (Number(t.debit) || 0), 0);
    const periodCredits = filteredTransactions.reduce((s, t) => s + (Number(t.credit) || 0), 0);

    const periodClosing = isDebitNormal
      ? (periodOpening + periodDebits - periodCredits)
      : (periodOpening + periodCredits - periodDebits);

    return {
      openingBalance: isNaN(periodOpening) ? 0 : periodOpening,
      totalDebits: periodDebits,
      totalCredits: periodCredits,
      closingBalance: isNaN(periodClosing) ? 0 : periodClosing
    };
  }, [startDate, filteredTransactions, ledgerTransactions, isDebitNormal]);

  // 8. Account Switcher Options
  const dropdownAccounts = useMemo(() => {
    const list = Array.isArray(allAccounts) ? [...allAccounts] : [];
    if (selectedAccount && !list.some(a => a?.id === selectedAccount.id)) {
      list.unshift(selectedAccount);
    }
    return list;
  }, [allAccounts, selectedAccount]);

  // 9. Validation: check if start date is after end date
  const isInvalidDateRange = Boolean(startDate && endDate && startDate > endDate);

  // 10. CSV Export Function
  const handleExportCSV = () => {
    const headers = [
      'Date', 
      'Voucher No', 
      'Type', 
      'Narration', 
      'Counterparty', 
      'Debit (BDT)', 
      'Credit (BDT)', 
      'Running Balance (BDT)'
    ];

    const openingRow = [
      startDate || '-',
      'OPENING',
      'Opening Balance',
      '"Opening Balance B/F"',
      '-',
      '0',
      '0',
      periodMetrics.openingBalance
    ];

    const rows = filteredTransactions.map(t => [
      t.voucherDate,
      t.voucherNumber,
      t.voucherType,
      `"${(t.narration || '').replace(/"/g, '""')}"`,
      `"${(t.counterparty || '').replace(/"/g, '""')}"`,
      t.debit,
      t.credit,
      t.runningBalance
    ]);

    const summaryRow = [
      endDate || '-',
      'CLOSING',
      'Closing Balance',
      '"Closing Balance C/F"',
      '-',
      periodMetrics.totalDebits,
      periodMetrics.totalCredits,
      periodMetrics.closingBalance
    ];

    const accName = selectedAccount?.bankName || 'Account';
    const dateRangeLabel = startDate || endDate
      ? `_${startDate || 'start'}_to_${endDate || 'today'}`
      : `_all_time_${new Date().toISOString().split('T')[0]}`;

    const metadataRows = [
      `"Account Ledger Report"`,
      `"Account Name: ${accName} [${resolvedAccountCode}]"`,
      `"Period: ${effectiveDateRangeLabel}"`,
      `"Opening Balance: BDT ${periodMetrics.openingBalance.toLocaleString()}"`,
      `"Total Inflow: BDT ${periodMetrics.totalDebits.toLocaleString()}"`,
      `"Total Outflow: BDT ${periodMetrics.totalCredits.toLocaleString()}"`,
      `"Closing Balance: BDT ${periodMetrics.closingBalance.toLocaleString()}"`,
      ''
    ];

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [
      ...metadataRows,
      headers.join(','), 
      openingRow.join(','),
      ...rows.map(e => e.join(',')),
      summaryRow.join(',')
    ].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Account_Ledger_${accName.replace(/\s+/g, '_')}${dateRangeLabel}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 11. Print Handler
  const handlePrint = () => {
    window.print();
  };

  if (!isOpen || !selectedAccount) return null;

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50 animate-in fade-in overflow-hidden h-screen print-modal-container print:p-0 print:bg-white print:static print:h-auto"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full p-4 sm:p-5 border border-slate-200 max-h-[96vh] flex flex-col overflow-hidden print-modal-container print:border-none print:shadow-none print:max-h-none print:p-0">
        
        {/* Printable Official Header (Only in Print View) */}
        <div className="hidden print:block pb-4 mb-3 border-b-2 border-slate-800 text-slate-900">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-xl font-black uppercase tracking-wider">{companyProfile.companyName}</h1>
              <p className="text-xs text-slate-600 font-sans">{companyProfile.address} | Mobile: {companyProfile.mobile}</p>
              <h2 className="text-sm font-bold mt-1 text-slate-800 uppercase underline decoration-1">
                Account Ledger & Bank Statement
              </h2>
            </div>
            <div className="text-right text-xs font-mono">
              <div>Period: <strong>{effectiveDateRangeLabel}</strong></div>
              <div>Printed On: {new Date().toLocaleDateString('en-GB')} {new Date().toLocaleTimeString('en-US')}</div>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-4 gap-2 text-xs bg-slate-50 p-2 border border-slate-300 rounded font-mono">
            <div>Account Name: <strong>{selectedAccount.bankName}</strong></div>
            <div>Account Code: <strong>{resolvedAccountCode}</strong></div>
            <div>Account No: <strong>{selectedAccount.accountNumber || '-'}</strong></div>
            <div>Currency / Type: <strong>{selectedAccount.currency || 'BDT'} ({selectedAccount.accountType || 'Current'})</strong></div>
          </div>
        </div>

        {/* Modal Header Bar (Screen Only) */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0 print:hidden">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-2xs shrink-0 ${
              selectedAccount.accountCategory === 'Cash' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
            }`}>
              {selectedAccount.accountCategory === 'Cash' ? <Wallet className="w-5 h-5" /> : <Landmark className="w-5 h-5" />}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-bold text-base text-slate-900 truncate">
                  {selectedAccount.bankName}
                </h3>
                <span className="font-mono text-[11px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800">
                  [{resolvedAccountCode}]
                </span>
                {selectedAccount.linkedPosLocation && (
                  <span className="text-[10px] bg-amber-100 text-amber-900 border border-amber-300 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    <MapPin className="w-2.5 h-2.5" />
                    <span>POS: {selectedAccount.linkedPosLocation}</span>
                  </span>
                )}
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                  {selectedAccount.currency || 'BDT'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 flex items-center gap-1.5 flex-wrap">
                <span>A/C: <strong className="font-mono text-slate-800">{selectedAccount.accountNumber || selectedAccount.coaCode || '-'}</strong></span>
                <span>•</span>
                <span>{selectedAccount.branch || selectedAccount.accountType || 'Main Branch'}</span>
                <span>•</span>
                <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded font-medium border border-blue-100">
                  {effectiveDateRangeLabel}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Quick Switch Account Dropdown */}
            <select
              value={selectedAccount.id}
              onChange={(e) => {
                const acc = dropdownAccounts.find(a => a.id === e.target.value);
                if (acc) onSelectAccount(acc);
              }}
              className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer max-w-[190px] sm:max-w-[220px] truncate"
            >
              {dropdownAccounts.map(a => (
                <option key={a.id} value={a.id}>
                  {a.bankName} ({a.currency || 'BDT'} {Number(a.ledgerBalance || 0).toLocaleString()})
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={handleExportCSV}
              className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Download CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">CSV</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Print"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print</span>
            </button>

            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 text-sm font-bold w-7 h-7 rounded-lg hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="space-y-3 sm:space-y-4 overflow-y-auto flex-1 pr-1 py-2 sm:py-3 text-xs print:overflow-visible">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 print:grid-cols-4 print:gap-2">
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5 sm:p-3 print:p-2">
              <span className="text-[10px] text-slate-500 uppercase font-mono block">Opening Balance:</span>
              <div className="text-sm sm:text-base font-mono font-bold text-slate-800 mt-0.5">
                {selectedAccount.currency || 'BDT'} {Number(periodMetrics.openingBalance || 0).toLocaleString()}
              </div>
              <span className="text-[10px] text-slate-400 font-sans block truncate">
                {startDate ? `Prior to ${startDate}` : 'Opening Balance'}
              </span>
            </div>

            <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-2.5 sm:p-3 print:p-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-emerald-800 uppercase font-mono font-bold">Total Inflow:</span>
                <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600 print:hidden" />
              </div>
              <div className="text-sm sm:text-base font-mono font-bold text-emerald-700 mt-0.5">
                + {selectedAccount.currency || 'BDT'} {Number(periodMetrics.totalDebits || 0).toLocaleString()}
              </div>
              <span className="text-[10px] text-emerald-600 font-sans block">
                Period Debits
              </span>
            </div>

            <div className="bg-rose-50/70 border border-rose-200 rounded-2xl p-2.5 sm:p-3 print:p-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-rose-800 uppercase font-mono font-bold">Total Outflow:</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-rose-600 print:hidden" />
              </div>
              <div className="text-sm sm:text-base font-mono font-bold text-rose-700 mt-0.5">
                - {selectedAccount.currency || 'BDT'} {Number(periodMetrics.totalCredits || 0).toLocaleString()}
              </div>
              <span className="text-[10px] text-rose-600 font-sans block">
                Period Credits
              </span>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-2.5 sm:p-3 print:p-2">
              <span className="text-[10px] text-blue-900 uppercase font-mono font-bold block">Closing Balance:</span>
              <div className="text-sm sm:text-base font-mono font-black text-blue-900 mt-0.5">
                {selectedAccount.currency || 'BDT'} {Number(periodMetrics.closingBalance || 0).toLocaleString()}
              </div>
              <span className="text-[10px] text-blue-700 font-sans block">
                {endDate ? `Balance as of ${endDate}` : 'Current Closing Balance'}
              </span>
            </div>
          </div>

          {/* Simple & Clean Filter Toolbar (Hidden in Print) */}
          <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 print:hidden space-y-2">
            <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-2.5 flex-wrap">
              
              {/* Search Box */}
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by voucher no, narration or party..."
                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:ring-2 focus:ring-blue-500 font-sans"
                />
              </div>

              {/* Clean Date Filter: Just From Date and To Date */}
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-1.5 bg-white px-2.5 py-1.5 rounded-xl border border-slate-300 shadow-2xs">
                  <label className="text-[11px] text-slate-600 font-bold shrink-0">From:</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="bg-transparent font-mono font-semibold text-slate-900 text-xs outline-none cursor-pointer"
                  />
                </div>

                <div className="flex items-center gap-1.5 bg-white px-2.5 py-1.5 rounded-xl border border-slate-300 shadow-2xs">
                  <label className="text-[11px] text-slate-600 font-bold shrink-0">To:</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="bg-transparent font-mono font-semibold text-slate-900 text-xs outline-none cursor-pointer"
                  />
                </div>

                {(startDate || endDate) && (
                  <button
                    type="button"
                    onClick={() => {
                      setStartDate('');
                      setEndDate('');
                    }}
                    className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                    title="Clear date filter"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                )}

                <span className="w-px h-5 bg-slate-300 mx-0.5 hidden sm:block" />

                {/* Sort Order Toggle */}
                <button
                  type="button"
                  onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                  className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  title={sortOrder === 'asc' ? 'Chronological (Oldest to Newest)' : 'Latest First (Newest to Oldest)'}
                >
                  <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  <span>{sortOrder === 'asc' ? 'Oldest First' : 'Newest First'}</span>
                </button>

                {/* Type Filters */}
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setFilterType('ALL')}
                    className={`px-2.5 py-1.5 rounded-xl transition-colors cursor-pointer text-xs ${
                      filterType === 'ALL'
                        ? 'bg-slate-900 text-white font-bold shadow-2xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    All ({filteredTransactions.length})
                  </button>

                  <button
                    type="button"
                    onClick={() => setFilterType('INFLOW')}
                    className={`px-2.5 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1 text-xs ${
                      filterType === 'INFLOW'
                        ? 'bg-emerald-600 text-white font-bold shadow-2xs'
                        : 'bg-white border border-slate-200 text-emerald-700 hover:bg-emerald-50'
                    }`}
                    title="View Inflows Only"
                  >
                    <ArrowDownLeft className="w-3 h-3" />
                    <span>Inflow</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFilterType('OUTFLOW')}
                    className={`px-2.5 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1 text-xs ${
                      filterType === 'OUTFLOW'
                        ? 'bg-rose-600 text-white font-bold shadow-2xs'
                        : 'bg-white border border-slate-200 text-rose-700 hover:bg-rose-50'
                    }`}
                    title="View Outflows Only"
                  >
                    <ArrowUpRight className="w-3 h-3" />
                    <span>Outflow</span>
                  </button>
                </div>

              </div>
            </div>

            {/* Validation Warning if start date > end date */}
            {isInvalidDateRange && (
              <div className="p-2 bg-rose-100 border border-rose-300 rounded-xl text-rose-800 text-[11px] font-bold flex items-center gap-1.5 animate-bounce">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Warning: Start date ({startDate}) cannot be after end date ({endDate}). Please select a valid date range.</span>
              </div>
            )}
          </div>

          {/* Ledger Table Container */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs print:border-slate-400">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100/90 text-slate-700 font-semibold border-b border-slate-200 print:bg-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Date & Voucher No</th>
                    <th className="py-2.5 px-3">Narration</th>
                    <th className="py-2.5 px-3">Offset Account</th>
                    <th className="py-2.5 px-3 text-right text-emerald-800">Debit (Dr)</th>
                    <th className="py-2.5 px-3 text-right text-rose-800">Credit (Cr)</th>
                    <th className="py-2.5 px-3 text-right">Running Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
                  
                  {/* Formal Opening Balance Row */}
                  <tr className="bg-slate-50/90 font-semibold text-slate-700 border-b border-slate-200">
                    <td className="py-2.5 px-3">
                      <span className="font-bold text-slate-900 block font-sans">Opening Balance</span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {startDate ? `Prior to ${startDate}` : 'Opening Balance'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-sans text-slate-600 italic">
                      Opening Balance Brought Forward
                    </td>
                    <td className="py-2.5 px-3 font-sans text-slate-400">
                      -
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-400">
                      -
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-400">
                      -
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900 bg-slate-100/70">
                      {selectedAccount.currency || 'BDT'} {Number(periodMetrics.openingBalance || 0).toLocaleString()}
                    </td>
                  </tr>

                  {/* Transaction Rows */}
                  {filteredTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400 font-sans">
                        <div className="flex flex-col items-center justify-center gap-1.5">
                          <AlertCircle className="w-6 h-6 text-slate-300" />
                          <p className="font-semibold text-slate-600">
                            No transactions found for the selected period ({effectiveDateRangeLabel}).
                          </p>
                          <p className="text-[11px] text-slate-400">
                            Try selecting a different date range or click "Reset" to view all transactions.
                          </p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    filteredTransactions.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-2.5 px-3">
                          <span className="font-bold text-blue-700 block">{tx.voucherNumber}</span>
                          <span className="text-[10px] text-slate-500 font-sans">{tx.voucherDate} ({tx.voucherType})</span>
                        </td>
                        <td className="py-2.5 px-3 font-sans text-slate-700">
                          <div className="font-medium text-slate-900">{tx.narration}</div>
                          {tx.costCenter && (
                            <span className="text-[10px] text-slate-400 block mt-0.5">
                              Cost Center: {tx.costCenter}
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-sans text-slate-600">
                          <span className="px-1.5 py-0.5 bg-slate-100 rounded text-[10px]">
                            {tx.counterparty}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-emerald-700">
                          {tx.debit > 0 ? `+ ${Number(tx.debit).toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-rose-600">
                          {tx.credit > 0 ? `- ${Number(tx.credit).toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                          {selectedAccount.currency || 'BDT'} {Number(tx.runningBalance || 0).toLocaleString()}
                        </td>
                      </tr>
                    ))
                  )}

                  {/* Summary Totals & Closing Balance Row */}
                  <tr className="bg-blue-50/70 font-bold border-t-2 border-slate-300 text-slate-900">
                    <td className="py-2.5 px-3 font-sans text-blue-900" colSpan={3}>
                      <span className="font-black">Total Period Movement & Closing Balance</span>
                      <span className="text-[10px] text-blue-700 font-mono block">
                        Period: {effectiveDateRangeLabel} (Total {filteredTransactions.length} Transactions)
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                      + {Number(periodMetrics.totalDebits || 0).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                      - {Number(periodMetrics.totalCredits || 0).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-black text-blue-950 bg-blue-100/80">
                      {selectedAccount.currency || 'BDT'} {Number(periodMetrics.closingBalance || 0).toLocaleString()}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Official Signatures Block (Only in Print View) */}
          <div className="hidden print:grid grid-cols-3 gap-6 pt-16 mt-8 text-center text-xs font-sans text-slate-800">
            <div>
              <div className="border-t border-slate-700 pt-1.5 font-bold">Prepared By</div>
              <div className="text-[10px] text-slate-500">Accountant</div>
            </div>
            <div>
              <div className="border-t border-slate-700 pt-1.5 font-bold">Audited & Checked By</div>
              <div className="text-[10px] text-slate-500">Internal Auditor</div>
            </div>
            <div>
              <div className="border-t border-slate-700 pt-1.5 font-bold">Authorized Signature</div>
              <div className="text-[10px] text-slate-500">Managing Director</div>
            </div>
          </div>
        </div>

        {/* Modal Footer (Screen Only) */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-3 border-t border-slate-100 shrink-0 print:hidden text-xs">
          <div className="text-[11px] text-slate-500 font-mono flex items-center gap-2 flex-wrap">
            <span>Account Code: <strong className="text-slate-800">{resolvedAccountCode}</strong></span>
            <span>•</span>
            <span>Period: <strong className="text-blue-700 font-bold">{effectiveDateRangeLabel}</strong></span>
            <span>•</span>
            <span>Selected Transactions: <strong className="text-slate-800">{filteredTransactions.length}</strong></span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>Download CSV</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-bold rounded-xl text-xs cursor-pointer transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5 text-blue-600" />
              <span>Print Report</span>
            </button>

            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs cursor-pointer transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};
