import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Building2, 
  Calendar, 
  ChevronDown, 
  FileText, 
  Loader2, 
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { 
  DepositSubType, 
  PaymentMethod, 
  AccountTransaction,
  AccountLedgerEntry
} from '../../types/accounts';
import { Customer, Supplier, BankAccount, AccountCOA, JournalVoucher } from '../../types/erp';
import { 
  postVoucher,
  getNextVoucherNumber, 
  saveAccountTransactions,
  getAccountTransactions 
} from '../../services/accountService';
import { getCustomers, updateCustomerBalance, formatCustomerBalance } from '../../utils/customerStorage';
import { getSuppliers, updateSupplierPayableBalance, formatSupplierBalance } from '../../utils/supplierStorage';
import { getBankAccounts, updateBankAccountBalance } from '../../utils/bankAccountStorage';
import { getCOA, saveCOA } from '../../utils/coaStorage';
import { addVoucher } from '../../utils/voucherStorage';
import { db } from '../../lib/firebase';
import { doc, writeBatch } from 'firebase/firestore';

export interface CreditLineItem {
  id: string;
  accountCode: string;
  particulars: string;
  amount: number;
}

interface DepositTransactionFormProps {
  onTransactionCreated?: (txn: AccountTransaction) => void;
  onNavigateToHistory?: () => void;
}

export const DepositTransactionForm: React.FC<DepositTransactionFormProps> = ({
  onTransactionCreated,
  onNavigateToHistory
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  // 1. Deposit Type (Segmented control)
  // 'General Deposit' · 'Customer Collection' · 'Supplier Refund'
  const [depositType, setDepositType] = useState<DepositSubType>('General Deposit');

  // Form Fields
  const [voucherNumber, setVoucherNumber] = useState<string>('RV-....');
  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [costCenter, setCostCenter] = useState<string>('');
  const [depositedIntoAccountId, setDepositedIntoAccountId] = useState<string>('');
  const [depositMethod, setDepositMethod] = useState<PaymentMethod>('' as any);
  const [referenceNo, setReferenceNo] = useState<string>('');
  const [narration, setNarration] = useState<string>('');
  const [branch, setBranch] = useState<string>(currentUser?.branch || 'Corporate Headquarters (Dhaka)');

  // Multi-line Credit Items for 'General Deposit' (starts empty with one blank line with 0 amount)
  const [creditLines, setCreditLines] = useState<CreditLineItem[]>([
    {
      id: 'line-1',
      accountCode: '',
      particulars: '',
      amount: 0
    }
  ]);

  // Customer selection for 'Deposit from Customer' (Customer Collection)
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customerSearch, setCustomerSearch] = useState<string>('');
  const [customerDropdownOpen, setCustomerDropdownOpen] = useState<boolean>(false);
  const [customerAmount, setCustomerAmount] = useState<string>('');
  const [customerParticulars, setCustomerParticulars] = useState<string>('');

  // Supplier selection for 'Deposit from Supplier' (Supplier Refund)
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [supplierSearch, setSupplierSearch] = useState<string>('');
  const [supplierDropdownOpen, setSupplierDropdownOpen] = useState<boolean>(false);
  const [supplierAmount, setSupplierAmount] = useState<string>('');
  const [supplierParticulars, setSupplierParticulars] = useState<string>('');

  // Lists
  const [coaList, setCoaList] = useState<AccountCOA[]>(() => getCOA());
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  const [customers, setCustomers] = useState<Customer[]>(() => getCustomers());
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => getSuppliers());

  // UI status
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<{ voucherNo: string; amount: number; message: string } | null>(null);

  // Sync Branch from logged-in user
  useEffect(() => {
    if (currentUser?.branch) {
      setBranch(currentUser.branch);
    }
  }, [currentUser]);

  // Fetch initial voucher number (RV series)
  const fetchVoucherNumber = async () => {
    try {
      const vNo = await getNextVoucherNumber('DEPOSIT', 'RV');
      setVoucherNumber(vNo);
    } catch {
      setVoucherNumber(`RV-${Date.now().toString().slice(-4)}`);
    }
  };

  useEffect(() => {
    fetchVoucherNumber();
  }, []);

  // Filter COA for Revenue, Capital, Liability (Income / Loan heads)
  const incomeHeads = useMemo(() => {
    return coaList.filter(c => 
      c.category === 'Revenue' || 
      c.category === 'Equity' || 
      c.category === 'Liability' || 
      c.code.startsWith('4') || 
      c.code.startsWith('3') ||
      c.code.startsWith('203')
    );
  }, [coaList]);

  // Selected Bank / Cash Account
  const selectedBankAccount = useMemo(() => {
    return bankAccounts.find(b => b.id === depositedIntoAccountId);
  }, [bankAccounts, depositedIntoAccountId]);

  // Selected Customer & Supplier
  const selectedCustomer = useMemo(() => {
    return customers.find(c => c.id === selectedCustomerId);
  }, [customers, selectedCustomerId]);

  const selectedSupplier = useMemo(() => {
    return suppliers.find(s => s.id === selectedSupplierId);
  }, [suppliers, selectedSupplierId]);

  // Filtered dropdowns
  const filteredCustomers = useMemo(() => {
    if (!customerSearch.trim()) return customers;
    const q = customerSearch.toLowerCase();
    return customers.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.code?.toLowerCase().includes(q) || 
      c.phone?.toLowerCase().includes(q)
    );
  }, [customers, customerSearch]);

  const filteredSuppliers = useMemo(() => {
    if (!supplierSearch.trim()) return suppliers;
    const q = supplierSearch.toLowerCase();
    return suppliers.filter(s => 
      s.name.toLowerCase().includes(q) || 
      s.code?.toLowerCase().includes(q) || 
      s.country?.toLowerCase().includes(q)
    );
  }, [suppliers, supplierSearch]);

  // Calculate Total Amount
  const totalAmount = useMemo(() => {
    if (depositType === 'General Deposit') {
      return creditLines.reduce((sum, line) => sum + (Number(line.amount) || 0), 0);
    } else if (depositType === 'Deposit from Customer') {
      return Number(customerAmount) || 0;
    } else if (depositType === 'Deposit from Supplier') {
      return Number(supplierAmount) || 0;
    }
    return 0;
  }, [depositType, creditLines, customerAmount, supplierAmount]);

  // Requirement 3: Real Double-Entry Balanced Check
  const totalDebits = totalAmount;
  const totalCredits = useMemo(() => {
    if (depositType === 'General Deposit') {
      return creditLines.reduce((sum, line) => sum + (Number(line.amount) || 0), 0);
    }
    return totalAmount;
  }, [depositType, creditLines, totalAmount]);

  const isBalanced = totalAmount > 0 && Math.abs(totalDebits - totalCredits) < 0.001;

  // Multi-line Credit handlers
  const handleAddLine = () => {
    setCreditLines(prev => [
      ...prev,
      {
        id: `line-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        accountCode: '',
        particulars: '',
        amount: 0
      }
    ]);
  };

  const handleRemoveLine = (id: string) => {
    if (creditLines.length <= 1) return;
    setCreditLines(prev => prev.filter(l => l.id !== id));
  };

  const handleUpdateLine = (id: string, updates: Partial<CreditLineItem>) => {
    setCreditLines(prev =>
      prev.map(l => {
        if (l.id === id) {
          const updated = { ...l, ...updates };
          if (updates.accountCode && updates.accountCode !== l.accountCode) {
            const head = coaList.find(c => c.code === updates.accountCode);
            if (head) {
              updated.particulars = head.name;
            }
          }
          return updated;
        }
        return l;
      })
    );
  };

  // Quick Presets
  const handleApplySalesRecoveryPreset = () => {
    setCreditLines([
      { id: `line-1-${Date.now()}`, accountCode: '4010', particulars: 'Sales Revenue / Due Recovery', amount: 0 }
    ]);
    setNarration('Sales due collection from customer');
  };

  const handleApplyCapitalPreset = () => {
    setCreditLines([
      { id: `line-1-${Date.now()}`, accountCode: '3010', particulars: 'Owner Capital Injection', amount: 0 }
    ]);
    setNarration('Owner capital injection into business operations');
  };

  const handleApplyByProductPreset = () => {
    setCreditLines([
      { id: `line-1-${Date.now()}`, accountCode: '4020', particulars: 'Stone Dust & By-Product Sales Collection', amount: 0 }
    ]);
    setNarration('Cash collection from site stone dust and by-product sales');
  };

  // SUBMIT & POST VOUCHER (Requirement 1, 2, 3, 4, 8)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (totalAmount <= 0) {
      setErrorMessage('Amount must be greater than 0.');
      return;
    }

    if (!selectedBankAccount) {
      setErrorMessage('Please select a Deposited To account.');
      return;
    }

    if (!isBalanced) {
      setErrorMessage(
        `Balance check failed: Debit and Credit amounts do not match (Debit: ৳${totalDebits.toLocaleString()}, Credit: ৳${totalCredits.toLocaleString()}).`
      );
      return;
    }

    // Validation for Customer
    if (depositType === 'Deposit from Customer' && !selectedCustomerId) {
      setErrorMessage('Please select a customer.');
      return;
    }

    // Validation for Supplier
    if (depositType === 'Deposit from Supplier' && !selectedSupplierId) {
      setErrorMessage('Please select a supplier.');
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Post to single-source Firestore via postVoucher
      const postedTxn = await postVoucher({
        transactionType: 'DEPOSIT',
        subType: depositType,
        date,
        amount: totalAmount,
        bankAccountId: selectedBankAccount.id,
        paymentMethod: depositMethod,
        referenceNo: referenceNo.trim() || undefined,
        note: narration.trim() || undefined,
        costCenter: depositType === 'General Deposit' ? costCenter : undefined,
        branch,
        partyType: depositType === 'Deposit from Customer' ? 'Customer' : depositType === 'Deposit from Supplier' ? 'Supplier' : 'None',
        partyId: depositType === 'Deposit from Customer' ? selectedCustomer?.id : depositType === 'Deposit from Supplier' ? selectedSupplier?.id : undefined,
        partyName: depositType === 'Deposit from Customer' ? selectedCustomer?.name : depositType === 'Deposit from Supplier' ? selectedSupplier?.name : undefined,
        partyCode: depositType === 'Deposit from Customer' ? selectedCustomer?.code : depositType === 'Deposit from Supplier' ? selectedSupplier?.code : undefined,
        partyPhone: depositType === 'Deposit from Customer' ? selectedCustomer?.phone : depositType === 'Deposit from Supplier' ? selectedSupplier?.paymentTerms : undefined,
        creditLines: depositType === 'General Deposit'
          ? creditLines.filter(l => Number(l.amount) > 0).map(l => ({ accountCode: l.accountCode, particulars: l.particulars, amount: Number(l.amount) }))
          : undefined,
        user: {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || 'Authorized User',
          email: currentUser?.email || 'admin@tradecore.local'
        }
      });

      // 2. Also record in local Journal Voucher list for voucher browser
      const jvId = `jv-${Date.now()}`;
      const newJournalVoucher: JournalVoucher = {
        id: jvId,
        voucherNumber: postedTxn.voucherNo,
        voucherType: 'RV',
        voucherDate: date,
        referenceType: depositType === 'General Deposit' ? 'Manual' : (depositType === 'Deposit from Customer' ? 'Sales' : 'Purchase'),
        ...(referenceNo.trim() ? { referenceNo: referenceNo.trim() } : {}),
        narration: narration.trim() || `${depositType} against ${postedTxn.voucherNo}`,
        items: [
          {
            accountCode: selectedBankAccount.coaCode || '1020',
            accountName: selectedBankAccount.bankName,
            debit: totalAmount,
            credit: 0,
            costCenter
          }
        ],
        totalDebit: totalAmount,
        totalCredit: totalAmount,
        postedBy: currentUser?.name || 'Authorized User',
        status: 'Approved & Posted'
      };
      addVoucher(newJournalVoucher);

      // Refresh states
      setBankAccounts(getBankAccounts());
      setCustomers(getCustomers());
      setSuppliers(getSuppliers());

      // Show success info
      setSuccessInfo({
        voucherNo: postedTxn.voucherNo,
        amount: totalAmount,
        message: `Receipt voucher ${postedTxn.voucherNo} posted to General Ledger!`
      });

      // Full Reset form to pristine empty state
      setDepositedIntoAccountId('');
      setCostCenter('');
      setDepositMethod('' as any);
      setNarration('');
      setCreditLines([
        {
          id: 'line-1',
          accountCode: '',
          particulars: '',
          amount: 0
        }
      ]);
      setSelectedCustomerId('');
      setCustomerSearch('');
      setCustomerAmount('');
      setCustomerParticulars('');

      setSelectedSupplierId('');
      setSupplierSearch('');
      setSupplierAmount('');
      setSupplierParticulars('');
      setReferenceNo('');
      setErrorMessage(null);
      fetchVoucherNumber();

      if (onTransactionCreated) {
        onTransactionCreated(postedTxn);
      }
    } catch (err: any) {
      console.error('Deposit posting error:', err);
      setErrorMessage(err.message || 'Failed to post voucher. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 border-t-2 border-t-emerald-600 rounded-xl shadow-xs p-5 md:p-6 text-slate-800">
      {/* Success Notification Bar */}
      {successInfo && (
        <div className="mb-5 p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between gap-3 text-xs text-emerald-800">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>{successInfo.voucherNo}</strong>: {successInfo.message} (Total ৳ {successInfo.amount.toLocaleString()})
            </span>
          </div>
          <div className="flex items-center gap-2">
            {onNavigateToHistory && (
              <button
                type="button"
                onClick={onNavigateToHistory}
                className="px-3 py-1 bg-white hover:bg-emerald-100 text-emerald-700 border border-emerald-300 rounded-lg font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>View History</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
            <button
              type="button"
              onClick={() => setSuccessInfo(null)}
              className="text-emerald-600 hover:text-emerald-900 font-bold px-1.5 py-0.5 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Top Bar: Title, Voucher No, Date */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Deposit Receipt (RV)
          </h2>
          <span className="font-mono text-xs bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-md border border-slate-200 font-semibold tracking-wider">
            {voucherNumber}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-500 font-medium">Date:</label>
          <div className="relative">
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 font-medium focus:outline-none focus:border-emerald-500 focus:bg-white transition-colors"
            />
          </div>
        </div>
      </div>

      {/* Segmented Type Selector: 3 Neutral Options */}
      <div className="my-4">
        <div className="bg-slate-100 p-1 rounded-xl grid grid-cols-3 gap-1 max-w-xl">
          <button
            type="button"
            onClick={() => setDepositType('General Deposit')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all text-center cursor-pointer ${
              depositType === 'General Deposit'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            General Deposit
          </button>

          <button
            type="button"
            onClick={() => setDepositType('Deposit from Customer')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all text-center cursor-pointer ${
              depositType === 'Deposit from Customer'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Customer Collection
          </button>

          <button
            type="button"
            onClick={() => setDepositType('Deposit from Supplier')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all text-center cursor-pointer ${
              depositType === 'Deposit from Supplier'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Supplier Refund
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} autoComplete="off" className="space-y-5">
        {/* MIDDLE SECTION 1: General Deposit Multi-Line Credit */}
        {depositType === 'General Deposit' && (
          <div className="space-y-3">
            {/* Presets row & Cost center */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5 text-xs">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-slate-500 text-[11px] font-medium mr-1">Quick Presets:</span>
                <button
                  type="button"
                  onClick={handleApplySalesRecoveryPreset}
                  className="px-2 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[11px] transition-colors cursor-pointer"
                >
                  Sales Due Recovery
                </button>
                <button
                  type="button"
                  onClick={handleApplyCapitalPreset}
                  className="px-2 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[11px] transition-colors cursor-pointer"
                >
                  Owner Capital Injection
                </button>
                <button
                  type="button"
                  onClick={handleApplyByProductPreset}
                  className="px-2 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[11px] transition-colors cursor-pointer"
                >
                  By-Product Sales
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-slate-500 text-[11px] font-medium shrink-0">Cost Center:</span>
                <select
                  value={costCenter}
                  onChange={e => setCostCenter(e.target.value)}
                  className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:border-emerald-500"
                >
                  <option value="">Select Cost Center...</option>
                  <option value="Corporate Headquarters (Dhaka)">Head Office (Dhaka)</option>
                  <option value="Sonahat Crushing Plant">Sonahat Crushing Plant</option>
                  <option value="Burimari Port Depot">Burimari Port Depot</option>
                </select>
              </div>
            </div>

            {/* Credit Lines Minimal List */}
            <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50/50">
              <div className="grid grid-cols-12 gap-2 px-3.5 py-2 bg-slate-100/70 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <div className="col-span-1 text-center">#</div>
                <div className="col-span-5">Credit Account Head</div>
                <div className="col-span-3">Particulars / Note</div>
                <div className="col-span-2 text-right">Amount (৳)</div>
                <div className="col-span-1 text-center">Action</div>
              </div>

              <div className="divide-y divide-slate-200/60 p-1.5 space-y-1">
                {creditLines.map((line, idx) => (
                  <div key={line.id} className="grid grid-cols-12 gap-2 items-center px-2 py-1 bg-white rounded-lg border border-slate-100 shadow-2xs">
                    <div className="col-span-1 text-center font-mono text-xs text-slate-400">
                      {idx + 1}
                    </div>

                    <div className="col-span-5">
                      <select
                        value={line.accountCode}
                        onChange={e => handleUpdateLine(line.id, { accountCode: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white"
                      >
                        <option value="">-- Select Account Head --</option>
                        {incomeHeads.map(head => (
                          <option key={head.code} value={head.code}>
                            {head.code} - {head.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="col-span-3">
                      <input
                        type="text"
                        value={line.particulars}
                        onChange={e => handleUpdateLine(line.id, { particulars: e.target.value })}
                        placeholder="Particulars..."
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white"
                      />
                    </div>

                    <div className="col-span-2">
                      <input
                        type="number"
                        min="0"
                        value={line.amount || ''}
                        onChange={e => {
                          const val = e.target.value;
                          handleUpdateLine(line.id, { amount: val === '' ? 0 : parseFloat(val) || 0 });
                        }}
                        onFocus={e => {
                          if (line.amount === 0) e.target.select();
                        }}
                        placeholder="0"
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono font-semibold text-right text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                      />
                    </div>

                    <div className="col-span-1 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveLine(line.id)}
                        disabled={creditLines.length <= 1}
                        className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                          creditLines.length <= 1 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'
                        }`}
                        title="Remove line"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="px-3.5 py-2 border-t border-slate-200 bg-white flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleAddLine}
                  className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Add Line</span>
                </button>
                <span className="text-xs text-slate-500">
                  Subtotal: <strong className="font-mono text-slate-900">৳ {totalAmount.toLocaleString()}</strong>
                </span>
              </div>
            </div>
          </div>
        )}

        {/* MIDDLE SECTION 2: Customer Collection */}
        {depositType === 'Deposit from Customer' && (
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3.5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Customer Selector */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Customer *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={selectedCustomer ? `${selectedCustomer.code} - ${selectedCustomer.name}` : customerSearch}
                    onChange={e => {
                      setCustomerSearch(e.target.value);
                      if (selectedCustomerId) setSelectedCustomerId('');
                      setCustomerDropdownOpen(true);
                    }}
                    onFocus={() => setCustomerDropdownOpen(true)}
                    placeholder="Search customer by name, code or phone..."
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-emerald-500 shadow-2xs"
                  />
                  {customerDropdownOpen && (
                    <div className="absolute top-full left-0 right-0 mt-1 max-h-52 overflow-y-auto bg-white border border-slate-200 rounded-lg shadow-lg z-30 divide-y divide-slate-100">
                      {filteredCustomers.length === 0 ? (
                        <div className="p-3 text-xs text-slate-400 text-center">No customer found</div>
                      ) : (
                        filteredCustomers.map(c => (
                          <div
                            key={c.id}
                            onClick={() => {
                              setSelectedCustomerId(c.id);
                              setCustomerSearch(`${c.code} - ${c.name}`);
                              setCustomerDropdownOpen(false);
                            }}
                            className="p-2.5 hover:bg-slate-50 cursor-pointer text-xs flex items-center justify-between"
                          >
                            <div>
                              <span className="font-bold text-slate-800">{c.name}</span>
                              <span className="text-slate-400 ml-2 font-mono text-[11px]">({c.code})</span>
                              <div className="text-[11px] text-slate-500">{c.phone || c.address}</div>
                            </div>
                            <div className="text-right">
                              {(() => {
                                const bal = formatCustomerBalance(c.currentBalance || 0);
                                return (
                                  <>
                                    <span className={`text-xs font-mono font-semibold ${bal.isAdvance ? 'text-emerald-700' : (bal.isDue ? 'text-rose-700' : 'text-slate-600')}`}>
                                      {bal.amountText}
                                    </span>
                                    <span className={`text-[10px] block font-medium ${bal.isAdvance ? 'text-emerald-600' : 'text-slate-400'}`}>
                                      {bal.isAdvance ? 'Advance' : (bal.isDue ? 'Receivable' : 'Settled')}
                                    </span>
                                  </>
                                );
                              })()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Amount */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Received Amount (৳) *
                </label>
                <input
                  type="number"
                  min="1"
                  value={customerAmount}
                  onChange={e => setCustomerAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-emerald-500 shadow-2xs"
                />
              </div>
            </div>

            {/* Inline Balance & Particulars */}
            {selectedCustomer && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 bg-white border border-slate-200 rounded-lg text-xs">
                <div>
                  <span className="text-slate-500">Current Balance: </span>
                  {(() => {
                    const bal = formatCustomerBalance(selectedCustomer.currentBalance || 0);
                    return (
                      <strong className={`font-mono ${bal.isAdvance ? 'text-emerald-700' : (bal.isDue ? 'text-rose-700' : 'text-slate-900')}`}>
                        {bal.text}
                      </strong>
                    );
                  })()}
                </div>
                {selectedCustomer.currentBalance > 0 && (
                  <button
                    type="button"
                    onClick={() => setCustomerAmount((selectedCustomer.currentBalance || 0).toString())}
                    className="text-[11px] text-emerald-600 hover:text-emerald-700 font-bold underline cursor-pointer"
                  >
                    Receive Full Due (৳ {(selectedCustomer.currentBalance || 0).toLocaleString()})
                  </button>
                )}
              </div>
            )}

            <div>
              <label className="text-xs text-slate-600 block mb-1">Particulars / Note (Optional):</label>
              <input
                type="text"
                value={customerParticulars}
                onChange={e => setCustomerParticulars(e.target.value)}
                placeholder="Customer due collection or advance deposit details..."
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        )}

        {/* MIDDLE SECTION 3: Supplier Refund */}
        {depositType === 'Deposit from Supplier' && (
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3.5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Supplier Selector */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Supplier *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={selectedSupplier ? `${selectedSupplier.code} - ${selectedSupplier.name}` : supplierSearch}
                    onChange={e => {
                      setSupplierSearch(e.target.value);
                      if (selectedSupplierId) setSelectedSupplierId('');
                      setSupplierDropdownOpen(true);
                    }}
                    onFocus={() => setSupplierDropdownOpen(true)}
                    placeholder="Search supplier by name or code..."
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-emerald-500 shadow-2xs"
                  />
                  {supplierDropdownOpen && (
                    <div className="absolute top-full left-0 right-0 mt-1 max-h-52 overflow-y-auto bg-white border border-slate-200 rounded-lg shadow-lg z-30 divide-y divide-slate-100">
                      {filteredSuppliers.length === 0 ? (
                        <div className="p-3 text-xs text-slate-400 text-center">No supplier found</div>
                      ) : (
                        filteredSuppliers.map(s => (
                          <div
                            key={s.id}
                            onClick={() => {
                              setSelectedSupplierId(s.id);
                              setSupplierSearch(`${s.code} - ${s.name}`);
                              setSupplierDropdownOpen(false);
                            }}
                            className="p-2.5 hover:bg-slate-50 cursor-pointer text-xs flex items-center justify-between"
                          >
                            <div>
                              <span className="font-bold text-slate-800">{s.name}</span>
                              <span className="text-slate-400 ml-2 font-mono text-[11px]">({s.code})</span>
                              <div className="text-[11px] text-slate-500">{s.country || 'Importer'}</div>
                            </div>
                            <div className="text-right">
                              {(() => {
                                const bal = formatSupplierBalance(s.currentPayable || 0);
                                return (
                                  <>
                                    <span className={`text-xs font-mono font-semibold ${bal.isAdvance ? 'text-emerald-700' : (bal.isPayable ? 'text-rose-700' : 'text-slate-600')}`}>
                                      {bal.amountText}
                                    </span>
                                    <span className={`text-[10px] block font-medium ${bal.isAdvance ? 'text-emerald-600' : 'text-slate-400'}`}>
                                      {bal.isAdvance ? 'Advance' : (bal.isPayable ? 'Payable' : 'Settled')}
                                    </span>
                                  </>
                                );
                              })()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Amount */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Refund Amount (৳) *
                </label>
                <input
                  type="number"
                  min="1"
                  value={supplierAmount}
                  onChange={e => setSupplierAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-emerald-500 shadow-2xs"
                />
              </div>
            </div>

            {/* Inline Balance */}
            {selectedSupplier && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 bg-white border border-slate-200 rounded-lg text-xs">
                <div>
                  <span className="text-slate-500">Current Balance: </span>
                  {(() => {
                    const bal = formatSupplierBalance(selectedSupplier.currentPayable || 0);
                    return (
                      <strong className={`font-mono ${bal.isAdvance ? 'text-emerald-700' : (bal.isPayable ? 'text-rose-700' : 'text-slate-900')}`}>
                        {bal.text}
                      </strong>
                    );
                  })()}
                </div>
                <div className="text-[11px] text-slate-500">
                  Control Head: <span className="font-mono text-slate-700">2010 - Accounts Payable</span>
                </div>
              </div>
            )}

            <div>
              <label className="text-xs text-slate-600 block mb-1">Particulars / Note (Optional):</label>
              <input
                type="text"
                value={supplierParticulars}
                onChange={e => setSupplierParticulars(e.target.value)}
                placeholder="Supplier refund details..."
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        )}

        {/* BOTTOM SECTION: Deposited To, Method, Ref, Narration */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 pt-2">
          {/* Deposited To Account */}
          <div className="md:col-span-1">
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Deposited To *
            </label>
            <select
              value={depositedIntoAccountId}
              onChange={e => setDepositedIntoAccountId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 font-medium focus:outline-none focus:border-emerald-500 focus:bg-white"
            >
              <option value="">Select Account...</option>
              {bankAccounts.map(b => (
                <option key={b.id} value={b.id}>
                  {b.bankName} ({b.accountNumber}) — ৳ {(b.ledgerBalance || 0).toLocaleString()}
                </option>
              ))}
            </select>
            {selectedBankAccount && (
              <span className="text-[11px] text-slate-500 mt-1 block">
                Current Balance: <strong className="font-mono text-slate-700">৳ {(selectedBankAccount.ledgerBalance || 0).toLocaleString()}</strong>
              </span>
            )}
          </div>

          {/* Deposit Method */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Deposit Method
            </label>
            <select
              value={depositMethod}
              onChange={e => setDepositMethod(e.target.value as PaymentMethod)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white"
            >
              <option value="">Select Deposit Method...</option>
              <option value="Cash">Cash</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cheque">Cheque</option>
              <option value="Mobile Banking">Mobile Banking (bKash / Nagad)</option>
            </select>
          </div>

          {/* Reference / Slip No */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Reference / Slip No (Optional)
            </label>
            <input
              type="text"
              value={referenceNo}
              onChange={e => setReferenceNo(e.target.value)}
              placeholder="e.g. SLIP-9901 or CHQ-Cit-12"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white"
            />
          </div>
        </div>

        {/* Narration */}
        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1">
            Narration / Description
          </label>
          <textarea
            rows={2}
            value={narration}
            onChange={e => setNarration(e.target.value)}
            placeholder="Receipt voucher narration..."
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white resize-none"
          />
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* FOOTER BAR: Total, Balanced Indicator, Save & Post Button */}
        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-4">
            <div>
              <span className="text-[11px] text-slate-500 block">Total Amount:</span>
              <span className="text-lg font-bold text-slate-900 font-mono">
                ৳ {totalAmount.toLocaleString()}
              </span>
            </div>

            <div className="h-7 w-px bg-slate-200" />

            {/* Requirement 3: Real Double-Entry Balanced Check Display */}
            {isBalanced ? (
              <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-medium bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Balanced (Dr = Cr)</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-rose-700 font-medium bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Unbalanced (Dr: ৳{totalDebits.toLocaleString()} ≠ Cr: ৳{totalCredits.toLocaleString()})</span>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={isSubmitting || totalAmount <= 0 || !isBalanced}
            className={`px-6 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer ${
              isSubmitting || totalAmount <= 0 || !isBalanced
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Posting to GL...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Save & Post Voucher</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
