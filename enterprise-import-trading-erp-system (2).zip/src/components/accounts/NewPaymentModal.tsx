import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  X, 
  CheckCircle2, 
  Calendar, 
  Building2, 
  DollarSign, 
  Plus, 
  Trash2, 
  Wallet, 
  Landmark, 
  FileText, 
  User, 
  Check
} from 'lucide-react';
import { AccountCOA, BankAccount, JournalVoucher } from '../../types/erp';
import { AccountSearchSelect } from './AccountSearchSelect';
import { postVoucher } from '../../services/accountService';
import { useAuth } from '../../contexts/AuthContext';
import { ModalWrapper } from '../common/ModalWrapper';

export interface PaymentDebitLine {
  id: string;
  accountCode: string;
  particulars: string;
  amount: number;
}

interface NewPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  coaList: AccountCOA[];
  bankAccounts: BankAccount[];
  onSavePayment: (data: {
    voucherDate: string;
    paidFromAccount: string; // Bank or Cash account code
    paymentMethod: 'Cash' | 'Cheque' | 'Bank Transfer' | 'Online';
    chequeNo?: string;
    chequeDate?: string;
    paidTo: string;
    narration: string;
    costCenter: string;
    debitLines: { accountCode: string; particulars: string; amount: number }[];
  }) => void;
}

export const NewPaymentModal: React.FC<NewPaymentModalProps> = ({
  isOpen,
  onClose,
  coaList,
  bankAccounts,
  onSavePayment
}) => {
  const [voucherDate, setVoucherDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [paidFromAccount, setPaidFromAccount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Cheque' | 'Bank Transfer' | 'Online'>('' as any);
  const [chequeNo, setChequeNo] = useState('');
  const [chequeDate, setChequeDate] = useState('');
  const [paidTo, setPaidTo] = useState('');
  const [costCenter, setCostCenter] = useState('');
  const [narration, setNarration] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Multiple debit expense lines (starts empty with one blank line)
  const [debitLines, setDebitLines] = useState<PaymentDebitLine[]>([
    {
      id: 'line-1',
      accountCode: '',
      particulars: '',
      amount: '' as any
    }
  ]);

  const resetForm = () => {
    setPaidFromAccount('');
    setPaymentMethod('' as any);
    setChequeNo('');
    setChequeDate('');
    setPaidTo('');
    setCostCenter('');
    setNarration('');
    setDebitLines([
      {
        id: `line-${Date.now()}`,
        accountCode: '',
        particulars: '',
        amount: '' as any
      }
    ]);
  };

  const isDirty = Boolean(
    paidFromAccount || paidTo || costCenter || narration ||
    debitLines.some(l => l.accountCode || l.particulars || (Number(l.amount) > 0))
  );

  const handleSafeClose = () => {
    if (isSubmitting) return;
    resetForm();
    onClose();
  };

  useEffect(() => {
    if (isOpen) {
      setVoucherDate(new Date().toISOString().split('T')[0]);
      resetForm();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const totalAmount = debitLines.reduce((sum, l) => sum + (Number(l.amount) || 0), 0);

  const handleAddLine = () => {
    setDebitLines(prev => [
      ...prev,
      {
        id: `line-${Date.now()}`,
        accountCode: '',
        particulars: '',
        amount: '' as any
      }
    ]);
  };

  const handleRemoveLine = (id: string) => {
    if (debitLines.length <= 1) return;
    setDebitLines(prev => prev.filter(l => l.id !== id));
  };

  const handleUpdateLine = (id: string, field: keyof PaymentDebitLine, value: any) => {
    setDebitLines(prev => prev.map(l => {
      if (l.id === id) {
        return { ...l, [field]: value };
      }
      return l;
    }));
  };

  const { currentUser } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (totalAmount <= 0) {
      alert('Please enter a valid total payment amount.');
      return;
    }
    if (!paidTo.trim()) {
      alert('Please enter the recipient or payee name (Paid To).');
      return;
    }

    setIsSubmitting(true);
    try {
      const sourceBank = bankAccounts.find(b => (b.coaCode || '1020') === paidFromAccount || b.id === paidFromAccount) || bankAccounts[0];
      if (sourceBank) {
        await postVoucher({
          transactionType: 'PAYMENT',
          subType: 'Expense / General Payment',
          date: voucherDate,
          amount: totalAmount,
          bankAccountId: sourceBank.id,
          paymentMethod,
          referenceNo: chequeNo || undefined,
          note: narration.trim() || `Payment to ${paidTo.trim()}`,
          costCenter,
          branch: 'Corporate Head Office',
          debitLines: debitLines.filter(l => Number(l.amount) > 0).map(l => ({ accountCode: l.accountCode, particulars: l.particulars, amount: Number(l.amount) })),
          user: {
            uid: currentUser?.uid || 'user-admin',
            name: currentUser?.name || 'Authorized User',
            email: currentUser?.email || 'admin@tradecore.local'
          },
          adminApprovedOverdraft: true
        });
      }

      onSavePayment({
        voucherDate,
        paidFromAccount,
        paymentMethod,
        chequeNo: paymentMethod === 'Cheque' ? chequeNo : undefined,
        chequeDate: paymentMethod === 'Cheque' ? chequeDate : undefined,
        paidTo: paidTo.trim(),
        narration: narration.trim() || `Payment to ${paidTo.trim()}`,
        costCenter,
        debitLines
      });
      resetForm();
      onClose();
    } catch (err: any) {
      console.error('Payment post error in modal:', err);
      alert(err.message || 'Failed to post payment voucher.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Find selected source account details
  const selectedSourceAccount = bankAccounts.find(b => (b.coaCode || '1020') === paidFromAccount) ||
    bankAccounts[0];

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleSafeClose}
      isDirty={isDirty}
      isSaving={isSubmitting}
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-slate-900 to-rose-950 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600/30 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white flex items-center gap-2">
                <span>New Payment Voucher</span>
              </h3>
            </div>
          </div>
          <button 
            type="button"
            data-modal-close="true"
            disabled={isSubmitting}
            onClick={handleSafeClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer disabled:opacity-50 shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} autoComplete="off" className="flex-1 flex flex-col min-h-0 overflow-hidden">
          <div className="p-5 sm:p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1 overscroll-contain">
            {/* Top Grid: Date, Payment Source, Method */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Payment Date */}
              <div>
                <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  <span>Payment Date *</span>
                </label>
                <input
                  type="date"
                  required
                  value={voucherDate}
                  onChange={(e) => setVoucherDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-medium focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              {/* Paid From (Source Account) */}
              <div>
                <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                  <Landmark className="w-3.5 h-3.5 text-rose-600" />
                  <span>Paid From *</span>
                </label>
                <select
                  value={paidFromAccount}
                  onChange={(e) => setPaidFromAccount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-bold bg-white focus:ring-2 focus:ring-rose-500 focus:outline-none"
                >
                  <option value="">Select Account...</option>
                  {bankAccounts.map(b => (
                    <option key={b.id} value={b.coaCode || '1020'}>
                      {b.bankName} - {b.accountNumber} (Balance: ৳{b.ledgerBalance.toLocaleString()})
                    </option>
                  ))}
                  <option value="1010">Cash in Hand - Main Cash Drawer (1010)</option>
                  <option value="1012">Burimari Yard Petty Cash (1012)</option>
                  <option value="1014">Sonahat Crushing Petty Cash (1014)</option>
                </select>
              </div>

              {/* Payment Method */}
              <div>
                <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                  <Wallet className="w-3.5 h-3.5 text-slate-500" />
                  <span>Payment Method *</span>
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-medium bg-white focus:ring-2 focus:ring-rose-500 focus:outline-none"
                >
                  <option value="">Select Payment Method...</option>
                  <option value="Bank Transfer">Bank Transfer / BEFTN / RTGS</option>
                  <option value="Cheque">Bank Cheque</option>
                  <option value="Cash">Cash</option>
                  <option value="Online">Online / Mobile Banking</option>
                </select>
              </div>
            </div>

            {/* Cheque details (conditional) */}
            {paymentMethod === 'Cheque' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-amber-50 p-3 rounded-xl border border-amber-200">
                <div>
                  <label className="block font-semibold text-amber-900 mb-1">
                    Cheque Number *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. CQ-992104"
                    value={chequeNo}
                    onChange={(e) => setChequeNo(e.target.value)}
                    className="w-full px-3 py-2 border border-amber-300 rounded-xl bg-white font-mono font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-amber-900 mb-1">
                    Cheque Maturity Date
                  </label>
                  <input
                    type="date"
                    value={chequeDate}
                    onChange={(e) => setChequeDate(e.target.value)}
                    className="w-full px-3 py-2 border border-amber-300 rounded-xl bg-white text-slate-900"
                  />
                </div>
              </div>
            )}

            {/* Recipient & Cost Center */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-slate-500" />
                  <span>Paid To / Payee *</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Padma Oil Company / Labor Contractor Quader"
                  value={paidTo}
                  onChange={(e) => setPaidTo(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-medium focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-slate-500" />
                  <span>Cost Center / Project</span>
                </label>
                <select
                  value={costCenter}
                  onChange={(e) => setCostCenter(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-medium bg-white focus:ring-2 focus:ring-rose-500 focus:outline-none"
                >
                  <option value="">Select Cost Center...</option>
                  <option value="Head Office">Head Office</option>
                  <option value="Sonahat Yard">Sonahat Crushing Yard</option>
                  <option value="Burimari Plant">Burimari Land Port Unit</option>
                  <option value="Chittagong WH">Chittagong Port Terminal</option>
                  <option value="Central Transport">Transport & Logistics Fleet</option>
                </select>
              </div>
            </div>

            {/* Debit Lines Section (Expenses / Vendor Accounts) */}
            <div className="pt-2 border-t border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-xs text-slate-900 block">
                    Expense / Debit Accounts
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleAddLine}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 text-rose-600" />
                  <span>Add Line</span>
                </button>
              </div>

              <div className="space-y-2">
                {debitLines.map((line, index) => (
                  <div key={line.id} className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center gap-2.5">
                    <span className="text-[10px] font-mono font-bold bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded shrink-0">
                      #{index + 1}
                    </span>

                    {/* Account Head Selector */}
                    <div className="flex-1 w-full sm:w-auto">
                      <AccountSearchSelect
                        label=""
                        coaList={coaList.filter(c => c.category === 'Expense' || c.category === 'Liability' || c.category === 'Asset')}
                        selectedCode={line.accountCode}
                        onSelect={(code: string) => handleUpdateLine(line.id, 'accountCode', code)}
                        placeholder="Select Account Head..."
                        typeBadge="Dr"
                      />
                    </div>

                    {/* Particulars Note */}
                    <div className="w-full sm:w-44">
                      <input
                        type="text"
                        placeholder="Particulars"
                        value={line.particulars}
                        onChange={(e) => handleUpdateLine(line.id, 'particulars', e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-300 rounded-xl bg-white text-xs text-slate-900"
                      />
                    </div>

                    {/* Amount Input */}
                    <div className="w-full sm:w-32 flex items-center gap-1">
                      <span className="text-slate-400 font-mono text-xs">৳</span>
                      <input
                        type="number"
                        min="1"
                        required
                        value={line.amount || ''}
                        onChange={(e) => handleUpdateLine(line.id, 'amount', Number(e.target.value))}
                        placeholder="Amount"
                        className="w-full px-2.5 py-1.5 border border-slate-300 rounded-xl bg-white text-xs font-bold font-mono text-slate-900 text-right"
                      />
                    </div>

                    {/* Delete Line Button */}
                    {debitLines.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveLine(line.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer self-end sm:self-center"
                        title="Remove Line"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Narration Note */}
            <div>
              <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-slate-500" />
                <span>General Narration / Notes</span>
              </label>
              <textarea
                rows={2}
                value={narration}
                onChange={(e) => setNarration(e.target.value)}
                placeholder="e.g. Payment to Labor Contractor Quader for Sonahat stone crushing labor bill..."
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Fixed Bottom Action Bar with Total Calculation */}
          <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Total Payment Amount:</span>
              <span className="text-base font-bold font-mono text-rose-600">
                BDT {totalAmount.toLocaleString()}
              </span>
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
              <button
                type="button"
                data-modal-close="true"
                onClick={handleSafeClose}
                disabled={isSubmitting}
                className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold shadow-xs cursor-pointer flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <Check className="w-4 h-4" />
                <span>{isSubmitting ? 'Saving...' : 'Save Payment Voucher'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
