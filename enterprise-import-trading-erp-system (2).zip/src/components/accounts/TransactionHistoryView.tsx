import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Calendar, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Download, 
  Printer, 
  Eye, 
  Trash2, 
  Edit3, 
  ShieldAlert, 
  Building2, 
  Wallet, 
  CheckCircle2, 
  RotateCcw, 
  ChevronDown,
  Layers,
  FileSpreadsheet,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { 
  AccountTransaction, 
  TransactionType, 
  PaymentSubType, 
  DepositSubType 
} from '../../types/accounts';
import { 
  getAccountTransactions, 
  voidAccountTransaction, 
  editAccountTransaction,
  subscribeAccountTransactions 
} from '../../services/accountService';
import { VoucherPrintModal } from './VoucherPrintModal';
import { getBankAccounts } from '../../utils/bankAccountStorage';
import { getAccountHeads } from '../../services/accountService';
import { PrintHeader, PrintSignatures } from '../common/PrintHeader';
import { ModalWrapper } from '../common/ModalWrapper';

interface TransactionHistoryViewProps {
  onOpenPaymentForm?: () => void;
  onOpenDepositForm?: () => void;
}

export const TransactionHistoryView: React.FC<TransactionHistoryViewProps> = ({
  onOpenPaymentForm,
  onOpenDepositForm
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  const [transactions, setTransactions] = useState<AccountTransaction[]>(() => getAccountTransactions());
  const bankAccounts = useMemo(() => getBankAccounts(), []);
  const accountHeads = useMemo(() => getAccountHeads(), []);

  useEffect(() => {
    const unsub = subscribeAccountTransactions(setTransactions);
    return () => unsub();
  }, []);

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterType, setFilterType] = useState<'ALL' | 'PAYMENT' | 'DEPOSIT'>('ALL');
  const [filterSubType, setFilterSubType] = useState<string>('ALL');
  const [filterBank, setFilterBank] = useState<string>('ALL');
  const [filterBranch, setFilterBranch] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'active' | 'voided'>('ALL');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');

  // Modals state
  const [viewVoucher, setViewVoucher] = useState<AccountTransaction | null>(null);
  
  // Void Modal State
  const [voidTarget, setVoidTarget] = useState<AccountTransaction | null>(null);
  const [voidReason, setVoidReason] = useState<string>('');
  const [voidSubmitting, setVoidSubmitting] = useState<boolean>(false);
  const [voidError, setVoidError] = useState<string | null>(null);

  // Edit Modal State (Admin Only)
  const [editTarget, setEditTarget] = useState<AccountTransaction | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('');
  const [editRefNo, setEditRefNo] = useState<string>('');
  const [editNote, setEditNote] = useState<string>('');
  const [editReason, setEditReason] = useState<string>('');
  const [editSubmitting, setEditSubmitting] = useState<boolean>(false);
  const [editError, setEditError] = useState<string | null>(null);

  const handleCloseVoidModal = () => {
    if (voidSubmitting) return;
    setVoidTarget(null);
    setVoidReason('');
    setVoidError(null);
  };

  const handleCloseEditModal = () => {
    if (editSubmitting) return;
    setEditTarget(null);
    setEditReason('');
    setEditError(null);
  };

  // Filter Transactions Logic
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      // Type Filter
      if (filterType !== 'ALL' && t.transactionType !== filterType) return false;

      // SubType Filter
      if (filterSubType !== 'ALL' && t.subType !== filterSubType) return false;

      // Bank Account Filter
      if (filterBank !== 'ALL' && t.bankAccountId !== filterBank) return false;

      // Branch Filter
      if (filterBranch !== 'ALL' && t.branch !== filterBranch) return false;

      // Status Filter
      if (filterStatus !== 'ALL' && t.status !== filterStatus) return false;

      // Date Range Filter
      if (dateFrom && t.date < dateFrom) return false;
      if (dateTo && t.date > dateTo) return false;

      // Search Query
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchesVoucher = t.voucherNo.toLowerCase().includes(q);
        const matchesParty = t.partyName?.toLowerCase().includes(q);
        const matchesHead = t.accountHeadName?.toLowerCase().includes(q);
        const matchesBank = t.bankAccountName?.toLowerCase().includes(q);
        const matchesRef = t.referenceNo?.toLowerCase().includes(q);
        const matchesNote = t.note?.toLowerCase().includes(q);
        if (!matchesVoucher && !matchesParty && !matchesHead && !matchesBank && !matchesRef && !matchesNote) {
          return false;
        }
      }

      return true;
    });
  }, [transactions, filterType, filterSubType, filterBank, filterBranch, filterStatus, dateFrom, dateTo, searchTerm]);

  // Aggregate Totals for Filtered Results (excluding voided from financial totals)
  const totals = useMemo(() => {
    let totalPayment = 0;
    let totalDeposit = 0;

    filteredTransactions.forEach(t => {
      if (t.status === 'active') {
        if (t.transactionType === 'PAYMENT') {
          totalPayment += t.amount;
        } else if (t.transactionType === 'DEPOSIT') {
          totalDeposit += t.amount;
        }
      }
    });

    const netCashFlow = totalDeposit - totalPayment;
    return { totalPayment, totalDeposit, netCashFlow };
  }, [filteredTransactions]);

  // Void Handler
  const handleConfirmVoid = async () => {
    if (!voidTarget) return;
    if (!voidReason.trim()) {
      setVoidError('Void reason is required');
      return;
    }

    setVoidSubmitting(true);
    setVoidError(null);

    try {
      await voidAccountTransaction(
        voidTarget.id,
        voidReason.trim(),
        {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || currentUser?.displayName || 'Admin'
        }
      );

      // Refresh list
      setTransactions(getAccountTransactions());
      setVoidTarget(null);
      setVoidReason('');
    } catch (err: any) {
      setVoidError(err.message || 'Could not void voucher');
    } finally {
      setVoidSubmitting(false);
    }
  };

  // Open Edit Modal
  const handleOpenEdit = (t: AccountTransaction) => {
    setEditTarget(t);
    setEditAmount(t.amount.toString());
    setEditDate(t.date);
    setEditRefNo(t.referenceNo || '');
    setEditNote(t.note || '');
    setEditReason('');
    setEditError(null);
  };

  // Confirm Edit Handler
  const handleConfirmEdit = async () => {
    if (!editTarget) return;
    const numAmt = parseFloat(editAmount);
    if (!numAmt || numAmt <= 0) {
      setEditError('Amount must be greater than 0');
      return;
    }
    if (!editReason.trim()) {
      setEditError('Edit reason is required');
      return;
    }

    setEditSubmitting(true);
    setEditError(null);

    try {
      await editAccountTransaction(
        editTarget.id,
        {
          date: editDate,
          amount: numAmt,
          referenceNo: editRefNo,
          note: editNote
        },
        {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || currentUser?.displayName || 'Admin'
        },
        editReason.trim()
      );

      setTransactions(getAccountTransactions());
      setEditTarget(null);
    } catch (err: any) {
      setEditError(err.message || 'Failed to update voucher');
    } finally {
      setEditSubmitting(false);
    }
  };

  // Export to CSV Function
  const handleExportCSV = () => {
    if (filteredTransactions.length === 0) return;

    const headers = ['Voucher No', 'Date', 'Type', 'Sub Type', 'Party/Head', 'Bank Account', 'Amount (BDT)', 'Branch', 'Status', 'Ref No', 'Note'];
    const rows = filteredTransactions.map(t => [
      t.voucherNo,
      t.date,
      t.transactionType,
      t.subType,
      t.partyName || t.accountHeadName || '',
      t.bankAccountName,
      t.amount,
      t.branch,
      t.status,
      t.referenceNo || '',
      t.note || ''
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + 
      [headers.join(','), ...rows.map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Transaction_History_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Official Print Header for Transactions */}
      <PrintHeader
        title="Payment & Deposit General Transaction Ledger"
        subtitle="Consolidated Double-Entry Cash & Bank Voucher Journal"
        periodLabel={dateFrom || dateTo ? `${dateFrom || 'Beginning'} to ${dateTo || 'Today'}` : 'All Recorded Transactions'}
        metadata={[
          { label: 'Total Transactions', value: `${filteredTransactions.length} Vouchers` },
          { label: 'Total Payment (Dr)', value: `৳${totals.totalPayment.toLocaleString()}` },
          { label: 'Total Deposit (Cr)', value: `৳${totals.totalDeposit.toLocaleString()}` },
          { label: 'Net Cash Flow', value: `৳${totals.netCashFlow.toLocaleString()}` }
        ]}
      />

      {/* Top Header Card (Hidden when printing) */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 no-print print:hidden">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <span>Transaction History</span>
          </h2>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {onOpenPaymentForm && (
            <button
              type="button"
              onClick={onOpenPaymentForm}
              className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowUpRight className="w-4 h-4 text-rose-600" />
              <span>+ New Payment</span>
            </button>
          )}

          {onOpenDepositForm && (
            <button
              type="button"
              onClick={onOpenDepositForm}
              className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
              <span>+ New Deposit</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-600" />
            <span>CSV</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="px-3.5 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Print Transaction Ledger"
          >
            <Printer className="w-4 h-4 text-blue-600" />
            <span>Print Ledger</span>
          </button>
        </div>
      </div>

      {/* KPI Financial Totals Cards for Filtered Results */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white border border-rose-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600">Total Payment</span>
            <span className="p-1.5 rounded-lg bg-rose-50 text-rose-600 font-bold text-xs">PV Outflow</span>
          </div>
          <div className="mt-2 text-xl font-mono font-bold text-rose-700">
            ৳{totals.totalPayment.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
        </div>

        <div className="bg-white border border-emerald-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600">Total Deposit</span>
            <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 font-bold text-xs">DV Inflow</span>
          </div>
          <div className="mt-2 text-xl font-mono font-bold text-emerald-700">
            ৳{totals.totalDeposit.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600">Net Cash Flow</span>
            <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600 font-bold text-xs">Deposit - Payment</span>
          </div>
          <div className={`mt-2 text-xl font-mono font-bold ${totals.netCashFlow >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            ৳{totals.netCashFlow.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
        </div>
      </div>

      {/* Filter and Search Toolbar (Hidden when printing) */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 shadow-sm space-y-3 no-print print:hidden">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Voucher no., party, head, reference..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl bg-white text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Type Filter */}
          <div>
            <select
              value={filterType}
              onChange={(e) => {
                setFilterType(e.target.value as any);
                setFilterSubType('ALL');
              }}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All Payments & Deposits</option>
              <option value="PAYMENT">Payments Only (PV)</option>
              <option value="DEPOSIT">Deposits Only (DV)</option>
            </select>
          </div>

          {/* Bank / Cash Filter */}
          <div>
            <select
              value={filterBank}
              onChange={(e) => setFilterBank(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All Bank & Cash Accounts</option>
              {bankAccounts.map(b => (
                <option key={b.id} value={b.id}>
                  {b.bankName}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All Statuses (Active & Voided)</option>
              <option value="active">Active Only</option>
              <option value="voided">Voided Only</option>
            </select>
          </div>
        </div>

        {/* Date Filter Row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
            <span className="text-slate-500 font-semibold">Date Range:</span>
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-xs text-slate-800"
            />
            <span className="text-slate-400">to</span>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-xs text-slate-800"
            />
            {(dateFrom || dateTo || searchTerm || filterType !== 'ALL' || filterBank !== 'ALL' || filterStatus !== 'ALL') && (
              <button
                type="button"
                onClick={() => {
                  setDateFrom('');
                  setDateTo('');
                  setSearchTerm('');
                  setFilterType('ALL');
                  setFilterSubType('ALL');
                  setFilterBank('ALL');
                  setFilterStatus('ALL');
                }}
                className="px-2.5 py-1 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg font-semibold cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>

          <div className="text-slate-500 font-medium">
            Total Results: <span className="font-bold text-slate-900">{filteredTransactions.length}</span> Vouchers
          </div>
        </div>
      </div>

      {/* Transactions Table Card */}
      <div className="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px] border-b border-slate-200">
              <tr>
                <th className="p-3.5">Voucher No.</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Type</th>
                <th className="p-3.5">Party / Account Head</th>
                <th className="p-3.5">Bank / Cash Account</th>
                <th className="p-3.5 text-right">Amount (৳ BDT)</th>
                <th className="p-3.5">Branch</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 text-right no-print print:hidden">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredTransactions.map((t) => {
                const isPayment = t.transactionType === 'PAYMENT';
                const isVoided = t.status === 'voided';

                return (
                  <tr 
                    key={t.id}
                    className={`transition-colors cursor-pointer ${
                      isVoided 
                        ? 'bg-slate-50/70 opacity-60 line-through text-slate-400' 
                        : 'hover:bg-slate-50 text-slate-800'
                    }`}
                    onClick={() => setViewVoucher(t)}
                  >
                    {/* Voucher No */}
                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5 font-mono font-bold">
                        <span className={`px-2 py-0.5 rounded-md text-[11px] ${
                          isPayment 
                            ? 'bg-rose-100 text-rose-800' 
                            : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {t.voucherNo}
                        </span>
                      </div>
                    </td>

                    {/* Date */}
                    <td className="p-3.5 whitespace-nowrap text-slate-600 font-medium">
                      {t.date}
                    </td>

                    {/* SubType Badge */}
                    <td className="p-3.5">
                      <div className="flex items-center gap-1 font-semibold">
                        {isPayment ? (
                          <ArrowUpRight className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                        ) : (
                          <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        )}
                        <span>{t.subType}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block font-normal mt-0.5">
                        {t.paymentMethod} {t.referenceNo ? `• Ref: ${t.referenceNo}` : ''}
                      </span>
                    </td>

                    {/* Party or Head */}
                    <td className="p-3.5">
                      {t.partyName ? (
                        <div>
                          <span className="font-bold text-slate-900 block">{t.partyName}</span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {t.partyType} ({t.partyCode || ''})
                          </span>
                        </div>
                      ) : (
                        <div>
                          <span className="font-semibold text-slate-900 block">{t.accountHeadName}</span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {t.accountHeadCode || 'Head'}
                          </span>
                        </div>
                      )}
                    </td>

                    {/* Bank / Cash Account */}
                    <td className="p-3.5">
                      <span className="font-medium text-slate-800 block text-xs">{t.bankAccountName}</span>
                    </td>

                    {/* Amount */}
                    <td className="p-3.5 text-right font-mono font-bold text-sm">
                      <span className={isPayment ? 'text-rose-700' : 'text-emerald-700'}>
                        {isPayment ? '-' : '+'}৳{t.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </span>
                    </td>

                    {/* Branch */}
                    <td className="p-3.5 whitespace-nowrap text-slate-600 text-xs">
                      {t.branch}
                    </td>

                    {/* Status Badge */}
                    <td className="p-3.5 text-center">
                      {isVoided ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-700" title={t.voidReason}>
                          Voided
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          Active
                        </span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="p-3.5 text-right no-print print:hidden" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        {/* View / Print */}
                        <button
                          type="button"
                          onClick={() => setViewVoucher(t)}
                          title="View / Print Voucher"
                          className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* Admin Only: Edit Action */}
                        {isAdmin && !isVoided && (
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(t)}
                            title="Edit Transaction (Admin Only)"
                            className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        )}

                        {/* Admin Only: Void Action */}
                        {isAdmin && !isVoided && (
                          <button
                            type="button"
                            onClick={() => {
                              setVoidTarget(t);
                              setVoidReason('');
                              setVoidError(null);
                            }}
                            title="Void Voucher (Admin Only)"
                            className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredTransactions.length === 0 && (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400">
                    <p className="font-semibold text-sm">No transactions found</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Signatures Block (Print Only) */}
      <PrintSignatures
        preparedByRole="Junior Accountant"
        auditedByRole="Senior Auditor"
        approvedByRole="Head of Finance"
      />

      {/* A4 Print Voucher Modal */}
      <VoucherPrintModal
        isOpen={!!viewVoucher}
        onClose={() => setViewVoucher(null)}
        transaction={viewVoucher}
      />

      {/* Admin Only: Void Transaction Modal */}
      {voidTarget && (
        <ModalWrapper
          isOpen={!!voidTarget}
          onClose={handleCloseVoidModal}
          isDirty={Boolean(voidReason.trim())}
          isSaving={voidSubmitting}
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
        >
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 relative">
            <button
              type="button"
              data-modal-close="true"
              disabled={voidSubmitting}
              onClick={handleCloseVoidModal}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-lg disabled:opacity-50 cursor-pointer"
            >
              ✕
            </button>
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-800 flex items-center justify-center mx-auto">
              <ShieldAlert className="w-6 h-6 text-rose-600" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-slate-900">
                Void Voucher
              </h3>
              <p className="text-xs text-slate-600">
                Vouchers cannot be deleted per accounting policy. Voiding this voucher will automatically reverse all related bank and party ledgers.
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1 font-mono">
              <div className="flex justify-between">
                <span>Voucher No.:</span>
                <span className="font-bold text-slate-900">{voidTarget.voucherNo}</span>
              </div>
              <div className="flex justify-between">
                <span>Amount:</span>
                <span className="font-bold text-rose-600">৳{voidTarget.amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Party / Head:</span>
                <span>{voidTarget.partyName || voidTarget.accountHeadName}</span>
              </div>
            </div>

            <div className="space-y-1.5 text-xs">
              <label className="block font-bold text-slate-800">
                Void Reason <span className="text-rose-500">*</span>
              </label>
              <textarea
                required
                rows={3}
                placeholder="Enter a clear reason for voiding this voucher (saved in audit trail)..."
                value={voidReason}
                onChange={(e) => setVoidReason(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>

            {voidError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
                {voidError}
              </div>
            )}

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                data-modal-close="true"
                disabled={voidSubmitting}
                onClick={handleCloseVoidModal}
                className="flex-1 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmVoid}
                disabled={voidSubmitting}
                className="flex-1 py-2.5 px-3 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs transition-colors shadow-sm flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {voidSubmitting ? 'Processing...' : 'Confirm Void'}
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* Admin Only: Edit Transaction Modal */}
      {editTarget && (
        <ModalWrapper
          isOpen={!!editTarget}
          onClose={handleCloseEditModal}
          isDirty={Boolean(
            editDate !== editTarget.date ||
            String(editAmount) !== String(editTarget.amount) ||
            editRefNo !== (editTarget.referenceNo || '') ||
            editNote !== (editTarget.note || '') ||
            editReason.trim()
          )}
          isSaving={editSubmitting}
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
        >
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 max-h-[92vh] overflow-y-auto">
            <div className="sticky top-0 z-10 bg-white flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Edit Voucher (Admin Only)
                </h3>
                <span className="text-xs font-mono font-bold text-blue-600">{editTarget.voucherNo}</span>
              </div>
              <button
                type="button"
                data-modal-close="true"
                disabled={editSubmitting}
                onClick={handleCloseEditModal}
                className="text-slate-400 hover:text-slate-700 p-1 disabled:opacity-50 shrink-0 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="block font-bold text-slate-800">Date</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={(e) => setEditDate(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <label className="block font-bold text-slate-800">Amount (৳)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editAmount}
                  onChange={(e) => setEditAmount(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-xl font-mono font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="block font-bold text-slate-800">Reference / Cheque No.</label>
                <input
                  type="text"
                  value={editRefNo}
                  onChange={(e) => setEditRefNo(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <label className="block font-bold text-slate-800">Note</label>
                <input
                  type="text"
                  value={editNote}
                  onChange={(e) => setEditNote(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <label className="block font-bold text-slate-800">
                  Reason for Edit <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Reason for change will be recorded in the audit log..."
                  value={editReason}
                  onChange={(e) => setEditReason(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>

            {editError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
                {editError}
              </div>
            )}

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                data-modal-close="true"
                disabled={editSubmitting}
                onClick={handleCloseEditModal}
                className="flex-1 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmEdit}
                disabled={editSubmitting}
                className="flex-1 py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-colors shadow-sm cursor-pointer disabled:opacity-50"
              >
                {editSubmitting ? 'Updating...' : 'Save Changes'}
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
