import React from 'react';
import { Printer, X, CheckCircle2, Building2, Calendar, CreditCard, ShieldAlert } from 'lucide-react';
import { AccountTransaction } from '../../types/accounts';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface VoucherPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: AccountTransaction | null;
}

export const VoucherPrintModal: React.FC<VoucherPrintModalProps> = ({
  isOpen,
  onClose,
  transaction
}) => {
  const [companyProfile, setCompanyProfile] = React.useState(() => getCompanyProfile());

  React.useEffect(() => {
    return subscribeCompanyProfile(setCompanyProfile);
  }, []);

  if (!isOpen || !transaction) return null;

  const isPayment = transaction.transactionType === 'PAYMENT';

  const handlePrint = () => {
    window.print();
  };

  // Convert numbers to simple wording
  const formatTakaWords = (num: number): string => {
    return `${num.toLocaleString('en-IN')} Taka Only`;
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 my-auto">
        {/* Top Action Bar (hidden in print) */}
        <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold font-mono px-2 py-0.5 rounded bg-slate-800 text-rose-400">
              {transaction.voucherNo}
            </span>
            <span className="text-xs font-medium text-slate-300">
              {isPayment ? 'Payment Voucher Details' : 'Deposit Voucher Details'}
            </span>
            {transaction.status === 'voided' && (
              <span className="text-[10px] font-bold bg-rose-900/80 text-rose-300 px-2 py-0.5 rounded">
                VOIDED
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Voucher</span>
            </button>
            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area (Styled for Clean A4 Voucher) */}
        <div className="p-6 sm:p-8 space-y-6 text-slate-900 bg-white" id="printable-voucher">
          {/* Header */}
          <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1">
            <h1 className="text-2xl font-black tracking-tight text-slate-950 uppercase">
              {companyProfile.companyName}
            </h1>
            <p className="text-xs text-slate-600 font-medium">
              {companyProfile.address}
            </p>
            <p className="text-[11px] text-slate-500 font-mono">
              Mobile: {companyProfile.mobile}
            </p>
            <div className="pt-2">
              <span className={`inline-block px-4 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                isPayment 
                  ? 'bg-rose-100 text-rose-900 border border-rose-300' 
                  : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
              }`}>
                {isPayment ? 'DEBIT VOUCHER' : 'CREDIT VOUCHER'}
              </span>
            </div>
          </div>

          {/* Void Watermark if voided */}
          {transaction.status === 'voided' && (
            <div className="p-3 bg-rose-50 border-2 border-dashed border-rose-300 rounded-xl text-center">
              <span className="text-sm font-black text-rose-800 uppercase tracking-widest block">
                *** VOIDED TRANSACTION ***
              </span>
              <span className="text-xs text-rose-600">
                Reason: {transaction.voidReason} (Date: {transaction.voidedAt?.split('T')[0]})
              </span>
            </div>
          )}

          {/* Meta Info Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
            <div>
              <span className="text-slate-500 font-medium block">Voucher No:</span>
              <span className="font-mono font-bold text-slate-950 text-sm">{transaction.voucherNo}</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block">Date:</span>
              <span className="font-bold text-slate-950">{transaction.date}</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block">Branch:</span>
              <span className="font-semibold text-slate-950">{transaction.branch}</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block">Method:</span>
              <span className="font-semibold text-slate-950">{transaction.paymentMethod}</span>
            </div>
          </div>

          {/* Transaction Details Table */}
          <div className="border border-slate-300 rounded-xl overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-800 uppercase font-bold text-[11px] border-b border-slate-300">
                <tr>
                  <th className="p-3">Particulars</th>
                  <th className="p-3">Party or Head</th>
                  <th className="p-3">Bank / Cash Account</th>
                  <th className="p-3 text-right">Amount (৳ BDT)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="p-3 space-y-1">
                    <span className="font-bold text-slate-900 block">{transaction.subType}</span>
                    {transaction.referenceNo && (
                      <span className="text-slate-500 text-[11px] block">
                        Ref / Cheque No: <span className="font-mono font-bold text-slate-700">{transaction.referenceNo}</span>
                      </span>
                    )}
                    {transaction.note && (
                      <span className="text-slate-600 italic block">{transaction.note}</span>
                    )}
                  </td>
                  <td className="p-3">
                    {transaction.partyName ? (
                      <div>
                        <span className="font-bold text-slate-900 block">{transaction.partyName}</span>
                        <span className="text-[10px] text-slate-500">
                          {transaction.partyType} {transaction.partyCode ? `(${transaction.partyCode})` : ''}
                        </span>
                      </div>
                    ) : (
                      <div>
                        <span className="font-bold text-slate-900 block">{transaction.accountHeadName}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{transaction.accountHeadCode}</span>
                      </div>
                    )}
                  </td>
                  <td className="p-3">
                    <span className="font-semibold text-slate-900 block">{transaction.bankAccountName}</span>
                  </td>
                  <td className="p-3 text-right font-mono font-bold text-sm text-slate-950">
                    ৳{transaction.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
              <tfoot className="bg-slate-50 border-t-2 border-slate-300 font-bold">
                <tr>
                  <td colSpan={3} className="p-3 text-right text-xs uppercase text-slate-700">
                    Total Amount:
                  </td>
                  <td className="p-3 text-right font-mono text-base text-slate-950">
                    ৳{transaction.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Amount in Words */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <span className="text-slate-500 font-semibold">In Words: </span>
            <span className="font-bold text-slate-900 uppercase">
              {formatTakaWords(transaction.amount)}
            </span>
          </div>

          {/* Signatures Block */}
          <div className="grid grid-cols-4 gap-4 pt-12 text-center text-xs">
            <div className="border-t border-slate-400 pt-1.5">
              <span className="font-semibold text-slate-700 block">Prepared By</span>
              <span className="text-[10px] text-slate-500">{transaction.createdBy?.name || 'Accounts Staff'}</span>
            </div>
            <div className="border-t border-slate-400 pt-1.5">
              <span className="font-semibold text-slate-700 block">Checked By</span>
              <span className="text-[10px] text-slate-500">Accounts Officer</span>
            </div>
            <div className="border-t border-slate-400 pt-1.5">
              <span className="font-semibold text-slate-700 block">Approved By</span>
              <span className="text-[10px] text-slate-500">Managing Director</span>
            </div>
            <div className="border-t border-slate-400 pt-1.5">
              <span className="font-semibold text-slate-700 block">Receiver's Signature</span>
              <span className="text-[10px] text-slate-500">Receiver's Sign</span>
            </div>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};
