import React, { useState } from 'react';
import { 
  ArrowRightLeft, 
  X, 
  CheckCircle2, 
  Building2, 
  DollarSign, 
  Calendar, 
  FileText, 
  AlertCircle,
  ArrowRight,
  Wallet
} from 'lucide-react';
import { AccountCOA, BankAccount, JournalVoucher } from '../../types/erp';
import { BankTransferRecord, addBankTransfer } from '../../utils/bankTransferStorage';
import { postVoucher } from '../../services/accountService';
import { useAuth } from '../../contexts/AuthContext';
import { ModalWrapper } from '../common/ModalWrapper';

interface BankAccountTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  bankAccounts: BankAccount[];
  coaList: AccountCOA[];
  onTransferSuccess: (
    transferRecord: BankTransferRecord, 
    contraVoucher: JournalVoucher, 
    updatedBankAccounts: BankAccount[], 
    updatedCOA: AccountCOA[]
  ) => void;
}

export const BankAccountTransferModal: React.FC<BankAccountTransferModalProps> = ({
  isOpen,
  onClose,
  bankAccounts,
  coaList,
  onTransferSuccess
}) => {
  if (!isOpen) return null;

  // Combine Bank Accounts and Liquid Cash accounts from COA
  const availableAccounts = React.useMemo(() => {
    const list: { id: string; code: string; name: string; type: string; balance: number; currency: string }[] = [];

    // Add bank accounts
    bankAccounts.forEach(b => {
      // Find matching COA code if possible
      const coaMatch = coaList.find(c => c.name.toLowerCase().includes(b.bankName.toLowerCase()) || c.code === '1020' || c.code === '1025');
      list.push({
        id: b.id,
        code: coaMatch?.code || (b.bankName.includes('Eastern') ? '1020' : '1025'),
        name: `${b.bankName} (${b.accountNumber})`,
        type: 'Bank',
        balance: b.ledgerBalance,
        currency: b.currency
      });
    });

    // Add Cash in Hand / Petty Cash
    const cashCOA = coaList.filter(c => c.code === '1010' || c.code.startsWith('101') || c.name.toLowerCase().includes('cash'));
    cashCOA.forEach(c => {
      if (!list.some(l => l.code === c.code)) {
        list.push({
          id: `cash-${c.code}`,
          code: c.code,
          name: c.name,
          type: 'Cash / Petty Cash',
          balance: c.balance,
          currency: 'BDT'
        });
      }
    });

    return list;
  }, [bankAccounts, coaList]);

  const [fromAccountId, setFromAccountId] = useState('');
  const [toAccountId, setToAccountId] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [transferDate, setTransferDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [transferMethod, setTransferMethod] = useState<'BEFTN / RTGS' | 'Cheque Transfer' | 'Online Banking / App' | 'Cash Deposit / Float'>('' as any);
  const [referenceNumber, setReferenceNumber] = useState('');
  const [narration, setNarration] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isDirty = Boolean(fromAccountId || toAccountId || (amount !== '' && Number(amount) > 0) || narration);

  const resetForm = () => {
    setFromAccountId('');
    setToAccountId('');
    setAmount('');
    setTransferDate(new Date().toISOString().split('T')[0]);
    setTransferMethod('' as any);
    setReferenceNumber('');
    setNarration('');
    setError(null);
    setIsSubmitting(false);
  };

  const handleSafeClose = () => {
    if (isSubmitting) return;
    resetForm();
    onClose();
  };

  const { currentUser } = useAuth();
  const sourceAcc = availableAccounts.find(a => a.id === fromAccountId);
  const destAcc = availableAccounts.find(a => a.id === toAccountId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fromAccountId || !toAccountId || !sourceAcc || !destAcc) {
      setError('Please select both source and destination accounts.');
      return;
    }

    if (sourceAcc.id === destAcc.id) {
      setError('Source and destination accounts cannot be the same. Please select different accounts.');
      return;
    }

    const numAmount = Number(amount) || 0;
    if (numAmount <= 0) {
      setError('Transfer amount must be greater than 0.');
      return;
    }

    if (numAmount > sourceAcc.balance) {
      setError(`Insufficient balance in source account. Current balance: BDT ${sourceAcc.balance.toLocaleString()}`);
      return;
    }

    setIsSubmitting(true);
    try {
      // 1. Post to unified atomic Firestore transaction via postVoucher (Requirement 1, 2)
      const postedTxn = await postVoucher({
        transactionType: 'CONTRA',
        subType: 'Bank Account Transfer',
        date: transferDate,
        amount: numAmount,
        bankAccountId: sourceAcc.id,
        destBankAccountId: destAcc.id,
        paymentMethod: transferMethod,
        referenceNo: referenceNumber,
        note: narration || `Transfer from ${sourceAcc.name} to ${destAcc.name}`,
        branch: 'Corporate Head Office',
        user: {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || 'Head of Accounts',
          email: currentUser?.email || 'admin@tradecore.local'
        }
      });

      // 2. Create Contra Journal Voucher for local browser
      const contraVoucherNumber = postedTxn.voucherNo;
      const contraVoucher: JournalVoucher = {
        id: `jv-contra-${Date.now()}`,
        voucherNumber: contraVoucherNumber,
        voucherType: 'Contra',
        voucherDate: transferDate,
        referenceType: 'Manual',
        referenceNo: referenceNumber,
        narration: `${narration} (From ${sourceAcc.name} to ${destAcc.name} via ${transferMethod})`,
        items: [
          {
            accountCode: destAcc.code,
            accountName: destAcc.name,
            debit: numAmount,
            credit: 0,
            costCenter: 'General'
          },
          {
            accountCode: sourceAcc.code,
            accountName: sourceAcc.name,
            debit: 0,
            credit: numAmount,
            costCenter: 'General'
          }
        ],
        totalDebit: numAmount,
        totalCredit: numAmount,
        postedBy: currentUser?.name || 'Head of Accounts',
        status: 'Approved & Posted'
      };

      // 3. Create Bank Transfer Log Record
      const transferRecord: BankTransferRecord = {
        id: `trf-${Date.now()}`,
        transferNumber: `TRF-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
        transferDate,
        fromAccountCode: sourceAcc.code,
        fromAccountName: sourceAcc.name,
        toAccountCode: destAcc.code,
        toAccountName: destAcc.name,
        amount: numAmount,
        transferMethod,
        referenceNumber,
        narration,
        voucherNumber: contraVoucherNumber,
        status: 'Completed',
        timestamp: new Date().toISOString()
      };

      // 4. Update Bank Accounts state for parent callback
      const updatedBankAccounts = bankAccounts.map(b => {
        if (b.id === sourceAcc.id) {
          return { ...b, ledgerBalance: b.ledgerBalance - numAmount, statementBalance: b.statementBalance - numAmount };
        }
        if (b.id === destAcc.id) {
          return { ...b, ledgerBalance: b.ledgerBalance + numAmount, statementBalance: b.statementBalance + numAmount };
        }
        return b;
      });

      // 5. Update COA balances for parent callback
      const updatedCOA = coaList.map(item => {
        if (item.code === destAcc.code) {
          return { ...item, balance: item.balance + numAmount };
        }
        if (item.code === sourceAcc.code) {
          return { ...item, balance: item.balance - numAmount };
        }
        return item;
      });

      // Save transfer log
      addBankTransfer(transferRecord);

      // Callback to parent module
      onTransferSuccess(transferRecord, contraVoucher, updatedBankAccounts, updatedCOA);

      // Reset form
      setFromAccountId('');
      setToAccountId('');
      setAmount('');
      setNarration('');
      setTransferMethod('' as any);
      setReferenceNumber('');
      onClose();
    } catch (err: any) {
      console.error('Bank transfer error:', err);
      setError(err.message || 'Failed to post bank fund transfer.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleSafeClose}
      isDirty={isDirty}
      isSaving={isSubmitting}
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in overflow-hidden h-screen"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-5 border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center shadow-2xs">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-slate-900">
                  Bank Account Transfer
                </h3>
                <span className="text-[10px] bg-blue-100 text-blue-800 font-mono font-bold px-2 py-0.5 rounded-full">
                  Contra Voucher
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            data-modal-close="true"
            disabled={isSubmitting}
            onClick={handleSafeClose}
            className="text-slate-400 hover:text-slate-600 text-sm font-bold w-7 h-7 rounded-lg hover:bg-slate-100 flex items-center justify-center cursor-pointer disabled:opacity-50 shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} autoComplete="off" className="space-y-4 text-xs overflow-y-auto pr-1 flex-1 py-2">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 flex items-center gap-2 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          {/* Transfer Accounts Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-2xl">
            {/* From Account */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-800 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                <span>From Account *</span>
              </label>
              <select
                value={fromAccountId}
                onChange={(e) => setFromAccountId(e.target.value)}
                className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium text-xs focus:ring-2 focus:ring-blue-500 outline-none cursor-pointer"
              >
                <option value="">Select source account...</option>
                {availableAccounts.map(acc => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name} — BDT {acc.balance.toLocaleString()}
                  </option>
                ))}
              </select>
              {sourceAcc && (
                <div className="text-[11px] text-slate-500 bg-white p-2 rounded-lg border border-slate-200/80 font-mono">
                  Current Balance: <strong className="text-slate-900">BDT {sourceAcc.balance.toLocaleString()}</strong>
                </div>
              )}
            </div>

            {/* To Account */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-800 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>To Account *</span>
              </label>
              <select
                value={toAccountId}
                onChange={(e) => setToAccountId(e.target.value)}
                className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium text-xs focus:ring-2 focus:ring-emerald-500 outline-none cursor-pointer"
              >
                <option value="">Select destination account...</option>
                {availableAccounts.map(acc => (
                  <option key={acc.id} value={acc.id} disabled={acc.id === fromAccountId}>
                    {acc.name} — BDT {acc.balance.toLocaleString()}
                  </option>
                ))}
              </select>
              {destAcc && (
                <div className="text-[11px] text-slate-500 bg-white p-2 rounded-lg border border-slate-200/80 font-mono">
                  Current Balance: <strong className="text-emerald-700">BDT {destAcc.balance.toLocaleString()}</strong>
                </div>
              )}
            </div>
          </div>

          {/* Amount (BDT) */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5 text-blue-600" />
                <span>Transfer Amount (BDT) *</span>
              </span>
              <span className="font-mono text-[11px] text-blue-700 font-bold">
                BDT {amount ? amount.toLocaleString() : 0}
              </span>
            </label>
            <input
              type="number"
              min="1"
              required
              value={amount || ''}
              onChange={(e) => setAmount(Number(e.target.value))}
              placeholder="Enter amount"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-base font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          {/* Transfer Method & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Transfer Date *</span>
              </label>
              <input
                type="date"
                required
                value={transferDate}
                onChange={(e) => setTransferDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-blue-500 outline-none text-xs"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Transfer Method *
              </label>
              <select
                value={transferMethod}
                onChange={(e) => setTransferMethod(e.target.value as any)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-xs cursor-pointer"
              >
                <option value="">Select Transfer Method...</option>
                <option value="Online Banking / App">Online Banking / App</option>
                <option value="BEFTN / RTGS">BEFTN / RTGS</option>
                <option value="Cheque Transfer">Cheque Transfer</option>
                <option value="Cash Deposit / Float">Cash Deposit / Float</option>
              </select>
            </div>
          </div>

          {/* Reference & Narration */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Ref / Cheque No *
            </label>
            <input
              type="text"
              required
              value={referenceNumber}
              onChange={(e) => setReferenceNumber(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-blue-500 outline-none text-xs"
              placeholder="e.g. RTGS-882194 or CHQ-771249"
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>Narration / Particulars *</span>
            </label>
            <input
              type="text"
              required
              value={narration}
              onChange={(e) => setNarration(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-xs"
              placeholder="e.g. Cash withdrawal from Eastern Bank for stone crushing site expenses"
            />
          </div>

          {/* Post-Transfer Balance Estimation Card */}
          {sourceAcc && destAcc && (
            <div className="p-3 bg-slate-900 text-white rounded-xl font-mono text-xs space-y-2 border border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-[11px] border-b border-slate-800 pb-1.5">
                <span className="text-slate-400">Estimated Balance After Transfer:</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Contra Balanced
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-rose-400 font-bold block">{sourceAcc.name}:</span>
                  <div className="text-slate-300">
                    Before: BDT {sourceAcc.balance.toLocaleString()}
                  </div>
                  <div className="text-white font-bold text-xs mt-0.5">
                    After: BDT {Math.max(0, sourceAcc.balance - (Number(amount) || 0)).toLocaleString()}
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-emerald-400 font-bold block">{destAcc.name}:</span>
                  <div className="text-slate-300">
                    Before: BDT {destAcc.balance.toLocaleString()}
                  </div>
                  <div className="text-emerald-300 font-bold text-xs mt-0.5">
                    After: BDT {(destAcc.balance + (Number(amount) || 0)).toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Footer Buttons */}
          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 shrink-0 sticky bottom-0 bg-white">
            <button
              type="button"
              data-modal-close="true"
              onClick={handleSafeClose}
              disabled={isSubmitting}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <ArrowRightLeft className="w-4 h-4" />
              <span>{isSubmitting ? 'Processing...' : 'Complete Transfer & Post Contra Voucher'}</span>
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
