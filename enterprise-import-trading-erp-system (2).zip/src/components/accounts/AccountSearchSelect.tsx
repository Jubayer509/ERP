import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Search, ChevronDown, Check, X, Hammer } from 'lucide-react';
import { AccountCOA } from '../../types/erp';

interface AccountSearchSelectProps {
  label: string;
  subLabel?: string;
  selectedCode: string;
  onSelect: (code: string) => void;
  coaList: AccountCOA[];
  typeBadge?: 'Dr' | 'Cr';
  placeholder?: string;
  paymentAccountsOnly?: boolean;
}

export const AccountSearchSelect: React.FC<AccountSearchSelectProps> = ({
  label,
  subLabel,
  selectedCode,
  onSelect,
  coaList,
  typeBadge,
  placeholder = 'Search by account code or name...',
  paymentAccountsOnly = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | 'CRUSHING' | 'Asset' | 'Expense' | 'Liability' | 'Revenue' | 'Equity'>('ALL');
  const [onlyPaymentAccounts, setOnlyPaymentAccounts] = useState(paymentAccountsOnly);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Sync onlyPaymentAccounts when prop changes
  useEffect(() => {
    setOnlyPaymentAccounts(paymentAccountsOnly);
  }, [paymentAccountsOnly]);

  // Find currently selected account
  const selectedAccount = useMemo(() => {
    return coaList.find(c => c.code === selectedCode);
  }, [coaList, selectedCode]);

  // Focus search input when dropdown opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    } else {
      setSearchTerm('');
      setCategoryFilter('ALL');
    }
  }, [isOpen]);

  // Close dropdown on click outside or escape key
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  // Filter accounts
  const filteredAccounts = useMemo(() => {
    const q = searchTerm.toLowerCase().trim();

    return coaList.filter(item => {
      // Payment accounts only filter (Bank & Petty Cash)
      if (onlyPaymentAccounts) {
        const isCashOrBank = 
          item.subCategory === 'Cash & Bank' || 
          item.code === '1010' || 
          item.code === '1020' || 
          item.code === '1025' || 
          item.code.startsWith('101') || 
          item.code.startsWith('102') || 
          item.name.toLowerCase().includes('cash') || 
          item.name.toLowerCase().includes('bank');
        if (!isCashOrBank || item.isParent) return false;
      }

      // Category filter
      if (categoryFilter === 'CRUSHING') {
        const isCrushing = item.code.startsWith('52') || item.subCategory.toLowerCase().includes('crushing');
        if (!isCrushing) return false;
      } else if (categoryFilter !== 'ALL') {
        if (item.category !== categoryFilter) return false;
      }

      // Search term filter
      if (!q) return true;

      const codeMatch = item.code.toLowerCase().includes(q);
      const nameMatch = item.name.toLowerCase().includes(q);
      const subCatMatch = (item.subCategory || '').toLowerCase().includes(q);
      const catMatch = (item.category || '').toLowerCase().includes(q);

      return codeMatch || nameMatch || subCatMatch || catMatch;
    });
  }, [coaList, searchTerm, categoryFilter, onlyPaymentAccounts]);

  const getCategoryBadgeClass = (category: string) => {
    switch (category) {
      case 'Asset':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Liability':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'Equity':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Revenue':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Expense':
      default:
        return 'bg-amber-100 text-amber-900 border-amber-200';
    }
  };

  return (
    <div className="relative" ref={containerRef}>
      {/* Label Bar */}
      <div className="flex items-center justify-between mb-1">
        <label className="font-semibold text-slate-700 flex items-center gap-1.5 text-xs">
          {typeBadge && (
            <span
              className={`px-1.5 py-0.2 rounded font-mono font-bold text-[10px] ${
                typeBadge === 'Dr'
                  ? 'bg-blue-100 text-blue-800 border border-blue-200'
                  : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
              }`}
            >
              {typeBadge}
            </span>
          )}
          <span>{label}</span>
        </label>
        {subLabel && <span className="text-[10px] text-slate-400">{subLabel}</span>}
      </div>

      {/* Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(prev => !prev)}
        className={`w-full p-2 bg-slate-50 hover:bg-slate-100/80 border rounded-xl text-left transition-all flex items-center justify-between gap-2 cursor-pointer shadow-2xs ${
          isOpen
            ? 'border-emerald-500 ring-2 ring-emerald-500/20 bg-white'
            : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        {selectedAccount ? (
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <span className="font-mono font-bold text-xs bg-slate-900 text-white px-2 py-0.5 rounded shadow-2xs shrink-0">
              {selectedAccount.code}
            </span>
            <div className="truncate flex-1">
              <div className="font-semibold text-xs text-slate-900 truncate">
                {selectedAccount.name}
              </div>
              <div className="text-[10px] text-slate-500 flex items-center gap-2">
                <span>{selectedAccount.subCategory}</span>
                <span>•</span>
                <span className="font-mono">Bal: BDT {selectedAccount.balance.toLocaleString()}</span>
              </div>
            </div>
            <span
              className={`text-[9px] font-bold px-1.5 py-0.5 rounded border shrink-0 ${getCategoryBadgeClass(
                selectedAccount.category
              )}`}
            >
              {selectedAccount.category}
            </span>
          </div>
        ) : (
          <span className="text-xs text-slate-400 font-normal">Select account...</span>
        )}

        <div className="flex items-center gap-1 text-slate-400 shrink-0">
          <Search className="w-3.5 h-3.5" />
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isOpen ? 'rotate-180 text-emerald-600' : ''}`} />
        </div>
      </button>

      {/* Dropdown Popover */}
      {isOpen && (
        <div className="absolute left-0 right-0 top-full mt-1.5 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-1">
          {/* Search Header */}
          <div className="p-2.5 bg-slate-50 border-b border-slate-200 space-y-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={placeholder}
                className="w-full pl-8 pr-7 py-1.5 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 font-sans"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2 top-2 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {paymentAccountsOnly && (
              <div className="flex items-center justify-between bg-emerald-50/90 border border-emerald-200/80 px-2 py-1.5 rounded-xl text-[11px]">
                <span className="font-semibold text-emerald-950 flex items-center gap-1">
                  <span>🏦 Bank & Petty Cash Accounts</span>
                  <span className="text-[10px] text-emerald-700 bg-emerald-200/70 px-1.5 py-0.2 rounded font-mono font-bold">
                    Payment Source
                  </span>
                </span>
                <button
                  type="button"
                  onClick={() => setOnlyPaymentAccounts(prev => !prev)}
                  className={`px-2 py-0.5 rounded-lg font-bold text-[10px] cursor-pointer transition-colors ${
                    onlyPaymentAccounts
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {onlyPaymentAccounts ? '✓ Bank & Cash Only' : 'Show All Accounts'}
                </button>
              </div>
            )}

            {/* Quick Category Filters */}
            <div className="flex items-center gap-1 overflow-x-auto pb-0.5 text-[10px] scrollbar-none font-medium">
              <button
                type="button"
                onClick={() => setCategoryFilter('ALL')}
                className={`px-2 py-0.5 rounded-lg whitespace-nowrap cursor-pointer transition-colors ${
                  categoryFilter === 'ALL'
                    ? 'bg-slate-900 text-white font-bold'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                All ({coaList.length})
              </button>

              <button
                type="button"
                onClick={() => setCategoryFilter('CRUSHING')}
                className={`px-2 py-0.5 rounded-lg whitespace-nowrap cursor-pointer transition-colors flex items-center gap-1 ${
                  categoryFilter === 'CRUSHING'
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
                }`}
              >
                <Hammer className="w-2.5 h-2.5" />
                <span>Stone Crushing (52xx)</span>
              </button>

              <button
                type="button"
                onClick={() => setCategoryFilter('Expense')}
                className={`px-2 py-0.5 rounded-lg whitespace-nowrap cursor-pointer transition-colors ${
                  categoryFilter === 'Expense'
                    ? 'bg-amber-600 text-white font-bold'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Expense
              </button>

              <button
                type="button"
                onClick={() => setCategoryFilter('Asset')}
                className={`px-2 py-0.5 rounded-lg whitespace-nowrap cursor-pointer transition-colors ${
                  categoryFilter === 'Asset'
                    ? 'bg-blue-600 text-white font-bold'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Asset
              </button>

              <button
                type="button"
                onClick={() => setCategoryFilter('Liability')}
                className={`px-2 py-0.5 rounded-lg whitespace-nowrap cursor-pointer transition-colors ${
                  categoryFilter === 'Liability'
                    ? 'bg-rose-600 text-white font-bold'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Liability
              </button>

              <button
                type="button"
                onClick={() => setCategoryFilter('Revenue')}
                className={`px-2 py-0.5 rounded-lg whitespace-nowrap cursor-pointer transition-colors ${
                  categoryFilter === 'Revenue'
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Revenue
              </button>
            </div>
          </div>

          {/* Results List */}
          <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 p-1">
            {filteredAccounts.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400">
                <Search className="w-5 h-5 mx-auto mb-1.5 opacity-40" />
                No account heads found.
              </div>
            ) : (
              filteredAccounts.map((item) => {
                const isSelected = item.code === selectedCode;
                const isCrushing = item.code.startsWith('52') || item.subCategory.toLowerCase().includes('crushing');

                return (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => {
                      onSelect(item.code);
                      setIsOpen(false);
                    }}
                    className={`w-full p-2 text-left rounded-xl transition-colors flex items-center justify-between gap-2 cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-50/80 text-emerald-950 font-semibold'
                        : 'hover:bg-slate-50 text-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <span
                        className={`font-mono font-bold text-[11px] px-1.5 py-0.5 rounded shrink-0 ${
                          isSelected
                            ? 'bg-emerald-600 text-white'
                            : isCrushing
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : 'bg-slate-100 text-slate-800'
                        }`}
                      >
                        {item.code}
                      </span>
                      <div className="truncate flex-1">
                        <div className="text-xs truncate flex items-center gap-1.5">
                          {isCrushing && <Hammer className="w-3 h-3 text-amber-600 shrink-0" />}
                          <span className={item.isParent ? 'font-bold uppercase' : 'font-medium'}>
                            {item.name}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-2 font-mono">
                          <span>{item.subCategory}</span>
                          <span>•</span>
                          <span>Balance: BDT {item.balance.toLocaleString()} ({item.normalBalance})</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${getCategoryBadgeClass(item.category)}`}>
                        {item.category}
                      </span>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
