import React, { useState } from 'react';
import { 
  FileText, 
  X, 
  Save, 
  DollarSign, 
  BookOpen, 
  Calendar 
} from 'lucide-react';
import { JournalVoucher, AccountCOA } from '../../types/erp';
import { AccountSearchSelect } from './AccountSearchSelect';
import { ModalWrapper } from '../common/ModalWrapper';

interface EditJournalVoucherModalProps {
  isOpen: boolean;
  voucher: JournalVoucher | null;
  coaList: AccountCOA[];
  onClose: () => void;
  onSave: (updated: JournalVoucher) => void;
}

export const EditJournalVoucherModal: React.FC<EditJournalVoucherModalProps> = ({
  isOpen,
  voucher,
  coaList,
  onClose,
  onSave
}) => {
  if (!isOpen || !voucher) return null;

  const [voucherType, setVoucherType] = useState(voucher.voucherType);
  const [voucherDate, setVoucherDate] = useState(voucher.voucherDate);
  const [narration, setNarration] = useState(voucher.narration);
  const [drAccount, setDrAccount] = useState(voucher.items[0]?.accountCode || '5010');
  const [crAccount, setCrAccount] = useState(voucher.items[1]?.accountCode || '1020');
  const [amount, setAmount] = useState(voucher.totalDebit);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const debitHead = coaList.find(c => c.code === drAccount);
    const creditHead = coaList.find(c => c.code === crAccount);
    if (!debitHead || !creditHead) return;

    const updated: JournalVoucher = {
      ...voucher,
      voucherType,
      voucherDate,
      narration,
      items: [
        { 
          accountCode: debitHead.code, 
          accountName: debitHead.name, 
          debit: amount, 
          credit: 0, 
          costCenter: voucher.items[0]?.costCenter || 'General' 
        },
        { 
          accountCode: creditHead.code, 
          accountName: creditHead.name, 
          debit: 0, 
          credit: amount, 
          costCenter: voucher.items[1]?.costCenter || 'General' 
        }
      ],
      totalDebit: amount,
      totalCredit: amount
    };
    onSave(updated);
  };

  const isDirty = Boolean(
    voucherType !== voucher.voucherType ||
    voucherDate !== voucher.voucherDate ||
    narration !== voucher.narration ||
    drAccount !== (voucher.items[0]?.accountCode || '5010') ||
    crAccount !== (voucher.items[1]?.accountCode || '1020') ||
    Number(amount) !== Number(voucher.totalDebit)
  );

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      isDirty={isDirty}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in overflow-hidden h-screen"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[92vh] flex flex-col border border-slate-200 overflow-hidden">
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-purple-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center border border-purple-400/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">Edit Financial Voucher</h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-purple-500/30 text-purple-200">
                  {voucher.voucherNumber}
                </span>
              </div>
            </div>
          </div>
          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs overflow-y-auto flex-1">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Voucher Type</label>
              <select
                value={voucherType}
                onChange={(e) => setVoucherType(e.target.value as any)}
                className="w-full border border-slate-300 rounded-xl p-2 bg-white"
              >
                <option value="PV">Payment Voucher (PV)</option>
                <option value="RV">Receipt Voucher (RV)</option>
                <option value="JV">Journal Voucher (JV)</option>
                <option value="Contra">Contra Voucher</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Posting Date</label>
              <input
                type="date"
                required
                value={voucherDate}
                onChange={(e) => setVoucherDate(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Transaction Amount (৳) <span className="text-rose-500">*</span>
            </label>
            <input
              type="number"
              min={1}
              required
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-base text-purple-700"
            />
          </div>

          <div className="space-y-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <AccountSearchSelect
              label="Debit Account (Dr.)"
              selectedCode={drAccount}
              onSelect={(code) => setDrAccount(code)}
              coaList={coaList}
              typeBadge="Dr"
              placeholder="Search debit account..."
            />

            <AccountSearchSelect
              label="Credit Account (Cr.)"
              selectedCode={crAccount}
              onSelect={(code) => setCrAccount(code)}
              coaList={coaList}
              typeBadge="Cr"
              placeholder="Search credit account..."
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Narration / Description</label>
            <textarea
              rows={2}
              required
              value={narration}
              onChange={(e) => setNarration(e.target.value)}
              className="w-full border border-slate-300 rounded-xl p-2 text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Voucher</span>
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
