import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Plus, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Building2, 
  Calendar, 
  ChevronDown, 
  FileText, 
  Loader2, 
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { 
  PaymentSubType, 
  PaymentMethod, 
  AccountHead, 
  AccountTransaction,
  AccountLedgerEntry
} from '../../types/accounts';
import { Customer, Supplier, BankAccount, AccountCOA, JournalVoucher } from '../../types/erp';
import { 
  postVoucher,
  getNextVoucherNumber, 
  saveAccountTransactions,
  getAccountTransactions 
} from '../../services/accountService';
import { getCustomers, updateCustomerBalance, formatCustomerBalance } from '../../utils/customerStorage';
import { getSuppliers, updateSupplierPayableBalance, formatSupplierBalance } from '../../utils/supplierStorage';
import { getBankAccounts, updateBankAccountBalance, isCashAccount as checkIsCashAccount } from '../../utils/bankAccountStorage';
import { getCOA, saveCOA } from '../../utils/coaStorage';
import { addVoucher, getVouchers } from '../../utils/voucherStorage';
import { db } from '../../lib/firebase';
import { doc, writeBatch } from 'firebase/firestore';

export interface DebitLineItem {
  id: string;
  accountCode: string;
  particulars: string;
  amount: number;
}

interface PaymentTransactionFormProps {
  onTransactionCreated?: (txn: AccountTransaction) => void;
  onNavigateToHistory?: () => void;
}

export const PaymentTransactionForm: React.FC<PaymentTransactionFormProps> = ({
  onTransactionCreated,
  onNavigateToHistory
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  // 1. Payment Type (Segmented control)
  // 'Expense / General' · 'Pay to Customer' · 'Pay to Supplier'
  const [paymentType, setPaymentType] = useState<PaymentSubType>('Expense / General Payment');

  // Form Fields
  const [voucherNumber, setVoucherNumber] = useState<string>('PV-....');
  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [costCenter, setCostCenter] = useState<string>('');
  const [paidFromAccountId, setPaidFromAccountId] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('' as any);
  const [referenceNo, setReferenceNo] = useState<string>('');
  const [narration, setNarration] = useState<string>('');
  const [branch, setBranch] = useState<string>(currentUser?.branch || 'Corporate Headquarters (Dhaka)');

  // Multi-line Debit Items for 'Expense / General' (starts empty with one blank line with 0 amount)
  const [debitLines, setDebitLines] = useState<DebitLineItem[]>([
    {
      id: 'line-1',
      accountCode: '',
      particulars: '',
      amount: 0
    }
  ]);

  // Customer selection for 'Pay to Customer'
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customerSearch, setCustomerSearch] = useState<string>('');
  const [customerDropdownOpen, setCustomerDropdownOpen] = useState<boolean>(false);
  const [customerAmount, setCustomerAmount] = useState<string>('');
  const [customerParticulars, setCustomerParticulars] = useState<string>('');
  const [customerConfirmExcess, setCustomerConfirmExcess] = useState<boolean>(false);

  // Supplier selection for 'Pay to Supplier'
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [supplierSearch, setSupplierSearch] = useState<string>('');
  const [supplierDropdownOpen, setSupplierDropdownOpen] = useState<boolean>(false);
  const [supplierAmount, setSupplierAmount] = useState<string>('');
  const [supplierParticulars, setSupplierParticulars] = useState<string>('');
  const [supplierConfirmExcess, setSupplierConfirmExcess] = useState<boolean>(false);

  // Lists
  const [coaList, setCoaList] = useState<AccountCOA[]>(() => getCOA());
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  const [customers, setCustomers] = useState<Customer[]>(() => getCustomers());
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => getSuppliers());

  // UI status
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<{ voucherNo: string; amount: number; message: string } | null>(null);

  // Sync Branch from logged-in user
  useEffect(() => {
    if (currentUser?.branch) {
      setBranch(currentUser.branch);
    }
  }, [currentUser]);

  // Fetch initial voucher number
  const fetchVoucherNumber = async () => {
    try {
      const vNo = await getNextVoucherNumber('PAYMENT', 'PV');
      setVoucherNumber(vNo);
    } catch {
      setVoucherNumber(`PV-${Date.now().toString().slice(-4)}`);
    }
  };

  useEffect(() => {
    fetchVoucherNumber();
  }, []);

  // Filter COA for Expense heads (5xxx or Expense category)
  const expenseHeads = useMemo(() => {
    return coaList.filter(c => c.category === 'Expense' || c.code.startsWith('5') || c.subCategory?.toLowerCase().includes('crushing'));
  }, [coaList]);

  // Selected Bank / Cash Account
  const selectedBankAccount = useMemo(() => {
    return bankAccounts.find(b => b.id === paidFromAccountId);
  }, [bankAccounts, paidFromAccountId]);

  // Selected Customer & Supplier
  const selectedCustomer = useMemo(() => {
    return customers.find(c => c.id === selectedCustomerId);
  }, [customers, selectedCustomerId]);

  const selectedSupplier = useMemo(() => {
    return suppliers.find(s => s.id === selectedSupplierId);
  }, [suppliers, selectedSupplierId]);

  // Filtered dropdowns
  const filteredCustomers = useMemo(() => {
    if (!customerSearch.trim()) return customers;
    const q = customerSearch.toLowerCase();
    return customers.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.code?.toLowerCase().includes(q) || 
      c.phone?.toLowerCase().includes(q)
    );
  }, [customers, customerSearch]);

  const filteredSuppliers = useMemo(() => {
    if (!supplierSearch.trim()) return suppliers;
    const q = supplierSearch.toLowerCase();
    return suppliers.filter(s => 
      s.name.toLowerCase().includes(q) || 
      s.code?.toLowerCase().includes(q) || 
      s.country?.toLowerCase().includes(q)
    );
  }, [suppliers, supplierSearch]);

  // Calculate Total Amount
  const totalAmount = useMemo(() => {
    if (paymentType === 'Expense / General Payment') {
      return debitLines.reduce((sum, line) => sum + (Number(line.amount) || 0), 0);
    } else if (paymentType === 'Pay to Customer') {
      return Number(customerAmount) || 0;
    } else if (paymentType === 'Pay to Supplier') {
      return Number(supplierAmount) || 0;
    }
    return 0;
  }, [paymentType, debitLines, customerAmount, supplierAmount]);

  const [adminApprovedOverdraft, setAdminApprovedOverdraft] = useState<boolean>(false);

  // Requirement 3: Real Double-Entry Balanced Check
  const totalDebits = useMemo(() => {
    if (paymentType === 'Expense / General Payment') {
      return debitLines.reduce((sum, line) => sum + (Number(line.amount) || 0), 0);
    }
    return totalAmount;
  }, [paymentType, debitLines, totalAmount]);

  const totalCredits = totalAmount;
  const isBalanced = totalAmount > 0 && Math.abs(totalDebits - totalCredits) < 0.001;

  // Requirement 5: Cash Non-Negative & Bank Overdraft Checks
  const isCashAccount = useMemo(() => {
    return checkIsCashAccount(selectedBankAccount);
  }, [selectedBankAccount]);

  const projectedBankBalance = useMemo(() => {
    if (!selectedBankAccount) return 0;
    return (selectedBankAccount.ledgerBalance || 0) - totalAmount;
  }, [selectedBankAccount, totalAmount]);

  const isCashDeficit = isCashAccount && totalAmount > 0 && projectedBankBalance < 0;
  const isBankOverdraft = !isCashAccount && selectedBankAccount && totalAmount > 0 && projectedBankBalance < 0;

  // Overpayment Warning Checks
  const customerOverpaymentWarning = useMemo(() => {
    if (paymentType !== 'Pay to Customer' || !selectedCustomer) return null;
    const recDue = selectedCustomer.currentBalance || 0;
    const amt = Number(customerAmount) || 0;
    if (amt <= 0) return null;

    if (recDue > 0) {
      return `Customer currently has an outstanding receivable due of ৳ ${recDue.toLocaleString()}. Paying ৳ ${amt.toLocaleString()} will increase their receivable balance.`;
    }
    const advanceHeld = selectedCustomer.advanceBalance || 0;
    if (amt > advanceHeld) {
      return `Payment amount (৳ ${amt.toLocaleString()}) exceeds customer's advance or refund balance.`;
    }
    return null;
  }, [paymentType, selectedCustomer, customerAmount]);

  const supplierOverpaymentWarning = useMemo(() => {
    if (paymentType !== 'Pay to Supplier' || !selectedSupplier) return null;
    const payable = selectedSupplier.currentPayable || 0;
    const amt = Number(supplierAmount) || 0;
    if (amt <= 0) return null;

    if (amt > payable) {
      return `Payment amount (৳ ${amt.toLocaleString()}) exceeds current payable due (৳ ${payable.toLocaleString()}) by ৳ ${(amt - payable).toLocaleString()}.`;
    }
    return null;
  }, [paymentType, selectedSupplier, supplierAmount]);

  // Multi-line Debit handlers
  const handleAddLine = () => {
    setDebitLines(prev => [
      ...prev,
      {
        id: `line-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        accountCode: '',
        particulars: '',
        amount: 0
      }
    ]);
  };

  const handleRemoveLine = (id: string) => {
    if (debitLines.length <= 1) return;
    setDebitLines(prev => prev.filter(l => l.id !== id));
  };

  const handleUpdateLine = (id: string, updates: Partial<DebitLineItem>) => {
    setDebitLines(prev =>
      prev.map(l => {
        if (l.id === id) {
          const updated = { ...l, ...updates };
          if (updates.accountCode && updates.accountCode !== l.accountCode) {
            const head = coaList.find(c => c.code === updates.accountCode);
            if (head) {
              updated.particulars = head.name;
            }
          }
          return updated;
        }
        return l;
      })
    );
  };

  // Quick Presets (Expense heads loaded with amount 0 as requested)
  const handleApplyCrushingPackagePreset = () => {
    setDebitLines([
      { id: `line-1-${Date.now()}`, accountCode: '5200', particulars: 'Stone Crushing & Machine Feeder Bill', amount: 0 },
      { id: `line-2-${Date.now()}`, accountCode: '5220', particulars: 'Crushing Electricity Bill Payment', amount: 0 },
      { id: `line-3-${Date.now()}`, accountCode: '5210', particulars: 'Stone Loading-Unloading Labor Bill', amount: 0 },
      { id: `line-4-${Date.now()}`, accountCode: '5100', particulars: 'Yard Site Office & Misc Administrative Expense', amount: 0 }
    ]);
    setNarration('Stone crushing package bill (crushing, electricity, labor, and site expenses)');
  };

  const handleApplyOfficeSitePreset = () => {
    setDebitLines([
      { id: `line-1-${Date.now()}`, accountCode: '5100', particulars: 'Office Stationery & Refreshment Expense', amount: 0 },
      { id: `line-2-${Date.now()}`, accountCode: '5120', particulars: 'Generator & Site Trip Diesel Fuel Expense', amount: 0 },
      { id: `line-3-${Date.now()}`, accountCode: '5210', particulars: 'Daily Casual Labor Attendance Bill', amount: 0 }
    ]);
    setNarration('Yard and office operating expense payment');
  };

  const handleApplyLaborPreset = () => {
    setDebitLines([
      { id: `line-1-${Date.now()}`, accountCode: '5210', particulars: 'Boulder Unloading & Site Labor Bill', amount: 0 },
      { id: `line-2-${Date.now()}`, accountCode: '5030', particulars: 'Local Transport & Truck Loading Wages', amount: 0 }
    ]);
    setNarration('Site loading-unloading and labor wages payment');
  };

  // SUBMIT & POST VOUCHER (Requirement 1, 2, 3, 5, 8)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (totalAmount <= 0) {
      setErrorMessage('Amount must be greater than 0.');
      return;
    }

    if (!selectedBankAccount) {
      setErrorMessage('Please select a Paid From account.');
      return;
    }

    if (!isBalanced) {
      setErrorMessage(
        `Balance check failed: Debit and Credit amounts do not match (Debit: ৳${totalDebits.toLocaleString()}, Credit: ৳${totalCredits.toLocaleString()}).`
      );
      return;
    }

    if (isCashDeficit) {
      setErrorMessage(
        `Insufficient cash balance. Current cash: ৳${(selectedBankAccount.ledgerBalance || 0).toLocaleString()}. Negative cash balance is not permitted.`
      );
      return;
    }

    if (isBankOverdraft && !adminApprovedOverdraft) {
      setErrorMessage(
        `Bank account overdraft detected. Please check the admin approval box below to continue.`
      );
      return;
    }

    // Validation for Customer
    if (paymentType === 'Pay to Customer') {
      if (!selectedCustomerId) {
        setErrorMessage('Please select a customer.');
        return;
      }
      if (customerOverpaymentWarning && !customerConfirmExcess) {
        setErrorMessage('Please check the confirmation box to proceed.');
        return;
      }
    }

    // Validation for Supplier
    if (paymentType === 'Pay to Supplier') {
      if (!selectedSupplierId) {
        setErrorMessage('Please select a supplier.');
        return;
      }
      if (supplierOverpaymentWarning && !supplierConfirmExcess) {
        setErrorMessage('Please check the confirmation box to proceed.');
        return;
      }
    }

    setIsSubmitting(true);

    try {
      // 1. Post to single-source Firestore via postVoucher
      const postedTxn = await postVoucher({
        transactionType: 'PAYMENT',
        subType: paymentType,
        date,
        amount: totalAmount,
        bankAccountId: selectedBankAccount.id,
        paymentMethod,
        referenceNo: referenceNo.trim() || undefined,
        note: narration.trim() || undefined,
        costCenter: paymentType === 'Expense / General Payment' ? costCenter : undefined,
        branch,
        partyType: paymentType === 'Pay to Customer' ? 'Customer' : paymentType === 'Pay to Supplier' ? 'Supplier' : 'None',
        partyId: paymentType === 'Pay to Customer' ? selectedCustomer?.id : paymentType === 'Pay to Supplier' ? selectedSupplier?.id : undefined,
        partyName: paymentType === 'Pay to Customer' ? selectedCustomer?.name : paymentType === 'Pay to Supplier' ? selectedSupplier?.name : undefined,
        partyCode: paymentType === 'Pay to Customer' ? selectedCustomer?.code : paymentType === 'Pay to Supplier' ? selectedSupplier?.code : undefined,
        partyPhone: paymentType === 'Pay to Customer' ? selectedCustomer?.phone : paymentType === 'Pay to Supplier' ? selectedSupplier?.paymentTerms : undefined,
        debitLines: paymentType === 'Expense / General Payment'
          ? debitLines.filter(l => Number(l.amount) > 0).map(l => ({ accountCode: l.accountCode, particulars: l.particulars, amount: Number(l.amount) }))
          : undefined,
        user: {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || 'Authorized User',
          email: currentUser?.email || 'admin@tradecore.local'
        },
        adminApprovedOverdraft
      });

      // 2. Also record in local Journal Voucher list for voucher browser
      const jvId = `jv-${Date.now()}`;
      const newJournalVoucher: JournalVoucher = {
        id: jvId,
        voucherNumber: postedTxn.voucherNo,
        voucherType: 'PV',
        voucherDate: date,
        referenceType: paymentType === 'Expense / General Payment' ? 'Manual' : (paymentType === 'Pay to Customer' ? 'Sales' : 'Purchase'),
        ...(referenceNo.trim() ? { referenceNo: referenceNo.trim() } : {}),
        narration: narration.trim() || `${paymentType} against ${postedTxn.voucherNo}`,
        items: [
          {
            accountCode: selectedBankAccount.coaCode || '1020',
            accountName: selectedBankAccount.bankName,
            debit: 0,
            credit: totalAmount,
            costCenter
          }
        ],
        totalDebit: totalAmount,
        totalCredit: totalAmount,
        postedBy: currentUser?.name || 'Authorized User',
        status: 'Approved & Posted'
      };
      addVoucher(newJournalVoucher);

      // Refresh form and data states
      setBankAccounts(getBankAccounts());
      setCustomers(getCustomers());
      setSuppliers(getSuppliers());

      setSuccessInfo({
        voucherNo: postedTxn.voucherNo,
        amount: totalAmount,
        message: `Voucher ${postedTxn.voucherNo} posted to General Ledger!`
      });

      setPaidFromAccountId('');
      setCostCenter('');
      setPaymentMethod('' as any);
      setNarration('');
      setDebitLines([
        {
          id: 'line-1',
          accountCode: '',
          particulars: '',
          amount: 0
        }
      ]);
      setSelectedCustomerId('');
      setCustomerSearch('');
      setCustomerAmount('');
      setCustomerParticulars('');
      setCustomerConfirmExcess(false);

      setSelectedSupplierId('');
      setSupplierSearch('');
      setSupplierAmount('');
      setSupplierParticulars('');
      setSupplierConfirmExcess(false);
      setReferenceNo('');
      setAdminApprovedOverdraft(false);
      setErrorMessage(null);
      fetchVoucherNumber();

      if (onTransactionCreated) {
        onTransactionCreated(postedTxn);
      }
    } catch (err: any) {
      console.error('Payment posting error:', err);
      setErrorMessage(err.message || 'Failed to post voucher. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 border-t-2 border-t-rose-600 rounded-xl shadow-xs p-5 md:p-6 text-slate-800">
      {/* Success Notification Bar */}
      {successInfo && (
        <div className="mb-5 p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between gap-3 text-xs text-emerald-800">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>{successInfo.voucherNo}</strong>: {successInfo.message} (Total ৳ {successInfo.amount.toLocaleString()})
            </span>
          </div>
          <div className="flex items-center gap-2">
            {onNavigateToHistory && (
              <button
                type="button"
                onClick={onNavigateToHistory}
                className="px-3 py-1 bg-white hover:bg-emerald-100 text-emerald-700 border border-emerald-300 rounded-lg font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>View History</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
            <button
              type="button"
              onClick={() => setSuccessInfo(null)}
              className="text-emerald-600 hover:text-emerald-900 font-bold px-1.5 py-0.5 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Top Bar: Title, Voucher No, Date */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Payment Voucher (PV)
          </h2>
          <span className="font-mono text-xs bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-md border border-slate-200 font-semibold tracking-wider">
            {voucherNumber}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-500 font-medium">Date:</label>
          <div className="relative">
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 font-medium focus:outline-none focus:border-rose-500 focus:bg-white transition-colors"
            />
          </div>
        </div>
      </div>

      {/* Segmented Type Selector: 3 Neutral Options */}
      <div className="my-4">
        <div className="bg-slate-100 p-1 rounded-xl grid grid-cols-3 gap-1 max-w-xl">
          <button
            type="button"
            onClick={() => setPaymentType('Expense / General Payment')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all text-center cursor-pointer ${
              paymentType === 'Expense / General Payment'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Expense / General
          </button>

          <button
            type="button"
            onClick={() => setPaymentType('Pay to Customer')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all text-center cursor-pointer ${
              paymentType === 'Pay to Customer'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pay to Customer
          </button>

          <button
            type="button"
            onClick={() => setPaymentType('Pay to Supplier')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all text-center cursor-pointer ${
              paymentType === 'Pay to Supplier'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pay to Supplier
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} autoComplete="off" className="space-y-5">
        {/* MIDDLE SECTION 1: Expense / General Multi-Line Debit */}
        {paymentType === 'Expense / General Payment' && (
          <div className="space-y-3">
            {/* Presets row & Cost center */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5 text-xs">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-slate-500 text-[11px] font-medium mr-1">Quick Presets:</span>
                <button
                  type="button"
                  onClick={handleApplyCrushingPackagePreset}
                  className="px-2 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[11px] transition-colors cursor-pointer"
                >
                  Stone Crushing Package
                </button>
                <button
                  type="button"
                  onClick={handleApplyOfficeSitePreset}
                  className="px-2 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[11px] transition-colors cursor-pointer"
                >
                  Office & Site Costs
                </button>
                <button
                  type="button"
                  onClick={handleApplyLaborPreset}
                  className="px-2 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[11px] transition-colors cursor-pointer"
                >
                  Labour & Handling
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-slate-500 text-[11px] font-medium shrink-0">Cost Center:</span>
                <select
                  value={costCenter}
                  onChange={e => setCostCenter(e.target.value)}
                  className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:border-rose-500"
                >
                  <option value="">Select Cost Center...</option>
                  <option value="Sonahat Crushing Plant">Sonahat Crushing Plant</option>
                  <option value="Burimari Port Depot">Burimari Port Depot</option>
                  <option value="Corporate Headquarters (Dhaka)">Head Office (Dhaka)</option>
                </select>
              </div>
            </div>

            {/* Debit Lines Minimal List */}
            <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50/50">
              <div className="grid grid-cols-12 gap-2 px-3.5 py-2 bg-slate-100/70 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <div className="col-span-1 text-center">#</div>
                <div className="col-span-5">Account Head</div>
                <div className="col-span-3">Particulars / Note</div>
                <div className="col-span-2 text-right">Amount (৳)</div>
                <div className="col-span-1 text-center">Action</div>
              </div>

              <div className="divide-y divide-slate-200/60 p-1.5 space-y-1">
                {debitLines.map((line, idx) => (
                  <div key={line.id} className="grid grid-cols-12 gap-2 items-center px-2 py-1 bg-white rounded-lg border border-slate-100 shadow-2xs">
                    <div className="col-span-1 text-center font-mono text-xs text-slate-400">
                      {idx + 1}
                    </div>

                    <div className="col-span-5">
                      <select
                        value={line.accountCode}
                        onChange={e => handleUpdateLine(line.id, { accountCode: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-rose-500 focus:bg-white"
                      >
                        <option value="">-- Select Account Head --</option>
                        {expenseHeads.map(head => (
                          <option key={head.code} value={head.code}>
                            {head.code} - {head.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="col-span-3">
                      <input
                        type="text"
                        value={line.particulars}
                        onChange={e => handleUpdateLine(line.id, { particulars: e.target.value })}
                        placeholder="Particulars..."
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-rose-500 focus:bg-white"
                      />
                    </div>

                    <div className="col-span-2">
                      <input
                        type="number"
                        min="0"
                        value={line.amount || ''}
                        onChange={e => {
                          const val = e.target.value;
                          handleUpdateLine(line.id, { amount: val === '' ? 0 : parseFloat(val) || 0 });
                        }}
                        onFocus={e => {
                          if (line.amount === 0) e.target.select();
                        }}
                        placeholder="0"
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono font-semibold text-right text-slate-900 focus:outline-none focus:border-rose-500 focus:bg-white"
                      />
                    </div>

                    <div className="col-span-1 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveLine(line.id)}
                        disabled={debitLines.length <= 1}
                        className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                          debitLines.length <= 1 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'
                        }`}
                        title="Remove line"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="px-3.5 py-2 border-t border-slate-200 bg-white flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleAddLine}
                  className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Add Line</span>
                </button>
                <span className="text-xs text-slate-500">
                  Subtotal: <strong className="font-mono text-slate-900">৳ {totalAmount.toLocaleString()}</strong>
                </span>
              </div>
            </div>
          </div>
        )}

        {/* MIDDLE SECTION 2: Pay to Customer */}
        {paymentType === 'Pay to Customer' && (
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3.5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Customer Selector */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Customer *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={selectedCustomer ? `${selectedCustomer.code} - ${selectedCustomer.name}` : customerSearch}
                    onChange={e => {
                      setCustomerSearch(e.target.value);
                      if (selectedCustomerId) setSelectedCustomerId('');
                      setCustomerDropdownOpen(true);
                    }}
                    onFocus={() => setCustomerDropdownOpen(true)}
                    placeholder="Search by name, phone or code..."
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-rose-500 shadow-2xs"
                  />
                  {customerDropdownOpen && (
                    <div className="absolute top-full left-0 right-0 mt-1 max-h-52 overflow-y-auto bg-white border border-slate-200 rounded-lg shadow-lg z-30 divide-y divide-slate-100">
                      {filteredCustomers.length === 0 ? (
                        <div className="p-3 text-xs text-slate-400 text-center">No customer found</div>
                      ) : (
                        filteredCustomers.map(c => (
                          <div
                            key={c.id}
                            onClick={() => {
                              setSelectedCustomerId(c.id);
                              setCustomerSearch(`${c.code} - ${c.name}`);
                              setCustomerDropdownOpen(false);
                            }}
                            className="p-2.5 hover:bg-slate-50 cursor-pointer text-xs flex items-center justify-between"
                          >
                            <div>
                              <span className="font-bold text-slate-800">{c.name}</span>
                              <span className="text-slate-400 ml-2 font-mono text-[11px]">({c.code})</span>
                              <div className="text-[11px] text-slate-500">{c.phone || c.address}</div>
                            </div>
                            <div className="text-right">
                              {(() => {
                                const bal = formatCustomerBalance(c.currentBalance || 0);
                                return (
                                  <>
                                    <span className={`text-xs font-mono font-semibold ${bal.isAdvance ? 'text-emerald-700' : (bal.isDue ? 'text-rose-700' : 'text-slate-600')}`}>
                                      {bal.amountText}
                                    </span>
                                    <span className={`text-[10px] block font-medium ${bal.isAdvance ? 'text-emerald-600' : 'text-slate-400'}`}>
                                      {bal.isAdvance ? 'Advance' : (bal.isDue ? 'Receivable' : 'Settled')}
                                    </span>
                                  </>
                                );
                              })()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Amount */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Payment Amount (৳) *
                </label>
                <input
                  type="number"
                  min="1"
                  value={customerAmount}
                  onChange={e => setCustomerAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-rose-500 shadow-2xs"
                />
              </div>
            </div>

            {/* Inline Balance & Particulars */}
            {selectedCustomer && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 bg-white border border-slate-200 rounded-lg text-xs">
                <div>
                  <span className="text-slate-500">Current Balance: </span>
                  {(() => {
                    const bal = formatCustomerBalance(selectedCustomer.currentBalance || 0);
                    return (
                      <strong className={`font-mono ${bal.isAdvance ? 'text-emerald-700' : (bal.isDue ? 'text-rose-700' : 'text-slate-800')}`}>
                        {bal.text}
                      </strong>
                    );
                  })()}
                </div>
                <div className="text-[11px] text-slate-500">
                  Control Head: <span className="font-mono text-slate-700">1000 - Accounts Receivable</span>
                </div>
              </div>
            )}

            <div>
              <label className="text-xs text-slate-600 block mb-1">Particulars / Note (Optional):</label>
              <input
                type="text"
                value={customerParticulars}
                onChange={e => setCustomerParticulars(e.target.value)}
                placeholder="Customer refund or adjustment details..."
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-rose-500"
              />
            </div>

            {/* Overpayment warning notice */}
            {customerOverpaymentWarning && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1.5 flex-1">
                  <p>{customerOverpaymentWarning}</p>
                  <label className="flex items-center gap-2 cursor-pointer font-medium text-amber-950">
                    <input
                      type="checkbox"
                      checked={customerConfirmExcess}
                      onChange={e => setCustomerConfirmExcess(e.target.checked)}
                      className="rounded border-amber-300 text-rose-600 focus:ring-rose-500 cursor-pointer"
                    />
                    <span>I confirm and authorize this customer payment</span>
                  </label>
                </div>
              </div>
            )}
          </div>
        )}

        {/* MIDDLE SECTION 3: Pay to Supplier */}
        {paymentType === 'Pay to Supplier' && (
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3.5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Supplier Selector */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Supplier *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={selectedSupplier ? `${selectedSupplier.code} - ${selectedSupplier.name}` : supplierSearch}
                    onChange={e => {
                      setSupplierSearch(e.target.value);
                      if (selectedSupplierId) setSelectedSupplierId('');
                      setSupplierDropdownOpen(true);
                    }}
                    onFocus={() => setSupplierDropdownOpen(true)}
                    placeholder="Search by supplier name or code..."
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-rose-500 shadow-2xs"
                  />
                  {supplierDropdownOpen && (
                    <div className="absolute top-full left-0 right-0 mt-1 max-h-52 overflow-y-auto bg-white border border-slate-200 rounded-lg shadow-lg z-30 divide-y divide-slate-100">
                      {filteredSuppliers.length === 0 ? (
                        <div className="p-3 text-xs text-slate-400 text-center">No supplier found</div>
                      ) : (
                        filteredSuppliers.map(s => (
                          <div
                            key={s.id}
                            onClick={() => {
                              setSelectedSupplierId(s.id);
                              setSupplierSearch(`${s.code} - ${s.name}`);
                              setSupplierDropdownOpen(false);
                            }}
                            className="p-2.5 hover:bg-slate-50 cursor-pointer text-xs flex items-center justify-between"
                          >
                            <div>
                              <span className="font-bold text-slate-800">{s.name}</span>
                              <span className="text-slate-400 ml-2 font-mono text-[11px]">({s.code})</span>
                              <div className="text-[11px] text-slate-500">{s.country || 'Importer'}</div>
                            </div>
                            <div className="text-right">
                              {(() => {
                                const bal = formatSupplierBalance(s.currentPayable || 0);
                                return (
                                  <>
                                    <span className={`text-xs font-mono font-semibold ${bal.isAdvance ? 'text-emerald-700' : (bal.isPayable ? 'text-rose-700' : 'text-slate-600')}`}>
                                      {bal.amountText}
                                    </span>
                                    <span className={`text-[10px] block font-medium ${bal.isAdvance ? 'text-emerald-600' : 'text-slate-400'}`}>
                                      {bal.isAdvance ? 'Advance' : (bal.isPayable ? 'Payable' : 'Settled')}
                                    </span>
                                  </>
                                );
                              })()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Amount */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Payment Amount (৳) *
                </label>
                <input
                  type="number"
                  min="1"
                  value={supplierAmount}
                  onChange={e => setSupplierAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-rose-500 shadow-2xs"
                />
              </div>
            </div>

            {/* Inline Payable Indicator */}
            {selectedSupplier && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 bg-white border border-slate-200 rounded-lg text-xs">
                <div>
                  <span className="text-slate-500">Current Balance: </span>
                  {(() => {
                    const bal = formatSupplierBalance(selectedSupplier.currentPayable || 0);
                    return (
                      <strong className={`font-mono ${bal.isAdvance ? 'text-emerald-700' : (bal.isPayable ? 'text-rose-700' : 'text-slate-800')}`}>
                        {bal.text}
                      </strong>
                    );
                  })()}
                </div>
                {selectedSupplier.currentPayable > 0 && (
                  <button
                    type="button"
                    onClick={() => setSupplierAmount((selectedSupplier.currentPayable || 0).toString())}
                    className="text-[11px] text-rose-600 hover:text-rose-700 font-bold underline cursor-pointer"
                  >
                    Pay Full Due (৳ {(selectedSupplier.currentPayable || 0).toLocaleString()})
                  </button>
                )}
              </div>
            )}

            <div>
              <label className="text-xs text-slate-600 block mb-1">Particulars / Note (Optional):</label>
              <input
                type="text"
                value={supplierParticulars}
                onChange={e => setSupplierParticulars(e.target.value)}
                placeholder="Supplier bill payment or adjustment details..."
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-rose-500"
              />
            </div>

            {/* Overpayment Warning */}
            {supplierOverpaymentWarning && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1.5 flex-1">
                  <p>{supplierOverpaymentWarning}</p>
                  <label className="flex items-center gap-2 cursor-pointer font-medium text-amber-950">
                    <input
                      type="checkbox"
                      checked={supplierConfirmExcess}
                      onChange={e => setSupplierConfirmExcess(e.target.checked)}
                      className="rounded border-amber-300 text-rose-600 focus:ring-rose-500 cursor-pointer"
                    />
                    <span>I confirm excess / advance payment</span>
                  </label>
                </div>
              </div>
            )}
          </div>
        )}

        {/* BOTTOM SECTION: Paid From, Method, Ref, Narration */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 pt-2">
          {/* Paid From Account */}
          <div className="md:col-span-1">
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Paid From *
            </label>
            <select
              value={paidFromAccountId}
              onChange={e => setPaidFromAccountId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 font-medium focus:outline-none focus:border-rose-500 focus:bg-white"
            >
              <option value="">Select Account...</option>
              {bankAccounts.map(b => (
                <option key={b.id} value={b.id}>
                  {b.bankName} ({b.accountNumber}) — ৳ {(b.ledgerBalance || 0).toLocaleString()}
                </option>
              ))}
            </select>
            {selectedBankAccount && (
              <span className="text-[11px] text-slate-500 mt-1 block">
                Current Balance: <strong className="font-mono text-slate-700">৳ {(selectedBankAccount.ledgerBalance || 0).toLocaleString()}</strong>
              </span>
            )}
          </div>

          {/* Payment Method */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Payment Method
            </label>
            <select
              value={paymentMethod}
              onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-rose-500 focus:bg-white"
            >
              <option value="">Select Payment Method...</option>
              <option value="Cash">Cash</option>
              <option value="Bank Transfer">Bank Transfer (Online / RTGS)</option>
              <option value="Cheque">Cheque</option>
              <option value="Mobile Banking">Mobile Banking (bKash / Nagad)</option>
            </select>
          </div>

          {/* Reference / Cheque No */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Reference / Cheque No (Optional)
            </label>
            <input
              type="text"
              value={referenceNo}
              onChange={e => setReferenceNo(e.target.value)}
              placeholder="e.g. CHQ-882194 or TXN-09"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-rose-500 focus:bg-white"
            />
          </div>
        </div>

        {/* Narration */}
        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1">
            Narration / Description
          </label>
          <textarea
            rows={2}
            value={narration}
            onChange={e => setNarration(e.target.value)}
            placeholder="Payment voucher narration..."
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-rose-500 focus:bg-white resize-none"
          />
        </div>

        {/* Requirement 5: Cash Non-Negative Warning & Block */}
        {isCashDeficit && (
          <div className="p-3.5 bg-rose-50 border border-rose-300 rounded-xl text-xs text-rose-800 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold">Insufficient Cash Balance (Negative Cash Strictly Blocked)</div>
              <div>Current balance of the selected cash account is ৳{(selectedBankAccount?.ledgerBalance || 0).toLocaleString()}, and projected balance after payment is ৳{projectedBankBalance.toLocaleString()}. Cash accounts cannot go negative.</div>
            </div>
          </div>
        )}

        {/* Requirement 5: Bank Overdraft Warning & Admin Approval Checkbox */}
        {isBankOverdraft && (
          <div className="p-3.5 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-900 space-y-2">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Bank Overdraft Warning: </span>
                <span>Current balance is ৳{(selectedBankAccount?.ledgerBalance || 0).toLocaleString()}. After this payment, the bank balance will be negative (৳{projectedBankBalance.toLocaleString()}).</span>
              </div>
            </div>
            <label className="flex items-center gap-2 pl-6 cursor-pointer font-medium text-amber-950">
              <input
                type="checkbox"
                checked={adminApprovedOverdraft}
                onChange={e => setAdminApprovedOverdraft(e.target.checked)}
                className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 border-amber-300"
              />
              <span>I approve this overdraft payment as Admin</span>
            </label>
          </div>
        )}

        {/* Error message */}
        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* FOOTER BAR: Total, Balanced Indicator, Save & Post Button */}
        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-4">
            <div>
              <span className="text-[11px] text-slate-500 block">Total Amount:</span>
              <span className="text-lg font-bold text-slate-900 font-mono">
                ৳ {totalAmount.toLocaleString()}
              </span>
            </div>

            <div className="h-7 w-px bg-slate-200" />

            {/* Requirement 3: Real Double-Entry Balanced Check Display */}
            {isBalanced ? (
              <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-medium bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Balanced (Dr = Cr)</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-rose-700 font-medium bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Unbalanced (Dr: ৳{totalDebits.toLocaleString()} ≠ Cr: ৳{totalCredits.toLocaleString()})</span>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={isSubmitting || totalAmount <= 0 || !isBalanced || isCashDeficit || (isBankOverdraft && !adminApprovedOverdraft)}
            className={`px-6 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer ${
              isSubmitting || totalAmount <= 0 || !isBalanced || isCashDeficit || (isBankOverdraft && !adminApprovedOverdraft)
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-rose-600 hover:bg-rose-500 text-white'
            }`}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Posting to GL...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Save & Post Voucher</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
