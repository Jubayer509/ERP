import React, { useState, useEffect } from 'react';
import { 
  Receipt, 
  X, 
  CheckCircle2, 
  Sparkles, 
  Calendar, 
  FileText, 
  Building2,
  DollarSign,
  Plus,
  Trash2,
  Layers,
  Hammer,
  Zap,
  Users,
  Briefcase
} from 'lucide-react';
import { AccountCOA, JournalVoucher } from '../../types/erp';
import { AccountSearchSelect } from './AccountSearchSelect';
import { ModalWrapper } from '../common/ModalWrapper';

export interface VoucherDebitLine {
  id: string;
  accountCode: string;
  particulars: string;
  amount: number;
}

interface NewFinancialVoucherModalProps {
  isOpen: boolean;
  onClose: () => void;
  coaList: AccountCOA[];
  initialVoucherType?: 'JV' | 'PV' | 'RV' | 'Contra';
  initialDrAccount?: string;
  initialCrAccount?: string;
  initialNarration?: string;
  initialAmount?: number;
  onSaveVoucher: (data: {
    voucherType: 'JV' | 'PV' | 'RV' | 'Contra';
    voucherDate: string;
    narration: string;
    costCenter: string;
    creditAccountCode: string;
    debitLines: { accountCode: string; particulars: string; amount: number }[];
  }) => void;
}

export const NewFinancialVoucherModal: React.FC<NewFinancialVoucherModalProps> = ({
  isOpen,
  onClose,
  coaList,
  initialVoucherType = 'PV',
  initialDrAccount = '',
  initialCrAccount = '',
  initialNarration = '',
  initialAmount,
  onSaveVoucher
}) => {
  const [voucherType, setVoucherType] = useState<'JV' | 'PV' | 'RV' | 'Contra'>(initialVoucherType);
  const [voucherDate, setVoucherDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [costCenter, setCostCenter] = useState('');
  const [mainNarration, setMainNarration] = useState(initialNarration || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Credit Account (Payment Source - Bank or Petty Cash)
  const [crAccount, setCrAccount] = useState(initialCrAccount || '');

  // Multiple Debit Lines (starts with a single blank line)
  const [debitLines, setDebitLines] = useState<VoucherDebitLine[]>([
    {
      id: 'line-1',
      accountCode: initialDrAccount || '',
      particulars: initialNarration || '',
      amount: initialAmount || ('' as any)
    }
  ]);

  const resetForm = () => {
    setCostCenter('');
    setMainNarration('');
    setCrAccount('');
    setDebitLines([
      {
        id: `line-${Date.now()}`,
        accountCode: '',
        particulars: '',
        amount: '' as any
      }
    ]);
  };

  const isDirty = Boolean(
    costCenter ||
    mainNarration !== (initialNarration || '') ||
    crAccount !== (initialCrAccount || '') ||
    debitLines.length > 1 ||
    (debitLines[0]?.accountCode || '') !== (initialDrAccount || '') ||
    (debitLines[0]?.particulars || '') !== (initialNarration || '') ||
    String(debitLines[0]?.amount || '') !== String(initialAmount || '')
  );

  const handleSafeClose = () => {
    if (isSubmitting) return;
    resetForm();
    onClose();
  };

  // Sync state when modal opens or initial props change
  useEffect(() => {
    if (isOpen) {
      setVoucherType(initialVoucherType);
      setCrAccount(initialCrAccount || '');
      setMainNarration(initialNarration || '');
      setCostCenter('');
      setDebitLines([
        {
          id: `line-${Date.now()}`,
          accountCode: initialDrAccount || '',
          particulars: initialNarration || '',
          amount: initialAmount || ('' as any)
        }
      ]);
    }
  }, [isOpen, initialVoucherType, initialDrAccount, initialCrAccount, initialNarration, initialAmount]);

  if (!isOpen) return null;

  // Calculate Total Debit Amount
  const totalDebitAmount = debitLines.reduce((sum, line) => sum + (Number(line.amount) || 0), 0);

  // Add a new debit expense line
  const handleAddLine = () => {
    setDebitLines(prev => [
      ...prev,
      {
        id: `line-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        accountCode: '',
        particulars: '',
        amount: '' as any
      }
    ]);
  };

  // Remove a line
  const handleRemoveLine = (id: string) => {
    if (debitLines.length <= 1) return;
    setDebitLines(prev => prev.filter(l => l.id !== id));
  };

  // Update a line field
  const handleUpdateLine = (id: string, updates: Partial<VoucherDebitLine>) => {
    setDebitLines(prev =>
      prev.map(l => {
        if (l.id === id) {
          const updated = { ...l, ...updates };
          // If account code changed and particulars not customized, update particulars to match head name
          if (updates.accountCode && updates.accountCode !== l.accountCode) {
            const head = coaList.find(c => c.code === updates.accountCode);
            if (head) {
              updated.particulars = head.name;
            }
          }
          return updated;
        }
        return l;
      })
    );
  };

  // Preset: Stone Crushing Complete Package
  const handleApplyCrushingPackagePreset = () => {
    setVoucherType('PV');
    setCrAccount('1020'); // Eastern Bank
    setMainNarration('Stone Crushing Package Bill (Crushing, Electricity, Labor & Office Expenses)');
    setDebitLines([
      {
        id: `line-1-${Date.now()}`,
        accountCode: '5200',
        particulars: 'Stone Crushing & Feeder Machine Bill',
        amount: 0
      },
      {
        id: `line-2-${Date.now()}`,
        accountCode: '5220',
        particulars: 'Crushing Plant Electricity Bill Payment',
        amount: 0
      },
      {
        id: `line-3-${Date.now()}`,
        accountCode: '5210',
        particulars: 'Stone Loading & Unloading Labor Bill',
        amount: 0
      },
      {
        id: `line-4-${Date.now()}`,
        accountCode: '5100',
        particulars: 'Yard Site Office & Administrative Expenses',
        amount: 0
      }
    ]);
  };

  // Preset: Office & Site Operational Costs
  const handleApplyOfficeSitePreset = () => {
    setVoucherType('PV');
    setCrAccount('1010'); // Cash in Hand / Petty Cash
    setMainNarration('Yard & Office Operational Expenses (Paid from Petty Cash)');
    setDebitLines([
      {
        id: `line-1-${Date.now()}`,
        accountCode: '5100',
        particulars: 'Office Stationery & Refreshment Expenses',
        amount: 0
      },
      {
        id: `line-2-${Date.now()}`,
        accountCode: '5120',
        particulars: 'Generator & Site Trip Diesel Fuel Expenses',
        amount: 0
      },
      {
        id: `line-3-${Date.now()}`,
        accountCode: '5210',
        particulars: 'Daily Casual Labor Attendance Bill',
        amount: 0
      }
    ]);
  };

  const creditHead = coaList.find(c => c.code === crAccount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (debitLines.length === 0) return;
    if (totalDebitAmount <= 0) return;

    setIsSubmitting(true);
    try {
      onSaveVoucher({
        voucherType,
        voucherDate,
        narration: mainNarration,
        costCenter,
        creditAccountCode: crAccount,
        debitLines: debitLines.map(l => ({
          accountCode: l.accountCode,
          particulars: l.particulars,
          amount: Number(l.amount) || 0
        }))
      });
      resetForm();
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleSafeClose}
      isDirty={isDirty}
      isSaving={isSubmitting}
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in overflow-hidden h-screen"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-5 border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shadow-2xs">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-slate-900">
                  New Financial Voucher
                </h3>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-mono font-bold px-2 py-0.5 rounded-full">
                  Multi-Item Debit / Single Credit
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            data-modal-close="true"
            disabled={isSubmitting}
            onClick={handleSafeClose}
            className="text-slate-400 hover:text-slate-600 text-sm font-bold w-7 h-7 rounded-lg hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer disabled:opacity-50 shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form Body - Scrollable */}
        <form onSubmit={handleSubmit} autoComplete="off" className="space-y-4 text-xs overflow-y-auto pr-1 flex-1 py-2">
          {/* Voucher Type Pills */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Voucher Type *
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setVoucherType('PV')}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  voucherType === 'PV'
                    ? 'bg-emerald-600 text-white font-bold border-emerald-700 shadow-2xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="font-mono text-xs">PV (Payment)</div>
                <div className={`text-[10px] ${voucherType === 'PV' ? 'text-emerald-100' : 'text-slate-400'}`}>
                  Expense / Payout
                </div>
              </button>

              <button
                type="button"
                onClick={() => setVoucherType('JV')}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  voucherType === 'JV'
                    ? 'bg-purple-600 text-white font-bold border-purple-700 shadow-2xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="font-mono text-xs">JV (Journal)</div>
                <div className={`text-[10px] ${voucherType === 'JV' ? 'text-purple-100' : 'text-slate-400'}`}>
                  Adjustment / General
                </div>
              </button>

              <button
                type="button"
                onClick={() => setVoucherType('RV')}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  voucherType === 'RV'
                    ? 'bg-blue-600 text-white font-bold border-blue-700 shadow-2xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="font-mono text-xs">RV (Receipt)</div>
                <div className={`text-[10px] ${voucherType === 'RV' ? 'text-blue-100' : 'text-slate-400'}`}>
                  Collection / Receipt
                </div>
              </button>

              <button
                type="button"
                onClick={() => setVoucherType('Contra')}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  voucherType === 'Contra'
                    ? 'bg-amber-600 text-white font-bold border-amber-700 shadow-2xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="font-mono text-xs">Contra</div>
                <div className={`text-[10px] ${voucherType === 'Contra' ? 'text-amber-100' : 'text-slate-400'}`}>
                  Cash ⇄ Bank
                </div>
              </button>
            </div>
          </div>

          {/* Date & Cost Center */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Voucher Date *</span>
              </label>
              <input
                type="date"
                required
                value={voucherDate}
                onChange={(e) => setVoucherDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-emerald-500 outline-none text-xs"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-slate-400" />
                <span>Cost Center / Plant</span>
              </label>
              <select
                value={costCenter}
                onChange={(e) => setCostCenter(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-xs cursor-pointer"
              >
                <option value="">Select Cost Center...</option>
                <option value="Sonahat Crushing Plant">Sonahat Crushing Plant</option>
                <option value="Burimari Land Port Yard">Burimari Land Port Yard</option>
                <option value="Bholaganj Site">Bholaganj Site</option>
                <option value="Head Office (Dhaka)">Head Office (Dhaka)</option>
              </select>
            </div>
          </div>

          {/* Quick Preset Buttons for Multi-Expense Entry */}
          <div className="p-3 bg-amber-50/70 border border-amber-200/90 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-amber-950 font-bold text-xs">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Quick Multi-Expense Bundles:</span>
              </div>
              <span className="text-[10px] text-amber-800 bg-amber-200/80 px-2 py-0.5 rounded font-mono font-bold">
                Auto-Fill
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleApplyCrushingPackagePreset}
                className="px-3 py-1.5 bg-white hover:bg-amber-100 text-slate-800 border border-amber-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
              >
                <Hammer className="w-3.5 h-3.5 text-amber-700" />
                <span>Stone Crushing Package (Crushing + Electricity + Labor + Office)</span>
              </button>

              <button
                type="button"
                onClick={handleApplyOfficeSitePreset}
                className="px-3 py-1.5 bg-white hover:bg-amber-100 text-slate-800 border border-amber-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
              >
                <Briefcase className="w-3.5 h-3.5 text-blue-700" />
                <span>Yard & Office Petty Cash (Stationery + Diesel + Labor)</span>
              </button>
            </div>
          </div>

          {/* SECTION 1: MULTIPLE DEBIT EXPENSE LINES */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-mono font-bold text-[10px]">
                  Debit (Dr)
                </span>
                <span>Debit Expense Lines:</span>
              </label>

              <button
                type="button"
                onClick={handleAddLine}
                className="px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-300 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>+ Add Line</span>
              </button>
            </div>

            {/* List of Debit Lines */}
            <div className="space-y-2.5">
              {debitLines.map((line, index) => {
                return (
                  <div
                    key={line.id}
                    className="p-3 bg-slate-50/90 border border-slate-200 rounded-2xl space-y-2.5 transition-all hover:border-slate-300 shadow-2xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-mono font-bold flex items-center justify-center">
                          {index + 1}
                        </span>
                        <span className="font-bold text-slate-800 text-xs">
                          Expense Line #{index + 1}
                        </span>
                      </div>

                      {debitLines.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveLine(line.id)}
                          className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                          title="Remove this expense line"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove</span>
                        </button>
                      )}
                    </div>

                    {/* Account Head Search & Select for this line */}
                    <div>
                      <AccountSearchSelect
                        label={`Debit Account Head #${index + 1}`}
                        selectedCode={line.accountCode}
                        onSelect={(code) => handleUpdateLine(line.id, { accountCode: code })}
                        coaList={coaList}
                        typeBadge="Dr"
                        placeholder="Search by expense code or name (e.g. 5200, 5210, 5220, 5100)..."
                      />
                    </div>

                    {/* Particulars & Amount Grid for this line */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-0.5">
                      <div className="sm:col-span-8">
                        <label className="text-[11px] font-semibold text-slate-600 block mb-0.5">
                          Particulars / Narration
                        </label>
                        <input
                          type="text"
                          required
                          value={line.particulars}
                          onChange={(e) => handleUpdateLine(line.id, { particulars: e.target.value })}
                          placeholder="e.g. Stone crushing feeder machine rent / Crushing electricity bill"
                          className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                        />
                      </div>

                      <div className="sm:col-span-4">
                        <label className="text-[11px] font-semibold text-slate-600 block mb-0.5">
                          Amount (BDT) *
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            required
                            value={line.amount || ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              handleUpdateLine(line.id, { amount: val === '' ? 0 : Number(val) || 0 });
                            }}
                            onFocus={(e) => {
                              if (line.amount === 0) e.target.select();
                            }}
                            placeholder="0"
                            className="w-full pl-2 pr-12 py-2 bg-white border border-slate-200 rounded-xl font-mono font-bold text-xs outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
                          />
                          <span className="absolute right-2 top-2 text-[10px] text-slate-400 font-mono">
                            BDT
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Total Debit Subtotal Bar */}
            <div className="flex items-center justify-between p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-xs">
              <span className="font-semibold text-blue-950">
                Total Debit Expenses ({debitLines.length} lines):
              </span>
              <span className="font-mono font-black text-sm text-blue-800">
                BDT {totalDebitAmount.toLocaleString()}
              </span>
            </div>
          </div>

          {/* SECTION 2: CREDIT PAYMENT ACCOUNT (BANK OR PETTY CASH ONLY) */}
          <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-mono font-bold text-[10px]">
                  Credit (Cr)
                </span>
                <span>Payment Source (Bank or Petty Cash):</span>
              </label>
              <span className="text-[10px] text-emerald-900 bg-emerald-200/80 px-2 py-0.5 rounded font-mono font-bold">
                Bank & Cash Only
              </span>
            </div>

            <AccountSearchSelect
              label="Credit Payment Account (Cr)"
              selectedCode={crAccount}
              onSelect={(code) => setCrAccount(code)}
              coaList={coaList}
              typeBadge="Cr"
              paymentAccountsOnly={true}
              placeholder="Search bank or petty cash (e.g. 1020, 1010, 1025)..."
            />
          </div>

          {/* SECTION 3: OVERALL NARRATION */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>Main Voucher Narration *</span>
            </label>
            <input
              type="text"
              required
              value={mainNarration}
              onChange={(e) => setMainNarration(e.target.value)}
              placeholder="e.g. Sonahat Crushing Package Bill (Crushing, Electricity, Labor & Office Expenses)"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>

          {/* REAL-TIME DOUBLE ENTRY PREVIEW */}
          <div className="p-3 bg-slate-900 text-white rounded-xl font-mono text-xs space-y-2 border border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-[11px] border-b border-slate-800 pb-2">
              <span className="text-slate-400">Double-Entry Balance Check:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Debit Total ({totalDebitAmount.toLocaleString()}) = Credit Total ({totalDebitAmount.toLocaleString()})
              </span>
            </div>

            <div className="space-y-1 text-[11px]">
              <div className="text-slate-400">Debits:</div>
              {debitLines.map((l, i) => {
                const head = coaList.find(c => c.code === l.accountCode);
                return (
                  <div key={l.id} className="flex justify-between text-slate-300 pl-2">
                    <span className="truncate">
                      Dr #{i + 1} [{l.accountCode}] {head?.name || 'Head'}: {l.particulars}
                    </span>
                    <span className="font-bold text-white shrink-0 ml-2">
                      BDT {Number(l.amount || 0).toLocaleString()}
                    </span>
                  </div>
                );
              })}

              <div className="pt-2 border-t border-slate-800 flex justify-between text-emerald-400 font-bold">
                <span className="truncate">
                  Cr [{crAccount}] {creditHead?.name || 'Bank/Cash'}
                </span>
                <span className="text-white shrink-0 ml-2">
                  BDT {totalDebitAmount.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Modal Footer Buttons */}
          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 shrink-0 sticky bottom-0 bg-white">
            <button
              type="button"
              data-modal-close="true"
              onClick={handleSafeClose}
              disabled={isSubmitting}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Posting...' : 'Post Voucher to GL'}</span>
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
