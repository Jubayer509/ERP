import React, { useState } from 'react';
import { 
  Building2, 
  Wallet, 
  X, 
  CheckCircle2, 
  MapPin, 
  DollarSign, 
  FileText, 
  User, 
  Hash, 
  Landmark,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { BankAccount } from '../../types/erp';
import { addBankAccount } from '../../utils/bankAccountStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface NewAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccountCreated: (account: BankAccount) => void;
}

export const NewAccountModal: React.FC<NewAccountModalProps> = ({
  isOpen,
  onClose,
  onAccountCreated
}) => {
  const [accountCategory, setAccountCategory] = useState<'Cash' | 'Bank'>('Cash');
  
  // Cash / POS Specific Fields
  const [linkedPosLocation, setLinkedPosLocation] = useState('');
  const [accountName, setAccountName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [custodianName, setCustodianName] = useState('');
  
  // Bank Specific Fields
  const [bankName, setBankName] = useState('');
  const [bankBranch, setBankBranch] = useState('');
  const [bankAccountType, setBankAccountType] = useState<BankAccount['accountType']>('' as any);
  const [currency, setCurrency] = useState('');

  // Common Fields
  const [openingBalance, setOpeningBalance] = useState<number | ''>('');
  const [coaCode, setCoaCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const resetForm = () => {
    setLinkedPosLocation('');
    setAccountName('');
    setAccountNumber('');
    setCustodianName('');
    setBankName('');
    setBankBranch('');
    setBankAccountType('' as any);
    setCurrency('');
    setOpeningBalance('');
    setCoaCode('');
    setFormError(null);
  };

  const isDirty = Boolean(
    linkedPosLocation || accountName || accountNumber || custodianName ||
    bankName || bankBranch || (openingBalance !== '' && Number(openingBalance) > 0) || coaCode
  );

  const handleSafeClose = () => {
    if (isSubmitting) return;
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  // Auto-fill suggestions when user chooses a specific POS Location from dropdown
  const handlePosChange = (pos: string) => {
    setLinkedPosLocation(pos);
    if (!pos) return;
    if (pos.includes('Burimari')) {
      setAccountName('Burimari Petty Cash');
      setAccountNumber(`POS-BUR-${Math.floor(10 + Math.random() * 90)}`);
      setCoaCode('1013');
      setCustodianName('Yard In-charge / Site Manager');
    } else if (pos.includes('Sonahat')) {
      setAccountName('Sonahat Petty Cash');
      setAccountNumber(`POS-SON-${Math.floor(10 + Math.random() * 90)}`);
      setCoaCode('1014');
      setCustodianName('Plant In-charge');
    } else if (pos.includes('Bholaganj')) {
      setAccountName('Bholaganj Site Cash');
      setAccountNumber(`POS-BHO-${Math.floor(10 + Math.random() * 90)}`);
      setCoaCode('1015');
      setCustodianName('Site Supervisor');
    } else {
      setAccountName('Central Cash');
      setAccountNumber(`POS-DHK-${Math.floor(10 + Math.random() * 90)}`);
      setCoaCode('1010');
      setCustodianName('Cashier / Accountant');
    }
  };

  const handleCategorySwitch = (cat: 'Cash' | 'Bank') => {
    setAccountCategory(cat);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setFormError(null);
    try {
      const numBal = Number(openingBalance) || 0;
      const newAcc: BankAccount = {
        id: `${accountCategory.toLowerCase()}-${Date.now()}`,
        bankName: accountCategory === 'Cash' ? accountName : bankName,
        accountNumber: accountNumber,
        branch: accountCategory === 'Cash' ? (linkedPosLocation || 'Head Office') : (bankBranch || 'Principal Branch'),
        accountType: accountCategory === 'Cash' ? 'POS Cash' : bankAccountType,
        ledgerBalance: numBal,
        statementBalance: numBal,
        currency: currency,
        type: accountCategory === 'Cash' ? 'cash' : 'bank',
        accountCategory: accountCategory,
        ...(accountCategory === 'Cash' && linkedPosLocation ? { linkedPosLocation } : {}),
        ...(coaCode ? { coaCode } : {}),
        ...(custodianName ? { custodianName } : {})
      };

      addBankAccount(newAcc);
      onAccountCreated(newAcc);
      resetForm();
      onClose();
    } catch (err: any) {
      console.error('Account creation failed:', err);
      setFormError(err.message || 'Account creation failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleSafeClose}
      isDirty={isDirty}
      isSaving={isSubmitting}
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in overflow-hidden h-screen"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-5 border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-2xs ${
              accountCategory === 'Cash' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
            }`}>
              {accountCategory === 'Cash' ? <Wallet className="w-5 h-5" /> : <Landmark className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-slate-900">
                  Create New Account
                </h3>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                  accountCategory === 'Cash' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                }`}>
                  {accountCategory === 'Cash' ? 'POS Petty Cash' : 'Bank Account'}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            data-modal-close="true"
            disabled={isSubmitting}
            onClick={handleSafeClose}
            className="text-slate-400 hover:text-slate-600 text-sm font-bold w-7 h-7 rounded-lg hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer disabled:opacity-50 shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} autoComplete="off" className="space-y-4 text-xs overflow-y-auto pr-1 flex-1 py-2">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-300 text-rose-800 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* Account Category Selector */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Account Type *
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleCategorySwitch('Cash')}
                className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  accountCategory === 'Cash'
                    ? 'bg-amber-500 text-slate-950 font-bold border-amber-600 shadow-2xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Wallet className="w-4 h-4" />
                <span>💵 Cash / POS Petty Cash</span>
              </button>

              <button
                type="button"
                onClick={() => handleCategorySwitch('Bank')}
                className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  accountCategory === 'Bank'
                    ? 'bg-blue-600 text-white font-bold border-blue-700 shadow-2xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Landmark className="w-4 h-4" />
                <span>🏦 Corporate Bank Account</span>
              </button>
            </div>
          </div>

          {/* IF CASH / PETTY CASH: POS LOCATION LINKING */}
          {accountCategory === 'Cash' && (
            <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-bold text-amber-950 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-amber-700" />
                  <span>Linked Specific POS *</span>
                </label>
                <span className="text-[10px] bg-amber-200/80 text-amber-900 px-2 py-0.5 rounded font-mono font-bold">
                  POS Integration
                </span>
              </div>

              {/* POS Selection Pills */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handlePosChange('Burimari Land Port Yard (Burimari POS)')}
                  className={`p-2 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    linkedPosLocation.includes('Burimari')
                      ? 'bg-white border-amber-500 shadow-2xs ring-2 ring-amber-400/40 font-bold text-amber-950'
                      : 'bg-white/70 border-slate-200 text-slate-700 hover:bg-white'
                  }`}
                >
                  <div className="font-bold">Burimari Land Port Yard</div>
                  <div className="text-[10px] text-slate-500">Burimari Yard POS Cash</div>
                </button>

                <button
                  type="button"
                  onClick={() => handlePosChange('Sonahat Crushing Plant (Sonahat POS)')}
                  className={`p-2 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    linkedPosLocation.includes('Sonahat')
                      ? 'bg-white border-amber-500 shadow-2xs ring-2 ring-amber-400/40 font-bold text-amber-950'
                      : 'bg-white/70 border-slate-200 text-slate-700 hover:bg-white'
                  }`}
                >
                  <div className="font-bold">Sonahat Crushing Plant</div>
                  <div className="text-[10px] text-slate-500">Sonahat Plant POS Cash</div>
                </button>

                <button
                  type="button"
                  onClick={() => handlePosChange('Bholaganj Site (Bholaganj Site POS)')}
                  className={`p-2 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    linkedPosLocation.includes('Bholaganj')
                      ? 'bg-white border-amber-500 shadow-2xs ring-2 ring-amber-400/40 font-bold text-amber-950'
                      : 'bg-white/70 border-slate-200 text-slate-700 hover:bg-white'
                  }`}
                >
                  <div className="font-bold">Bholaganj Site & Ghat</div>
                  <div className="text-[10px] text-slate-500">Bholaganj Site POS Cash</div>
                </button>

                <button
                  type="button"
                  onClick={() => handlePosChange('Head Office Dhaka (Dhaka HQ POS)')}
                  className={`p-2 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    linkedPosLocation.includes('Dhaka')
                      ? 'bg-white border-amber-500 shadow-2xs ring-2 ring-amber-400/40 font-bold text-amber-950'
                      : 'bg-white/70 border-slate-200 text-slate-700 hover:bg-white'
                  }`}
                >
                  <div className="font-bold">Head Office (Dhaka)</div>
                  <div className="text-[10px] text-slate-500">Central HQ Cash Drawer</div>
                </button>
              </div>

              {/* Account Title */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Cash Account Title *
                </label>
                <input
                  type="text"
                  required
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 outline-none"
                  placeholder="e.g. Burimari Petty Cash"
                />
              </div>

              {/* Custodian / In-charge */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span>Custodian / In-charge</span>
                </label>
                <input
                  type="text"
                  value={custodianName}
                  onChange={(e) => setCustodianName(e.target.value)}
                  className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:ring-2 focus:ring-amber-500 outline-none"
                  placeholder="e.g. Md. Yard Manager"
                />
              </div>
            </div>
          )}

          {/* IF BANK ACCOUNT */}
          {accountCategory === 'Bank' && (
            <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-bold text-blue-950 flex items-center gap-1.5">
                  <Building2 className="w-4 h-4 text-blue-700" />
                  <span>Bank Account Details *</span>
                </label>
                <span className="text-[10px] bg-blue-200/80 text-blue-900 px-2 py-0.5 rounded font-mono font-bold">
                  Corporate Bank
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Bank Name *</label>
                  <input
                    type="text"
                    required
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="e.g. Islami Bank Bangladesh PLC"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Branch *</label>
                  <input
                    type="text"
                    required
                    value={bankBranch}
                    onChange={(e) => setBankBranch(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="e.g. Agrabad Corporate Branch"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Account Type</label>
                  <select
                    value={bankAccountType}
                    onChange={(e) => setBankAccountType(e.target.value as any)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-blue-500 outline-none cursor-pointer"
                  >
                    <option value="">Select Account Type...</option>
                    <option value="Current">Current Account</option>
                    <option value="Savings">Savings Account</option>
                    <option value="Overdraft/LTR">Overdraft / LTR Account</option>
                    <option value="Foreign Currency (USD)">Foreign Currency (USD)</option>
                    <option value="Margin Deposit">LC Margin Deposit</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Currency</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-blue-500 outline-none cursor-pointer"
                  >
                    <option value="">Select Currency...</option>
                    <option value="BDT">BDT</option>
                    <option value="USD">USD</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Account Number & COA Code */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                <Hash className="w-3.5 h-3.5 text-slate-400" />
                <span>Account / Reference Number *</span>
              </label>
              <input
                type="text"
                required
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 outline-none"
                placeholder="e.g. 104-102-009941"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-slate-400" />
                <span>COA Ledger Code (Chart of Accounts) *</span>
              </label>
              <input
                type="text"
                required
                value={coaCode}
                onChange={(e) => setCoaCode(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 outline-none"
                placeholder="e.g. 1011 (Cash) or 1026 (Bank)"
              />
            </div>
          </div>

          {/* Opening Balance */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                <span>Opening Balance ({currency}) *</span>
              </span>
              <span className="font-mono text-[11px] text-emerald-700 font-bold">
                {currency} {openingBalance ? openingBalance.toLocaleString() : 0}
              </span>
            </label>
            <input
              type="number"
              min="0"
              required
              value={openingBalance || ''}
              onChange={(e) => setOpeningBalance(Number(e.target.value))}
              placeholder="Enter opening balance"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>

          {/* Modal Footer Buttons */}
          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 shrink-0 sticky bottom-0 bg-white">
            <button
              type="button"
              data-modal-close="true"
              onClick={handleSafeClose}
              disabled={isSubmitting}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-5 py-2 text-white font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5 transition-colors disabled:opacity-50 ${
                accountCategory === 'Cash' ? 'bg-amber-600 hover:bg-amber-500' : 'bg-blue-600 hover:bg-blue-500'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving...' : (accountCategory === 'Cash' ? 'Save POS Cash Account' : 'Save Bank Account')}</span>
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
