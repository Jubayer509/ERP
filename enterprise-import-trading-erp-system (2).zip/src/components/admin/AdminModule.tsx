import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Settings, 
  Building, 
  KeyRound, 
  History, 
  Database, 
  Lock, 
  CheckCircle2, 
  Sliders, 
  RefreshCw, 
  Clock, 
  Eye, 
  Users, 
  UserPlus, 
  Trash2, 
  UserCheck, 
  XCircle, 
  AlertTriangle, 
  Mail, 
  Building2, 
  Phone, 
  Calendar, 
  ShieldAlert, 
  Edit3, 
  Send,
  Landmark,
  Plus,
  BookOpen,
  Search,
  Wallet,
  ArrowRight,
  Filter,
  CloudUpload
} from 'lucide-react';
import { MOCK_AUDIT_LOGS } from '../../data/mockErpData';
import { useAuth } from '../../contexts/AuthContext';
import { UserRole, BankAccount, JournalVoucher } from '../../types/erp';
import { ROLE_LABELS } from '../../data/mockUsers';
import { FiscalYearManagementTab } from './FiscalYearManagementTab';
import { AddUserModal } from './AddUserModal';
import { EditUserModal } from './EditUserModal';
import { ChangePasswordModal } from './ChangePasswordModal';
import { UserCredentialsModal } from './UserCredentialsModal';
import { UserPermissionsModal } from './UserPermissionsModal';
import { RbacPermissionForm } from './RbacPermissionForm';
import { NewAccountModal } from '../accounts/NewAccountModal';
import { AccountLedgerModal } from '../accounts/AccountLedgerModal';
import { getBankAccounts, subscribeBankAccounts, isCashAccount } from '../../utils/bankAccountStorage';
import { getVouchers, subscribeVouchers } from '../../utils/voucherStorage';
import { ErpUser, UserPermissions } from '../../types/erp';
import { BackupRestoreTab } from './BackupRestoreTab';
import { exportAllTradecoreData } from '../../services/backupService';
import {
  getSystemInventorySettings,
  saveSystemInventorySettings,
  subscribeSystemInventorySettings,
  SystemInventorySettings,
  getCompanyProfile,
  saveCompanyProfile,
  subscribeCompanyProfile,
  CompanyProfileSettings
} from '../../utils/systemSettingsStorage';

export interface AdminModuleProps {
  activeSubTab?: 'users' | 'rbac' | 'banking' | 'fiscal_year' | 'company' | 'sequences' | 'audit' | 'backup_restore';
  onSubTabChange?: (tab: 'users' | 'rbac' | 'banking' | 'fiscal_year' | 'company' | 'sequences' | 'audit' | 'backup_restore') => void;
}

export const AdminModule: React.FC<AdminModuleProps> = ({
  activeSubTab,
  onSubTabChange
}) => {
  const { 
    users, 
    currentUser, 
    addNewUser, 
    updateUserRole, 
    updateUserPermissions, 
    toggleUserStatus, 
    deleteUser, 
    sendPasswordReset 
  } = useAuth();
  const [internalTab, setInternalTab] = useState<'users' | 'rbac' | 'banking' | 'fiscal_year' | 'company' | 'sequences' | 'audit' | 'backup_restore'>('users');
  const activeTab = activeSubTab || internalTab;

  const setActiveTab = (tab: 'users' | 'rbac' | 'banking' | 'fiscal_year' | 'company' | 'sequences' | 'audit' | 'backup_restore') => {
    setInternalTab(tab);
    if (onSubTabChange) {
      onSubTabChange(tab);
    }
  };
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Bank & Cash Accounts State (moved from Accounting per user request)
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  const [vouchers, setVouchers] = useState<JournalVoucher[]>(() => getVouchers());
  const [showNewAccountModal, setShowNewAccountModal] = useState(false);
  const [selectedLedgerAccount, setSelectedLedgerAccount] = useState<BankAccount | null>(null);
  const [bankAccountFilter, setBankAccountFilter] = useState<'ALL' | 'BANK' | 'CASH'>('ALL');
  const [accountSearch, setAccountSearch] = useState('');

  const [inventorySettings, setInventorySettings] = useState<SystemInventorySettings>(() => getSystemInventorySettings());
  const [companyProfile, setCompanyProfile] = useState<CompanyProfileSettings>(() => getCompanyProfile());
  const [isEditingCompany, setIsEditingCompany] = useState(false);
  const [companyForm, setCompanyForm] = useState<CompanyProfileSettings>(() => getCompanyProfile());

  useEffect(() => {
    const unsubB = subscribeBankAccounts(setBankAccounts);
    const unsubV = subscribeVouchers(setVouchers);
    const unsubInv = subscribeSystemInventorySettings(setInventorySettings);
    const unsubComp = subscribeCompanyProfile((updated) => {
      setCompanyProfile(updated);
      setCompanyForm(updated);
    });
    return () => {
      unsubB();
      unsubV();
      unsubInv();
      unsubComp();
    };
  }, []);

  // User Modals State
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedUserForEdit, setSelectedUserForEdit] = useState<ErpUser | null>(null);
  const [selectedUserForPassword, setSelectedUserForPassword] = useState<ErpUser | null>(null);
  const [selectedUserForCredentials, setSelectedUserForCredentials] = useState<ErpUser | null>(null);
  const [selectedUserForPermissions, setSelectedUserForPermissions] = useState<ErpUser | null>(null);
  const [rbacSelectedUid, setRbacSelectedUid] = useState<string>('');

  // RBAC Matrix State
  const [roles, setRoles] = useState([
    {
      role: 'Super Administrator',
      modules: { sales: 'CRUD+A', purchase: 'CRUD+A', lc: 'CRUD+A', inventory: 'CRUD+A', accounts: 'CRUD+A', hr: 'CRUD+A', admin: 'Full' }
    },
    {
      role: 'Commercial Manager (LC)',
      modules: { sales: 'R', purchase: 'CRUD+A', lc: 'CRUD+A', inventory: 'R', accounts: 'R', hr: 'None', admin: 'None' }
    },
    {
      role: 'Head of Accounts (CFO)',
      modules: { sales: 'R+A', purchase: 'R+A', lc: 'R+A', inventory: 'R', accounts: 'CRUD+A', hr: 'R+A', admin: 'None' }
    },
    {
      role: 'Warehouse Officer',
      modules: { sales: 'None', purchase: 'R', lc: 'R', inventory: 'CRUD', accounts: 'None', hr: 'None', admin: 'None' }
    },
    {
      role: 'Sales Executive',
      modules: { sales: 'CRU', purchase: 'None', lc: 'None', inventory: 'R', accounts: 'None', hr: 'None', admin: 'None' }
    }
  ]);

  const [auditLogs, setAuditLogs] = useState(MOCK_AUDIT_LOGS);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Requirement 3: User Management visible ONLY to users with role "admin"
  if (currentUser?.role !== 'admin') {
    return (
      <div className="bg-white border border-rose-200 rounded-3xl p-8 max-w-lg mx-auto text-center space-y-4 my-12 shadow-sm animate-in fade-in">
        <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-2xl mx-auto flex items-center justify-center border border-rose-200 shadow-inner">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            Access Denied
          </h2>
          <p className="text-xs text-rose-700 font-medium mt-1">
            User Management is visible and accessible ONLY to Super Administrators.
          </p>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          Your current role is <strong>Manager</strong>, which does not have access to User Management and System Security settings. Please contact a System Administrator for details.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-xl border border-slate-700 flex items-center gap-2">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider bg-slate-800 text-slate-200 px-2 py-0.5 rounded font-mono">
              Module 07
            </span>
            <span className="text-xs text-slate-500 font-medium">Enterprise Security, RBAC Matrix & Immutable Audit Trail</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900">System Setup, Admin & Security</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Role-based permissions enforcement, multi-branch setup, auto-numbering prefixes, and tamper-evident audit logging.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              try {
                const { filename } = exportAllTradecoreData();
                triggerToast(`✓ Backup downloaded: ${filename}`);
              } catch (e: any) {
                triggerToast(`Export error: ${e.message}`);
              }
            }}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
            title="Download full JSON file containing every tradecore_* local storage key"
          >
            <Database className="w-3.5 h-3.5" />
            <span>Backup / Export all data</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('backup_restore')}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
            title="Restore backup file into Cloud Firestore"
          >
            <CloudUpload className="w-3.5 h-3.5" />
            <span>Import data</span>
          </button>
        </div>
      </div>

      {/* Sub-Module Navigation Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-200">
        <button
          type="button"
          onClick={() => setActiveTab('users')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'users'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>User Accounts</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('rbac')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'rbac'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>RBAC Matrix</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('banking')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'banking'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Landmark className="w-3.5 h-3.5" />
          <span>Bank & Cash Accounts</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('fiscal_year')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'fiscal_year'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-blue-700 bg-blue-50/70 hover:bg-blue-100 border border-blue-200/60'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Fiscal Year</span>
          <span className="text-[10px] bg-emerald-500 text-white font-mono font-bold px-1.5 py-0.2 rounded-full">
            Active/Closed
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('company')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'company'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Building className="w-3.5 h-3.5" />
          <span>Company Profile</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sequences')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'sequences'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Invoice Sequences</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('audit')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'audit'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>System Audit Trail</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('backup_restore')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'backup_restore'
              ? 'bg-indigo-700 text-white shadow-xs'
              : 'text-indigo-700 bg-indigo-50/70 hover:bg-indigo-100 border border-indigo-200/60'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>Backup & Restore</span>
        </button>
      </div>

      {/* Tab 0: User Directory & Multi-User Management */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Enterprise Multi-User Directory & Role Assignments
              </h2>
            </div>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add User Account</span>
            </button>
          </div>

          {/* Users Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-3.5">User Identity & Name</th>
                    <th className="py-3 px-3.5">Role & Access Level</th>
                    <th className="py-3 px-3.5">Assigned Operational Branch</th>
                    <th className="py-3 px-3.5">Phone & Contact</th>
                    <th className="py-3 px-3.5 text-center">Account Status</th>
                    <th className="py-3 px-3.5 text-center">Actions & Role Shift</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u) => {
                    const isSelf = currentUser?.uid === u.uid;
                    const roleMeta = ROLE_LABELS[u.role] || { title: u.role, badgeColor: 'bg-slate-100 text-slate-800' };
                    return (
                      <tr key={u.uid} className={`hover:bg-slate-50/80 transition-colors ${isSelf ? 'bg-blue-50/40' : ''}`}>
                        <td className="py-3 px-3.5">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold flex items-center justify-center text-xs shrink-0 shadow-xs">
                              {u.displayName.charAt(0)}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-slate-900 truncate">
                                  {u.displayName}
                                </span>
                                {u.userId && (
                                  <span className="text-[10px] bg-cyan-50 text-cyan-800 border border-cyan-200 font-mono font-bold px-1.5 py-0.2 rounded">
                                    ID: {u.userId}
                                  </span>
                                )}
                                {isSelf && (
                                  <span className="text-[10px] bg-blue-600 text-white font-bold px-1.5 py-0.2 rounded-full">
                                    You
                                  </span>
                                )}
                              </div>
                              <span className="text-[11px] text-slate-500 font-mono block">
                                {u.email}
                              </span>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-3.5">
                          <select
                            value={u.role === 'admin' ? 'admin' : 'manager'}
                            onChange={(e) => {
                              updateUserRole(u.uid, e.target.value as UserRole);
                              triggerToast(`✓ Updated role for ${u.displayName} to ${e.target.value === 'admin' ? 'Super Admin' : 'Manager'}`);
                            }}
                            className="text-xs font-bold py-1 px-2.5 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 shadow-2xs"
                          >
                            <option value="admin">Super Admin</option>
                            <option value="manager">Manager</option>
                          </select>
                        </td>

                        <td className="py-3 px-3.5 text-slate-700">
                          <span className="truncate block max-w-[200px]">{u.branch}</span>
                        </td>

                        <td className="py-3 px-3.5 text-slate-600 font-mono text-[11px]">
                          {u.phone || 'N/A'}
                        </td>

                        <td className="py-3 px-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              toggleUserStatus(u.uid);
                              triggerToast(`✓ User status toggled for ${u.displayName}`);
                            }}
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-colors cursor-pointer ${
                              u.status === 'active'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                                : 'bg-rose-50 text-rose-700 border-rose-300 hover:bg-rose-100'
                            }`}
                          >
                            {u.status === 'active' ? 'Active' : 'Suspended'}
                          </button>
                        </td>

                        <td className="py-3 px-3.5 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => setSelectedUserForEdit(u)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors cursor-pointer"
                              title="Edit Role, Branch & Account"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => setSelectedUserForPermissions(u)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 transition-colors cursor-pointer"
                              title="Module Access RBAC"
                            >
                              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                            </button>

                            <button
                              type="button"
                              onClick={async () => {
                                if (confirm(`Send Firebase password reset email to ${u.email}?`)) {
                                  const res = await sendPasswordReset(u.email);
                                  if (res.success) {
                                    triggerToast(`✓ Password reset email sent to ${u.email}`);
                                  } else {
                                    triggerToast(`✕ Failed: ${res.error}`);
                                  }
                                }
                              }}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
                              title="Send Password Reset Email"
                            >
                              <Send className="w-3.5 h-3.5 text-blue-600" />
                            </button>

                            <button
                              type="button"
                              onClick={() => setSelectedUserForCredentials(u)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
                              title="View & Copy Login Credentials"
                            >
                              <KeyRound className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => setSelectedUserForPassword(u)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                              title="Change / Set Password"
                            >
                              <Lock className="w-3.5 h-3.5" />
                            </button>

                            {!isSelf && (
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`Are you sure you want to remove user ${u.displayName}?`)) {
                                    deleteUser(u.uid);
                                    triggerToast(`✓ User ${u.displayName} removed from system.`);
                                  }
                                }}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                                title="Remove User"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Add User Account Modal */}
      <AddUserModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onUserCreated={(newUser) => {
          triggerToast(`✓ Created new user account: ${newUser.displayName} (ID: ${newUser.userId || newUser.uid})`);
        }}
      />

      {/* Edit User Account Modal */}
      <EditUserModal
        isOpen={!!selectedUserForEdit}
        user={selectedUserForEdit}
        onClose={() => setSelectedUserForEdit(null)}
        onSuccess={(msg) => triggerToast(msg)}
      />

      {/* Change Password Modal */}
      <ChangePasswordModal
        isOpen={!!selectedUserForPassword}
        user={selectedUserForPassword}
        onClose={() => setSelectedUserForPassword(null)}
        onSuccess={() => {
          triggerToast(`✓ Password successfully updated for ${selectedUserForPassword?.displayName}`);
        }}
      />

      {/* User Credentials Modal */}
      <UserCredentialsModal
        isOpen={!!selectedUserForCredentials}
        user={selectedUserForCredentials}
        onClose={() => setSelectedUserForCredentials(null)}
        onOpenChangePassword={(user) => {
          setSelectedUserForPassword(user);
        }}
      />

      {/* User Permissions Modal */}
      <UserPermissionsModal
        isOpen={!!selectedUserForPermissions}
        user={selectedUserForPermissions}
        onClose={() => setSelectedUserForPermissions(null)}
        onSuccess={() => {
          triggerToast(`✓ Updated module permissions for ${selectedUserForPermissions?.displayName}`);
        }}
      />

      {/* Tab 1: RBAC Permission Center (Tickmark Form) */}
      {activeTab === 'rbac' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800 px-2 py-0.5 rounded font-mono">
                  RBAC Policy
                </span>
                <span className="text-xs text-slate-500 font-medium">2-Role System: Admin & Manager Only</span>
              </div>
              <h2 className="text-base font-bold text-slate-900">
                Access & Permission RBAC Management
              </h2>
            </div>

            {/* Quick User Selector Dropdown */}
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 p-2 rounded-xl">
              <span className="text-xs font-semibold text-slate-700 whitespace-nowrap">Select User:</span>
              <select
                value={rbacSelectedUid || (users.find(u => u.role !== 'admin')?.uid || users[0]?.uid || '')}
                onChange={(e) => setRbacSelectedUid(e.target.value)}
                className="text-xs font-bold py-1.5 px-3 rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
              >
                {users.map(u => (
                  <option key={u.uid} value={u.uid}>
                    {u.displayName} ({u.userId || u.email.split('@')[0]}) — {u.role === 'admin' ? 'Admin' : 'Manager'}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Active Selected User Card & Form */}
          {(() => {
            const activeUser = users.find(u => u.uid === rbacSelectedUid) || users.find(u => u.role !== 'admin') || users[0];
            if (!activeUser) {
              return (
                <div className="p-8 text-center text-slate-400 text-xs">
                  No users found. Please create a user first.
                </div>
              );
            }

            return (
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 rounded-2xl p-4 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-600 font-bold flex items-center justify-center text-sm shadow-xs">
                      {activeUser.displayName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-white">{activeUser.displayName}</span>
                        {activeUser.userId && (
                          <span className="font-mono text-[10px] bg-cyan-900/60 text-cyan-300 border border-cyan-500/40 font-bold px-1.5 py-0.2 rounded">
                            ID: {activeUser.userId}
                          </span>
                        )}
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          activeUser.role === 'admin' 
                            ? 'bg-purple-900/60 text-purple-300 border border-purple-500/40' 
                            : 'bg-blue-900/60 text-blue-300 border border-blue-500/40'
                        }`}>
                          {activeUser.role === 'admin' ? 'Super Admin' : 'Manager'}
                        </span>
                      </div>
                      <span className="text-xs text-slate-300 font-mono">
                        {activeUser.email} • {activeUser.branch}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const newR = activeUser.role === 'admin' ? 'manager' : 'admin';
                        updateUserRole(activeUser.uid, newR);
                        triggerToast(`✓ Role shifted to ${newR === 'admin' ? 'Super Admin' : 'Manager'} for ${activeUser.displayName}`);
                      }}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Switch to {activeUser.role === 'admin' ? 'Manager Role' : 'Admin Role'}
                    </button>
                  </div>
                </div>

                <RbacPermissionForm
                  key={activeUser.uid}
                  user={activeUser}
                  onSave={async (newPermissions) => {
                    await updateUserPermissions(activeUser.uid, newPermissions);
                    triggerToast(`✓ Updated module permissions for ${activeUser.displayName}`);
                  }}
                  showSaveButton={true}
                />
              </div>
            );
          })()}
        </div>
      )}

      {/* Tab: Bank & Cash Accounts (Moved from Accounting to Settings per user request) */}
      {activeTab === 'banking' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Landmark className="w-4 h-4 text-blue-600" />
                <span>Bank & Cash Accounts</span>
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowNewAccountModal(true)}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Open New Bank / Cash Account</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
              <span className="text-[11px] text-slate-500 font-semibold block">Total Active Accounts</span>
              <span className="text-xl font-bold font-mono text-slate-900">{bankAccounts.length} Accounts</span>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
              <span className="text-[11px] text-slate-500 font-semibold block">Bank Accounts Liquidity</span>
              <span className="text-xl font-bold font-mono text-blue-700">
                BDT {bankAccounts.filter(a => a.accountType !== 'Foreign Currency (USD)' && !isCashAccount(a)).reduce((sum, a) => sum + (a.ledgerBalance || 0), 0).toLocaleString()}
              </span>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
              <span className="text-[11px] text-slate-500 font-semibold block">Cash & Petty Cash Balance</span>
              <span className="text-xl font-bold font-mono text-emerald-700">
                BDT {bankAccounts.filter(a => isCashAccount(a)).reduce((sum, a) => sum + (a.ledgerBalance || 0), 0).toLocaleString()}
              </span>
            </div>
          </div>

          {/* Filter & Search */}
          <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                type="button"
                onClick={() => setBankAccountFilter('ALL')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  bankAccountFilter === 'ALL'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All Accounts ({bankAccounts.length})
              </button>
              <button
                type="button"
                onClick={() => setBankAccountFilter('BANK')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  bankAccountFilter === 'BANK'
                    ? 'bg-blue-600 text-white'
                    : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                }`}
              >
                Bank Accounts ({bankAccounts.filter(a => !isCashAccount(a)).length})
              </button>
              <button
                type="button"
                onClick={() => setBankAccountFilter('CASH')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  bankAccountFilter === 'CASH'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                }`}
              >
                Cash & Petty Cash ({bankAccounts.filter(a => isCashAccount(a)).length})
              </button>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <input
                type="text"
                placeholder="Search by title, number, branch..."
                value={accountSearch}
                onChange={(e) => setAccountSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Accounts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {bankAccounts
              .filter(acc => {
                const isCashAcc = isCashAccount(acc);
                if (bankAccountFilter === 'BANK') {
                  return !isCashAcc;
                }
                if (bankAccountFilter === 'CASH') {
                  return isCashAcc;
                }
                return true;
              })
              .filter(acc => {
                if (!accountSearch.trim()) return true;
                const q = accountSearch.toLowerCase();
                return (
                  acc.bankName.toLowerCase().includes(q) ||
                  acc.accountNumber.toLowerCase().includes(q) ||
                  acc.branch.toLowerCase().includes(q)
                );
              })
              .map((account) => {
                const isCash = isCashAccount(account);
                return (
                  <div
                    key={account.id}
                    className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs hover:border-blue-300 transition-all flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                            isCash ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}>
                            {isCash ? <Wallet className="w-5 h-5" /> : <Landmark className="w-5 h-5" />}
                          </div>
                          <div>
                            <h3 className="font-bold text-sm text-slate-900 leading-tight">
                              {account.bankName}
                            </h3>
                            <span className="font-mono text-xs text-slate-500">
                              {account.accountNumber}
                            </span>
                          </div>
                        </div>

                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isCash ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {account.accountType}
                        </span>
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-100 space-y-1 text-xs">
                        <div className="flex justify-between text-slate-600">
                          <span>Location / Branch:</span>
                          <span className="font-semibold text-slate-800 truncate max-w-[180px]">{account.branch}</span>
                        </div>
                        <div className="flex justify-between text-slate-600">
                          <span>Currency:</span>
                          <span className="font-mono font-bold text-slate-900">{account.currency}</span>
                        </div>
                        <div className="flex justify-between items-baseline pt-1">
                          <span className="text-slate-500 font-medium">Ledger Balance:</span>
                          <span className="text-base font-bold font-mono text-slate-900">
                            {account.currency} {account.ledgerBalance.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => setSelectedLedgerAccount(account)}
                        className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <BookOpen className="w-3.5 h-3.5 text-blue-400" />
                        <span>View Account Ledger</span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                      </button>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Tab 1.5: Fiscal Year System (Active / Closed / Reopen) */}
      {activeTab === 'fiscal_year' && (
        <FiscalYearManagementTab />
      )}

      {/* Tab 2: Company & Multi-Branch */}
      {activeTab === 'company' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h3 className="font-bold text-sm text-slate-900">Corporate Entity Profile</h3>
              {!isEditingCompany ? (
                <button
                  type="button"
                  onClick={() => {
                    setCompanyForm(companyProfile);
                    setIsEditingCompany(true);
                  }}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit Profile</span>
                </button>
              ) : (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setCompanyForm(companyProfile);
                      setIsEditingCompany(false);
                    }}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const saved = saveCompanyProfile(
                        companyForm,
                        currentUser?.displayName || currentUser?.email || 'Admin'
                      );
                      setCompanyProfile(saved);
                      setCompanyForm(saved);
                      setIsEditingCompany(false);
                      triggerToast('✓ Company Profile updated successfully');
                    }}
                    className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </button>
                </div>
              )}
            </div>

            {!isEditingCompany ? (
              <div className="space-y-2.5 text-slate-700">
                <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Company Name:</span>
                  <span className="font-bold text-slate-900 text-right">{companyProfile.companyName}</span>
                </div>
                <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Address:</span>
                  <span className="font-semibold text-slate-900 text-right">{companyProfile.address}</span>
                </div>
                <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Mobile:</span>
                  <span className="font-mono font-bold text-slate-900 text-right">{companyProfile.mobile}</span>
                </div>
                <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Fiscal Year Duration:</span>
                  <span className="font-semibold text-slate-900 text-right">{companyProfile.fiscalYearDuration}</span>
                </div>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const saved = saveCompanyProfile(
                    companyForm,
                    currentUser?.displayName || currentUser?.email || 'Admin'
                  );
                  setCompanyProfile(saved);
                  setCompanyForm(saved);
                  setIsEditingCompany(false);
                  triggerToast('✓ Company Profile updated successfully');
                }}
                className="space-y-3"
              >
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Company Name</label>
                  <input
                    type="text"
                    required
                    value={companyForm.companyName}
                    onChange={(e) => setCompanyForm({ ...companyForm, companyName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="M/S JUBAYER OVERSEAS"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Address</label>
                  <input
                    type="text"
                    required
                    value={companyForm.address}
                    onChange={(e) => setCompanyForm({ ...companyForm, address: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Thana Road Patgram, Lalmonirhat"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Mobile</label>
                  <input
                    type="text"
                    required
                    value={companyForm.mobile}
                    onChange={(e) => setCompanyForm({ ...companyForm, mobile: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="01701562509"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Fiscal Year Duration</label>
                  <input
                    type="text"
                    value={companyForm.fiscalYearDuration}
                    onChange={(e) => setCompanyForm({ ...companyForm, fiscalYearDuration: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="July 01 to June 30"
                  />
                </div>
              </form>
            )}
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs">
            <h3 className="font-bold text-sm text-slate-900">Active Operational Branches</h3>
            <div className="space-y-2">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex justify-between font-bold text-slate-900">
                  <span>Head Office ({companyProfile.companyName})</span>
                  <span className="font-mono text-blue-700">BR-01</span>
                </div>
                <p className="text-slate-500 text-[11px] mt-0.5">{companyProfile.address} • Mobile: {companyProfile.mobile}</p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex justify-between font-bold text-slate-900">
                  <span>Burimari & Sonahat Port Operations</span>
                  <span className="font-mono text-blue-700">BR-02</span>
                </div>
                <p className="text-slate-500 text-[11px] mt-0.5">Burimari Land Port, Patgram, Lalmonirhat</p>
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs md:col-span-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Inventory & Sales Stock Control Policy</h3>
                <p className="text-slate-500 text-xs mt-0.5">
                  When OFF (default), sales invoices and dispatches are strictly blocked when line quantity exceeds available warehouse stock. When ON, only Admin users may override with a mandatory reason recorded on the invoice.
                </p>
              </div>
              <label className="inline-flex items-center gap-2.5 cursor-pointer shrink-0 bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-xl">
                <input
                  type="checkbox"
                  checked={inventorySettings.allowNegativeStock}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    const updated = saveSystemInventorySettings(
                      { allowNegativeStock: checked },
                      currentUser?.name || currentUser?.email || 'Admin'
                    );
                    setInventorySettings(updated);
                    triggerToast(`✓ Allow negative stock is now ${checked ? 'ON (Admin override with reason)' : 'OFF (Strictly blocked)'}`);
                  }}
                  className="w-4 h-4 rounded accent-blue-600 cursor-pointer"
                />
                <span className="font-bold text-slate-900">
                  Allow negative stock ({inventorySettings.allowNegativeStock ? 'ON' : 'OFF'})
                </span>
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Document Numbering Sequences */}
      {activeTab === 'sequences' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Document Auto-Numbering Prefix & Sequence Engine</h2>
              <p className="text-xs text-slate-500">Continuous non-gap numbering enforced for statutory compliance</p>
            </div>
            <span className="text-xs font-mono font-bold bg-slate-100 px-3 py-1 rounded text-slate-700">
              Zero-Gap Database Sequences
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block font-sans font-semibold">Sales Orders:</span>
              <span className="font-bold text-blue-700 text-sm">SO-YYYY-NNNN</span>
              <span className="text-[11px] text-slate-400 block mt-1">e.g. SO-2026-0821</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block font-sans font-semibold">Sales Tax Invoices:</span>
              <span className="font-bold text-blue-700 text-sm">INV-YYYY-NNNN</span>
              <span className="text-[11px] text-slate-400 block mt-1">e.g. INV-2026-0412</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block font-sans font-semibold">Letter of Credit:</span>
              <span className="font-bold text-blue-700 text-sm">LC-YYYY-BR-NNNN</span>
              <span className="text-[11px] text-slate-400 block mt-1">e.g. LC-2026-CH-0042</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block font-sans font-semibold">Goods Received Notes:</span>
              <span className="font-bold text-blue-700 text-sm">GRN-YYYY-NNNN</span>
              <span className="text-[11px] text-slate-400 block mt-1">e.g. GRN-2026-0104</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block font-sans font-semibold">Journal Vouchers:</span>
              <span className="font-bold text-blue-700 text-sm">VCH-YYYY-NNNN</span>
              <span className="text-[11px] text-slate-400 block mt-1">e.g. VCH-2026-0301</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block font-sans font-semibold">Delivery Challans:</span>
              <span className="font-bold text-blue-700 text-sm">DC-YYYY-NNNN</span>
              <span className="text-[11px] text-slate-400 block mt-1">e.g. DC-2026-0641</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Audit Trail */}
      {activeTab === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Immutable System Activity & Security Audit Trail</h2>
              <p className="text-xs text-slate-500">Append-only log recording IP addresses, user identity, action, and timestamps</p>
            </div>
            <span className="text-xs font-mono font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1 rounded">
              Cryptographically Gated
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200 font-sans">
                <tr>
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">User</th>
                  <th className="py-2.5 px-3">Module</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">Particulars / Record</th>
                  <th className="py-2.5 px-3">IP Address</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="py-2.5 px-3 text-slate-500">{log.timestamp}</td>
                    <td className="py-2.5 px-3 font-sans font-bold text-slate-900">{log.user}</td>
                    <td className="py-2.5 px-3 font-sans font-medium text-blue-700">{log.module}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-slate-100 font-semibold text-slate-800 text-[10px]">
                        {log.action}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-sans text-slate-700">{log.details}</td>
                    <td className="py-2.5 px-3 text-slate-500">{log.ipAddress}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Backup & Restore */}
      {activeTab === 'backup_restore' && (
        <BackupRestoreTab />
      )}

      {/* New Bank / Cash Account Modal */}
      <NewAccountModal
        isOpen={showNewAccountModal}
        onClose={() => setShowNewAccountModal(false)}
        onAccountCreated={(newAcc) => {
          setBankAccounts(getBankAccounts());
          triggerToast(`✓ New account opened: ${newAcc.bankName} (${newAcc.accountNumber})`);
        }}
      />

      {/* Account Ledger Modal */}
      {selectedLedgerAccount && (
        <AccountLedgerModal
          isOpen={!!selectedLedgerAccount}
          onClose={() => setSelectedLedgerAccount(null)}
          selectedAccount={selectedLedgerAccount}
          allAccounts={bankAccounts}
          vouchers={vouchers}
          onSelectAccount={setSelectedLedgerAccount}
        />
      )}
    </div>
  );
};
