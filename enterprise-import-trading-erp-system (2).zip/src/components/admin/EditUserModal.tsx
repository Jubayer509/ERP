import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  Building2, 
  Mail, 
  Phone, 
  User, 
  Check, 
  AlertCircle,
  KeyRound,
  Send,
  Power
} from 'lucide-react';
import { ErpUser, UserRole } from '../../types/erp';
import { useAuth } from '../../contexts/AuthContext';
import { ROLE_LABELS } from '../../data/mockUsers';
import { ModalWrapper } from '../common/ModalWrapper';

interface EditUserModalProps {
  user: ErpUser | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (msg: string) => void;
}

export const EditUserModal: React.FC<EditUserModalProps> = ({
  user,
  isOpen,
  onClose,
  onSuccess
}) => {
  const { updateUserRoleAndBranch, toggleUserStatus, sendPasswordReset } = useAuth();

  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState<UserRole>('manager');
  const [branch, setBranch] = useState('Corporate Headquarters (Dhaka)');
  const [phone, setPhone] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isSendingReset, setIsSendingReset] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (user) {
      setDisplayName(user.displayName || user.name || '');
      setRole(user.role === 'admin' ? 'admin' : 'manager');
      setBranch(user.branch || 'Corporate Headquarters (Dhaka)');
      setPhone(user.phone || '');
      const activeState = user.active !== undefined ? user.active : user.status === 'active';
      setIsActive(activeState);
      setFeedback(null);
    }
  }, [user]);

  if (!isOpen || !user) return null;

  const originalRole = user.role === 'admin' ? 'admin' : 'manager';
  const originalBranch = user.branch || 'Corporate Headquarters (Dhaka)';
  const originalActive = user.active !== undefined ? user.active : user.status === 'active';
  const isFormDirty = role !== originalRole || branch !== originalBranch || isActive !== originalActive;

  const handleUnifiedClose = () => {
    if (isSaving || isSendingReset) return;
    onClose();
    setFeedback(null);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setIsSaving(true);

    try {
      const res = await updateUserRoleAndBranch(user.uid, role, branch);
      
      // If active state changed, toggle it
      const currentActive = user.active !== undefined ? user.active : user.status === 'active';
      if (currentActive !== isActive) {
        await toggleUserStatus(user.uid);
      }

      setIsSaving(false);
      if (res.success) {
        if (onSuccess) {
          onSuccess(`✓ Updated ${user.displayName}'s role and branch settings successfully.`);
        }
        onClose();
      } else {
        setFeedback({ type: 'error', text: res.error || 'Failed to update user profile.' });
      }
    } catch (err: any) {
      setIsSaving(false);
      setFeedback({ type: 'error', text: err?.message || 'Error saving user.' });
    }
  };

  const handleSendResetEmail = async () => {
    if (!user.email) return;
    setIsSendingReset(true);
    setFeedback(null);
    try {
      const res = await sendPasswordReset(user.email);
      setIsSendingReset(false);
      if (res.success) {
        setFeedback({
          type: 'success',
          text: `✓ Password reset link sent to ${user.email}. User can reset via email.`
        });
      } else {
        setFeedback({
          type: 'error',
          text: res.error || 'Could not send reset email.'
        });
      }
    } catch (err: any) {
      setIsSendingReset(false);
      setFeedback({
        type: 'error',
        text: err?.message || 'Failed to send password reset email.'
      });
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleUnifiedClose}
      isDirty={isFormDirty}
      isSaving={isSaving || isSendingReset}
      backdropClassName="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                Edit User Account
              </h3>
            </div>
          </div>
          <button 
            type="button"
            onClick={handleUnifiedClose}
            disabled={isSaving || isSendingReset}
            className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer disabled:opacity-50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* User Capsule */}
        <div className="bg-slate-50 border-b border-slate-200 p-3.5 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white font-bold flex items-center justify-center text-sm shadow-xs">
              {user.displayName?.charAt(0) || 'U'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-sm">{user.displayName}</span>
                {user.userId && (
                  <span className="text-[10px] bg-cyan-100 text-cyan-800 font-mono font-bold px-1.5 py-0.2 rounded border border-cyan-200">
                    ID: {user.userId}
                  </span>
                )}
              </div>
              <span className="text-[11px] text-slate-500 font-mono block">
                {user.email}
              </span>
            </div>
          </div>

          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
            isActive 
              ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
              : 'bg-rose-50 text-rose-700 border-rose-300'
          }`}>
            {isActive ? 'Active' : 'Disabled'}
          </span>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-5 space-y-4 text-xs overflow-y-auto flex-1">
          {feedback && (
            <div className={`p-3 rounded-xl text-xs flex items-start gap-2 animate-in fade-in ${
              feedback.type === 'success' 
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-800' 
                : 'bg-rose-50 border border-rose-200 text-rose-800'
            }`}>
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="font-medium">{feedback.text}</span>
            </div>
          )}

          {/* 1. Name */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Full Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <input
                type="text"
                disabled
                value={displayName}
                className="w-full pl-9 pr-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-slate-700 font-medium cursor-not-allowed"
              />
            </div>
          </div>

          {/* 2. Role Selector */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>Designated Role *</span>
            </label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold"
            >
              <option value="manager">Manager (Custom Module Access)</option>
              <option value="admin">Super Admin / Owner (Full Access)</option>
            </select>
          </div>

          {/* 3. Branch Selector */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Assigned Branch / Site *</span>
            </label>
            <select
              value={branch}
              onChange={(e) => setBranch(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
            >
              <option value="Corporate Headquarters (Dhaka)">Corporate Headquarters (Dhaka)</option>
              <option value="Chittagong Port Branch (BR-02)">Chittagong Port Branch</option>
              <option value="Burimari Land Port Unit">Burimari Land Port Unit</option>
              <option value="Sonahat Land Port Unit">Sonahat Land Port Unit</option>
              <option value="Tejgaon Central Depot">Tejgaon Central Depot</option>
              <option value="All Branches">All Branches</option>
            </select>
          </div>

          {/* 4. Account Status Toggle */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between bg-slate-50 p-3 rounded-xl border">
            <div>
              <span className="font-bold text-slate-800 block text-xs">
                Account Status
              </span>
              <span className="text-[11px] text-slate-500 block">
                {isActive ? 'Account can log in and perform actions' : 'Account is disabled / suspended from login'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setIsActive(!isActive)}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                isActive 
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white' 
                  : 'bg-rose-600 hover:bg-rose-500 text-white'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>{isActive ? 'Active' : 'Disabled'}</span>
            </button>
          </div>

          {/* 5. Trigger Password Reset Email */}
          <div className="pt-2 border-t border-slate-100 bg-blue-50/50 p-3 rounded-xl border border-blue-100 flex items-center justify-between gap-3">
            <div>
              <span className="font-bold text-blue-950 block text-xs flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-blue-600" />
                <span>Trigger Password Reset Email</span>
              </span>
              <span className="text-[11px] text-blue-700 block mt-0.5">
                Send a secure Firebase password reset email directly to {user.email}
              </span>
            </div>
            <button
              type="button"
              onClick={handleSendResetEmail}
              disabled={isSendingReset}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-300 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-2xs transition-colors shrink-0 cursor-pointer"
            >
              {isSendingReset ? (
                <span>Sending...</span>
              ) : (
                <>
                  <Send className="w-3 h-3" />
                  <span>Send Reset</span>
                </>
              )}
            </button>
          </div>

          {/* Modal Actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={handleUnifiedClose}
              disabled={isSaving || isSendingReset}
              className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white rounded-xl font-bold shadow-xs cursor-pointer flex items-center gap-1.5 transition-colors"
            >
              {isSaving ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save Changes</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
