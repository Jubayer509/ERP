import React, { useState } from 'react';
import { 
  Copy, 
  Check, 
  X, 
  ShieldCheck, 
  KeyRound, 
  Mail, 
  Building2, 
  User 
} from 'lucide-react';
import { ErpUser } from '../../types/erp';
import { ROLE_LABELS } from '../../data/mockUsers';
import { ModalWrapper } from '../common/ModalWrapper';

interface UserCredentialsModalProps {
  user: ErpUser | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenChangePassword?: (user: ErpUser) => void;
}

export const UserCredentialsModal: React.FC<UserCredentialsModalProps> = ({
  user,
  isOpen,
  onClose,
  onOpenChangePassword
}) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [allCopied, setAllCopied] = useState(false);

  if (!isOpen || !user) return null;

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const copyAll = () => {
    const summary = [
      `🏢 TradeCore ERP - System Login Credentials`,
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
      `👤 Employee Name: ${user.displayName}`,
      `🆔 User ID: ${user.userId || user.uid}`,
      `📧 Login Email: ${user.email}`,
      user.password ? `🔑 Password: ${user.password}` : `🔑 Password: (Managed via Firebase Auth / System Reset)`,
      `💼 Role: ${ROLE_LABELS[user.role]?.title || user.role}`,
      `📍 Assigned Branch: ${user.branch}`,
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
      `🌐 Sign in at ERP Login using User ID or Email`
    ].join('\n');

    navigator.clipboard.writeText(summary);
    setAllCopied(true);
    setTimeout(() => setAllCopied(false), 2000);
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      isDirty={false}
      backdropClassName="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm">User Login Credentials</h3>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700">
          <div className="bg-slate-900 rounded-2xl p-4 text-white space-y-3">
            {/* User ID */}
            <div className="flex items-center justify-between bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
              <div>
                <span className="text-[10px] text-slate-400 block font-medium">User Login ID:</span>
                <span className="text-sm font-mono font-bold text-cyan-300">
                  {user.userId || user.uid}
                </span>
              </div>
              <button
                type="button"
                onClick={() => copyToClipboard(user.userId || user.uid, 'userId')}
                className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
              >
                {copiedField === 'userId' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedField === 'userId' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {/* Email */}
            <div className="flex items-center justify-between bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
              <div>
                <span className="text-[10px] text-slate-400 block font-medium">Corporate Email:</span>
                <span className="text-xs font-mono text-slate-200 truncate max-w-[200px] block">
                  {user.email}
                </span>
              </div>
              <button
                type="button"
                onClick={() => copyToClipboard(user.email, 'email')}
                className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
              >
                {copiedField === 'email' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedField === 'email' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {/* Password */}
            <div className="flex items-center justify-between bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
              <div>
                <span className="text-[10px] text-slate-400 block font-medium">Password:</span>
                <span className="text-sm font-mono font-bold text-amber-300">
                  {user.password || '••••••••'}
                </span>
              </div>
              {user.password ? (
                <button
                  type="button"
                  onClick={() => copyToClipboard(user.password || '', 'password')}
                  className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
                >
                  {copiedField === 'password' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedField === 'password' ? 'Copied' : 'Copy'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    if (onOpenChangePassword) onOpenChangePassword(user);
                  }}
                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[11px] font-semibold cursor-pointer"
                >
                  Set Password
                </button>
              )}
            </div>

            {/* Meta */}
            <div className="grid grid-cols-2 gap-2 text-xs pt-1">
              <div className="bg-slate-800/50 p-2 rounded-lg">
                <span className="text-[10px] text-slate-400 block">Role:</span>
                <span className="font-semibold text-slate-200">
                  {ROLE_LABELS[user.role]?.title || user.role}
                </span>
              </div>
              <div className="bg-slate-800/50 p-2 rounded-lg">
                <span className="text-[10px] text-slate-400 block">Branch:</span>
                <span className="font-semibold text-slate-200 truncate block">
                  {user.branch}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <button
              type="button"
              onClick={copyAll}
              className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              {allCopied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              <span>{allCopied ? 'Credentials Copied!' : 'Copy All Credentials'}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  if (onOpenChangePassword) onOpenChangePassword(user);
                }}
                className="flex-1 py-2 px-3 border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Change Password
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};
