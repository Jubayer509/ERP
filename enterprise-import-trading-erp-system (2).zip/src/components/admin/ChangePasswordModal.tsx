import React, { useState } from 'react';
import { 
  KeyRound, 
  Eye, 
  EyeOff, 
  Sparkles, 
  Check, 
  Copy, 
  CheckCircle2, 
  AlertCircle, 
  X,
  Lock
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { ErpUser } from '../../types/erp';
import { ModalWrapper } from '../common/ModalWrapper';

interface ChangePasswordModalProps {
  user: ErpUser | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({
  user,
  isOpen,
  onClose,
  onSuccess
}) => {
  const { updateUserPassword } = useAuth();
  const [newPassword, setNewPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const isFormDirty = !successMsg && newPassword.trim() !== '';

  const handleUnifiedClose = () => {
    if (isSubmitting) return;
    onClose();
    setNewPassword('');
    setErrorMsg(null);
    setSuccessMsg(null);
  };

  if (!isOpen || !user) return null;

  const generatePassword = () => {
    const prefixes = ['Trade', 'Apex', 'Core', 'Pass', 'Burimari', 'Sonahat'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const symbols = ['@', '#', '$', '!'];
    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    const num = Math.floor(100 + Math.random() * 900);
    const generated = `${prefix}${symbol}${num}`;
    setNewPassword(generated);
    setShowPassword(true);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(newPassword);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const clean = newPassword.trim();
    if (!clean || clean.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }

    setIsSubmitting(true);
    const res = await updateUserPassword(user.uid, clean);
    setIsSubmitting(false);

    if (res.success) {
      setSuccessMsg(`✓ Password updated successfully for ${user.displayName}`);
      if (onSuccess) onSuccess();
    } else {
      setErrorMsg(res.error || 'Failed to update password.');
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleUnifiedClose}
      isDirty={isFormDirty}
      isSaving={isSubmitting}
      backdropClassName="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm">Change User Password</h3>
            </div>
          </div>
          <button 
            type="button"
            onClick={handleUnifiedClose}
            disabled={isSubmitting}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer disabled:opacity-50"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* User Identity Banner */}
        <div className="bg-slate-50 border-b border-slate-200 p-3.5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 text-white font-bold flex items-center justify-center text-xs shrink-0 shadow-xs">
            {user.displayName.charAt(0)}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-900 text-xs truncate">{user.displayName}</span>
              {user.userId && (
                <span className="font-mono text-[10px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.2 rounded">
                  ID: {user.userId}
                </span>
              )}
            </div>
            <span className="text-[11px] text-slate-500 font-mono block truncate">
              {user.email}
            </span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs text-slate-700">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold block">{successMsg}</span>
                <span className="text-[11px] text-emerald-700 mt-1 block">
                  New Password: <strong className="font-mono">{newPassword}</strong>
                </span>
              </div>
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-blue-600" />
                <span>New Password *</span>
              </label>
              <button
                type="button"
                onClick={generatePassword}
                className="text-[11px] text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
              >
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>Generate</span>
              </button>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new password (min 6 chars)"
                className="w-full pl-3 pr-20 py-2 border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono font-semibold"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {newPassword && (
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                    title="Copy password"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              The user can sign in using this new password with their User ID or Email.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={handleUnifiedClose}
              disabled={isSubmitting}
              className="px-3.5 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer disabled:opacity-50"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-400 text-white rounded-xl font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              {isSubmitting ? 'Updating...' : 'Save Password'}
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
