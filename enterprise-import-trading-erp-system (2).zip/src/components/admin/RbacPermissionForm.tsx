import React, { useState, useEffect } from 'react';
import { 
  Check, 
  ShieldCheck, 
  CheckSquare, 
  Square, 
  RotateCcw, 
  Save, 
  Sparkles,
  LayoutGrid, 
  TrendingUp, 
  ShoppingCart, 
  Ship, 
  Boxes, 
  Receipt, 
  FileText, 
  Users, 
  Lock,
  AlertCircle
} from 'lucide-react';
import { 
  UserPermissions, 
  DEFAULT_ADMIN_PERMISSIONS, 
  DEFAULT_MANAGER_PERMISSIONS, 
  ErpUser, 
  UserRole 
} from '../../types/erp';
import { ROLE_LABELS } from '../../data/mockUsers';

interface RbacPermissionFormProps {
  user?: ErpUser | null;
  role?: UserRole;
  initialPermissions?: UserPermissions;
  onSave?: (permissions: UserPermissions) => Promise<void> | void;
  onChange?: (permissions: UserPermissions) => void;
  showSaveButton?: boolean;
  compact?: boolean;
}

interface ModuleItem {
  key: keyof UserPermissions;
  label: string;
  bengali: string;
  description: string;
  icon: React.FC<{ className?: string }>;
  iconBg: string;
  category: 'core' | 'operations' | 'finance' | 'admin';
}

const MODULE_DEFINITIONS: ModuleItem[] = [
  {
    key: 'dashboard',
    label: 'Dashboard Overview',
    bengali: 'Dashboard',
    description: 'Business charts, revenue/expense analytics & daily summary',
    icon: LayoutGrid,
    iconBg: 'bg-indigo-50 text-indigo-600 border-indigo-200',
    category: 'core'
  },
  {
    key: 'sales',
    label: 'Sales & POS Invoicing',
    bengali: 'Sales & POS',
    description: 'Sales invoices, customer payments, delivery orders & measurement reports',
    icon: TrendingUp,
    iconBg: 'bg-blue-50 text-blue-600 border-blue-200',
    category: 'operations'
  },
  {
    key: 'purchase',
    label: 'Purchase & Store',
    bengali: 'Purchase & Suppliers',
    description: 'Purchase invoices, goods received (GRN), weight slips & supplier ledgers',
    icon: ShoppingCart,
    iconBg: 'bg-amber-50 text-amber-600 border-amber-200',
    category: 'operations'
  },
  {
    key: 'lc',
    label: 'LC & Import Hub',
    bengali: 'LC & Import',
    description: 'Letters of Credit, bank margin, Bill of Entry & border receiving',
    icon: Ship,
    iconBg: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    category: 'operations'
  },
  {
    key: 'inventory',
    label: 'Item & Warehouse',
    bengali: 'Inventory',
    description: 'Product catalog, stock levels, shortage tracking & warehouse transfers',
    icon: Boxes,
    iconBg: 'bg-teal-50 text-teal-700 border-teal-200',
    category: 'operations'
  },
  {
    key: 'accounts',
    label: 'Accounts & Banking',
    bengali: 'Accounting',
    description: 'Chart of Accounts, journal vouchers, cash/bank accounts & ledgers',
    icon: Receipt,
    iconBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    category: 'finance'
  },
  {
    key: 'reports',
    label: 'Reports & Statements',
    bengali: 'Reports & Audit',
    description: 'Customer ledgers, trial balance, truck reports & balance sheet',
    icon: FileText,
    iconBg: 'bg-violet-50 text-violet-700 border-violet-200',
    category: 'finance'
  },
  {
    key: 'hrm',
    label: 'HRM & Payroll',
    bengali: 'HRM & Payroll',
    description: 'Employee profiles, daily attendance & salary/allowance management',
    icon: Users,
    iconBg: 'bg-rose-50 text-rose-600 border-rose-200',
    category: 'core'
  },
  {
    key: 'admin',
    label: 'System & Security',
    bengali: 'System & Security',
    description: 'User creation, role assignment, backups & sequence configuration',
    icon: ShieldCheck,
    iconBg: 'bg-purple-50 text-purple-700 border-purple-200',
    category: 'admin'
  }
];

export const RbacPermissionForm: React.FC<RbacPermissionFormProps> = ({
  user,
  role,
  initialPermissions,
  onSave,
  onChange,
  showSaveButton = true,
  compact = false
}) => {
  const effectiveRole: UserRole = role || user?.role || 'manager';
  const isAdmin = effectiveRole === 'admin';

  const [permissions, setPermissions] = useState<UserPermissions>(() => {
    if (initialPermissions) return { ...initialPermissions };
    if (user?.permissions) return { ...user.permissions };
    return isAdmin ? { ...DEFAULT_ADMIN_PERMISSIONS } : { ...DEFAULT_MANAGER_PERMISSIONS };
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    if (initialPermissions) {
      setPermissions({ ...initialPermissions });
    } else if (user?.permissions) {
      setPermissions({ ...user.permissions });
    } else if (isAdmin) {
      setPermissions({ ...DEFAULT_ADMIN_PERMISSIONS });
    } else {
      setPermissions({ ...DEFAULT_MANAGER_PERMISSIONS });
    }
  }, [user?.uid, user?.permissions, initialPermissions, isAdmin]);

  const togglePermission = (key: keyof UserPermissions) => {
    const updated = {
      ...permissions,
      [key]: !permissions[key]
    };
    setPermissions(updated);
    if (onChange) onChange(updated);
  };

  const setAll = (val: boolean) => {
    const updated: UserPermissions = {
      dashboard: val,
      sales: val,
      purchase: val,
      lc: val,
      inventory: val,
      accounts: val,
      hrm: val,
      reports: val,
      admin: val
    };
    setPermissions(updated);
    if (onChange) onChange(updated);
  };

  const resetToManagerDefault = () => {
    const updated = { ...DEFAULT_MANAGER_PERMISSIONS };
    setPermissions(updated);
    if (onChange) onChange(updated);
  };

  const handleSave = async () => {
    if (!onSave) return;
    setIsSaving(true);
    try {
      await onSave(permissions);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } finally {
      setIsSaving(false);
    }
  };

  const activeCount = Object.values(permissions).filter(Boolean).length;

  return (
    <div className="space-y-4">
      {/* Top Banner & Quick Controls */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-blue-600/10 text-blue-600 border border-blue-200 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-xs sm:text-sm text-slate-900">
                RBAC Access Control
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-mono ${
                isAdmin 
                  ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                  : 'bg-blue-100 text-blue-800 border border-blue-200'
              }`}>
                {ROLE_LABELS[effectiveRole]?.title.split('(')[0].trim() || effectiveRole}
              </span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={() => setAll(true)}
            className="px-2.5 py-1 text-[11px] font-semibold bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
          >
            <CheckSquare className="w-3 h-3 text-emerald-600" />
            <span>Select All</span>
          </button>

          <button
            type="button"
            onClick={() => setAll(false)}
            className="px-2.5 py-1 text-[11px] font-semibold bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
          >
            <Square className="w-3 h-3 text-slate-400" />
            <span>Deselect All</span>
          </button>

          <button
            type="button"
            onClick={resetToManagerDefault}
            className="px-2.5 py-1 text-[11px] font-semibold bg-blue-50 border border-blue-200 hover:bg-blue-100 text-blue-700 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Manager Default</span>
          </button>

          <span className="text-[11px] font-mono font-bold px-2 py-1 bg-slate-200 text-slate-800 rounded-lg">
            {activeCount} / 9 Enabled
          </span>
        </div>
      </div>

      {/* Admin Notice if user has Admin role */}
      {isAdmin && (
        <div className="p-3 bg-purple-50 border border-purple-200 rounded-xl text-purple-900 text-xs flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
          <div className="text-[11px]">
            <strong>Super Admin Role:</strong> All 9 system modules are automatically enabled for Admin users.
          </div>
        </div>
      )}

      {/* The 9-Module Tickmark Grid */}
      <div className={`grid grid-cols-1 ${compact ? 'sm:grid-cols-2' : 'sm:grid-cols-2 lg:grid-cols-3'} gap-2.5 sm:gap-3`}>
        {MODULE_DEFINITIONS.map((mod) => {
          const isChecked = !!permissions[mod.key];
          const Icon = mod.icon;

          return (
            <div
              key={mod.key}
              onClick={() => togglePermission(mod.key)}
              className={`relative rounded-2xl p-3 sm:p-3.5 border transition-all cursor-pointer select-none flex flex-col justify-between ${
                isChecked
                  ? 'bg-white border-blue-400/90 shadow-sm ring-1 ring-blue-500/20'
                  : 'bg-slate-50/70 border-slate-200 opacity-70 hover:opacity-100 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start gap-3">
                {/* Large Checkbox / Tickmark */}
                <div className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                  isChecked
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'border-2 border-slate-300 bg-white hover:border-slate-400'
                }`}>
                  {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>

                {/* Module Details */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-bold text-slate-900 text-xs">
                      {mod.label}
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium bg-slate-100 px-1.5 py-0.2 rounded">
                      {mod.bengali}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {mod.description}
                  </p>
                </div>

                {/* Module Icon Badge */}
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border ${mod.iconBg}`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>

              {/* Status footer pill */}
              <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px]">
                <span className={`font-semibold ${isChecked ? 'text-emerald-700' : 'text-slate-400'}`}>
                  {isChecked ? '✓ Allowed' : '✕ Restricted'}
                </span>
                <span className="text-slate-400 font-mono text-[9px] uppercase tracking-wider">
                  {mod.key}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Save Button (when onSave is provided) */}
      {showSaveButton && onSave && (
        <div className="pt-2 flex items-center justify-between border-t border-slate-200">
          <div className="text-xs text-slate-500">
            {saveSuccess && (
              <span className="text-emerald-600 font-bold flex items-center gap-1 animate-in fade-in">
                ✓ Permissions successfully saved!
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-400 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            {isSaving ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Save className="w-3.5 h-3.5" />
            )}
            <span>{isSaving ? 'Saving...' : 'Save Permissions'}</span>
          </button>
        </div>
      )}
    </div>
  );
};
