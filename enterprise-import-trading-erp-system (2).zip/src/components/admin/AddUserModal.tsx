import React, { useState } from 'react';
import { 
  UserPlus, 
  KeyRound, 
  Mail, 
  User, 
  Building2, 
  Phone, 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  Sparkles, 
  Copy, 
  Check, 
  CheckCircle2, 
  AlertCircle,
  X
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { 
  UserRole, 
  ErpUser, 
  UserPermissions, 
  DEFAULT_ADMIN_PERMISSIONS, 
  DEFAULT_MANAGER_PERMISSIONS 
} from '../../types/erp';
import { ROLE_LABELS } from '../../data/mockUsers';
import { RbacPermissionForm } from './RbacPermissionForm';
import { ModalWrapper } from '../common/ModalWrapper';

interface AddUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUserCreated?: (user: ErpUser) => void;
}

export const AddUserModal: React.FC<AddUserModalProps> = ({
  isOpen,
  onClose,
  onUserCreated
}) => {
  const { addNewUser, users } = useAuth();

  // Form State
  const [displayName, setDisplayName] = useState('');
  const [userId, setUserId] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState<UserRole>('' as any);
  const [permissions, setPermissions] = useState<UserPermissions>(DEFAULT_MANAGER_PERMISSIONS);
  const [branch, setBranch] = useState('');
  const [phone, setPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Success summary state
  const [createdUser, setCreatedUser] = useState<ErpUser | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [allCopied, setAllCopied] = useState(false);

  if (!isOpen) return null;

  // Generate suggested User ID based on branch & role
  const generateUserId = () => {
    let prefix = 'EMP';
    if (branch.includes('Burimari')) {
      prefix = 'BUR';
    } else if (branch.includes('Sonahat')) {
      prefix = 'SON';
    } else if (role === 'admin') {
      prefix = 'ADM';
    } else if (role === 'accounts') {
      prefix = 'ACC';
    } else if (role === 'sales') {
      prefix = 'SAL';
    }

    const randomNum = Math.floor(10 + Math.random() * 90);
    const newId = `${prefix}-${randomNum}`;
    setUserId(newId);

    // Auto-update email if not manually altered
    if (!email || email.includes('@tradecore-erp.com')) {
      setEmail(`${newId.toLowerCase()}@tradecore-erp.com`);
    }
  };

  // Generate secure readable password
  const generatePassword = () => {
    const prefixes = ['Trade', 'Apex', 'Core', 'Burimari', 'Sonahat', 'Port'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const symbols = ['@', '#', '$', '!'];
    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    const num = Math.floor(100 + Math.random() * 900);
    const generated = `${prefix}${symbol}${num}`;
    setPassword(generated);
    setShowPassword(true);
  };

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const copyAllCredentials = () => {
    if (!createdUser) return;
    const summary = [
      `🏢 TradeCore ERP - System Login Credentials`,
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
      `👤 Employee Name: ${createdUser.displayName}`,
      `🆔 User ID: ${createdUser.userId || createdUser.uid}`,
      `📧 Login Email: ${createdUser.email}`,
      `🔑 Password: ${createdUser.password || password}`,
      `💼 Designated Role: ${ROLE_LABELS[createdUser.role]?.title || createdUser.role}`,
      `📍 Assigned Branch: ${createdUser.branch}`,
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
      `🌐 Login URL: System Portal (Use User ID or Email to Sign In)`
    ].join('\n');

    navigator.clipboard.writeText(summary);
    setAllCopied(true);
    setTimeout(() => setAllCopied(false), 2500);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const cleanName = displayName.trim();
    const cleanUserId = (userId || '').trim().toUpperCase();
    let cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    if (!cleanName) {
      setFormError('Please enter full name.');
      return;
    }

    if (!cleanPassword || cleanPassword.length < 6) {
      setFormError('Password must be at least 6 characters.');
      return;
    }

    if (!cleanEmail && !cleanUserId) {
      setFormError('Please provide a User ID or Email.');
      return;
    }

    if (!cleanEmail && cleanUserId) {
      cleanEmail = `${cleanUserId.toLowerCase()}@tradecore-erp.com`;
    }

    // Check for duplicate User ID
    if (cleanUserId && users.some(u => u.userId?.toUpperCase() === cleanUserId)) {
      setFormError(`User ID "${cleanUserId}" is already assigned to another user.`);
      return;
    }

    // Check for duplicate Email
    if (users.some(u => u.email.toLowerCase() === cleanEmail)) {
      setFormError(`Email "${cleanEmail}" is already registered.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await addNewUser({
        displayName: cleanName,
        userId: cleanUserId,
        email: cleanEmail,
        password: cleanPassword,
        role,
        branch,
        phone: phone.trim(),
        status: 'active',
        assignedOffice: (branch.includes('Burimari') ? 'Burimari Office' : branch.includes('Sonahat') ? 'Sonahat Office' : 'All Branches') as any,
        permissions: role === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : permissions
      }, cleanPassword);

      setIsSubmitting(false);

      if (res?.success && res.user) {
        setCreatedUser(res.user);
        if (onUserCreated) onUserCreated(res.user);
      } else {
        setFormError(res?.error || 'Failed to create user account. Please try again.');
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setFormError(err?.message || 'Error occurred while creating user.');
    }
  };

  const handleResetForNext = () => {
    setCreatedUser(null);
    setDisplayName('');
    setUserId('');
    setEmail('');
    setPassword('');
    setShowPassword(false);
    setRole('' as any);
    setBranch('');
    setPhone('');
    setPermissions(DEFAULT_MANAGER_PERMISSIONS);
    setFormError(null);
  };

  const isFormDirty = !createdUser && (displayName.trim() !== '' || password.trim() !== '' || userId.trim() !== '');

  const handleUnifiedClose = () => {
    if (isSubmitting) return;
    onClose();
    handleResetForNext();
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleUnifiedClose}
      isDirty={isFormDirty}
      isSaving={isSubmitting}
      backdropClassName="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs overflow-y-auto p-2 sm:p-4 flex items-center justify-center"
    >
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 max-h-[90vh] flex flex-col my-auto">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                Add User Account
              </h3>
            </div>
          </div>
          <button 
            type="button"
            onClick={handleUnifiedClose}
            disabled={isSubmitting}
            className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer disabled:opacity-50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* View 1: Success Credentials Card */}
        {createdUser ? (
          <div className="p-6 space-y-5 animate-in fade-in overflow-y-auto flex-1">
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-emerald-900 flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-sm text-emerald-950">
                  User Account Created Successfully!
                </h4>
                <p className="text-xs text-emerald-700 mt-0.5">
                  The user has been registered with their System ID, Password and customized module permissions.
                </p>
              </div>
            </div>

            {/* Credentials Box */}
            <div className="bg-slate-900 rounded-2xl p-4 text-white space-y-3 shadow-inner">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                <span>Account Access Details</span>
                <span className="text-emerald-400 font-mono text-[10px]">Ready for Login</span>
              </div>

              {/* User ID Row */}
              <div className="flex items-center justify-between bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
                <div>
                  <span className="text-[10px] text-slate-400 block font-medium">User Login ID:</span>
                  <span className="text-sm font-mono font-bold text-cyan-300">
                    {createdUser.userId || createdUser.uid}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(createdUser.userId || createdUser.uid, 'userId')}
                  className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
                >
                  {copiedField === 'userId' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedField === 'userId' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Temporary Password Row */}
              <div className="flex items-center justify-between bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
                <div>
                  <span className="text-[10px] text-amber-400 block font-medium">Temporary Password:</span>
                  <span className="text-sm font-mono font-bold text-amber-300">
                    {createdUser.temporaryPassword || createdUser.password || password}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(createdUser.temporaryPassword || createdUser.password || password, 'password')}
                  className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
                >
                  {copiedField === 'password' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedField === 'password' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Email Row */}
              <div className="flex items-center justify-between bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
                <div>
                  <span className="text-[10px] text-slate-400 block font-medium">Corporate Email:</span>
                  <span className="text-xs font-mono text-slate-200 truncate max-w-[220px] block">
                    {createdUser.email}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(createdUser.email, 'email')}
                  className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
                >
                  {copiedField === 'email' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedField === 'email' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Meta Row: Role & Branch */}
              <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                <div className="bg-slate-800/50 p-2 rounded-lg">
                  <span className="text-[10px] text-slate-400 block">Designated Role:</span>
                  <span className="font-semibold text-slate-200">
                    {ROLE_LABELS[createdUser.role]?.title || createdUser.role}
                  </span>
                </div>
                <div className="bg-slate-800/50 p-2 rounded-lg">
                  <span className="text-[10px] text-slate-400 block">Assigned Branch:</span>
                  <span className="font-semibold text-slate-200 truncate block">
                    {createdUser.branch}
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={copyAllCredentials}
                className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                {allCopied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                <span>{allCopied ? 'All Credentials Copied to Clipboard!' : 'Copy All Credentials'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetForNext}
                  className="flex-1 py-2 px-3 border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  + Add Another User
                </button>
                <button
                  type="button"
                  onClick={handleUnifiedClose}
                  className="flex-1 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* View 2: User Creation Form */
          <form onSubmit={handleSubmit} autoComplete="off" className="flex-1 flex flex-col min-h-0 overflow-hidden">
            {/* Scrollable Form Body */}
            <div className="p-4 sm:p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1 overscroll-auto">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="font-medium">{formError}</span>
                </div>
              )}

              {/* 1. Full Name */}
              <div>
                <label className="block font-semibold text-slate-800 mb-1 flex items-center justify-between">
                  <span>Full Name *</span>
                  <span className="text-[10px] text-slate-500">e.g. Tariqul Islam</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  <input
                    type="text"
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Tariqul Islam"
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                  />
                </div>
              </div>

            {/* 2. System User ID (Login ID) */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-blue-600" />
                  <span>User Login ID *</span>
                </label>
                <button
                  type="button"
                  onClick={generateUserId}
                  className="text-[11px] text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  <span>Auto-Generate</span>
                </button>
              </div>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={userId}
                  onChange={(e) => setUserId(e.target.value.toUpperCase())}
                  placeholder="e.g. BUR-01, EMP-101, TARIQUL"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono font-bold tracking-wide"
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                The user can sign in directly using this User ID or Email.
              </p>
            </div>

            {/* 3. Temporary Password Field */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-blue-600" />
                  <span>Temporary Password *</span>
                </label>
                <button
                  type="button"
                  onClick={generatePassword}
                  className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  <span>Generate Password</span>
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter min 6 chars or click Generate"
                  className="w-full pl-3 pr-10 py-2 border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono font-semibold"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
              <p className="text-[10px] text-amber-700 font-medium mt-1">
                The user will be required to change their password on first login.
              </p>
            </div>

            {/* 4. Corporate Email */}
            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Corporate Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tariqul@tradecore-erp.com"
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                />
              </div>
            </div>

            {/* 5. Role and Operational Branch Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                  <span>Designated Role *</span>
                </label>
                <select
                  value={role}
                  onChange={(e) => {
                    const r = e.target.value as UserRole;
                    setRole(r);
                    if (r === 'admin') {
                      setPermissions(DEFAULT_ADMIN_PERMISSIONS);
                    } else {
                      setPermissions(DEFAULT_MANAGER_PERMISSIONS);
                    }
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                >
                  <option value="">Select Role...</option>
                  <option value="manager">Manager (Custom Module Access)</option>
                  <option value="admin">Super Admin / Owner (Full Access)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>Branch / Site</span>
                </label>
                <select
                  value={branch}
                  onChange={(e) => {
                    setBranch(e.target.value);
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                >
                  <option value="">Select Branch / Site...</option>
                  <option value="Chittagong Port Branch (BR-02)">Chittagong Port Branch</option>
                  <option value="Corporate Headquarters (Dhaka)">Corporate HQ (Dhaka)</option>
                  <option value="Burimari Land Port Unit">Burimari Land Port Unit</option>
                  <option value="Sonahat Land Port Unit">Sonahat Land Port Unit</option>
                  <option value="Tejgaon Central Depot">Tejgaon Central Depot</option>
                </select>
              </div>
            </div>

            {/* 6. Phone Contact */}
            <div>
              <label className="block font-semibold text-slate-800 mb-1 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span>Contact Telephone</span>
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+880 1712-345678"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
              />
            </div>

            {/* 7. RBAC Module Access Tickmark Form */}
            <div className="pt-3 border-t border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>Module Access Permissions</span>
                </label>
                <span className="text-[11px] text-slate-500">
                  {role === 'admin' ? 'All 9 modules enabled for Admin' : 'Select modules for Manager'}
                </span>
              </div>

              <RbacPermissionForm
                role={role}
                initialPermissions={permissions}
                onChange={(p) => setPermissions(p)}
                showSaveButton={false}
                compact={true}
              />
            </div>

            </div>

            {/* Fixed Bottom Action Bar */}
            <div className="p-3.5 sm:p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5 shrink-0">
              <button
                type="button"
                onClick={handleUnifiedClose}
                disabled={isSubmitting}
                className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-400 text-white rounded-xl font-bold shadow-xs cursor-pointer flex items-center gap-1.5 transition-colors"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Creating Account...</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Create User Account</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </ModalWrapper>
  );
};
