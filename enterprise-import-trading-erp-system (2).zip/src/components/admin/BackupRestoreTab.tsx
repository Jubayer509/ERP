import React, { useState } from 'react';
import { 
  Download, 
  Upload, 
  Database, 
  CheckCircle2, 
  AlertTriangle, 
  FileJson, 
  RefreshCw, 
  HardDrive,
  CloudUpload,
  ShieldCheck,
  Info
} from 'lucide-react';
import { exportAllTradecoreData, restoreBackupToFirestore, RestoreResult } from '../../services/backupService';

export const BackupRestoreTab: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [progressMsg, setProgressMsg] = useState<string | null>(null);
  const [restoreResult, setRestoreResult] = useState<RestoreResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Read current local storage key count
  const getLocalKeyCount = () => {
    let count = 0;
    if (typeof window !== 'undefined' && window.localStorage) {
      for (let i = 0; i < window.localStorage.length; i++) {
        const k = window.localStorage.key(i);
        if (k && k.startsWith('tradecore_')) count++;
      }
    }
    return count;
  };

  const handleExport = () => {
    setIsExporting(true);
    setErrorMessage(null);
    try {
      const { filename, payload } = exportAllTradecoreData();
      setProgressMsg(`Successfully downloaded: ${filename} (${payload.totalKeys} data tables)`);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to export data');
    } finally {
      setIsExporting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMessage(null);
    setRestoreResult(null);
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleImport = async () => {
    if (!selectedFile) {
      setErrorMessage('Please select a backup JSON file');
      return;
    }

    setIsImporting(true);
    setErrorMessage(null);
    setRestoreResult(null);
    setProgressMsg('Reading file...');

    try {
      const text = await selectedFile.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        throw new Error('Invalid JSON file. Please upload a valid TradeCore backup file.');
      }

      const res = await restoreBackupToFirestore(parsed, (msg) => {
        setProgressMsg(msg);
      });

      setRestoreResult(res);
      setProgressMsg(null);
    } catch (err: any) {
      console.error('Import failed:', err);
      // Step C: if a Firestore write fails, show a visible red error message and do NOT report success
      setErrorMessage(`Firestore Import Failed: ${err.message || 'Unknown database write error'}`);
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider bg-indigo-900 text-indigo-100 px-2 py-0.5 rounded font-mono">
              Data Management
            </span>
            <span className="text-xs text-slate-500 font-medium">Single Source of Truth: Cloud Firestore with Offline Cache</span>
          </div>
          <h2 className="text-lg font-bold text-slate-900">
            System Data Backup & Cloud Firestore Import
          </h2>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="text-right">
            <span className="text-[11px] text-slate-400 block font-medium">Local Storage Active Keys</span>
            <span className="text-sm font-bold font-mono text-slate-800">{getLocalKeyCount()} TradeCore Tables</span>
          </div>
        </div>
      </div>

      {/* Visible Error Message (Red Banner) */}
      {errorMessage && (
        <div className="bg-rose-50 border-2 border-rose-500 text-rose-900 rounded-xl p-4 flex items-start gap-3 animate-in fade-in">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold uppercase tracking-wide text-rose-800">
              Action Failed
            </h4>
            <p className="text-xs font-medium text-rose-700 leading-relaxed">
              {errorMessage}
            </p>
          </div>
        </div>
      )}

      {/* Progress Message */}
      {progressMsg && (
        <div className="bg-blue-50 border border-blue-200 text-blue-900 rounded-xl p-3.5 flex items-center gap-3 animate-in fade-in">
          <RefreshCw className="w-4 h-4 text-blue-600 shrink-0 animate-spin" />
          <p className="text-xs font-medium text-blue-800">{progressMsg}</p>
        </div>
      )}

      {/* Success Result Box */}
      {restoreResult && restoreResult.success && (
        <div className="bg-emerald-50 border-2 border-emerald-500 text-emerald-950 rounded-xl p-5 space-y-3 animate-in fade-in">
          <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>Successfully Restored to Firestore!</span>
          </div>
          <div className="text-xs text-emerald-900">
            Updated <strong>{restoreResult.totalCollections}</strong> collections in Firestore:
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
            {Object.entries(restoreResult.restoredCounts).map(([col, count]) => (
              <div key={col} className="bg-white/80 border border-emerald-200 rounded-lg p-2 font-mono">
                <span className="text-slate-500 block text-[10px] uppercase truncate">{col}</span>
                <span className="font-bold text-emerald-700 text-sm">{count} records</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Two Column Grid: Export and Import */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Step A.1: Backup / Export All Data */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center shadow-xs">
                <Download className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  Backup / Export all data
                </h3>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-600 space-y-1.5 leading-relaxed">
              <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                <Info className="w-3.5 h-3.5 text-blue-600" />
                <span>Included in Backup:</span>
              </div>
              <ul className="list-disc list-inside space-y-0.5 text-slate-600 pl-1 text-[11px]">
                <li>Bank & Cash Accounts</li>
                <li>Customers & Suppliers</li>
                <li>Account Heads & Chart of Accounts</li>
                <li>Transactions & Vouchers</li>
                <li>Ledger Entries & Balances</li>
                <li>Sales, Purchases & Inventory Items</li>
              </ul>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={handleExport}
              disabled={isExporting}
              className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Exporting...' : 'Backup / Export all data (Download JSON)'}</span>
            </button>
          </div>
        </div>

        {/* Step A.2: Import data into Firestore */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <CloudUpload className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  Import data (Restore to Firestore)
                </h3>
              </div>
            </div>

            <div className="border-2 border-dashed border-slate-300 rounded-xl p-4 text-center hover:border-blue-500 transition-colors bg-slate-50/60">
              <FileJson className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <label className="block text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer mb-1">
                <span>Select Backup JSON File</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
              <p className="text-[11px] text-slate-500">
                {selectedFile ? (
                  <span className="font-bold text-slate-800 font-mono">
                    ✓ {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
                  </span>
                ) : (
                  'Select a tradecore_erp_backup_*.json file'
                )}
              </p>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5 text-[11px] text-amber-900 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <span>
                After restoring, Cloud Firestore will serve as the single source of truth.
              </span>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={handleImport}
              disabled={isImporting || !selectedFile}
              className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isImporting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Saving to Firestore...</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>Import data (Restore to Firestore)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
