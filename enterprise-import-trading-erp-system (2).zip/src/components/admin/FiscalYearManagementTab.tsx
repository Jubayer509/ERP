import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  CheckCircle2, 
  Lock, 
  Unlock, 
  Plus, 
  Clock, 
  AlertCircle, 
  ShieldCheck, 
  FileText, 
  RotateCcw,
  Sparkles,
  Layers,
  ArrowRight,
  TrendingUp,
  Building2,
  Trash2
} from 'lucide-react';
import { FiscalYear, FiscalYearStatus } from '../../types/erp';
import { 
  getFiscalYears, 
  getActiveFiscalYear, 
  setActiveFiscalYear, 
  closeFiscalYear, 
  reopenFiscalYear, 
  addFiscalYear, 
  deleteFiscalYear,
  subscribeFiscalYears,
  formatFiscalYearDisplay 
} from '../../utils/fiscalYearStorage';
import { ModalWrapper } from '../common/ModalWrapper';

export const FiscalYearManagementTab: React.FC = () => {
  const [fiscalYears, setFiscalYears] = useState<FiscalYear[]>(() => getFiscalYears());
  const [activeFY, setActiveFY] = useState<FiscalYear>(() => getActiveFiscalYear());
  const [showAddModal, setShowAddModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State for new FY
  const [formName, setFormName] = useState('');
  const [formBengaliName, setFormBengaliName] = useState('');
  const [formStartDate, setFormStartDate] = useState('');
  const [formEndDate, setFormEndDate] = useState('');
  const [formStatus, setFormStatus] = useState<FiscalYearStatus>('' as any);
  const [formDescription, setFormDescription] = useState('');

  useEffect(() => {
    const unsub = subscribeFiscalYears((updated) => {
      setFiscalYears(updated);
      setActiveFY(getActiveFiscalYear());
    });
    return unsub;
  }, []);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleMakeActive = (id: string, name: string) => {
    const updated = setActiveFiscalYear(id);
    setFiscalYears(updated);
    setActiveFY(getActiveFiscalYear());
    triggerToast(`✓ "${name}" set as the Active Fiscal Year!`);
  };

  const handleCloseYear = (id: string, name: string) => {
    const updated = closeFiscalYear(id, 'Admin / Managing Director');
    setFiscalYears(updated);
    setActiveFY(getActiveFiscalYear());
    triggerToast(`✓ "${name}" closed and locked successfully.`);
  };

  const handleReopenYear = (id: string, name: string) => {
    const updated = reopenFiscalYear(id);
    setFiscalYears(updated);
    setActiveFY(getActiveFiscalYear());
    triggerToast(`✓ "${name}" reopened as Active!`);
  };

  const handleDeleteYear = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete fiscal year "${name}"?`)) {
      const updated = deleteFiscalYear(id);
      setFiscalYears(updated);
      setActiveFY(getActiveFiscalYear());
      triggerToast(`✓ Fiscal year "${name}" removed.`);
    }
  };

  const isFormDirty = Boolean(formName || formBengaliName || formStartDate || formEndDate || formStatus || formDescription);

  const handleCloseModal = () => {
    setShowAddModal(false);
    setFormName('');
    setFormBengaliName('');
    setFormStartDate('');
    setFormEndDate('');
    setFormStatus('' as any);
    setFormDescription('');
  };

  const handleCreateYear = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formStartDate || !formEndDate) return;

    const updated = addFiscalYear({
      name: formName.trim() || `FY ${formStartDate.split('-')[0]}-${formEndDate.split('-')[0]}`,
      bengaliName: formBengaliName.trim() || `${formStartDate.split('-')[0]}-${formEndDate.split('-')[0]} Fiscal Year`,
      startDate: formStartDate,
      endDate: formEndDate,
      status: formStatus,
      isDefault: formStatus === 'Active',
      description: formDescription.trim(),
      totalVouchers: 0,
      totalTransactions: 0
    });

    setFiscalYears(updated);
    setActiveFY(getActiveFiscalYear());
    handleCloseModal();
    triggerToast(`✓ New fiscal year "${formName}" created successfully!`);
  };

  const formatDateDisplay = (dateStr: string) => {
    if (!dateStr) return '';
    const [y, m, d] = dateStr.split('-');
    return `${d}/${m}/${y}`;
  };

  return (
    <div className="space-y-5">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            <span>Fiscal Year (FY) System</span>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full font-mono">
              Current: {activeFY?.name} ({activeFY?.status})
            </span>
          </h2>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-2 shrink-0 cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4 text-emerald-400" />
          <span>+ Add Fiscal Year</span>
        </button>
      </div>

      {/* Active Fiscal Year Overview Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 rounded-2xl p-5 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 mb-1 font-mono tracking-wider uppercase">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Current Active Financial Year</span>
            </div>
            <div className="text-2xl sm:text-3xl font-black tracking-tight flex items-center gap-3">
              <span>{activeFY?.name}</span>
            </div>
            <div className="text-xs text-slate-300 font-mono mt-1 flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span>Duration: {formatDateDisplay(activeFY?.startDate)} to {formatDateDisplay(activeFY?.endDate)}</span>
              <span>·</span>
              <span className="text-emerald-300 font-bold">{activeFY?.status} Status</span>
            </div>
            <p className="text-xs text-slate-400 mt-2 max-w-xl">
              {activeFY?.description}
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-xs p-3.5 rounded-xl border border-white/15">
            <div className="text-right">
              <div className="text-[11px] text-slate-300 font-medium">System Status</div>
              <div className="text-sm font-black text-emerald-400 font-mono">Open & Reporting</div>
              <div className="text-[10px] text-slate-400 font-mono mt-0.5">Applied Across All Statements</div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>

      {/* Fiscal Years Master Table */}
      <div className="bg-white border border-slate-200/90 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-600" />
            <h3 className="font-bold text-sm text-slate-900">Fiscal Year Registry</h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            Total Fiscal Years: {fiscalYears.length}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-700 font-bold">
                <th className="py-3 px-4">FY Name</th>
                <th className="py-3 px-4">Duration</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4">Transactions & Vouchers</th>
                <th className="py-3 px-4">Description & Audit Reference</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {fiscalYears.map((fy) => {
                const isActive = fy.status === 'Active';
                const isClosed = fy.status === 'Closed';
                const isUpcoming = fy.status === 'Upcoming';

                return (
                  <tr 
                    key={fy.id} 
                    className={`hover:bg-slate-50/60 transition-colors ${
                      isActive ? 'bg-emerald-50/30' : ''
                    }`}
                  >
                    {/* FY Name */}
                    <td className="py-3.5 px-4 font-semibold text-slate-900">
                      <div className="flex items-center gap-2">
                        <Calendar className={`w-4 h-4 ${isActive ? 'text-emerald-600' : isClosed ? 'text-slate-400' : 'text-blue-500'}`} />
                        <div>
                          <div className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                            <span>{fy.name}</span>
                            {isActive && (
                              <span className="text-[10px] bg-emerald-600 text-white font-bold px-1.5 py-0.2 rounded-full font-mono">
                                Default Active
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 font-sans">
                            {fy.bengaliName}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Date Duration */}
                    <td className="py-3.5 px-4 font-mono font-medium text-slate-700">
                      <div className="text-xs">
                        {formatDateDisplay(fy.startDate)} — {formatDateDisplay(fy.endDate)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {fy.startDate} to {fy.endDate}
                      </div>
                    </td>

                    {/* Status Badge */}
                    <td className="py-3.5 px-4 text-center">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full ${
                        isActive
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : isClosed
                            ? 'bg-slate-100 text-slate-700 border border-slate-200'
                            : 'bg-blue-100 text-blue-800 border border-blue-200'
                      }`}>
                        {isActive && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />}
                        {isClosed && <Lock className="w-3 h-3 text-slate-500" />}
                        {isUpcoming && <Clock className="w-3 h-3 text-blue-600" />}
                        <span>{fy.status}</span>
                      </span>
                    </td>

                    {/* Transactions / Vouchers */}
                    <td className="py-3.5 px-4 font-mono text-slate-700">
                      <div>
                        {fy.totalTransactions ? `${fy.totalTransactions.toLocaleString()} Transactions` : 'N/A'}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {fy.totalVouchers ? `${fy.totalVouchers.toLocaleString()} Vouchers` : '0 Vouchers'}
                      </div>
                    </td>

                    {/* Notes / Audit */}
                    <td className="py-3.5 px-4 text-slate-600 max-w-xs">
                      <p className="text-[11px] truncate" title={fy.description}>
                        {fy.description || '—'}
                      </p>
                      {fy.closedDate && (
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          Closed: {formatDateDisplay(fy.closedDate)} by {fy.closedBy}
                        </div>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5 flex-wrap">
                        {!isActive && (
                          <button
                            type="button"
                            onClick={() => handleMakeActive(fy.id, fy.name)}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                            title="Set as Active Fiscal Year"
                          >
                            Set Active
                          </button>
                        )}

                        {isActive && (
                          <button
                            type="button"
                            onClick={() => handleCloseYear(fy.id, fy.name)}
                            className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                            title="Close and Lock Fiscal Year"
                          >
                            <Lock className="w-3 h-3 text-amber-600" />
                            <span>Close FY</span>
                          </button>
                        )}

                        {isClosed && (
                          <button
                            type="button"
                            onClick={() => handleReopenYear(fy.id, fy.name)}
                            className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                            title="Reopen Fiscal Year"
                          >
                            <Unlock className="w-3 h-3 text-slate-600" />
                            <span>Re-Open</span>
                          </button>
                        )}

                        {fiscalYears.length > 1 && !isActive && (
                          <button
                            type="button"
                            onClick={() => handleDeleteYear(fy.id, fy.name)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Fiscal Year Modal */}
      <ModalWrapper
        isOpen={showAddModal}
        onClose={handleCloseModal}
        isDirty={isFormDirty}
        backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto overscroll-contain flex min-h-full items-center justify-center p-4"
      >
        <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 space-y-4 max-h-[85vh] overflow-y-auto overscroll-contain my-auto border border-slate-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              <h3 className="font-bold text-sm text-slate-900">Create Fiscal Year</h3>
            </div>
            <button
              type="button"
              onClick={handleCloseModal}
              className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
            >
              ✕
            </button>
          </div>

          <form onSubmit={handleCreateYear} autoComplete="off" className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">FY Code / Name:</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. FY 2026-2027"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-blue-500 font-medium text-xs"
                />
              </div>
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Display Title:</label>
                <input
                  type="text"
                  value={formBengaliName}
                  onChange={(e) => setFormBengaliName(e.target.value)}
                  placeholder="e.g. 2026-2027 Fiscal Year"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-blue-500 font-medium text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Start Date:</label>
                <input
                  type="date"
                  required
                  value={formStartDate}
                  onChange={(e) => setFormStartDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-blue-500 font-mono text-xs cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">Typically July 1</span>
              </div>
              <div>
                <label className="block text-slate-700 font-semibold mb-1">End Date:</label>
                <input
                  type="date"
                  required
                  value={formEndDate}
                  onChange={(e) => setFormEndDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-blue-500 font-mono text-xs cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">Typically June 30</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Initial Status:</label>
              <select
                value={formStatus}
                onChange={(e) => setFormStatus(e.target.value as FiscalYearStatus)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-blue-500 font-medium text-xs cursor-pointer"
              >
                <option value="">Select Initial Status...</option>
                <option value="Upcoming">Upcoming (Planning)</option>
                <option value="Active">Active (Current Fiscal Year)</option>
                <option value="Closed">Closed (Locked)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Description / Audit Note:</label>
              <textarea
                rows={2}
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                placeholder="Special notes regarding this fiscal year..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-blue-500 font-medium text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={handleCloseModal}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold transition-all shadow-xs cursor-pointer"
              >
                Save Fiscal Year
              </button>
            </div>
          </form>
        </div>
      </ModalWrapper>
    </div>
  );
};
