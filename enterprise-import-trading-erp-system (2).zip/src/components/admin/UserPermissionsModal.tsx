import React from 'react';
import { 
  ShieldCheck, 
  X, 
  User as UserIcon, 
  Building2 
} from 'lucide-react';
import { ErpUser, UserPermissions } from '../../types/erp';
import { useAuth } from '../../contexts/AuthContext';
import { RbacPermissionForm } from './RbacPermissionForm';
import { ROLE_LABELS } from '../../data/mockUsers';
import { ModalWrapper } from '../common/ModalWrapper';

interface UserPermissionsModalProps {
  user: ErpUser | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const UserPermissionsModal: React.FC<UserPermissionsModalProps> = ({
  user,
  isOpen,
  onClose,
  onSuccess
}) => {
  const { updateUserPermissions } = useAuth();

  if (!isOpen || !user) return null;

  const handleSave = async (permissions: UserPermissions) => {
    const res = await updateUserPermissions(user.uid, permissions);
    if (res.success && onSuccess) {
      onSuccess();
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      isDirty={false}
      backdropClassName="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 my-auto max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white flex items-center gap-2">
                <span>User Access & RBAC Permissions</span>
              </h3>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* User Identity Card */}
        <div className="bg-slate-50 border-b border-slate-200 p-3.5 sm:p-4 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold flex items-center justify-center text-xs shadow-xs">
              {user.displayName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-sm">{user.displayName}</span>
                {user.userId && (
                  <span className="font-mono text-[10px] bg-cyan-100 text-cyan-800 font-bold px-1.5 py-0.2 rounded border border-cyan-200">
                    ID: {user.userId}
                  </span>
                )}
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  user.role === 'admin' 
                    ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                    : 'bg-blue-100 text-blue-800 border border-blue-200'
                }`}>
                  {ROLE_LABELS[user.role]?.title || user.role}
                </span>
              </div>
              <span className="text-[11px] text-slate-500 font-mono block">
                {user.email} • {user.branch}
              </span>
            </div>
          </div>
        </div>

        {/* Scrollable Form Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          <RbacPermissionForm
            user={user}
            onSave={handleSave}
            showSaveButton={true}
          />
        </div>
      </div>
    </ModalWrapper>
  );
};
