import React, { useState, useEffect } from 'react';
import { 
  Store, 
  Truck, 
  Receipt, 
  CreditCard, 
  Search, 
  Plus, 
  Trash2, 
  Printer, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  User, 
  Phone, 
  Building2, 
  Scale, 
  DollarSign, 
  AlertCircle, 
  Wallet, 
  ShieldCheck, 
  ArrowRight,
  Filter,
  RefreshCw,
  Lock,
  ChevronDown
} from 'lucide-react';
import { POSSale, InventoryItem, Customer } from '../../types/erp';
import { MOCK_POS_SALES, MOCK_ITEMS, MOCK_CUSTOMERS } from '../../data/mockErpData';
import { useAuth } from '../../contexts/AuthContext';
import { getActiveItems, subscribeItems } from '../../utils/itemStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface POSModuleProps {
  currentBranch?: string;
  onBranchChange?: (branch: string) => void;
  currency?: string;
}

const LOCAL_STORAGE_POS_KEY = 'tradecore_pos_sales_v1';

export const POSModule: React.FC<POSModuleProps> = ({
  currentBranch = 'All Branches',
  onBranchChange,
  currency = 'BDT'
}) => {
  const { currentUser } = useAuth();

  // Determine active operating branch:
  // If user is not admin, they are strictly locked to their assigned branch!
  const isOwner = currentUser?.role === 'admin';
  const userAssignedBranch = currentUser?.branch && currentUser.branch !== 'All Branches'
    ? currentUser.branch
    : 'Burimari Office';

  const [activeOffice, setActiveOffice] = useState<string>(() => {
    if (!isOwner) {
      return userAssignedBranch;
    }
    if (currentBranch && currentBranch !== 'All Branches') {
      return currentBranch;
    }
    return 'Burimari Office';
  });

  // Sync when header branch changes (for admin)
  useEffect(() => {
    if (isOwner && currentBranch && currentBranch !== 'All Branches') {
      setActiveOffice(currentBranch);
    }
  }, [isOwner, currentBranch]);

  // If user is not admin, keep them locked
  useEffect(() => {
    if (!isOwner) {
      setActiveOffice(userAssignedBranch);
    }
  }, [isOwner, userAssignedBranch]);

  // Tab State
  const [activeTab, setActiveTab] = useState<'counter' | 'history'>('counter');

  // POS Sales State with LocalStorage
  const [salesList, setSalesList] = useState<POSSale[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_POS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse saved POS sales', e);
    }
    return MOCK_POS_SALES;
  });

  const saveSales = (newSales: POSSale[]) => {
    setSalesList(newSales);
    localStorage.setItem(LOCAL_STORAGE_POS_KEY, JSON.stringify(newSales));
  };

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // ==================== POS COUNTER STATE ====================
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customCustomerName, setCustomCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [truckNo, setTruckNo] = useState<string>('');
  const [driverName, setDriverName] = useState<string>('');
  const [driverPhone, setDriverPhone] = useState<string>('');
  const [weighbridgeSlipNo, setWeighbridgeSlipNo] = useState<string>('');
  const [netWeightMt, setNetWeightMt] = useState<number>(0);

  // Cart Items
  const [cartItems, setCartItems] = useState<{
    itemId: string;
    itemName: string;
    quantity: number;
    unitPrice: number;
    uom: string;
    total: number;
  }[]>([]);

  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'bKash / Nagad' | 'Bank Cheque' | 'Credit'>('' as any);
  const [orderNotes, setOrderNotes] = useState<string>('');

  // Active Items state connected with Inventory & Item Master
  const [activeInventoryItems, setActiveInventoryItems] = useState<InventoryItem[]>(() => getActiveItems());

  useEffect(() => {
    const unsub = subscribeItems((items) => {
      setActiveInventoryItems(items.filter(i => (i.status || 'Active') === 'Active'));
    });
    return () => unsub();
  }, []);

  // Cart Calculations
  const subtotal = cartItems.reduce((acc, item) => acc + item.total, 0);
  const grandTotal = Math.max(0, subtotal - discountAmount);
  const dueAmount = Math.max(0, grandTotal - paidAmount);

  // Stone & Boulder Fast Products - STRICTLY ONLY ACTIVE ITEMS
  const fastProducts = activeInventoryItems.slice(0, 8).map((item, idx) => ({
    id: item.id,
    name: item.name,
    price: item.sellingPrice || 3500,
    uom: item.uom || 'MT',
    tag: idx === 0 ? 'High Demand' : (idx === 1 ? 'Ready Stock' : (item.category === 'Boulder' ? 'Quarry Boulder' : 'Crushed Stone'))
  }));

  const handleAddProductToCart = (prod: typeof fastProducts[0]) => {
    const existingIndex = cartItems.findIndex(i => i.itemId === prod.id);
    if (existingIndex >= 0) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += 10;
      updated[existingIndex].total = updated[existingIndex].quantity * updated[existingIndex].unitPrice;
      setCartItems(updated);
    } else {
      setCartItems([
        ...cartItems,
        {
          itemId: prod.id,
          itemName: prod.name,
          quantity: 25,
          unitPrice: prod.price,
          uom: prod.uom,
          total: 25 * prod.price
        }
      ]);
    }
  };

  const handleUpdateCartQty = (index: number, newQty: number) => {
    if (newQty <= 0) return;
    const updated = [...cartItems];
    updated[index].quantity = newQty;
    updated[index].total = newQty * updated[index].unitPrice;
    setCartItems(updated);
  };

  const handleUpdateCartPrice = (index: number, newPrice: number) => {
    if (newPrice < 0) return;
    const updated = [...cartItems];
    updated[index].unitPrice = newPrice;
    updated[index].total = updated[index].quantity * newPrice;
    setCartItems(updated);
  };

  const handleRemoveCartItem = (index: number) => {
    setCartItems(cartItems.filter((_, i) => i !== index));
  };

  // Sync Net Weight to first item quantity if applicable
  const handleNetWeightChange = (wt: number) => {
    setNetWeightMt(wt);
    if (cartItems.length === 1 && wt > 0) {
      handleUpdateCartQty(0, wt);
    }
  };

  // ==================== PRINTABLE MODAL STATE ====================
  const [printModalSale, setPrintModalSale] = useState<POSSale | null>(null);

  // Complete POS Sale
  const handleCompleteSale = (e: React.FormEvent) => {
    e.preventDefault();

    if (cartItems.length === 0) {
      showToast('⚠️ Please add at least one item to the counter!');
      return;
    }

    const customerDisplayName = selectedCustomerId 
      ? (MOCK_CUSTOMERS.find(c => c.id === selectedCustomerId)?.name || customCustomerName || 'Walk-in Cash Buyer')
      : (customCustomerName || 'Walk-in Cash Buyer');

    const branchPrefix = activeOffice.includes('Burimari') ? 'BUR' : 'SON';
    const timestamp = Date.now().toString().slice(-4);
    const invoiceNo = `POS-${branchPrefix}-${new Date().getFullYear().toString().slice(-2)}${timestamp}`;
    const challanNo = `CH-${branchPrefix}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newSale: POSSale = {
      id: `pos-${Date.now()}`,
      invoiceNo,
      challanNo,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
      branch: activeOffice,
      cashierUid: currentUser?.uid || 'user-branch',
      cashierName: currentUser?.displayName || 'Branch Cashier',
      customerName: customerDisplayName,
      customerPhone: customerPhone || 'N/A',
      truckNo: truckNo || 'Spot Handover / Yard Release',
      driverName: driverName || '',
      driverPhone: driverPhone || '',
      weighbridgeSlipNo: weighbridgeSlipNo || `WB-${branchPrefix}-${Math.floor(1000 + Math.random() * 9000)}`,
      netWeightMt: netWeightMt || cartItems.reduce((acc, i) => acc + i.quantity, 0),
      items: [...cartItems],
      subtotal,
      discount: discountAmount,
      taxAmount: 0,
      grandTotal,
      paidAmount,
      dueAmount,
      paymentMethod,
      status: dueAmount > 0 ? 'Pending Due' : 'Completed',
      notes: orderNotes
    };

    const updatedList = [newSale, ...salesList];
    saveSales(updatedList);

    // Open Printable Receipt Modal immediately
    setPrintModalSale(newSale);

    // Reset Form for next customer
    setCartItems([]);
    setSelectedCustomerId('');
    setCustomCustomerName('');
    setCustomerPhone('');
    setTruckNo('');
    setDriverName('');
    setDriverPhone('');
    setWeighbridgeSlipNo('');
    setNetWeightMt(0);
    setDiscountAmount(0);
    setPaidAmount(0);
    setPaymentMethod('' as any);
    setOrderNotes('');
    showToast(`✓ Sale completed! Invoice ${newSale.invoiceNo} created`);
  };

  // ==================== FILTERED SALES FOR ACTIVE OFFICE ====================
  const officeSales = salesList.filter(s => {
    if (activeOffice === 'All Branches') return true;
    return s.branch.toLowerCase().includes(activeOffice.toLowerCase().replace(' office', ''));
  });

  // Today's Office Metrics
  const todayStr = new Date().toISOString().split('T')[0];
  const todaySales = officeSales.filter(s => s.date === todayStr);

  const todayCashCollection = todaySales.reduce((acc, s) => acc + s.paidAmount, 0);
  const todayTotalSalesValue = todaySales.reduce((acc, s) => acc + s.grandTotal, 0);
  const todayPendingDue = todaySales.reduce((acc, s) => acc + s.dueAmount, 0);
  const todayTrucksCount = todaySales.filter(s => s.truckNo && s.truckNo !== 'Spot Handover / Yard Release').length;

  // Search & Filter in History Tab
  const [historySearch, setHistorySearch] = useState('');
  const [historyStatusFilter, setHistoryStatusFilter] = useState<'All' | 'Completed' | 'Pending Due'>('All');

  const filteredHistory = officeSales.filter(s => {
    const matchesSearch = 
      s.invoiceNo.toLowerCase().includes(historySearch.toLowerCase()) ||
      s.challanNo.toLowerCase().includes(historySearch.toLowerCase()) ||
      s.customerName.toLowerCase().includes(historySearch.toLowerCase()) ||
      (s.truckNo && s.truckNo.toLowerCase().includes(historySearch.toLowerCase()));

    const matchesStatus = historyStatusFilter === 'All' ? true : s.status === historyStatusFilter;
    return matchesSearch && matchesStatus;
  });

  // Record Payment on Due Sale Modal
  const [duePaymentSale, setDuePaymentSale] = useState<POSSale | null>(null);
  const [paymentAmountInput, setPaymentAmountInput] = useState<number>(0);

  const handleRecordDuePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!duePaymentSale || paymentAmountInput <= 0) return;

    const newPaid = duePaymentSale.paidAmount + paymentAmountInput;
    const newDue = Math.max(0, duePaymentSale.grandTotal - newPaid);

    const updated = salesList.map(s => {
      if (s.id === duePaymentSale.id) {
        return {
          ...s,
          paidAmount: newPaid,
          dueAmount: newDue,
          status: newDue === 0 ? 'Completed' : 'Pending Due'
        } as POSSale;
      }
      return s;
    });

    saveSales(updated);
    setDuePaymentSale(null);
    showToast(`✓ Payment recorded! ৳${paymentAmountInput.toLocaleString()} received`);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-emerald-500/40 flex items-center gap-3 animate-in slide-in-from-bottom-5">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Top Header & Branch Status Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 shadow-lg border border-slate-800">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Store className="w-6 h-6 text-amber-400 shrink-0" />
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                {activeOffice === 'Burimari Office' ? 'Burimari Office POS Counter' :
                 activeOffice === 'Sonahat Office' ? 'Sonahat Office POS Counter' :
                 'All Branches POS & Counter Sales'}
              </h1>
            </div>
          </div>

          {/* Branch Switching for Owner vs Locked Badge for Staff */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0 w-full sm:w-auto">
            {isOwner ? (
              <div className="flex items-center bg-slate-800/90 border border-blue-500/40 rounded-xl p-1 shadow-inner">
                <span className="text-[11px] font-bold text-slate-400 px-2 flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>Select Branch:</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setActiveOffice('Burimari Office');
                    if (onBranchChange) onBranchChange('Burimari Office');
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeOffice === 'Burimari Office'
                      ? 'bg-amber-600 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  📍 Burimari Office
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveOffice('Sonahat Office');
                    if (onBranchChange) onBranchChange('Sonahat Office');
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeOffice === 'Sonahat Office'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  📍 Sonahat Office
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 bg-slate-800/90 border border-amber-500/40 rounded-xl px-3 py-2 text-amber-200">
                <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                <div className="text-left text-xs">
                  <span className="font-bold block text-white">{activeOffice}</span>
                  <span className="text-[10px] text-amber-300">Assigned Cashier: {currentUser?.displayName}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Live Daily Drawer Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-800">
          <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
              <Wallet className="w-3 h-3 text-emerald-400" />
              <span>Today's Cash Collection</span>
            </span>
            <div className="text-base sm:text-lg font-bold font-mono text-emerald-400 mt-1">
              ৳{todayCashCollection.toLocaleString()}
            </div>
            <span className="text-[10px] text-slate-400">{todaySales.length} Transactions</span>
          </div>

          <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-blue-400" />
              <span>Today's Total Sale</span>
            </span>
            <div className="text-base sm:text-lg font-bold font-mono text-white mt-1">
              ৳{todayTotalSalesValue.toLocaleString()}
            </div>
            <span className="text-[10px] text-slate-400">{activeOffice} Counter</span>
          </div>

          <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-400" />
              <span>Pending Due</span>
            </span>
            <div className="text-base sm:text-lg font-bold font-mono text-amber-400 mt-1">
              ৳{todayPendingDue.toLocaleString()}
            </div>
            <span className="text-[10px] text-slate-400">Receivable on Ledger</span>
          </div>

          <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
              <Truck className="w-3 h-3 text-indigo-400" />
              <span>Trucks Dispatched</span>
            </span>
            <div className="text-base sm:text-lg font-bold font-mono text-indigo-300 mt-1">
              {todayTrucksCount} Trucks
            </div>
            <span className="text-[10px] text-slate-400">Scale Weighed</span>
          </div>
        </div>
      </div>

      {/* POS Navigation Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('counter')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'counter'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Store className="w-4 h-4" />
            <span>⚡ Counter Sale & Billing</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'history'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>📋 Branch POS Register ({officeSales.length} Transactions)</span>
          </button>
        </div>

        <span className="hidden sm:inline-block text-xs text-slate-500 font-medium">
          Cashier: <strong className="text-slate-800">{currentUser?.displayName}</strong> ({activeOffice})
        </span>
      </div>

      {/* ==================== TAB 1: LIVE COUNTER SALE ==================== */}
      {activeTab === 'counter' && (
        <form onSubmit={handleCompleteSale} autoComplete="off" className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left Column: Product Picker, Truck & Customer Details */}
          <div className="lg:col-span-7 space-y-4">
            {/* Quick Product Cards */}
            <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Scale className="w-4 h-4 text-indigo-600" />
                  <h3 className="font-bold text-slate-900 text-sm">
                    Select Stone / Goods ({activeOffice} Yard Stock)
                  </h3>
                </div>
                <span className="text-[11px] text-slate-400">Click to add to billing cart</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {fastProducts.map((prod) => (
                  <button
                    key={prod.id}
                    type="button"
                    onClick={() => handleAddProductToCart(prod)}
                    className="p-3 rounded-xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 text-left transition-all group flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 group-hover:bg-blue-100 group-hover:text-blue-700">
                          {prod.tag}
                        </span>
                      </div>
                      <span className="font-bold text-xs text-slate-900 group-hover:text-blue-700 line-clamp-2">
                        {prod.name}
                      </span>
                    </div>
                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-indigo-900">
                        ৳{prod.price.toLocaleString()} / {prod.uom}
                      </span>
                      <Plus className="w-3.5 h-3.5 text-blue-600 group-hover:scale-125 transition-transform" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Truck, Driver & Weighbridge Inputs */}
            <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200 space-y-3.5">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                <Truck className="w-4 h-4 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Transport & Weighbridge Details
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Truck Number *
                  </label>
                  <input
                    type="text"
                    value={truckNo}
                    onChange={(e) => setTruckNo(e.target.value)}
                    placeholder="e.g. Dhaka Metro-Ta 11-5678"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-slate-400"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Weighbridge Slip No *
                  </label>
                  <input
                    type="text"
                    value={weighbridgeSlipNo}
                    onChange={(e) => setWeighbridgeSlipNo(e.target.value)}
                    placeholder="e.g. WB-BUR-9945"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-slate-400"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Net Weighed Quantity (MT) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min={0.5}
                    value={netWeightMt || ''}
                    onChange={(e) => handleNetWeightChange(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-base text-indigo-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Driver Phone No
                  </label>
                  <input
                    type="text"
                    value={driverPhone}
                    onChange={(e) => setDriverPhone(e.target.value)}
                    placeholder="017XX-XXXXXX"
                    className="w-full border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-slate-400"
                  />
                </div>
              </div>
            </div>

            {/* Customer Information */}
            <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200 space-y-3.5">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                <User className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Customer / Buyer Information
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Select Existing Dealer / Customer
                  </label>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => {
                      setSelectedCustomerId(e.target.value);
                      const found = MOCK_CUSTOMERS.find(c => c.id === e.target.value);
                      if (found) {
                        setCustomCustomerName(found.name);
                        setCustomerPhone(found.phone || '');
                      }
                    }}
                    className="w-full border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-blue-500 focus:outline-none font-medium"
                  >
                    <option value="">-- Or Enter Walk-in Buyer Below --</option>
                    {MOCK_CUSTOMERS.map(c => (
                      <option key={c.id} value={c.id}>{c.name} ({c.tradeName})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Customer Name
                  </label>
                  <input
                    type="text"
                    value={customCustomerName}
                    onChange={(e) => setCustomCustomerName(e.target.value)}
                    placeholder="e.g. M/S Haji Stone Traders"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-slate-400"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">
                    Customer Mobile Number
                  </label>
                  <input
                    type="text"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. 01712-345678"
                    className="w-full border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-slate-400"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Billing Cart & Payment Settlement */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-md border border-slate-200 space-y-4 sticky top-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-bold text-slate-900 text-sm">
                    POS Sales Bill
                  </h3>
                </div>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                  {activeOffice}
                </span>
              </div>

              {/* Items In Cart Table */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
                  <span>Item & Qty (MT)</span>
                  <span>Rate / Amount</span>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {cartItems.map((item, idx) => (
                    <div key={idx} className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <span className="font-bold text-slate-900 line-clamp-1">{item.itemName}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveCartItem(idx)}
                          className="text-slate-400 hover:text-rose-600 transition-colors p-0.5"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div className="flex items-center gap-1.5">
                          <label className="text-[10px] text-slate-500 font-semibold">Qty:</label>
                          <input
                            type="number"
                            step="0.1"
                            value={item.quantity}
                            onChange={(e) => handleUpdateCartQty(idx, Number(e.target.value))}
                            className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 font-mono font-bold text-slate-800 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                          />
                          <span className="text-[10px] text-slate-400 font-bold">{item.uom}</span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <label className="text-[10px] text-slate-500 font-semibold">Rate:</label>
                          <input
                            type="number"
                            value={item.unitPrice}
                            onChange={(e) => handleUpdateCartPrice(idx, Number(e.target.value))}
                            className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 font-mono font-bold text-slate-800 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-200 text-[11px]">
                        <span className="text-slate-500 font-medium">Line Total:</span>
                        <span className="font-mono font-bold text-indigo-900">৳{item.total.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bill Totals */}
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-600">
                  <span>Subtotal:</span>
                  <span className="font-mono font-bold text-slate-900">৳{subtotal.toLocaleString()}</span>
                </div>

                <div className="flex items-center justify-between text-slate-600">
                  <span className="flex items-center gap-1">
                    <span>Discount:</span>
                  </span>
                  <input
                    type="number"
                    value={discountAmount || ''}
                    onChange={(e) => setDiscountAmount(Number(e.target.value))}
                    min={0}
                    className="w-28 text-right bg-white border border-slate-300 rounded-lg px-2 py-1 font-mono font-bold text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-300 text-sm font-bold text-slate-900">
                  <span>Grand Total:</span>
                  <span className="text-base font-mono text-blue-900">৳{grandTotal.toLocaleString()}</span>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-2 text-xs">
                <label className="block font-bold text-slate-800">
                  Payment Method *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Cash', 'bKash / Nagad', 'Bank Cheque', 'Credit'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`p-2 rounded-xl border text-xs font-bold transition-all text-center ${
                        paymentMethod === method
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              {/* Paid Amount & Due Calculation */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Paid Amount *
                  </label>
                  <input
                    type="number"
                    value={paidAmount || ''}
                    onChange={(e) => setPaidAmount(Number(e.target.value))}
                    min={0}
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-emerald-700 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Due Amount
                  </label>
                  <div className={`p-2.5 rounded-xl border font-mono font-bold text-sm ${
                    dueAmount > 0 
                      ? 'bg-amber-50 text-amber-900 border-amber-300' 
                      : 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  }`}>
                    ৳{dueAmount.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <button
                type="submit"
                className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-sm font-bold shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Complete Sale & Print Slip</span>
              </button>

              <p className="text-[10px] text-center text-slate-400">
                Automatically recorded in {activeOffice} cash & stock ledger
              </p>
            </div>
          </div>
        </form>
      )}

      {/* ==================== TAB 2: BRANCH POS REGISTER / HISTORY ==================== */}
      {activeTab === 'history' && (
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-4 sm:p-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                {activeOffice} - POS Transaction Register
              </h3>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={historySearch}
                  onChange={(e) => setHistorySearch(e.target.value)}
                  placeholder="Search invoice, truck, or customer..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <select
                value={historyStatusFilter}
                onChange={(e) => setHistoryStatusFilter(e.target.value as any)}
                className="text-xs border border-slate-300 rounded-xl px-2.5 py-1.5 focus:ring-2 focus:ring-blue-500 focus:outline-none font-medium"
              >
                <option value="All">All Status</option>
                <option value="Completed">Paid</option>
                <option value="Pending Due">Due</option>
              </select>
            </div>
          </div>

          {/* Transactions Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 border-y border-slate-200 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Date / Invoice</th>
                  <th className="py-2.5 px-3">Customer / Phone</th>
                  <th className="py-2.5 px-3">Truck & Weighbridge</th>
                  <th className="py-2.5 px-3">Items & MT</th>
                  <th className="py-2.5 px-3 text-right">Grand Total</th>
                  <th className="py-2.5 px-3 text-right">Paid / Due</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredHistory.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      <Receipt className="w-10 h-10 mx-auto mb-2 text-slate-300 stroke-1" />
                      <p className="font-semibold">No transactions found</p>
                    </td>
                  </tr>
                ) : (
                  filteredHistory.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900 font-mono">{s.invoiceNo}</div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-1">
                          <span>{s.date}</span>
                          <span>•</span>
                          <span>{s.time}</span>
                        </div>
                        <div className="text-[10px] font-mono text-indigo-700 mt-0.5">{s.challanNo}</div>
                      </td>

                      <td className="py-3 px-3">
                        <span className="font-bold text-slate-900 block">{s.customerName}</span>
                        <span className="text-[10px] text-slate-400">{s.customerPhone || 'N/A'}</span>
                      </td>

                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1 font-semibold text-slate-800">
                          <Truck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          <span>{s.truckNo}</span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-500">
                          Slip: {s.weighbridgeSlipNo} ({s.netWeightMt} MT)
                        </span>
                      </td>

                      <td className="py-3 px-3">
                        <span className="text-slate-800 font-medium block">
                          {s.items.map(i => `${i.itemName} (${i.quantity} ${i.uom})`).join(', ')}
                        </span>
                        <span className="text-[10px] text-slate-400">Cashier: {s.cashierName}</span>
                      </td>

                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                        ৳{s.grandTotal.toLocaleString()}
                      </td>

                      <td className="py-3 px-3 text-right font-mono">
                        <span className="text-emerald-700 font-bold block">৳{s.paidAmount.toLocaleString()}</span>
                        {s.dueAmount > 0 && (
                          <span className="text-amber-700 text-[10px] font-bold">Due: ৳{s.dueAmount.toLocaleString()}</span>
                        )}
                      </td>

                      <td className="py-3 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          s.status === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-100 text-amber-800 border border-amber-200'
                        }`}>
                          {s.status === 'Completed' ? '✓ Paid' : '⏳ Due'}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {s.dueAmount > 0 && (
                            <button
                              type="button"
                              onClick={() => {
                                setDuePaymentSale(s);
                                setPaymentAmountInput(0);
                              }}
                              className="px-2 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-800 rounded-lg text-[10px] font-bold transition-colors"
                              title="Record payment against outstanding due"
                            >
                              Pay Due
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => setPrintModalSale(s)}
                            className="p-1.5 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-200 rounded-lg transition-colors"
                            title="Print official receipt & delivery challan"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== MODAL 1: PRINTABLE POS SLIP & CHALLAN ==================== */}
      <ModalWrapper
        isOpen={!!printModalSale}
        onClose={() => setPrintModalSale(null)}
        isDirty={false}
        backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
      >
        {printModalSale && (
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 animate-in fade-in zoom-in-95 border border-slate-200 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Official Delivery Challan & POS Money Receipt
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setPrintModalSale(null)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Printable Receipt Paper Container */}
            <div id="printable-pos-receipt" className="p-4 bg-slate-50 border border-slate-200 rounded-xl mt-4 font-mono text-xs space-y-3">
              {/* Slip Header */}
              <div className="text-center pb-3 border-b border-dashed border-slate-300">
                <h2 className="text-base font-bold text-slate-900 tracking-tight">
                  APEX GLOBAL & TRADECORE ENTERPRISE
                </h2>
                <div className="text-xs font-bold text-blue-900 mt-0.5">
                  {printModalSale.branch.toUpperCase()}
                </div>
                <p className="text-[10px] text-slate-500">
                  Land Port Stock Yard, Customs Approved Weighing Terminal
                </p>
                <div className="text-[10px] font-bold text-slate-700 mt-1">
                  DELIVERY CHALLAN & CASH MONEY RECEIPT
                </div>
              </div>

              {/* Meta details */}
              <div className="grid grid-cols-2 gap-2 text-[11px] pb-2 border-b border-dashed border-slate-300">
                <div>
                  <span className="text-slate-500 block">Invoice No:</span>
                  <strong className="text-slate-900">{printModalSale.invoiceNo}</strong>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block">Challan No:</span>
                  <strong className="text-indigo-900">{printModalSale.challanNo}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Date & Time:</span>
                  <span>{printModalSale.date} {printModalSale.time}</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block">Branch Cashier:</span>
                  <span>{printModalSale.cashierName.split('(')[0]}</span>
                </div>
              </div>

              {/* Transport & Customer */}
              <div className="p-2 bg-white rounded-lg border border-slate-200 text-[11px] space-y-1">
                <div><strong>Customer:</strong> {printModalSale.customerName}</div>
                <div><strong>Mobile:</strong> {printModalSale.customerPhone || 'N/A'}</div>
                <div><strong>Truck No:</strong> {printModalSale.truckNo}</div>
                <div><strong>Weighbridge Slip:</strong> {printModalSale.weighbridgeSlipNo} ({printModalSale.netWeightMt} MT Net)</div>
              </div>

              {/* Items List */}
              <table className="w-full text-left text-[11px] border-collapse">
                <thead>
                  <tr className="border-b border-slate-300 text-slate-500">
                    <th className="py-1">Description</th>
                    <th className="py-1 text-center">MT</th>
                    <th className="py-1 text-right">Rate</th>
                    <th className="py-1 text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {printModalSale.items.map((i, idx) => (
                    <tr key={idx}>
                      <td className="py-1 font-semibold text-slate-800">{i.itemName}</td>
                      <td className="py-1 text-center font-bold">{i.quantity}</td>
                      <td className="py-1 text-right">৳{i.unitPrice}</td>
                      <td className="py-1 text-right font-bold">৳{i.total.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Calculations */}
              <div className="pt-2 border-t border-dashed border-slate-300 space-y-1 text-right text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Subtotal:</span>
                  <span>৳{printModalSale.subtotal.toLocaleString()}</span>
                </div>
                {printModalSale.discount > 0 && (
                  <div className="flex justify-between text-rose-600">
                    <span>Discount:</span>
                    <span>-৳{printModalSale.discount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-sm text-slate-900 pt-1 border-t border-slate-200">
                  <span>Grand Total:</span>
                  <span>৳{printModalSale.grandTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-emerald-700 font-bold">
                  <span>Paid ({printModalSale.paymentMethod}):</span>
                  <span>৳{printModalSale.paidAmount.toLocaleString()}</span>
                </div>
                {printModalSale.dueAmount > 0 && (
                  <div className="flex justify-between text-amber-700 font-bold">
                    <span>Current Due:</span>
                    <span>৳{printModalSale.dueAmount.toLocaleString()}</span>
                  </div>
                )}
              </div>

              {/* Signatures */}
              <div className="pt-6 grid grid-cols-2 gap-4 text-center text-[10px] text-slate-500">
                <div className="border-t border-slate-400 pt-1">
                  Customer Signature
                </div>
                <div className="border-t border-slate-400 pt-1">
                  Authorized Branch In-Charge
                </div>
              </div>
            </div>

            {/* Print Buttons */}
            <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200 mt-4">
              <button
                type="button"
                onClick={() => setPrintModalSale(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition-colors text-xs cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-colors flex items-center gap-1.5 text-xs shadow-xs cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Official Slip</span>
              </button>
            </div>
          </div>
        )}
      </ModalWrapper>

      {/* ==================== MODAL 2: RECORD PAYMENT FOR DUE SALE ==================== */}
      <ModalWrapper
        isOpen={!!duePaymentSale}
        onClose={() => {
          setDuePaymentSale(null);
          setPaymentAmountInput(0);
        }}
        isDirty={paymentAmountInput > 0}
        backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
      >
        {duePaymentSale && (
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Record Due Payment
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setDuePaymentSale(null);
                  setPaymentAmountInput(0);
                }}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRecordDuePayment} autoComplete="off" className="space-y-4 mt-4 text-xs">
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                <div className="font-bold text-slate-800">{duePaymentSale.customerName}</div>
                <div className="text-[11px] text-slate-600">Invoice: {duePaymentSale.invoiceNo} • {duePaymentSale.branch}</div>
                <div className="text-sm font-bold text-amber-900 font-mono pt-1">
                  Total Due: ৳{duePaymentSale.dueAmount.toLocaleString()}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Payment Collection Amount *
                </label>
                <input
                  type="number"
                  value={paymentAmountInput || ''}
                  onChange={(e) => setPaymentAmountInput(Number(e.target.value))}
                  max={duePaymentSale.dueAmount}
                  min={1}
                  required
                  className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-base text-emerald-700 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setDuePaymentSale(null);
                    setPaymentAmountInput(0);
                  }}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition-colors shadow-xs cursor-pointer"
                >
                  Confirm & Receive Payment
                </button>
              </div>
            </form>
          </div>
        )}
      </ModalWrapper>
    </div>
  );
};
