import React, { useState } from 'react';
import { ModalWrapper } from '../common/ModalWrapper';
import { 
  Send, 
  Search, 
  Plus, 
  Truck, 
  Printer, 
  Scale, 
  FileText, 
  User, 
  CheckCircle2, 
  MapPin,
  ExternalLink,
  AlertCircle
} from 'lucide-react';
import { SalesDispatchRecord, InventoryItem, Warehouse, Customer } from '../../types/erp';
import { 
  isStockItem, 
  getAvailableStockForWarehouse, 
  validateStockAvailabilityForLines 
} from '../../utils/itemStorage';
import { getSystemInventorySettings } from '../../utils/systemSettingsStorage';
import { useAuth } from '../../contexts/AuthContext';

interface SalesDispatchesTabProps {
  dispatches: SalesDispatchRecord[];
  items: InventoryItem[];
  warehouses: Warehouse[];
  customers: Customer[];
  onAddDispatch: (dispatch: SalesDispatchRecord) => void;
}

export const SalesDispatchesTab: React.FC<SalesDispatchesTabProps> = ({
  dispatches,
  items,
  warehouses,
  customers,
  onAddDispatch
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';
  const allowNegativeStock = getSystemInventorySettings().allowNegativeStock;

  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedChallanForPrint, setSelectedChallanForPrint] = useState<SalesDispatchRecord | null>(null);

  // New dispatch form state
  const [customerId, setCustomerId] = useState('');
  const [destination, setDestination] = useState('');
  const [vehicleNo, setVehicleNo] = useState('');
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState('');
  const [selectedItemId, setSelectedItemId] = useState('');
  const [lengthFt, setLengthFt] = useState(0);
  const [widthFt, setWidthFt] = useState(0);
  const [heightFt, setHeightFt] = useState(0);
  const [netWeightMt, setNetWeightMt] = useState(0);
  const [scaleSlipNo, setScaleSlipNo] = useState('');
  const [negativeStockReason, setNegativeStockReason] = useState('');
  const [dispatchError, setDispatchError] = useState<string | null>(null);

  const calculatedCft = Number((lengthFt * widthFt * heightFt).toFixed(1));
  const selectedItemObj = items.find(i => i.id === selectedItemId);
  const availWarehouseStock = selectedItemObj ? getAvailableStockForWarehouse(selectedItemObj, selectedWarehouseId) : 0;
  const dispatchQtyInItemUom = selectedItemObj?.uom?.toUpperCase() === 'CFT' ? calculatedCft : netWeightMt;

  const filteredDispatches = dispatches.filter(dsp =>
    dsp.challanNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dsp.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dsp.vehicleNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dsp.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dsp.destination.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDispatchError(null);
    const itm = items.find(i => i.id === selectedItemId);
    const wh = warehouses.find(w => w.id === selectedWarehouseId);
    const cust = customers.find(c => c.id === customerId);
    if (!itm || !wh || !cust) return;

    const qtyToDispatch = itm.uom?.toUpperCase() === 'CFT' ? calculatedCft : netWeightMt;
    const stockCheck = validateStockAvailabilityForLines(
      [{ itemId: itm.id, itemName: itm.name, quantity: qtyToDispatch, uom: itm.uom }],
      wh.id,
      { isAdmin, negativeStockReason }
    );

    if (!stockCheck.valid) {
      setDispatchError(stockCheck.errors[0]);
      return;
    }

    const newDispatch: SalesDispatchRecord = {
      id: `dsp-${Date.now()}`,
      challanNo: `CH-BUR-${String(dispatches.length + 1055).padStart(4, '0')}`,
      dispatchDate: new Date().toISOString().split('T')[0],
      invoiceNo: `INV-2026-${String(dispatches.length + 425).padStart(5, '0')}`,
      customerId: cust.id,
      customerName: cust.name,
      destination,
      vehicleNo: vehicleNo.trim(),
      driverName: driverName.trim(),
      driverPhone: driverPhone.trim(),
      measurementLength: lengthFt,
      measurementWidth: widthFt,
      measurementHeight: heightFt,
      measurementCft: calculatedCft,
      netWeightMt,
      weighbridgeSlipNo: scaleSlipNo,
      itemId: itm.id,
      itemName: itm.name,
      dispatchedQty: qtyToDispatch,
      uom: itm.uom,
      warehouseId: wh.id,
      warehouseName: wh.name,
      dispatchedBy: currentUser?.name || 'Amir Hamza',
      status: 'Dispatched'
    };

    onAddDispatch(newDispatch);
    setShowAddModal(false);
    resetDispatchForm();
  };

  const resetDispatchForm = () => {
    setCustomerId('');
    setDestination('');
    setVehicleNo('');
    setDriverName('');
    setDriverPhone('');
    setSelectedWarehouseId('');
    setSelectedItemId('');
    setLengthFt(0);
    setWidthFt(0);
    setHeightFt(0);
    setNetWeightMt(0);
    setScaleSlipNo('');
    setNegativeStockReason('');
    setDispatchError(null);
  };

  const handleCloseAddModal = () => {
    setShowAddModal(false);
    resetDispatchForm();
  };

  const isAddDirty = Boolean(
    showAddModal && (
      customerId ||
      destination.trim() ||
      vehicleNo.trim() ||
      driverName.trim() ||
      driverPhone.trim() ||
      selectedWarehouseId ||
      selectedItemId ||
      lengthFt > 0 ||
      widthFt > 0 ||
      heightFt > 0 ||
      netWeightMt > 0 ||
      scaleSlipNo.trim()
    )
  );

  const handlePrintSlip = (dsp: SalesDispatchRecord) => {
    setSelectedChallanForPrint(dsp);
    setTimeout(() => {
      window.print();
    }, 200);
  };

  return (
    <div className="space-y-4">
      {/* Search & Actions */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Challan, Truck No, Customer, Destination..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-amber-500 font-sans"
          />
        </div>

        <button
          type="button"
          onClick={() => {
            resetDispatchForm();
            setShowAddModal(true);
          }}
          className="px-3.5 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Create Delivery Challan
        </button>
      </div>

      {/* Dispatches List */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Challan & Date</th>
                <th className="py-3 px-4">Customer & Destination</th>
                <th className="py-3 px-4">Product Cargo</th>
                <th className="py-3 px-4">Truck No & Driver</th>
                <th className="py-3 px-4 text-center">Measurement (CFT)</th>
                <th className="py-3 px-4 text-right">Net Weight</th>
                <th className="py-3 px-4">Dispatch Yard</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Print</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredDispatches.map((dsp) => (
                <tr key={dsp.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4">
                    <span className="font-mono font-bold text-amber-900">{dsp.challanNo}</span>
                    <div className="text-[10px] text-slate-400 font-mono">{dsp.dispatchDate}</div>
                    {dsp.invoiceNo && (
                      <span className="text-[10px] text-blue-700 font-mono">{dsp.invoiceNo}</span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-slate-900">{dsp.customerName}</span>
                    <div className="text-[10px] text-slate-500 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {dsp.destination}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-slate-900">{dsp.itemName}</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-mono font-bold text-slate-800 flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-slate-400" />
                      {dsp.vehicleNo}
                    </div>
                    <div className="text-[10px] text-slate-500">
                      {dsp.driverName} {dsp.driverPhone && `(${dsp.driverPhone})`}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center font-mono">
                    {dsp.measurementCft ? (
                      <div>
                        <span className="font-bold text-slate-900">{dsp.measurementCft} CFT</span>
                        <div className="text-[10px] text-slate-400">
                          {dsp.measurementLength} × {dsp.measurementWidth} × {dsp.measurementHeight} ft
                        </div>
                      </div>
                    ) : (
                      <span className="text-slate-400">-</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {dsp.dispatchedQty} {dsp.uom}
                    {dsp.weighbridgeSlipNo && (
                      <div className="text-[10px] text-slate-400 font-normal">Slip: {dsp.weighbridgeSlipNo}</div>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-medium border border-slate-200">
                      {dsp.warehouseName}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                      <CheckCircle2 className="w-3 h-3" /> {dsp.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <button
                      type="button"
                      onClick={() => handlePrintSlip(dsp)}
                      className="p-1.5 text-slate-600 hover:text-slate-950 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                      title="Print Challan Slip"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: New Sales Dispatch Challan */}
      {showAddModal && (
        <ModalWrapper
          isOpen={showAddModal}
          onClose={handleCloseAddModal}
          isDirty={isAddDirty}
          maxWidth="max-w-2xl"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-5 space-y-4 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Send className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-sm text-slate-900">Issue Sales Dispatch & Delivery Challan</h3>
              </div>
              <button 
                type="button"
                data-modal-close="true"
                onClick={handleCloseAddModal} 
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} autoComplete="off" className="space-y-3 text-xs">
              {dispatchError && (
                <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="font-semibold">{dispatchError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Customer *</label>
                  <select
                    value={customerId}
                    onChange={(e) => setCustomerId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value="">Select Customer...</option>
                    {customers.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Delivery Destination *</label>
                  <input
                    type="text"
                    required
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Product Item *</label>
                  <select
                    value={selectedItemId}
                    onChange={(e) => {
                      setDispatchError(null);
                      setSelectedItemId(e.target.value);
                    }}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value="">Select Product Item...</option>
                    {items.map(i => {
                      const whAvail = getAvailableStockForWarehouse(i, selectedWarehouseId);
                      const outOfStock = isStockItem(i) && whAvail <= 0;
                      return (
                        <option
                          key={i.id}
                          value={i.id}
                          disabled={outOfStock && !(allowNegativeStock && isAdmin)}
                        >
                          {i.name} ({outOfStock ? `Out of stock: 0 ${i.uom}` : `Yard Stock: ${whAvail} ${i.uom}`})
                        </option>
                      );
                    })}
                  </select>
                  {selectedItemObj && isStockItem(selectedItemObj) && (
                    <span className={`text-[10px] font-mono mt-0.5 block ${
                      dispatchQtyInItemUom > availWarehouseStock ? 'text-rose-600 font-bold' : 'text-slate-500'
                    }`}>
                      Available in selected yard: {availWarehouseStock} {selectedItemObj.uom}
                      {dispatchQtyInItemUom > availWarehouseStock ? ` — Exceeds available stock by ${Number((dispatchQtyInItemUom - availWarehouseStock).toFixed(2))} ${selectedItemObj.uom}` : ''}
                    </span>
                  )}
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Dispatch Yard *</label>
                  <select
                    value={selectedWarehouseId}
                    onChange={(e) => {
                      setDispatchError(null);
                      setSelectedWarehouseId(e.target.value);
                    }}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value="">Select Dispatch Yard...</option>
                    {warehouses.map(w => (
                      <option key={w.id} value={w.id}>{w.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {selectedItemObj && isStockItem(selectedItemObj) && dispatchQtyInItemUom > availWarehouseStock && allowNegativeStock && isAdmin && (
                <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-xl space-y-1">
                  <label className="block text-[11px] font-bold text-amber-900">
                    Admin Negative Stock Override Reason *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter reason for dispatching above available yard stock..."
                    value={negativeStockReason}
                    onChange={(e) => setNegativeStockReason(e.target.value)}
                    className="w-full p-1.5 bg-white border border-amber-300 rounded-lg text-xs text-slate-900"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Truck / Vehicle No *</label>
                  <input
                    type="text"
                    required
                    value={vehicleNo}
                    onChange={(e) => setVehicleNo(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Driver Name</label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Driver Phone</label>
                  <input
                    type="text"
                    value={driverPhone}
                    onChange={(e) => setDriverPhone(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              {/* Truck Measurement section */}
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3">
                <div className="font-bold text-amber-950 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Scale className="w-4 h-4 text-amber-700" />
                    Truck Dimension Measurement
                  </div>
                  <span className="font-mono font-bold text-amber-900">{calculatedCft} CFT</span>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Length (Feet)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={lengthFt || ''}
                      onChange={(e) => setLengthFt(Number(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Width (Feet)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={widthFt || ''}
                      onChange={(e) => setWidthFt(Number(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Height (Feet)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={heightFt || ''}
                      onChange={(e) => setHeightFt(Number(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Net Weight MT (Scale)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={netWeightMt || ''}
                      onChange={(e) => setNetWeightMt(Number(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Weighbridge Slip No</label>
                    <input
                      type="text"
                      value={scaleSlipNo}
                      onChange={(e) => setScaleSlipNo(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleCloseAddModal}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  Confirm & Dispatch Cargo
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* Printable Challan Slip (Hidden during screen viewing, styled for window.print) */}
      {selectedChallanForPrint && (
        <div className="hidden print:block fixed inset-0 bg-white p-8 z-50 text-slate-900 font-sans">
          <div className="max-w-2xl mx-auto border-2 border-slate-900 p-6 space-y-4">
            <div className="text-center border-b-2 border-slate-900 pb-3">
              <h1 className="text-2xl font-black tracking-wider uppercase">STARLINE IMPORTS & EXPORTS</h1>
              <p className="text-xs font-semibold text-slate-700">Burimari Land Port / Sonahat Land Port</p>
              <h2 className="text-sm font-bold mt-2 uppercase bg-slate-900 text-white inline-block px-4 py-1">
                DELIVERY CHALLAN & GATE PASS
              </h2>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs font-mono">
              <div>
                <p><strong>Challan No:</strong> {selectedChallanForPrint.challanNo}</p>
                <p><strong>Date:</strong> {selectedChallanForPrint.dispatchDate}</p>
                <p><strong>Customer:</strong> {selectedChallanForPrint.customerName}</p>
                <p><strong>Destination:</strong> {selectedChallanForPrint.destination}</p>
              </div>
              <div>
                <p><strong>Vehicle No:</strong> {selectedChallanForPrint.vehicleNo}</p>
                <p><strong>Driver:</strong> {selectedChallanForPrint.driverName} ({selectedChallanForPrint.driverPhone})</p>
                <p><strong>Scale Slip:</strong> {selectedChallanForPrint.weighbridgeSlipNo}</p>
                <p><strong>Dispatch Yard:</strong> {selectedChallanForPrint.warehouseName}</p>
              </div>
            </div>

            <table className="w-full text-xs border border-slate-900 border-collapse mt-4">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-900">
                  <th className="p-2 border-r border-slate-900 text-left">Item Description</th>
                  <th className="p-2 border-r border-slate-900 text-center">Dimensions (L × W × H)</th>
                  <th className="p-2 border-r border-slate-900 text-right">CFT Volume</th>
                  <th className="p-2 text-right">Net Weight (MT)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="p-2 border-r border-slate-900 font-bold">{selectedChallanForPrint.itemName}</td>
                  <td className="p-2 border-r border-slate-900 text-center font-mono">
                    {selectedChallanForPrint.measurementLength} × {selectedChallanForPrint.measurementWidth} × {selectedChallanForPrint.measurementHeight} ft
                  </td>
                  <td className="p-2 border-r border-slate-900 text-right font-mono font-bold">
                    {selectedChallanForPrint.measurementCft} CFT
                  </td>
                  <td className="p-2 text-right font-mono font-bold">
                    {selectedChallanForPrint.dispatchedQty} MT
                  </td>
                </tr>
              </tbody>
            </table>

            <div className="pt-12 grid grid-cols-3 gap-4 text-center text-xs border-t border-slate-400 mt-12">
              <div>
                <div className="border-t border-slate-900 pt-1">Driver Signature</div>
              </div>
              <div>
                <div className="border-t border-slate-900 pt-1">Yard Scale Officer</div>
              </div>
              <div>
                <div className="border-t border-slate-900 pt-1">Authorized Starline Sign</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
