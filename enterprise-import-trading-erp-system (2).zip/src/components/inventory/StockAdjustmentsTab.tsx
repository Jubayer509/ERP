import React, { useState } from 'react';
import { 
  SlidersHorizontal, 
  Search, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingDown, 
  TrendingUp, 
  FileText,
  DollarSign
} from 'lucide-react';
import { StockAdjustment, InventoryItem, Warehouse } from '../../types/erp';
import { ModalWrapper } from '../common/ModalWrapper';

interface StockAdjustmentsTabProps {
  adjustments: StockAdjustment[];
  items: InventoryItem[];
  warehouses: Warehouse[];
  onAddAdjustment: (adj: StockAdjustment) => void;
  currency?: string;
}

export const StockAdjustmentsTab: React.FC<StockAdjustmentsTabProps> = ({
  adjustments,
  items,
  warehouses,
  onAddAdjustment,
  currency = 'BDT'
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New adjustment form state
  const [selectedItemId, setSelectedItemId] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState('');
  const [adjType, setAdjType] = useState<StockAdjustment['type']>('' as any);
  const [quantity, setQuantity] = useState(0); // negative for loss/damage, positive for surplus
  const [reason, setReason] = useState('');

  const selectedItem = items.find(i => i.id === selectedItemId);
  const unitCost = selectedItem?.avgUnitCost || 0;
  const totalValue = Math.abs(quantity * unitCost);

  const filteredAdjustments = adjustments.filter(adj =>
    adj.adjustmentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    adj.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    adj.warehouseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    adj.reason.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isFormDirty = Boolean(selectedItemId || selectedWarehouseId || adjType || quantity !== 0 || reason.trim());

  const resetForm = () => {
    setSelectedItemId('');
    setSelectedWarehouseId('');
    setAdjType('' as any);
    setQuantity(0);
    setReason('');
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    resetForm();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const itm = items.find(i => i.id === selectedItemId);
    const wh = warehouses.find(w => w.id === selectedWarehouseId);
    if (!itm || !wh || quantity === 0) return;

    const newAdj: StockAdjustment = {
      id: `adj-${Date.now()}`,
      adjustmentNumber: `ADJ-2026-${String(adjustments.length + 15).padStart(4, '0')}`,
      adjustmentDate: new Date().toISOString().split('T')[0],
      warehouseId: wh.id,
      warehouseName: wh.name,
      itemId: itm.id,
      itemName: itm.name,
      type: adjType,
      quantity,
      unitCost,
      totalValue,
      reason: reason.trim(),
      approvedBy: 'Jubayer (Operations Lead)'
    };

    onAddAdjustment(newAdj);
    handleCloseModal();
  };

  return (
    <div className="space-y-4">
      {/* Search & Actions */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search adjustment ref, item, yard or audit reason..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-amber-500 font-sans"
          />
        </div>

        <button
          type="button"
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="px-3.5 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Record Stock Adjustment
        </button>
      </div>

      {/* Adjustments List */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Adjustment Ref & Date</th>
                <th className="py-3 px-4">Adjusted Item</th>
                <th className="py-3 px-4">Yard / Location</th>
                <th className="py-3 px-4">Adjustment Type</th>
                <th className="py-3 px-4 text-right">Adjusted Qty</th>
                <th className="py-3 px-4 text-right">Unit Rate</th>
                <th className="py-3 px-4 text-right">Total Impact Value</th>
                <th className="py-3 px-4">Audit Reason & Approval</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredAdjustments.map((adj) => {
                const isLoss = adj.quantity < 0;

                return (
                  <tr key={adj.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4">
                      <span className="font-mono font-bold text-slate-900">{adj.adjustmentNumber}</span>
                      <div className="text-[10px] text-slate-400 font-mono">{adj.adjustmentDate}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-900">{adj.itemName}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium">
                      {adj.warehouseName}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isLoss ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {adj.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold">
                      <span className={isLoss ? 'text-rose-700' : 'text-emerald-700'}>
                        {isLoss ? '' : '+'}{adj.quantity} MT
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono">
                      {currency} {adj.unitCost.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold">
                      <span className={isLoss ? 'text-rose-700' : 'text-emerald-700'}>
                        {currency} {adj.totalValue.toLocaleString()}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-800">{adj.reason}</div>
                      <div className="text-[10px] text-slate-400">By: {adj.approvedBy}</div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: New Stock Adjustment */}
      <ModalWrapper
        isOpen={showAddModal}
        onClose={handleCloseModal}
        isDirty={isFormDirty}
        backdropClassName="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
      >
        <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-5 space-y-4 border border-slate-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-5 h-5 text-amber-600" />
              <h3 className="font-bold text-sm text-slate-900">Record Stock Adjustment</h3>
            </div>
            <button 
              type="button"
              onClick={handleCloseModal} 
              className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
            >
              ✕
            </button>
          </div>

          <form onSubmit={handleSubmit} autoComplete="off" className="space-y-3 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Product Item *</label>
              <select
                value={selectedItemId}
                onChange={(e) => setSelectedItemId(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
              >
                <option value="">Select Product Item...</option>
                {items.map(i => (
                  <option key={i.id} value={i.id}>{i.name} (Current Stock: {i.totalStock} {i.uom})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Storage Location / Yard *</label>
              <select
                value={selectedWarehouseId}
                onChange={(e) => setSelectedWarehouseId(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
              >
                <option value="">Select Storage Location / Yard...</option>
                {warehouses.map(w => (
                  <option key={w.id} value={w.id}>{w.name}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Adjustment Type</label>
                <select
                  value={adjType}
                  onChange={(e) => setAdjType(e.target.value as any)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                >
                  <option value="">Select Adjustment Type...</option>
                  <option value="Damage">Damage</option>
                  <option value="Loss / Shrinkage">Loss / Moisture Shrinkage</option>
                  <option value="Surplus">Surplus / Found Physical Count</option>
                  <option value="Annual Audit Reconcile">Annual Audit Reconcile</option>
                </select>
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Qty Adjustment (+ or - MT) *
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={quantity || ''}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Audit Reason / Justification *</label>
              <input
                type="text"
                required
                placeholder="e.g. Rain washing erosion, ground soil settlement"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
              />
            </div>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-[11px] font-mono">
              Financial Impact: {quantity < 0 ? 'Loss write-off' : 'Inventory Gain'} of {currency} {totalValue.toLocaleString()} will auto-post to GL Account 5400.
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={handleCloseModal}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl shadow-xs cursor-pointer"
              >
                Commit Adjustment
              </button>
            </div>
          </form>
        </div>
      </ModalWrapper>
    </div>
  );
};
