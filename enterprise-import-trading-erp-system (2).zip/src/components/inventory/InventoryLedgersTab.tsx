import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  Calendar, 
  Building,
  TrendingUp,
  TrendingDown,
  ArrowDownLeft,
  ArrowUpRight
} from 'lucide-react';
import { InventoryLedgerEntry, InventoryItem, Warehouse } from '../../types/erp';
import { PrintHeader, PrintSignatures } from '../common/PrintHeader';

interface InventoryLedgersTabProps {
  ledgers: InventoryLedgerEntry[];
  items: InventoryItem[];
  warehouses: Warehouse[];
  currency?: string;
}

export const InventoryLedgersTab: React.FC<InventoryLedgersTabProps> = ({
  ledgers,
  items,
  warehouses,
  currency = 'BDT'
}) => {
  const [selectedItemId, setSelectedItemId] = useState<string>('all');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLedgers = ledgers.filter(entry => {
    const matchesItem = selectedItemId === 'all' || entry.itemId === selectedItemId;
    const matchesWh = selectedWarehouseId === 'all' || entry.warehouseId === selectedWarehouseId;
    const matchesSearch = 
      entry.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.refNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (entry.partyOrVehicle && entry.partyOrVehicle.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (entry.notes && entry.notes.toLowerCase().includes(searchTerm.toLowerCase()));

    return matchesItem && matchesWh && matchesSearch;
  });

  const totalInQty = filteredLedgers.reduce((acc, l) => acc + l.inQty, 0);
  const totalOutQty = filteredLedgers.reduce((acc, l) => acc + l.outQty, 0);

  const selectedItemName = selectedItemId === 'all' 
    ? 'All Items' 
    : items.find(i => i.id === selectedItemId)?.name || selectedItemId;
  const selectedWarehouseName = selectedWarehouseId === 'all'
    ? 'All Locations'
    : warehouses.find(w => w.id === selectedWarehouseId)?.name || selectedWarehouseId;

  const exportCsv = () => {
    const headers = ['Date', 'Reference No', 'Item Name', 'Warehouse', 'Txn Type', 'In Qty', 'Out Qty', 'Balance Qty', 'Unit Rate BDT', 'Balance Value BDT', 'Party / Vehicle', 'Notes'];
    const rows = filteredLedgers.map(l => [
      `"${l.date} ${l.time || ''}"`,
      `"${l.refNo}"`,
      `"${l.itemName}"`,
      `"${l.warehouseName}"`,
      `"${l.txnType}"`,
      l.inQty,
      l.outQty,
      l.balanceQty,
      l.unitRate,
      l.balanceValue,
      `"${l.partyOrVehicle || ''}"`,
      `"${l.notes || ''}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Inventory_Ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      {/* Official Print Header */}
      <PrintHeader
        title="Inventory Stock Ledger & Movement Statement"
        subtitle="Central Material Stock Ledger, Crushing Yard & Port Dispatch Log"
        metadata={[
          { label: 'Item', value: selectedItemName },
          { label: 'Location', value: selectedWarehouseName },
          { label: 'Total Entries', value: `${filteredLedgers.length}` },
          { label: 'Net Balance Change', value: `${(totalInQty - totalOutQty).toLocaleString()} MT` }
        ]}
      />

      {/* KPI Cards (Clean in print) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 print:grid-cols-3 print:gap-2">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs print:p-2 print:border-slate-300">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span>Total Inflow</span>
            <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 print:hidden">
              <ArrowDownLeft className="w-4 h-4" />
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-emerald-700">
            +{totalInQty.toLocaleString()} MT
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs print:p-2 print:border-slate-300">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span>Total Outflow</span>
            <span className="p-1.5 rounded-lg bg-rose-50 text-rose-700 print:hidden">
              <ArrowUpRight className="w-4 h-4" />
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-rose-700">
            -{totalOutQty.toLocaleString()} MT
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs print:p-2 print:border-slate-300">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span>Net Change</span>
            <span className="p-1.5 rounded-lg bg-blue-50 text-blue-700 print:hidden">
              <BookOpen className="w-4 h-4" />
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-900">
            {(totalInQty - totalOutQty).toLocaleString()} MT
          </div>
        </div>
      </div>

      {/* Filter and Control Bar (Hidden when printing) */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3 no-print print:hidden">
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto flex-1">
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search Ref, Item, Vehicle, Notes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-amber-500 font-sans"
            />
          </div>

          <select
            value={selectedItemId}
            onChange={(e) => setSelectedItemId(e.target.value)}
            className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none font-medium text-slate-700 max-w-[200px]"
          >
            <option value="all">All Products</option>
            {items.map(it => (
              <option key={it.id} value={it.id}>{it.name}</option>
            ))}
          </select>

          <select
            value={selectedWarehouseId}
            onChange={(e) => setSelectedWarehouseId(e.target.value)}
            className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none font-medium text-slate-700 max-w-[180px]"
          >
            <option value="all">All Locations</option>
            {warehouses.map(w => (
              <option key={w.id} value={w.id}>{w.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            onClick={exportCsv}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
          <button
            onClick={() => window.print()}
            className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Ledger
          </button>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs print:border-slate-300 print:shadow-none">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200 print:bg-slate-100">
              <tr>
                <th className="py-3 px-4">Date & Time</th>
                <th className="py-3 px-4">Reference No</th>
                <th className="py-3 px-4">Item Name</th>
                <th className="py-3 px-4">Warehouse Yard</th>
                <th className="py-3 px-4">Transaction Type</th>
                <th className="py-3 px-4 text-right">In Qty</th>
                <th className="py-3 px-4 text-right">Out Qty</th>
                <th className="py-3 px-4 text-right">Balance Qty</th>
                <th className="py-3 px-4 text-right">Unit Rate</th>
                <th className="py-3 px-4 text-right">Balance Value</th>
                <th className="py-3 px-4">Party / Vehicle / Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredLedgers.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-mono font-medium text-slate-900">{row.date}</div>
                    <span className="text-[10px] text-slate-400 font-mono">{row.time || ''}</span>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-blue-700 whitespace-nowrap">
                    {row.refNo}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-slate-900">{row.itemName}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {row.warehouseName}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                      row.txnType === 'GRN Receiving' || row.txnType === 'Transfer In' || row.txnType === 'Crushing Output'
                        ? 'bg-emerald-100 text-emerald-800'
                        : row.txnType === 'Sales Dispatch' || row.txnType === 'Transfer Out' || row.txnType === 'Crushing Input'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-slate-100 text-slate-800'
                    }`}>
                      {row.txnType}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                    {row.inQty > 0 ? `+${row.inQty.toLocaleString()}` : '-'}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-rose-700">
                    {row.outQty > 0 ? `-${row.outQty.toLocaleString()}` : '-'}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {row.balanceQty.toLocaleString()} {row.uom}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-600">
                    {currency} {row.unitRate.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {currency} {row.balanceValue.toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium text-slate-800">{row.partyOrVehicle || '-'}</div>
                    {row.notes && (
                      <div className="text-[10px] text-slate-400 truncate max-w-xs">{row.notes}</div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Signatures Block (Print Only) */}
      <PrintSignatures
        preparedByRole="Yard Supervisor"
        auditedByRole="Stock Auditor"
        approvedByRole="Managing Director"
      />
    </div>
  );
};
