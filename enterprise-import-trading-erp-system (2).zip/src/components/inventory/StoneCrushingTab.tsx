import React, { useState, useMemo } from 'react';
import { 
  Hammer, 
  Plus, 
  CheckCircle2, 
  AlertTriangle, 
  Layers, 
  Scale, 
  ArrowRight, 
  History,
  FileCheck2,
  Calculator,
  RefreshCw,
  Info,
  Check,
  PackageCheck,
  X
} from 'lucide-react';
import { 
  StoneCrushingConversionBatch, 
  InventoryItem, 
  Warehouse
} from '../../types/erp';
import { ModalWrapper } from '../common/ModalWrapper';

interface StoneCrushingTabProps {
  batches: StoneCrushingConversionBatch[];
  items: InventoryItem[];
  warehouses: Warehouse[];
  onExecuteCrushing: (batch: StoneCrushingConversionBatch) => void;
  currency?: string;
}

interface CrushedOutputRow {
  fractionKey: string;
  fractionLabel: string;
  defaultCftPerTon: number;
  cftPerTon: number;
  totalCft: number;
  percentage: number;
  itemId: string;
  unitRateBdt: number;
  isDust?: boolean;
}

export const StoneCrushingTab: React.FC<StoneCrushingTabProps> = ({
  batches,
  items,
  warehouses,
  onExecuteCrushing,
  currency = 'BDT'
}) => {
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [selectedBatchDetails, setSelectedBatchDetails] = useState<StoneCrushingConversionBatch | null>(null);

  // Boulder stone raw materials (measured in Ton / MT)
  const boulderItems = useMemo(() => {
    return items.filter(i => 
      i.category.toLowerCase().includes('boulder') || 
      i.name.toLowerCase().includes('boulder') ||
      i.sku.toLowerCase().includes('boulder') ||
      i.uom === 'Ton' ||
      i.uom === 'MT'
    );
  }, [items]);

  // ALL Crushed Stone output items (measured in CFT)
  const allCrushedItems = useMemo(() => {
    return items.filter(i => 
      i.category.toLowerCase().includes('crush') ||
      i.category.toLowerCase().includes('stone') ||
      i.name.toLowerCase().includes('crush') ||
      i.name.toLowerCase().includes('down') ||
      i.name.toLowerCase().includes('chips') ||
      i.name.toLowerCase().includes('dust') ||
      i.uom === 'CFT' ||
      i.sku.toLowerCase().includes('crush') ||
      i.sku.toLowerCase().includes('chips') ||
      i.sku.toLowerCase().includes('dust')
    );
  }, [items]);

  // Crushing plants / mill yards
  const crushingPlants = useMemo(() => {
    const plants = warehouses.filter(w => 
      w.name.toLowerCase().includes('crush') || 
      w.name.toLowerCase().includes('plant') ||
      w.name.toLowerCase().includes('yard') ||
      w.name.toLowerCase().includes('bur') ||
      w.name.toLowerCase().includes('son')
    );
    return plants.length > 0 ? plants : warehouses;
  }, [warehouses]);

  // Helper to find specific crushed items by keyword
  const findCrushedItem = (keywords: string[]) => {
    return allCrushedItems.find(i => {
      const target = (i.name + ' ' + i.sku).toLowerCase();
      return keywords.some(k => target.includes(k.toLowerCase()));
    });
  };

  // Helper matching standard fractions to existing items
  const matched34 = findCrushedItem(['CRUSH-3-4', '3/4" crush', 'single size', '3/4" stone']) || allCrushedItems[0];
  const matched34Down = findCrushedItem(['CRUSH-20MM', '3/4" down', '20mm']) || allCrushedItems[1] || allCrushedItems[0];
  const matched58 = findCrushedItem(['CRUSH-16MM', '5/8', '16mm']) || allCrushedItems[2] || allCrushedItems[0];
  const matched12 = findCrushedItem(['CRUSH-12MM', '1/2', '12mm']) || allCrushedItems[3] || allCrushedItems[0];
  const matched14 = findCrushedItem(['CHIPS-6MM', '1/4', '6mm', 'chips']) || allCrushedItems[4] || allCrushedItems[0];
  const matchedDust = findCrushedItem(['DUST-WST', 'dust']) || allCrushedItems[5] || allCrushedItems[0];

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Batch Form State
  const [inputBoulderId, setInputBoulderId] = useState<string>('');
  const [plantId, setPlantId] = useState<string>('');
  const [inputQtyTon, setInputQtyTon] = useState<number>(0);
  const [targetCftPerTon, setTargetCftPerTon] = useState<number>(0);
  const [crushingExpenseBdt] = useState<number>(0); // Crushing expenses are tracked step-by-step in Chart of Accounts
  const [operatorName, setOperatorName] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');

  // Fractions CFT distribution per 1 Ton
  const [cft34, setCft34] = useState<number>(0);
  const [cft34Down, setCft34Down] = useState<number>(0);
  const [cft58, setCft58] = useState<number>(0);
  const [cft12, setCft12] = useState<number>(0);
  const [cft14, setCft14] = useState<number>(0);
  const [cftDust, setCftDust] = useState<number>(0);

  // Selected item IDs for each fraction
  const [itemId34, setItemId34] = useState<string>('');
  const [itemId34Down, setItemId34Down] = useState<string>('');
  const [itemId58, setItemId58] = useState<string>('');
  const [itemId12, setItemId12] = useState<string>('');
  const [itemId14, setItemId14] = useState<string>('');
  const [itemIdDust, setItemIdDust] = useState<string>('');

  // Optional custom extra crushed item
  const [hasExtraItem, setHasExtraItem] = useState(false);
  const [extraItemId, setExtraItemId] = useState<string>('');
  const [extraCft, setExtraCft] = useState<number>(0);

  // Reset form state to empty
  const resetBatchForm = () => {
    setInputBoulderId('');
    setPlantId('');
    setInputQtyTon(0);
    setTargetCftPerTon(0);
    setOperatorName('');
    setRemarks('');
    setCft34(0);
    setCft34Down(0);
    setCft58(0);
    setCft12(0);
    setCft14(0);
    setCftDust(0);
    setItemId34('');
    setItemId34Down('');
    setItemId58('');
    setItemId12('');
    setItemId14('');
    setItemIdDust('');
    setHasExtraItem(false);
    setExtraItemId('');
    setExtraCft(0);
  };

  const handleOpenBatchModal = () => {
    resetBatchForm();
    setShowBatchModal(true);
  };

  // Selected Raw Boulder details
  const selectedBoulder = useMemo(() => {
    return items.find(i => i.id === inputBoulderId);
  }, [items, inputBoulderId]);

  const inputUnitCost = selectedBoulder?.avgUnitCost || 0;
  const totalInputBoulderCost = Number((inputQtyTon * inputUnitCost).toFixed(2));
  // Total production cost equals raw boulder cost (expenses recorded in accounts)
  const totalProductionCost = totalInputBoulderCost;

  // Actual measured sum of CFT per ton
  const currentTotalCftPerTon = Number((cft34 + cft34Down + cft58 + cft12 + cft14 + cftDust + (hasExtraItem ? extraCft : 0)).toFixed(2));

  // Quick preset button for 5/8"
  const applyPreset58 = (val58: number) => {
    setCft58(val58);
  };

  // Total CFT outputs based on input Ton
  const totalProducedCft = Number((inputQtyTon * currentTotalCftPerTon).toFixed(1));
  const qtyCft34 = Number((inputQtyTon * cft34).toFixed(1));
  const qtyCft34Down = Number((inputQtyTon * cft34Down).toFixed(1));
  const qtyCft58 = Number((inputQtyTon * cft58).toFixed(1));
  const qtyCft12 = Number((inputQtyTon * cft12).toFixed(1));
  const qtyCft14 = Number((inputQtyTon * cft14).toFixed(1));
  const qtyCftDust = Number((inputQtyTon * cftDust).toFixed(1));
  const qtyCftExtra = hasExtraItem ? Number((inputQtyTon * extraCft).toFixed(1)) : 0;

  // Percentage calculations
  const pct34 = currentTotalCftPerTon > 0 ? Number(((cft34 / currentTotalCftPerTon) * 100).toFixed(2)) : 0;
  const pct34Down = currentTotalCftPerTon > 0 ? Number(((cft34Down / currentTotalCftPerTon) * 100).toFixed(2)) : 0;
  const pct58 = currentTotalCftPerTon > 0 ? Number(((cft58 / currentTotalCftPerTon) * 100).toFixed(2)) : 0;
  const pct12 = currentTotalCftPerTon > 0 ? Number(((cft12 / currentTotalCftPerTon) * 100).toFixed(2)) : 0;
  const pct14 = currentTotalCftPerTon > 0 ? Number(((cft14 / currentTotalCftPerTon) * 100).toFixed(2)) : 0;
  const pctDust = currentTotalCftPerTon > 0 ? Number(((cftDust / currentTotalCftPerTon) * 100).toFixed(2)) : 0;
  const pctExtra = hasExtraItem && currentTotalCftPerTon > 0 ? Number(((extraCft / currentTotalCftPerTon) * 100).toFixed(2)) : 0;

  // Cost allocations: Dust valued at ~38 BDT/CFT, remaining production cost allocated among commercial aggregates
  const dustValuation = qtyCftDust * 38;
  const remainingCostToAllocate = Math.max(0, totalProductionCost - dustValuation);
  const totalCommercialCft = totalProducedCft - qtyCftDust;
  const baseCostPerCft = totalCommercialCft > 0 ? Number((remainingCostToAllocate / totalCommercialCft).toFixed(2)) : 112;

  const costPerCft34 = Number((baseCostPerCft * 1.02).toFixed(2));
  const costPerCft34Down = Number((baseCostPerCft * 0.99).toFixed(2));
  const costPerCft58 = Number((baseCostPerCft * 1.01).toFixed(2));
  const costPerCft12 = Number((baseCostPerCft * 1.04).toFixed(2));
  const costPerCft14 = Number((baseCostPerCft * 0.95).toFixed(2));
  const costPerCftDust = 38;

  const handleExecuteBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBoulder || inputQtyTon <= 0 || totalProducedCft <= 0) return;

    const plantWh = warehouses.find(w => w.id === plantId) || warehouses[0];

    const getItemName = (id: string, fallback: string) => {
      const it = items.find(i => i.id === id);
      return it ? it.name : fallback;
    };

    const outputsList: StoneCrushingConversionBatch['outputs'] = [
      {
        itemId: itemId34 || matched34?.id || 'item-stn-07',
        itemName: getItemName(itemId34 || matched34?.id || '', '3/4" Crush Stone'),
        fractionSize: '3/4" Stone',
        cftPerTon: cft34,
        quantityCft: qtyCft34,
        percentage: pct34,
        allocatedUnitCostBdt: costPerCft34,
        totalValueBdt: Math.round(qtyCft34 * costPerCft34)
      },
      {
        itemId: itemId34Down || matched34Down?.id || 'item-stn-03',
        itemName: getItemName(itemId34Down || matched34Down?.id || '', '3/4" Down / 20MM Crush Stone'),
        fractionSize: '3/4" Down (20mm)',
        cftPerTon: cft34Down,
        quantityCft: qtyCft34Down,
        percentage: pct34Down,
        allocatedUnitCostBdt: costPerCft34Down,
        totalValueBdt: Math.round(qtyCft34Down * costPerCft34Down)
      },
      {
        itemId: itemId58 || matched58?.id || 'item-stn-08',
        itemName: getItemName(itemId58 || matched58?.id || '', '5/8" Down / 16MM Crush Stone'),
        fractionSize: '5/8" Down (16mm)',
        cftPerTon: cft58,
        quantityCft: qtyCft58,
        percentage: pct58,
        allocatedUnitCostBdt: costPerCft58,
        totalValueBdt: Math.round(qtyCft58 * costPerCft58)
      },
      {
        itemId: itemId12 || matched12?.id || 'item-stn-04',
        itemName: getItemName(itemId12 || matched12?.id || '', '1/2" Down / 12MM Crush Stone'),
        fractionSize: '1/2" Down (12mm)',
        cftPerTon: cft12,
        quantityCft: qtyCft12,
        percentage: pct12,
        allocatedUnitCostBdt: costPerCft12,
        totalValueBdt: Math.round(qtyCft12 * costPerCft12)
      },
      {
        itemId: itemId14 || matched14?.id || 'item-stn-05',
        itemName: getItemName(itemId14 || matched14?.id || '', '1/4" Chips / 6MM Pea Gravel'),
        fractionSize: '1/4" Chips (6mm)',
        cftPerTon: cft14,
        quantityCft: qtyCft14,
        percentage: pct14,
        allocatedUnitCostBdt: costPerCft14,
        totalValueBdt: Math.round(qtyCft14 * costPerCft14)
      },
      {
        itemId: itemIdDust || matchedDust?.id || 'item-stn-06',
        itemName: getItemName(itemIdDust || matchedDust?.id || '', 'Stone Dust / Crushing Screening'),
        fractionSize: 'Stone Dust',
        cftPerTon: cftDust,
        quantityCft: qtyCftDust,
        percentage: pctDust,
        allocatedUnitCostBdt: costPerCftDust,
        totalValueBdt: Math.round(qtyCftDust * costPerCftDust)
      }
    ];

    if (hasExtraItem && extraItemId && extraCft > 0) {
      outputsList.push({
        itemId: extraItemId,
        itemName: getItemName(extraItemId, 'Custom Crushed Size'),
        fractionSize: 'Custom Size',
        cftPerTon: extraCft,
        quantityCft: qtyCftExtra,
        percentage: pctExtra,
        allocatedUnitCostBdt: baseCostPerCft,
        totalValueBdt: Math.round(qtyCftExtra * baseCostPerCft)
      });
    }

    const newBatch: StoneCrushingConversionBatch = {
      id: `crush-${Date.now()}`,
      batchNo: `CRUSH-2026-${String(batches.length + 38).padStart(4, '0')}`,
      date: new Date().toISOString().split('T')[0],
      plantWarehouseId: plantWh.id,
      plantWarehouseName: plantWh.name,
      inputBoulderItemId: selectedBoulder.id,
      inputBoulderItemName: selectedBoulder.name,
      inputBoulderQtyTon: inputQtyTon,
      inputBoulderQtyMt: inputQtyTon,
      inputUnitCostBdt: inputUnitCost,
      totalInputCostBdt: totalInputBoulderCost,
      crushingExpenseBdt: 0,
      cftPerTonRatio: targetCftPerTon,
      outputs: outputsList,
      totalOutputQtyCft: totalProducedCft,
      dustWastageQtyCft: qtyCftDust,
      dustWastagePercent: pctDust,
      lossVarianceCft: Number((inputQtyTon * targetCftPerTon - totalProducedCft).toFixed(1)),
      operatorName,
      status: 'Completed & Posted',
      remarks
    };

    onExecuteCrushing(newBatch);
    handleCloseBatchModal();
  };

  const isBatchDirty = Boolean(
    inputBoulderId || plantId || inputQtyTon > 0 || targetCftPerTon > 0 || operatorName.trim() || remarks.trim() ||
    cft34 > 0 || cft34Down > 0 || cft58 > 0 || cft12 > 0 || cft14 > 0 || cftDust > 0
  );

  const handleCloseBatchModal = () => {
    setShowBatchModal(false);
    resetBatchForm();
  };

  return (
    <div className="space-y-4">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hero Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Hammer className="w-5 h-5 text-amber-600" />
            Item Adjustment: Boulder Stone to Crush Stone (in CFT) & Dust Wastage
          </h2>
        </div>

        <button
          type="button"
          onClick={handleOpenBatchModal}
          className="px-4 py-2.5 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center gap-2 shadow-xs cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          New Crushing Batch
        </button>
      </div>

      {/* Crushing Batches History Log */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-slate-600" />
            <h3 className="font-bold text-sm text-slate-900">
              Boulder to Crushed Stone History
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {batches.length} Batches Completed
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Batch No & Date</th>
                <th className="py-3 px-4">Crushing Mill / Yard</th>
                <th className="py-3 px-4">Input Boulder (Ton)</th>
                <th className="py-3 px-4">Crushed Stone Output Breakdown (CFT)</th>
                <th className="py-3 px-4 text-right">Total Output</th>
                <th className="py-3 px-4 text-center">Dust Wastage</th>
                <th className="py-3 px-4 text-right">Crushing Cost</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">View</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {batches.map((batch) => {
                const inputTon = batch.inputBoulderQtyTon ?? batch.inputBoulderQtyMt ?? 0;
                const totalCft = batch.totalOutputQtyCft ?? (batch.totalOutputQtyMt ? batch.totalOutputQtyMt * 24 : 0);
                const dustCft = batch.dustWastageQtyCft ?? (batch.dustWastageQtyMt ? batch.dustWastageQtyMt * 24 : 0);

                return (
                  <tr key={batch.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4">
                      <span className="font-mono font-bold text-amber-900">{batch.batchNo}</span>
                      <div className="text-[10px] text-slate-400 font-mono">{batch.date}</div>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      {batch.plantWarehouseName}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{batch.inputBoulderItemName}</div>
                      <div className="text-[11px] font-mono font-bold text-amber-800">
                        {inputTon} Ton (MT)
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1.5 max-w-md">
                        {batch.outputs.map((out, idx) => {
                          const outCft = out.quantityCft ?? (out.quantityMt ? out.quantityMt * 24 : 0);
                          return (
                            <span 
                              key={idx} 
                              className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-slate-100 border border-slate-200 text-slate-800"
                            >
                              {out.fractionSize}: <strong>{outCft.toLocaleString()} CFT</strong>
                              {out.cftPerTon ? <span className="text-slate-500 text-[9px] ml-1">({out.cftPerTon}/Ton)</span> : ''}
                            </span>
                          );
                        })}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800">
                      {totalCft.toLocaleString()} CFT
                    </td>
                    <td className="py-3 px-4 text-center font-mono">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        batch.dustWastagePercent <= 5 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {batch.dustWastagePercent}% ({dustCft.toLocaleString()} CFT)
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      {currency} {batch.crushingExpenseBdt.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3" /> Posted
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => setSelectedBatchDetails(batch)}
                        className="px-2.5 py-1 text-slate-600 hover:text-slate-950 hover:bg-slate-100 rounded text-xs font-semibold cursor-pointer"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: New Crushing Batch */}
      <ModalWrapper
        isOpen={showBatchModal}
        onClose={handleCloseBatchModal}
        isDirty={isBatchDirty}
        backdropClassName="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
      >
        <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full p-6 space-y-4 border border-slate-200 max-h-[92vh] overflow-y-auto">
          {/* Modal Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Hammer className="w-5 h-5 text-amber-600" />
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  New Boulder to Crushed Stone & Dust Conversion Batch
                </h3>
              </div>
            </div>
            <button 
              type="button"
              onClick={handleCloseBatchModal} 
              className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer p-1"
            >
              ✕
            </button>
          </div>

            <form onSubmit={handleExecuteBatch} autoComplete="off" className="space-y-4 text-xs">
              {/* Step 1: Input Boulder Stone (Ton) */}
              <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-amber-950 flex items-center gap-1.5 text-xs">
                    <Layers className="w-4 h-4 text-amber-700" />
                    Step 1: Input Boulder in Ton
                  </h4>
                  <span className="text-[11px] font-mono text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded font-semibold">
                    UOM: Ton
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Select Boulder Stone Item *
                    </label>
                    <select
                      value={inputBoulderId}
                      onChange={(e) => setInputBoulderId(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-medium"
                    >
                      <option value="">Select Boulder Stone Item...</option>
                      {boulderItems.map(i => (
                        <option key={i.id} value={i.id}>
                          {i.name} — (Stock: {i.totalStock} Ton)
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Crushing Mill / Plant Location *
                    </label>
                    <select
                      value={plantId}
                      onChange={(e) => setPlantId(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-medium"
                    >
                      <option value="">Select Crushing Mill / Plant...</option>
                      {crushingPlants.map(w => (
                        <option key={w.id} value={w.id}>{w.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Boulder Input Quantity (Ton) *
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min="0.5"
                        step="0.5"
                        value={inputQtyTon || ''}
                        onChange={(e) => setInputQtyTon(Number(e.target.value))}
                        className="w-full p-2 pr-12 bg-white border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-amber-500 outline-none text-sm"
                      />
                      <span className="absolute right-3 top-2 text-slate-400 font-bold">Ton</span>
                    </div>
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Average Ratio (CFT / Ton)
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min="10"
                        max="40"
                        step="0.5"
                        value={targetCftPerTon || ''}
                        onChange={(e) => setTargetCftPerTon(Number(e.target.value))}
                        className="w-full p-2 pr-12 bg-white border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-amber-500 outline-none text-sm text-emerald-800"
                      />
                      <span className="absolute right-3 top-2 text-slate-400 font-bold">CFT</span>
                    </div>
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Boulder Purchase Rate ({currency}/Ton)
                    </label>
                    <input
                      type="number"
                      disabled
                      value={inputUnitCost || ''}
                      className="w-full p-2 bg-slate-100 border border-slate-200 rounded-xl font-mono text-slate-600"
                    />
                  </div>
                </div>

                <div className="p-3 bg-blue-50/80 border border-blue-200 rounded-xl flex items-center gap-2 text-xs text-blue-950">
                  <Info className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>
                    All stone crushing expenses (labor, electricity, loader, machine operator & helper bills) are recorded directly under <strong>'Stone Crushing Cost'</strong> in the Chart of Accounts.
                  </span>
                </div>

                <div className="flex flex-wrap justify-between items-center text-slate-700 font-mono text-[11px] pt-1 border-t border-amber-200/60">
                  <span>
                    Raw Boulder Cost: <strong>{currency} {totalInputBoulderCost.toLocaleString()}</strong>
                  </span>
                  <span className="text-emerald-800 font-bold">
                    Expected Total Output: <strong>{totalProducedCft.toLocaleString()} CFT</strong>
                  </span>
                </div>
              </div>

              {/* Step 2: Crushed Output Fractions in CFT */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                      <Scale className="w-4 h-4 text-amber-600" />
                      Step 2: Output Breakdown in CFT
                    </h4>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 border border-emerald-200 shadow-2xs">
                      Total Output: {totalProducedCft.toLocaleString()} CFT ({currentTotalCftPerTon} CFT/Ton)
                    </span>
                  </div>
                </div>

                {/* Crushed Stones Output Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {/* 1. 3/4" Single Size */}
                  <div className="p-3 bg-white border border-blue-200 rounded-xl space-y-2 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-blue-900 text-xs">3/4" Stone (3/4" Size)</label>
                      <span className="text-[10px] font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
                        {pct34}%
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 block mb-0.5">Inventory Item:</span>
                      <select
                        value={itemId34}
                        onChange={(e) => setItemId34(e.target.value)}
                        className="w-full p-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                      >
                        <option value="">Select Item...</option>
                        {allCrushedItems.map(i => (
                          <option key={i.id} value={i.id}>{i.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">CFT / Ton:</span>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={cft34 || ''}
                            onChange={(e) => setCft34(Number(e.target.value))}
                            className="w-full p-1.5 pr-8 border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900"
                          />
                          <span className="absolute right-2 top-1.5 text-[10px] text-slate-400">CFT</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">Total Output:</span>
                        <div className="p-1.5 bg-blue-50/50 rounded-lg text-xs font-mono font-bold text-blue-900 border border-blue-100">
                          {qtyCft34.toLocaleString()} CFT
                        </div>
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono flex justify-between">
                      <span>Rate: {currency} {costPerCft34}/CFT</span>
                      <span>Std: 6 CFT/Ton</span>
                    </div>
                  </div>

                  {/* 2. 3/4" Down (20mm) */}
                  <div className="p-3 bg-white border border-indigo-200 rounded-xl space-y-2 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-indigo-900 text-xs">3/4" Down (20mm)</label>
                      <span className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded">
                        {pct34Down}%
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 block mb-0.5">Inventory Item:</span>
                      <select
                        value={itemId34Down}
                        onChange={(e) => setItemId34Down(e.target.value)}
                        className="w-full p-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                      >
                        <option value="">Select Item...</option>
                        {allCrushedItems.map(i => (
                          <option key={i.id} value={i.id}>{i.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">CFT / Ton:</span>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={cft34Down || ''}
                            onChange={(e) => setCft34Down(Number(e.target.value))}
                            className="w-full p-1.5 pr-8 border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900"
                          />
                          <span className="absolute right-2 top-1.5 text-[10px] text-slate-400">CFT</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">Total Output:</span>
                        <div className="p-1.5 bg-indigo-50/50 rounded-lg text-xs font-mono font-bold text-indigo-900 border border-indigo-100">
                          {qtyCft34Down.toLocaleString()} CFT
                        </div>
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono flex justify-between">
                      <span>Rate: {currency} {costPerCft34Down}/CFT</span>
                      <span>Std: 10 CFT/Ton</span>
                    </div>
                  </div>

                  {/* 3. 5/8" Down (16mm) with 3 - 4 CFT Quick Buttons */}
                  <div className="p-3 bg-white border border-teal-200 rounded-xl space-y-2 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <label className="font-bold text-teal-900 text-xs">5/8" Down (16mm)</label>
                      </div>
                      <span className="text-[10px] font-mono font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded">
                        {pct58}%
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 block mb-0.5">Inventory Item:</span>
                      <select
                        value={itemId58}
                        onChange={(e) => setItemId58(e.target.value)}
                        className="w-full p-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                      >
                        <option value="">Select Item...</option>
                        {allCrushedItems.map(i => (
                          <option key={i.id} value={i.id}>{i.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div>
                        <div className="flex justify-between items-center text-[10px] text-slate-500 mb-0.5">
                          <span>CFT / Ton:</span>
                          <div className="flex gap-1">
                            <button
                              type="button"
                              onClick={() => applyPreset58(3.0)}
                              className={`px-1 rounded text-[9px] font-mono font-bold cursor-pointer ${cft58 === 3 ? 'bg-teal-600 text-white' : 'bg-slate-100 text-slate-600'}`}
                            >
                              3
                            </button>
                            <button
                              type="button"
                              onClick={() => applyPreset58(3.5)}
                              className={`px-1 rounded text-[9px] font-mono font-bold cursor-pointer ${cft58 === 3.5 ? 'bg-teal-600 text-white' : 'bg-slate-100 text-slate-600'}`}
                            >
                              3.5
                            </button>
                            <button
                              type="button"
                              onClick={() => applyPreset58(4.0)}
                              className={`px-1 rounded text-[9px] font-mono font-bold cursor-pointer ${cft58 === 4 ? 'bg-teal-600 text-white' : 'bg-slate-100 text-slate-600'}`}
                            >
                              4
                            </button>
                          </div>
                        </div>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={cft58 || ''}
                            onChange={(e) => setCft58(Number(e.target.value))}
                            className="w-full p-1.5 pr-8 border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900"
                          />
                          <span className="absolute right-2 top-1.5 text-[10px] text-slate-400">CFT</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">Total Output:</span>
                        <div className="p-1.5 bg-teal-50/50 rounded-lg text-xs font-mono font-bold text-teal-900 border border-teal-100">
                          {qtyCft58.toLocaleString()} CFT
                        </div>
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono flex justify-between">
                      <span>Rate: {currency} {costPerCft58}/CFT</span>
                      <span>Std: 3 - 4 CFT/Ton</span>
                    </div>
                  </div>

                  {/* 4. 1/2" Down (12mm) */}
                  <div className="p-3 bg-white border border-purple-200 rounded-xl space-y-2 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-purple-900 text-xs">1/2" Down (12mm)</label>
                      <span className="text-[10px] font-mono font-bold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded">
                        {pct12}%
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 block mb-0.5">Inventory Item:</span>
                      <select
                        value={itemId12}
                        onChange={(e) => setItemId12(e.target.value)}
                        className="w-full p-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                      >
                        <option value="">Select Item...</option>
                        {allCrushedItems.map(i => (
                          <option key={i.id} value={i.id}>{i.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">CFT / Ton:</span>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={cft12 || ''}
                            onChange={(e) => setCft12(Number(e.target.value))}
                            className="w-full p-1.5 pr-8 border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900"
                          />
                          <span className="absolute right-2 top-1.5 text-[10px] text-slate-400">CFT</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">Total Output:</span>
                        <div className="p-1.5 bg-purple-50/50 rounded-lg text-xs font-mono font-bold text-purple-900 border border-purple-100">
                          {qtyCft12.toLocaleString()} CFT
                        </div>
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono flex justify-between">
                      <span>Rate: {currency} {costPerCft12}/CFT</span>
                      <span>Std: 2 CFT/Ton</span>
                    </div>
                  </div>

                  {/* 5. 1/4" Chips (6mm) */}
                  <div className="p-3 bg-white border border-sky-200 rounded-xl space-y-2 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-sky-900 text-xs">1/4" Chips (6mm)</label>
                      <span className="text-[10px] font-mono font-bold text-sky-700 bg-sky-50 px-1.5 py-0.5 rounded">
                        {pct14}%
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 block mb-0.5">Inventory Item:</span>
                      <select
                        value={itemId14}
                        onChange={(e) => setItemId14(e.target.value)}
                        className="w-full p-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                      >
                        <option value="">Select Item...</option>
                        {allCrushedItems.map(i => (
                          <option key={i.id} value={i.id}>{i.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">CFT / Ton:</span>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={cft14 || ''}
                            onChange={(e) => setCft14(Number(e.target.value))}
                            className="w-full p-1.5 pr-8 border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900"
                          />
                          <span className="absolute right-2 top-1.5 text-[10px] text-slate-400">CFT</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">Total Output:</span>
                        <div className="p-1.5 bg-sky-50/50 rounded-lg text-xs font-mono font-bold text-sky-900 border border-sky-100">
                          {qtyCft14.toLocaleString()} CFT
                        </div>
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono flex justify-between">
                      <span>Rate: {currency} {costPerCft14}/CFT</span>
                      <span>Std: 2 CFT/Ton</span>
                    </div>
                  </div>

                  {/* 6. Stone Dust (Optional) */}
                  <div className="p-3 bg-amber-50/80 border border-amber-300 rounded-xl space-y-2 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-amber-950 text-xs flex items-center gap-1">
                        Stone Dust (Optional)
                      </label>
                      <span className="text-[10px] font-mono font-bold text-amber-800 bg-amber-200/70 px-1.5 py-0.5 rounded">
                        {pctDust}%
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 block mb-0.5">Inventory Item:</span>
                      <select
                        value={itemIdDust}
                        onChange={(e) => setItemIdDust(e.target.value)}
                        className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-[11px] font-medium"
                      >
                        <option value="">Select Item...</option>
                        {allCrushedItems.map(i => (
                          <option key={i.id} value={i.id}>{i.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">CFT / Ton:</span>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="0.1"
                            value={cftDust || ''}
                            onChange={(e) => setCftDust(Number(e.target.value))}
                            className="w-full p-1.5 pr-8 border border-amber-300 rounded-lg text-xs font-mono font-bold text-amber-950 bg-white"
                          />
                          <span className="absolute right-2 top-1.5 text-[10px] text-slate-400">CFT</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">Total Dust:</span>
                        <div className="p-1.5 bg-amber-100/70 rounded-lg text-xs font-mono font-bold text-amber-950 border border-amber-200">
                          {qtyCftDust.toLocaleString()} CFT
                        </div>
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono flex justify-between">
                      <span>Rate: {currency} {costPerCftDust}/CFT</span>
                      <span className="text-slate-600 font-sans font-medium">Optional if produced</span>
                    </div>
                  </div>
                </div>

                {/* Additional / Custom Crushed Item Toggle */}
                <div className="pt-1">
                  {!hasExtraItem ? (
                    <button
                      type="button"
                      onClick={() => {
                        setHasExtraItem(true);
                        setExtraItemId(allCrushedItems.find(i => i.sku.includes('25MM'))?.id || allCrushedItems[0]?.id || '');
                      }}
                      className="text-xs text-slate-600 hover:text-slate-900 font-semibold flex items-center gap-1.5 py-1 px-2.5 rounded-lg border border-dashed border-slate-300 hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add Custom Crushed Stone Size (e.g. 1" Down or Custom Size)
                    </button>
                  ) : (
                    <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">Additional Crushed Stone Item</span>
                        <button
                          type="button"
                          onClick={() => {
                            setHasExtraItem(false);
                            setExtraCft(0);
                          }}
                          className="text-rose-600 hover:text-rose-800 text-xs font-semibold cursor-pointer"
                        >
                          ✕ Remove
                        </button>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="sm:col-span-2">
                          <label className="text-[10px] text-slate-500 block mb-0.5">Select Item:</label>
                          <select
                            value={extraItemId}
                            onChange={(e) => setExtraItemId(e.target.value)}
                            className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          >
                            {allCrushedItems.map(i => (
                              <option key={i.id} value={i.id}>{i.name} ({i.sku})</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 block mb-0.5">CFT / Ton:</label>
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={extraCft}
                            onChange={(e) => setExtraCft(Number(e.target.value))}
                            className="w-full p-2 border border-slate-200 rounded-lg text-xs font-mono font-bold"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Operator & Remarks */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Plant Operator / Engineer</label>
                  <input
                    type="text"
                    value={operatorName}
                    onChange={(e) => setOperatorName(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Batch Remarks / Notes</label>
                  <input
                    type="text"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              {/* Live Inventory Posting Summary */}
              <div className="p-3.5 bg-blue-50/80 border border-blue-200 rounded-xl text-blue-950 text-xs space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-blue-900">
                  <PackageCheck className="w-4 h-4 text-blue-700" />
                  Stock & Ledger Posting Summary:
                </div>
                <div className="leading-relaxed">
                  Submitting will deduct <strong>{inputQtyTon} Ton</strong> of raw boulder stone from stock and add <strong>{totalProducedCft.toLocaleString()} CFT</strong> of crushed stone ({qtyCft34.toLocaleString()} CFT 3/4", {qtyCft34Down.toLocaleString()} CFT 3/4" Down, {qtyCft58.toLocaleString()} CFT 5/8", {qtyCft12.toLocaleString()} CFT 1/2", {qtyCft14.toLocaleString()} CFT 1/4" chips & {qtyCftDust.toLocaleString()} CFT dust) in CFT.
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleCloseBatchModal}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!selectedBoulder || inputQtyTon <= 0 || totalProducedCft <= 0}
                  className="px-5 py-2.5 rounded-xl font-bold text-slate-950 shadow-xs transition-all flex items-center gap-2 bg-[#def645] hover:bg-[#d0e835] cursor-pointer disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed"
                >
                  <Check className="w-4 h-4" />
                  Complete Crushing & Post Stock ({totalProducedCft.toLocaleString()} CFT)
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>

      {/* MODAL: View Batch Details */}
      <ModalWrapper
        isOpen={!!selectedBatchDetails}
        onClose={() => setSelectedBatchDetails(null)}
        isDirty={false}
        backdropClassName="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
      >
        {selectedBatchDetails && (
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 space-y-4 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-sm text-slate-900">
                  Batch Details: {selectedBatchDetails.batchNo}
                </h3>
              </div>
              <button 
                type="button"
                onClick={() => setSelectedBatchDetails(null)} 
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-xs space-y-3">
              <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-xl">
                <div>
                  <span className="text-slate-500">Date:</span>
                  <div className="font-mono font-bold text-slate-900">{selectedBatchDetails.date}</div>
                </div>
                <div>
                  <span className="text-slate-500">Crushing Mill / Plant:</span>
                  <div className="font-semibold text-slate-900">{selectedBatchDetails.plantWarehouseName}</div>
                </div>
                <div>
                  <span className="text-slate-500">Input Boulder Stone:</span>
                  <div className="font-semibold text-slate-900">{selectedBatchDetails.inputBoulderItemName}</div>
                </div>
                <div>
                  <span className="text-slate-500">Boulder Quantity (Ton):</span>
                  <div className="font-mono font-bold text-amber-900">
                    {selectedBatchDetails.inputBoulderQtyTon ?? selectedBatchDetails.inputBoulderQtyMt} Ton
                  </div>
                </div>
                <div>
                  <span className="text-slate-500">Total Output (CFT):</span>
                  <div className="font-mono font-bold text-emerald-800">
                    {(selectedBatchDetails.totalOutputQtyCft ?? (selectedBatchDetails.totalOutputQtyMt ? selectedBatchDetails.totalOutputQtyMt * 24 : 0)).toLocaleString()} CFT
                  </div>
                </div>
                <div>
                  <span className="text-slate-500">Crushing Cost:</span>
                  <div className="font-mono font-bold text-slate-900">
                    {currency} {selectedBatchDetails.crushingExpenseBdt.toLocaleString()}
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 mb-2">Crushed Stone Output Breakdown (CFT Allocation):</h4>
                <div className="space-y-1.5">
                  {selectedBatchDetails.outputs.map((out, idx) => {
                    const outCft = out.quantityCft ?? (out.quantityMt ? out.quantityMt * 24 : 0);
                    return (
                      <div key={idx} className="flex justify-between items-center p-2.5 bg-slate-50 rounded-lg border border-slate-100 font-mono text-xs">
                        <div>
                          <strong className="text-slate-900">{out.fractionSize}</strong>
                          <div className="text-[10px] text-slate-500 font-normal">{out.itemName}</div>
                        </div>
                        <div className="text-right">
                          <strong className="text-slate-900 text-sm">{outCft.toLocaleString()} CFT</strong>
                          <span className="text-slate-500 text-[10px] ml-2">({out.percentage}%)</span>
                          {out.cftPerTon ? <div className="text-[10px] text-slate-400">{out.cftPerTon} CFT/Ton</div> : null}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-950 space-y-1">
                <div className="font-bold">Dust & Wastage Ratio:</div>
                <div className="text-xs">
                  {selectedBatchDetails.dustWastagePercent}% ({(selectedBatchDetails.dustWastageQtyCft ?? (selectedBatchDetails.dustWastageQtyMt ? selectedBatchDetails.dustWastageQtyMt * 24 : 0)).toLocaleString()} CFT)
                </div>
                {selectedBatchDetails.remarks && (
                  <div className="text-[10px] text-amber-800 pt-0.5 border-t border-amber-200/50 mt-1">
                    Remarks: {selectedBatchDetails.remarks}
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedBatchDetails(null)}
                className="px-4 py-2 bg-slate-900 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </ModalWrapper>
    </div>
  );
};
