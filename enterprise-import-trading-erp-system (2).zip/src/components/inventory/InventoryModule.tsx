import React, { useState, useEffect } from 'react';
import { 
  Boxes, 
  Warehouse as WarehouseIcon, 
  ArrowDownToLine, 
  ArrowLeftRight, 
  Send, 
  SlidersHorizontal, 
  BookOpen, 
  TrendingUp, 
  Hammer, 
  CheckCircle2, 
  AlertTriangle,
  Scale
} from 'lucide-react';
import { 
  InventoryItem, 
  Warehouse, 
  StockTransfer, 
  StockAdjustment, 
  StockReceivingRecord, 
  SalesDispatchRecord, 
  InventoryLedgerEntry, 
  StoneCrushingConversionBatch,
  InventorySubTab 
} from '../../types/erp';
import { 
  MOCK_ITEMS, 
  MOCK_WAREHOUSES, 
  MOCK_TRANSFERS, 
  MOCK_ADJUSTMENTS, 
  MOCK_STOCK_RECEIVINGS, 
  MOCK_SALES_DISPATCHES, 
  MOCK_INVENTORY_LEDGERS, 
  MOCK_CRUSHING_BATCHES,
  MOCK_CUSTOMERS,
  MOCK_SUPPLIERS
} from '../../data/mockErpData';
import { 
  getItems, 
  saveItems,
  subscribeItems, 
  addItem, 
  updateItem, 
  deleteItem, 
  toggleItemStatus,
  validateStockAvailabilityForLines,
  deductStockForInvoiceLines
} from '../../utils/itemStorage';
import { getSalesInvoices } from '../../utils/salesStorage';
import {
  getWarehouses,
  subscribeWarehouses,
  addWarehouse,
  updateWarehouse,
  deleteWarehouse
} from '../../utils/locationStorage';
import {
  getStockTransfers,
  saveStockTransfers,
  subscribeStockTransfers
} from '../../utils/stockTransferStorage';

import { ItemsTab } from './ItemsTab';
import { LocationsTab } from './LocationsTab';
import { StockTransfersTab } from './StockTransfersTab';
import { StockAdjustmentsTab } from './StockAdjustmentsTab';
import { InventoryLedgersTab } from './InventoryLedgersTab';
import { InventoryMovementReportTab } from './InventoryMovementReportTab';
import { StoneCrushingTab } from './StoneCrushingTab';

export interface InventoryModuleProps {
  initialSubTab?: InventorySubTab;
  currentBranch?: string;
  currency?: string;
  activeSubTab?: InventorySubTab;
  onSubTabChange?: (tab: InventorySubTab) => void;
}

export const InventoryModule: React.FC<InventoryModuleProps> = ({
  initialSubTab = 'items',
  currentBranch = 'All Branches',
  currency = 'BDT',
  activeSubTab,
  onSubTabChange
}) => {
  const [internalTab, setInternalTab] = useState<InventorySubTab>(initialSubTab === ('sales_dispatches' as any) ? 'items' : initialSubTab);
  const rawActiveTab = activeSubTab || internalTab;
  const activeTab: InventorySubTab = rawActiveTab === ('sales_dispatches' as any) ? 'items' : rawActiveTab;

  const handleSelectTab = (tab: InventorySubTab) => {
    const targetTab = tab === ('sales_dispatches' as any) ? 'items' : tab;
    setInternalTab(targetTab);
    if (onSubTabChange) {
      onSubTabChange(targetTab);
    }
  };

  // Core Data States
  const [items, setItems] = useState<InventoryItem[]>(() => getItems());
  const [warehouses, setWarehouses] = useState<Warehouse[]>(() => getWarehouses());
  const [receivings, setReceivings] = useState<StockReceivingRecord[]>(MOCK_STOCK_RECEIVINGS);
  const [transfers, setTransfers] = useState<StockTransfer[]>(() => getStockTransfers());
  const [dispatches, setDispatches] = useState<SalesDispatchRecord[]>(MOCK_SALES_DISPATCHES);
  const [adjustments, setAdjustments] = useState<StockAdjustment[]>(MOCK_ADJUSTMENTS);
  const [ledgers, setLedgers] = useState<InventoryLedgerEntry[]>(MOCK_INVENTORY_LEDGERS);
  const [crushingBatches, setCrushingBatches] = useState<StoneCrushingConversionBatch[]>(MOCK_CRUSHING_BATCHES);

  // Subscribe to live items storage
  useEffect(() => {
    const unsub = subscribeItems(setItems);
    return () => unsub();
  }, []);

  // Subscribe to live warehouses storage
  useEffect(() => {
    const unsub = subscribeWarehouses(setWarehouses);
    return () => unsub();
  }, []);

  // Subscribe to live stock transfers
  useEffect(() => {
    const unsub = subscribeStockTransfers(setTransfers);
    return () => unsub();
  }, []);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // 1. Add New Item
  const handleAddItem = (newItem: InventoryItem) => {
    const updated = addItem(newItem);
    setItems(updated);
    showToast(`✓ New item "${newItem.name}" added to catalog.`);
  };

  // 1.1 Update Item
  const handleUpdateItem = (updatedItem: InventoryItem) => {
    const updated = updateItem(updatedItem);
    setItems(updated);
    showToast(`✓ Item "${updatedItem.name}" updated successfully.`);
  };

  // 1.2 Delete Item
  const handleDeleteItem = (id: string) => {
    const itm = items.find(i => i.id === id);
    const updated = deleteItem(id);
    setItems(updated);
    showToast(`✓ Item "${itm?.name || ''}" removed from catalog.`);
  };

  // 1.3 Toggle Item Status
  const handleToggleItemStatus = (id: string) => {
    const updated = toggleItemStatus(id);
    setItems(updated);
    const itm = updated.find(i => i.id === id);
    showToast(`✓ Item "${itm?.name || ''}" marked as ${itm?.status || 'Active'}.`);
  };

  // 2. Add New Location / Warehouse
  const handleAddWarehouse = (newWh: Warehouse) => {
    const updated = addWarehouse(newWh);
    setWarehouses(updated);
    showToast(`✓ Location "${newWh.name}" added successfully.`);
  };

  // 2.1 Update Location
  const handleUpdateWarehouse = (updatedWh: Warehouse) => {
    const updated = updateWarehouse(updatedWh);
    setWarehouses(updated);
    showToast(`✓ Location "${updatedWh.name}" updated successfully.`);
  };

  // 2.2 Delete Location
  const handleDeleteWarehouse = (id: string) => {
    const wh = warehouses.find(w => w.id === id);
    const updated = deleteWarehouse(id);
    setWarehouses(updated);
    showToast(`✓ Location "${wh?.name || ''}" deleted.`);
  };

  // 3. Add Stock Receiving (GRN)
  const handleAddReceiving = (rec: StockReceivingRecord) => {
    setReceivings(prev => [rec, ...prev]);

    // Update item stock in that warehouse and total stock
    setItems(prev => {
      const next = prev.map(item => {
        if (item.id === rec.itemId) {
          const currentWhStock = item.stockByWarehouse?.[rec.warehouseId] || 0;
          return {
            ...item,
            totalStock: Number((item.totalStock + rec.receivedQty).toFixed(2)),
            stockByWarehouse: {
              ...item.stockByWarehouse,
              [rec.warehouseId]: Number((currentWhStock + rec.receivedQty).toFixed(2))
            }
          };
        }
        return item;
      });
      saveItems(next);
      return next;
    });

    // Post to Inventory Ledger
    const targetItem = items.find(i => i.id === rec.itemId);
    const newLedgerEntry: InventoryLedgerEntry = {
      id: `led-${Date.now()}`,
      date: rec.date,
      time: rec.time,
      itemId: rec.itemId,
      itemName: rec.itemName,
      sku: targetItem?.sku,
      warehouseId: rec.warehouseId,
      warehouseName: rec.warehouseName,
      txnType: 'GRN Receiving',
      refNo: rec.grnNo,
      inQty: rec.receivedQty,
      outQty: 0,
      balanceQty: (targetItem?.totalStock || 0) + rec.receivedQty,
      uom: rec.uom,
      unitRate: rec.unitCostBdt,
      balanceValue: ((targetItem?.totalStock || 0) + rec.receivedQty) * rec.unitCostBdt,
      partyOrVehicle: `${rec.supplierName} / ${rec.vehicleNo}`,
      notes: rec.remarks || 'Stock receiving entered and posted.'
    };
    setLedgers(prev => [newLedgerEntry, ...prev]);

    showToast(`✓ GRN ${rec.grnNo} recorded: +${rec.receivedQty} MT posted to stock.`);
  };

  // 4. Add Stock Transfer
  const handleAddTransfer = (tr: StockTransfer) => {
    setTransfers(prev => {
      const next = [tr, ...prev];
      saveStockTransfers(next);
      return next;
    });

    // Deduct from source warehouse
    setItems(prev => {
      const next = prev.map(item => {
        if (item.id === tr.itemId) {
          const srcStock = item.stockByWarehouse?.[tr.sourceWarehouseId] || 0;
          return {
            ...item,
            stockByWarehouse: {
              ...item.stockByWarehouse,
              [tr.sourceWarehouseId]: Math.max(0, Number((srcStock - tr.quantity).toFixed(2)))
            }
          };
        }
        return item;
      });
      saveItems(next);
      return next;
    });

    // Ledger for Transfer Out
    const targetItem = items.find(i => i.id === tr.itemId);
    const outLedger: InventoryLedgerEntry = {
      id: `led-${Date.now()}-out`,
      date: tr.transferDate,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      itemId: tr.itemId,
      itemName: tr.itemName,
      sku: tr.sku,
      warehouseId: tr.sourceWarehouseId,
      warehouseName: tr.sourceWarehouseName,
      txnType: 'Transfer Out',
      refNo: tr.transferNumber,
      inQty: 0,
      outQty: tr.quantity,
      balanceQty: Math.max(0, (targetItem?.totalStock || 0) - tr.quantity),
      uom: tr.uom,
      unitRate: targetItem?.avgUnitCost || 2450,
      balanceValue: Math.max(0, (targetItem?.totalStock || 0) - tr.quantity) * (targetItem?.avgUnitCost || 2450),
      partyOrVehicle: `➔ In-Transit to ${tr.destWarehouseName} (${tr.trackingVehicle})`,
      notes: 'Dispatched inter-warehouse stock transfer.'
    };
    setLedgers(prev => [outLedger, ...prev]);

    showToast(`✓ Transfer ${tr.transferNumber} issued: ${tr.quantity} ${tr.uom} in-transit to ${tr.destWarehouseName}.`);
  };

  // Reconcile and Receive Stock Transfer
  const handleReceiveTransfer = (transferId: string) => {
    const tr = transfers.find(t => t.id === transferId);
    if (!tr) return;

    setTransfers(prev => {
      const next = prev.map(t => t.id === transferId ? { ...t, status: 'Received & Reconciled' as const } : t);
      saveStockTransfers(next);
      return next;
    });

    // Add to destination warehouse
    setItems(prev => {
      const next = prev.map(item => {
        if (item.id === tr.itemId) {
          const destStock = item.stockByWarehouse?.[tr.destWarehouseId] || 0;
          return {
            ...item,
            stockByWarehouse: {
              ...item.stockByWarehouse,
              [tr.destWarehouseId]: Number((destStock + tr.quantity).toFixed(2))
            }
          };
        }
        return item;
      });
      saveItems(next);
      return next;
    });

    // Ledger for Transfer In
    const targetItem = items.find(i => i.id === tr.itemId);
    const inLedger: InventoryLedgerEntry = {
      id: `led-${Date.now()}-in`,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      itemId: tr.itemId,
      itemName: tr.itemName,
      sku: tr.sku,
      warehouseId: tr.destWarehouseId,
      warehouseName: tr.destWarehouseName,
      txnType: 'Transfer In',
      refNo: tr.transferNumber,
      inQty: tr.quantity,
      outQty: 0,
      balanceQty: targetItem?.totalStock || 0,
      uom: tr.uom,
      unitRate: targetItem?.avgUnitCost || 2450,
      balanceValue: (targetItem?.totalStock || 0) * (targetItem?.avgUnitCost || 2450),
      partyOrVehicle: `From ${tr.sourceWarehouseName}`,
      notes: 'Cargo received & reconciled into destination stock yard.'
    };
    setLedgers(prev => [inLedger, ...prev]);

    showToast(`✓ Transfer ${tr.transferNumber} arrived & reconciled at ${tr.destWarehouseName} (+${tr.quantity} ${tr.uom}).`);
  };

  // 5. Add Sales Dispatch (Single-point deduction rule: if linked to an already-invoiced sale that deducted stock, do not deduct twice)
  const handleAddDispatch = (dsp: SalesDispatchRecord) => {
    const existingInvoices = getSalesInvoices();
    const alreadyDeductedByInvoice = Boolean(
      dsp.invoiceNo && existingInvoices.some(inv => inv.invoiceNumber === dsp.invoiceNo && inv.stockDeducted !== false)
    );

    if (!alreadyDeductedByInvoice) {
      const check = validateStockAvailabilityForLines(
        [{ itemId: dsp.itemId, itemName: dsp.itemName, quantity: dsp.dispatchedQty, uom: dsp.uom }],
        dsp.warehouseId
      );
      if (!check.valid) {
        showToast(`⚠️ ${check.errors[0]}`);
        return;
      }
      const updatedItems = deductStockForInvoiceLines(
        [{ itemId: dsp.itemId, itemName: dsp.itemName, quantity: dsp.dispatchedQty, uom: dsp.uom }],
        dsp.warehouseId
      );
      setItems(updatedItems);
    }

    setDispatches(prev => [dsp, ...prev]);

    // Ledger for Sales Dispatch
    const targetItem = items.find(i => i.id === dsp.itemId);
    const newBal = alreadyDeductedByInvoice
      ? (targetItem?.totalStock || 0)
      : Math.max(0, (targetItem?.totalStock || 0) - dsp.dispatchedQty);
    const dspLedger: InventoryLedgerEntry = {
      id: `led-${Date.now()}`,
      date: dsp.dispatchDate,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      itemId: dsp.itemId,
      itemName: dsp.itemName,
      sku: targetItem?.sku,
      warehouseId: dsp.warehouseId,
      warehouseName: dsp.warehouseName,
      txnType: 'Sales Dispatch',
      refNo: dsp.challanNo,
      inQty: 0,
      outQty: dsp.dispatchedQty,
      balanceQty: newBal,
      uom: dsp.uom,
      unitRate: targetItem?.avgUnitCost || 2600,
      balanceValue: newBal * (targetItem?.avgUnitCost || 2600),
      partyOrVehicle: `${dsp.customerName} / ${dsp.vehicleNo}`,
      notes: `Gate pass issued. Destination: ${dsp.destination} (Truck: ${dsp.measurementCft || 0} CFT)`
    };
    setLedgers(prev => [dspLedger, ...prev]);

    showToast(`✓ Delivery Challan ${dsp.challanNo} issued: -${dsp.dispatchedQty} ${dsp.uom} dispatched.`);
  };

  // 6. Add Stock Adjustment
  const handleAddAdjustment = (adj: StockAdjustment) => {
    setAdjustments(prev => [adj, ...prev]);

    // Update stock (+ or -)
    setItems(prev => prev.map(item => {
      if (item.id === adj.itemId) {
        const currentWhStock = item.stockByWarehouse?.[adj.warehouseId] || 0;
        const newTotal = Math.max(0, Number((item.totalStock + adj.quantity).toFixed(2)));
        const newWhStock = Math.max(0, Number((currentWhStock + adj.quantity).toFixed(2)));
        return {
          ...item,
          totalStock: newTotal,
          stockByWarehouse: {
            ...item.stockByWarehouse,
            [adj.warehouseId]: newWhStock
          }
        };
      }
      return item;
    }));

    // Ledger for Adjustment
    const targetItem = items.find(i => i.id === adj.itemId);
    const newBal = Math.max(0, (targetItem?.totalStock || 0) + adj.quantity);
    const adjLedger: InventoryLedgerEntry = {
      id: `led-${Date.now()}`,
      date: adj.adjustmentDate,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      itemId: adj.itemId,
      itemName: adj.itemName,
      sku: targetItem?.sku,
      warehouseId: adj.warehouseId,
      warehouseName: adj.warehouseName,
      txnType: 'Stock Adjustment',
      refNo: adj.adjustmentNumber,
      inQty: adj.quantity > 0 ? adj.quantity : 0,
      outQty: adj.quantity < 0 ? Math.abs(adj.quantity) : 0,
      balanceQty: newBal,
      uom: targetItem?.uom || 'MT',
      unitRate: adj.unitCost,
      balanceValue: newBal * adj.unitCost,
      partyOrVehicle: `Approval: ${adj.approvedBy}`,
      notes: `${adj.type}: ${adj.reason}`
    };
    setLedgers(prev => [adjLedger, ...prev]);

    showToast(`✓ Stock Adjustment ${adj.adjustmentNumber} saved (${adj.quantity > 0 ? '+' : ''}${adj.quantity} MT).`);
  };

  // 7. Execute Stone Boulder to Crushed Stone Conversion
  const handleExecuteCrushing = (batch: StoneCrushingConversionBatch) => {
    setCrushingBatches(prev => [batch, ...prev]);

    const inputQtyTon = batch.inputBoulderQtyTon ?? batch.inputBoulderQtyMt ?? 0;

    // 1. Deduct raw boulder stone from plant warehouse (in Ton) & 2. Increment each output crushed fraction (in CFT)
    setItems(prev => {
      const next = prev.map(item => {
        if (item.id === batch.inputBoulderItemId) {
          const curWhStock = item.stockByWarehouse?.[batch.plantWarehouseId] || 0;
          return {
            ...item,
            totalStock: Math.max(0, Number((item.totalStock - inputQtyTon).toFixed(2))),
            stockByWarehouse: {
              ...item.stockByWarehouse,
              [batch.plantWarehouseId]: Math.max(0, Number((curWhStock - inputQtyTon).toFixed(2)))
            }
          };
        }

        const matchingOutput = batch.outputs.find(o => o.itemId === item.id);
        if (matchingOutput) {
          const outputQtyCft = matchingOutput.quantityCft ?? matchingOutput.quantityMt ?? 0;
          const curWhStock = item.stockByWarehouse?.[batch.plantWarehouseId] || 0;
          return {
            ...item,
            totalStock: Number((item.totalStock + outputQtyCft).toFixed(2)),
            stockByWarehouse: {
              ...item.stockByWarehouse,
              [batch.plantWarehouseId]: Number((curWhStock + outputQtyCft).toFixed(2))
            }
          };
        }

        return item;
      });
      saveItems(next);
      return next;
    });

    // Post to Ledgers: Boulder Outflow (in Ton) & Produced Fractions Inflows (in CFT)
    const newLedgerEntries: InventoryLedgerEntry[] = [
      {
        id: `led-${Date.now()}-crush-in`,
        date: batch.date,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        itemId: batch.inputBoulderItemId,
        itemName: batch.inputBoulderItemName,
        warehouseId: batch.plantWarehouseId,
        warehouseName: batch.plantWarehouseName,
        txnType: 'Crushing Input',
        refNo: batch.batchNo,
        inQty: 0,
        outQty: inputQtyTon,
        balanceQty: 0,
        uom: 'Ton',
        unitRate: batch.inputUnitCostBdt,
        balanceValue: 0,
        partyOrVehicle: `Batch ${batch.batchNo} feed (${inputQtyTon} Ton)`,
        notes: `Crushed into ${batch.totalOutputQtyCft.toLocaleString()} CFT crushed stone & dust (${batch.dustWastagePercent}% wastage)`
      },
      ...batch.outputs.map((out, idx) => {
        const outQtyCft = out.quantityCft ?? out.quantityMt ?? 0;
        return {
          id: `led-${Date.now()}-out-${idx}`,
          date: batch.date,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          itemId: out.itemId,
          itemName: out.itemName,
          warehouseId: batch.plantWarehouseId,
          warehouseName: batch.plantWarehouseName,
          txnType: 'Crushing Output' as const,
          refNo: batch.batchNo,
          inQty: outQtyCft,
          outQty: 0,
          balanceQty: outQtyCft,
          uom: 'CFT',
          unitRate: out.allocatedUnitCostBdt,
          balanceValue: out.totalValueBdt,
          partyOrVehicle: `Produced from ${inputQtyTon} Ton Boulder (${out.percentage}%)`,
          notes: `Fraction: ${out.fractionSize}${out.cftPerTon ? ` (${out.cftPerTon} CFT/Ton)` : ''}`
        };
      })
    ];

    setLedgers(prev => [...newLedgerEntries, ...prev]);

    showToast(`✓ Crushing Batch ${batch.batchNo} posted: ${inputQtyTon} Ton boulder converted into ${batch.totalOutputQtyCft.toLocaleString()} CFT crushed stone & dust.`);
  };

  // Subtabs navigation items
  const subTabs: {
    id: InventorySubTab;
    label: string;
    bengali: string;
    icon: React.FC<{ className?: string }>;
    count?: number;
  }[] = [
    { id: 'items', label: 'Items Catalog', bengali: '', icon: Boxes, count: items.length },
    { id: 'stone_crushing', label: 'Boulder to Crush Stone', bengali: '', icon: Hammer, count: crushingBatches.length },
    { id: 'locations', label: 'Location & Yards', bengali: '', icon: WarehouseIcon, count: warehouses.length },
    { id: 'stock_transfers', label: 'Stock Transfers', bengali: '', icon: ArrowLeftRight, count: transfers.length },
    { id: 'stock_adjustments', label: 'Stock Adjustments', bengali: '', icon: SlidersHorizontal, count: adjustments.length },
    { id: 'inventory_ledgers', label: 'Inventory Ledgers', bengali: '', icon: BookOpen },
    { id: 'inventory_movement', label: 'Item Inventory Movement', bengali: '', icon: TrendingUp }
  ];

  return (
    <div className="space-y-4">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Module Header Capsule */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">
            Item & Inventory Management
          </h1>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs flex items-center gap-2">
            <WarehouseIcon className="w-4 h-4 text-slate-500" />
            <div className="text-left">
              <div className="text-[10px] text-slate-400 font-medium">Branch Yard</div>
              <div className="font-bold text-slate-800">{currentBranch}</div>
            </div>
          </div>

          <div className="px-3.5 py-2 bg-amber-50 border border-amber-200 rounded-2xl text-xs flex items-center gap-2">
            <Scale className="w-4 h-4 text-amber-700" />
            <div className="text-left">
              <div className="text-[10px] text-amber-700 font-medium">Total On-Hand</div>
              <div className="font-bold text-amber-950 font-mono">
                {items.reduce((acc, i) => acc + i.totalStock, 0).toLocaleString()} MT
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Active Sub-Tab View Rendering (Subcategories selected via Sidebar) */}
      <div className="transition-all duration-150">
        {activeTab === 'items' && (
          <ItemsTab
            items={items}
            warehouses={warehouses}
            onAddItem={handleAddItem}
            onUpdateItem={handleUpdateItem}
            onDeleteItem={handleDeleteItem}
            onToggleItemStatus={handleToggleItemStatus}
            currency={currency}
          />
        )}

        {activeTab === 'locations' && (
          <LocationsTab
            warehouses={warehouses}
            items={items}
            onAddWarehouse={handleAddWarehouse}
            onUpdateWarehouse={handleUpdateWarehouse}
            onDeleteWarehouse={handleDeleteWarehouse}
            currency={currency}
          />
        )}

        {activeTab === 'stock_receivings' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center space-y-3">
            <div className="p-3 bg-blue-50 text-blue-700 rounded-2xl w-fit mx-auto">
              <Boxes className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm">Stock Receiving is Integrated into LC & Purchase Modules</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
              Use <strong>LC Module &gt; LC Product Receiving</strong> for LC imports, or create an invoice in the <strong>Purchase Module</strong> for direct purchases.
            </p>
            <button
              type="button"
              onClick={() => handleSelectTab('items')}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Back to Items Catalog
            </button>
          </div>
        )}

        {activeTab === 'stock_transfers' && (
          <StockTransfersTab
            transfers={transfers}
            items={items}
            warehouses={warehouses}
            onAddTransfer={handleAddTransfer}
            onReceiveTransfer={handleReceiveTransfer}
          />
        )}

        {activeTab === 'stock_adjustments' && (
          <StockAdjustmentsTab
            adjustments={adjustments}
            items={items}
            warehouses={warehouses}
            onAddAdjustment={handleAddAdjustment}
            currency={currency}
          />
        )}

        {activeTab === 'inventory_ledgers' && (
          <InventoryLedgersTab
            ledgers={ledgers}
            items={items}
            warehouses={warehouses}
            currency={currency}
          />
        )}

        {activeTab === 'inventory_movement' && (
          <InventoryMovementReportTab
            ledgers={ledgers}
            items={items}
            warehouses={warehouses}
            currency={currency}
          />
        )}

        {activeTab === 'stone_crushing' && (
          <StoneCrushingTab
            batches={crushingBatches}
            items={items}
            warehouses={warehouses}
            onExecuteCrushing={handleExecuteCrushing}
            currency={currency}
          />
        )}
      </div>
    </div>
  );
};
