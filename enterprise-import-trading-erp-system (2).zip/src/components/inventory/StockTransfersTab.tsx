import React, { useState } from 'react';
import { 
  ArrowLeftRight, 
  Search, 
  Plus, 
  Truck, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Warehouse as WarehouseIcon,
  ArrowRight,
  Scale,
  Printer,
  FileText,
  Boxes,
  HelpCircle
} from 'lucide-react';
import { StockTransfer, InventoryItem, Warehouse } from '../../types/erp';
import { getUOMs } from '../../utils/uomStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface StockTransfersTabProps {
  transfers: StockTransfer[];
  items: InventoryItem[];
  warehouses: Warehouse[];
  onAddTransfer: (transfer: StockTransfer) => void;
  onReceiveTransfer: (transferId: string) => void;
}

export const StockTransfersTab: React.FC<StockTransfersTabProps> = ({
  transfers,
  items,
  warehouses,
  onAddTransfer,
  onReceiveTransfer
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [uomFilter, setUomFilter] = useState<'ALL' | 'CFT' | 'TON'>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedSlipForPrint, setSelectedSlipForPrint] = useState<StockTransfer | null>(null);

  // New transfer form state
  const [selectedItemId, setSelectedItemId] = useState('');
  const [sourceWhId, setSourceWhId] = useState('');
  const [destWhId, setDestWhId] = useState('');
  const [quantity, setQuantity] = useState<number>(0);
  const [vehicleNo, setVehicleNo] = useState('');
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [remarks, setRemarks] = useState('');

  // Detect appropriate default UOM for item
  const detectItemUom = (item?: InventoryItem): string => {
    if (!item) return '';
    if (item.uom) return item.uom;
    const nameLower = (item.name || '').toLowerCase();
    const catLower = (item.category || '').toLowerCase();
    if (nameLower.includes('crush') || nameLower.includes('down') || nameLower.includes('chips') || catLower.includes('crush')) {
      return 'CFT';
    }
    if (nameLower.includes('boulder') || catLower.includes('boulder')) {
      return 'Ton';
    }
    return 'CFT';
  };

  const [selectedUom, setSelectedUom] = useState<string>('');

  const standardUoms = [
    { id: 'CFT', label: 'CFT', hint: 'Crushed Stone / 3/4" Down / Chips' },
    { id: 'Ton', label: 'Ton', hint: 'Raw Boulder Stone' },
    { id: 'MT', label: 'MT (Metric Ton)', hint: 'Steel / Heavy Cargo' },
    { id: 'Bag', label: 'Bag', hint: 'Cement / Packaged Goods' }
  ];

  const resetTransferForm = () => {
    setSelectedItemId('');
    setSourceWhId('');
    setDestWhId('');
    setQuantity(0);
    setVehicleNo('');
    setDriverName('');
    setDriverPhone('');
    setRemarks('');
    setSelectedUom('');
  };

  const handleOpenModal = () => {
    resetTransferForm();
    setShowAddModal(true);
  };

  const handleItemChange = (itemId: string) => {
    setSelectedItemId(itemId);
    const itm = items.find(i => i.id === itemId);
    if (itm) {
      setSelectedUom(detectItemUom(itm));
    } else {
      setSelectedUom('');
    }
  };

  const selectedItemObj = items.find(i => i.id === selectedItemId);
  const currentSourceStock = selectedItemObj?.stockByWarehouse?.[sourceWhId] ?? selectedItemObj?.totalStock ?? 0;

  // Filter transfers
  const filteredTransfers = transfers.filter(tr => {
    const matchesSearch = 
      tr.transferNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tr.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tr.sourceWarehouseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tr.destWarehouseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (tr.trackingVehicle && tr.trackingVehicle.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (!matchesSearch) return false;

    if (uomFilter === 'CFT') {
      return (tr.uom || '').toUpperCase() === 'CFT';
    }
    if (uomFilter === 'TON') {
      const u = (tr.uom || '').toLowerCase();
      return u === 'ton' || u === 'mt';
    }

    return true;
  });

  const isTransferDirty = Boolean(
    selectedItemId || sourceWhId || destWhId || quantity > 0 || vehicleNo.trim() || driverName.trim() || driverPhone.trim() || remarks.trim()
  );

  const handleCloseTransferModal = () => {
    setShowAddModal(false);
    resetTransferForm();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const itm = items.find(i => i.id === selectedItemId);
    const src = warehouses.find(w => w.id === sourceWhId);
    const dst = warehouses.find(w => w.id === destWhId);
    if (!itm || !src || !dst || src.id === dst.id) return;

    const newTransfer: StockTransfer = {
      id: `tr-${Date.now()}`,
      transferNumber: `TR-2026-${String(transfers.length + 105).padStart(4, '0')}`,
      transferDate: new Date().toISOString().split('T')[0],
      sourceWarehouseId: src.id,
      sourceWarehouseName: src.name,
      destWarehouseId: dst.id,
      destWarehouseName: dst.name,
      itemId: itm.id,
      itemName: itm.name,
      sku: itm.sku,
      quantity: Number(quantity),
      uom: selectedUom,
      status: 'In-Transit',
      trackingVehicle: `${vehicleNo.trim()}${driverName ? ` (${driverName.trim()})` : ''}`
    };

    onAddTransfer(newTransfer);
    handleCloseTransferModal();
  };

  // Approximate Stone Weight & Volume conversions
  const isCft = selectedUom.toUpperCase() === 'CFT';
  const isTon = selectedUom.toLowerCase() === 'ton' || selectedUom.toUpperCase() === 'MT';
  const approxTonFromCft = isCft && quantity > 0 ? (quantity / 21.5).toFixed(2) : null;
  const approxCftFromTon = isTon && quantity > 0 ? Math.round(quantity * 21.5) : null;

  return (
    <div className="space-y-4">
      {/* Search, Filter & Actions Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-3 flex-1 flex-wrap">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[220px] max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search transfer no, item, yard, or truck no..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-amber-500 font-sans"
            />
          </div>

          {/* UOM Filter Tabs */}
          <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            <button
              type="button"
              onClick={() => setUomFilter('ALL')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                uomFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All UOMs ({transfers.length})
            </button>
            <button
              type="button"
              onClick={() => setUomFilter('CFT')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                uomFilter === 'CFT' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600 hover:text-blue-700'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              CFT Transfers
            </button>
            <button
              type="button"
              onClick={() => setUomFilter('TON')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                uomFilter === 'TON' ? 'bg-white text-emerald-700 shadow-xs font-bold' : 'text-slate-600 hover:text-emerald-700'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              Ton / MT Transfers
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={handleOpenModal}
          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>New Stock Transfer</span>
        </button>
      </div>

      {/* Transfers Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="p-3 bg-slate-50/70 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-amber-600" />
            <span className="font-bold text-slate-900">Inter-Yard Stock Transfers</span>
            <span className="text-slate-400 font-mono">({filteredTransfers.length} records)</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Transfer No & Date</th>
                <th className="py-3 px-4">Item</th>
                <th className="py-3 px-4">Origin Yard</th>
                <th className="py-3 px-4">Destination Yard</th>
                <th className="py-3 px-4 text-right">Quantity & UOM</th>
                <th className="py-3 px-4">Vehicle & Driver</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredTransfers.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No stock transfer records found.
                  </td>
                </tr>
              ) : (
                filteredTransfers.map((tr) => {
                  const isCftTransfer = (tr.uom || '').toUpperCase() === 'CFT';
                  return (
                    <tr key={tr.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-blue-700">{tr.transferNumber}</span>
                        <div className="text-[10px] text-slate-400 font-mono">{tr.transferDate}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-900">{tr.itemName}</span>
                        <div className="text-[10px] text-slate-400 font-mono">SKU: {tr.sku}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-medium">
                        {tr.sourceWarehouseName}
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-medium">
                        <div className="flex items-center gap-1">
                          <ArrowRight className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{tr.destWarehouseName}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <span className="font-mono font-bold text-slate-900 text-sm">
                            {tr.quantity.toLocaleString()}
                          </span>
                          <span className={`px-2 py-0.5 rounded-md font-mono font-bold text-[10px] ${
                            isCftTransfer 
                              ? 'bg-blue-100 text-blue-800 border border-blue-200' 
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          }`}>
                            {tr.uom}
                          </span>
                        </div>
                        {isCftTransfer && (
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                            ≈ {(tr.quantity / 21.5).toFixed(1)} Ton
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 font-mono text-slate-700">
                          <Truck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{tr.trackingVehicle || 'Port Yard Trailer'}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        {tr.status === 'In-Transit' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                            <Clock className="w-3 h-3" /> In-Transit
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" /> Reconciled
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {tr.status === 'In-Transit' ? (
                            <button
                              type="button"
                              onClick={() => onReceiveTransfer(tr.id)}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-[11px] shadow-xs cursor-pointer transition-colors"
                              title="Receive & reconcile stock at destination yard"
                            >
                              Receive Stock
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-mono">Received</span>
                          )}
                          <button
                            type="button"
                            onClick={() => setSelectedSlipForPrint(tr)}
                            className="p-1 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
                            title="Print Transfer Challan & Gate Pass"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: New Stock Transfer */}
      <ModalWrapper
        isOpen={showAddModal}
        onClose={handleCloseTransferModal}
        isDirty={isTransferDirty}
        backdropClassName="fixed inset-0 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in overflow-hidden h-screen"
      >
        <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-5 border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                <ArrowLeftRight className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  Inter-Warehouse Stock Transfer
                </h3>
              </div>
            </div>
            <button 
              type="button"
              onClick={handleCloseTransferModal} 
              className="text-slate-400 hover:text-slate-600 text-sm font-bold w-7 h-7 rounded-lg hover:bg-slate-100 flex items-center justify-center cursor-pointer"
            >
              ✕
            </button>
          </div>

            <form onSubmit={handleSubmit} autoComplete="off" className="space-y-3.5 text-xs overflow-y-auto pr-1 flex-1 py-3">
              {/* Product Selector */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Product Item *
                </label>
                <select
                  value={selectedItemId}
                  onChange={(e) => handleItemChange(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs font-semibold text-slate-900 cursor-pointer"
                >
                  <option value="">Select Product Item...</option>
                  {items.map(i => (
                    <option key={i.id} value={i.id}>
                      {i.name} — [Total Stock: {i.totalStock} {i.uom || 'CFT'}]
                    </option>
                  ))}
                </select>
                {selectedItemObj && (
                  <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1.5 px-2 py-1 bg-slate-50 rounded-lg border border-slate-200/60 font-mono">
                    <span>Current Stock at Source Yard:</span>
                    <strong className="text-amber-950 font-bold bg-amber-100 px-2 py-0.5 rounded">
                      {currentSourceStock} {selectedItemObj.uom || selectedUom}
                    </strong>
                  </div>
                )}
              </div>

              {/* Source & Destination Warehouses */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Source Yard *</label>
                  <select
                    value={sourceWhId}
                    onChange={(e) => setSourceWhId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs cursor-pointer"
                  >
                    <option value="">Select Source Yard...</option>
                    {warehouses.map(w => (
                      <option key={w.id} value={w.id}>{w.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Destination Yard *</label>
                  <select
                    value={destWhId}
                    onChange={(e) => setDestWhId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs cursor-pointer"
                  >
                    <option value="">Select Destination Yard...</option>
                    {warehouses.map(w => (
                      <option key={w.id} value={w.id} disabled={w.id === sourceWhId}>{w.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* CRITICAL: UOM SELECTOR & QUANTITY INPUT */}
              <div className="p-3.5 bg-amber-50/60 border border-amber-200 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800 flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5 text-amber-700" />
                    <span>Select UOM & Quantity *</span>
                  </label>
                  <span className="text-[10px] text-amber-900 bg-amber-200/80 px-2 py-0.5 rounded font-mono font-semibold">
                    UOM Select Option
                  </span>
                </div>

                {/* UOM Radio Pill Options */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {standardUoms.map((u) => {
                    const isSelected = selectedUom === u.id;
                    return (
                      <button
                        key={u.id}
                        type="button"
                        onClick={() => setSelectedUom(u.id)}
                        className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500 text-slate-950 font-bold border-amber-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-amber-300'
                        }`}
                      >
                        <div className="font-mono text-xs">{u.label}</div>
                        <div className={`text-[9px] truncate ${isSelected ? 'text-slate-900' : 'text-slate-400'}`}>
                          {u.hint}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Quantity Input and Selected UOM display */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-1">
                  <div className="sm:col-span-8">
                    <div className="relative">
                      <input
                        type="number"
                        min="0.1"
                        step="any"
                        required
                        value={quantity || ''}
                        onChange={(e) => setQuantity(Number(e.target.value))}
                        className="w-full pl-3 pr-20 py-2.5 bg-white border border-amber-300 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none text-base font-bold text-slate-900"
                        placeholder="Enter quantity"
                      />
                      <span className="absolute right-3 top-2.5 font-mono font-bold text-xs bg-amber-100 text-amber-900 px-2 py-1 rounded">
                        {selectedUom}
                      </span>
                    </div>
                  </div>

                  {/* Stone Conversion Estimation Capsule */}
                  <div className="sm:col-span-4 bg-white/90 border border-amber-200 rounded-xl p-2 flex flex-col justify-center">
                    <span className="text-[10px] text-slate-500 font-sans block">
                      Estimated Conversion:
                    </span>
                    <div className="font-mono font-bold text-xs text-indigo-700">
                      {isCft && approxTonFromCft && (
                        <span>≈ {approxTonFromCft} Ton</span>
                      )}
                      {isTon && approxCftFromTon && (
                        <span>≈ {approxCftFromTon.toLocaleString()} CFT</span>
                      )}
                      {!isCft && !isTon && (
                        <span>100% {selectedUom}</span>
                      )}
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono mt-0.5">
                      (1 Ton Stone ≈ 21.5 CFT)
                    </span>
                  </div>
                </div>
              </div>

              {/* Transport Vehicle & Driver */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Truck / Vehicle No *</label>
                  <input
                    type="text"
                    required
                    value={vehicleNo}
                    onChange={(e) => setVehicleNo(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none text-xs"
                    placeholder="e.g. Dhaka Metro-Ta 15-8974"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Driver Name</label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs"
                    placeholder="Driver Name"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Driver Phone</label>
                  <input
                    type="text"
                    value={driverPhone}
                    onChange={(e) => setDriverPhone(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none text-xs"
                    placeholder="01712-XXXXXX"
                  />
                </div>
              </div>

              {/* Remarks */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Transfer Remarks / Challan Note</label>
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs"
                  placeholder="e.g. Dispatched for Sonahat crushing feeder stock"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleCloseTransferModal}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <ArrowLeftRight className="w-4 h-4" />
                  <span>Confirm & Dispatch Transfer</span>
                </button>
              </div>
            </form>
          </div>
      </ModalWrapper>

      {/* Modal: Print Transfer Gate Pass Slip */}
      <ModalWrapper
        isOpen={!!selectedSlipForPrint}
        onClose={() => setSelectedSlipForPrint(null)}
        isDirty={false}
        backdropClassName="fixed inset-0 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in overflow-hidden h-screen"
      >
        {selectedSlipForPrint && (
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-slate-200 text-slate-800 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-sm text-slate-900">
                  Inter-Yard Transfer Challan & Gate Pass
                </h3>
              </div>
              <button 
                type="button"
                onClick={() => setSelectedSlipForPrint(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-slate-50/50 font-sans text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-mono block">Challan No</span>
                  <span className="font-mono font-bold text-blue-700 text-sm">{selectedSlipForPrint.transferNumber}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-mono block">Date</span>
                  <span className="font-mono font-semibold">{selectedSlipForPrint.transferDate}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block text-[10px]">Origin Yard:</span>
                  <strong className="text-slate-900">{selectedSlipForPrint.sourceWarehouseName}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Destination Yard:</span>
                  <strong className="text-slate-900">{selectedSlipForPrint.destWarehouseName}</strong>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200">
                <span className="text-slate-400 block text-[10px]">Transferred Item:</span>
                <strong className="text-slate-900 text-sm">{selectedSlipForPrint.itemName}</strong>
                <div className="text-[10px] text-slate-500 font-mono">SKU: {selectedSlipForPrint.sku}</div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex justify-between items-center">
                <div>
                  <span className="text-amber-900 text-[10px] uppercase font-bold block">Total Quantity & UOM:</span>
                  <div className="text-lg font-mono font-black text-slate-900">
                    {selectedSlipForPrint.quantity.toLocaleString()} {selectedSlipForPrint.uom}
                  </div>
                </div>
                <div className="text-right font-mono text-xs text-amber-800">
                  {(selectedSlipForPrint.uom || '').toUpperCase() === 'CFT' 
                    ? `≈ ${(selectedSlipForPrint.quantity / 21.5).toFixed(1)} Ton`
                    : `≈ ${Math.round(selectedSlipForPrint.quantity * 21.5)} CFT`}
                </div>
              </div>

              <div>
                <span className="text-slate-400 block text-[10px]">Vehicle & Driver Details:</span>
                <strong className="text-slate-900 font-mono">{selectedSlipForPrint.trackingVehicle || 'Not Assigned'}</strong>
              </div>

              <div className="pt-6 grid grid-cols-2 gap-4 text-center text-[10px] text-slate-500 font-sans">
                <div className="border-t border-dashed border-slate-300 pt-1">Dispatching Yard In-Charge</div>
                <div className="border-t border-dashed border-slate-300 pt-1">Receiving Yard In-Charge</div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedSlipForPrint(null)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print</span>
              </button>
            </div>
          </div>
        )}
      </ModalWrapper>
    </div>
  );
};
