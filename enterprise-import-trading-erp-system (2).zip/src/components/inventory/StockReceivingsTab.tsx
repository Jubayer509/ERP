import React, { useState } from 'react';
import { 
  ArrowDownToLine, 
  Search, 
  Plus, 
  Truck, 
  Scale, 
  Calendar, 
  CheckCircle2, 
  FileText,
  Building,
  User,
  ExternalLink
} from 'lucide-react';
import { StockReceivingRecord, InventoryItem, Warehouse, Supplier } from '../../types/erp';
import { ModalWrapper } from '../common/ModalWrapper';

interface StockReceivingsTabProps {
  receivings: StockReceivingRecord[];
  items: InventoryItem[];
  warehouses: Warehouse[];
  suppliers: Supplier[];
  onAddReceiving: (receiving: StockReceivingRecord) => void;
  currency?: string;
}

export const StockReceivingsTab: React.FC<StockReceivingsTabProps> = ({
  receivings,
  items,
  warehouses,
  suppliers,
  onAddReceiving,
  currency = 'BDT'
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Receiving form state
  const [supplierId, setSupplierId] = useState('');
  const [lcNumber, setLcNumber] = useState('');
  const [portOrBorder, setPortOrBorder] = useState('');
  const [vehicleNo, setVehicleNo] = useState('');
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [weighbridgeSlipNo, setWeighbridgeSlipNo] = useState('');
  const [grossWeightMt, setGrossWeightMt] = useState(0);
  const [tareWeightMt, setTareWeightMt] = useState(0);
  const [selectedItemId, setSelectedItemId] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState('');
  const [unitCostBdt, setUnitCostBdt] = useState(0);
  const [remarks, setRemarks] = useState('');

  const netWeightMt = Math.max(0, Number((grossWeightMt - tareWeightMt).toFixed(2)));
  const totalCostBdt = Math.round(netWeightMt * unitCostBdt);
  const cftEquivalent = Math.round(netWeightMt * 20.2); // approx 20.2 cft per MT for boulder

  const filteredReceivings = receivings.filter(rec => 
    rec.grnNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rec.vehicleNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rec.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rec.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rec.weighbridgeSlipNo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isFormDirty = Boolean(
    supplierId || lcNumber.trim() || portOrBorder.trim() || vehicleNo.trim() || driverName.trim() || driverPhone.trim() ||
    weighbridgeSlipNo.trim() || grossWeightMt > 0 || tareWeightMt > 0 || selectedItemId || selectedWarehouseId || unitCostBdt > 0 || remarks.trim()
  );

  const resetReceivingForm = () => {
    setSupplierId('');
    setLcNumber('');
    setPortOrBorder('');
    setVehicleNo('');
    setDriverName('');
    setDriverPhone('');
    setWeighbridgeSlipNo('');
    setGrossWeightMt(0);
    setTareWeightMt(0);
    setSelectedItemId('');
    setSelectedWarehouseId('');
    setUnitCostBdt(0);
    setRemarks('');
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    resetReceivingForm();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const itm = items.find(i => i.id === selectedItemId);
    const wh = warehouses.find(w => w.id === selectedWarehouseId);
    const supp = suppliers.find(s => s.id === supplierId);
    if (!itm || !wh) return;

    const newReceiving: StockReceivingRecord = {
      id: `grn-${Date.now()}`,
      grnNo: `GRN-BUR-2026-${String(receivings.length + 85).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      supplierId: supp?.id || 'supp-direct',
      supplierName: supp?.name || 'Border Direct Vendor',
      lcNumber: lcNumber.trim() || undefined,
      portOrBorder,
      vehicleNo: vehicleNo.trim(),
      driverName: driverName.trim(),
      driverPhone: driverPhone.trim(),
      weighbridgeSlipNo: weighbridgeSlipNo.trim(),
      grossWeightMt,
      tareWeightMt,
      netWeightMt,
      itemId: itm.id,
      itemName: itm.name,
      receivedQty: netWeightMt,
      uom: itm.uom,
      cftEquivalent,
      unitCostBdt,
      totalCostBdt,
      warehouseId: wh.id,
      warehouseName: wh.name,
      remarks,
      receivedBy: 'Amir Hamza (Yard In-charge)',
      status: 'Received & Stock Added'
    };

    onAddReceiving(newReceiving);
    handleCloseModal();
  };

  return (
    <div className="space-y-4">
      {/* Search & Action Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search GRN, Truck/Dumper No, Scale Slip, Supplier..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-amber-500 font-sans"
          />
        </div>

        <button
          type="button"
          onClick={() => {
            resetReceivingForm();
            setShowAddModal(true);
          }}
          className="px-3.5 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Record Stock Receiving (GRN)
        </button>
      </div>

      {/* Receivings List */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">GRN & Date</th>
                <th className="py-3 px-4">Supplier / LC</th>
                <th className="py-3 px-4">Item Received</th>
                <th className="py-3 px-4">Vehicle & Scale Slip</th>
                <th className="py-3 px-4 text-right">Net Weight</th>
                <th className="py-3 px-4 text-right">Unit Rate</th>
                <th className="py-3 px-4 text-right">Total Cost</th>
                <th className="py-3 px-4">Receiving Yard</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredReceivings.map((rec) => (
                <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-mono font-bold text-slate-900">{rec.grnNo}</div>
                    <span className="text-[10px] text-slate-400 font-mono">{rec.date} {rec.time}</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{rec.supplierName}</div>
                    {rec.lcNumber && (
                      <span className="text-[10px] text-blue-700 font-mono font-medium">
                        LC: {rec.lcNumber}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-slate-900">{rec.itemName}</span>
                    {rec.cftEquivalent && (
                      <div className="text-[10px] text-slate-500 font-mono">≈ {rec.cftEquivalent} CFT</div>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-mono font-bold text-slate-800 flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-slate-500" />
                      {rec.vehicleNo}
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">Slip: {rec.weighbridgeSlipNo}</span>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {rec.netWeightMt} {rec.uom}
                    <div className="text-[10px] text-slate-400 font-normal">
                      G: {rec.grossWeightMt} / T: {rec.tareWeightMt}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono">
                    {currency} {rec.unitCostBdt.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-amber-900">
                    {currency} {rec.totalCostBdt.toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-medium border border-slate-200">
                      {rec.warehouseName}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3" /> In Stock
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: New Stock Receiving */}
      <ModalWrapper
        isOpen={showAddModal}
        onClose={handleCloseModal}
        isDirty={isFormDirty}
        backdropClassName="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
      >
        <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-5 space-y-4 border border-slate-200 max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <ArrowDownToLine className="w-5 h-5 text-amber-600" />
              <h3 className="font-bold text-sm text-slate-900">Record Stock Receiving / GRN</h3>
            </div>
            <button 
              type="button"
              onClick={handleCloseModal} 
              className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
            >
              ✕
            </button>
          </div>

          <form onSubmit={handleSubmit} autoComplete="off" className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Supplier / Exporter *</label>
                <select
                  value={supplierId}
                  onChange={(e) => setSupplierId(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                >
                  <option value="">Select Supplier / Exporter...</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.country})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Linked Import LC No</label>
                <input
                  type="text"
                  placeholder="e.g. LC-BUR-2026-0048"
                  value={lcNumber}
                  onChange={(e) => setLcNumber(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Product Item *</label>
                <select
                  value={selectedItemId}
                  onChange={(e) => {
                    setSelectedItemId(e.target.value);
                  }}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                >
                  <option value="">Select Product Item...</option>
                  {items.map(i => (
                    <option key={i.id} value={i.id}>{i.name} ({i.sku})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Receiving Yard / Warehouse *</label>
                <select
                  value={selectedWarehouseId}
                  onChange={(e) => setSelectedWarehouseId(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                >
                  <option value="">Select Receiving Yard...</option>
                  {warehouses.map(w => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Weighbridge scale section */}
            <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3">
              <div className="font-bold text-amber-950 flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-amber-700" />
                Weighbridge Scale & Vehicle Data
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Vehicle / Dumper No *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. BP-2-A-9102"
                    value={vehicleNo}
                    onChange={(e) => setVehicleNo(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Driver Name</label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Scale Slip No *</label>
                  <input
                    type="text"
                    required
                    value={weighbridgeSlipNo}
                    onChange={(e) => setWeighbridgeSlipNo(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Gross Wt (MT)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={grossWeightMt || ''}
                    onChange={(e) => setGrossWeightMt(Number(e.target.value))}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Tare Wt (MT)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={tareWeightMt || ''}
                    onChange={(e) => setTareWeightMt(Number(e.target.value))}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Net Weight (MT)</label>
                  <input
                    type="number"
                    disabled
                    value={netWeightMt || ''}
                    className="w-full p-2 bg-amber-100/70 border border-amber-300 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Unit Rate ({currency})</label>
                  <input
                    type="number"
                    value={unitCostBdt || ''}
                    onChange={(e) => setUnitCostBdt(Number(e.target.value))}
                    className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-between items-center pt-1 font-mono text-[11px] text-slate-600">
                <span>CFT Equivalent: <strong>{cftEquivalent} CFT</strong></span>
                <span>Total Cost: <strong className="text-amber-900 text-sm">{currency} {totalCostBdt.toLocaleString()}</strong></span>
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Remarks & Inspection Notes</label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={handleCloseModal}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl shadow-xs cursor-pointer"
              >
                Confirm & Post to Stock
              </button>
            </div>
          </form>
        </div>
      </ModalWrapper>
    </div>
  );
};
