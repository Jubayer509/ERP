import React, { useState, useMemo } from 'react';
import { ModalWrapper } from '../common/ModalWrapper';
import { 
  Warehouse as WarehouseIcon, 
  MapPin, 
  Plus, 
  Building2,
  Phone,
  UserCheck,
  Edit2,
  Trash2,
  Search,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Boxes,
  Factory,
  ShieldCheck,
  Package
} from 'lucide-react';
import { Warehouse, InventoryItem } from '../../types/erp';

export interface LocationsTabProps {
  warehouses: Warehouse[];
  items: InventoryItem[];
  onAddWarehouse: (warehouse: Warehouse) => void;
  onUpdateWarehouse?: (warehouse: Warehouse) => void;
  onDeleteWarehouse?: (id: string) => void;
  currency?: string;
}

export const LocationsTab: React.FC<LocationsTabProps> = ({
  warehouses,
  items,
  onAddWarehouse,
  onUpdateWarehouse,
  onDeleteWarehouse,
  currency = 'BDT'
}) => {
  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | Warehouse['type']>('ALL');

  // Modal States
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingWh, setEditingWh] = useState<Warehouse | null>(null);
  const [deletingWh, setDeletingWh] = useState<Warehouse | null>(null);
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);

  // Form Fields (Add & Edit)
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [type, setType] = useState<Warehouse['type']>('' as any);
  const [managerName, setManagerName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [capacity, setCapacity] = useState('');
  const [status, setStatus] = useState<'Active' | 'Inactive'>('Active');

  const triggerToast = (msg: string) => {
    setFeedbackToast(msg);
    setTimeout(() => setFeedbackToast(null), 3500);
  };

  // Reset form
  const resetForm = () => {
    setCode('');
    setName('');
    setLocation('');
    setType('' as any);
    setManagerName('');
    setContactPhone('');
    setCapacity('');
    setStatus('Active');
  };

  // Open Add Modal
  const handleOpenAdd = () => {
    resetForm();
    setShowAddModal(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (wh: Warehouse) => {
    setEditingWh(wh);
    setCode(wh.code);
    setName(wh.name);
    setLocation(wh.location);
    setType(wh.type);
    setManagerName(wh.managerName || '');
    setContactPhone(wh.contactPhone || '');
    setCapacity(wh.capacity || '');
    setStatus(wh.status || 'Active');
  };

  const handleCloseAddModal = () => {
    setShowAddModal(false);
    resetForm();
  };

  const isAddDirty = Boolean(showAddModal && (code.trim() || name.trim() || location.trim() || managerName.trim() || contactPhone.trim()));

  const handleCloseEditModal = () => {
    setEditingWh(null);
    resetForm();
  };

  const isEditDirty = Boolean(
    editingWh && (
      code !== editingWh.code ||
      name !== editingWh.name ||
      location !== editingWh.location ||
      type !== editingWh.type ||
      managerName !== (editingWh.managerName || '') ||
      contactPhone !== (editingWh.contactPhone || '')
    )
  );

  // Submit Create
  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) return;

    const newWh: Warehouse = {
      id: `wh-${Date.now()}`,
      code: code.trim().toUpperCase(),
      name: name.trim(),
      location: location.trim(),
      type,
      managerName: managerName.trim() || undefined,
      contactPhone: contactPhone.trim() || undefined,
      capacity: capacity.trim() || undefined,
      status
    };

    onAddWarehouse(newWh);
    setShowAddModal(false);
    resetForm();
    triggerToast(`✓ Location "${newWh.name}" added successfully.`);
  };

  // Submit Update
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWh || !name.trim() || !code.trim()) return;

    const updatedWh: Warehouse = {
      ...editingWh,
      code: code.trim().toUpperCase(),
      name: name.trim(),
      location: location.trim(),
      type,
      managerName: managerName.trim() || undefined,
      contactPhone: contactPhone.trim() || undefined,
      capacity: capacity.trim() || undefined,
      status
    };

    if (onUpdateWarehouse) {
      onUpdateWarehouse(updatedWh);
    }
    setEditingWh(null);
    resetForm();
    triggerToast(`✓ Location "${updatedWh.name}" updated successfully.`);
  };

  // Confirm Delete
  const handleConfirmDelete = () => {
    if (!deletingWh) return;
    const whName = deletingWh.name;
    if (onDeleteWarehouse) {
      onDeleteWarehouse(deletingWh.id);
    }
    setDeletingWh(null);
    triggerToast(`✓ Location "${whName}" deleted.`);
  };

  // Filtered Warehouses
  const filteredWarehouses = useMemo(() => {
    return warehouses.filter(wh => {
      const matchSearch = 
        wh.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        wh.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        wh.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (wh.managerName && wh.managerName.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchType = typeFilter === 'ALL' || wh.type === typeFilter;
      return matchSearch && matchType;
    });
  }, [warehouses, searchTerm, typeFilter]);

  // Overall Statistics
  const totalStockAcrossAll = useMemo(() => {
    return items.reduce((acc, it) => acc + (it.totalStock || 0), 0);
  }, [items]);

  const portYardsCount = warehouses.filter(w => w.type === 'Bonded Port Yard').length;
  const plantCount = warehouses.filter(w => w.type === 'Retail Depot' || w.name.includes('Crush') || w.name.includes('Plant')).length;

  return (
    <div className="space-y-4">
      {/* Toast Notification */}
      {feedbackToast && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedbackToast}</span>
        </div>
      )}

      {/* Top Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-2xs flex items-center gap-3">
          <div className="p-2.5 bg-amber-50 text-amber-700 rounded-xl border border-amber-100">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-500 font-semibold">Total Locations / Depots</div>
            <div className="text-lg font-black text-slate-900 font-mono">{warehouses.length}</div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-2xs flex items-center gap-3">
          <div className="p-2.5 bg-blue-50 text-blue-700 rounded-xl border border-blue-100">
            <WarehouseIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-500 font-semibold">Land Port Stock Yards</div>
            <div className="text-lg font-black text-blue-900 font-mono">{portYardsCount}</div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-2xs flex items-center gap-3">
          <div className="p-2.5 bg-purple-50 text-purple-700 rounded-xl border border-purple-100">
            <Factory className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-500 font-semibold">Stone Crushing Mills / Sites</div>
            <div className="text-lg font-black text-purple-900 font-mono">{plantCount}</div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-2xs flex items-center gap-3">
          <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-500 font-semibold">Total On-Hand Stock</div>
            <div className="text-lg font-black text-emerald-900 font-mono">{totalStockAcrossAll.toLocaleString()} MT</div>
          </div>
        </div>
      </div>

      {/* Top Banner, Search & Action Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <WarehouseIcon className="w-4 h-4 text-amber-600" />
              Storage Locations & Port Yards
            </h2>
          </div>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            New Location
          </button>
        </div>

        {/* Search & Type Filter Tabs */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by location name, code, or address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-amber-500 font-sans text-slate-900"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs">
            <button
              type="button"
              onClick={() => setTypeFilter('ALL')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                typeFilter === 'ALL'
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All ({warehouses.length})
            </button>
            <button
              type="button"
              onClick={() => setTypeFilter('Bonded Port Yard')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                typeFilter === 'Bonded Port Yard'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
              }`}
            >
              Port Yards ({warehouses.filter(w => w.type === 'Bonded Port Yard').length})
            </button>
            <button
              type="button"
              onClick={() => setTypeFilter('Retail Depot')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                typeFilter === 'Retail Depot'
                  ? 'bg-purple-600 text-white shadow-2xs'
                  : 'bg-purple-50 text-purple-700 hover:bg-purple-100'
              }`}
            >
              Crushing Plants ({warehouses.filter(w => w.type === 'Retail Depot').length})
            </button>
            <button
              type="button"
              onClick={() => setTypeFilter('Central Warehouse')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                typeFilter === 'Central Warehouse'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
              }`}
            >
              Central Depots ({warehouses.filter(w => w.type === 'Central Warehouse').length})
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Locations */}
      {filteredWarehouses.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-500 space-y-2">
          <WarehouseIcon className="w-10 h-10 text-slate-300 mx-auto" />
          <h4 className="font-bold text-slate-800 text-sm">No locations found</h4>
          <p className="text-xs">No location or yard matches your search criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredWarehouses.map((wh) => {
            // Calculate stock summary for this warehouse
            const whItems = items.filter(it => (it.stockByWarehouse?.[wh.id] || 0) > 0);
            const totalStockInWh = whItems.reduce((acc, it) => acc + (it.stockByWarehouse?.[wh.id] || 0), 0);
            const totalValuation = whItems.reduce((acc, it) => acc + ((it.stockByWarehouse?.[wh.id] || 0) * (it.avgUnitCost || 0)), 0);

            const isCrusher = wh.type === 'Retail Depot' || wh.name.includes('Crush') || wh.name.includes('Plant');

            return (
              <div 
                key={wh.id} 
                className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:border-amber-400 hover:shadow-md transition-all flex flex-col justify-between space-y-4 group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className={`p-2.5 rounded-xl border ${
                      isCrusher 
                        ? 'bg-purple-50 text-purple-700 border-purple-100' 
                        : 'bg-amber-50 text-amber-700 border-amber-100'
                    }`}>
                      {isCrusher ? <Factory className="w-5 h-5" /> : <Building2 className="w-5 h-5" />}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[10px] font-mono font-bold border border-slate-200">
                        {wh.code}
                      </span>
                      {wh.status === 'Inactive' ? (
                        <span className="px-1.5 py-0.5 bg-slate-200 text-slate-600 rounded text-[9px] font-bold">
                          Inactive
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[9px] font-bold">
                          Active
                        </span>
                      )}
                    </div>
                  </div>

                  <h3 className="font-bold text-slate-900 text-sm leading-tight mb-1 group-hover:text-amber-900 transition-colors">
                    {wh.name}
                  </h3>

                  <div className="flex items-start gap-1.5 text-xs text-slate-500 mb-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <span className="line-clamp-2">{wh.location}</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 mb-2">
                    <div className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${
                      wh.type === 'Bonded Port Yard' 
                        ? 'bg-blue-50 text-blue-700 border-blue-200' 
                        : wh.type === 'Central Warehouse'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : isCrusher
                        ? 'bg-purple-50 text-purple-700 border-purple-200'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}>
                      {wh.type === 'Retail Depot' ? 'Crushing Plant' : wh.type}
                    </div>

                    {wh.capacity && (
                      <span className="text-[10px] bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full font-mono">
                        Capacity: {wh.capacity}
                      </span>
                    )}
                  </div>

                  {(wh.managerName || wh.contactPhone) && (
                    <div className="bg-slate-50 border border-slate-100 rounded-xl p-2 text-[11px] text-slate-600 space-y-1">
                      {wh.managerName && (
                        <div className="flex items-center gap-1.5 font-medium">
                          <UserCheck className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>Manager: <strong>{wh.managerName}</strong></span>
                        </div>
                      )}
                      {wh.contactPhone && (
                        <div className="flex items-center gap-1.5 font-mono text-[10px] text-slate-500">
                          <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{wh.contactPhone}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Stock Stats & Action Buttons */}
                <div className="pt-3 border-t border-slate-100 space-y-2.5 text-xs">
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Stocked Items (SKUs):</span>
                      <span className="font-mono font-bold text-slate-900">{whItems.length} Products</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Total Stock Quantity:</span>
                      <span className="font-mono font-bold text-amber-700">{totalStockInWh.toLocaleString()} MT</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Stock Valuation:</span>
                      <span className="font-mono font-bold text-emerald-700">{currency} {totalValuation.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Actions: Edit & Delete Buttons */}
                  <div className="flex items-center justify-end gap-1.5 pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(wh)}
                      className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                      title="Edit Location"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span>Edit</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDeletingWh(wh)}
                      className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                      title="Delete Location"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL 1: Add New Location */}
      {showAddModal && (
        <ModalWrapper
          isOpen={showAddModal}
          onClose={handleCloseAddModal}
          isDirty={isAddDirty}
          maxWidth="max-w-lg"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-slate-200 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                  <WarehouseIcon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Add New Warehouse / Location</h3>
                </div>
              </div>
              <button 
                type="button"
                data-modal-close="true"
                onClick={handleCloseAddModal} 
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreate} autoComplete="off" className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Location Code *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. WH-BUR-YARD-2"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase focus:ring-2 focus:ring-amber-500 outline-none font-bold"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Facility Type *</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-semibold text-slate-800"
                  >
                    <option value="">Select Facility Type...</option>
                    <option value="Bonded Port Yard">Bonded Port Yard</option>
                    <option value="Retail Depot">Crushing Plant / Processing Yard</option>
                    <option value="Central Warehouse">Central Warehouse</option>
                    <option value="Regional Hub">Regional Hub</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Location / Yard Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Burimari Land Port Crushing Plant & Yard"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-medium"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Full Physical Address / Zone *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Land Port Bypass Road, Burimari, Patgram, Lalmonirhat"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Yard Manager / In-Charge</label>
                  <input
                    type="text"
                    placeholder="e.g. Md. Shahidul Islam"
                    value={managerName}
                    onChange={(e) => setManagerName(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Contact Phone No</label>
                  <input
                    type="text"
                    placeholder="e.g. 01712-345678"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Storage Capacity</label>
                  <input
                    type="text"
                    placeholder="e.g. 25,000 MT or 50,000 CFT"
                    value={capacity}
                    onChange={(e) => setCapacity(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Operating Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleCloseAddModal}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl shadow-xs cursor-pointer transition-colors"
                >
                  Save Location
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* MODAL 2: Edit Location */}
      {editingWh && (
        <ModalWrapper
          isOpen={Boolean(editingWh)}
          onClose={handleCloseEditModal}
          isDirty={isEditDirty}
          maxWidth="max-w-lg"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-slate-200 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-800 rounded-xl">
                  <Edit2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Edit Location</h3>
                  <p className="text-[11px] text-slate-500 font-mono">{editingWh.code} — {editingWh.name}</p>
                </div>
              </div>
              <button 
                type="button"
                data-modal-close="true"
                onClick={handleCloseEditModal} 
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleUpdate} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Location Code *</label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase focus:ring-2 focus:ring-blue-500 outline-none font-bold"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Facility Type *</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-semibold text-slate-800"
                  >
                    <option value="Bonded Port Yard">Bonded Port Yard</option>
                    <option value="Retail Depot">Crushing Plant / Processing Yard</option>
                    <option value="Central Warehouse">Central Warehouse</option>
                    <option value="Regional Hub">Regional Hub</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Location / Yard Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-medium"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Full Physical Address / Zone *</label>
                <input
                  type="text"
                  required
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Yard Manager / In-Charge</label>
                  <input
                    type="text"
                    value={managerName}
                    onChange={(e) => setManagerName(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Contact Phone No</label>
                  <input
                    type="text"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Storage Capacity</label>
                  <input
                    type="text"
                    value={capacity}
                    onChange={(e) => setCapacity(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Operating Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-semibold"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleCloseEditModal}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs cursor-pointer transition-colors"
                >
                  Update Location
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* MODAL 3: Delete Confirmation */}
      {deletingWh && (
        <ModalWrapper
          isOpen={Boolean(deletingWh)}
          onClose={() => setDeletingWh(null)}
          isDirty={false}
          maxWidth="max-w-md"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-rose-200">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-3 bg-rose-50 rounded-2xl border border-rose-100">
                <AlertTriangle className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">Delete Location?</h3>
              </div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Location Name:</span>
                <span className="font-bold text-slate-900">{deletingWh.name}</span>
              </div>
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-500 font-mono">Code: {deletingWh.code}</span>
                <span className="text-slate-500">{deletingWh.type}</span>
              </div>
              <div className="text-[11px] text-slate-500">
                Address: {deletingWh.location}
              </div>

              {/* Warning if stock exists */}
              {(() => {
                const whItems = items.filter(it => (it.stockByWarehouse?.[deletingWh.id] || 0) > 0);
                const totalStockInWh = whItems.reduce((acc, it) => acc + (it.stockByWarehouse?.[deletingWh.id] || 0), 0);
                if (totalStockInWh > 0) {
                  return (
                    <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 font-semibold text-[11px] flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                      <span>Warning: This location currently holds <strong>{totalStockInWh.toLocaleString()} MT</strong> in stock!</span>
                    </div>
                  );
                }
                return null;
              })()}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setDeletingWh(null)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs shadow-xs cursor-pointer transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
