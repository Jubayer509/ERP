import React, { useState, useEffect } from 'react';
import { ModalWrapper } from '../common/ModalWrapper';
import { 
  Boxes, 
  Search, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  Filter, 
  Tag, 
  Layers, 
  X, 
  Check, 
  Edit2, 
  Trash2, 
  Power, 
  Settings, 
  Scale, 
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { InventoryItem, Warehouse, ItemCategoryRecord } from '../../types/erp';
import { 
  getItems, 
  saveItems, 
  addItem, 
  updateItem, 
  deleteItem, 
  toggleItemStatus, 
  subscribeItems,
  getCategories,
  saveCategories,
  addCategory,
  updateCategory,
  deleteCategory,
  toggleCategoryStatus,
  subscribeCategories
} from '../../utils/itemStorage';
import { 
  getUOMs, 
  addUOM, 
  deleteUOM, 
  subscribeUOMs 
} from '../../utils/uomStorage';

interface ItemsTabProps {
  items: InventoryItem[];
  warehouses: Warehouse[];
  onAddItem: (item: InventoryItem) => void;
  onUpdateItem?: (item: InventoryItem) => void;
  onDeleteItem?: (id: string) => void;
  onToggleItemStatus?: (id: string) => void;
  currency?: string;
}

export const ItemsTab: React.FC<ItemsTabProps> = ({
  items: propItems,
  warehouses,
  onAddItem,
  onUpdateItem,
  onDeleteItem,
  onToggleItemStatus,
  currency = 'BDT'
}) => {
  // Sync items with reactive storage or props
  const [items, setItems] = useState<InventoryItem[]>(() => {
    const stored = getItems();
    return stored.length > 0 ? stored : propItems;
  });

  // Sync categories with reactive storage
  const [categories, setCategories] = useState<ItemCategoryRecord[]>(() => getCategories());

  // Available UOMs (connected to Sales & Purchase modules)
  const [availableUoms, setAvailableUoms] = useState<string[]>(() => getUOMs());

  // Listeners for cross-component reactive updates
  useEffect(() => {
    const unsubItems = subscribeItems((updated) => setItems(updated));
    const unsubCats = subscribeCategories((updated) => setCategories(updated));
    const unsubUoms = subscribeUOMs((updated) => setAvailableUoms(updated));

    return () => {
      unsubItems();
      unsubCats();
      unsubUoms();
    };
  }, []);

  // Filter & Search states
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [viewMode, setViewMode] = useState<'grouped' | 'table'>('grouped');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [deletingItemId, setDeletingItemId] = useState<string | null>(null);
  const [showCategoryManagerModal, setShowCategoryManagerModal] = useState(false);
  const [showNewUomInline, setShowNewUomInline] = useState(false);
  const [newUomInput, setNewUomInput] = useState('');

  // Quick category inline add
  const [isAddingNewCategoryInline, setIsAddingNewCategoryInline] = useState(false);
  const [newCategoryInputInline, setNewCategoryInputInline] = useState('');

  // Category Edit state inside Category Manager Modal
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [editCategoryName, setEditCategoryName] = useState('');
  const [editCategoryDesc, setEditCategoryDesc] = useState('');
  const [deletingCategory, setDeletingCategory] = useState<ItemCategoryRecord | null>(null);
  const [newCategoryModalName, setNewCategoryModalName] = useState('');
  const [newCategoryModalDesc, setNewCategoryModalDesc] = useState('');

  // Add Item form fields (NO quick presets as requested)
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState('');
  const [uom, setUom] = useState<string>('');
  const [sellingPrice, setSellingPrice] = useState<number | ''>('');
  const [itemStatus, setItemStatus] = useState<'Active' | 'Inactive'>('Active');

  // Edit Item form fields
  const [editName, setEditName] = useState('');
  const [editSku, setEditSku] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editUom, setEditUom] = useState('');
  const [editSellingPrice, setEditSellingPrice] = useState<number | ''>('');
  const [editStatus, setEditStatus] = useState<'Active' | 'Inactive'>('Active');

  // Feedback toast
  const [feedback, setFeedback] = useState<string | null>(null);
  const triggerToast = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3500);
  };

  // Filtered items logic
  const filteredItems = items.filter(item => {
    const itemStatusNormalized = item.status || 'Active';
    const matchesStatus = 
      statusFilter === 'ALL' ||
      (statusFilter === 'ACTIVE' && itemStatusNormalized === 'Active') ||
      (statusFilter === 'INACTIVE' && itemStatusNormalized === 'Inactive');

    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;

    const matchesSearch = 
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesStatus && matchesCategory && matchesSearch;
  });

  // Active categories for select dropdowns
  const activeCategories = categories.filter(c => c.status === 'Active');

  // ================= UOM ADD HANDLER =================
  const handleAddNewUom = (targetForm: 'add' | 'edit') => {
    const trimmed = newUomInput.trim();
    if (!trimmed) return;
    
    // Add to storage (emits event to Sales & Purchase invoices)
    addUOM(trimmed);
    
    // Auto-select in current form
    if (targetForm === 'add') {
      setUom(trimmed);
    } else {
      setEditUom(trimmed);
    }

    setNewUomInput('');
    setShowNewUomInline(false);
    triggerToast(`✓ New UOM "${trimmed}" added and synced with Sales & Purchase invoices.`);
  };

  // ================= ADD ITEM =================
  const resetAddItemForm = () => {
    setName('');
    setSku('');
    setCategory('');
    setUom('');
    setSellingPrice('');
    setItemStatus('Active');
    setShowNewUomInline(false);
    setNewUomInput('');
  };

  const handleOpenAddModal = () => {
    resetAddItemForm();
    setShowAddModal(true);
  };

  const handleCreateItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !sku.trim()) return;

    const newItem: InventoryItem = {
      id: `item-${Date.now()}`,
      sku: sku.trim().toUpperCase(),
      name: name.trim(),
      category: category.trim(),
      uom: uom || 'MT',
      totalStock: 0,
      minStock: 0,
      reorderPoint: 0,
      avgUnitCost: 0,
      sellingPrice: sellingPrice ? Number(sellingPrice) : 0,
      status: itemStatus,
      stockByWarehouse: {}
    };

    const updated = addItem(newItem);
    setItems(updated);
    if (onAddItem) onAddItem(newItem);

    setShowAddModal(false);
    resetAddItemForm();
    triggerToast(`✓ Item "${newItem.name}" added (${newItem.status}).`);
  };

  // ================= EDIT ITEM =================
  const handleOpenEditModal = (item: InventoryItem) => {
    setEditingItem(item);
    setEditName(item.name);
    setEditSku(item.sku);
    setEditCategory(item.category);
    setEditUom(item.uom);
    setEditSellingPrice(item.sellingPrice || '');
    setEditStatus(item.status || 'Active');
    setShowNewUomInline(false);
    setNewUomInput('');
  };

  const handleCloseAddModal = () => {
    setShowAddModal(false);
    resetAddItemForm();
  };

  const isAddDirty = Boolean(showAddModal && (name.trim() !== '' || sku.trim() !== '' || category !== '' || uom !== '' || sellingPrice !== ''));

  const handleCloseEditModal = () => {
    setEditingItem(null);
    setShowNewUomInline(false);
    setNewUomInput('');
  };

  const isEditDirty = Boolean(
    editingItem && (
      editName.trim() !== editingItem.name ||
      editSku.trim() !== editingItem.sku ||
      editCategory !== editingItem.category ||
      editUom !== editingItem.uom ||
      (editSellingPrice === '' ? 0 : Number(editSellingPrice)) !== (editingItem.sellingPrice || 0) ||
      editStatus !== (editingItem.status || 'Active')
    )
  );

  const handleSaveEditItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem || !editName.trim() || !editSku.trim()) return;

    const updated: InventoryItem = {
      ...editingItem,
      name: editName.trim(),
      sku: editSku.trim().toUpperCase(),
      category: editCategory.trim(),
      uom: editUom || 'MT',
      sellingPrice: editSellingPrice ? Number(editSellingPrice) : 0,
      status: editStatus
    };

    const updatedList = updateItem(updated);
    setItems(updatedList);
    if (onUpdateItem) onUpdateItem(updated);

    setEditingItem(null);
    triggerToast(`✓ Item "${updated.name}" updated.`);
  };

  // ================= DELETE ITEM =================
  const handleConfirmDeleteItem = () => {
    if (!deletingItemId) return;
    const itemToDelete = items.find(i => i.id === deletingItemId);
    const updatedList = deleteItem(deletingItemId);
    setItems(updatedList);
    if (onDeleteItem) onDeleteItem(deletingItemId);

    setDeletingItemId(null);
    triggerToast(`✓ Item "${itemToDelete?.name || ''}" deleted.`);
  };

  // ================= TOGGLE ITEM STATUS =================
  const handleToggleItem = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updatedList = toggleItemStatus(id);
    setItems(updatedList);
    if (onToggleItemStatus) onToggleItemStatus(id);

    const itm = updatedList.find(i => i.id === id);
    const isNowActive = itm?.status === 'Active';
    triggerToast(`✓ Item "${itm?.name}" is now ${isNowActive ? 'Active' : 'Inactive'}.`);
  };

  // ================= CATEGORY HANDLERS =================
  const handleCreateCategoryFromModal = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCategoryModalName.trim();
    if (!trimmed) return;

    const updated = addCategory({
      name: trimmed,
      description: newCategoryModalDesc.trim(),
      status: 'Active'
    });
    setCategories(updated);
    setNewCategoryModalName('');
    setNewCategoryModalDesc('');
    triggerToast(`✓ Category "${trimmed}" added.`);
  };

  const handleStartEditCategory = (cat: ItemCategoryRecord) => {
    setEditingCategoryId(cat.id);
    setEditCategoryName(cat.name);
    setEditCategoryDesc(cat.description || '');
  };

  const handleSaveEditCategory = (id: string) => {
    const trimmed = editCategoryName.trim();
    if (!trimmed) return;

    const updated = updateCategory(id, {
      name: trimmed,
      description: editCategoryDesc.trim()
    });
    setCategories(updated);
    // Reload items as category name may have cascaded
    setItems(getItems());
    setEditingCategoryId(null);
    triggerToast(`✓ Category "${trimmed}" updated across all associated items.`);
  };

  const handleToggleCategory = (id: string) => {
    const updated = toggleCategoryStatus(id);
    setCategories(updated);
    const cat = updated.find(c => c.id === id);
    triggerToast(`✓ Category "${cat?.name}" is now ${cat?.status === 'Active' ? 'Active' : 'Inactive'}.`);
  };

  const handleConfirmDeleteCategory = () => {
    if (!deletingCategory) return;
    const catName = deletingCategory.name;
    const updated = deleteCategory(deletingCategory.id, 'Boulder');
    setCategories(updated);
    setItems(getItems());
    setDeletingCategory(null);
    triggerToast(`✓ Category "${catName}" deleted.`);
  };

  // Quick inline add category in header
  const handleAddNewCategoryInline = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = newCategoryInputInline.trim();
    if (!trimmed) return;
    const updated = addCategory({ name: trimmed, status: 'Active' });
    setCategories(updated);
    setSelectedCategory(trimmed);
    setNewCategoryInputInline('');
    setIsAddingNewCategoryInline(false);
    triggerToast(`✓ New category "${trimmed}" added.`);
  };

  // ================= RENDER ITEM TABLE =================
  const renderItemTable = (itemList: InventoryItem[], emptyMsg = 'No items found.') => (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-xs">
        <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
          <tr>
            <th className="py-2.5 px-3">Item SKU / Code</th>
            <th className="py-2.5 px-3">Item Name & Spec</th>
            <th className="py-2.5 px-3">Category</th>
            <th className="py-2.5 px-3 text-center">UOM</th>
            <th className="py-2.5 px-3 text-right">Available Stock</th>
            <th className="py-2.5 px-3 text-right">Selling Price</th>
            <th className="py-2.5 px-3 text-center">Status (Active/Inactive)</th>
            <th className="py-2.5 px-3 text-center">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 text-slate-700">
          {itemList.length === 0 ? (
            <tr>
              <td colSpan={8} className="py-8 text-center text-slate-400">
                <Boxes className="w-8 h-8 text-slate-300 mx-auto mb-2 opacity-50" />
                <span>{emptyMsg}</span>
              </td>
            </tr>
          ) : (
            itemList.map((item) => {
              const isActive = (item.status || 'Active') === 'Active';

              return (
                <tr 
                  key={item.id} 
                  className={`hover:bg-slate-50/80 transition-colors ${
                    !isActive ? 'bg-slate-50/50 opacity-80' : ''
                  }`}
                >
                  {/* SKU */}
                  <td className="py-2.5 px-3">
                    <div className="font-mono font-bold text-slate-900">{item.sku}</div>
                  </td>

                  {/* Name */}
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-1.5">
                      <span className={`font-semibold ${isActive ? 'text-slate-900' : 'text-slate-600 line-through decoration-slate-400'}`}>
                        {item.name}
                      </span>
                      {!isActive && (
                        <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.2 rounded font-medium">
                          Inactive
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Category */}
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded-md text-[11px] font-semibold border ${
                      item.category === 'Boulder' 
                        ? 'bg-amber-50 text-amber-900 border-amber-200' 
                        : item.category === 'Crushed Stone'
                        ? 'bg-blue-50 text-blue-900 border-blue-200'
                        : 'bg-slate-100 text-slate-700 border-slate-200'
                    }`}>
                      {item.category}
                    </span>
                  </td>

                  {/* UOM */}
                  <td className="py-2.5 px-3 text-center">
                    <span className="font-mono font-bold text-slate-700 px-2 py-0.5 bg-slate-100 border border-slate-200 rounded text-[11px]">
                      {item.uom}
                    </span>
                  </td>

                  {/* Stock */}
                  <td className="py-2.5 px-3 text-right">
                    <span className="font-mono font-bold text-slate-900">
                      {(item.totalStock || 0).toLocaleString()}
                    </span>
                    <span className="text-[10px] text-slate-500 ml-1 font-mono">{item.uom}</span>
                  </td>

                  {/* Price */}
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                    {item.sellingPrice && item.sellingPrice > 0 ? (
                      `${currency} ${item.sellingPrice.toLocaleString()}`
                    ) : (
                      <span className="text-slate-400 font-normal">-</span>
                    )}
                  </td>

                  {/* Interactive Status Toggle (Active / Inactive) */}
                  <td className="py-2.5 px-3 text-center">
                    {isActive ? (
                      <button
                        type="button"
                        onClick={(e) => handleToggleItem(item.id, e)}
                        title="Click to deactivate — hides item from invoices"
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold cursor-pointer transition-all border shadow-2xs bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100"
                      >
                        <Power className="w-3 h-3 text-emerald-600" />
                        <span>Active</span>
                      </button>
                    ) : (
                      <div className="flex flex-col items-center gap-1">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-300">
                          <Power className="w-2.5 h-2.5 text-slate-400" />
                          Inactive
                        </span>
                        <button
                          type="button"
                          onClick={(e) => handleToggleItem(item.id, e)}
                          title="Reactivate this item"
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold shadow-xs cursor-pointer transition-all"
                        >
                          <CheckCircle2 className="w-3 h-3 stroke-[2.5]" />
                          <span>Activate</span>
                        </button>
                      </div>
                    )}
                  </td>

                  {/* Actions (Edit & Delete) */}
                  <td className="py-2.5 px-3 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {!isActive && (
                        <button
                          type="button"
                          onClick={(e) => handleToggleItem(item.id, e)}
                          title="Reactivate"
                          className="px-2 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-300 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Active</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(item)}
                        title="Edit Item"
                        className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer border border-blue-200/60"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeletingItemId(item.id)}
                        title="Delete Item"
                        className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer border border-rose-200/60"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );

  // Grouped items by category for grouped view
  const boulderItems = filteredItems.filter(i => i.category === 'Boulder');
  const crushedItems = filteredItems.filter(i => i.category === 'Crushed Stone');
  const otherItems = filteredItems.filter(i => i.category !== 'Boulder' && i.category !== 'Crushed Stone');

  return (
    <div className="space-y-4">
      {/* Toast Notification */}
      {feedback && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* 1. All Categories ALWAYS VISIBLE Quick Bar with Category Management Button */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 flex-1">
          <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mr-1 flex items-center gap-1">
            <Tag className="w-3.5 h-3.5 text-amber-600" />
            Item Category:
          </span>

          {/* All Button */}
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedCategory === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>All Items ({items.length})</span>
          </button>

          {/* Dynamic Categories Chips */}
          {categories.map(cat => {
            const count = items.filter(i => i.category === cat.name).length;
            const isCatSelected = selectedCategory === cat.name;
            const isCatActive = cat.status === 'Active';

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.name)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                  isCatSelected
                    ? 'bg-[#def645] text-slate-950 border-slate-900 shadow-xs ring-1 ring-slate-900/20'
                    : !isCatActive
                    ? 'bg-slate-100 text-slate-400 border-slate-200'
                    : cat.name === 'Boulder'
                    ? 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
                    : cat.name === 'Crushed Stone'
                    ? 'bg-blue-50 text-blue-900 border-blue-200 hover:bg-blue-100'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>{cat.name}</span>
                {!isCatActive && (
                  <span className="text-[9px] bg-slate-300/80 text-slate-700 px-1 py-0.2 rounded font-normal">
                    Inactive
                  </span>
                )}
                <span className={`text-[10px] px-1.5 py-0.2 rounded-md font-mono ${
                  isCatSelected ? 'bg-slate-950 text-white' : 'bg-white text-slate-700 border border-slate-200'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}

          {/* Quick Inline Add Category */}
          {!isAddingNewCategoryInline ? (
            <button
              type="button"
              onClick={() => setIsAddingNewCategoryInline(true)}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Plus className="w-3 h-3 stroke-[2.5]" />
              New Category
            </button>
          ) : (
            <div className="flex items-center gap-1 bg-white border border-blue-400 p-0.5 rounded-xl shadow-xs animate-in fade-in">
              <input
                type="text"
                autoFocus
                placeholder="Category name..."
                value={newCategoryInputInline}
                onChange={(e) => setNewCategoryInputInline(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddNewCategoryInline();
                  }
                }}
                className="px-2 py-0.5 text-xs outline-none font-semibold w-28 text-slate-900"
              />
              <button
                type="button"
                onClick={() => handleAddNewCategoryInline()}
                className="p-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer"
              >
                <Check className="w-3 h-3 stroke-[2.5]" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsAddingNewCategoryInline(false);
                  setNewCategoryInputInline('');
                }}
                className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>

        {/* Right Action: Category Manager Modal Trigger & View Mode */}
        <div className="flex items-center gap-2">
          {/* Category Management Button (Add, Edit, Delete, Active/Inactive) */}
          <button
            type="button"
            onClick={() => setShowCategoryManagerModal(true)}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
          >
            <Settings className="w-3.5 h-3.5 text-amber-600" />
            <span>Category Settings</span>
          </button>

          {/* View Mode Switcher */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 shrink-0">
            <button
              type="button"
              onClick={() => setViewMode('grouped')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                viewMode === 'grouped'
                  ? 'bg-white text-slate-950 shadow-2xs font-black'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3 h-3 text-amber-600" />
              <span>Grouped View</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                viewMode === 'table'
                  ? 'bg-white text-slate-950 shadow-2xs font-black'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Table View</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Search & Action Bar (with Active/Inactive status filter and +New Item button) */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex flex-1 items-center gap-2 w-full max-w-xl">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by item name or SKU code..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-amber-500 font-sans text-slate-900"
            />
          </div>

          {/* Active / Inactive filter selector */}
          <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs shrink-0">
            <button
              type="button"
              onClick={() => setStatusFilter('ALL')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                statusFilter === 'ALL'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({items.length})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('ACTIVE')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                statusFilter === 'ACTIVE'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'text-emerald-700 hover:bg-emerald-50'
              }`}
            >
              Active ({items.filter(i => (i.status || 'Active') === 'Active').length})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('INACTIVE')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                statusFilter === 'INACTIVE'
                  ? 'bg-slate-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              Inactive ({items.filter(i => (i.status || 'Active') === 'Inactive').length})
            </button>
          </div>
        </div>

        {/* Right: + New Item Button */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            type="button"
            onClick={handleOpenAddModal}
            className="px-4 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            New Item
          </button>
        </div>
      </div>

      {/* Inactive Items Policy & One-Click Reactivation Banner */}
      {(statusFilter === 'INACTIVE' || items.some(i => (i.status || 'Active') === 'Inactive')) && (
        <div className={`p-3.5 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs animate-in fade-in ${
          statusFilter === 'INACTIVE' 
            ? 'bg-amber-50/90 border-amber-300 text-amber-950 shadow-xs' 
            : 'bg-slate-50 border-slate-200 text-slate-700'
        }`}>
          <div className="flex items-start sm:items-center gap-2.5">
            <div className="p-1.5 bg-amber-100 text-amber-800 rounded-xl shrink-0 mt-0.5 sm:mt-0">
              <Power className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold">
                Inactive Item Policy:
              </span>{' '}
              <span>
                Inactive items are hidden from Sales and Purchase invoices. Click <b>"Activate"</b> at any time to make them available again.
              </span>
            </div>
          </div>

          {items.some(i => (i.status || 'Active') === 'Inactive') && (
            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              {statusFilter !== 'INACTIVE' && (
                <button
                  type="button"
                  onClick={() => setStatusFilter('INACTIVE')}
                  className="px-2.5 py-1.5 bg-white border border-amber-300 text-amber-900 rounded-xl font-bold text-xs hover:bg-amber-50 cursor-pointer shadow-2xs"
                >
                  View Inactive ({items.filter(i => (i.status || 'Active') === 'Inactive').length})
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  const inactiveItems = items.filter(i => (i.status || 'Active') === 'Inactive');
                  inactiveItems.forEach(i => toggleItemStatus(i.id));
                  setItems(getItems());
                  triggerToast(`✓ All (${inactiveItems.length}) inactive items reactivated!`);
                }}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Activate All ({items.filter(i => (i.status || 'Active') === 'Inactive').length})</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* 3. Items Display: Grouped View OR Unified Table View */}
      {viewMode === 'grouped' && selectedCategory === 'all' ? (
        <div className="space-y-5">
          {/* Section A: Boulder Category */}
          <div className="bg-white border-2 border-amber-200/80 rounded-3xl overflow-hidden shadow-xs">
            <div className="bg-gradient-to-r from-amber-50 to-amber-100/50 p-4 border-b border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500 text-white rounded-xl shadow-xs">
                  <Boxes className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-black text-slate-900 tracking-tight">
                      Boulder Category
                    </h3>
                    <span className="text-[10px] font-bold bg-amber-200 text-amber-950 px-2 py-0.5 rounded-md font-mono">
                      UOM: Ton
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-[10px] text-slate-500 font-medium">Item Count</div>
                  <div className="text-xs font-bold text-slate-800">{boulderItems.length} Variants</div>
                </div>
                <div className="text-right pl-3 border-l border-amber-200">
                  <div className="text-[10px] text-amber-800 font-medium">Total Stock</div>
                  <div className="text-xs font-bold text-amber-950 font-mono">
                    {boulderItems.reduce((acc, i) => acc + (i.totalStock || 0), 0).toLocaleString()} Ton
                  </div>
                </div>
              </div>
            </div>

            {renderItemTable(boulderItems, 'No boulder items found.')}
          </div>

          {/* Section B: Crushed Stone Category */}
          <div className="bg-white border-2 border-blue-200/80 rounded-3xl overflow-hidden shadow-xs">
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50/50 p-4 border-b border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-600 text-white rounded-xl shadow-xs">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-black text-slate-900 tracking-tight">
                      Crushed Stone Category (Aggregates & Dust)
                    </h3>
                    <span className="text-[10px] font-bold bg-blue-200 text-blue-950 px-2 py-0.5 rounded-md font-mono">
                      UOM: CFT
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-[10px] text-slate-500 font-medium">Item Count</div>
                  <div className="text-xs font-bold text-slate-800">{crushedItems.length} Sizes & Grades</div>
                </div>
                <div className="text-right pl-3 border-l border-blue-200">
                  <div className="text-[10px] text-blue-800 font-medium">Total Stock</div>
                  <div className="text-xs font-bold text-blue-950 font-mono">
                    {crushedItems.reduce((acc, i) => acc + (i.totalStock || 0), 0).toLocaleString()} CFT
                  </div>
                </div>
              </div>
            </div>

            {renderItemTable(crushedItems, 'No crushed stone items found.')}
          </div>

          {/* Section C: Other Categories */}
          {otherItems.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xs">
              <div className="bg-slate-50 p-4 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Other Custom Category Items</h3>
                </div>
                <span className="text-xs font-bold text-slate-700">{otherItems.length} Items</span>
              </div>
              {renderItemTable(otherItems)}
            </div>
          )}
        </div>
      ) : (
        /* Single Unified Table View */
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800">
              {selectedCategory === 'all' 
                ? `All Items (${filteredItems.length} Items)` 
                : `${selectedCategory} Category Items (${filteredItems.length} Items)`}
            </span>
            {selectedCategory !== 'all' && (
              <button
                type="button"
                onClick={() => setSelectedCategory('all')}
                className="text-[11px] font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                ← View All Categories
              </button>
            )}
          </div>
          {renderItemTable(filteredItems)}
        </div>
      )}

      {/* ================= MODAL: CREATE NEW ITEM (NO QUICK PRESETS, WITH +NEW UOM) ================= */}
      {showAddModal && (
        <ModalWrapper
          isOpen={showAddModal}
          onClose={handleCloseAddModal}
          isDirty={isAddDirty}
          maxWidth="max-w-xl"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-5 space-y-4 border border-slate-200 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-50 text-amber-700 rounded-xl">
                  <Boxes className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Create New Item</h3>
                </div>
              </div>
              <button 
                type="button"
                data-modal-close="true"
                onClick={handleCloseAddModal} 
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateItemSubmit} autoComplete="off" className="space-y-4 text-xs">
              {/* Category Selector */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Item Category *
                </label>
                <select
                  value={category}
                  onChange={(e) => {
                    setCategory(e.target.value);
                  }}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 outline-none text-xs"
                >
                  <option value="">Select Category...</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.name}>
                      {c.name} {c.status === 'Inactive' ? '(Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Item Name */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Item Name & Specification *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bhutan Boulder Stone or 3/4 Down Stone..."
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (!sku) {
                      const slug = e.target.value
                        .replace(/[^a-zA-Z0-9]/g, '-')
                        .replace(/-+/g, '-')
                        .toUpperCase()
                        .slice(0, 14);
                      if (slug) {
                        setSku(category === 'Boulder' ? `BLD-${slug}` : category === 'Crushed Stone' ? `CRUSH-${slug}` : `ITM-${slug}`);
                      }
                    }
                  }}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-semibold text-slate-900 text-xs"
                />
              </div>

              {/* SKU & UOM Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Item SKU / Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. BLD-BHUTAN"
                    value={sku}
                    onChange={(e) => setSku(e.target.value.toUpperCase())}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase font-bold focus:ring-2 focus:ring-amber-500 outline-none text-xs text-slate-900"
                  />
                </div>

                {/* UOM Section with Dedicated + New UOM Button right above */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-semibold text-slate-700 flex items-center gap-1">
                      <Scale className="w-3.5 h-3.5 text-blue-600" />
                      Unit Of Measure (UOM) *
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowNewUomInline(!showNewUomInline)}
                      className="text-[11px] font-bold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-2 py-0.5 rounded-lg border border-blue-200 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3 h-3 stroke-[2.5]" />
                      + New UOM
                    </button>
                  </div>

                  {/* Inline New UOM input if clicked */}
                  {showNewUomInline && (
                    <div className="mb-2 p-2 bg-blue-50 border border-blue-200 rounded-xl flex items-center gap-1.5 animate-in fade-in">
                      <input
                        type="text"
                        autoFocus
                        placeholder="Enter new UOM (e.g. Bag, Sqft, Trip)..."
                        value={newUomInput}
                        onChange={(e) => setNewUomInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddNewUom('add');
                          }
                        }}
                        className="flex-1 p-1.5 bg-white border border-blue-300 rounded-lg text-xs font-semibold outline-none text-slate-900"
                      />
                      <button
                        type="button"
                        onClick={() => handleAddNewUom('add')}
                        className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs cursor-pointer"
                      >
                        Add
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowNewUomInline(false)}
                        className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  <select
                    value={uom}
                    onChange={(e) => setUom(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-bold text-slate-900 text-xs"
                  >
                    <option value="">Select UOM...</option>
                    {availableUoms.map(u => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Used automatically in Sales and Purchase invoices
                  </span>
                </div>
              </div>

              {/* Selling Price & Status Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Selling Price / Unit Rate ({currency})
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="e.g. 130 or 3800"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-amber-500 outline-none text-xs text-slate-900"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Item Status *
                  </label>
                  <div className="flex items-center gap-2 pt-0.5">
                    <button
                      type="button"
                      onClick={() => setItemStatus('Active')}
                      className={`flex-1 py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                        itemStatus === 'Active'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-2xs'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <Power className="w-3.5 h-3.5 text-emerald-600" />
                      Active
                    </button>
                    <button
                      type="button"
                      onClick={() => setItemStatus('Inactive')}
                      className={`flex-1 py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                        itemStatus === 'Inactive'
                          ? 'bg-slate-800 border-slate-900 text-white shadow-2xs'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <Power className="w-3.5 h-3.5 text-slate-400" />
                      Inactive
                    </button>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleCloseAddModal}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#def645] hover:bg-[#d0e835] text-slate-950 font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  Save Item
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* ================= MODAL: EDIT ITEM ================= */}
      {editingItem && (
        <ModalWrapper
          isOpen={Boolean(editingItem)}
          onClose={handleCloseEditModal}
          isDirty={isEditDirty}
          maxWidth="max-w-xl"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-5 space-y-4 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-50 text-blue-700 rounded-xl">
                  <Edit2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Edit Item</h3>
                </div>
              </div>
              <button 
                type="button"
                data-modal-close="true"
                onClick={handleCloseEditModal} 
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditItem} className="space-y-4 text-xs">
              {/* Category */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Item Category *
                </label>
                <select
                  value={editCategory}
                  onChange={(e) => setEditCategory(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none text-xs"
                >
                  {categories.map(c => (
                    <option key={c.id} value={c.name}>
                      {c.name} {c.status === 'Inactive' ? '(Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Name */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Item Name & Specification *
                </label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-semibold text-slate-900 text-xs"
                />
              </div>

              {/* SKU & UOM */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Item SKU / Code *
                  </label>
                  <input
                    type="text"
                    required
                    value={editSku}
                    onChange={(e) => setEditSku(e.target.value.toUpperCase())}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase font-bold focus:ring-2 focus:ring-blue-500 outline-none text-xs text-slate-900"
                  />
                </div>

                {/* UOM with +New UOM button right above */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-semibold text-slate-700 flex items-center gap-1">
                      <Scale className="w-3.5 h-3.5 text-blue-600" />
                      Unit Of Measure (UOM) *
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowNewUomInline(!showNewUomInline)}
                      className="text-[11px] font-bold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-2 py-0.5 rounded-lg border border-blue-200 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3 h-3 stroke-[2.5]" />
                      + New UOM
                    </button>
                  </div>

                  {/* Inline New UOM input */}
                  {showNewUomInline && (
                    <div className="mb-2 p-2 bg-blue-50 border border-blue-200 rounded-xl flex items-center gap-1.5 animate-in fade-in">
                      <input
                        type="text"
                        autoFocus
                        placeholder="Enter new UOM..."
                        value={newUomInput}
                        onChange={(e) => setNewUomInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddNewUom('edit');
                          }
                        }}
                        className="flex-1 p-1.5 bg-white border border-blue-300 rounded-lg text-xs font-semibold outline-none text-slate-900"
                      />
                      <button
                        type="button"
                        onClick={() => handleAddNewUom('edit')}
                        className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs cursor-pointer"
                      >
                        Add
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowNewUomInline(false)}
                        className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  <select
                    value={editUom}
                    onChange={(e) => setEditUom(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-slate-900 text-xs"
                  >
                    {availableUoms.map(u => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Selling Price & Status */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Selling Price / Unit Rate ({currency})
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={editSellingPrice}
                    onChange={(e) => setEditSellingPrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-blue-500 outline-none text-xs text-slate-900"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Item Status *
                  </label>
                  <div className="flex items-center gap-2 pt-0.5">
                    <button
                      type="button"
                      onClick={() => setEditStatus('Active')}
                      className={`flex-1 py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                        editStatus === 'Active'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-2xs'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <Power className="w-3.5 h-3.5 text-emerald-600" />
                      Active
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditStatus('Inactive')}
                      className={`flex-1 py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                        editStatus === 'Inactive'
                          ? 'bg-slate-800 border-slate-900 text-white shadow-2xs'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <Power className="w-3.5 h-3.5 text-slate-400" />
                      Inactive
                    </button>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleCloseEditModal}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* ================= MODAL: DELETE ITEM CONFIRMATION ================= */}
      {deletingItemId && (
        <ModalWrapper
          isOpen={Boolean(deletingItemId)}
          onClose={() => setDeletingItemId(null)}
          isDirty={false}
          maxWidth="max-w-md"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-5 space-y-4 border border-slate-200">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2.5 bg-rose-50 rounded-xl border border-rose-100">
                <AlertTriangle className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Delete Item Confirmation</h3>
                <p className="text-[11px] text-slate-500">This item will be permanently removed from the catalog.</p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="text-xs font-bold text-slate-900">
                {items.find(i => i.id === deletingItemId)?.name}
              </div>
              <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                SKU: {items.find(i => i.id === deletingItemId)?.sku} • UOM: {items.find(i => i.id === deletingItemId)?.uom}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setDeletingItemId(null)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteItem}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* ================= MODAL: CATEGORY MANAGEMENT (ADD, EDIT, DELETE, ACTIVE/INACTIVE) ================= */}
      {showCategoryManagerModal && (
        <ModalWrapper
          isOpen={showCategoryManagerModal}
          onClose={() => {
            setShowCategoryManagerModal(false);
            setEditingCategoryId(null);
          }}
          isDirty={Boolean(newCategoryModalName.trim() || newCategoryModalDesc.trim())}
          maxWidth="max-w-2xl"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-6 space-y-5 border border-slate-200 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-100 text-amber-900 rounded-xl">
                  <Tag className="w-5 h-5 text-amber-700" />
                </div>
                <div>
                  <h3 className="font-black text-base text-slate-900">
                    Category Management
                  </h3>
                </div>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={() => {
                  setShowCategoryManagerModal(false);
                  setEditingCategoryId(null);
                }}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Create New Category Card */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <Plus className="w-4 h-4 text-blue-600 stroke-[2.5]" />
                Add Category
              </div>
              <form onSubmit={handleCreateCategoryFromModal} autoComplete="off" className="grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs">
                <div className="sm:col-span-5">
                  <input
                    type="text"
                    required
                    placeholder="Category name (e.g. Cement, Sand)..."
                    value={newCategoryModalName}
                    onChange={(e) => setNewCategoryModalName(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-semibold text-slate-900"
                  />
                </div>
                <div className="sm:col-span-5">
                  <input
                    type="text"
                    placeholder="Description / notes (optional)..."
                    value={newCategoryModalDesc}
                    onChange={(e) => setNewCategoryModalDesc(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-slate-700"
                  />
                </div>
                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs cursor-pointer flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add
                  </button>
                </div>
              </form>
            </div>

            {/* Categories List Table */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                <span>Existing Categories ({categories.length})</span>
                <span className="text-[11px] text-slate-400 font-normal">Editing updates associated items automatically</span>
              </div>

              <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 bg-white">
                {categories.map((cat) => {
                  const itemCount = items.filter(i => i.category === cat.name).length;
                  const isCatActive = cat.status === 'Active';
                  const isEditingThis = editingCategoryId === cat.id;

                  return (
                    <div key={cat.id} className="p-3.5 hover:bg-slate-50/70 transition-colors">
                      {isEditingThis ? (
                        /* Editing Mode */
                        <div className="space-y-2 bg-blue-50/50 p-3 rounded-xl border border-blue-200">
                          <div className="text-xs font-bold text-blue-900 flex items-center gap-1">
                            <Edit2 className="w-3.5 h-3.5 text-blue-600" />
                            Edit Category:
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                            <input
                              type="text"
                              required
                              value={editCategoryName}
                              onChange={(e) => setEditCategoryName(e.target.value)}
                              placeholder="Category name"
                              className="p-2 bg-white border border-blue-300 rounded-xl font-bold text-slate-900 outline-none"
                            />
                            <input
                              type="text"
                              value={editCategoryDesc}
                              onChange={(e) => setEditCategoryDesc(e.target.value)}
                              placeholder="Description"
                              className="p-2 bg-white border border-blue-300 rounded-xl text-slate-800 outline-none"
                            />
                          </div>
                          <div className="flex justify-end gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => setEditingCategoryId(null)}
                              className="px-3 py-1 bg-white border border-slate-300 text-slate-600 rounded-lg text-xs font-medium cursor-pointer"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveEditCategory(cat.id)}
                              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold cursor-pointer flex items-center gap-1"
                            >
                              <Check className="w-3.5 h-3.5" /> Save
                            </button>
                          </div>
                        </div>
                      ) : (
                        /* Normal Display Mode */
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <span className={`font-bold text-sm ${isCatActive ? 'text-slate-900' : 'text-slate-500 line-through'}`}>
                                {cat.name}
                              </span>
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-100 text-slate-700 border border-slate-200">
                                {itemCount} Items
                              </span>
                              {cat.isDefault && (
                                <span className="text-[10px] bg-amber-50 text-amber-800 border border-amber-200 px-1.5 py-0.2 rounded font-semibold">
                                  Default
                                </span>
                              )}
                            </div>
                            {cat.description && (
                              <p className="text-[11px] text-slate-500">{cat.description}</p>
                            )}
                          </div>

                          {/* Action Buttons for Category: Status Toggle, Edit, Delete */}
                          <div className="flex items-center gap-2 self-start sm:self-center">
                            {/* Active / Inactive Toggle Button */}
                            <button
                              type="button"
                              onClick={() => handleToggleCategory(cat.id)}
                              title={`Click to set ${isCatActive ? 'Inactive' : 'Active'}`}
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 border cursor-pointer transition-all ${
                                isCatActive
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                                  : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                              }`}
                            >
                              <Power className={`w-3 h-3 ${isCatActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                              <span>{isCatActive ? 'Active' : 'Inactive'}</span>
                            </button>

                            {/* Edit Button */}
                            <button
                              type="button"
                              onClick={() => handleStartEditCategory(cat)}
                              title="Edit Category"
                              className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                            >
                              <Edit2 className="w-3 h-3" />
                              <span>Edit</span>
                            </button>

                            {/* Delete Button */}
                            <button
                              type="button"
                              onClick={() => setDeletingCategory(cat)}
                              title="Delete Category"
                              className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg border border-transparent hover:border-rose-200 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Footer */}
            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => {
                  setShowCategoryManagerModal(false);
                  setEditingCategoryId(null);
                }}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* ================= MODAL: DELETE CATEGORY CONFIRMATION ================= */}
      {deletingCategory && (
        <ModalWrapper
          isOpen={Boolean(deletingCategory)}
          onClose={() => setDeletingCategory(null)}
          isDirty={false}
          maxWidth="max-w-md"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-5 space-y-4 border border-slate-200">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2.5 bg-rose-50 rounded-xl border border-rose-100">
                <AlertTriangle className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Delete Category Confirmation</h3>
                <p className="text-[11px] text-slate-500">Are you sure you want to delete this category?</p>
              </div>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
              <div className="font-bold">Category: {deletingCategory.name}</div>
              <p className="text-[11px]">
                All items in this category will be reassigned to "Boulder" automatically so no data is lost.
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setDeletingCategory(null)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteCategory}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete Category
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
