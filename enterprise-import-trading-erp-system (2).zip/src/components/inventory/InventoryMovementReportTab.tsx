import React, { useState } from 'react';
import { 
  ArrowLeftRight, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  Calendar, 
  ArrowDownLeft, 
  ArrowUpRight, 
  TrendingUp, 
  CheckCircle2, 
  Layers,
  Scale
} from 'lucide-react';
import { InventoryLedgerEntry, InventoryItem, Warehouse } from '../../types/erp';

interface InventoryMovementReportTabProps {
  ledgers: InventoryLedgerEntry[];
  items: InventoryItem[];
  warehouses: Warehouse[];
  currency?: string;
}

export const InventoryMovementReportTab: React.FC<InventoryMovementReportTabProps> = ({
  ledgers,
  items,
  warehouses,
  currency = 'BDT'
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedItemId, setSelectedItemId] = useState('all');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState('all');
  const [directionFilter, setDirectionFilter] = useState<'all' | 'in' | 'out'>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filteredMovements = ledgers.filter(entry => {
    // Search
    const matchesSearch = 
      entry.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.refNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (entry.partyOrVehicle && entry.partyOrVehicle.toLowerCase().includes(searchTerm.toLowerCase())) ||
      entry.warehouseName.toLowerCase().includes(searchTerm.toLowerCase());

    // Item
    const matchesItem = selectedItemId === 'all' || entry.itemId === selectedItemId;

    // Warehouse
    const matchesWh = selectedWarehouseId === 'all' || entry.warehouseId === selectedWarehouseId;

    // Direction (In vs Out)
    const matchesDirection = 
      directionFilter === 'all' ||
      (directionFilter === 'in' && entry.inQty > 0) ||
      (directionFilter === 'out' && entry.outQty > 0);

    // Date
    let matchesDate = true;
    if (dateFilter === 'today') {
      matchesDate = entry.date === new Date().toISOString().split('T')[0];
    } else if (dateFilter === 'week') {
      // past 7 days
      const d = new Date(entry.date);
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - d.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      matchesDate = diffDays <= 7;
    } else if (dateFilter === 'month') {
      matchesDate = entry.date.startsWith('2026-09');
    }

    if (startDate && entry.date < startDate) matchesDate = false;
    if (endDate && entry.date > endDate) matchesDate = false;

    return matchesSearch && matchesItem && matchesWh && matchesDirection && matchesDate;
  });

  const totalInQty = filteredMovements.reduce((acc, m) => acc + m.inQty, 0);
  const totalOutQty = filteredMovements.reduce((acc, m) => acc + m.outQty, 0);
  const netMovement = totalInQty - totalOutQty;

  const exportMovementCsv = () => {
    const headers = ['Date', 'Ref No', 'Item Name', 'Yard / Warehouse', 'Movement Type', 'Direction', 'Quantity (MT)', 'Rate (BDT)', 'Party / Vehicle', 'Remarks'];
    const rows = filteredMovements.map(m => [
      `"${m.date} ${m.time || ''}"`,
      `"${m.refNo}"`,
      `"${m.itemName}"`,
      `"${m.warehouseName}"`,
      `"${m.txnType}"`,
      m.inQty > 0 ? 'IN' : 'OUT',
      m.inQty > 0 ? m.inQty : m.outQty,
      m.unitRate,
      `"${m.partyOrVehicle || ''}"`,
      `"${m.notes || ''}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Item_Movement_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      {/* Title & Stats */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-amber-600" />
            Item Inventory Movement Report
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportMovementCsv}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
          <button
            onClick={() => window.print()}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Report
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span>Total Inflow</span>
            <span className="p-1 rounded bg-emerald-50 text-emerald-700">
              <ArrowDownLeft className="w-4 h-4" />
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-emerald-700">
            +{totalInQty.toLocaleString()} MT
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Purchases, Transfers-In, Crushing Output</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span>Total Outflow</span>
            <span className="p-1 rounded bg-rose-50 text-rose-700">
              <ArrowUpRight className="w-4 h-4" />
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-rose-700">
            -{totalOutQty.toLocaleString()} MT
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Sales Dispatches, Crusher Feed, Transfers-Out</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span>Net Balance Shift</span>
            <span className="p-1 rounded bg-blue-50 text-blue-700">
              <Scale className="w-4 h-4" />
            </span>
          </div>
          <div className={`text-xl font-bold font-mono ${netMovement >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {netMovement >= 0 ? `+${netMovement.toLocaleString()}` : netMovement.toLocaleString()} MT
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Net Stock delta in filtered period</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span>Movement Events</span>
            <span className="p-1 rounded bg-amber-50 text-amber-700">
              <Layers className="w-4 h-4" />
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-900">
            {filteredMovements.length} Records
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Matched under active filter criteria</div>
        </div>
      </div>

      {/* Multi-Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          {/* Instant Search */}
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search ref, item, vehicle..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Movement Direction Filter */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setDirectionFilter('all')}
              className={`px-3 py-1 rounded-lg transition-colors ${
                directionFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setDirectionFilter('in')}
              className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1 ${
                directionFilter === 'in' ? 'bg-emerald-600 text-white shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              <ArrowDownLeft className="w-3.5 h-3.5" />
              Inflow Only
            </button>
            <button
              onClick={() => setDirectionFilter('out')}
              className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1 ${
                directionFilter === 'out' ? 'bg-rose-600 text-white shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              Outflow Only
            </button>
          </div>

          {/* Item Filter */}
          <select
            value={selectedItemId}
            onChange={(e) => setSelectedItemId(e.target.value)}
            className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none font-medium text-slate-700 max-w-[200px]"
          >
            <option value="all">All Items</option>
            {items.map(it => (
              <option key={it.id} value={it.id}>{it.name}</option>
            ))}
          </select>

          {/* Yard / Location Filter */}
          <select
            value={selectedWarehouseId}
            onChange={(e) => setSelectedWarehouseId(e.target.value)}
            className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none font-medium text-slate-700 max-w-[180px]"
          >
            <option value="all">All Yards / Locations</option>
            {warehouses.map(w => (
              <option key={w.id} value={w.id}>{w.name}</option>
            ))}
          </select>

          {/* Quick Date Presets */}
          <div className="flex items-center gap-1 text-xs">
            {(['all', 'today', 'week', 'month'] as const).map(preset => (
              <button
                key={preset}
                onClick={() => setDateFilter(preset)}
                className={`px-2.5 py-1 rounded-lg font-medium capitalize ${
                  dateFilter === preset ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {preset === 'all' ? 'All Time' : preset}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Date Range */}
        <div className="flex items-center gap-2 text-xs pt-1 border-t border-slate-100 text-slate-600">
          <Calendar className="w-3.5 h-3.5 text-slate-400" />
          <span>Custom Range:</span>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="p-1 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
          <span>to</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="p-1 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
          {(startDate || endDate) && (
            <button
              onClick={() => { setStartDate(''); setEndDate(''); }}
              className="text-[11px] text-rose-600 hover:underline font-semibold ml-2"
            >
              Clear Range
            </button>
          )}
        </div>
      </div>

      {/* Movement Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Reference No</th>
                <th className="py-3 px-4">Item Name</th>
                <th className="py-3 px-4">Yard Location</th>
                <th className="py-3 px-4">Movement Action</th>
                <th className="py-3 px-4 text-center">Direction</th>
                <th className="py-3 px-4 text-right">Movement Qty</th>
                <th className="py-3 px-4 text-right">Stock After Txn</th>
                <th className="py-3 px-4">Party / Vehicle / Particulars</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredMovements.map((m) => {
                const isIn = m.inQty > 0;

                return (
                  <tr key={m.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono whitespace-nowrap">
                      {m.date}
                      <span className="text-[10px] text-slate-400 block">{m.time || ''}</span>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-blue-700 whitespace-nowrap">
                      {m.refNo}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-900">{m.itemName}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium">
                      {m.warehouseName}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 text-[10px] font-semibold">
                        {m.txnType}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      {isIn ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          <ArrowDownLeft className="w-3 h-3" /> IN
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                          <ArrowUpRight className="w-3 h-3" /> OUT
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold">
                      <span className={isIn ? 'text-emerald-700' : 'text-rose-700'}>
                        {isIn ? `+${m.inQty.toLocaleString()}` : `-${m.outQty.toLocaleString()}`} {m.uom}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      {m.balanceQty.toLocaleString()} {m.uom}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800">{m.partyOrVehicle || '-'}</div>
                      {m.notes && <div className="text-[10px] text-slate-400">{m.notes}</div>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
