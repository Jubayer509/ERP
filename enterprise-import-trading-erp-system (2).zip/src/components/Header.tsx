import React, { useState, useRef, useEffect } from 'react';
import { 
  Building2, 
  Bell, 
  Search, 
  Moon,
  ChevronDown, 
  LogOut, 
  Sparkles, 
  ArrowRight, 
  Lock,
  AlertTriangle,
  CheckCircle2,
  X,
  Trash2,
  RotateCcw,
  Calendar,
  Menu
} from 'lucide-react';
import { ModuleTab, FiscalYear } from '../types/erp';
import { useAuth } from '../contexts/AuthContext';
import { ROLE_LABELS } from '../data/mockUsers';
import { RecycleBinModal } from './common/RecycleBinModal';
import { getDeletedRecords, subscribeRecycleBin } from '../utils/recycleBinStorage';
import { 
  getActiveFiscalYear, 
  getFiscalYears, 
  subscribeFiscalYears, 
  setActiveFiscalYear, 
  formatFiscalYearDisplay 
} from '../utils/fiscalYearStorage';
import { getCompanyProfile, subscribeCompanyProfile } from '../utils/systemSettingsStorage';

interface HeaderProps {
  currentTab: ModuleTab;
  onSelectTab: (tab: ModuleTab) => void;
  branch: string;
  setBranch: (branch: string) => void;
  currency: string;
  setCurrency: (curr: string) => void;
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  branch,
  setBranch,
  currency,
  setCurrency,
  onToggleMobileMenu
}) => {
  const { currentUser, logout } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isRecycleBinOpen, setIsRecycleBinOpen] = useState(false);
  const [trashCount, setTrashCount] = useState<number>(() => getDeletedRecords().length);
  const [activeFY, setActiveFY] = useState<FiscalYear>(() => getActiveFiscalYear());
  const [fiscalYears, setFiscalYears] = useState<FiscalYear[]>(() => getFiscalYears());
  const [showFyMenu, setShowFyMenu] = useState(false);
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  const userMenuRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const fyMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsub = subscribeRecycleBin(() => {
      setTrashCount(getDeletedRecords().length);
    });
    const unsubComp = subscribeCompanyProfile(setCompanyProfile);
    return () => {
      unsub();
      unsubComp();
    };
  }, []);

  useEffect(() => {
    const unsub = subscribeFiscalYears((updated) => {
      setFiscalYears(updated);
      setActiveFY(getActiveFiscalYear());
    });
    return unsub;
  }, []);

  // Close menus on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotifications(false);
      }
      if (fyMenuRef.current && !fyMenuRef.current.contains(e.target as Node)) {
        setShowFyMenu(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const notifications = [
    { id: 1, title: 'LC Expiry Alert (Action Required)', desc: 'Shipment expiry for LC-2026-CH-0042 ($195k) due in 3 days.', time: 'Just now', urgent: true, tab: 'purchase' as ModuleTab },
    { id: 2, title: 'SO Approval Required', desc: 'SO-2026-0821 (BDT 3.3M) exceeds credit limit for Pioneer Const.', time: '10m ago', urgent: true, tab: 'sales' as ModuleTab },
    { id: 3, title: 'Cheque Maturity in 48h', desc: 'CHQ-882194 (BDT 2.0M) from Rahman Steel matures tomorrow', time: '1h ago', urgent: false, tab: 'accounts' as ModuleTab },
    { id: 4, title: 'Truck Release Challan', desc: 'Dhaka Metro-Ta 11-5678 weighed & cleared at Burimari Gate', time: '2h ago', urgent: false, tab: 'truck_report' as ModuleTab }
  ];

  // User display name (e.g. "Josiah" as in the image or current user)
  const greetingName = currentUser?.displayName ? currentUser.displayName.split(' ')[0] : 'Josiah';

  return (
    <header className="w-full pt-3 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4 select-none">
      {/* Left: Starline Brand & Welcome Greeting */}
      <div className="flex items-center gap-3 sm:gap-4">
        {onToggleMobileMenu && (
          <button
            type="button"
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 rounded-xl bg-white border border-slate-200 text-slate-800 hover:bg-slate-100 shadow-xs cursor-pointer"
            title="Toggle Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        <div 
          onClick={() => onSelectTab('dashboard')}
          className="flex items-center gap-2.5 bg-slate-900 hover:bg-slate-800 text-white px-3.5 py-2 rounded-2xl shadow-sm cursor-pointer transition-colors"
          title="Go to Dashboard"
        >
          <svg className="w-6 h-6 fill-current text-[#def645]" viewBox="0 0 24 24">
            <path d="M12 1L13.8 8.6L20.8 4.8L16.2 11.2L23 12L16.2 12.8L20.8 19.2L13.8 15.4L12 23L10.2 15.4L3.2 19.2L7.8 12.8L1 12L7.8 11.2L3.2 4.8L10.2 8.6Z" />
          </svg>
          <span className="text-base font-extrabold tracking-tight">Starline</span>
        </div>

        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <span>Welcome, {greetingName}</span>
          </h1>
        </div>
      </div>

      {/* Right: Modern Pill Actions from the Design */}
      <div className="flex flex-wrap items-center gap-2 sm:gap-3">
        {/* Branch Selector Pill */}
        {currentUser?.role === 'admin' ? (
          <div className="flex items-center gap-1.5 bg-white/90 border border-slate-200/80 rounded-2xl px-3 py-2 shadow-xs text-xs">
            <Building2 className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={branch}
              onChange={(e) => setBranch(e.target.value)}
              className="bg-transparent font-semibold text-slate-800 outline-none cursor-pointer text-xs"
            >
              <option value="All Branches">{companyProfile.companyName} (Consolidated)</option>
              <option value="Burimari Office">Burimari Office</option>
              <option value="Sonahat Office">Sonahat Office</option>
            </select>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 bg-white/90 border border-amber-300 rounded-2xl px-3 py-2 shadow-xs text-xs text-amber-900 font-semibold">
            <Lock className="w-3 h-3 text-amber-500" />
            <span>{branch}</span>
          </div>
        )}

        {/* Currency Pill */}
        <div className="flex items-center bg-white/90 border border-slate-200/80 rounded-2xl p-1 shadow-xs text-xs">
          {(['BDT', 'USD'] as const).map((c) => (
            <button
              key={c}
              onClick={() => setCurrency(c)}
              className={`px-2.5 py-1 rounded-xl font-bold transition-all text-xs ${
                currency === c ? 'bg-[#def645] text-slate-950 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {/* Fiscal Year (FY) Capsule & Quick Switcher */}
        <div className="relative" ref={fyMenuRef}>
          <button
            type="button"
            onClick={() => setShowFyMenu(!showFyMenu)}
            className="flex items-center gap-1.5 bg-white/90 border border-slate-200/80 hover:border-slate-300 rounded-2xl px-3 py-2 shadow-xs text-xs transition-colors cursor-pointer group"
            title="Fiscal Year - Active & Closed"
          >
            <Calendar className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-800 font-mono text-xs">{activeFY?.name}</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full font-mono ${
                activeFY?.status === 'Active' 
                  ? 'bg-emerald-100 text-emerald-800' 
                  : 'bg-slate-100 text-slate-600'
              }`}>
                {activeFY?.status}
              </span>
            </div>
            <ChevronDown className="w-3 h-3 text-slate-400 group-hover:text-slate-600 shrink-0" />
          </button>

          {showFyMenu && (
            <div className="absolute right-0 top-11 z-50 w-80 bg-white border border-slate-200 rounded-2xl shadow-xl p-3.5 animate-in fade-in zoom-in-95 text-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span className="font-bold text-slate-900 text-xs">Financial Year (FY)</span>
                </div>
                <button 
                  onClick={() => setShowFyMenu(false)} 
                  className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Active FY summary card */}
              <div className="p-3 bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-xl shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider font-mono">
                    Current Active Fiscal Year
                  </span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-1.5 py-0.5 rounded">
                    Active
                  </span>
                </div>
                <div className="font-black text-sm text-white mt-1">
                  {activeFY?.name}
                </div>
                <div className="text-[11px] text-slate-300 font-mono mt-0.5">
                  {formatFiscalYearDisplay(activeFY)}
                </div>
              </div>

              {/* Quick switch list */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  All Fiscal Years:
                </span>
                {fiscalYears.map((fy) => {
                  const isCurrent = fy.id === activeFY?.id;
                  return (
                    <div
                      key={fy.id}
                      onClick={() => {
                        if (fy.status !== 'Active') {
                          setActiveFiscalYear(fy.id);
                        }
                        setShowFyMenu(false);
                      }}
                      className={`p-2 rounded-xl flex items-center justify-between transition-colors cursor-pointer border ${
                        isCurrent 
                          ? 'bg-blue-50/70 border-blue-200 text-blue-900 font-bold' 
                          : 'bg-white border-slate-100 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-xs">{fy.name}</span>
                          <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold font-mono ${
                            fy.status === 'Active' 
                              ? 'bg-emerald-100 text-emerald-800' 
                              : fy.status === 'Closed' 
                                ? 'bg-slate-100 text-slate-600' 
                                : 'bg-blue-100 text-blue-800'
                          }`}>
                            {fy.status}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {formatFiscalYearDisplay(fy)}
                        </div>
                      </div>

                      {isCurrent ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <span className="text-[10px] text-blue-600 hover:underline">
                          Set Active
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    setShowFyMenu(false);
                    onSelectTab('admin');
                  }}
                  className="w-full py-1.5 text-center bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Manage Fiscal Years</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Action Capsule: Search, Moon, Bell (Exact pill capsule from Software Design.jpg) */}
        <div className="flex items-center bg-white/90 border border-slate-200/80 rounded-2xl p-1 shadow-xs">
          {/* Search Button */}
          <div className="relative">
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              title="Search"
            >
              <Search className="w-4 h-4" />
            </button>

            {isSearchOpen && (
              <div className="absolute right-0 top-10 z-50 bg-white border border-slate-200 rounded-2xl p-2 shadow-xl flex items-center gap-2 w-64 animate-in fade-in zoom-in-95">
                <Search className="w-4 h-4 text-slate-400 shrink-0 ml-1" />
                <input
                  type="text"
                  placeholder="Search invoices, items, trucks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                  className="w-full text-xs outline-none bg-transparent text-slate-800"
                />
                <button onClick={() => setIsSearchOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>

          {/* Moon / Theme Toggle (from photo) */}
          <button
            className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            title="Theme Toggle"
          >
            <Moon className="w-4 h-4" />
          </button>

          {/* Bell with red notification badge '2' (exact from photo) */}
          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors relative"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {/* Red Badge '2' as shown in photo */}
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                2
              </span>
            </button>

            {showNotifications && (
              <div className="absolute right-0 top-10 w-80 bg-white border border-slate-200 rounded-2xl shadow-xl p-3 z-50 animate-in fade-in zoom-in-95 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <span className="font-bold text-slate-900 text-xs">Store Alerts & Invoices</span>
                  <button onClick={() => setShowNotifications(false)} className="text-slate-400 hover:text-slate-600">
                    ✕
                  </button>
                </div>
                <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto pt-1">
                  {notifications.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        onSelectTab(item.tab);
                        setShowNotifications(false);
                      }}
                      className="py-2 px-1.5 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-900 text-xs">{item.title}</span>
                        <span className="text-[10px] text-slate-400">{item.time}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{item.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Recycle Bin & Restore Hub Button */}
          <button
            type="button"
            onClick={() => setIsRecycleBinOpen(true)}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-600 hover:text-rose-600 hover:bg-rose-50 transition-colors relative cursor-pointer"
            title="Recycle Bin & Restore Hub"
          >
            <Trash2 className="w-4 h-4" />
            {trashCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-rose-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center border-2 border-white animate-pulse">
                {trashCount > 9 ? '9+' : trashCount}
              </span>
            )}
          </button>
        </div>

        {/* User Profile Capsule */}
        <div className="relative" ref={userMenuRef}>
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 bg-white/90 hover:bg-white border border-slate-200/80 rounded-2xl px-2.5 py-1.5 shadow-xs cursor-pointer transition-all"
          >
            <div className="w-7 h-7 rounded-xl bg-slate-900 text-white font-bold text-xs flex items-center justify-center">
              {currentUser ? currentUser.displayName.charAt(0) : 'J'}
            </div>
            <div className="hidden sm:block text-left">
              <span className="text-xs font-bold text-slate-800 block leading-tight truncate max-w-[110px]">
                {currentUser?.displayName || 'Josiah'}
              </span>
              <span className="text-[10px] text-slate-400 block leading-none">
                {currentUser?.role ? (ROLE_LABELS[currentUser.role]?.title.split('/')[0] || currentUser.role) : 'Store Manager'}
              </span>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* User Menu Dropdown */}
          {showUserMenu && (
            <div className="absolute right-0 top-12 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl p-3 z-50 animate-in fade-in zoom-in-95 text-xs space-y-3">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="font-bold text-slate-900 block text-xs truncate">
                  {currentUser?.displayName}
                </span>
                <span className="text-[10px] text-slate-500 block truncate">
                  {currentUser?.email}
                </span>
                <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                    {currentUser ? (ROLE_LABELS[currentUser.role]?.title || currentUser.role) : 'User'}
                  </span>
                  {currentUser?.branch && (
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                      {currentUser.branch}
                    </span>
                  )}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowUserMenu(false);
                    logout();
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold transition-colors flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Global Recycle Bin & Restore Hub Modal */}
      <RecycleBinModal 
        isOpen={isRecycleBinOpen} 
        onClose={() => setIsRecycleBinOpen(false)} 
      />
    </header>
  );
};
