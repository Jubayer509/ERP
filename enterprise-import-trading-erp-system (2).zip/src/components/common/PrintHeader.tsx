import React, { useState, useEffect } from 'react';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';

interface PrintHeaderProps {
  title: string;
  subtitle?: string;
  periodLabel?: string;
  metadata?: Array<{ label: string; value: React.ReactNode }>;
  companyName?: string;
}

export const PrintHeader: React.FC<PrintHeaderProps> = ({
  title,
  subtitle,
  periodLabel,
  metadata = [],
  companyName
}) => {
  const [profile, setProfile] = useState(() => getCompanyProfile());

  useEffect(() => {
    return subscribeCompanyProfile(setProfile);
  }, []);

  const currentDate = new Date().toLocaleDateString('en-GB');
  const currentTime = new Date().toLocaleTimeString('en-US');
  const displayCompanyName = companyName || profile.companyName;
  const displaySubtitle = subtitle ?? `${profile.companyName} • Financial & Ledger Records`;

  return (
    <div className="hidden print:block pb-3 mb-3 border-b-2 border-slate-900 text-slate-900">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-xl font-black uppercase tracking-wider text-slate-950">
            {displayCompanyName}
          </h1>
          <p className="text-[11px] text-slate-600 font-sans">
            {profile.address} | Mobile: {profile.mobile}
          </p>
          <h2 className="text-sm font-bold mt-1 text-slate-900 uppercase tracking-wide underline decoration-1">
            {title}
          </h2>
          {displaySubtitle && (
            <p className="text-[10px] text-slate-500 font-medium">
              {displaySubtitle}
            </p>
          )}
        </div>
        <div className="text-right text-xs font-mono shrink-0 pl-4">
          {periodLabel && (
            <div className="text-slate-800">
              Period: <strong>{periodLabel}</strong>
            </div>
          )}
          <div className="text-slate-500 text-[11px] mt-0.5">
            Print Date: {currentDate} {currentTime}
          </div>
        </div>
      </div>

      {metadata.length > 0 && (
        <div className="mt-2.5 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-slate-50 p-2 border border-slate-300 rounded font-mono">
          {metadata.map((item, idx) => (
            <div key={idx} className="truncate">
              <span className="text-slate-600">{item.label}: </span>
              <strong className="text-slate-900">{item.value}</strong>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export const PrintSignatures: React.FC<{
  preparedByRole?: string;
  auditedByRole?: string;
  approvedByRole?: string;
}> = ({
  preparedByRole = 'Accountant',
  auditedByRole = 'Internal Auditor',
  approvedByRole = 'Managing Director'
}) => {
  return (
    <div className="hidden print:grid grid-cols-3 gap-6 pt-16 mt-8 text-center text-xs font-sans text-slate-800 break-inside-avoid">
      <div>
        <div className="border-t border-slate-700 pt-1.5 font-bold">Prepared By</div>
        <div className="text-[10px] text-slate-500">{preparedByRole}</div>
      </div>
      <div>
        <div className="border-t border-slate-700 pt-1.5 font-bold">Audited & Checked By</div>
        <div className="text-[10px] text-slate-500">{auditedByRole}</div>
      </div>
      <div>
        <div className="border-t border-slate-700 pt-1.5 font-bold">Authorized Signature</div>
        <div className="text-[10px] text-slate-500">{approvedByRole}</div>
      </div>
    </div>
  );
};
