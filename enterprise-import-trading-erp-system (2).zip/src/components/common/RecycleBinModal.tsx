import React, { useState, useEffect, useMemo } from 'react';
import { 
  Trash2, 
  RotateCcw, 
  AlertTriangle, 
  Search, 
  X, 
  Receipt, 
  CreditCard, 
  FileText, 
  CheckCircle2, 
  Clock, 
  ShieldAlert,
  ArrowRight,
  Filter
} from 'lucide-react';
import { 
  DeletedRecord, 
  DeletedRecordType, 
  getDeletedRecords, 
  restoreDeletedRecord, 
  permanentlyDeleteRecord, 
  clearRecycleBin, 
  subscribeRecycleBin 
} from '../../utils/recycleBinStorage';
import { ModalWrapper } from './ModalWrapper';

interface RecycleBinModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: DeletedRecordType | 'all';
  onRecordRestored?: (record: DeletedRecord) => void;
}

export const RecycleBinModal: React.FC<RecycleBinModalProps> = ({
  isOpen,
  onClose,
  initialType = 'all',
  onRecordRestored
}) => {
  const [deletedRecords, setDeletedRecords] = useState<DeletedRecord[]>([]);
  const [selectedType, setSelectedType] = useState<DeletedRecordType | 'all'>(initialType);
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [confirmPermanentId, setConfirmPermanentId] = useState<string | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  useEffect(() => {
    setSelectedType(initialType);
  }, [initialType]);

  const loadRecords = () => {
    setDeletedRecords(getDeletedRecords());
  };

  useEffect(() => {
    if (isOpen) {
      loadRecords();
    }
  }, [isOpen]);

  useEffect(() => {
    const unsubscribe = subscribeRecycleBin(() => {
      loadRecords();
    });
    return unsubscribe;
  }, []);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleRestore = (trashId: string) => {
    const restored = restoreDeletedRecord(trashId);
    if (restored) {
      loadRecords();
      triggerToast(`"${restored.referenceNumber}" restored successfully.`);
      if (onRecordRestored) {
        onRecordRestored(restored);
      }
    }
  };

  const handlePermanentDelete = (trashId: string) => {
    const success = permanentlyDeleteRecord(trashId);
    if (success) {
      loadRecords();
      setConfirmPermanentId(null);
      triggerToast('Record permanently deleted.');
    }
  };

  const handleClearAll = () => {
    clearRecycleBin(selectedType === 'all' ? undefined : selectedType);
    loadRecords();
    setConfirmClearAll(false);
    triggerToast('Recycle Bin emptied.');
  };

  // Filtered list
  const filteredRecords = useMemo(() => {
    return deletedRecords.filter(r => {
      const matchesType = selectedType === 'all' || r.recordType === selectedType;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || 
        r.referenceNumber.toLowerCase().includes(q) ||
        r.title.toLowerCase().includes(q) ||
        r.partyName.toLowerCase().includes(q) ||
        (r.reason && r.reason.toLowerCase().includes(q)) ||
        (r.deletedBy && r.deletedBy.toLowerCase().includes(q));

      return matchesType && matchesSearch;
    });
  }, [deletedRecords, selectedType, searchQuery]);

  // Counts by type
  const counts = useMemo(() => {
    const map = {
      all: deletedRecords.length,
      purchase_invoice: 0,
      sales_invoice: 0,
      supplier_payment: 0,
      customer_payment: 0,
      journal_voucher: 0
    };
    deletedRecords.forEach(r => {
      if (map[r.recordType] !== undefined) {
        map[r.recordType]++;
      }
    });
    return map;
  }, [deletedRecords]);

  if (!isOpen) return null;

  const getTypeBadge = (type: DeletedRecordType) => {
    switch (type) {
      case 'purchase_invoice':
        return { label: 'Purchase Invoice', color: 'bg-indigo-100 text-indigo-800 border-indigo-200', icon: Receipt };
      case 'sales_invoice':
        return { label: 'Sales Invoice', color: 'bg-blue-100 text-blue-800 border-blue-200', icon: Receipt };
      case 'supplier_payment':
        return { label: 'Supplier Payment', color: 'bg-amber-100 text-amber-800 border-amber-200', icon: CreditCard };
      case 'customer_payment':
        return { label: 'Customer Payment', color: 'bg-emerald-100 text-emerald-800 border-emerald-200', icon: CreditCard };
      case 'journal_voucher':
        return { label: 'Accounts Voucher', color: 'bg-purple-100 text-purple-800 border-purple-200', icon: FileText };
      default:
        return { label: type, color: 'bg-slate-100 text-slate-800 border-slate-200', icon: FileText };
    }
  };

  const formatTimeAgo = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const diffMs = Date.now() - date.getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins} min ago`;
      const diffHours = Math.floor(diffMins / 60);
      if (diffHours < 24) return `${diffHours} hr ago`;
      const diffDays = Math.floor(diffHours / 24);
      return `${diffDays} days ago (${date.toLocaleDateString()})`;
    } catch {
      return isoString;
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      isDirty={false}
      backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in"
    >
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-14 right-6 z-60 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200 animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-rose-900 via-rose-800 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-rose-300 border border-white/10">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold">Recycle Bin & Restore Hub</h2>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white text-xs font-bold transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Filter Toolbar */}
        <div className="p-3 sm:p-4 bg-slate-50 border-b border-slate-200 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search by Invoice No, Ref, Supplier, Customer, Notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Clear All Button */}
            {deletedRecords.length > 0 && (
              <div className="shrink-0 flex items-center gap-2">
                {!confirmClearAll ? (
                  <button
                    type="button"
                    onClick={() => setConfirmClearAll(true)}
                    className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Empty Trash ({counts[selectedType]})</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-1.5 bg-rose-100 p-1 rounded-xl border border-rose-300 animate-in fade-in">
                    <span className="text-[11px] font-bold text-rose-900 px-1.5">Empty all?</span>
                    <button
                      type="button"
                      onClick={handleClearAll}
                      className="px-2 py-0.5 bg-rose-700 text-white rounded text-[11px] font-bold hover:bg-rose-800"
                    >
                      Yes, Empty
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClearAll(false)}
                      className="px-2 py-0.5 bg-slate-200 text-slate-700 rounded text-[11px] font-semibold hover:bg-slate-300"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Type Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
            <button
              type="button"
              onClick={() => setSelectedType('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                selectedType === 'all'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200/80 text-slate-700 border border-slate-200'
              }`}
            >
              <span>All Records</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${selectedType === 'all' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                {counts.all}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('purchase_invoice')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                selectedType === 'purchase_invoice'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200/80 text-slate-700 border border-slate-200'
              }`}
            >
              <span>Purchase Invoices</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${selectedType === 'purchase_invoice' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                {counts.purchase_invoice}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('sales_invoice')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                selectedType === 'sales_invoice'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200/80 text-slate-700 border border-slate-200'
              }`}
            >
              <span>Sales Invoices</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${selectedType === 'sales_invoice' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                {counts.sales_invoice}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('supplier_payment')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                selectedType === 'supplier_payment'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200/80 text-slate-700 border border-slate-200'
              }`}
            >
              <span>Supplier Payments</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${selectedType === 'supplier_payment' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                {counts.supplier_payment}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('customer_payment')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                selectedType === 'customer_payment'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200/80 text-slate-700 border border-slate-200'
              }`}
            >
              <span>Customer Receipts</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${selectedType === 'customer_payment' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                {counts.customer_payment}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('journal_voucher')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                selectedType === 'journal_voucher'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200/80 text-slate-700 border border-slate-200'
              }`}
            >
              <span>Accounts Vouchers</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${selectedType === 'journal_voucher' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                {counts.journal_voucher}
              </span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
          {filteredRecords.length === 0 ? (
            <div className="py-14 text-center">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 mb-3">
                <Trash2 className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-slate-700 text-sm">Recycle Bin is Empty</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                {searchQuery 
                  ? 'No matching deleted records found.'
                  : 'No deleted records in this category.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredRecords.map((item) => {
                const badge = getTypeBadge(item.recordType);
                const isConfirming = confirmPermanentId === item.id;

                return (
                  <div
                    key={item.id}
                    className="p-3.5 sm:p-4 bg-white hover:bg-slate-50/80 rounded-xl border border-slate-200 shadow-2xs transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 group"
                  >
                    {/* Left: Info */}
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${badge.color}`}>
                          {badge.label}
                        </span>
                        <span className="font-mono font-bold text-xs text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                          {item.referenceNumber}
                        </span>
                        <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          {formatTimeAgo(item.deletedAt)}
                        </span>
                      </div>

                      <div className="flex items-baseline gap-2 flex-wrap">
                        <h4 className="font-bold text-slate-800 text-xs sm:text-sm truncate">
                          {item.partyName || item.title}
                        </h4>
                        <span className="text-xs text-slate-400 font-mono">
                          Date: {item.date}
                        </span>
                        <span className="font-mono font-bold text-rose-600 text-xs sm:text-sm">
                          ৳ {item.amount.toLocaleString()}
                        </span>
                      </div>

                      {item.reason && (
                        <p className="text-[11px] text-slate-500 bg-slate-50 p-1.5 rounded-lg border border-slate-200/60 inline-block max-w-full">
                          <strong className="text-slate-600">Delete Reason:</strong> {item.reason}
                        </p>
                      )}

                      <div className="text-[10px] text-slate-400 font-mono">
                        Deleted by: {item.deletedBy || 'System Admin'}
                      </div>
                    </div>

                    {/* Right: Actions */}
                    <div className="shrink-0 flex items-center gap-2 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                      {/* Restore Button */}
                      <button
                        type="button"
                        onClick={() => handleRestore(item.id)}
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer hover:shadow"
                        title="Restore record"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Restore</span>
                      </button>

                      {/* Permanent Delete Button */}
                      {!isConfirming ? (
                        <button
                          type="button"
                          onClick={() => setConfirmPermanentId(item.id)}
                          className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                          title="Delete permanently"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Delete Forever</span>
                        </button>
                      ) : (
                        <div className="flex items-center gap-1 bg-rose-50 p-1 rounded-xl border border-rose-300 animate-in fade-in">
                          <span className="text-[10px] font-bold text-rose-900 px-1">Delete forever?</span>
                          <button
                            type="button"
                            onClick={() => handlePermanentDelete(item.id)}
                            className="px-2 py-1 bg-rose-700 text-white rounded text-[10px] font-bold hover:bg-rose-800"
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmPermanentId(null)}
                            className="px-2 py-1 bg-slate-200 text-slate-700 rounded text-[10px] hover:bg-slate-300"
                          >
                            No
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-emerald-600" />
            <span>Restoring a record automatically reconciles ledgers, balances, and stock.</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </ModalWrapper>
  );
};
