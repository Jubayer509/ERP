import React, { useState } from 'react';
import { Trash2, AlertTriangle, X, RotateCcw } from 'lucide-react';
import { ModalWrapper } from './ModalWrapper';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  title: string;
  referenceNumber: string;
  partyName?: string;
  amount?: number;
  date?: string;
  onClose: () => void;
  onConfirm: (reason: string) => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  title,
  referenceNumber,
  partyName,
  amount,
  date,
  onClose,
  onConfirm
}) => {
  const [reason, setReason] = useState('Mistaken entry / duplicate');

  if (!isOpen) return null;

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm(reason);
  };

  const isFormDirty = reason.trim() !== 'Mistaken entry / duplicate';

  const handleClose = () => {
    onClose();
    setReason('Mistaken entry / duplicate');
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleClose}
      isDirty={isFormDirty}
      backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        <div className="p-4 sm:p-5 bg-rose-50 border-b border-rose-100 flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0 border border-rose-200">
            <Trash2 className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">Confirm Deletion</h3>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleConfirm} className="p-4 sm:p-5 space-y-4 text-xs">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">{title}:</span>
              <span className="font-mono font-bold text-slate-900">{referenceNumber}</span>
            </div>
            {partyName && (
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Party / Entity:</span>
                <span className="font-semibold text-slate-800 truncate max-w-[200px]">{partyName}</span>
              </div>
            )}
            {amount !== undefined && (
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Amount:</span>
                <span className="font-mono font-bold text-rose-600">৳ {amount.toLocaleString()}</span>
              </div>
            )}
          </div>

          <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl flex items-start gap-2 text-emerald-800">
            <RotateCcw className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              This record will be moved to the <strong>Recycle Bin</strong> and can be restored anytime.
            </p>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Deletion Reason
            </label>
            <input
              type="text"
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Mistaken entry / duplicate invoice"
              className="w-full border border-slate-300 rounded-xl p-2 focus:ring-2 focus:ring-rose-500 outline-none text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete to Trash</span>
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
