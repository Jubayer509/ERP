import React, { useEffect, useRef, useState } from 'react';
import { AlertTriangle } from 'lucide-react';

// Stack of currently mounted/open ModalWrapper instances so only the topmost modal handles Escape
const openModalStack: symbol[] = [];

export interface ModalWrapperProps {
  /** Whether the modal is open (defaults to true when conditionally rendered) */
  isOpen?: boolean;
  /** Single close function that closes the modal, resets form state, clears errors, and releases locks */
  onClose: () => void;
  /** Whether the user has entered or modified unsaved input in the form */
  isDirty?: boolean;
  /** Whether a save/submit operation is currently in progress */
  isSaving?: boolean;
  /** Exact outer backdrop container classes to preserve identical visual styling */
  className?: string;
  /** Optional inline style for the backdrop container */
  style?: React.CSSProperties;
  /** If true, disables closing on backdrop click (e.g., mandatory security modal) */
  disableBackdropClose?: boolean;
  /** If true, disables closing on Escape key (e.g., mandatory security modal) */
  disableEscapeClose?: boolean;
  children: React.ReactNode;
}

export const ModalWrapper: React.FC<ModalWrapperProps> = ({
  isOpen = true,
  onClose,
  isDirty = false,
  isSaving = false,
  className = 'fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4',
  style,
  disableBackdropClose = false,
  disableEscapeClose = false,
  children,
}) => {
  const [showDiscardConfirm, setShowDiscardConfirm] = useState(false);
  const instanceIdRef = useRef<symbol>(Symbol('ModalWrapper'));
  const mouseDownOnBackdropRef = useRef(false);

  const latestPropsRef = useRef({
    onClose,
    isDirty,
    isSaving,
    disableEscapeClose,
    showDiscardConfirm,
  });
  latestPropsRef.current = {
    onClose,
    isDirty,
    isSaving,
    disableEscapeClose,
    showDiscardConfirm,
  };

  useEffect(() => {
    if (!isOpen) {
      setShowDiscardConfirm(false);
      return;
    }

    const id = instanceIdRef.current;
    openModalStack.push(id);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      // Only the topmost active modal responds to Escape
      if (openModalStack[openModalStack.length - 1] !== id) return;

      const {
        onClose: currentOnClose,
        isDirty: currentIsDirty,
        isSaving: currentIsSaving,
        disableEscapeClose: currentDisableEscape,
        showDiscardConfirm: currentShowDiscard,
      } = latestPropsRef.current;

      if (currentDisableEscape) return;
      e.preventDefault();
      e.stopPropagation();

      if (currentIsSaving) return;

      if (currentShowDiscard) {
        setShowDiscardConfirm(false);
        return;
      }

      if (currentIsDirty) {
        setShowDiscardConfirm(true);
      } else {
        currentOnClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      const idx = openModalStack.lastIndexOf(id);
      if (idx !== -1) {
        openModalStack.splice(idx, 1);
      }
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClickCapture = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement | null;
    if (!target || typeof target.closest !== 'function') return;

    const closeBtn = target.closest('[data-modal-close="true"]');
    if (!closeBtn) return;

    if (isSaving) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    if (isDirty) {
      e.preventDefault();
      e.stopPropagation();
      setShowDiscardConfirm(true);
    }
  };

  const handleBackdropMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    mouseDownOnBackdropRef.current = e.target === e.currentTarget;
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target !== e.currentTarget || !mouseDownOnBackdropRef.current) {
      mouseDownOnBackdropRef.current = false;
      return;
    }
    mouseDownOnBackdropRef.current = false;

    if (disableBackdropClose || isSaving) return;

    if (isDirty) {
      setShowDiscardConfirm(true);
    } else {
      onClose();
    }
  };

  const handleConfirmDiscard = () => {
    setShowDiscardConfirm(false);
    onClose();
  };

  return (
    <div
      className={className}
      style={style}
      onClickCapture={handleClickCapture}
      onMouseDown={handleBackdropMouseDown}
      onClick={handleBackdropClick}
    >
      {children}

      {showDiscardConfirm && (
        <div
          className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4"
          onMouseDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation();
            if (e.target === e.currentTarget) {
              setShowDiscardConfirm(false);
            }
          }}
        >
          <div
            className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-xs p-5 animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-bold text-slate-900">Discard changes?</h4>
                <p className="text-xs text-slate-600 mt-1">
                  You have unsaved input. Closing now will discard your changes.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 mt-4 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowDiscardConfirm(false)}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Keep editing
              </button>
              <button
                type="button"
                onClick={handleConfirmDiscard}
                className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 transition-colors shadow-xs cursor-pointer"
              >
                Discard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
