import React, { useState, useMemo } from 'react';
import { ModalWrapper } from '../common/ModalWrapper';
import { 
  Users, 
  DollarSign, 
  Plus, 
  Printer, 
  Building2, 
  Search, 
  FileText, 
  Phone, 
  CheckCircle2, 
  Clock, 
  ChevronRight,
  UserPlus,
  ArrowDownToLine,
  Filter,
  Check,
  CreditCard,
  Briefcase,
  AlertCircle,
  History,
  Calendar,
  Wallet
} from 'lucide-react';
import { Employee } from '../../types/erp';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';

export interface HRMModuleProps {
  currentBranch?: string;
  currency?: string;
  activeSubTab?: 'employees' | 'salary_sheet';
  onSubTabChange?: (tab: 'employees' | 'salary_sheet') => void;
  openAddEmployeeModalSignal?: number;
  openSalaryReportModalSignal?: number;
}

export interface SalaryPaymentTransaction {
  id: string;
  amount: number;
  date: string;
  paymentMethod: 'Cash' | 'Bank Transfer' | 'bKash/Nagad';
  paymentType: 'Advance' | 'Remaining Settlement' | 'Full Payment';
  note?: string;
}

export interface MonthlySalaryRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  empCode: string;
  designation: string;
  branch: string;
  phone: string;
  monthlySalary: number;
  bonus: number;
  deduction: number;
  netPayable: number;
  paidAmount: number;
  dueAmount: number;
  month: string; // e.g. "2026-09"
  status: 'Paid' | 'Partial' | 'Unpaid';
  payments: SalaryPaymentTransaction[];
  lastPaymentDate?: string;
  paymentMethod: 'Bank Transfer' | 'Cash' | 'bKash/Nagad';
}

export const HRMModule: React.FC<HRMModuleProps> = ({ 
  currentBranch = 'All Branches', 
  currency = 'BDT',
  activeSubTab,
  onSubTabChange,
  openAddEmployeeModalSignal,
  openSalaryReportModalSignal
}) => {
  // Only 2 main tabs: 'employees' and 'salary_sheet'
  const [activeTab, setActiveTab] = useState<'employees' | 'salary_sheet'>(activeSubTab || 'salary_sheet');
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  React.useEffect(() => {
    return subscribeCompanyProfile(setCompanyProfile);
  }, []);

  React.useEffect(() => {
    if (activeSubTab && activeSubTab !== activeTab) {
      setActiveTab(activeSubTab);
    }
  }, [activeSubTab]);

  React.useEffect(() => {
    if (openAddEmployeeModalSignal && openAddEmployeeModalSignal > 0) {
      setShowAddEmpModal(true);
    }
  }, [openAddEmployeeModalSignal]);

  React.useEffect(() => {
    if (openSalaryReportModalSignal && openSalaryReportModalSignal > 0) {
      setShowSalaryReportModal(true);
    }
  }, [openSalaryReportModalSignal]);

  // Selected Salary Month (default: September 2026)
  const [selectedMonth, setSelectedMonth] = useState('2026-09');
  const [branchFilter, setBranchFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Paid' | 'Partial' | 'Unpaid'>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Employees State
  const [employees, setEmployees] = useState<Employee[]>([
    {
      id: 'emp-01',
      empCode: 'EMP-001',
      name: 'Mohammad Faruk Hossain',
      department: 'Import & Logistics',
      designation: 'General Manager - Commercial & LC',
      joiningDate: '2020-01-15',
      branch: 'Head Office (Dhaka)',
      phone: '+880 1711 223344',
      basicSalary: 95000,
      houseRent: 45000,
      conveyance: 12000,
      medicalAllowance: 8000,
      grossSalary: 160000,
      pfDeduction: 0,
      taxDeduction: 0,
      bankAccount: 'EBL - 104829104',
      status: 'Active'
    },
    {
      id: 'emp-02',
      empCode: 'EMP-002',
      name: 'Fariha Yasmin',
      department: 'Accounts & Finance',
      designation: 'Senior Manager - Financial Control',
      joiningDate: '2021-03-01',
      branch: 'Head Office (Dhaka)',
      phone: '+880 1712 556677',
      basicSalary: 80000,
      houseRent: 38000,
      conveyance: 10000,
      medicalAllowance: 7000,
      grossSalary: 135000,
      pfDeduction: 0,
      taxDeduction: 0,
      bankAccount: 'City Bank - 11092837',
      status: 'Active'
    },
    {
      id: 'emp-03',
      empCode: 'EMP-003',
      name: 'Jasim Uddin',
      department: 'Warehouse',
      designation: 'Burimari Yard Supervisor & Scale Incharge',
      joiningDate: '2022-06-10',
      branch: 'Burimari Office',
      phone: '+880 1713 998877',
      basicSalary: 45000,
      houseRent: 20000,
      conveyance: 5000,
      medicalAllowance: 5000,
      grossSalary: 75000,
      pfDeduction: 0,
      taxDeduction: 0,
      bankAccount: 'Islami Bank - 20501192',
      status: 'Active'
    },
    {
      id: 'emp-04',
      empCode: 'EMP-004',
      name: 'Kamrul Hasan',
      department: 'Sales & Distribution',
      designation: 'Commercial Executive - Sales',
      joiningDate: '2022-11-01',
      branch: 'Head Office (Dhaka)',
      phone: '+880 1714 332211',
      basicSalary: 50000,
      houseRent: 22000,
      conveyance: 5000,
      medicalAllowance: 5000,
      grossSalary: 82000,
      pfDeduction: 0,
      taxDeduction: 0,
      bankAccount: 'Brac Bank - 1502204',
      status: 'Active'
    },
    {
      id: 'emp-05',
      empCode: 'EMP-005',
      name: 'Rashedul Islam',
      department: 'Sales & Distribution',
      designation: 'Burimari Branch Sales Officer',
      joiningDate: '2023-04-15',
      branch: 'Burimari Office',
      phone: '+880 1823 456789',
      basicSalary: 38000,
      houseRent: 18000,
      conveyance: 5000,
      medicalAllowance: 4000,
      grossSalary: 65000,
      pfDeduction: 0,
      taxDeduction: 0,
      bankAccount: 'Cash in Hand',
      status: 'Active'
    },
    {
      id: 'emp-06',
      empCode: 'EMP-006',
      name: 'Mizanur Rahman',
      department: 'Warehouse',
      designation: 'Sonahat Weighbridge Operator',
      joiningDate: '2023-08-01',
      branch: 'Sonahat Office',
      phone: '+880 1912 334455',
      basicSalary: 35000,
      houseRent: 15000,
      conveyance: 4000,
      medicalAllowance: 4000,
      grossSalary: 58000,
      pfDeduction: 0,
      taxDeduction: 0,
      bankAccount: 'Dutch-Bangla Bank - 1182903',
      status: 'Active'
    }
  ]);

  // Salary Records State with Partial Payments Support
  const [salaryRecords, setSalaryRecords] = useState<MonthlySalaryRecord[]>([
    {
      id: 'sal-01',
      employeeId: 'emp-01',
      employeeName: 'Mohammad Faruk Hossain',
      empCode: 'EMP-001',
      designation: 'General Manager - Commercial & LC',
      branch: 'Head Office (Dhaka)',
      phone: '+880 1711 223344',
      monthlySalary: 160000,
      bonus: 0,
      deduction: 0,
      netPayable: 160000,
      paidAmount: 160000,
      dueAmount: 0,
      month: '2026-09',
      status: 'Paid',
      lastPaymentDate: '2026-09-05',
      paymentMethod: 'Bank Transfer',
      payments: [
        {
          id: 'pay-01-1',
          amount: 160000,
          date: '2026-09-05',
          paymentMethod: 'Bank Transfer',
          paymentType: 'Full Payment',
          note: 'Full salary payment for September'
        }
      ]
    },
    {
      id: 'sal-02',
      employeeId: 'emp-02',
      employeeName: 'Fariha Yasmin',
      empCode: 'EMP-002',
      designation: 'Senior Manager - Financial Control',
      branch: 'Head Office (Dhaka)',
      phone: '+880 1712 556677',
      monthlySalary: 135000,
      bonus: 0,
      deduction: 0,
      netPayable: 135000,
      paidAmount: 135000,
      dueAmount: 0,
      month: '2026-09',
      status: 'Paid',
      lastPaymentDate: '2026-09-05',
      paymentMethod: 'Bank Transfer',
      payments: [
        {
          id: 'pay-02-1',
          amount: 135000,
          date: '2026-09-05',
          paymentMethod: 'Bank Transfer',
          paymentType: 'Full Payment',
          note: 'Full salary payment for September'
        }
      ]
    },
    {
      id: 'sal-03',
      employeeId: 'emp-03',
      employeeName: 'Jasim Uddin',
      empCode: 'EMP-003',
      designation: 'Burimari Yard Supervisor & Scale Incharge',
      branch: 'Burimari Office',
      phone: '+880 1713 998877',
      monthlySalary: 75000,
      bonus: 5000,
      deduction: 0,
      netPayable: 80000,
      paidAmount: 80000,
      dueAmount: 0,
      month: '2026-09',
      status: 'Paid',
      lastPaymentDate: '2026-09-05',
      paymentMethod: 'Bank Transfer',
      payments: [
        {
          id: 'pay-03-1',
          amount: 80000,
          date: '2026-09-05',
          paymentMethod: 'Bank Transfer',
          paymentType: 'Full Payment',
          note: 'Full salary payment including bonus'
        }
      ]
    },
    {
      id: 'sal-04',
      employeeId: 'emp-04',
      employeeName: 'Kamrul Hasan',
      empCode: 'EMP-004',
      designation: 'Commercial Executive - Sales',
      branch: 'Head Office (Dhaka)',
      phone: '+880 1714 332211',
      monthlySalary: 82000,
      bonus: 0,
      deduction: 0,
      netPayable: 82000,
      paidAmount: 0,
      dueAmount: 82000,
      month: '2026-09',
      status: 'Unpaid',
      paymentMethod: 'Bank Transfer',
      payments: []
    },
    {
      id: 'sal-05',
      employeeId: 'emp-05',
      employeeName: 'Rashedul Islam',
      empCode: 'EMP-005',
      designation: 'Burimari Branch Sales Officer',
      branch: 'Burimari Office',
      phone: '+880 1823 456789',
      monthlySalary: 65000,
      bonus: 0,
      deduction: 0,
      netPayable: 65000,
      paidAmount: 25000,
      dueAmount: 40000,
      month: '2026-09',
      status: 'Partial',
      lastPaymentDate: '2026-09-12',
      paymentMethod: 'Cash',
      payments: [
        {
          id: 'pay-05-1',
          amount: 25000,
          date: '2026-09-12',
          paymentMethod: 'Cash',
          paymentType: 'Advance',
          note: 'Mid-month cash advance for urgent family expenses'
        }
      ]
    },
    {
      id: 'sal-06',
      employeeId: 'emp-06',
      employeeName: 'Mizanur Rahman',
      empCode: 'EMP-006',
      designation: 'Sonahat Weighbridge Operator',
      branch: 'Sonahat Office',
      phone: '+880 1912 334455',
      monthlySalary: 58000,
      bonus: 0,
      deduction: 0,
      netPayable: 58000,
      paidAmount: 18000,
      dueAmount: 40000,
      month: '2026-09',
      status: 'Partial',
      lastPaymentDate: '2026-09-15',
      paymentMethod: 'bKash/Nagad',
      payments: [
        {
          id: 'pay-06-1',
          amount: 18000,
          date: '2026-09-15',
          paymentMethod: 'bKash/Nagad',
          paymentType: 'Advance',
          note: 'Salary advance via bKash'
        }
      ]
    }
  ]);

  // Modals state
  const [showAddEmpModal, setShowAddEmpModal] = useState(false);
  const [showSalaryReportModal, setShowSalaryReportModal] = useState(false);
  const [selectedPayslipRecord, setSelectedPayslipRecord] = useState<MonthlySalaryRecord | null>(null);

  // Partial Payment Modal State
  const [selectedPaymentRecord, setSelectedPaymentRecord] = useState<MonthlySalaryRecord | null>(null);
  const [paymentForm, setPaymentForm] = useState({
    amount: 0,
    paymentDate: new Date().toISOString().split('T')[0],
    paymentMethod: '' as 'Cash' | 'Bank Transfer' | 'bKash/Nagad',
    paymentType: '' as SalaryPaymentTransaction['paymentType'],
    note: ''
  });

  // History Drawer/Modal State
  const [selectedHistoryRecord, setSelectedHistoryRecord] = useState<MonthlySalaryRecord | null>(null);

  // Add Employee Form State
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    designation: '',
    customDesignation: '',
    branch: '',
    phone: '',
    monthlySalary: 0,
    paymentMethod: '' as 'Cash' | 'Bank Transfer' | 'bKash/Nagad'
  });

  // Pre-configured Designations for easy one-click selection
  const designationOptions = [
    'Branch Manager',
    'Senior Sales Officer',
    'Weighbridge Scale Operator',
    'Yard Supervisor',
    'Accountant',
    'LC Executive',
    'Driver / Helper',
    'Custom Designation'
  ];

  // Open Payment Modal for an employee
  const handleOpenPaymentModal = (record: MonthlySalaryRecord) => {
    setSelectedPaymentRecord(record);
    setPaymentForm({
      amount: 0,
      paymentDate: new Date().toISOString().split('T')[0],
      paymentMethod: '' as any,
      paymentType: '' as any,
      note: ''
    });
  };

  const handleClosePaymentModal = () => {
    setSelectedPaymentRecord(null);
    setPaymentForm({
      amount: 0,
      paymentDate: new Date().toISOString().split('T')[0],
      paymentMethod: '' as any,
      paymentType: '' as any,
      note: ''
    });
  };

  const isPaymentDirty = Boolean(selectedPaymentRecord && (paymentForm.amount > 0 || paymentForm.note.trim() !== ''));

  const handleCloseAddEmpModal = () => {
    setShowAddEmpModal(false);
    setNewEmployee({
      name: '',
      designation: '',
      customDesignation: '',
      branch: '',
      phone: '',
      monthlySalary: 0,
      paymentMethod: '' as any
    });
  };

  const isAddEmpDirty = Boolean(
    showAddEmpModal && (
      newEmployee.name.trim() !== '' ||
      newEmployee.customDesignation.trim() !== '' ||
      newEmployee.phone.trim() !== ''
    )
  );

  // Submit Payment (Partial or Full)
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPaymentRecord) return;

    const payAmount = Number(paymentForm.amount);
    if (isNaN(payAmount) || payAmount <= 0) {
      triggerToast('⚠️ Please enter a valid amount');
      return;
    }

    if (payAmount > selectedPaymentRecord.dueAmount) {
      triggerToast(`⚠️ Payment amount cannot exceed remaining due (৳${selectedPaymentRecord.dueAmount.toLocaleString()})!`);
      return;
    }

    const newTx: SalaryPaymentTransaction = {
      id: `tx-${Date.now()}`,
      amount: payAmount,
      date: paymentForm.paymentDate,
      paymentMethod: paymentForm.paymentMethod,
      paymentType: paymentForm.paymentType,
      note: paymentForm.note || (payAmount === selectedPaymentRecord.dueAmount ? 'Remaining Due Settlement' : 'Partial / Advance Withdrawal')
    };

    setSalaryRecords(salaryRecords.map(rec => {
      if (rec.id === selectedPaymentRecord.id) {
        const updatedPaid = rec.paidAmount + payAmount;
        const updatedDue = Math.max(0, rec.netPayable - updatedPaid);
        const newStatus: MonthlySalaryRecord['status'] = updatedDue === 0 ? 'Paid' : 'Partial';

        return {
          ...rec,
          paidAmount: updatedPaid,
          dueAmount: updatedDue,
          status: newStatus,
          lastPaymentDate: paymentForm.paymentDate,
          payments: [...rec.payments, newTx]
        };
      }
      return rec;
    }));

    setSelectedPaymentRecord(null);
    triggerToast(`✓ ৳${payAmount.toLocaleString()} recorded successfully! (${paymentForm.paymentType})`);
  };

  // Handle Add Employee
  const handleAddEmployeeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmployee.name.trim()) {
      triggerToast('⚠️ Please enter employee name');
      return;
    }

    const finalDesignation = newEmployee.designation === 'Custom Designation'
      ? (newEmployee.customDesignation || 'Officer')
      : newEmployee.designation;

    const nextCode = `EMP-00${employees.length + 1}`;
    const salaryAmount = Number(newEmployee.monthlySalary) || 0;

    const created: Employee = {
      id: `emp-${Date.now()}`,
      empCode: nextCode,
      name: newEmployee.name.trim(),
      department: 'Sales & Distribution',
      designation: finalDesignation,
      joiningDate: new Date().toISOString().split('T')[0],
      branch: newEmployee.branch,
      phone: newEmployee.phone || '+880 1700 000000',
      basicSalary: salaryAmount,
      houseRent: 0,
      conveyance: 0,
      medicalAllowance: 0,
      grossSalary: salaryAmount,
      pfDeduction: 0,
      taxDeduction: 0,
      bankAccount: newEmployee.paymentMethod,
      status: 'Active'
    };

    setEmployees([...employees, created]);

    // Also add to current month's salary records
    const newSalaryRec: MonthlySalaryRecord = {
      id: `sal-${Date.now()}`,
      employeeId: created.id,
      employeeName: created.name,
      empCode: created.empCode,
      designation: created.designation,
      branch: created.branch || 'Burimari Office',
      phone: created.phone || '',
      monthlySalary: salaryAmount,
      bonus: 0,
      deduction: 0,
      netPayable: salaryAmount,
      paidAmount: 0,
      dueAmount: salaryAmount,
      month: selectedMonth,
      status: 'Unpaid',
      paymentMethod: newEmployee.paymentMethod,
      payments: []
    };

    setSalaryRecords([...salaryRecords, newSalaryRec]);
    setShowAddEmpModal(false);
    setNewEmployee({
      name: '',
      designation: '',
      customDesignation: '',
      branch: '',
      phone: '',
      monthlySalary: 0,
      paymentMethod: '' as any
    });

    triggerToast(`✓ Employee ${created.name} (${created.empCode}) added successfully!`);
  };

  // Disburse all remaining dues for the month
  const handleDisburseAllRemainingDues = () => {
    const today = new Date().toISOString().split('T')[0];
    let updatedCount = 0;

    setSalaryRecords(salaryRecords.map(rec => {
      if (rec.month === selectedMonth && rec.dueAmount > 0) {
        updatedCount++;
        const settlementTx: SalaryPaymentTransaction = {
          id: `tx-settle-${rec.id}-${Date.now()}`,
          amount: rec.dueAmount,
          date: today,
          paymentMethod: rec.paymentMethod,
          paymentType: 'Remaining Settlement',
          note: 'Final settlement of remaining monthly salary due'
        };

        return {
          ...rec,
          paidAmount: rec.netPayable,
          dueAmount: 0,
          status: 'Paid',
          lastPaymentDate: today,
          payments: [...rec.payments, settlementTx]
        };
      }
      return rec;
    }));

    triggerToast(`✓ Settled remaining salary dues for ${updatedCount} employees for ${selectedMonth}!`);
  };

  // Filtered employees list
  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const matchSearch = 
        emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.empCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.designation.toLowerCase().includes(searchQuery.toLowerCase());
      const matchBranch = branchFilter === 'All' || emp.branch === branchFilter;
      return matchSearch && matchBranch;
    });
  }, [employees, searchQuery, branchFilter]);

  // Filtered salary records for active month and branch and status
  const filteredSalaryRecords = useMemo(() => {
    return salaryRecords.filter(rec => {
      const matchMonth = rec.month === selectedMonth;
      const matchBranch = branchFilter === 'All' || rec.branch === branchFilter;
      const matchStatus = statusFilter === 'All' || rec.status === statusFilter;
      const matchSearch = 
        rec.employeeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.empCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.designation.toLowerCase().includes(searchQuery.toLowerCase());
      return matchMonth && matchBranch && matchStatus && matchSearch;
    });
  }, [salaryRecords, selectedMonth, branchFilter, statusFilter, searchQuery]);

  // Totals calculations
  const totalEmployeesCount = employees.length;
  const totalMonthlyBill = useMemo(() => {
    return salaryRecords
      .filter(r => r.month === selectedMonth && (branchFilter === 'All' || r.branch === branchFilter))
      .reduce((sum, r) => sum + r.netPayable, 0);
  }, [salaryRecords, selectedMonth, branchFilter]);

  const totalPaidAmount = useMemo(() => {
    return salaryRecords
      .filter(r => r.month === selectedMonth && (branchFilter === 'All' || r.branch === branchFilter))
      .reduce((sum, r) => sum + r.paidAmount, 0);
  }, [salaryRecords, selectedMonth, branchFilter]);

  const totalDueAmount = totalMonthlyBill - totalPaidAmount;
  const partialCount = salaryRecords.filter(r => r.month === selectedMonth && r.status === 'Partial').length;
  const paidCount = salaryRecords.filter(r => r.month === selectedMonth && r.status === 'Paid').length;
  const unpaidCount = salaryRecords.filter(r => r.month === selectedMonth && r.status === 'Unpaid').length;

  return (
    <div className="space-y-5">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* HEADER BANNER                                                             */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-[28px] p-6 shadow-xs border border-white/60">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span>Employees & Monthly Payroll</span>
            </h1>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setShowAddEmpModal(true)}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <UserPlus className="w-4 h-4 text-lime-400" />
              <span>+ Add Employee</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('salary_sheet');
                setShowSalaryReportModal(true);
              }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <FileText className="w-4 h-4 text-slate-600" />
              <span>Print Salary Report</span>
            </button>

            <button
              type="button"
              onClick={handleDisburseAllRemainingDues}
              className="px-4 py-2 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 rounded-2xl text-xs font-black transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Check className="w-4 h-4 text-slate-950 stroke-[2.5]" />
              <span>Settle All Remaining Dues</span>
            </button>
          </div>
        </div>

        {/* 4 Summary Stat Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-5 mt-5 border-t border-slate-100">
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3.5">
            <span className="text-[11px] text-slate-500 font-medium block">Total Workforce</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-xl font-black text-slate-900 font-sans tracking-tight">
                {totalEmployeesCount}
              </span>
              <span className="text-[10px] text-slate-500 font-medium">Staff</span>
            </div>
          </div>

          <div className="bg-[#fef5ea] border border-[#fedec2]/80 rounded-2xl p-3.5">
            <span className="text-[11px] text-slate-500 font-medium block">Monthly Salary Budget ({selectedMonth})</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-xl font-black text-slate-900 font-sans tracking-tight">
                ৳{(totalMonthlyBill / 1000).toFixed(0)}K
              </span>
              <span className="text-[10px] text-amber-700 font-semibold">Total Payable</span>
            </div>
          </div>

          <div className="bg-[#eaf9f7] border border-[#ccf3ec]/80 rounded-2xl p-3.5">
            <span className="text-[11px] text-slate-500 font-medium block">Total Paid / Withdrawn</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-xl font-black text-emerald-700 font-sans tracking-tight">
                ৳{(totalPaidAmount / 1000).toFixed(0)}K
              </span>
              <span className="text-[10px] text-emerald-700 font-semibold">
                ({paidCount} Full, {partialCount} Partial)
              </span>
            </div>
          </div>

          <div className="bg-rose-50/70 border border-rose-200/80 rounded-2xl p-3.5">
            <span className="text-[11px] text-slate-500 font-medium block">Remaining Salary Due</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-xl font-black text-rose-700 font-sans tracking-tight">
                ৳{(totalDueAmount / 1000).toFixed(0)}K
              </span>
              <span className="text-[10px] text-rose-700 font-semibold">
                ({unpaidCount + partialCount} Employees Due)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* FILTERS BAR                                                               */}
      {/* ========================================================================= */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white/90 border border-slate-200/80 rounded-2xl p-3 shadow-xs select-none">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-900 font-sans">
            {activeTab === 'salary_sheet' ? 'Monthly Payroll & Advances' : `Employee Directory (${employees.length} Staff)`}
          </span>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {activeTab === 'salary_sheet' && (
            <>
              {/* Month Picker */}
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 rounded-xl px-2.5 py-1 text-xs">
                <span className="text-[11px] text-slate-500 font-semibold">Month:</span>
                <input
                  type="month"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="bg-transparent font-mono text-slate-800 text-xs outline-none cursor-pointer"
                />
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 rounded-xl px-2.5 py-1 text-xs">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="bg-transparent font-medium text-slate-700 outline-none cursor-pointer text-xs"
                >
                  <option value="All">All Statuses</option>
                  <option value="Partial">Partially Paid ({partialCount})</option>
                  <option value="Unpaid">Unpaid ({unpaidCount})</option>
                  <option value="Paid">Fully Paid ({paidCount})</option>
                </select>
              </div>
            </>
          )}

          {/* Branch Filter */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 rounded-xl px-2.5 py-1 text-xs">
            <Building2 className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={branchFilter}
              onChange={(e) => setBranchFilter(e.target.value)}
              className="bg-transparent font-medium text-slate-700 outline-none cursor-pointer text-xs"
            >
              <option value="All">All Branches</option>
              <option value="Burimari Office">Burimari Office</option>
              <option value="Sonahat Office">Sonahat Office</option>
              <option value="Head Office (Dhaka)">Head Office (Dhaka)</option>
            </select>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* VIEW 1: PAYROLL & SALARY SHEET WITH PARTIAL ADVANCES                     */}
      {/* ========================================================================= */}
      {activeTab === 'salary_sheet' && (
        <div className="bg-white rounded-[28px] p-5 sm:p-6 shadow-xs border border-white/60 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 tracking-tight">
                  Salary Sheet & Advance Ledger ({selectedMonth})
                </h2>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {branchFilter === 'All' ? 'All Branches' : branchFilter}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowSalaryReportModal(true)}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-slate-600" />
                <span>Print Report</span>
              </button>

              <button
                type="button"
                onClick={handleDisburseAllRemainingDues}
                className="px-3.5 py-1.5 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 rounded-xl text-xs font-black transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Pay Remaining Dues</span>
              </button>
            </div>
          </div>

          {/* Salary Sheet Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200/80">
                <tr>
                  <th className="py-3 px-3">Employee Details</th>
                  <th className="py-3 px-3">Designation</th>
                  <th className="py-3 px-3">Branch</th>
                  <th className="py-3 px-3 text-right">Monthly Salary</th>
                  <th className="py-3 px-3 text-right text-emerald-700">Paid / Withdrawn</th>
                  <th className="py-3 px-3 text-right text-rose-600">Remaining Due</th>
                  <th className="py-3 px-3 text-center">Installments</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-slate-800">
                {filteredSalaryRecords.map((item) => {
                  const isFullyPaid = item.status === 'Paid';
                  const isPartial = item.status === 'Partial';
                  const isUnpaid = item.status === 'Unpaid';

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-3 px-3 font-sans">
                        <div className="font-bold text-slate-900">{item.employeeName}</div>
                        <div className="text-[10px] text-blue-600 font-mono font-semibold">{item.empCode}</div>
                      </td>
                      <td className="py-3 px-3 font-sans font-medium text-slate-700">
                        {item.designation}
                      </td>
                      <td className="py-3 px-3 font-sans text-slate-500 text-[11px]">
                        {item.branch}
                      </td>
                      <td className="py-3 px-3 text-right font-semibold">
                        ৳{item.monthlySalary.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-3 text-right text-emerald-700 font-bold">
                        {item.paidAmount > 0 ? `৳${item.paidAmount.toLocaleString('en-IN')}` : '—'}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-rose-600">
                        {item.dueAmount > 0 ? `৳${item.dueAmount.toLocaleString('en-IN')}` : '৳0 (Paid)'}
                      </td>
                      <td className="py-3 px-3 text-center font-sans">
                        {item.payments.length > 0 ? (
                          <button
                            type="button"
                            onClick={() => setSelectedHistoryRecord(item)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold text-[11px] transition-colors cursor-pointer"
                            title="View Payment History"
                          >
                            <History className="w-3 h-3" />
                            <span>{item.payments.length}</span>
                          </button>
                        ) : (
                          <span className="text-slate-400 text-[11px]">0</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-center font-sans">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          isFullyPaid
                            ? 'bg-emerald-100 text-emerald-800'
                            : isPartial
                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {isFullyPaid && <CheckCircle2 className="w-3 h-3" />}
                          {isPartial && <Clock className="w-3 h-3 text-amber-600" />}
                          {isUnpaid && <AlertCircle className="w-3 h-3" />}
                          <span>
                            {isFullyPaid ? 'Paid' : isPartial ? 'Partial' : 'Unpaid'}
                          </span>
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center font-sans">
                        <div className="flex items-center justify-center gap-1.5">
                          {item.dueAmount > 0 ? (
                            <button
                              type="button"
                              onClick={() => handleOpenPaymentModal(item)}
                              className="px-2.5 py-1 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 font-bold rounded-lg text-[11px] transition-colors cursor-pointer shadow-xs flex items-center gap-1"
                            >
                              <Wallet className="w-3 h-3" />
                              <span>{isPartial ? 'Pay Balance' : 'Pay / Advance'}</span>
                            </button>
                          ) : (
                            <span className="text-[10px] text-emerald-700 font-semibold px-2 py-0.5 bg-emerald-50 rounded">
                              ✓ Paid
                            </span>
                          )}

                          <button
                            type="button"
                            onClick={() => setSelectedPayslipRecord(item)}
                            className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-[11px] transition-colors cursor-pointer"
                            title="View Payslip"
                          >
                            Slip
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VIEW 2: EMPLOYEES DIRECTORY                                               */}
      {/* ========================================================================= */}
      {activeTab === 'employees' && (
        <div className="space-y-4">
          {/* Search bar & quick action */}
          <div className="bg-white rounded-[24px] p-4 shadow-xs border border-white/60 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 flex-1 max-w-md bg-slate-50 border border-slate-200/80 rounded-xl px-3 py-2">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                placeholder="Search by name, designation or code..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent outline-none text-slate-800 text-xs"
              />
            </div>

            <button
              type="button"
              onClick={() => setShowAddEmpModal(true)}
              className="px-4 py-2 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Employee</span>
            </button>
          </div>

          {/* Employees Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredEmployees.map((emp) => {
              const rec = salaryRecords.find(r => (r.employeeId === emp.id || r.empCode === emp.empCode) && r.month === selectedMonth);

              return (
                <div
                  key={emp.id}
                  className="bg-white rounded-[24px] p-5 shadow-xs border border-white/60 space-y-3.5 hover:shadow-md transition-all text-xs"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-900 text-white font-black text-sm flex items-center justify-center shadow-xs">
                        {emp.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-slate-900">{emp.name}</h3>
                        <span className="font-mono text-[10px] text-blue-600 font-semibold block">
                          {emp.empCode}
                        </span>
                      </div>
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      {emp.status}
                    </span>
                  </div>

                  <div className="space-y-1 text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <Briefcase className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-bold text-slate-800 text-xs">{emp.designation}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                      <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{emp.branch || 'Burimari Office'}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{emp.phone || '+880 1711 000000'}</span>
                    </div>
                  </div>

                  <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between font-mono text-xs">
                    <span className="text-slate-500 font-sans text-[11px]">Monthly Salary:</span>
                    <span className="font-black text-slate-900 text-sm">
                      ৳{emp.grossSalary.toLocaleString('en-IN')}
                    </span>
                  </div>

                  {rec && (
                    <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1 font-mono text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-slate-500 font-sans">Paid This Month:</span>
                        <span className="font-bold text-emerald-700">৳{rec.paidAmount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500 font-sans">Remaining Due:</span>
                        <span className="font-bold text-rose-600">৳{rec.dueAmount.toLocaleString()}</span>
                      </div>
                    </div>
                  )}

                  <div className="pt-1 flex items-center gap-2">
                    {rec && rec.dueAmount > 0 && (
                      <button
                        type="button"
                        onClick={() => handleOpenPaymentModal(rec)}
                        className="flex-1 py-2 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 rounded-xl font-bold transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-1"
                      >
                        <Wallet className="w-3.5 h-3.5" />
                        <span>Pay / Advance</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        if (rec) {
                          setSelectedPayslipRecord(rec);
                        }
                      }}
                      className="flex-1 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200/80 rounded-xl font-semibold text-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5 text-slate-500" />
                      <span>View Payslip</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: PARTIAL / ADVANCE PAYMENT ENTRY                                  */}
      {/* ========================================================================= */}
      {selectedPaymentRecord && (
        <ModalWrapper
          isOpen={Boolean(selectedPaymentRecord)}
          onClose={handleClosePaymentModal}
          isDirty={isPaymentDirty}
          maxWidth="max-w-lg"
        >
          <div className="bg-white rounded-[28px] shadow-2xl max-w-lg w-full p-6 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-slate-900" />
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Salary Payment or Advance Withdrawal</h3>
                  <p className="text-[11px] text-slate-500">
                    {selectedPaymentRecord.employeeName} ({selectedPaymentRecord.empCode}) • {selectedPaymentRecord.month}
                  </p>
                </div>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={handleClosePaymentModal}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            {/* Current Salary Balance Card */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                  <span className="text-[10px] text-slate-500 block">Monthly Salary</span>
                  <span className="font-black text-slate-900 font-mono text-sm">
                    ৳{selectedPaymentRecord.netPayable.toLocaleString()}
                  </span>
                </div>
                <div className="bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-200/80">
                  <span className="text-[10px] text-emerald-800 block">Already Paid</span>
                  <span className="font-black text-emerald-700 font-mono text-sm">
                    ৳{selectedPaymentRecord.paidAmount.toLocaleString()}
                  </span>
                </div>
                <div className="bg-rose-50/60 p-2.5 rounded-xl border border-rose-200/80">
                  <span className="text-[10px] text-rose-800 block">Current Remaining Due</span>
                  <span className="font-black text-rose-600 font-mono text-sm">
                    ৳{selectedPaymentRecord.dueAmount.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            <form onSubmit={handlePaymentSubmit} autoComplete="off" className="space-y-3.5 text-xs">
              {/* Payment Type Selection */}
              <div>
                <label className="block text-slate-700 font-semibold mb-1.5">
                  Select Payment Type <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentForm({
                        ...paymentForm,
                        paymentType: 'Advance',
                        amount: Math.min(selectedPaymentRecord.dueAmount, 10000),
                        note: 'Salary advance'
                      });
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      paymentForm.paymentType === 'Advance'
                        ? 'bg-amber-50 border-amber-400 text-amber-950 font-bold shadow-xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="font-bold flex items-center gap-1">
                      <span>🟡 Advance / Partial Installment</span>
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Mid-month partial withdrawal</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPaymentForm({
                        ...paymentForm,
                        paymentType: 'Remaining Settlement',
                        amount: selectedPaymentRecord.dueAmount,
                        note: 'Full settlement of remaining salary due'
                      });
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      paymentForm.paymentType === 'Remaining Settlement' || paymentForm.paymentType === 'Full Payment'
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-bold shadow-xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="font-bold flex items-center gap-1">
                      <span>🟢 Full Remaining Due</span>
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      Settle full ৳{selectedPaymentRecord.dueAmount.toLocaleString()} at once
                    </span>
                  </button>
                </div>
              </div>

              {/* Amount Input */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-700 font-semibold">
                    Amount (BDT) <span className="text-rose-500">*</span>
                  </label>
                  <span className="text-[11px] text-slate-500">
                    Maximum Payable: <strong className="font-mono text-slate-800">৳{selectedPaymentRecord.dueAmount.toLocaleString()}</strong>
                  </span>
                </div>
                <input
                  type="number"
                  required
                  min={1}
                  max={selectedPaymentRecord.dueAmount}
                  value={paymentForm.amount || ''}
                  onChange={(e) => setPaymentForm({ ...paymentForm, amount: Number(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 outline-none font-mono font-black text-slate-900 text-base"
                />

                {/* Quick Amount Buttons */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {[5000, 10000, 15000, 20000].map(amt => {
                    if (amt <= selectedPaymentRecord.dueAmount) {
                      return (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => setPaymentForm({ ...paymentForm, amount: amt })}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-mono rounded-lg text-[11px] transition-colors cursor-pointer"
                        >
                          +৳{amt.toLocaleString()}
                        </button>
                      );
                    }
                    return null;
                  })}
                  <button
                    type="button"
                    onClick={() => setPaymentForm({ ...paymentForm, amount: selectedPaymentRecord.dueAmount })}
                    className="px-2.5 py-1 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 font-bold rounded-lg text-[11px] transition-colors cursor-pointer"
                  >
                    Full Due (৳{selectedPaymentRecord.dueAmount.toLocaleString()})
                  </button>
                </div>
              </div>

              {/* Date and Payment Method */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Payment Date</label>
                  <input
                    type="date"
                    required
                    value={paymentForm.paymentDate}
                    onChange={(e) => setPaymentForm({ ...paymentForm, paymentDate: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none font-mono text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Payment Method</label>
                  <select
                    value={paymentForm.paymentMethod}
                    onChange={(e) => setPaymentForm({ ...paymentForm, paymentMethod: e.target.value as any })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none cursor-pointer font-medium text-slate-800"
                  >
                    <option value="">Select Payment Method...</option>
                    <option value="Cash">Cash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="bKash/Nagad">bKash / Nagad (Mobile Banking)</option>
                  </select>
                </div>
              </div>

              {/* Note / Remarks */}
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Note / Reason</label>
                <input
                  type="text"
                  placeholder="e.g. Advance of 10,000 BDT on the 15th"
                  value={paymentForm.note}
                  onChange={(e) => setPaymentForm({ ...paymentForm, note: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none text-slate-800"
                />
              </div>

              {/* Previous Payments in this month */}
              {selectedPaymentRecord.payments.length > 0 && (
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
                  <span className="font-bold text-slate-800 block text-[11px]">
                    Previous Installments This Month:
                  </span>
                  <div className="space-y-1 max-h-24 overflow-y-auto">
                    {selectedPaymentRecord.payments.map((p, idx) => (
                      <div key={p.id || idx} className="flex items-center justify-between text-[11px] bg-white p-1.5 rounded-lg border border-slate-100">
                        <span className="font-mono text-slate-500">{p.date} • {p.paymentMethod}</span>
                        <span className="font-bold text-emerald-700 font-mono">৳{p.amount.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleClosePaymentModal}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 font-black rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>Confirm Payment</span>
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: PAYMENT HISTORY DRAWER / VIEW                                    */}
      {/* ========================================================================= */}
      {selectedHistoryRecord && (
        <ModalWrapper
          isOpen={Boolean(selectedHistoryRecord)}
          onClose={() => setSelectedHistoryRecord(null)}
          isDirty={false}
          maxWidth="max-w-md"
        >
          <div className="bg-white rounded-[28px] shadow-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="font-bold text-slate-900 text-base">Advance & Salary Installment History</h3>
                <p className="text-[11px] text-slate-500">
                  {selectedHistoryRecord.employeeName} ({selectedHistoryRecord.empCode}) • {selectedHistoryRecord.month}
                </p>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setSelectedHistoryRecord(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 grid grid-cols-3 gap-2 text-center text-xs font-mono">
              <div>
                <span className="text-[10px] text-slate-500 font-sans block">Net Payable</span>
                <span className="font-bold text-slate-900">৳{selectedHistoryRecord.netPayable.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-[10px] text-emerald-700 font-sans block">Total Paid</span>
                <span className="font-bold text-emerald-700">৳{selectedHistoryRecord.paidAmount.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-[10px] text-rose-700 font-sans block">Remaining Due</span>
                <span className="font-bold text-rose-600">৳{selectedHistoryRecord.dueAmount.toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <span className="font-bold text-slate-800 text-xs block">All Transactions / Withdrawals:</span>
              {selectedHistoryRecord.payments.length === 0 ? (
                <p className="text-slate-400 py-3 text-center">No payments or withdrawals recorded yet.</p>
              ) : (
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {selectedHistoryRecord.payments.map((p, idx) => (
                    <div key={p.id || idx} className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{p.paymentType}</span>
                        <span className="font-mono font-black text-emerald-700 text-sm">৳{p.amount.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                        <span>Date: {p.date}</span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 font-sans text-slate-700">{p.paymentMethod}</span>
                      </div>
                      {p.note && (
                        <p className="text-[11px] text-slate-600 italic pt-1 border-t border-slate-100">
                          "{p.note}"
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              {selectedHistoryRecord.dueAmount > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    const rec = selectedHistoryRecord;
                    setSelectedHistoryRecord(null);
                    handleOpenPaymentModal(rec);
                  }}
                  className="px-4 py-2 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Wallet className="w-3.5 h-3.5" />
                  <span>Add Payment / Installment</span>
                </button>
              )}
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setSelectedHistoryRecord(null)}
                className="ml-auto px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-semibold text-xs hover:bg-slate-50"
              >
                Close
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: ADD NEW EMPLOYEE                                                 */}
      {/* ========================================================================= */}
      {showAddEmpModal && (
        <ModalWrapper
          isOpen={showAddEmpModal}
          onClose={handleCloseAddEmpModal}
          isDirty={isAddEmpDirty}
          maxWidth="max-w-lg"
        >
          <div className="bg-white rounded-[28px] shadow-2xl max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-slate-900" />
                <h3 className="font-bold text-slate-900 text-base">Add New Employee</h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={handleCloseAddEmpModal}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddEmployeeSubmit} autoComplete="off" className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Md. Rafiqul Islam"
                  value={newEmployee.name}
                  onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none font-medium text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Designation <span className="text-rose-500">*</span>
                </label>
                <select
                  value={newEmployee.designation}
                  onChange={(e) => setNewEmployee({ ...newEmployee, designation: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none cursor-pointer font-medium text-slate-800"
                >
                  <option value="">Select Designation...</option>
                  {designationOptions.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>

                {newEmployee.designation === 'Custom Designation' && (
                  <input
                    type="text"
                    required
                    placeholder="Enter designation (e.g. Security Incharge)"
                    value={newEmployee.customDesignation}
                    onChange={(e) => setNewEmployee({ ...newEmployee, customDesignation: e.target.value })}
                    className="w-full mt-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none font-medium text-slate-800"
                  />
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Branch / Office</label>
                  <select
                    value={newEmployee.branch}
                    onChange={(e) => setNewEmployee({ ...newEmployee, branch: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none cursor-pointer font-medium text-slate-800"
                  >
                    <option value="">Select Branch...</option>
                    <option value="Burimari Office">Burimari Office</option>
                    <option value="Sonahat Office">Sonahat Office</option>
                    <option value="Head Office (Dhaka)">Head Office (Dhaka)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Mobile Number</label>
                  <input
                    type="text"
                    placeholder="01711-xxxxxx"
                    value={newEmployee.phone}
                    onChange={(e) => setNewEmployee({ ...newEmployee, phone: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Monthly Salary (BDT) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={newEmployee.monthlySalary || ''}
                    onChange={(e) => setNewEmployee({ ...newEmployee, monthlySalary: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Payment Method</label>
                  <select
                    value={newEmployee.paymentMethod}
                    onChange={(e) => setNewEmployee({ ...newEmployee, paymentMethod: e.target.value as any })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none cursor-pointer font-medium text-slate-800"
                  >
                    <option value="">Select Payment Method...</option>
                    <option value="Cash">Cash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="bKash/Nagad">bKash / Nagad (Mobile Banking)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleCloseAddEmpModal}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 font-bold rounded-xl shadow-xs transition-colors"
                >
                  Save Employee
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: FULL PRINTABLE SALARY REPORT WITH ADVANCE BREAKDOWN              */}
      {/* ========================================================================= */}
      {showSalaryReportModal && (
        <ModalWrapper
          isOpen={showSalaryReportModal}
          onClose={() => setShowSalaryReportModal(false)}
          isDirty={false}
          maxWidth="max-w-4xl"
        >
          <div className="bg-white rounded-[28px] shadow-2xl max-w-4xl w-full p-6 space-y-4 max-h-[92vh] overflow-y-auto">
            {/* Modal Actions */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="text-xs font-bold uppercase text-slate-500">Official Salary Statement & Advance Log</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-1.5 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={() => setShowSalaryReportModal(false)}
                  className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold text-xs"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Printable Report Document */}
            <div className="p-6 bg-white border border-slate-300 rounded-2xl space-y-4 font-sans text-xs">
              <div className="text-center pb-4 border-b border-slate-300">
                <h2 className="text-xl font-black text-slate-900 uppercase tracking-wide">
                  {companyProfile.companyName}
                </h2>
                <p className="text-slate-600 text-xs mt-0.5">
                  {companyProfile.address} • Mobile: {companyProfile.mobile}
                </p>
                <h3 className="text-sm font-bold text-slate-800 mt-2">
                  Monthly Salary & Advance Statement
                </h3>
                <p className="text-slate-500 font-mono text-[11px]">
                  Month: {selectedMonth} | Branch: {branchFilter === 'All' ? 'All Branches Consolidated' : branchFilter}
                </p>
              </div>

              {/* Table */}
              <table className="w-full text-left border-collapse border border-slate-300 text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-800">
                    <th className="border border-slate-300 p-2">#</th>
                    <th className="border border-slate-300 p-2">Code</th>
                    <th className="border border-slate-300 p-2">Employee Name</th>
                    <th className="border border-slate-300 p-2">Designation</th>
                    <th className="border border-slate-300 p-2">Branch</th>
                    <th className="border border-slate-300 p-2 text-right">Monthly Salary</th>
                    <th className="border border-slate-300 p-2 text-right text-emerald-800">Paid / Withdrawn</th>
                    <th className="border border-slate-300 p-2 text-right text-rose-800">Remaining Due</th>
                    <th className="border border-slate-300 p-2 text-center">Status</th>
                    <th className="border border-slate-300 p-2 text-center">Signature</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {filteredSalaryRecords.map((r, index) => (
                    <tr key={r.id}>
                      <td className="border border-slate-300 p-2 text-center">{index + 1}</td>
                      <td className="border border-slate-300 p-2 text-blue-700 font-bold">{r.empCode}</td>
                      <td className="border border-slate-300 p-2 font-sans font-bold text-slate-900">{r.employeeName}</td>
                      <td className="border border-slate-300 p-2 font-sans text-slate-700">{r.designation}</td>
                      <td className="border border-slate-300 p-2 font-sans text-slate-600">{r.branch}</td>
                      <td className="border border-slate-300 p-2 text-right">৳{r.monthlySalary.toLocaleString()}</td>
                      <td className="border border-slate-300 p-2 text-right text-emerald-700 font-bold">
                        ৳{r.paidAmount.toLocaleString()}
                      </td>
                      <td className="border border-slate-300 p-2 text-right font-black text-rose-600">
                        ৳{r.dueAmount.toLocaleString()}
                      </td>
                      <td className="border border-slate-300 p-2 text-center font-sans">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          r.status === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : r.status === 'Partial'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {r.status === 'Paid' ? 'Paid' : r.status === 'Partial' ? 'Partial' : 'Unpaid'}
                        </span>
                      </td>
                      <td className="border border-slate-300 p-2 text-center text-slate-300">
                        ____________
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-slate-50 font-bold text-slate-900">
                    <td colSpan={5} className="border border-slate-300 p-2 text-right font-sans">
                      Total:
                    </td>
                    <td className="border border-slate-300 p-2 text-right font-black">
                      ৳{totalMonthlyBill.toLocaleString()}
                    </td>
                    <td className="border border-slate-300 p-2 text-right font-black text-emerald-700">
                      ৳{totalPaidAmount.toLocaleString()}
                    </td>
                    <td className="border border-slate-300 p-2 text-right font-black text-rose-600">
                      ৳{totalDueAmount.toLocaleString()}
                    </td>
                    <td colSpan={2} className="border border-slate-300 p-2 text-center text-[10px] text-slate-600">
                      Paid Rate: {totalMonthlyBill > 0 ? ((totalPaidAmount / totalMonthlyBill) * 100).toFixed(1) : 0}%
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Signatures */}
              <div className="grid grid-cols-3 gap-6 pt-12 text-center text-[11px] text-slate-700">
                <div>
                  <div className="border-t border-slate-400 pt-1 font-semibold">Prepared By (Accountant)</div>
                </div>
                <div>
                  <div className="border-t border-slate-400 pt-1 font-semibold">Verified By (HR Manager)</div>
                </div>
                <div>
                  <div className="border-t border-slate-400 pt-1 font-semibold">Managing Director / Owner</div>
                </div>
              </div>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: INDIVIDUAL PAYSLIP WITH INSTALLMENT HISTORY                      */}
      {/* ========================================================================= */}
      {selectedPayslipRecord && (
        <ModalWrapper
          isOpen={Boolean(selectedPayslipRecord)}
          onClose={() => setSelectedPayslipRecord(null)}
          isDirty={false}
          maxWidth="max-w-md"
        >
          <div className="bg-white rounded-[28px] shadow-2xl max-w-md w-full p-6 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="text-xs font-bold uppercase text-slate-500">Employee Payslip & Payment Receipt</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1 shadow-xs cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={() => setSelectedPayslipRecord(null)}
                  className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold text-xs"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="border border-slate-200 rounded-2xl p-5 space-y-3 bg-white text-xs">
              <div className="text-center pb-3 border-b border-slate-200">
                <h3 className="font-black text-slate-900 text-sm">{companyProfile.companyName}</h3>
                <p className="text-[10px] text-slate-500">{companyProfile.address} • Mobile: {companyProfile.mobile}</p>
                <span className="inline-block mt-1 font-mono font-bold bg-slate-100 text-slate-800 px-2.5 py-0.5 rounded-md text-[11px]">
                  Month: {selectedPayslipRecord.month}
                </span>
              </div>

              <div className="space-y-1 text-slate-700">
                <div className="flex justify-between">
                  <span className="text-slate-400">Name:</span>
                  <span className="font-bold text-slate-900">{selectedPayslipRecord.employeeName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Employee Code:</span>
                  <span className="font-mono text-blue-700 font-bold">{selectedPayslipRecord.empCode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Designation:</span>
                  <span className="font-semibold text-slate-800">{selectedPayslipRecord.designation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Branch:</span>
                  <span className="text-slate-800">{selectedPayslipRecord.branch}</span>
                </div>
              </div>

              {/* Installments Breakdown */}
              <div className="pt-2 border-t border-slate-200 space-y-1.5 font-mono">
                <div className="flex justify-between text-slate-800">
                  <span className="font-sans text-slate-500">Monthly Salary:</span>
                  <span className="font-bold">৳{selectedPayslipRecord.monthlySalary.toLocaleString()}</span>
                </div>

                {selectedPayslipRecord.payments.length > 0 && (
                  <div className="p-2.5 bg-slate-50 rounded-xl space-y-1 text-[11px]">
                    <span className="font-bold text-slate-700 font-sans block text-[10px]">
                      Installments Paid:
                    </span>
                    {selectedPayslipRecord.payments.map((p, i) => (
                      <div key={i} className="flex justify-between text-slate-600">
                        <span>• {p.date} ({p.paymentMethod}):</span>
                        <span className="font-bold text-emerald-700">৳{p.amount.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex justify-between text-emerald-700 font-bold pt-1">
                  <span className="font-sans">Total Paid / Withdrawn:</span>
                  <span>৳{selectedPayslipRecord.paidAmount.toLocaleString()}</span>
                </div>

                <div className="flex justify-between text-rose-600 font-black text-sm pt-1 border-t border-slate-200">
                  <span className="font-sans">Remaining Salary Due:</span>
                  <span>৳{selectedPayslipRecord.dueAmount.toLocaleString()}</span>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between text-[10px] text-slate-400">
                <div>Employee Signature</div>
                <div>Authorized Signature</div>
              </div>
            </div>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
