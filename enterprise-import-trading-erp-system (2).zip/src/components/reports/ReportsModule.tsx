import React, { useState, useMemo, useEffect } from 'react';
import { 
  TrendingUp, 
  ShoppingCart, 
  CreditCard, 
  Warehouse, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  Calendar, 
  ChevronRight, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowUpRight, 
  ArrowDownRight, 
  Hammer, 
  DollarSign, 
  Layers, 
  Boxes, 
  Package, 
  PieChart, 
  Award, 
  BarChart3, 
  ExternalLink,
  Sparkles,
  Building2,
  RefreshCw,
  X,
  Eye,
  Plus,
  Truck,
  FileText,
  Scale
} from 'lucide-react';
import { 
  SalesInvoice, 
  DirectPurchaseInvoice, 
  InventoryItem, 
  Warehouse as WarehouseType, 
  AccountCOA, 
  JournalVoucher,
  ModuleTab
} from '../../types/erp';
import { 
  MOCK_SALES_INVOICES, 
  MOCK_DIRECT_PURCHASE_INVOICES, 
  MOCK_JOURNAL_VOUCHERS 
} from '../../data/mockErpData';
import { getItems, subscribeItems } from '../../utils/itemStorage';
import { getWarehouses, subscribeWarehouses } from '../../utils/locationStorage';
import { getCOA, saveCOA, subscribeCOA } from '../../utils/coaStorage';
import { getSalesInvoices, subscribeSalesInvoices } from '../../utils/salesStorage';
import { getVouchers, addVoucher, subscribeVouchers } from '../../utils/voucherStorage';
import {
  getAccountTransactions,
  subscribeAccountTransactions,
  getAccountLedgers,
  subscribeAccountLedgers,
  getAccountHeads
} from '../../services/accountService';
import { AccountTransaction, AccountLedgerEntry } from '../../types/accounts';
import { VoucherPrintModal } from '../accounts/VoucherPrintModal';
import { PrintableInvoiceModal } from '../sales/PrintableInvoiceModal';
import { ModalWrapper } from '../common/ModalWrapper';

export type ReportSubTab = 
  | 'sales_reports'
  | 'purchase_reports'
  | 'expense_reports'
  | 'stock_reports';

export type DatePreset = 
  | 'all' 
  | 'today' 
  | 'yesterday' 
  | 'week' 
  | 'month' 
  | 'last_month' 
  | 'year' 
  | 'custom';

export interface ReportsModuleProps {
  currentBranch?: string;
  currency?: string;
  initialReport?: ReportSubTab;
  activeSubTab?: ReportSubTab;
  onSubTabChange?: (tab: ReportSubTab) => void;
  onNavigateTab?: (tab: ModuleTab) => void;
}

interface ReportDateFilterBarProps {
  dateRange: DatePreset;
  setDateRange: (preset: DatePreset) => void;
  customStartDate: string;
  setCustomStartDate: (d: string) => void;
  customEndDate: string;
  setCustomEndDate: (d: string) => void;
  colorTheme?: 'blue' | 'emerald' | 'amber' | 'indigo';
}

const ReportDateFilterBar: React.FC<ReportDateFilterBarProps> = ({
  dateRange,
  setDateRange,
  customStartDate,
  setCustomStartDate,
  customEndDate,
  setCustomEndDate,
  colorTheme = 'blue'
}) => {
  const isCustom = dateRange === 'custom';

  const themeClasses = {
    blue: {
      badge: 'bg-blue-100 text-blue-900 border-blue-200',
      activeBtn: 'bg-blue-600 text-white shadow-xs',
      focus: 'focus:ring-blue-500 focus:border-blue-500',
      icon: 'text-blue-600',
      pillBg: 'bg-blue-50/50 border-blue-200'
    },
    emerald: {
      badge: 'bg-emerald-100 text-emerald-900 border-emerald-200',
      activeBtn: 'bg-emerald-600 text-white shadow-xs',
      focus: 'focus:ring-emerald-500 focus:border-emerald-500',
      icon: 'text-emerald-600',
      pillBg: 'bg-emerald-50/50 border-emerald-200'
    },
    amber: {
      badge: 'bg-amber-100 text-amber-950 border-amber-300',
      activeBtn: 'bg-amber-500 text-slate-950 font-bold shadow-xs',
      focus: 'focus:ring-amber-500 focus:border-amber-500',
      icon: 'text-amber-700',
      pillBg: 'bg-amber-50/50 border-amber-200'
    },
    indigo: {
      badge: 'bg-indigo-100 text-indigo-900 border-indigo-200',
      activeBtn: 'bg-indigo-600 text-white shadow-xs',
      focus: 'focus:ring-indigo-500 focus:border-indigo-500',
      icon: 'text-indigo-600',
      pillBg: 'bg-indigo-50/50 border-indigo-200'
    }
  }[colorTheme];

  const getDateSummaryText = () => {
    switch (dateRange) {
      case 'today': return 'Today';
      case 'yesterday': return 'Yesterday';
      case 'week': return 'Last 7 Days';
      case 'month': return 'This Month (Oct 2026)';
      case 'last_month': return 'Last Month (Sep 2026)';
      case 'year': return 'Current Fiscal Year';
      case 'custom':
        if (customStartDate && customEndDate) return `${customStartDate} to ${customEndDate}`;
        if (customStartDate) return `From ${customStartDate}`;
        if (customEndDate) return `Until ${customEndDate}`;
        return 'Custom Range (Select Dates)';
      default: return 'All Time';
    }
  };

  return (
    <div className={`p-2.5 rounded-xl border flex flex-wrap items-center justify-between gap-2.5 transition-colors ${themeClasses.pillBg}`}>
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 font-bold text-slate-800 text-xs shrink-0">
          <Calendar className={`w-4 h-4 ${themeClasses.icon}`} />
          <span>Date Filter:</span>
        </div>

        {/* Preset Select Dropdown */}
        <select
          value={dateRange}
          onChange={(e) => setDateRange(e.target.value as DatePreset)}
          className={`px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-800 outline-none cursor-pointer shadow-2xs ${themeClasses.focus}`}
        >
          <option value="all">All Time</option>
          <option value="today">Today</option>
          <option value="yesterday">Yesterday</option>
          <option value="week">Last 7 Days</option>
          <option value="month">This Month</option>
          <option value="last_month">Last Month</option>
          <option value="year">Current FY</option>
          <option value="custom">Custom Range...</option>
        </select>

        {/* Direct Button for Custom Date */}
        {!isCustom ? (
          <button
            type="button"
            onClick={() => setDateRange('custom')}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 font-medium text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
          >
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <span>Custom Date Range</span>
          </button>
        ) : (
          /* Custom Date Inputs */
          <div className="flex flex-wrap items-center gap-1.5 bg-white p-1 rounded-lg border border-slate-300 shadow-2xs">
            <div className="flex items-center gap-1 pl-1.5">
              <span className="text-[11px] text-slate-600 font-semibold">From:</span>
              <input
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className={`px-2 py-1 bg-slate-50 border border-slate-200 rounded text-xs font-mono text-slate-900 outline-none ${themeClasses.focus}`}
              />
            </div>
            <div className="flex items-center gap-1">
              <span className="text-[11px] text-slate-500 font-semibold">To:</span>
              <input
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className={`px-2 py-1 bg-slate-50 border border-slate-200 rounded text-xs font-mono text-slate-900 outline-none ${themeClasses.focus}`}
              />
            </div>

            {/* Quick Helper Button */}
            <button
              type="button"
              onClick={() => {
                setCustomStartDate('2026-09-01');
                setCustomEndDate('2026-09-30');
              }}
              className="px-2 py-1 text-[11px] font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
              title="Select September 2026"
            >
              Sep '26
            </button>

            {(customStartDate || customEndDate) && (
              <button
                type="button"
                onClick={() => {
                  setCustomStartDate('');
                  setCustomEndDate('');
                }}
                className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                title="Clear Dates"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Active Filter Pill & Reset */}
      {dateRange !== 'all' && (
        <div className="flex items-center gap-1.5 ml-auto">
          <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border flex items-center gap-1 shadow-2xs ${themeClasses.badge}`}>
            <span>Active Range: {getDateSummaryText()}</span>
          </span>
          <button
            type="button"
            onClick={() => {
              setDateRange('all');
              setCustomStartDate('');
              setCustomEndDate('');
            }}
            className="p-1 hover:bg-slate-200 rounded text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
            title="Clear filter and show all time"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};

export const ReportsModule: React.FC<ReportsModuleProps> = ({
  currentBranch = 'All Branches',
  currency = 'BDT',
  initialReport = 'sales_reports',
  activeSubTab,
  onSubTabChange,
  onNavigateTab
}) => {
  const [internalTab, setInternalTab] = useState<ReportSubTab>(initialReport);
  const activeTab = (activeSubTab as ReportSubTab) || internalTab;

  const setActiveTab = (tab: ReportSubTab) => {
    setInternalTab(tab);
    if (onSubTabChange) {
      onSubTabChange(tab);
    }
  };

  // Sub-views for Sales Reports: 'invoices' | 'item_wise' | 'month_wise' | 'top_selling'
  const [salesSubView, setSalesSubView] = useState<'invoices' | 'item_wise' | 'month_wise' | 'top_selling'>('invoices');
  const [salesInvoiceStatusFilter, setSalesInvoiceStatusFilter] = useState<'ALL' | 'Paid' | 'Partially Paid' | 'Unpaid'>('ALL');
  const [selectedPrintInvoice, setSelectedPrintInvoice] = useState<SalesInvoice | null>(null);

  // Quick Expense Voucher Modal state (accessible directly from Expense Report)
  const [showQuickExpenseModal, setShowQuickExpenseModal] = useState<boolean>(false);
  const [quickExpHeadCode, setQuickExpHeadCode] = useState<string>('');
  const [quickExpAmount, setQuickExpAmount] = useState<number>(0);
  const [quickExpDate, setQuickExpDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [quickExpPayee, setQuickExpPayee] = useState<string>('');
  const [quickExpNarration, setQuickExpNarration] = useState<string>('');
  const [quickExpPaymentMode, setQuickExpPaymentMode] = useState<string>('');

  // Sub-views for Purchase Reports: 'item_wise' | 'month_wise'
  const [purchaseSubView, setPurchaseSubView] = useState<'item_wise' | 'month_wise'>('item_wise');

  // Top Selling Items Metric: 'qty' | 'revenue'
  const [topSellingMetric, setTopSellingMetric] = useState<'revenue' | 'qty'>('revenue');

  // Filter for Expense Report: 'ALL' (all chart of accounts) or specific account code like '5200'
  const [expenseAccountFilter, setExpenseAccountFilter] = useState<string>('ALL');

  // Stock Report Filters
  const [stockCategoryFilter, setStockCategoryFilter] = useState<string>('ALL');
  const [stockWarehouseFilter, setStockWarehouseFilter] = useState<string>('ALL');
  const [stockStatusFilter, setStockStatusFilter] = useState<'ALL' | 'LOW' | 'IN_STOCK'>('ALL');

  // Search & Global Date Range
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dateRange, setDateRange] = useState<DatePreset>('all');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');

  // Live Core ERP Data States
  const [items, setItems] = useState<InventoryItem[]>(() => getItems());
  const [warehouses, setWarehouses] = useState<WarehouseType[]>(() => getWarehouses());
  const [coaList, setCoaList] = useState<AccountCOA[]>(() => getCOA());

  // Helper to load all sales invoices including POS counter sales
  const loadAllSalesInvoices = (): SalesInvoice[] => {
    const standardInvoices = getSalesInvoices();
    try {
      const rawPos = localStorage.getItem('tradecore_pos_sales_v1');
      if (rawPos) {
        const posSales: any[] = JSON.parse(rawPos);
        if (Array.isArray(posSales) && posSales.length > 0) {
          const existingNumbers = new Set(standardInvoices.map(i => i.invoiceNumber));
          const posAsInvoices: SalesInvoice[] = posSales
            .filter(p => !existingNumbers.has(p.invoiceNo))
            .map(p => ({
              id: p.id,
              invoiceNumber: p.invoiceNo,
              customerId: 'pos-customer',
              customerName: p.customerName || 'Spot Customer',
              invoiceDate: p.date,
              dueDate: p.date,
              branch: p.branch,
              cashierName: p.cashierName,
              truckNo: p.truckNo,
              driverName: p.driverName,
              items: (p.items || []).map((it: any) => ({
                itemId: it.itemId || it.itemName,
                itemName: it.itemName,
                quantity: it.quantity,
                uom: it.uom,
                unitPrice: it.unitPrice,
                amount: it.total
              })),
              totalAmount: p.grandTotal,
              paidAmount: p.paidAmount,
              dueAmount: p.dueAmount,
              paymentMethod: p.paymentMethod,
              status: p.dueAmount === 0 ? 'Paid' : p.paidAmount > 0 ? 'Partially Paid' : 'Unpaid'
            }));
          return [...posAsInvoices, ...standardInvoices];
        }
      }
    } catch (e) {
      console.error(e);
    }
    return standardInvoices;
  };

  const loadAllPurchaseInvoices = (): DirectPurchaseInvoice[] => {
    try {
      const raw = localStorage.getItem('tradecore_purchase_invoices_v1');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return MOCK_DIRECT_PURCHASE_INVOICES;
  };

  const [salesInvoices, setSalesInvoices] = useState<SalesInvoice[]>(() => loadAllSalesInvoices());
  const [purchaseInvoices, setPurchaseInvoices] = useState<DirectPurchaseInvoice[]>(() => loadAllPurchaseInvoices());
  const [vouchers, setVouchers] = useState<JournalVoucher[]>(() => getVouchers());
  const [accountTransactions, setAccountTransactions] = useState<AccountTransaction[]>(() => getAccountTransactions());
  const [accountLedgers, setAccountLedgers] = useState<AccountLedgerEntry[]>(() => getAccountLedgers());
  const [selectedVoucherTxnForView, setSelectedVoucherTxnForView] = useState<AccountTransaction | null>(null);

  // Subscribe to live storage events
  useEffect(() => {
    const unsubItems = subscribeItems(setItems);
    const unsubWh = subscribeWarehouses(setWarehouses);
    const unsubCoa = subscribeCOA(setCoaList);
    const unsubSales = subscribeSalesInvoices(() => {
      setSalesInvoices(loadAllSalesInvoices());
    });
    const unsubVouchers = subscribeVouchers(setVouchers);
    const unsubAccTxns = subscribeAccountTransactions(setAccountTransactions);
    const unsubAccLedgers = subscribeAccountLedgers(setAccountLedgers);

    const refreshData = () => {
      setSalesInvoices(loadAllSalesInvoices());
      setPurchaseInvoices(loadAllPurchaseInvoices());
      setVouchers(getVouchers());
      setAccountTransactions(getAccountTransactions());
      setAccountLedgers(getAccountLedgers());
      setCoaList(getCOA());
      setItems(getItems());
    };

    window.addEventListener('storage', refreshData);
    window.addEventListener('focus', refreshData);
    window.addEventListener('tradecore_sales_invoices_updated', refreshData);
    window.addEventListener('tradecore_vouchers_updated', refreshData);

    return () => {
      unsubItems();
      unsubWh();
      unsubCoa();
      unsubSales();
      unsubVouchers();
      unsubAccTxns();
      unsubAccLedgers();
      window.removeEventListener('storage', refreshData);
      window.removeEventListener('focus', refreshData);
      window.removeEventListener('tradecore_sales_invoices_updated', refreshData);
      window.removeEventListener('tradecore_vouchers_updated', refreshData);
    };
  }, []);

  // Modal for viewing item sales breakdown or voucher details
  const [selectedItemDetail, setSelectedItemDetail] = useState<{
    itemName: string;
    sku: string;
    uom: string;
    totalQty: number;
    totalAmount: number;
    transactions: { date: string; invoiceNo: string; customer: string; qty: number; rate: number; total: number }[];
  } | null>(null);

  // Quick Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Helper date filtering for sales, purchases, expenses & stock audits
  const isDateInRange = (dateStr?: string) => {
    if (!dateStr) return true;
    if (dateRange === 'all') return true;

    let itemDateStr = '';
    if (/^\d{4}-\d{2}-\d{2}/.test(dateStr)) {
      itemDateStr = dateStr.substring(0, 10);
    } else {
      const itemDate = new Date(dateStr);
      if (isNaN(itemDate.getTime())) return true;
      itemDateStr = itemDate.toISOString().split('T')[0];
    }

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    if (dateRange === 'today') {
      return itemDateStr === todayStr;
    }
    if (dateRange === 'yesterday') {
      const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      return itemDateStr === yesterday.toISOString().split('T')[0];
    }
    if (dateRange === 'week') {
      const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      return itemDateStr >= sevenDaysAgo && itemDateStr <= todayStr;
    }
    if (dateRange === 'month') {
      const yearMonth = todayStr.substring(0, 7);
      return itemDateStr.startsWith(yearMonth);
    }
    if (dateRange === 'last_month') {
      const prevDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const prevYearMonth = prevDate.toISOString().split('T')[0].substring(0, 7);
      return itemDateStr.startsWith(prevYearMonth);
    }
    if (dateRange === 'year') {
      const yearStr = String(now.getFullYear());
      return itemDateStr.startsWith(yearStr);
    }
    if (dateRange === 'custom') {
      if (customStartDate && customEndDate) {
        return itemDateStr >= customStartDate && itemDateStr <= customEndDate;
      }
      if (customStartDate) {
        return itemDateStr >= customStartDate;
      }
      if (customEndDate) {
        return itemDateStr <= customEndDate;
      }
      return true;
    }
    return true;
  };

  // ----------------------------------------------------
  // 1. SALES REPORT DATA COMPUTATIONS
  // ----------------------------------------------------
  const filteredSalesInvoices = useMemo(() => {
    return salesInvoices.filter(inv => isDateInRange(inv.invoiceDate));
  }, [salesInvoices, dateRange, customStartDate, customEndDate]);

  // Total Sales KPI
  const totalSalesRevenue = useMemo(() => {
    return filteredSalesInvoices.reduce((sum, inv) => sum + (inv.totalAmount || 0), 0);
  }, [filteredSalesInvoices]);

  const totalSalesCollected = useMemo(() => {
    return filteredSalesInvoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
  }, [filteredSalesInvoices]);

  const totalSalesDue = useMemo(() => {
    return filteredSalesInvoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);
  }, [filteredSalesInvoices]);

  // Tabular Sales Invoices list for the 'invoices' sub-view
  const tabularSalesInvoices = useMemo(() => {
    return salesInvoices.filter(inv => {
      if (!isDateInRange(inv.invoiceDate)) return false;
      if (salesInvoiceStatusFilter !== 'ALL') {
        if (salesInvoiceStatusFilter === 'Paid' && inv.status !== 'Paid') return false;
        if (salesInvoiceStatusFilter === 'Partially Paid' && inv.status !== 'Partially Paid') return false;
        if (salesInvoiceStatusFilter === 'Unpaid' && inv.status !== 'Unpaid') return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matches = 
          inv.invoiceNumber.toLowerCase().includes(q) ||
          inv.customerName.toLowerCase().includes(q) ||
          (inv.truckNo && inv.truckNo.toLowerCase().includes(q)) ||
          (inv.driverName && inv.driverName.toLowerCase().includes(q)) ||
          (inv.items || []).some(it => it.itemName.toLowerCase().includes(q));
        if (!matches) return false;
      }
      return true;
    });
  }, [salesInvoices, dateRange, customStartDate, customEndDate, salesInvoiceStatusFilter, searchQuery]);

  // Aggregate Sales: Item Wise
  const itemWiseSales = useMemo(() => {
    const itemMap = new Map<string, {
      itemId: string;
      itemName: string;
      sku: string;
      category: string;
      uom: string;
      soldQty: number;
      invoiceCount: number;
      grossAmount: number;
      discountAmount: number;
      netAmount: number;
      paidAmount: number;
      dueAmount: number;
      transactions: { date: string; invoiceNo: string; customer: string; qty: number; rate: number; total: number }[];
    }>();

    filteredSalesInvoices.forEach(inv => {
      const itemsList = inv.items || [];
      const invoicePaidRatio = inv.totalAmount > 0 ? (inv.paidAmount || 0) / inv.totalAmount : 1;

      itemsList.forEach(line => {
        const itmId = line.itemId || line.itemName;
        const lineQty = Number(line.quantity || 0);
        const lineTotal = Number(line.amount || (line.unitPrice * line.quantity) || 0);
        const matchedInventory = items.find(i => i.id === line.itemId || i.name === line.itemName);

        const current = itemMap.get(itmId) || {
          itemId: itmId,
          itemName: line.itemName || matchedInventory?.name || 'Unnamed Item',
          sku: matchedInventory?.sku || 'SKU-GEN',
          category: matchedInventory?.category || 'General',
          uom: line.uom || matchedInventory?.uom || 'CFT',
          soldQty: 0,
          invoiceCount: 0,
          grossAmount: 0,
          discountAmount: 0,
          netAmount: 0,
          paidAmount: 0,
          dueAmount: 0,
          transactions: []
        };

        current.soldQty += lineQty;
        current.invoiceCount += 1;
        current.grossAmount += lineTotal;
        current.netAmount += lineTotal;
        current.paidAmount += lineTotal * invoicePaidRatio;
        current.dueAmount += lineTotal * (1 - invoicePaidRatio);

        current.transactions.push({
          date: inv.invoiceDate,
          invoiceNo: inv.invoiceNumber,
          customer: inv.customerName,
          qty: lineQty,
          rate: line.unitPrice,
          total: lineTotal
        });

        itemMap.set(itmId, current);
      });
    });

    let result = Array.from(itemMap.values());
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(r => 
        r.itemName.toLowerCase().includes(q) || 
        r.sku.toLowerCase().includes(q) ||
        r.category.toLowerCase().includes(q)
      );
    }
    return result.sort((a, b) => b.netAmount - a.netAmount);
  }, [filteredSalesInvoices, items, searchQuery]);

  // Aggregate Sales: Month Wise
  const monthWiseSales = useMemo(() => {
    const monthMap = new Map<string, {
      monthKey: string;
      monthLabel: string;
      year: number;
      invoiceCount: number;
      totalQtyCft: number;
      totalQtyMt: number;
      grossRevenue: number;
      discount: number;
      netRevenue: number;
      cashCollected: number;
      receivableDue: number;
    }>();

    filteredSalesInvoices.forEach(inv => {
      if (!inv.invoiceDate) return;
      const d = new Date(inv.invoiceDate);
      if (isNaN(d.getTime())) return;

      const year = d.getFullYear();
      const monthNum = d.getMonth() + 1;
      const monthKey = `${year}-${String(monthNum).padStart(2, '0')}`;
      const monthLabel = d.toLocaleString('en-US', { month: 'long', year: 'numeric' });

      const cur = monthMap.get(monthKey) || {
        monthKey,
        monthLabel,
        year,
        invoiceCount: 0,
        totalQtyCft: 0,
        totalQtyMt: 0,
        grossRevenue: 0,
        discount: 0,
        netRevenue: 0,
        cashCollected: 0,
        receivableDue: 0
      };

      cur.invoiceCount += 1;
      cur.grossRevenue += inv.totalAmount;
      cur.discount += 0;
      cur.netRevenue += inv.totalAmount;
      cur.cashCollected += inv.paidAmount || 0;
      cur.receivableDue += inv.dueAmount || 0;

      (inv.items || []).forEach(it => {
        if (it.uom === 'CFT' || it.itemName.toLowerCase().includes('crush')) {
          cur.totalQtyCft += Number(it.quantity || 0);
        } else {
          cur.totalQtyMt += Number(it.quantity || 0);
        }
      });

      monthMap.set(monthKey, cur);
    });

    return Array.from(monthMap.values()).sort((a, b) => b.monthKey.localeCompare(a.monthKey));
  }, [filteredSalesInvoices]);

  // Aggregate Sales: Top Selling Items
  const topSellingItems = useMemo(() => {
    const list = [...itemWiseSales];
    if (topSellingMetric === 'revenue') {
      list.sort((a, b) => b.netAmount - a.netAmount);
    } else {
      list.sort((a, b) => b.soldQty - a.soldQty);
    }
    return list;
  }, [itemWiseSales, topSellingMetric]);

  // ----------------------------------------------------
  // 2. PURCHASE REPORT DATA COMPUTATIONS
  // ----------------------------------------------------
  const filteredPurchaseInvoices = useMemo(() => {
    return purchaseInvoices.filter(inv => isDateInRange(inv.invoiceDate));
  }, [purchaseInvoices, dateRange, customStartDate, customEndDate]);

  const totalPurchaseCost = useMemo(() => {
    return filteredPurchaseInvoices.reduce((sum, inv) => sum + (inv.grandTotal || 0), 0);
  }, [filteredPurchaseInvoices]);

  const totalPurchasePaid = useMemo(() => {
    return filteredPurchaseInvoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
  }, [filteredPurchaseInvoices]);

  const totalPurchaseDue = useMemo(() => {
    return filteredPurchaseInvoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);
  }, [filteredPurchaseInvoices]);

  // Item Wise Purchase
  const itemWisePurchase = useMemo(() => {
    const pMap = new Map<string, {
      itemId: string;
      itemName: string;
      category: string;
      uom: string;
      purchasedQty: number;
      billCount: number;
      totalCost: number;
      paidAmount: number;
      dueAmount: number;
      suppliers: Set<string>;
      transactions: { date: string; invoiceNo: string; supplier: string; qty: number; rate: number; total: number }[];
    }>();

    filteredPurchaseInvoices.forEach(inv => {
      const itemsList = inv.items || [];
      const paidRatio = inv.grandTotal > 0 ? (inv.paidAmount || 0) / inv.grandTotal : 1;

      itemsList.forEach(line => {
        const itmId = line.itemId || line.itemName;
        const lineQty = Number(line.quantity || 0);
        const lineTotal = Number(line.totalPrice || (line.unitPrice * line.quantity) || 0);
        const matchedItem = items.find(i => i.id === line.itemId || i.name === line.itemName);

        const current = pMap.get(itmId) || {
          itemId: itmId,
          itemName: line.itemName || matchedItem?.name || 'Item',
          category: matchedItem?.category || 'Boulder / Raw Material',
          uom: line.uom || matchedItem?.uom || 'Ton',
          purchasedQty: 0,
          billCount: 0,
          totalCost: 0,
          paidAmount: 0,
          dueAmount: 0,
          suppliers: new Set<string>(),
          transactions: []
        };

        current.purchasedQty += lineQty;
        current.billCount += 1;
        current.totalCost += lineTotal;
        current.paidAmount += lineTotal * paidRatio;
        current.dueAmount += lineTotal * (1 - paidRatio);
        if (inv.supplierName) current.suppliers.add(inv.supplierName);

        current.transactions.push({
          date: inv.invoiceDate,
          invoiceNo: inv.invoiceNumber,
          supplier: inv.supplierName,
          qty: lineQty,
          rate: line.unitPrice,
          total: lineTotal
        });

        pMap.set(itmId, current);
      });
    });

    let res = Array.from(pMap.values());
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      res = res.filter(r => r.itemName.toLowerCase().includes(q) || r.category.toLowerCase().includes(q));
    }
    return res.sort((a, b) => b.totalCost - a.totalCost);
  }, [filteredPurchaseInvoices, items, searchQuery]);

  // Month Wise Purchase
  const monthWisePurchase = useMemo(() => {
    const pMonthMap = new Map<string, {
      monthKey: string;
      monthLabel: string;
      year: number;
      billCount: number;
      totalQtyMt: number;
      totalQtyCft: number;
      totalCost: number;
      paidAmount: number;
      dueAmount: number;
    }>();

    filteredPurchaseInvoices.forEach(inv => {
      if (!inv.invoiceDate) return;
      const d = new Date(inv.invoiceDate);
      if (isNaN(d.getTime())) return;

      const year = d.getFullYear();
      const monthNum = d.getMonth() + 1;
      const monthKey = `${year}-${String(monthNum).padStart(2, '0')}`;
      const monthLabel = d.toLocaleString('en-US', { month: 'long', year: 'numeric' });

      const cur = pMonthMap.get(monthKey) || {
        monthKey,
        monthLabel,
        year,
        billCount: 0,
        totalQtyMt: 0,
        totalQtyCft: 0,
        totalCost: 0,
        paidAmount: 0,
        dueAmount: 0
      };

      cur.billCount += 1;
      cur.totalCost += inv.grandTotal;
      cur.paidAmount += inv.paidAmount || 0;
      cur.dueAmount += inv.dueAmount || 0;

      (inv.items || []).forEach(it => {
        if (it.uom === 'CFT') {
          cur.totalQtyCft += Number(it.quantity || 0);
        } else {
          cur.totalQtyMt += Number(it.quantity || 0);
        }
      });

      pMonthMap.set(monthKey, cur);
    });

    return Array.from(pMonthMap.values()).sort((a, b) => b.monthKey.localeCompare(a.monthKey));
  }, [filteredPurchaseInvoices]);

  // ----------------------------------------------------
  // 3. EXPENSE REPORT COMPUTATIONS (Chart of Accounts)
  // ----------------------------------------------------
  // Map legacy account_heads codes/ids to COA codes so posted ledger lines match Trial Balance
  const resolveExpenseCoaCode = useMemo(() => {
    const coaByCode = new Map<string, AccountCOA>();
    const coaByName = new Map<string, AccountCOA>();
    coaList.forEach(c => {
      if (c.category === 'Expense') {
        coaByCode.set(c.code, c);
        coaByName.set(c.name.toLowerCase().trim(), c);
      }
    });
    const heads = getAccountHeads();
    const headToCoaCode = new Map<string, string>();
    heads.forEach(h => {
      const byName = coaByName.get((h.name || '').toLowerCase().trim()) || coaByName.get((h.nameEn || '').toLowerCase().trim());
      if (byName) {
        if (h.id) headToCoaCode.set(h.id, byName.code);
        if (h.code) headToCoaCode.set(h.code, byName.code);
      }
    });
    return (rawCodeOrId?: string, rawName?: string): string | null => {
      if (rawCodeOrId && coaByCode.has(rawCodeOrId)) return rawCodeOrId;
      if (rawCodeOrId && rawCodeOrId.startsWith('coa-')) {
        const stripped = rawCodeOrId.replace(/^coa-/, '');
        if (coaByCode.has(stripped)) return stripped;
      }
      if (rawCodeOrId && headToCoaCode.has(rawCodeOrId)) return headToCoaCode.get(rawCodeOrId)!;
      if (rawName) {
        const byName = coaByName.get(rawName.toLowerCase().trim());
        if (byName) return byName.code;
      }
      return null;
    };
  }, [coaList]);

  // All Expense Heads in COA (5000 series COGS/Crushing & 6000 series Operating Expenses)
  // Includes posted active ledger debits minus credits (matching Trial Balance), while excluding 13100 Inventory capitalization
  const expenseAccounts = useMemo(() => {
    const ledgerDeltaByCode = new Map<string, number>();
    const activeTxnsById = new Map<string, AccountTransaction>();
    accountTransactions.forEach(tx => {
      if (tx.status !== 'voided') activeTxnsById.set(tx.id, tx);
    });

    accountLedgers.forEach(led => {
      if (led.status === 'voided' || led.accountType !== 'AccountHead') return;
      // Capitalized inventory lines (13100) are Asset lines, NOT Expense lines
      if (led.accountId === '13100') return;
      const parentTx = activeTxnsById.get(led.transactionId);
      const matchedCode = resolveExpenseCoaCode(
        led.accountId || parentTx?.accountHeadCode || parentTx?.accountHeadId,
        led.accountName || parentTx?.accountHeadName
      );
      if (!matchedCode) return;
      const delta = (Number(led.debit) || 0) - (Number(led.credit) || 0);
      if (delta !== 0) {
        ledgerDeltaByCode.set(matchedCode, (ledgerDeltaByCode.get(matchedCode) || 0) + delta);
      }
    });

    return coaList
      .filter(acc => acc.category === 'Expense')
      .map(acc => {
        if (acc.isParent) return acc;
        const postedDelta = ledgerDeltaByCode.get(acc.code) || 0;
        return postedDelta !== 0 ? { ...acc, balance: (Number(acc.balance) || 0) + postedDelta } : acc;
      });
  }, [coaList, accountLedgers, accountTransactions, resolveExpenseCoaCode]);

  // Total Company Expense across all COA expense heads
  const totalAllExpenses = useMemo(() => {
    return expenseAccounts.reduce((sum, acc) => sum + (acc.isParent ? 0 : acc.balance), 0);
  }, [expenseAccounts]);

  // Selected Filtered Account
  const selectedFilteredAccount = useMemo(() => {
    if (expenseAccountFilter === 'ALL') return null;
    return expenseAccounts.find(a => a.code === expenseAccountFilter) || null;
  }, [expenseAccounts, expenseAccountFilter]);

  // Filtered Expense Rows
  const filteredExpenseRows = useMemo(() => {
    let rows = expenseAccounts.filter(a => !a.isParent);
    if (expenseAccountFilter !== 'ALL') {
      rows = rows.filter(a => a.code === expenseAccountFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      rows = rows.filter(r => r.name.toLowerCase().includes(q) || r.code.includes(q) || r.subCategory.toLowerCase().includes(q));
    }
    return rows;
  }, [expenseAccounts, expenseAccountFilter, searchQuery]);

  // Detailed Expense Transactions extracted dynamically from live vouchers AND posted account_ledgers
  const expenseTransactions = useMemo(() => {
    const list: {
      id: string;
      voucherNo: string;
      transactionId?: string;
      date: string;
      accountCode: string;
      accountName: string;
      description: string;
      payee: string;
      paymentMode: string;
      amount: number;
      refNo: string;
    }[] = [];

    // Helper map for fast COA lookups
    const coaMap = new Map<string, AccountCOA>();
    coaList.forEach(c => coaMap.set(c.code, c));
    const seenVoucherKeys = new Set<string>();

    // 1. Read posted ledger lines from accountService (account_ledgers + account_transactions)
    const activeTxnsById = new Map<string, AccountTransaction>();
    accountTransactions.forEach(tx => {
      if (tx.status !== 'voided') activeTxnsById.set(tx.id, tx);
    });

    accountLedgers.forEach(led => {
      if (led.status === 'voided' || led.accountType !== 'AccountHead') return;
      const debitAmt = Number(led.debit || 0);
      if (debitAmt <= 0) return;
      // Exclude capitalized inventory lines (13100) from Expense total; they are shown in the separate section below
      if (led.accountId === '13100') return;

      const parentTx = activeTxnsById.get(led.transactionId);
      const matchedCode = resolveExpenseCoaCode(
        led.accountId || parentTx?.accountHeadCode || parentTx?.accountHeadId,
        led.accountName || parentTx?.accountHeadName
      );
      if (!matchedCode) return;

      const matchedCoa = coaMap.get(matchedCode);
      if (!matchedCoa || matchedCoa.category !== 'Expense') return;

      if (expenseAccountFilter !== 'ALL' && matchedCode !== expenseAccountFilter) {
        return;
      }

      const vchNo = led.voucherNo || parentTx?.voucherNo || 'PV';
      const vchDate = led.date || parentTx?.date || '';
      const desc = led.description || parentTx?.note || matchedCoa.name;
      const payee = parentTx?.partyName || parentTx?.accountHeadName || matchedCoa.name;
      const paymentMode = parentTx?.bankAccountName
        ? `${parentTx.paymentMethod || 'Payment'} (${parentTx.bankAccountName})`
        : parentTx?.paymentMethod || 'Voucher';
      const refNo = parentTx?.referenceNo || vchNo;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          vchNo.toLowerCase().includes(q) ||
          matchedCode.includes(q) ||
          matchedCoa.name.toLowerCase().includes(q) ||
          desc.toLowerCase().includes(q) ||
          payee.toLowerCase().includes(q) ||
          refNo.toLowerCase().includes(q);
        if (!match) return;
      }

      const dedupeKey = `${vchNo}-${matchedCode}-${debitAmt}`;
      seenVoucherKeys.add(dedupeKey);

      list.push({
        id: led.id,
        voucherNo: vchNo,
        transactionId: led.transactionId,
        date: vchDate,
        accountCode: matchedCode,
        accountName: matchedCoa.name,
        description: desc,
        payee,
        paymentMode,
        amount: debitAmt,
        refNo
      });
    });

    // 2. Also include manual JournalVouchers from voucherStorage
    vouchers.forEach((vch, vIdx) => {
      const vchDate = vch.voucherDate || '';
      const vchNo = vch.voucherNumber || `VCH-${vIdx + 1}`;
      const vchNarration = vch.narration || '';
      const vchPayee = vch.postedBy || vch.referenceNo || 'Approved Vendor';
      
      const creditLeg = (vch.items || []).find(it => (it.credit || 0) > 0);
      const paymentMode = creditLeg?.accountName || (vch.voucherType === 'PV' ? 'Payment Voucher (Cash/Bank)' : vch.voucherType || 'Voucher');

      (vch.items || []).forEach((item, itmIdx) => {
        const debitAmt = Number(item.debit || 0);
        if (debitAmt <= 0) return;

        const code = item.accountCode;
        if (code === '13100') return;
        const matchedCoa = coaMap.get(code);
        const isExpense = 
          matchedCoa?.category === 'Expense' || 
          code.startsWith('5') || 
          code.startsWith('6') ||
          (item.accountName && (
            item.accountName.toLowerCase().includes('expense') ||
            item.accountName.toLowerCase().includes('cost') ||
            item.accountName.toLowerCase().includes('crushing') ||
            item.accountName.toLowerCase().includes('rent') ||
            item.accountName.toLowerCase().includes('salary') ||
            item.accountName.toLowerCase().includes('bill') ||
            item.accountName.toLowerCase().includes('charge') ||
            item.accountName.toLowerCase().includes('labour') ||
            item.accountName.toLowerCase().includes('duty') ||
            item.accountName.toLowerCase().includes('freight')
          ));

        if (!isExpense) return;

        if (expenseAccountFilter !== 'ALL' && code !== expenseAccountFilter) {
          return;
        }

        const dedupeKey = `${vchNo}-${code}-${debitAmt}`;
        if (seenVoucherKeys.has(dedupeKey)) return;

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const match = 
            vchNo.toLowerCase().includes(q) ||
            code.includes(q) ||
            (item.accountName || '').toLowerCase().includes(q) ||
            vchNarration.toLowerCase().includes(q) ||
            vchPayee.toLowerCase().includes(q) ||
            (vch.referenceNo || '').toLowerCase().includes(q);
          if (!match) return;
        }

        list.push({
          id: `${vch.id || vchNo}-${code}-${itmIdx}`,
          voucherNo: vchNo,
          date: vchDate,
          accountCode: code,
          accountName: item.accountName || matchedCoa?.name || 'Expense Account Head',
          description: vchNarration || item.accountName || 'Expense Payment',
          payee: vchPayee,
          paymentMode,
          amount: debitAmt,
          refNo: vch.referenceNo || vchNo
        });
      });
    });

    // If no dynamic vouchers were found yet for 5200, provide preloaded fallback
    if (list.length === 0 && expenseAccountFilter === '5200') {
      return [
        {
          id: 'exp-crush-fallback-1',
          voucherNo: 'PV-2026-CR-012',
          date: '2026-09-28',
          accountCode: '5200',
          accountName: 'Stone Crushing Cost',
          description: 'Stone crushing labor bill and crushing charges paid (Sonahat Mill)',
          payee: 'Burimari Crushing Labor Sardar (Kader Team)',
          paymentMode: 'Cash',
          amount: 145000,
          refNo: 'LAB-SON-882'
        }
      ];
    }

    // Sort newest date first
    return list.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [vouchers, accountLedgers, accountTransactions, coaList, expenseAccountFilter, searchQuery, resolveExpenseCoaCode]);

  // Capitalized LC costs (debited to 13100 Raw Material Inventory, NOT part of Expense total)
  const capitalizedLcCostData = useMemo(() => {
    const coaByCode = new Map<string, AccountCOA>();
    const coaByName = new Map<string, AccountCOA>();
    coaList.forEach(c => {
      coaByCode.set(c.code, c);
      coaByName.set(c.name.toLowerCase().trim(), c);
    });

    const rows: {
      id: string;
      voucherNo: string;
      transactionId: string;
      date: string;
      lcNumber: string;
      headCode: string;
      headName: string;
      paidFrom: string;
      amount: number;
      narration: string;
      txn: AccountTransaction;
    }[] = [];

    const seenTxIds = new Set<string>();

    accountTransactions.forEach(tx => {
      if (!tx || tx.status === 'voided') return;
      const isCapTo13100 =
        tx.accountHeadCode === '13100' ||
        (tx.multiLines && tx.multiLines.some(l => l.accountCode === '13100')) ||
        Boolean(tx.lcExpenseRecord?.capitalizedToInventory);

      if (!isCapTo13100) return;
      if (!isDateInRange(tx.date)) return;

      // Determine the expense head selected when posting
      let headName =
        tx.lcExpenseRecord?.expenseType ||
        tx.lcExpenseHead ||
        (tx.accountHeadName && tx.accountHeadName !== 'Raw Material Inventory (Landed Stock)' ? tx.accountHeadName : '');

      if (!headName && tx.note) {
        const parts = tx.note.split(' - ');
        if (parts.length >= 2) {
          headName = parts.slice(1).join(' - ').trim();
        }
      }
      if (!headName) headName = 'All Kind Of Lc Expense';

      let headCode = '5225';
      if (tx.accountHeadId && tx.accountHeadId.startsWith('coa-')) {
        headCode = tx.accountHeadId.replace(/^coa-/, '');
      } else {
        const matchedCoa = coaByName.get(headName.toLowerCase().trim());
        if (matchedCoa) headCode = matchedCoa.code;
      }

      if (expenseAccountFilter !== 'ALL' && expenseAccountFilter !== headCode) {
        return;
      }

      let lcNum = tx.lcNumber || tx.lcExpenseRecord?.lcNumber || '';
      if (!lcNum) {
        const refMatch = (tx.referenceNo || tx.note || '').match(/LC-[A-Z0-9-]+/i);
        if (refMatch) lcNum = refMatch[0].toUpperCase();
        else lcNum = tx.referenceNo || 'LC Import';
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          tx.voucherNo.toLowerCase().includes(q) ||
          headCode.toLowerCase().includes(q) ||
          headName.toLowerCase().includes(q) ||
          lcNum.toLowerCase().includes(q) ||
          (tx.bankAccountName || '').toLowerCase().includes(q);
        if (!match) return;
      }

      seenTxIds.add(tx.id);
      rows.push({
        id: tx.id,
        voucherNo: tx.voucherNo,
        transactionId: tx.id,
        date: tx.date,
        lcNumber: lcNum,
        headCode,
        headName,
        paidFrom: tx.bankAccountName || tx.paymentMethod || 'Bank/Cash',
        amount: Number(tx.amount) || 0,
        narration: tx.note || `LC ${lcNum} - ${headName}`,
        txn: tx
      });
    });

    rows.sort((a, b) => (b.date || '').localeCompare(a.date || '') || b.voucherNo.localeCompare(a.voucherNo));

    // Group by expense head
    const byHeadMap = new Map<
      string,
      {
        headCode: string;
        headName: string;
        totalAmount: number;
        vouchers: typeof rows;
      }
    >();

    rows.forEach(r => {
      const key = `${r.headCode}::${r.headName}`;
      const existing = byHeadMap.get(key) || {
        headCode: r.headCode,
        headName: r.headName,
        totalAmount: 0,
        vouchers: []
      };
      existing.totalAmount += r.amount;
      existing.vouchers.push(r);
      byHeadMap.set(key, existing);
    });

    const byHead = Array.from(byHeadMap.values()).sort((a, b) => b.totalAmount - a.totalAmount);
    const totalCapitalized = rows.reduce((s, r) => s + r.amount, 0);

    return { rows, byHead, totalCapitalized };
  }, [accountTransactions, coaList, expenseAccountFilter, searchQuery, dateRange, customStartDate, customEndDate]);

  // Date-filtered Expense Transactions
  const filteredExpenseTransactions = useMemo(() => {
    return expenseTransactions.filter(v => isDateInRange(v.date));
  }, [expenseTransactions, dateRange, customStartDate, customEndDate]);

  const filteredExpenseTotal = useMemo(() => {
    return filteredExpenseTransactions.reduce((acc, t) => acc + t.amount, 0);
  }, [filteredExpenseTransactions]);

  // Handle saving quick expense voucher directly from report
  const handleSaveQuickExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(quickExpAmount);
    if (!amt || amt <= 0) return;

    const targetHead = coaList.find(c => c.code === quickExpHeadCode) || {
      code: quickExpHeadCode,
      name: 'Stone Crushing Cost'
    };

    const newV: JournalVoucher = {
      id: `jv-${Date.now()}`,
      voucherNumber: `PV-2026-CR-${Math.floor(100 + Math.random() * 900)}`,
      voucherType: 'PV',
      voucherDate: quickExpDate,
      referenceType: 'Manual',
      referenceNo: `EXP-MAN-${Date.now().toString().slice(-4)}`,
      narration: quickExpNarration.trim(),
      items: [
        { 
          accountCode: targetHead.code, 
          accountName: targetHead.name, 
          debit: amt, 
          credit: 0, 
          costCenter: 'Burimari Crushing Yard' 
        },
        { 
          accountCode: '1010', 
          accountName: quickExpPaymentMode.includes('Bank') ? 'Bank Accounts' : 'Cash in Hand', 
          debit: 0, 
          credit: amt, 
          costCenter: 'Head Office' 
        }
      ],
      totalDebit: amt,
      totalCredit: amt,
      postedBy: quickExpPayee.trim() || 'Approved Vendor',
      status: 'Approved & Posted'
    };

    addVoucher(newV);
    setVouchers(prev => [newV, ...prev]);

    // Update CoA balance
    const updatedCoa = coaList.map(item => {
      if (item.code === targetHead.code) {
        return { ...item, balance: (item.balance || 0) + amt };
      }
      return item;
    });
    saveCOA(updatedCoa);
    setCoaList(updatedCoa);

    handleCloseQuickExpense();
    triggerToast(`✓ Expense Voucher ${newV.voucherNumber} (৳${amt.toLocaleString()}) added!`);
  };

  const isQuickExpDirty = (quickExpAmount || 0) > 0 || quickExpPayee.trim() !== '' || quickExpNarration.trim() !== '';

  const handleCloseQuickExpense = () => {
    setShowQuickExpenseModal(false);
    setQuickExpHeadCode('');
    setQuickExpAmount(0);
    setQuickExpDate(new Date().toISOString().split('T')[0]);
    setQuickExpPayee('');
    setQuickExpNarration('');
    setQuickExpPaymentMode('');
  };

  // ----------------------------------------------------
  // 4. STOCK REPORT DATA COMPUTATIONS
  // ----------------------------------------------------
  const filteredStockItems = useMemo(() => {
    return items.filter(item => {
      // Category filter
      if (stockCategoryFilter !== 'ALL') {
        if (stockCategoryFilter === 'BOULDER') {
          const isBoulder = item.category === 'Boulder' || item.category.toLowerCase().includes('boulder') || item.uom === 'Ton' || item.name.toLowerCase().includes('boulder');
          if (!isBoulder) return false;
        } else if (stockCategoryFilter === 'CRUSHED') {
          const isCrushed = item.category === 'Crushed Stone' || item.uom === 'CFT' || item.category.toLowerCase().includes('crush') || item.name.toLowerCase().includes('crush') || item.name.toLowerCase().includes('down') || item.name.toLowerCase().includes('chips');
          if (!isCrushed) return false;
        } else if (stockCategoryFilter === 'AGRO') {
          if (!item.category.toLowerCase().includes('agro') && !item.category.toLowerCase().includes('feed')) return false;
        } else if (stockCategoryFilter === 'STEEL') {
          if (!item.category.toLowerCase().includes('steel')) return false;
        }
      }

      // Warehouse filter
      if (stockWarehouseFilter !== 'ALL') {
        const whStock = item.stockByWarehouse?.[stockWarehouseFilter] || 0;
        if (whStock <= 0) return false;
      }

      // Status filter
      const reorder = item.minStock || item.reorderPoint || 0;
      if (stockStatusFilter === 'LOW') {
        if (item.totalStock > reorder) return false;
      } else if (stockStatusFilter === 'IN_STOCK') {
        if (item.totalStock <= 0) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match = item.name.toLowerCase().includes(q) || 
                      item.sku.toLowerCase().includes(q) || 
                      item.category.toLowerCase().includes(q);
        if (!match) return false;
      }

      return true;
    });
  }, [items, stockCategoryFilter, stockWarehouseFilter, stockStatusFilter, searchQuery]);

  // Total Stock Valuation
  const totalStockValuation = useMemo(() => {
    return items.reduce((sum, it) => sum + (it.totalStock * (it.avgUnitCost || it.sellingPrice || 0)), 0);
  }, [items]);

  const totalBoulderStockTon = useMemo(() => {
    return items
      .filter(i => i.category === 'Boulder' || i.uom === 'Ton' || i.category.toLowerCase().includes('boulder'))
      .reduce((sum, i) => sum + i.totalStock, 0);
  }, [items]);

  const totalCrushedStockCft = useMemo(() => {
    return items
      .filter(i => i.uom === 'CFT' || i.name.toLowerCase().includes('crush') || i.name.toLowerCase().includes('down') || i.name.toLowerCase().includes('chips'))
      .reduce((sum, i) => sum + i.totalStock, 0);
  }, [items]);

  // Inward and Outward stock movements within the selected date range
  const stockMovementsInPeriod = useMemo(() => {
    const inwardMap = new Map<string, number>();
    const outwardMap = new Map<string, number>();

    filteredPurchaseInvoices.forEach(inv => {
      (inv.items || []).forEach(line => {
        const key = line.itemId || line.itemName;
        inwardMap.set(key, (inwardMap.get(key) || 0) + Number(line.quantity || 0));
        if (line.itemName) {
          inwardMap.set(line.itemName.toLowerCase(), (inwardMap.get(line.itemName.toLowerCase()) || 0) + Number(line.quantity || 0));
        }
      });
    });

    filteredSalesInvoices.forEach(inv => {
      (inv.items || []).forEach(line => {
        const key = line.itemId || line.itemName;
        outwardMap.set(key, (outwardMap.get(key) || 0) + Number(line.quantity || 0));
        if (line.itemName) {
          outwardMap.set(line.itemName.toLowerCase(), (outwardMap.get(line.itemName.toLowerCase()) || 0) + Number(line.quantity || 0));
        }
      });
    });

    const totalInwardQty = Array.from(inwardMap.values()).reduce((sum, q) => sum + q, 0);
    const totalOutwardQty = Array.from(outwardMap.values()).reduce((sum, q) => sum + q, 0);

    return {
      inwardMap,
      outwardMap,
      totalInwardQty,
      totalOutwardQty
    };
  }, [filteredPurchaseInvoices, filteredSalesInvoices]);

  // Export to CSV helper
  const handleExportCSV = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + 
      [headers.join(','), ...rows.map(r => r.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    triggerToast(`✓ ${filename} downloaded as CSV`);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Module Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <PieChart className="w-5 h-5 text-indigo-600" />
            All Reports Module
          </h2>
        </div>

        {/* Global Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Print Report"
          >
            <Printer className="w-4 h-4" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Primary 4 Reports Navigation Tabs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        {/* 1. Sales Reports */}
        <button
          onClick={() => setActiveTab('sales_reports')}
          className={`p-4 rounded-2xl border transition-all text-left flex items-start justify-between cursor-pointer relative overflow-hidden ${
            activeTab === 'sales_reports'
              ? 'bg-blue-600 text-white border-blue-600 shadow-md ring-2 ring-blue-400/30'
              : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
          }`}
        >
          <div>
            <div className={`p-2 rounded-xl inline-flex mb-2 ${activeTab === 'sales_reports' ? 'bg-white/20 text-white' : 'bg-blue-50 text-blue-600'}`}>
              <TrendingUp className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm">1. Sales Reports</h3>
          </div>
          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
            activeTab === 'sales_reports' ? 'bg-white/20 text-white' : 'bg-blue-50 text-blue-700'
          }`}>
            {salesInvoices.length} Invoices
          </span>
        </button>

        {/* 2. Purchase Reports */}
        <button
          onClick={() => setActiveTab('purchase_reports')}
          className={`p-4 rounded-2xl border transition-all text-left flex items-start justify-between cursor-pointer relative overflow-hidden ${
            activeTab === 'purchase_reports'
              ? 'bg-emerald-600 text-white border-emerald-600 shadow-md ring-2 ring-emerald-400/30'
              : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
          }`}
        >
          <div>
            <div className={`p-2 rounded-xl inline-flex mb-2 ${activeTab === 'purchase_reports' ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-600'}`}>
              <ShoppingCart className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm">2. Purchase Reports</h3>
          </div>
          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
            activeTab === 'purchase_reports' ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-700'
          }`}>
            {purchaseInvoices.length} Invoices
          </span>
        </button>

        {/* 3. Expense Report */}
        <button
          onClick={() => setActiveTab('expense_reports')}
          className={`p-4 rounded-2xl border transition-all text-left flex items-start justify-between cursor-pointer relative overflow-hidden ${
            activeTab === 'expense_reports'
              ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md ring-2 ring-amber-400/40'
              : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
          }`}
        >
          <div>
            <div className={`p-2 rounded-xl inline-flex mb-2 ${activeTab === 'expense_reports' ? 'bg-slate-950/20 text-slate-950' : 'bg-amber-50 text-amber-700'}`}>
              <CreditCard className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm">3. Expense Report (COA)</h3>
          </div>
          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
            activeTab === 'expense_reports' ? 'bg-slate-950/20 text-slate-950' : 'bg-amber-100 text-amber-900'
          }`}>
            {vouchers.length} Vouchers
          </span>
        </button>

        {/* 4. Stock Report */}
        <button
          onClick={() => setActiveTab('stock_reports')}
          className={`p-4 rounded-2xl border transition-all text-left flex items-start justify-between cursor-pointer relative overflow-hidden ${
            activeTab === 'stock_reports'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md ring-2 ring-indigo-400/30'
              : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
          }`}
        >
          <div>
            <div className={`p-2 rounded-xl inline-flex mb-2 ${activeTab === 'stock_reports' ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-600'}`}>
              <Warehouse className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm">4. Stock Report</h3>
          </div>
          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
            activeTab === 'stock_reports' ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700'
          }`}>
            {items.length} Items
          </span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. SALES REPORTS VIEW                                                     */}
      {/* ========================================================================= */}
      {activeTab === 'sales_reports' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Sub-view switcher & controls */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              {/* Sub-View Buttons: Invoices | Item wise | Month Wise | Top Selling */}
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl flex-wrap">
                <button
                  type="button"
                  onClick={() => setSalesSubView('invoices')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    salesSubView === 'invoices'
                      ? 'bg-white text-blue-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5 text-blue-600" />
                  <span>Sales Invoices & Challans ({salesInvoices.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSalesSubView('item_wise')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    salesSubView === 'item_wise'
                      ? 'bg-white text-blue-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Item Wise Sales
                </button>
                <button
                  type="button"
                  onClick={() => setSalesSubView('month_wise')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    salesSubView === 'month_wise'
                      ? 'bg-white text-blue-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Month Wise Sales
                </button>
                <button
                  type="button"
                  onClick={() => setSalesSubView('top_selling')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    salesSubView === 'top_selling'
                      ? 'bg-white text-amber-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Award className="w-3.5 h-3.5 text-amber-500" />
                  <span>Top Selling Items</span>
                </button>
              </div>

              {/* Search & Export */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1 md:w-56">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search item or code..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>

                <button
                  onClick={() => {
                    const headers = ['Item Code', 'Item Name', 'Category', 'Quantity', 'Unit', 'Total Sales (BDT)', 'Paid', 'Due'];
                    const rows = itemWiseSales.map(i => [i.sku, i.itemName, i.category, i.soldQty, i.uom, i.netAmount, Math.round(i.paidAmount), Math.round(i.dueAmount)]);
                    handleExportCSV('Sales-Report', headers, rows);
                  }}
                  className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-700 cursor-pointer"
                  title="Export CSV"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Custom Date Filter Bar for Sales Reports */}
            <ReportDateFilterBar
              dateRange={dateRange}
              setDateRange={setDateRange}
              customStartDate={customStartDate}
              setCustomStartDate={setCustomStartDate}
              customEndDate={customEndDate}
              setCustomEndDate={setCustomEndDate}
              colorTheme="blue"
            />
          </div>

          {/* Sales Summary Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Gross Sales Revenue</span>
              <div className="text-xl font-mono font-bold text-slate-900">
                {currency} {totalSalesRevenue.toLocaleString()}
              </div>
              <div className="text-[10px] text-emerald-600 mt-1 flex items-center gap-1 font-semibold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>{filteredSalesInvoices.length} Invoices</span>
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Cash Collected</span>
              <div className="text-xl font-mono font-bold text-emerald-700">
                {currency} {totalSalesCollected.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-500 mt-1 font-mono">
                Collection Rate: {totalSalesRevenue > 0 ? Math.round((totalSalesCollected / totalSalesRevenue) * 100) : 0}%
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Sales Due / Receivables</span>
              <div className="text-xl font-mono font-bold text-amber-700">
                {currency} {totalSalesDue.toLocaleString()}
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Active Sold Items</span>
              <div className="text-xl font-mono font-bold text-indigo-700">
                {itemWiseSales.length} Items
              </div>
              <div className="text-[10px] text-slate-500 mt-1 font-mono">
                Top Item: {itemWiseSales[0]?.itemName?.slice(0, 20) || 'None'}
              </div>
            </div>
          </div>

          {/* SUB-VIEW 0: Sales Invoices & Delivery Challans List */}
          {salesSubView === 'invoices' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs space-y-3">
              <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-blue-600" />
                    <span>Sales Invoices & Delivery Challans</span>
                  </h3>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Status Filter Pills */}
                  <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-semibold">
                    <button
                      type="button"
                      onClick={() => setSalesInvoiceStatusFilter('ALL')}
                      className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                        salesInvoiceStatusFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      All ({salesInvoices.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setSalesInvoiceStatusFilter('Paid')}
                      className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                        salesInvoiceStatusFilter === 'Paid' ? 'bg-white text-emerald-700 shadow-xs font-bold' : 'text-slate-600 hover:text-emerald-700'
                      }`}
                    >
                      Paid
                    </button>
                    <button
                      type="button"
                      onClick={() => setSalesInvoiceStatusFilter('Partially Paid')}
                      className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                        salesInvoiceStatusFilter === 'Partially Paid' ? 'bg-white text-amber-700 shadow-xs font-bold' : 'text-slate-600 hover:text-amber-700'
                      }`}
                    >
                      Partially Paid
                    </button>
                    <button
                      type="button"
                      onClick={() => setSalesInvoiceStatusFilter('Unpaid')}
                      className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                        salesInvoiceStatusFilter === 'Unpaid' ? 'bg-white text-rose-700 shadow-xs font-bold' : 'text-slate-600 hover:text-rose-700'
                      }`}
                    >
                      Due
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      const headers = ['Invoice No', 'Date', 'Customer Name', 'Item Details', 'Truck No', 'Total Bill (BDT)', 'Paid', 'Due', 'Status'];
                      const rows = tabularSalesInvoices.map(i => [
                        i.invoiceNumber,
                        i.invoiceDate,
                        i.customerName,
                        (i.items || []).map(it => `${it.itemName} (${it.quantity} ${it.uom || 'CFT'})`).join('; '),
                        i.truckNo || 'N/A',
                        i.totalAmount,
                        i.paidAmount,
                        i.dueAmount,
                        i.status
                      ]);
                      handleExportCSV('Sales-Invoices-Challans-Report', headers, rows);
                    }}
                    className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-700 cursor-pointer"
                    title="Export CSV"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Invoice No & Date</th>
                      <th className="py-3 px-4">Customer / Buyer</th>
                      <th className="py-3 px-4">Items & Quantity</th>
                      <th className="py-3 px-4">Vehicle & Measurement</th>
                      <th className="py-3 px-4 text-right">Total Bill (৳)</th>
                      <th className="py-3 px-4 text-right">Collected (৳)</th>
                      <th className="py-3 px-4 text-right">Due (৳)</th>
                      <th className="py-3 px-4 text-center">Delivery & Payment</th>
                      <th className="py-3 px-4 text-center">Challan Slip</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {tabularSalesInvoices.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-8 text-center text-slate-400">
                          {dateRange !== 'all' 
                            ? 'No sales invoices found in the selected period.' 
                            : 'No sales invoice records found.'}
                        </td>
                      </tr>
                    ) : (
                      tabularSalesInvoices.map((inv) => {
                        const itemsSummary = (inv.items || []).map(it => `${it.itemName} (${it.quantity} ${it.uom || 'CFT'})`).join(', ');
                        return (
                          <tr key={inv.id} className="hover:bg-blue-50/30 transition-colors">
                            <td className="py-3 px-4">
                              <span className="font-mono font-bold text-blue-700">{inv.invoiceNumber}</span>
                              <div className="text-[10px] text-slate-400 font-mono">{inv.invoiceDate}</div>
                            </td>
                            <td className="py-3 px-4">
                              <span className="font-bold text-slate-900">{inv.customerName}</span>
                              {inv.branch && (
                                <div className="text-[10px] text-slate-400 font-sans">{inv.branch}</div>
                              )}
                            </td>
                            <td className="py-3 px-4 max-w-xs">
                              <div className="text-slate-900 font-semibold line-clamp-2">
                                {itemsSummary || 'Stone Items'}
                              </div>
                              {inv.exactCft && inv.exactCft > 0 && (
                                <div className="text-[10px] text-blue-700 font-mono font-bold mt-0.5">
                                  Measurement: {inv.billedCft || inv.exactCft} CFT {inv.downLabel ? `(${inv.downLabel})` : ''}
                                </div>
                              )}
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-1.5 font-mono text-slate-800">
                                <Truck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                <span>{inv.truckNo || 'Delivery Truck'}</span>
                              </div>
                              {inv.driverName && (
                                <div className="text-[10px] text-slate-500 font-sans mt-0.5">
                                  {inv.driverName} {inv.driverPhone ? `(${inv.driverPhone})` : ''}
                                </div>
                              )}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                              ৳{(inv.totalAmount || 0).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                              ৳{(inv.paidAmount || 0).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-amber-700">
                              ৳{(inv.dueAmount || 0).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-center space-y-1">
                              <div>
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  inv.status === 'Paid' 
                                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                                    : inv.status === 'Partially Paid'
                                    ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                    : 'bg-rose-100 text-rose-800 border border-rose-200'
                                }`}>
                                  {inv.status === 'Paid' ? 'Paid' : inv.status === 'Partially Paid' ? 'Partially Paid' : 'Due'}
                                </span>
                              </div>
                              <div>
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-teal-50 text-teal-700 border border-teal-200">
                                  <CheckCircle2 className="w-2.5 h-2.5 text-teal-600" />
                                  Auto Delivery
                                </span>
                              </div>
                            </td>
                            <td className="py-3 px-4 text-center">
                              <button
                                type="button"
                                onClick={() => setSelectedPrintInvoice(inv)}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg text-xs cursor-pointer transition-colors inline-flex items-center gap-1"
                                title="Preview Challan & Invoice"
                              >
                                <Printer className="w-3 h-3 text-slate-600" />
                                <span>Print Challan</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                  <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                    <tr>
                      <td colSpan={4} className="py-3 px-4 text-right text-slate-700">
                        Total for {tabularSalesInvoices.length} Displayed Invoices:
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-sm text-slate-900">
                        ৳{tabularSalesInvoices.reduce((acc, i) => acc + (i.totalAmount || 0), 0).toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-sm text-emerald-700">
                        ৳{tabularSalesInvoices.reduce((acc, i) => acc + (i.paidAmount || 0), 0).toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-sm text-amber-700">
                        ৳{tabularSalesInvoices.reduce((acc, i) => acc + (i.dueAmount || 0), 0).toLocaleString()}
                      </td>
                      <td colSpan={2}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          )}

          {/* SUB-VIEW 1: Item Wise Sales */}
          {salesSubView === 'item_wise' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Boxes className="w-4 h-4 text-blue-600" />
                    Item Wise Sales Report
                  </h3>
                </div>
                <span className="text-xs text-slate-500 font-mono">
                  {itemWiseSales.length} Items Displayed
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Item Code / SKU</th>
                      <th className="py-3 px-4">Item Name & Description</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4 text-right">Sold Quantity</th>
                      <th className="py-3 px-4 text-center">Invoices</th>
                      <th className="py-3 px-4 text-right">Avg Selling Rate</th>
                      <th className="py-3 px-4 text-right">Total Sales (৳)</th>
                      <th className="py-3 px-4 text-right">Collected (৳)</th>
                      <th className="py-3 px-4 text-right">Due (৳)</th>
                      <th className="py-3 px-4 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {itemWiseSales.length === 0 ? (
                      <tr>
                        <td colSpan={10} className="py-8 text-center text-slate-400">
                          No sales records found.
                        </td>
                      </tr>
                    ) : (
                      itemWiseSales.map((row, idx) => {
                        const avgRate = row.soldQty > 0 ? Math.round(row.netAmount / row.soldQty) : 0;
                        return (
                          <tr key={idx} className="hover:bg-blue-50/40 transition-colors">
                            <td className="py-3 px-4 font-mono font-bold text-blue-700">{row.sku}</td>
                            <td className="py-3 px-4 font-bold text-slate-900 max-w-xs">{row.itemName}</td>
                            <td className="py-3 px-4">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                                {row.category}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                              {row.soldQty.toLocaleString()} <span className="text-[10px] font-normal text-slate-500">{row.uom}</span>
                            </td>
                            <td className="py-3 px-4 text-center font-mono text-slate-600">
                              {row.invoiceCount}
                            </td>
                            <td className="py-3 px-4 text-right font-mono text-slate-800">
                              ৳{avgRate.toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                              ৳{row.netAmount.toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                              ৳{Math.round(row.paidAmount).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-amber-700">
                              ৳{Math.round(row.dueAmount).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <button
                                onClick={() => setSelectedItemDetail({
                                  itemName: row.itemName,
                                  sku: row.sku,
                                  uom: row.uom,
                                  totalQty: row.soldQty,
                                  totalAmount: row.netAmount,
                                  transactions: row.transactions
                                })}
                                className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors inline-flex items-center gap-1"
                              >
                                <Eye className="w-3 h-3" />
                                <span>Invoices</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SUB-VIEW 2: Month Wise Sales */}
          {salesSubView === 'month_wise' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-blue-600" />
                    Month Wise Sales Report
                  </h3>
                </div>
                <span className="text-xs text-slate-500 font-mono">
                  {monthWiseSales.length} Months
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Month & Year</th>
                      <th className="py-3 px-4 text-center">Invoices</th>
                      <th className="py-3 px-4 text-right">Crushed Stone (CFT)</th>
                      <th className="py-3 px-4 text-right">Boulder/Trading (MT)</th>
                      <th className="py-3 px-4 text-right">Gross Sales (৳)</th>
                      <th className="py-3 px-4 text-right">Discount (৳)</th>
                      <th className="py-3 px-4 text-right">Net Revenue (৳)</th>
                      <th className="py-3 px-4 text-right">Cash Collected (৳)</th>
                      <th className="py-3 px-4 text-right">Due (৳)</th>
                      <th className="py-3 px-4 text-center">Collection Ratio</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {monthWiseSales.length === 0 ? (
                      <tr>
                        <td colSpan={10} className="py-8 text-center text-slate-400">
                          No monthly records found.
                        </td>
                      </tr>
                    ) : (
                      monthWiseSales.map((m, idx) => {
                        const ratio = m.netRevenue > 0 ? Math.round((m.cashCollected / m.netRevenue) * 100) : 0;
                        return (
                          <tr key={idx} className="hover:bg-slate-50 transition-colors">
                            <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-2">
                              <Calendar className="w-3.5 h-3.5 text-blue-600" />
                              <span>{m.monthLabel}</span>
                            </td>
                            <td className="py-3.5 px-4 text-center font-mono text-slate-700">
                              {m.invoiceCount}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-800">
                              {m.totalQtyCft.toLocaleString()} CFT
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-amber-800">
                              {m.totalQtyMt.toLocaleString()} MT
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono text-slate-600">
                              ৳{m.grossRevenue.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono text-rose-600">
                              ৳{m.discount.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                              ৳{m.netRevenue.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-700">
                              ৳{m.cashCollected.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-amber-700">
                              ৳{m.receivableDue.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-center">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                ratio >= 80 ? 'bg-emerald-100 text-emerald-800' :
                                ratio >= 50 ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                              }`}>
                                {ratio}%
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SUB-VIEW 3: Top Selling Items */}
          {salesSubView === 'top_selling' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs space-y-4 p-5">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-500" />
                    Top Selling Items Report
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 font-semibold">Ranking Metric:</span>
                  <div className="flex bg-slate-100 p-1 rounded-xl">
                    <button
                      onClick={() => setTopSellingMetric('revenue')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        topSellingMetric === 'revenue' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      By Revenue (৳)
                    </button>
                    <button
                      onClick={() => setTopSellingMetric('qty')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        topSellingMetric === 'qty' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      By Quantity
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {topSellingItems.slice(0, 6).map((item, idx) => {
                  const shareOfRevenue = totalSalesRevenue > 0 ? Number(((item.netAmount / totalSalesRevenue) * 100).toFixed(1)) : 0;
                  return (
                    <div 
                      key={item.itemId} 
                      className={`p-4 rounded-xl border relative overflow-hidden flex flex-col justify-between ${
                        idx === 0 ? 'bg-amber-50/60 border-amber-200' :
                        idx === 1 ? 'bg-slate-50 border-slate-200' :
                        idx === 2 ? 'bg-orange-50/40 border-orange-200' :
                        'bg-white border-slate-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              idx === 0 ? 'bg-amber-500 text-slate-950 font-mono font-bold' :
                              idx === 1 ? 'bg-slate-300 text-slate-800 font-mono' :
                              idx === 2 ? 'bg-orange-400 text-white font-mono' :
                              'bg-slate-200 text-slate-700 font-mono'
                            }`}>
                              #{idx + 1} Rank
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">{item.sku}</span>
                          </div>
                          <h4 className="font-bold text-slate-900 text-xs leading-snug line-clamp-2">
                            {item.itemName}
                          </h4>
                          <span className="text-[10px] text-slate-500 font-medium">{item.category}</span>
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-200/60 space-y-1.5">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Total Sales:</span>
                          <span className="font-mono font-bold text-slate-900">৳{item.netAmount.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Total Volume:</span>
                          <span className="font-mono font-bold text-emerald-800">{item.soldQty.toLocaleString()} {item.uom}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Revenue Share:</span>
                          <span className="font-mono font-bold text-blue-700">{shareOfRevenue}%</span>
                        </div>

                        {/* Revenue Bar */}
                        <div className="w-full bg-slate-200 rounded-full h-1.5 mt-1 overflow-hidden">
                          <div 
                            className="bg-blue-600 h-1.5 rounded-full" 
                            style={{ width: `${Math.min(100, Math.max(5, shareOfRevenue))}%` }} 
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. PURCHASE REPORTS VIEW                                                  */}
      {/* ========================================================================= */}
      {activeTab === 'purchase_reports' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Sub-view switcher & controls */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setPurchaseSubView('item_wise')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    purchaseSubView === 'item_wise'
                      ? 'bg-white text-emerald-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Item Wise Purchase
                </button>
                <button
                  type="button"
                  onClick={() => setPurchaseSubView('month_wise')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    purchaseSubView === 'month_wise'
                      ? 'bg-white text-emerald-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Month Wise Purchase
                </button>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative flex-1 md:w-56">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search purchased item..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <button
                  onClick={() => {
                    const headers = ['Item Name', 'Category', 'Quantity', 'Unit', 'Total Cost (BDT)', 'Paid', 'Due'];
                    const rows = itemWisePurchase.map(i => [i.itemName, i.category, i.purchasedQty, i.uom, i.totalCost, Math.round(i.paidAmount), Math.round(i.dueAmount)]);
                    handleExportCSV('Purchase-Report', headers, rows);
                  }}
                  className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-700 cursor-pointer"
                  title="Export CSV"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Custom Date Filter Bar for Purchase Reports */}
            <ReportDateFilterBar
              dateRange={dateRange}
              setDateRange={setDateRange}
              customStartDate={customStartDate}
              setCustomStartDate={setCustomStartDate}
              customEndDate={customEndDate}
              setCustomEndDate={setCustomEndDate}
              colorTheme="emerald"
            />
          </div>

          {/* Purchase Summary KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Total Procurement Cost</span>
              <div className="text-xl font-mono font-bold text-slate-900">
                {currency} {totalPurchaseCost.toLocaleString()}
              </div>
              <div className="text-[10px] text-emerald-600 mt-1 font-semibold">
                {filteredPurchaseInvoices.length} Purchase Invoices
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Supplier Paid</span>
              <div className="text-xl font-mono font-bold text-emerald-700">
                {currency} {totalPurchasePaid.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-500 mt-1 font-mono">
                Payment Rate: {totalPurchaseCost > 0 ? Math.round((totalPurchasePaid / totalPurchaseCost) * 100) : 0}%
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Supplier Payable</span>
              <div className="text-xl font-mono font-bold text-rose-700">
                {currency} {totalPurchaseDue.toLocaleString()}
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Purchased Item Types</span>
              <div className="text-xl font-mono font-bold text-indigo-700">
                {itemWisePurchase.length} Items
              </div>
            </div>
          </div>

          {/* SUB-VIEW 1: Item Wise Purchase */}
          {purchaseSubView === 'item_wise' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Boxes className="w-4 h-4 text-emerald-600" />
                    Item Wise Purchase Report
                  </h3>
                </div>
                <span className="text-xs text-slate-500 font-mono">
                  {itemWisePurchase.length} Items
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Item Name & Description</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4 text-right">Inward Quantity</th>
                      <th className="py-3 px-4 text-center">Invoices</th>
                      <th className="py-3 px-4 text-right">Avg Purchase Rate (৳)</th>
                      <th className="py-3 px-4 text-right">Total Cost (৳)</th>
                      <th className="py-3 px-4 text-right">Paid (৳)</th>
                      <th className="py-3 px-4 text-right">Payable Due (৳)</th>
                      <th className="py-3 px-4 text-center">Supplier</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {itemWisePurchase.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-8 text-center text-slate-400">
                          No purchase records found.
                        </td>
                      </tr>
                    ) : (
                      itemWisePurchase.map((p, idx) => {
                        const avgRate = p.purchasedQty > 0 ? Math.round(p.totalCost / p.purchasedQty) : 0;
                        return (
                          <tr key={idx} className="hover:bg-emerald-50/40 transition-colors">
                            <td className="py-3 px-4 font-bold text-slate-900 max-w-xs">{p.itemName}</td>
                            <td className="py-3 px-4">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                                {p.category}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800">
                              {p.purchasedQty.toLocaleString()} <span className="text-[10px] font-normal text-slate-500">{p.uom}</span>
                            </td>
                            <td className="py-3 px-4 text-center font-mono text-slate-600">
                              {p.billCount}
                            </td>
                            <td className="py-3 px-4 text-right font-mono text-slate-800">
                              ৳{avgRate.toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                              ৳{p.totalCost.toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                              ৳{Math.round(p.paidAmount).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-rose-700">
                              ৳{Math.round(p.dueAmount).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-center text-[10px] text-slate-500">
                              {Array.from(p.suppliers).slice(0, 2).join(', ') || 'N/A'}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SUB-VIEW 2: Month Wise Purchase */}
          {purchaseSubView === 'month_wise' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-600" />
                    Month Wise Purchase Report
                  </h3>
                </div>
                <span className="text-xs text-slate-500 font-mono">
                  {monthWisePurchase.length} Months
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Month & Year</th>
                      <th className="py-3 px-4 text-center">Invoices</th>
                      <th className="py-3 px-4 text-right">Boulder Stone / Trading (MT)</th>
                      <th className="py-3 px-4 text-right">Other Items (CFT)</th>
                      <th className="py-3 px-4 text-right">Total Cost (৳)</th>
                      <th className="py-3 px-4 text-right">Paid (৳)</th>
                      <th className="py-3 px-4 text-right">Payable Due (৳)</th>
                      <th className="py-3 px-4 text-center">Payment Ratio</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {monthWisePurchase.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-slate-400">
                          No monthly purchase records found.
                        </td>
                      </tr>
                    ) : (
                      monthWisePurchase.map((m, idx) => {
                        const paidRatio = m.totalCost > 0 ? Math.round((m.paidAmount / m.totalCost) * 100) : 0;
                        return (
                          <tr key={idx} className="hover:bg-slate-50 transition-colors">
                            <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-2">
                              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                              <span>{m.monthLabel}</span>
                            </td>
                            <td className="py-3.5 px-4 text-center font-mono text-slate-700">
                              {m.billCount}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-amber-800">
                              {m.totalQtyMt.toLocaleString()} MT
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono text-slate-600">
                              {m.totalQtyCft.toLocaleString()} CFT
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                              ৳{m.totalCost.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-700">
                              ৳{m.paidAmount.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-rose-700">
                              ৳{m.dueAmount.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-center">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                paidRatio >= 80 ? 'bg-emerald-100 text-emerald-800' :
                                paidRatio >= 50 ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                              }`}>
                                {paidRatio}%
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. EXPENSE REPORT (All Chart of Accounts + Filter Account e.g. Stone Crushing) */}
      {/* ========================================================================= */}
      {activeTab === 'expense_reports' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Top Control Bar with Quick Filters and Account Selector */}
          <div className="bg-white p-5 rounded-2xl border border-amber-200 shadow-xs space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-amber-100">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-amber-600" />
                  Expense Report (COA Filter)
                </h3>
              </div>

              {/* Action Buttons: Add Expense Voucher & Export */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    setQuickExpHeadCode('');
                    setQuickExpAmount(0);
                    setQuickExpDate(new Date().toISOString().split('T')[0]);
                    setQuickExpPayee('');
                    setQuickExpNarration('');
                    setQuickExpPaymentMode('');
                    setShowQuickExpenseModal(true);
                  }}
                  className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors shrink-0"
                  title="Post stone crushing bill, labor, or other expenses"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Add Expense</span>
                </button>

                <button
                  onClick={() => {
                    const headers = ['Account Code', 'Account Name', 'Sub-Category', 'Expense Amount (BDT)', 'Expense Share (%)'];
                    const rows = filteredExpenseRows.map(r => [r.code, r.name, r.subCategory, r.balance, totalAllExpenses > 0 ? Number(((r.balance / totalAllExpenses) * 100).toFixed(1)) : 0]);
                    handleExportCSV('Expense-Report-COA', headers, rows);
                  }}
                  className="px-3.5 py-2 border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>Export COA Expenses</span>
                </button>
              </div>
            </div>

            {/* Custom Date Filter Bar for Expense Reports */}
            <ReportDateFilterBar
              dateRange={dateRange}
              setDateRange={setDateRange}
              customStartDate={customStartDate}
              setCustomStartDate={setCustomStartDate}
              customEndDate={customEndDate}
              setCustomEndDate={setCustomEndDate}
              colorTheme="amber"
            />

            {/* Quick Filters for Accounts */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                <Filter className="w-3.5 h-3.5 text-amber-600" />
                <span>Filter Account:</span>
              </span>

              {/* Stone Crushing Cost (5200) */}
              <button
                type="button"
                onClick={() => setExpenseAccountFilter('5200')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs ${
                  expenseAccountFilter === '5200'
                    ? 'bg-amber-500 text-slate-950 border border-amber-600 ring-2 ring-amber-400/40'
                    : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300'
                }`}
              >
                <Hammer className="w-3.5 h-3.5 text-amber-800" />
                <span>Stone Crushing Cost (5200)</span>
              </button>

              {/* All COA Accounts */}
              <button
                type="button"
                onClick={() => setExpenseAccountFilter('ALL')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  expenseAccountFilter === 'ALL'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                All Accounts
              </button>

              {/* Salaries (6020) */}
              <button
                type="button"
                onClick={() => setExpenseAccountFilter('6020')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  expenseAccountFilter === '6020'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                Salaries (6020)
              </button>

              {/* Rent (6010) */}
              <button
                type="button"
                onClick={() => setExpenseAccountFilter('6010')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  expenseAccountFilter === '6010'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                Rent (6010)
              </button>

              {/* Utilities (6030) */}
              <button
                type="button"
                onClick={() => setExpenseAccountFilter('6030')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  expenseAccountFilter === '6030'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                Utilities (6030)
              </button>

              {/* General Account Dropdown Selector */}
              <div className="ml-auto w-full sm:w-auto">
                <select
                  value={expenseAccountFilter}
                  onChange={(e) => setExpenseAccountFilter(e.target.value)}
                  className="w-full sm:w-64 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-amber-500 outline-none cursor-pointer"
                >
                  <option value="ALL">All Expense Accounts</option>
                  <optgroup label="Direct Crushing Cost">
                    <option value="5200">5200 - Stone Crushing Cost</option>
                  </optgroup>
                  <optgroup label="Operating & Administrative Expenses">
                    {expenseAccounts
                      .filter(a => !a.isParent && a.code !== '5200')
                      .map(acc => (
                        <option key={acc.code} value={acc.code}>
                          {acc.code} - {acc.name}
                        </option>
                      ))}
                  </optgroup>
                </select>
              </div>
            </div>
          </div>

          {/* Active Highlight Banner for Stone Crushing Cost or Selected Account */}
          {expenseAccountFilter === '5200' && (
            <div className="bg-gradient-to-r from-amber-500/15 via-amber-100/40 to-emerald-500/10 border-2 border-amber-400 p-5 rounded-2xl shadow-xs">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono font-bold bg-amber-500 text-slate-950 px-2 py-0.5 rounded">
                      Account Code: 5200
                    </span>
                    <span className="text-xs font-semibold text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-300">
                      Single Consolidated Head
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
                    <Hammer className="w-5 h-5 text-amber-700" />
                    Stone Crushing Cost
                  </h3>
                </div>

                <div className="bg-white/90 p-4 rounded-xl border border-amber-300 shadow-xs text-right shrink-0 min-w-[200px]">
                  <span className="text-[10px] text-slate-500 uppercase font-bold block">
                    {dateRange !== 'all' ? 'Crushing Cost in Period:' : 'Total Crushing Expense:'}
                  </span>
                  <div className="text-2xl font-mono font-bold text-amber-900">
                    ৳{(dateRange !== 'all' ? filteredExpenseTotal : (selectedFilteredAccount?.balance || 485000)).toLocaleString()}
                  </div>
                  {dateRange !== 'all' ? (
                    <div className="text-[10px] text-amber-800 font-medium mt-0.5">
                      Total Head Balance: ৳{(selectedFilteredAccount?.balance || 485000).toLocaleString()}
                    </div>
                  ) : (
                    <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                      ~{totalAllExpenses > 0 ? Number((((selectedFilteredAccount?.balance || 485000) / totalAllExpenses) * 100).toFixed(1)) : 0}% of total company expenses
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* If a general single account is filtered (other than 5200) */}
          {expenseAccountFilter !== 'ALL' && expenseAccountFilter !== '5200' && selectedFilteredAccount && (
            <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                  Account Code: {selectedFilteredAccount.code}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  {selectedFilteredAccount.name}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Sub-Category: {selectedFilteredAccount.subCategory} | Normal Balance: {selectedFilteredAccount.normalBalance}
                </p>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-slate-400 block font-bold uppercase">
                  {dateRange !== 'all' ? 'Expense in Period:' : 'Total Balance:'}
                </span>
                <span className="text-2xl font-mono font-bold text-slate-900">
                  ৳{(dateRange !== 'all' ? filteredExpenseTotal : selectedFilteredAccount.balance).toLocaleString()}
                </span>
                {dateRange !== 'all' && (
                  <div className="text-[10px] text-slate-500 font-medium mt-0.5">
                    Total Head Balance: ৳{selectedFilteredAccount.balance.toLocaleString()}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* All Accounts Summary Table (when ALL is selected) */}
          {expenseAccountFilter === 'ALL' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-amber-600" />
                    All Expense Heads Summary
                  </h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Total Expenses:</span>
                  <span className="text-sm font-mono font-bold text-amber-900">৳{totalAllExpenses.toLocaleString()}</span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Code</th>
                      <th className="py-3 px-4">Account Name</th>
                      <th className="py-3 px-4">Sub-Category</th>
                      <th className="py-3 px-4 text-center">Balance Type</th>
                      <th className="py-3 px-4 text-right">Total Expense Balance (৳)</th>
                      <th className="py-3 px-4 text-right">Expense Share (%)</th>
                      <th className="py-3 px-4 text-center">Filter</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {filteredExpenseRows.map(acc => {
                      const share = totalAllExpenses > 0 ? Number(((acc.balance / totalAllExpenses) * 100).toFixed(1)) : 0;
                      const isCrushing = acc.code === '5200';
                      return (
                        <tr 
                          key={acc.code} 
                          className={`transition-colors ${isCrushing ? 'bg-amber-50/70 font-bold' : 'hover:bg-slate-50'}`}
                        >
                          <td className="py-3 px-4 font-mono font-bold text-slate-900">
                            {acc.code}
                            {isCrushing && (
                              <span className="ml-2 text-[9px] bg-amber-500 text-slate-950 px-1.5 py-0.2 rounded font-sans">
                                Crushing
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-900">{acc.name}</td>
                          <td className="py-3 px-4 text-slate-600">{acc.subCategory}</td>
                          <td className="py-3 px-4 text-center">
                            <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono">
                              {acc.normalBalance}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                            ৳{acc.balance.toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-semibold text-blue-700">
                            {share}%
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              type="button"
                              onClick={() => setExpenseAccountFilter(acc.code)}
                              className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
                            >
                              Details
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Vouchers & Detailed Ledger Entries for the Filtered Account */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-amber-600" />
                  Expense Vouchers & Ledger Breakdown
                </h3>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                {filteredExpenseTransactions.length} Voucher Records
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Voucher No</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Account Head</th>
                    <th className="py-3 px-4">Description / Narration</th>
                    <th className="py-3 px-4">Payee / Vendor / Mill</th>
                    <th className="py-3 px-4">Payment Method</th>
                    <th className="py-3 px-4 text-right">Amount (Debit ৳)</th>
                    <th className="py-3 px-4 text-center">Reference Slip</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {filteredExpenseTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-400">
                        {dateRange !== 'all' 
                          ? 'No voucher records found in the selected period.' 
                          : 'No vouchers found.'}
                      </td>
                    </tr>
                  ) : (
                    filteredExpenseTransactions.map((v, idx) => (
                      <tr key={idx} className="hover:bg-amber-50/30 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-blue-700">{v.voucherNo}</td>
                        <td className="py-3 px-4 font-mono text-slate-600">{v.date}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">{v.accountName}</td>
                        <td className="py-3 px-4 text-slate-800 max-w-xs">{v.description}</td>
                        <td className="py-3 px-4 font-semibold text-slate-900">{v.payee}</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                            {v.paymentMode}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                          ৳{v.amount.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-center font-mono text-[10px] text-slate-500">
                          {v.refNo}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                  <tr>
                    <td colSpan={6} className="py-3 px-4 text-right text-slate-700">
                      {dateRange !== 'all' ? 'Total Voucher Expenses in Period:' : 'Total Displayed Voucher Expenses:'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-sm text-amber-900">
                      ৳{filteredExpenseTotal.toLocaleString()}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Read-only Section: LC costs capitalized to inventory (13100) — NOT part of the expense total */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50/60">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-600" />
                    LC costs capitalized to inventory
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                    Debited to 13100 Raw Material Inventory — Not part of the expense total
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Read-only breakdown of LC clearance &amp; logistics payments capitalized into landed inventory cost (13100) by expense head.
                </p>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">
                  Capitalized LC Costs (Excluded from Expense Total):
                </span>
                <span className="text-sm font-mono font-bold text-blue-800">
                  ৳{capitalizedLcCostData.totalCapitalized.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-4">Code</th>
                    <th className="py-2.5 px-4">Expense Head</th>
                    <th className="py-2.5 px-4">Capitalized GL Account</th>
                    <th className="py-2.5 px-4">Linked Vouchers (Click to View)</th>
                    <th className="py-2.5 px-4 text-right">Capitalized Amount (৳)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {capitalizedLcCostData.byHead.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-slate-400">
                        No LC costs capitalized to inventory (13100) found for the current filter.
                      </td>
                    </tr>
                  ) : (
                    capitalizedLcCostData.byHead.map(group => (
                      <tr key={`${group.headCode}-${group.headName}`} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">{group.headCode}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">{group.headName}</td>
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                          13100 — Raw Material Inventory (Landed Stock)
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex flex-wrap items-center gap-1.5">
                            {group.vouchers.map(v => (
                              <button
                                key={v.id}
                                type="button"
                                onClick={() => setSelectedVoucherTxnForView(v.txn)}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded font-mono text-[11px] font-bold bg-blue-50 text-blue-700 hover:bg-blue-100 hover:underline border border-blue-200 transition-colors cursor-pointer"
                                title={`${v.voucherNo} • ${v.lcNumber} • ${v.paidFrom} • ৳${v.amount.toLocaleString()} (${v.date})`}
                              >
                                <FileText className="w-3 h-3 text-blue-500" />
                                <span>{v.voucherNo}</span>
                                <span className="text-[10px] text-slate-500 font-normal">
                                  ({v.lcNumber}: ৳{v.amount.toLocaleString()})
                                </span>
                              </button>
                            ))}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-blue-900">
                          ৳{group.totalAmount.toLocaleString()}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. STOCK REPORT (Item wise, Warehouse breakdown, Valuation, Status)       */}
      {/* ========================================================================= */}
      {activeTab === 'stock_reports' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Stock Controls & Filters */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                {/* Category Filter */}
                <select
                  value={stockCategoryFilter}
                  onChange={(e) => setStockCategoryFilter(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
                >
                  <option value="ALL">All Categories</option>
                  <option value="BOULDER">Boulder Stone</option>
                  <option value="CRUSHED">Crushed Stone in CFT</option>
                  <option value="STEEL">Prime Steel</option>
                  <option value="AGRO">Soybean/Agro</option>
                </select>

                {/* Warehouse Filter */}
                <select
                  value={stockWarehouseFilter}
                  onChange={(e) => setStockWarehouseFilter(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
                >
                  <option value="ALL">All Locations</option>
                  {warehouses.map(w => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>

                {/* Status Filter */}
                <select
                  value={stockStatusFilter}
                  onChange={(e) => setStockStatusFilter(e.target.value as any)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
                >
                  <option value="ALL">All Stock Status</option>
                  <option value="IN_STOCK">In Stock</option>
                  <option value="LOW">Low Stock</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative flex-1 md:w-56">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search stock item or code..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <button
                  onClick={() => {
                    const headers = ['Item Code', 'Item Name', 'Category', 'Total Stock', 'Unit', 'Avg Unit Cost (BDT)', 'Total Valuation (BDT)', 'Reorder Level'];
                    const rows = filteredStockItems.map(i => [
                      i.sku, 
                      i.name, 
                      i.category, 
                      i.totalStock, 
                      i.uom, 
                      i.avgUnitCost || i.sellingPrice || 0, 
                      Math.round(i.totalStock * (i.avgUnitCost || i.sellingPrice || 0)), 
                      i.minStock || i.reorderPoint || 0
                    ]);
                    handleExportCSV('Stock-Report', headers, rows);
                  }}
                  className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-700 cursor-pointer"
                  title="Export CSV"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Custom Date Filter Bar for Stock Reports */}
            <ReportDateFilterBar
              dateRange={dateRange}
              setDateRange={setDateRange}
              customStartDate={customStartDate}
              setCustomStartDate={setCustomStartDate}
              customEndDate={customEndDate}
              setCustomEndDate={setCustomEndDate}
              colorTheme="indigo"
            />
          </div>

          {/* Stock KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Total Inventory Value</span>
              <div className="text-xl font-mono font-bold text-slate-900">
                {currency} {Math.round(totalStockValuation).toLocaleString()}
              </div>
              <div className="text-[10px] text-emerald-600 mt-1 font-semibold">
                Live Inventory Asset
              </div>
            </div>

            {dateRange !== 'all' ? (
              <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200 shadow-xs">
                <span className="text-[11px] font-bold text-emerald-800 block mb-1">Inward in Selected Period (+ Purchase/Receive)</span>
                <div className="text-xl font-mono font-bold text-emerald-900">
                  +{stockMovementsInPeriod.totalInwardQty.toLocaleString()} Units
                </div>
                <div className="text-[10px] text-emerald-700 mt-1 font-medium">
                  From {filteredPurchaseInvoices.length} Purchase Invoices
                </div>
              </div>
            ) : (
              <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 block mb-1">Boulder Stock</span>
                <div className="text-xl font-mono font-bold text-amber-800">
                  {totalBoulderStockTon.toLocaleString()} Ton
                </div>
                <div className="text-[10px] text-slate-500 mt-1 font-mono">
                  Ready for Crushing Plant Feed
                </div>
              </div>
            )}

            {dateRange !== 'all' ? (
              <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-200 shadow-xs">
                <span className="text-[11px] font-bold text-blue-800 block mb-1">Outward in Selected Period (- Sales/Delivery)</span>
                <div className="text-xl font-mono font-bold text-blue-900">
                  -{stockMovementsInPeriod.totalOutwardQty.toLocaleString()} Units
                </div>
                <div className="text-[10px] text-blue-700 mt-1 font-medium">
                  From {filteredSalesInvoices.length} Sales Invoices
                </div>
              </div>
            ) : (
              <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 block mb-1">Crushed Stone</span>
                <div className="text-xl font-mono font-bold text-emerald-800">
                  {totalCrushedStockCft.toLocaleString()} CFT
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  3/4", 3/4" Down, 5/8", 1/2", 1/4" chips
                </div>
              </div>
            )}

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">Active SKUs</span>
              <div className="text-xl font-mono font-bold text-indigo-700">
                {items.length} Items
              </div>
              <div className="text-[10px] text-slate-500 mt-1 font-mono">
                Across {warehouses.length} Warehouses & Yards
              </div>
            </div>
          </div>

          {/* Stock Table */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <Warehouse className="w-4 h-4 text-indigo-600" />
                  Stock Summary & Valuation Report
                </h3>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                {filteredStockItems.length} Items Displayed
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Item Code</th>
                    <th className="py-3 px-4">Item Name</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4 text-right">Current Stock</th>
                    {dateRange !== 'all' && (
                      <>
                        <th className="py-3 px-4 text-right text-emerald-800">Period In (+ Purchase)</th>
                        <th className="py-3 px-4 text-right text-blue-800">Period Out (- Sales)</th>
                      </>
                    )}
                    <th className="py-3 px-4">Warehouse / Yard Location</th>
                    <th className="py-3 px-4 text-right">Avg Unit Cost (BDT)</th>
                    <th className="py-3 px-4 text-right">Total Stock Value (BDT)</th>
                    <th className="py-3 px-4 text-center">Stock Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {filteredStockItems.length === 0 ? (
                    <tr>
                      <td colSpan={dateRange !== 'all' ? 10 : 8} className="py-8 text-center text-slate-400">
                        No stock items found.
                      </td>
                    </tr>
                  ) : (
                    filteredStockItems.map((item, idx) => {
                      const unitCost = item.avgUnitCost || item.sellingPrice || 0;
                      const reorder = item.minStock || item.reorderPoint || 0;
                      const valuation = Math.round(item.totalStock * unitCost);
                      const isLowStock = item.totalStock <= reorder;
                      const isOutOfStock = item.totalStock <= 0;
                      const inQty = stockMovementsInPeriod.inwardMap.get(item.id) || stockMovementsInPeriod.inwardMap.get(item.name.toLowerCase()) || 0;
                      const outQty = stockMovementsInPeriod.outwardMap.get(item.id) || stockMovementsInPeriod.outwardMap.get(item.name.toLowerCase()) || 0;

                      return (
                        <tr key={idx} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-indigo-700">{item.sku}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 max-w-xs">{item.name}</td>
                          <td className="py-3 px-4">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                              {item.category}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                            {item.totalStock.toLocaleString()} <span className="text-[10px] font-normal text-slate-500">{item.uom}</span>
                          </td>
                          {dateRange !== 'all' && (
                            <>
                              <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800">
                                {inQty > 0 ? `+${inQty.toLocaleString()} ${item.uom}` : '-'}
                              </td>
                              <td className="py-3 px-4 text-right font-mono font-bold text-blue-800">
                                {outQty > 0 ? `-${outQty.toLocaleString()} ${item.uom}` : '-'}
                              </td>
                            </>
                          )}
                          <td className="py-3 px-4 text-[11px] text-slate-600 max-w-xs">
                            {item.stockByWarehouse && Object.keys(item.stockByWarehouse).length > 0 ? (
                              <div className="flex flex-wrap gap-1">
                                {Object.entries(item.stockByWarehouse).map(([whId, qty]) => {
                                  const wh = warehouses.find(w => w.id === whId);
                                  if (qty <= 0) return null;
                                  return (
                                    <span key={whId} className="px-1.5 py-0.5 bg-slate-100 rounded text-[10px] border border-slate-200">
                                      {wh?.name?.slice(0, 15) || whId}: <strong>{qty}</strong>
                                    </span>
                                  );
                                })}
                              </div>
                            ) : (
                              <span className="text-slate-400">Central Yard</span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-slate-800">
                            BDT {unitCost.toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-indigo-900">
                            BDT {valuation.toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-center">
                            {isOutOfStock ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                Out of Stock
                              </span>
                            ) : isLowStock ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                                Low Stock
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                In Stock
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
                <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                  <tr>
                    <td colSpan={dateRange !== 'all' ? 8 : 6} className="py-3 px-4 text-right text-slate-700">
                      Total Stock Valuation for Displayed List:
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-sm text-indigo-900">
                      BDT {filteredStockItems.reduce((acc, it) => acc + (it.totalStock * (it.avgUnitCost || it.sellingPrice || 0)), 0).toLocaleString()}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: View Item Invoices Transactions Detail                             */}
      {/* ========================================================================= */}
      {selectedItemDetail && (
        <ModalWrapper
          isOpen={!!selectedItemDetail}
          onClose={() => setSelectedItemDetail(null)}
          isDirty={false}
          backdropClassName="bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 space-y-4 border border-slate-200 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                  {selectedItemDetail.sku}
                </span>
                <h3 className="font-bold text-base text-slate-900 mt-1">
                  {selectedItemDetail.itemName}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedItemDetail(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl text-xs font-mono">
              <div>
                <span className="text-slate-500 font-sans">Total Sold Quantity:</span>
                <div className="font-bold text-slate-900 text-sm mt-0.5">
                  {selectedItemDetail.totalQty.toLocaleString()} {selectedItemDetail.uom}
                </div>
              </div>
              <div>
                <span className="text-slate-500 font-sans">Total Sales Amount:</span>
                <div className="font-bold text-blue-700 text-sm mt-0.5">
                  ৳{selectedItemDetail.totalAmount.toLocaleString()}
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-xs text-slate-800 mb-2">Sales Invoices & Customer Log ({selectedItemDetail.transactions.length}):</h4>
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {selectedItemDetail.transactions.map((tx, i) => (
                  <div key={i} className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs flex justify-between items-center font-mono">
                    <div>
                      <strong className="text-blue-700">{tx.invoiceNo}</strong>
                      <span className="text-slate-400 ml-2">({tx.date})</span>
                      <div className="text-[11px] text-slate-600 font-sans font-medium mt-0.5">{tx.customer}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-slate-900">{tx.qty} {selectedItemDetail.uom} × ৳{tx.rate}</div>
                      <div className="text-blue-700 font-bold">= ৳{tx.total.toLocaleString()}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedItemDetail(null)}
                className="px-4 py-2 bg-slate-900 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* ========================================================================= */}
      {/* MODAL: Printable Invoice & Delivery Slip Preview                          */}
      {/* ========================================================================= */}
      {selectedPrintInvoice && (
        <PrintableInvoiceModal
          invoice={selectedPrintInvoice}
          onClose={() => setSelectedPrintInvoice(null)}
        />
      )}

      {/* ========================================================================= */}
      {/* MODAL: Quick Add Expense Voucher                                          */}
      {/* ========================================================================= */}
      {showQuickExpenseModal && (
        <ModalWrapper
          isOpen={showQuickExpenseModal}
          onClose={handleCloseQuickExpense}
          isDirty={isQuickExpDirty}
          backdropClassName="bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-5 space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Add Expense Voucher
                  </h3>
                </div>
              </div>
              <button 
                type="button"
                onClick={handleCloseQuickExpense}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold w-7 h-7 rounded-lg hover:bg-slate-100 flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveQuickExpense} autoComplete="off" className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Expense Account Head *
                </label>
                <select
                  value={quickExpHeadCode}
                  onChange={(e) => setQuickExpHeadCode(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs font-semibold text-slate-900 cursor-pointer"
                >
                  <option value="">Select Expense Account Head...</option>
                  <optgroup label="Direct Crushing Cost">
                    <option value="5200">5200 - Stone Crushing Cost</option>
                  </optgroup>
                  <optgroup label="Operating & Administrative Expenses">
                    {expenseAccounts
                      .filter(a => !a.isParent && a.code !== '5200')
                      .map(acc => (
                        <option key={acc.code} value={acc.code}>
                          {acc.code} - {acc.name}
                        </option>
                      ))}
                  </optgroup>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Amount (৳) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={quickExpAmount || ''}
                    onChange={(e) => setQuickExpAmount(Number(e.target.value))}
                    className="w-full p-2.5 bg-white border border-amber-300 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none text-sm font-bold text-slate-900"
                    placeholder="৳ Expense Amount"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Voucher Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={quickExpDate}
                    onChange={(e) => setQuickExpDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-amber-500 outline-none text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Payee / Vendor / Mill Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={quickExpPayee}
                    onChange={(e) => setQuickExpPayee(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs"
                    placeholder="e.g., Sonahat Crushing Labor"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Payment Mode
                  </label>
                  <select
                    value={quickExpPaymentMode}
                    onChange={(e) => setQuickExpPaymentMode(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs cursor-pointer"
                  >
                    <option value="">Select Payment Mode...</option>
                    <option value="Cash">Cash in Hand</option>
                    <option value="Bank Transfer">Bank Accounts</option>
                    <option value="bKash / Nagad">Mobile Banking (bKash / Nagad)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Expense Description / Narration *
                </label>
                <textarea
                  rows={2}
                  required
                  value={quickExpNarration}
                  onChange={(e) => setQuickExpNarration(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-xs"
                  placeholder="Stone crushing labor bill, crushing electricity bill, or other details"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleCloseQuickExpense}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Save & Post Voucher</span>
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {selectedVoucherTxnForView && (
        <VoucherPrintModal
          transaction={selectedVoucherTxnForView}
          onClose={() => setSelectedVoucherTxnForView(null)}
        />
      )}
    </div>
  );
};
