import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AlertTriangle, Clock, LogOut, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

// 60 minutes = 3,600,000 ms
const INACTIVITY_LIMIT_MS = 60 * 60 * 1000;
// Warning starts 1 minute before = 59 minutes (60 seconds remaining)
const WARNING_BEFORE_MS = 60 * 1000;
const WARNING_THRESHOLD_MS = INACTIVITY_LIMIT_MS - WARNING_BEFORE_MS;

export const InactivitySessionManager: React.FC = () => {
  const { isAuthenticated, logout, currentUser } = useAuth();
  const [showWarning, setShowWarning] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(60);

  const lastActivityRef = useRef<number>(Date.now());
  const timerCheckRef = useRef<any>(null);

  // Record user activity
  const handleUserActivity = useCallback(() => {
    // Only reset if warning modal is not currently open
    if (!showWarning) {
      lastActivityRef.current = Date.now();
    }
  }, [showWarning]);

  // Keep session alive
  const handleStayLoggedIn = () => {
    lastActivityRef.current = Date.now();
    setShowWarning(false);
    setSecondsRemaining(60);
  };

  const handleLogoutNow = () => {
    setShowWarning(false);
    logout();
  };

  useEffect(() => {
    if (!isAuthenticated || !currentUser) {
      setShowWarning(false);
      return;
    }

    lastActivityRef.current = Date.now();

    // Listen for real user interactions
    const activityEvents = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
    activityEvents.forEach((eventName) => {
      window.addEventListener(eventName, handleUserActivity, { passive: true });
    });

    // Interval checker running every 1 second
    timerCheckRef.current = setInterval(() => {
      const now = Date.now();
      const idleTime = now - lastActivityRef.current;

      if (idleTime >= INACTIVITY_LIMIT_MS) {
        // Inactivity exceeded 60 minutes -> Auto Logout!
        clearInterval(timerCheckRef.current);
        setShowWarning(false);
        logout();
      } else if (idleTime >= WARNING_THRESHOLD_MS) {
        // Within the last 60 seconds (59 to 60 minutes)
        const msRemaining = Math.max(0, INACTIVITY_LIMIT_MS - idleTime);
        const secs = Math.ceil(msRemaining / 1000);
        setShowWarning(true);
        setSecondsRemaining(secs);
      } else {
        setShowWarning(false);
      }
    }, 1000);

    return () => {
      activityEvents.forEach((eventName) => {
        window.removeEventListener(eventName, handleUserActivity);
      });
      if (timerCheckRef.current) {
        clearInterval(timerCheckRef.current);
      }
    };
  }, [isAuthenticated, currentUser, handleUserActivity, logout]);

  if (!showWarning) return null;

  return (
    <div className="fixed inset-0 z-[120] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-amber-200 overflow-hidden animate-in zoom-in-95">
        {/* Warning Header */}
        <div className="p-6 bg-gradient-to-r from-amber-600 via-amber-700 to-slate-900 text-white text-center">
          <div className="w-12 h-12 rounded-2xl bg-white/20 border border-white/30 flex items-center justify-center mx-auto mb-3 shadow-inner">
            <Clock className="w-6 h-6 text-amber-200 animate-pulse" />
          </div>
          <h3 className="text-base sm:text-lg font-bold text-white">
            Session Inactivity Warning
          </h3>
        </div>

        {/* Modal Body */}
        <div className="p-6 text-center space-y-4">
          <p className="text-xs text-slate-600 leading-relaxed">
            You have been inactive for <strong>59 minutes</strong>. For enterprise data security, you will be automatically logged out in:
          </p>

          {/* Countdown Display */}
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-amber-50 border-4 border-amber-400 text-amber-600 font-mono font-bold text-2xl shadow-inner">
            {secondsRemaining}s
          </div>

          <p className="text-[11px] text-slate-500">
            Click <strong>Stay Logged In</strong> to continue working or <strong>Log Out</strong> to exit safely.
          </p>

          {/* Actions */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-2.5">
            <button
              type="button"
              onClick={handleStayLoggedIn}
              className="w-full sm:flex-1 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Stay Logged In</span>
            </button>
            <button
              type="button"
              onClick={handleLogoutNow}
              className="w-full sm:flex-1 py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out Now</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
