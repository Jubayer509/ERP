import React, { useState } from 'react';
import { 
  Server, 
  Database, 
  Layers, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  Terminal, 
  Lock, 
  Zap, 
  Copy, 
  Check,
  Cpu,
  RefreshCw
} from 'lucide-react';
import { ARCHITECTURE_GUIDANCE } from '../../data/architectureBlueprint';

export const ArchitectureGuide: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyCode = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const sampleEnvConfig = `# PRODUCTION ENTERPRISE CLUSTER CONFIGURATION
# Database Master (Read/Write)
DB_CONNECTION=pgsql
DB_HOST=erp-db-primary.internal.vpc
DB_PORT=5432
DB_DATABASE=tradecore_erp_prod
DB_USERNAME=tradecore_app
DB_PASSWORD=vault_managed_secret
DB_SCHEMA=public
DB_POOL_MIN=10
DB_POOL_MAX=100

# Database Read Replicas for High-Concurrency Reporting
DB_READ_REPLICA_1=erp-db-replica-01.internal.vpc:5432
DB_READ_REPLICA_2=erp-db-replica-02.internal.vpc:5432

# Redis High-Availability Sentinel & Queues
REDIS_HOST=erp-redis-sentinel.internal.vpc
REDIS_PORT=26379
REDIS_PASSWORD=vault_redis_secret
QUEUE_CONNECTION=rabbitmq
RABBITMQ_HOST=erp-mq-cluster.internal.vpc

# Multi-Currency & Forex Live Feed
FOREX_PROVIDER=central_bank_api_gateway
BASE_CURRENCY=BDT
SECONDARY_CURRENCIES=USD,EUR,CNY,GBP,AED`;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/40 rounded-xl p-6 text-white shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/30">
                Architectural Blueprint
              </span>
              <span className="text-xs text-slate-400 font-mono">20-Year Enterprise Design Pattern</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Enterprise Tech Stack & Scalability Guidance
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
              Tailored architectural design for high-concurrency import, trading, multi-currency customs clearance, 
              double-entry general ledger, and multi-location warehouse distribution.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <div className="bg-slate-800/80 border border-slate-700 rounded-lg p-3 text-center">
              <p className="text-[11px] text-slate-400 font-medium uppercase">ACID Compliance</p>
              <p className="text-sm font-bold text-emerald-400">Strict MVCC</p>
            </div>
            <div className="bg-slate-800/80 border border-slate-700 rounded-lg p-3 text-center">
              <p className="text-[11px] text-slate-400 font-medium uppercase">Architecture</p>
              <p className="text-sm font-bold text-blue-400">Modular Monolith / CQRS</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tech Stack Layers Breakdown */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-600" />
          Recommended Technology Stack by Layer
        </h2>
        <div className="grid grid-cols-1 gap-4">
          {ARCHITECTURE_GUIDANCE.map((item, idx) => (
            <div 
              key={idx} 
              className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm hover:border-blue-300 transition-colors"
            >
              <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                      Layer 0{idx + 1}
                    </span>
                    <h3 className="font-bold text-slate-900 text-base">{item.layer}</h3>
                  </div>

                  <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        Architect Recommended:
                      </span>
                      <span className="text-sm font-semibold text-slate-900 font-mono">{item.recommended}</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                      {item.reasoning}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    <div className="text-xs">
                      <span className="font-bold text-slate-600 block mb-1">Production Scalability Design:</span>
                      <p className="text-slate-600 leading-relaxed bg-blue-50/50 p-2.5 rounded border border-blue-100">
                        {item.scalabilityNotes}
                      </p>
                    </div>
                    <div className="text-xs">
                      <span className="font-bold text-slate-600 block mb-1">Evaluated Alternatives:</span>
                      <div className="flex flex-wrap gap-1.5 p-2 rounded bg-slate-50 border border-slate-100">
                        {item.alternatives.map((alt, i) => (
                          <span key={i} className="px-2 py-0.5 bg-white border border-slate-200 rounded text-slate-700 font-mono text-[11px]">
                            {alt}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Deep Dive Comparison: Laravel vs Node.js vs Python for ERP Systems */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
        <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Server className="w-4 h-4 text-indigo-600" />
          Backend Technology Evaluation Matrix for ERP Systems
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
            <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Criteria</th>
                <th className="py-2.5 px-3 text-blue-900 bg-blue-50/70">Node.js (NestJS + TypeScript)</th>
                <th className="py-2.5 px-3 text-indigo-900 bg-indigo-50/70">Laravel 11 (PHP 8.3+)</th>
                <th className="py-2.5 px-3 text-emerald-900 bg-emerald-50/70">Python (FastAPI / Django)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-700">
              <tr>
                <td className="py-2.5 px-3 font-semibold bg-slate-50">Type Safety & Contracts</td>
                <td className="py-2.5 px-3 bg-blue-50/30">End-to-end TypeScript sharing with React UI</td>
                <td className="py-2.5 px-3 bg-indigo-50/30">Strict PHP 8.3 typing + Eloquent models</td>
                <td className="py-2.5 px-3 bg-emerald-50/30">Pydantic typing with FastAPI</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold bg-slate-50">Financial ACID Transactions</td>
                <td className="py-2.5 px-3 bg-blue-50/30">Prisma / TypeORM transaction blocks</td>
                <td className="py-2.5 px-3 bg-indigo-50/30 font-semibold text-emerald-700">Native DB::transaction() + auto rollback</td>
                <td className="py-2.5 px-3 bg-emerald-50/30">SQLAlchemy transaction sessions</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold bg-slate-50">Async Job Queues (Landed Cost/Aging)</td>
                <td className="py-2.5 px-3 bg-blue-50/30">BullMQ (Redis-backed) workers</td>
                <td className="py-2.5 px-3 bg-indigo-50/30 font-semibold text-emerald-700">Laravel Horizon + Redis native queues</td>
                <td className="py-2.5 px-3 bg-emerald-50/30">Celery + Redis/RabbitMQ</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold bg-slate-50">Development Velocity</td>
                <td className="py-2.5 px-3 bg-blue-50/30">High (modular microservices ready)</td>
                <td className="py-2.5 px-3 bg-indigo-50/30 font-semibold text-emerald-700">Fastest for enterprise trading & auth</td>
                <td className="py-2.5 px-3 bg-emerald-50/30">Medium (excellent for ML/Forecasting)</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold bg-slate-50">Verdict for Trading ERP</td>
                <td className="py-2.5 px-3 bg-blue-50/50 font-bold text-blue-900">Recommended for High-IOPS API</td>
                <td className="py-2.5 px-3 bg-indigo-50/50 font-bold text-indigo-900">Recommended for Rapid Full-Stack ERP</td>
                <td className="py-2.5 px-3 bg-emerald-50/50 font-bold text-emerald-900">Best for ML Demand Forecasting Module</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* High-Availability Deployment Architecture Snippet */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span className="font-mono text-xs font-bold text-slate-200">
              Production Environment Architecture Configuration (.env.production)
            </span>
          </div>
          <button
            onClick={() => copyCode(sampleEnvConfig, 1)}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-white px-2 py-1 bg-slate-800 rounded border border-slate-700"
          >
            {copiedIndex === 1 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedIndex === 1 ? 'Copied' : 'Copy Config'}
          </button>
        </div>
        <pre className="mt-3 text-[11px] font-mono text-slate-300 overflow-x-auto leading-relaxed p-3 bg-slate-950 rounded-lg border border-slate-800/80">
          {sampleEnvConfig}
        </pre>
      </div>

      {/* Security, SOX Auditing & Compliance Card */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-5">
        <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 mb-2">
          <Lock className="w-4 h-4 text-emerald-600" />
          Enterprise Financial Data Safety & Audit Rules (IFRS / GAAP Compliance)
        </h3>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-slate-600">
          <li className="flex items-start gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
            <span><strong>Zero In-Place Updates on Posted Vouchers:</strong> Once approved, vouchers become immutable. Modifications require formal Contra/Reversal vouchers.</span>
          </li>
          <li className="flex items-start gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
            <span><strong>Database Trigger Audit Logging:</strong> PostgreSQL triggers automatically capture OLD and NEW row snapshots into write-only `audit_logs` table.</span>
          </li>
          <li className="flex items-start gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
            <span><strong>Row-Level Security (RLS):</strong> Branch isolation enforced at the database layer to prevent cross-subsidiary leakage.</span>
          </li>
          <li className="flex items-start gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
            <span><strong>Floating Point Immunity:</strong> All monetary calculations strictly utilize `NUMERIC(18, 4)` and `DECIMAL` primitives to prevent rounding drift.</span>
          </li>
        </ul>
      </div>
    </div>
  );
};
