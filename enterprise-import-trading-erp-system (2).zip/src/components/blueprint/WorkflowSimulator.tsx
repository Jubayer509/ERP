import React, { useState } from 'react';
import { 
  GitMerge, 
  ArrowRight, 
  CheckCircle2, 
  FileText, 
  Database, 
  Calculator, 
  Receipt, 
  Play, 
  RotateCcw,
  Sparkles,
  DollarSign,
  Boxes,
  Ship,
  Scale
} from 'lucide-react';
import { WORKFLOW_STEPS, WorkflowStep } from '../../data/architectureBlueprint';

export const WorkflowSimulator: React.FC = () => {
  const [activeStepIndex, setActiveStepIndex] = useState(0);

  // Live Interactive Landed Cost & Accounting Simulation Parameters
  const [fobUsd, setFobUsd] = useState(100000);
  const [exchangeRate, setExchangeRate] = useState(118.50);
  const [quantityMt, setQuantityMt] = useState(200);
  const [customsDutyPercent, setCustomsDutyPercent] = useState(25.0);
  const [regulatoryDutyPercent, setRegulatoryDutyPercent] = useState(3.0);
  const [portDemurrageBdt, setPortDemurrageBdt] = useState(180000);
  const [cfCommissionBdt, setCfCommissionBdt] = useState(75000);
  const [localFreightBdt, setLocalFreightBdt] = useState(145000);
  const [insuranceBdt, setInsuranceBdt] = useState(65000);

  // Computed values
  const baseFobBdt = fobUsd * exchangeRate;
  const customsDutyBdt = baseFobBdt * (customsDutyPercent / 100);
  const regulatoryDutyBdt = baseFobBdt * (regulatoryDutyPercent / 100);
  const totalDutiesBdt = customsDutyBdt + regulatoryDutyBdt;
  const totalPortLogisticsBdt = portDemurrageBdt + cfCommissionBdt + localFreightBdt + insuranceBdt;
  const totalCapitalizedLandedCost = baseFobBdt + totalDutiesBdt + totalPortLogisticsBdt;
  const landedUnitCostPerMt = totalCapitalizedLandedCost / (quantityMt || 1);
  const baseUnitCostPerMt = baseFobBdt / (quantityMt || 1);

  const activeStep: WorkflowStep = WORKFLOW_STEPS[activeStepIndex];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-900/40 rounded-xl p-6 text-white shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded border border-blue-500/30">
                End-to-End Workflow Engine
              </span>
              <span className="text-xs text-slate-400 font-mono">Automated Data Pipeline & Accounting Integration</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              LC Opening ➔ Customs Duty ➔ GRN ➔ Landed Cost ➔ Inventory ➔ Accounts
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
              Step-by-step interactive architectural pipeline demonstrating how physical cargo movements, customs tariff 
              assessments, warehouse intake, and double-entry financial ledgers synchronize in real-time.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setActiveStepIndex((prev) => (prev + 1) % WORKFLOW_STEPS.length)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-md transition-colors"
            >
              <Play className="w-3.5 h-3.5" />
              Next Stage ({activeStepIndex + 1}/7)
            </button>
            <button
              onClick={() => setActiveStepIndex(0)}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs transition-colors"
              title="Reset to Stage 1"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Stage Timeline Stepper */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm overflow-x-auto">
        <div className="flex items-center justify-between min-w-[760px] gap-2">
          {WORKFLOW_STEPS.map((step, idx) => {
            const isCompleted = idx < activeStepIndex;
            const isCurrent = idx === activeStepIndex;
            return (
              <React.Fragment key={step.stepNumber}>
                <button
                  onClick={() => setActiveStepIndex(idx)}
                  className={`flex flex-col items-center text-center p-2 rounded-lg transition-all flex-1 ${
                    isCurrent
                      ? 'bg-blue-50 border-2 border-blue-600 shadow-xs'
                      : isCompleted
                      ? 'bg-slate-50 border border-slate-200 hover:bg-slate-100'
                      : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center font-mono text-xs font-bold mb-1.5 transition-colors ${
                      isCurrent
                        ? 'bg-blue-600 text-white shadow-md'
                        : isCompleted
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : step.stepNumber}
                  </div>
                  <span className="text-[11px] font-bold text-slate-900 leading-tight">
                    {step.stageName.split('. ')[1]}
                  </span>
                </button>
                {idx < WORKFLOW_STEPS.length - 1 && (
                  <ArrowRight className="w-4 h-4 text-slate-300 shrink-0" />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Active Stage Deep-Dive Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Columns: Operational & Database Flow */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center font-mono">
                  {activeStep.stepNumber}
                </span>
                <h2 className="text-base font-bold text-slate-900">{activeStep.stageName}</h2>
              </div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold font-mono">
                Stage {activeStep.stepNumber} of 7
              </span>
            </div>

            {/* Trigger Event & Operational Action */}
            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Triggering Business Event:
                </label>
                <p className="text-xs font-semibold text-slate-800 bg-amber-50/60 p-2.5 rounded-lg border border-amber-200/60 leading-relaxed">
                  {activeStep.triggerEvent}
                </p>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  ERP Operational Execution:
                </label>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {activeStep.operationalAction}
                </p>
              </div>
            </div>

            {/* Required Documents & Database Tables */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 mb-2">
                  <FileText className="w-3.5 h-3.5 text-indigo-600" />
                  Required Commercial Documents
                </div>
                <ul className="space-y-1">
                  {activeStep.requiredDocuments.map((doc, i) => (
                    <li key={i} className="text-[11px] text-slate-600 flex items-center gap-1.5 font-medium">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                      {doc}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 mb-2">
                  <Database className="w-3.5 h-3.5 text-emerald-600" />
                  Database Entities Updated
                </div>
                <ul className="space-y-1 font-mono">
                  {activeStep.dbEntitiesUpdated.map((ent, i) => (
                    <li key={i} className="text-[11px] text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200/50">
                      {ent}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Right 5 Columns: Double-Entry Accounting Impact Card */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-sm text-slate-100">Accounting Ledger Impact (GL)</h3>
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono font-bold px-2 py-0.5 rounded">
                Double-Entry
              </span>
            </div>

            {/* Debit and Credit Entries */}
            <div className="space-y-2">
              <div className="p-2.5 rounded-lg bg-emerald-950/50 border border-emerald-800/60">
                <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Debit Account:</span>
                <p className="text-xs font-mono font-semibold text-emerald-200 mt-0.5">
                  {activeStep.accountingImpact.debitAccount}
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-rose-950/50 border border-rose-800/60">
                <span className="text-[10px] uppercase font-bold text-rose-400 tracking-wider">Credit Account:</span>
                <p className="text-xs font-mono font-semibold text-rose-200 mt-0.5">
                  {activeStep.accountingImpact.creditAccount}
                </p>
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-1 pt-1">
              <p className="text-[11px] text-slate-400">
                <strong>Posting Nature:</strong> {activeStep.accountingImpact.nature}
              </p>
              <p className="text-[11px] text-slate-400 leading-relaxed bg-slate-950 p-2.5 rounded border border-slate-800 font-mono">
                {activeStep.accountingImpact.formulaOrExplanation}
              </p>
            </div>

            {activeStep.sampleCalculation && (
              <div className="pt-2 border-t border-slate-800">
                <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                  Numerical Production Example:
                </span>
                <p className="text-[11px] text-amber-200/90 font-mono mt-1 bg-amber-950/30 p-2 rounded border border-amber-800/40 leading-relaxed">
                  {activeStep.sampleCalculation}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Landed Cost & Journal Voucher Simulation Engine */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <Calculator className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-base text-slate-900">
                Interactive Landed Cost Engine & GL Voucher Generator
              </h3>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              Simulate live cost accumulation and watch how the ERP calculates unit landed cost and balances the Journal Voucher.
            </p>
          </div>
          <span className="text-xs font-mono bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded font-bold border border-indigo-200">
            Real-time Allocation Engine
          </span>
        </div>

        {/* Input Parameters Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
          <div>
            <label className="font-semibold text-slate-600 block mb-1">FOB Value (USD $)</label>
            <input
              type="number"
              value={fobUsd}
              onChange={(e) => setFobUsd(Number(e.target.value))}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-semibold focus:ring-1 focus:ring-blue-500 outline-none"
            />
          </div>
          <div>
            <label className="font-semibold text-slate-600 block mb-1">Exchange Rate (BDT/$)</label>
            <input
              type="number"
              step="0.1"
              value={exchangeRate}
              onChange={(e) => setExchangeRate(Number(e.target.value))}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-semibold focus:ring-1 focus:ring-blue-500 outline-none"
            />
          </div>
          <div>
            <label className="font-semibold text-slate-600 block mb-1">Import Qty (MT)</label>
            <input
              type="number"
              value={quantityMt}
              onChange={(e) => setQuantityMt(Number(e.target.value))}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-semibold focus:ring-1 focus:ring-blue-500 outline-none"
            />
          </div>
          <div>
            <label className="font-semibold text-slate-600 block mb-1">Customs Duty CD (%)</label>
            <input
              type="number"
              step="0.5"
              value={customsDutyPercent}
              onChange={(e) => setCustomsDutyPercent(Number(e.target.value))}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-semibold focus:ring-1 focus:ring-blue-500 outline-none"
            />
          </div>
          <div>
            <label className="font-semibold text-slate-600 block mb-1">Port Demurrage (BDT)</label>
            <input
              type="number"
              value={portDemurrageBdt}
              onChange={(e) => setPortDemurrageBdt(Number(e.target.value))}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-semibold focus:ring-1 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        {/* Live Calculation Summary Banner */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
          <div>
            <span className="text-slate-500 block">Base FOB Cost (BDT):</span>
            <span className="text-sm font-mono font-bold text-slate-900">
              BDT {baseFobBdt.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              @ BDT {baseUnitCostPerMt.toFixed(0)}/MT
            </span>
          </div>
          <div>
            <span className="text-slate-500 block">Customs Duties (CD+RD):</span>
            <span className="text-sm font-mono font-bold text-amber-600">
              BDT {totalDutiesBdt.toLocaleString()}
            </span>
            <span className="text-[10px] text-amber-500 block mt-0.5">
              {(customsDutyPercent + regulatoryDutyPercent)}% Total Tariff
            </span>
          </div>
          <div>
            <span className="text-slate-500 block">Port, C&F & Local Freight:</span>
            <span className="text-sm font-mono font-bold text-indigo-600">
              BDT {totalPortLogisticsBdt.toLocaleString()}
            </span>
            <span className="text-[10px] text-indigo-500 block mt-0.5">
              Demurrage + Transport + C&F
            </span>
          </div>
          <div className="bg-blue-600 text-white p-2.5 rounded-lg">
            <span className="text-blue-100 block text-[11px] font-semibold">True Landed Unit Cost:</span>
            <span className="text-base font-mono font-bold block">
              BDT {landedUnitCostPerMt.toFixed(0)} / MT
            </span>
            <span className="text-[10px] text-blue-200 block">
              Total Inflow: BDT {totalCapitalizedLandedCost.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Live Double-Entry Voucher Generation Preview */}
        <div className="bg-slate-950 rounded-xl p-4 text-slate-200 border border-slate-800">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="font-mono font-bold text-white">
                Auto-Generated General Ledger Journal Voucher (JV-SIM-001)
              </span>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 font-bold">
              Status: Balanced (Debit = Credit)
            </span>
          </div>

          <table className="w-full text-left text-xs font-mono">
            <thead className="text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-1.5 px-2">Account Code & Title</th>
                <th className="py-1.5 px-2">Type</th>
                <th className="py-1.5 px-2 text-right">Debit (BDT)</th>
                <th className="py-1.5 px-2 text-right">Credit (BDT)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-1.5 px-2 text-white">1200 - Merchandise Inventory (Asset)</td>
                <td className="py-1.5 px-2 text-emerald-400">Inventory Addition</td>
                <td className="py-1.5 px-2 text-right text-emerald-400 font-bold">
                  {totalCapitalizedLandedCost.toLocaleString()}
                </td>
                <td className="py-1.5 px-2 text-right text-slate-500">-</td>
              </tr>
              <tr>
                <td className="py-1.5 px-2 text-slate-400">1160 - Goods In-Transit / LC Clearing WIP (Asset)</td>
                <td className="py-1.5 px-2 text-slate-400">Clear WIP</td>
                <td className="py-1.5 px-2 text-right text-slate-500">-</td>
                <td className="py-1.5 px-2 text-right text-rose-400 font-bold">
                  {totalCapitalizedLandedCost.toLocaleString()}
                </td>
              </tr>
            </tbody>
            <tfoot className="border-t-2 border-slate-700 font-bold text-slate-100">
              <tr>
                <td colSpan={2} className="py-2 px-2 text-right">TOTALS:</td>
                <td className="py-2 px-2 text-right text-emerald-400">
                  BDT {totalCapitalizedLandedCost.toLocaleString()}
                </td>
                <td className="py-2 px-2 text-right text-rose-400">
                  BDT {totalCapitalizedLandedCost.toLocaleString()}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
