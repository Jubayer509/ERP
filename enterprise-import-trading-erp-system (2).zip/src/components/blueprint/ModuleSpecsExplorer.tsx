import React, { useState } from 'react';
import { 
  BookOpen, 
  CheckCircle2, 
  FileText, 
  ShieldCheck, 
  Layers, 
  BarChart3, 
  ChevronRight,
  Search
} from 'lucide-react';
import { MODULE_SPECIFICATIONS, ModuleSpecification } from '../../data/architectureBlueprint';

export const ModuleSpecsExplorer: React.FC = () => {
  const [selectedModuleId, setSelectedModuleId] = useState<string>('sales');
  const [search, setSearch] = useState('');

  const currentModule: ModuleSpecification = 
    MODULE_SPECIFICATIONS.find(m => m.id === selectedModuleId) || MODULE_SPECIFICATIONS[0];

  const filteredModules = MODULE_SPECIFICATIONS.filter(m => 
    m.moduleName.toLowerCase().includes(search.toLowerCase()) ||
    m.tagline.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-white shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/30">
                Complete Functional Blueprint
              </span>
              <span className="text-xs text-slate-400 font-mono">All 8 Core Modules Specification</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Enterprise Module Breakdown & Engineering Specifications
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
              Comprehensive functional blueprints for all operational departments: sub-features, user actions, 
              form field schemas, validation rules, financial reporting capabilities, and RBAC authorization boundaries.
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-400 block font-mono">Standardized Specs</span>
            <span className="text-base font-bold text-emerald-400">8 Modules Documented</span>
          </div>
        </div>
      </div>

      {/* Main Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Sidebar: Module Selector */}
        <div className="lg:col-span-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search module or feature..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="space-y-1.5 max-h-[600px] overflow-y-auto pr-1">
            {filteredModules.map((mod) => {
              const isSelected = mod.id === selectedModuleId;
              return (
                <button
                  key={mod.id}
                  onClick={() => setSelectedModuleId(mod.id)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    isSelected
                      ? 'bg-blue-50 border-blue-500 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900">
                      {mod.moduleName}
                    </span>
                    <ChevronRight className={`w-3.5 h-3.5 ${isSelected ? 'text-blue-600' : 'text-slate-400'}`} />
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">{mod.tagline}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Content: Comprehensive Module Deep Dive */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
            {/* Header info */}
            <div className="border-b border-slate-200 pb-3">
              <span className="text-xs font-mono font-bold text-blue-600 uppercase tracking-wider">
                Module Architectural Specification
              </span>
              <h2 className="text-lg font-bold text-slate-900 mt-0.5">{currentModule.moduleName}</h2>
              <p className="text-xs text-slate-600 mt-1">{currentModule.tagline}</p>
            </div>

            {/* Core Operations Pills */}
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                Core Operations Supported:
              </label>
              <div className="flex flex-wrap gap-2">
                {currentModule.coreOperations.map((op, i) => (
                  <span key={i} className="px-2.5 py-1 bg-slate-100 text-slate-800 text-xs font-semibold rounded-md border border-slate-200">
                    ✓ {op}
                  </span>
                ))}
              </div>
            </div>

            {/* Sub-features & Form Schemas */}
            <div className="space-y-4 pt-2">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-indigo-600" />
                Sub-Features, User Actions & Form Field Schemas
              </h3>

              <div className="space-y-3">
                {currentModule.subFeatures.map((sub, idx) => (
                  <div key={idx} className="p-4 bg-slate-50/70 border border-slate-200 rounded-lg space-y-2.5">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-slate-900">{sub.name}</h4>
                      <span className="text-[10px] bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded font-mono font-semibold">
                        Feature 0{idx + 1}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{sub.description}</p>

                    {/* Operational Actions */}
                    <div className="text-xs">
                      <span className="font-bold text-slate-700 block mb-1">Available User Actions:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {sub.actions.map((act, i) => (
                          <span key={i} className="bg-white border border-slate-200 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium">
                            {act}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Form Fields & Schema */}
                    <div className="text-xs">
                      <span className="font-bold text-slate-700 block mb-1">Form Entities & Field Schemas:</span>
                      <div className="p-2.5 bg-white border border-slate-200 rounded font-mono text-[11px] text-slate-700 leading-relaxed">
                        {sub.formsAndFields.join(' ')}
                      </div>
                    </div>

                    {/* Validation & Business Rules */}
                    <div className="text-xs">
                      <span className="font-bold text-slate-700 block mb-1">Core Business Logic & Validations:</span>
                      <ul className="space-y-1">
                        {sub.validationsAndRules.map((rule, i) => (
                          <li key={i} className="text-[11px] text-slate-600 flex items-start gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            <span>{rule}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Reporting Capabilities */}
            <div className="pt-2 border-t border-slate-200">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                <BarChart3 className="w-4 h-4 text-emerald-600" />
                Departmental Reporting Capabilities
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                {currentModule.reportingCapabilities.map((rep, i) => (
                  <div key={i} className="p-2.5 bg-emerald-50/50 border border-emerald-100 rounded text-slate-700 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                    <span>{rep}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Security and RBAC Matrix */}
            <div className="pt-2 border-t border-slate-200">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                <ShieldCheck className="w-4 h-4 text-indigo-600" />
                Role-Based Access Control (RBAC) Entitlements
              </h3>
              <div className="flex flex-wrap gap-2 text-xs">
                {currentModule.securityAndPermissions.map((sec, i) => (
                  <span key={i} className="px-2.5 py-1 bg-slate-900 text-slate-200 rounded font-mono text-[11px]">
                    {sec}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
