import React, { useState } from 'react';
import { 
  Database, 
  Key, 
  Link2, 
  Table, 
  Code2, 
  Search, 
  Copy, 
  Check, 
  ExternalLink,
  Layers,
  ArrowRight
} from 'lucide-react';
import { PRIMARY_SCHEMA_TABLES, SchemaTable } from '../../data/architectureBlueprint';

export const DatabaseSchemaViewer: React.FC = () => {
  const [selectedTable, setSelectedTable] = useState<SchemaTable>(PRIMARY_SCHEMA_TABLES[0]);
  const [searchFilter, setSearchFilter] = useState('');
  const [copied, setCopied] = useState(false);

  const filteredTables = PRIMARY_SCHEMA_TABLES.filter(t => 
    t.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
    t.module.toLowerCase().includes(searchFilter.toLowerCase()) ||
    t.description.toLowerCase().includes(searchFilter.toLowerCase())
  );

  const generatePostgresDDL = (table: SchemaTable) => {
    const cols = table.columns.map(c => {
      let line = `  ${c.name.padEnd(26)} ${c.type}`;
      if (!c.isNullable) line += ' NOT NULL';
      if (c.name === 'id') line += ' DEFAULT gen_random_uuid()';
      if (c.fkRef) line += ` REFERENCES ${c.fkRef} ON DELETE RESTRICT`;
      return line;
    }).join(',\n');

    return `-- Table Definition: ${table.name} (${table.module})\n-- ${table.description}\nCREATE TABLE ${table.name} (\n${cols},\n  CONSTRAINT pk_${table.name} PRIMARY KEY (${table.primaryKey.split(' ')[0]})\n);\n\n-- Indexes & Optimization:\n${table.indexes.join(';\n')};`;
  };

  const copyDDL = () => {
    navigator.clipboard.writeText(generatePostgresDDL(selectedTable));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Cross-entity relationship map
  const relationships = [
    { from: 'lc_masters', fromCol: 'id', to: 'purchase_orders', toCol: 'lc_id', relation: '1 : N', desc: 'An LC can fulfill multiple purchase orders or containers' },
    { from: 'lc_masters', fromCol: 'id', to: 'lc_bill_of_entries', toCol: 'lc_id', relation: '1 : N', desc: 'LC has customs Bill of Entries per shipment/arrival' },
    { from: 'lc_masters', fromCol: 'id', to: 'grn_masters', toCol: 'lc_id', relation: '1 : N', desc: 'Direct link between physical warehouse GRN and import LC' },
    { from: 'grn_masters', fromCol: 'id', to: 'stock_ledger_entries', toCol: 'reference_voucher_no', relation: '1 : N', desc: 'GRN generates immutable chronological stock ledger intake records' },
    { from: 'inventory_items', fromCol: 'id', to: 'stock_ledger_entries', toCol: 'item_id', relation: '1 : N', desc: 'Product catalog movement tracking' },
    { from: 'journal_vouchers', fromCol: 'id', to: 'journal_voucher_items', toCol: 'voucher_id', relation: '1 : N', desc: 'Double-entry header to line-item split' },
    { from: 'chart_of_accounts', fromCol: 'code', to: 'journal_voucher_items', toCol: 'account_code', relation: '1 : N', desc: 'General ledger account head validation' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-white shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30">
                Relational Data Model
              </span>
              <span className="text-xs text-slate-400 font-mono">PostgreSQL DDL & Foreign Key Architecture</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Primary Entity Tables & Foreign Key Relationships
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
              Fully normalized 3NF database schema mapping relationships across Letter of Credit (LC), 
              Direct Purchase Invoices, Goods Received Note (GRN), Inventory Stock Ledger, and General Ledger (GL).
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="px-3 py-1 bg-slate-800 text-xs text-emerald-400 font-mono rounded border border-slate-700">
              Foreign Key Gating: RESTRICT
            </span>
          </div>
        </div>
      </div>

      {/* Relational Visualizer: Core Entity Relationships */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-3">
          <Link2 className="w-4 h-4 text-emerald-600" />
          Core Cross-Module Foreign Key Matrix (LC ⇄ Purchase ⇄ Inventory ⇄ Accounts)
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {relationships.map((rel, i) => (
            <div key={i} className="p-3 rounded-lg border border-slate-200 bg-slate-50/70 text-xs hover:border-emerald-300 transition-colors">
              <div className="flex items-center justify-between font-mono font-semibold text-slate-800 mb-1">
                <span className="text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">{rel.from}</span>
                <span className="text-[11px] font-bold text-slate-500">{rel.relation}</span>
                <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">{rel.to}</span>
              </div>
              <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1 mt-1">
                <span>{rel.from}.{rel.fromCol}</span>
                <ArrowRight className="w-3 h-3 text-slate-400" />
                <span>{rel.to}.{rel.toCol}</span>
              </div>
              <p className="text-slate-600 text-[11px] mt-2 leading-relaxed">
                {rel.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Entity Explorer & DDL Generator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Table List */}
        <div className="lg:col-span-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search table or module..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>

          <div className="space-y-1.5 max-h-[540px] overflow-y-auto pr-1">
            {filteredTables.map((t) => {
              const isSelected = selectedTable.name === t.name;
              return (
                <button
                  key={t.name}
                  onClick={() => setSelectedTable(t)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-500 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-slate-900">
                      {t.name}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-medium">
                      {t.module}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">{t.description}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Table Schema Details & DDL */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <Table className="w-5 h-5 text-blue-600" />
                  <h3 className="font-mono font-bold text-base text-slate-900">{selectedTable.name}</h3>
                  <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-800 rounded font-medium">
                    {selectedTable.module}
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-1">{selectedTable.description}</p>
              </div>
              <button
                onClick={copyDDL}
                className="flex items-center gap-1.5 text-xs bg-slate-900 text-white hover:bg-slate-800 px-3 py-1.5 rounded-lg transition-colors font-medium self-start sm:self-auto"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied DDL' : 'Copy SQL DDL'}
              </button>
            </div>

            {/* Column Schema Table */}
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
                <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Column Name</th>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3">Null</th>
                    <th className="py-2.5 px-3">Foreign Key / Reference</th>
                    <th className="py-2.5 px-3">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700">
                  {selectedTable.columns.map((col, idx) => (
                    <tr key={idx} className={col.name === 'id' ? 'bg-amber-50/40' : 'hover:bg-slate-50/50'}>
                      <td className="py-2 px-3 font-mono font-bold text-slate-900 flex items-center gap-1.5">
                        {col.name === 'id' && <Key className="w-3 h-3 text-amber-600" />}
                        {col.name}
                      </td>
                      <td className="py-2 px-3 font-mono text-blue-700">{col.type}</td>
                      <td className="py-2 px-3 text-slate-500">{col.isNullable ? 'YES' : 'NO'}</td>
                      <td className="py-2 px-3 font-mono text-[11px] text-emerald-700">
                        {col.fkRef ? (
                          <span className="flex items-center gap-1">
                            <Link2 className="w-3 h-3 text-emerald-600 shrink-0" />
                            {col.fkRef}
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-slate-600">{col.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Indexes */}
            <div className="mt-4 pt-3 border-t border-slate-200">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                Production Database Indexes
              </h4>
              <div className="space-y-1">
                {selectedTable.indexes.map((idxStr, i) => (
                  <div key={i} className="text-[11px] font-mono bg-slate-900 text-emerald-400 p-2 rounded">
                    {idxStr}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
