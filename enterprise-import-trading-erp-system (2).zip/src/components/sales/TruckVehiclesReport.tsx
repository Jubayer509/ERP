import React, { useState, useMemo } from 'react';
import { 
  Truck, 
  Search, 
  Filter, 
  Calendar, 
  Printer, 
  Download, 
  Plus, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  TrendingUp,
  Scale,
  Ruler,
  Calculator,
  User,
  MapPin,
  X,
  ChevronRight,
  Info,
  Layers,
  ArrowUpDown,
  ArrowDown
} from 'lucide-react';
import { TruckMeasurementRecord, SalesInvoice, Customer } from '../../types/erp';
import { MOCK_TRUCK_RECORDS } from '../../data/mockErpData';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';
import { ModalWrapper } from '../common/ModalWrapper';
import { 
  calculateStoneCft, 
  STONE_INCH_OPTIONS, 
  STONE_DOWN_OPTIONS,
  getStoneInchDecimal,
  calculateEffectiveStoneFeet
} from '../../utils/stoneMeasurement';

interface TruckVehiclesReportProps {
  records?: TruckMeasurementRecord[];
  invoices?: SalesInvoice[];
  customers?: Customer[];
  onOpenNewInvoiceModal?: () => void;
  onViewInvoice?: (invoice: SalesInvoice) => void;
}

export const TruckVehiclesReport: React.FC<TruckVehiclesReportProps> = ({
  records = MOCK_TRUCK_RECORDS,
  invoices = [],
  customers = [],
  onOpenNewInvoiceModal,
  onViewInvoice
}) => {
  // Search & Filter state
  const [searchTruckNo, setSearchTruckNo] = useState<string>('');
  const [selectedDriver, setSelectedDriver] = useState<string>('All');
  const [selectedCustomer, setSelectedCustomer] = useState<string>('All');
  const [dateRange, setDateRange] = useState<'All' | 'Today' | '7days' | '30days'>('All');
  const [productFilter, setProductFilter] = useState<string>('All');

  // Interactive Tools & Modals
  const [showCalculator, setShowCalculator] = useState<boolean>(false);
  // Default values set to user's stone formula example: 18 ft 2 in × 6 ft 9 in × 3 ft 9 in
  const [calcDownInches, setCalcDownInches] = useState<number>(0);
  const [calcLengthFt, setCalcLengthFt] = useState<number | ''>('');
  const [calcLengthIn, setCalcLengthIn] = useState<number | ''>('');
  const [calcWidthFt, setCalcWidthFt] = useState<number | ''>('');
  const [calcWidthIn, setCalcWidthIn] = useState<number | ''>('');
  const [calcHeightFt, setCalcHeightFt] = useState<number | ''>('');
  const [calcHeightIn, setCalcHeightIn] = useState<number | ''>('');
  const [calcRate, setCalcRate] = useState<number | ''>('');

  // Print Slip Modal State
  const [selectedSlipRecord, setSelectedSlipRecord] = useState<TruckMeasurementRecord | null>(null);
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  React.useEffect(() => {
    return subscribeCompanyProfile(setCompanyProfile);
  }, []);

  // Combine props records with any records created from invoices that have transport details
  const allRecords = useMemo(() => {
    const list = [...records];

    // Check if any invoice has truck details and is not yet in records
    invoices.forEach(inv => {
      if (inv.truckNo && !list.some(r => r.invoiceNo === inv.invoiceNumber)) {
        const cft = inv.billedCft || inv.measurementCft || (
          (inv.measurementLength || 18) * (inv.measurementWidth || 6) * (inv.measurementHeight || 3)
        ) || 460;
        
        list.unshift({
          id: `tr-inv-${inv.id}`,
          truckNo: inv.truckNo,
          driverName: inv.driverName || 'Truck Driver',
          driverPhone: inv.driverPhone || 'N/A',
          date: inv.invoiceDate,
          time: '12:00 PM',
          challanNo: `CH-${inv.invoiceNumber.replace('INV-', '')}`,
          invoiceNo: inv.invoiceNumber,
          customerName: inv.customerName,
          destination: 'Customer Project Yard',
          itemName: inv.items[0]?.itemName || '20MM Crushed Stone',
          measurementLength: inv.measurementLength || 18,
          measurementLengthInches: inv.measurementLengthInches || 0,
          measurementWidth: inv.measurementWidth || 6,
          measurementWidthInches: inv.measurementWidthInches || 0,
          measurementHeight: inv.measurementHeight || 3,
          measurementHeightInches: inv.measurementHeightInches || 0,
          measurementLengthEffective: inv.measurementLengthEffective,
          measurementWidthEffective: inv.measurementWidthEffective,
          measurementHeightEffective: inv.measurementHeightEffective,
          exactCft: inv.exactCft,
          volumeCft: Math.round(cft * 100) / 100,
          formulaDisplay: inv.formulaDisplay,
          downInches: inv.downInches,
          downLabel: inv.downLabel,
          originalHeightFeet: inv.originalHeightFeet,
          originalHeightInches: inv.originalHeightInches,
          originalVolumeCft: inv.originalBilledCft,
          effectiveHeightFeet: inv.effectiveHeightFeet,
          effectiveHeightInches: inv.effectiveHeightInches,
          netWeightMt: inv.netWeightMt || Math.round(cft * 0.043 * 10) / 10,
          ratePerCftOrMt: inv.items[0]?.unitPrice || 165,
          uom: 'CFT',
          totalAmount: inv.totalAmount,
          status: 'Delivered',
          branch: inv.branch || 'Burimari Office',
          notes: inv.downInches ? `Down Measurement: ${inv.downLabel} (Original measurement preserved)` : 'Measurement saved directly from sales invoice'
        });
      }
    });

    return list;
  }, [records, invoices]);

  // Unique list of trucks for quick chips and dropdowns
  const uniqueTrucks = useMemo(() => {
    const map = new Map<string, { count: number; totalCft: number; driverName: string }>();
    allRecords.forEach(r => {
      const existing = map.get(r.truckNo) || { count: 0, totalCft: 0, driverName: r.driverName };
      existing.count += 1;
      existing.totalCft += r.volumeCft;
      map.set(r.truckNo, existing);
    });
    return Array.from(map.entries()).map(([truckNo, data]) => ({
      truckNo,
      ...data
    }));
  }, [allRecords]);

  // Filtered records
  const filteredRecords = useMemo(() => {
    return allRecords.filter(r => {
      // Truck search
      if (searchTruckNo.trim()) {
        const q = searchTruckNo.toLowerCase().trim();
        const matchesTruck = r.truckNo.toLowerCase().includes(q);
        const matchesDriver = r.driverName.toLowerCase().includes(q);
        const matchesChallan = r.challanNo.toLowerCase().includes(q);
        const matchesInv = (r.invoiceNo || '').toLowerCase().includes(q);
        if (!matchesTruck && !matchesDriver && !matchesChallan && !matchesInv) {
          return false;
        }
      }

      // Customer filter
      if (selectedCustomer !== 'All' && r.customerName !== selectedCustomer) {
        return false;
      }

      // Product filter
      if (productFilter !== 'All') {
        if (!r.itemName.toLowerCase().includes(productFilter.toLowerCase())) {
          return false;
        }
      }

      // Date range filter
      if (dateRange !== 'All') {
        const recDate = new Date(r.date);
        const now = new Date('2026-09-24T00:00:00');
        const diffDays = Math.floor((now.getTime() - recDate.getTime()) / (1000 * 3600 * 24));
        if (dateRange === 'Today' && diffDays !== 0) return false;
        if (dateRange === '7days' && (diffDays < 0 || diffDays > 7)) return false;
        if (dateRange === '30days' && (diffDays < 0 || diffDays > 30)) return false;
      }

      return true;
    });
  }, [allRecords, searchTruckNo, selectedCustomer, productFilter, dateRange]);

  // Aggregate Metrics
  const totalTrips = filteredRecords.length;
  const totalVolumeCft = filteredRecords.reduce((sum, r) => sum + r.volumeCft, 0);
  const totalWeightMt = filteredRecords.reduce((sum, r) => sum + (r.netWeightMt || 0), 0);
  const totalAmountBdt = filteredRecords.reduce((sum, r) => sum + r.totalAmount, 0);
  const avgCftPerTrip = totalTrips > 0 ? Math.round((totalVolumeCft / totalTrips) * 10) / 10 : 0;

  // Selected Truck Profile if user searched an exact truck
  const activeTruckProfile = useMemo(() => {
    if (!searchTruckNo.trim()) return null;
    const match = uniqueTrucks.find(t => t.truckNo.toLowerCase() === searchTruckNo.trim().toLowerCase());
    return match || null;
  }, [searchTruckNo, uniqueTrucks]);

  // Live Stone Formula Calculator outputs with Down Option
  const calcResult = calculateStoneCft(
    Number(calcLengthFt) || 0,
    Number(calcLengthIn) || 0,
    Number(calcWidthFt) || 0,
    Number(calcWidthIn) || 0,
    Number(calcHeightFt) || 0,
    Number(calcHeightIn) || 0,
    calcDownInches
  );
  const calculatedCftOutput = calcResult.billedCft;
  const calculatedTonEquivalent = Math.round(calculatedCftOutput * 0.0435 * 100) / 100;
  const calculatedTotalAmount = Math.round(calculatedCftOutput * (Number(calcRate) || 0));

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* ================= 1. Header & Quick Actions ================= */}
      <div className="bg-white p-5 rounded-2xl shadow-xs border border-slate-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-xs">
              <Truck className="w-4 h-4" />
            </div>
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
              Truck & Vehicles Measurement Report
            </h2>
            <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-full">
              Sales Invoice Auto-Sync
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setShowCalculator(!showCalculator)}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs ${
              showCalculator
                ? 'bg-amber-600 text-white shadow-amber-200'
                : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>{showCalculator ? 'Close Calculator' : 'CFT Calculator'}</span>
          </button>

          {onOpenNewInvoiceModal && (
            <button
              type="button"
              onClick={onOpenNewInvoiceModal}
              className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Create Sales Invoice</span>
            </button>
          )}
        </div>
      </div>

      {/* ================= 2. Live CFT Calculator Panel (Collapsible) ================= */}
      {showCalculator && (
        <div className="bg-amber-50/70 border border-amber-200 p-4 sm:p-5 rounded-2xl shadow-xs animate-in slide-in-from-top-2 duration-200 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2.5 border-b border-amber-200/80 gap-2">
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4 text-amber-700 shrink-0" />
              <h3 className="font-bold text-xs sm:text-sm text-amber-950">
                Stone & Boulder CFT Calculator
              </h3>
            </div>
            <span className="text-[11px] text-amber-900 font-medium bg-amber-100/90 border border-amber-300/80 px-2 py-0.5 rounded shrink-0">
              Enter feet and inches (Auto CFT calculation)
            </span>
          </div>

          {/* Down Option Selector */}
          <div className="bg-amber-100/70 border border-amber-300 rounded-xl p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs">
            <div className="flex items-center gap-2">
              <ArrowDown className="w-4 h-4 text-amber-800" />
              <span className="text-xs font-bold text-amber-950">Truck Down Option:</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <select
                value={calcDownInches}
                onChange={(e) => setCalcDownInches(Number(e.target.value))}
                className="bg-white border border-amber-300 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-900 focus:ring-1 focus:ring-amber-500 outline-none shadow-2xs"
              >
                {STONE_DOWN_OPTIONS.map(opt => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
              {calcDownInches > 0 && calcResult.originalBilledCft > 0 && (
                <span className="text-[11px] font-mono font-bold text-amber-900 bg-white px-2 py-0.5 rounded border border-amber-300">
                  Original: {calcResult.originalBilledCft} CFT → Effective: {calcResult.billedCft} CFT
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Length (L) */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/80 shadow-2xs space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-700">Length:</label>
                <span className="text-[10px] font-mono text-slate-500 font-bold">{calcResult.lengthEffective}</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={calcLengthFt}
                    onChange={(e) => setCalcLengthFt(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 font-mono text-xs font-bold text-center text-slate-900 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                    title="Length Feet"
                  />
                  <span className="text-[10px] text-slate-500 shrink-0 font-medium">ft</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="11.5"
                    step="0.5"
                    placeholder="0"
                    value={calcLengthIn}
                    onChange={(e) => setCalcLengthIn(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-1.5 py-1 font-mono text-xs font-bold text-center text-slate-900 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                    title="Length Inches (0.5, 1, 1.5, 2, 2.5...)"
                  />
                  <span className="text-[10px] text-slate-500 shrink-0 font-medium">in</span>
                </div>
              </div>
            </div>

            {/* Width (W) */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/80 shadow-2xs space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-700">Width:</label>
                <span className="text-[10px] font-mono text-slate-500 font-bold">{calcResult.widthEffective}</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={calcWidthFt}
                    onChange={(e) => setCalcWidthFt(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 font-mono text-xs font-bold text-center text-slate-900 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                    title="Width Feet"
                  />
                  <span className="text-[10px] text-slate-500 shrink-0 font-medium">ft</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="11.5"
                    step="0.5"
                    placeholder="0"
                    value={calcWidthIn}
                    onChange={(e) => setCalcWidthIn(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-1.5 py-1 font-mono text-xs font-bold text-center text-slate-900 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                    title="Width Inches"
                  />
                  <span className="text-[10px] text-slate-500 shrink-0 font-medium">in</span>
                </div>
              </div>
            </div>

            {/* Height (H) */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/80 shadow-2xs space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-700">Height:</label>
                <span className="text-[10px] font-mono text-slate-500 font-bold">
                  {calcDownInches > 0 ? `${calcResult.heightEffective} (Orig: ${calcResult.originalHeightEffective})` : calcResult.originalHeightEffective}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={calcHeightFt}
                    onChange={(e) => setCalcHeightFt(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 font-mono text-xs font-bold text-center text-slate-900 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                    title="Height Feet"
                  />
                  <span className="text-[10px] text-slate-500 shrink-0 font-medium">ft</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="11.5"
                    step="0.5"
                    placeholder="0"
                    value={calcHeightIn}
                    onChange={(e) => setCalcHeightIn(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-1.5 py-1 font-mono text-xs font-bold text-center text-slate-900 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                    title="Height Inches"
                  />
                  <span className="text-[10px] text-slate-500 shrink-0 font-medium">in</span>
                </div>
              </div>
            </div>

            {/* Rate & Result Card */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-300 shadow-2xs flex flex-col justify-between space-y-1.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  Rate (৳/CFT):
                </label>
                <input
                  type="number"
                  step="1"
                  value={calcRate}
                  onChange={(e) => setCalcRate(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1 font-mono text-xs font-bold text-slate-900 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                />
              </div>

              <div className="pt-1.5 border-t border-amber-100">
                <span className="text-[10px] text-slate-500 font-semibold block">Calculated Total Volume:</span>
                <div className="font-mono text-xl font-black text-amber-950 leading-tight">
                  {calculatedCftOutput.toLocaleString()} <span className="text-xs font-bold text-amber-800">CFT</span>
                </div>
                <div className="text-[10px] font-mono text-slate-600 font-medium">
                  ৳{calculatedTotalAmount.toLocaleString()} <span className="text-slate-400">| ≈ {calculatedTonEquivalent} MT</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= 3. KPI Summary Metric Cards ================= */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Total Trips */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono">
              Total Trips
            </span>
            <span className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <Truck className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {totalTrips}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Dispatched truck trips</p>
        </div>

        {/* Total Volume (CFT) */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 font-mono">
              Total Volume
            </span>
            <span className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Ruler className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-amber-900 font-mono">
            {totalVolumeCft.toLocaleString()} <span className="text-xs font-semibold text-slate-500">CFT</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Total crushed stone & boulders</p>
        </div>

        {/* Total Weight (MT) */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 font-mono">
              Weight (MT)
            </span>
            <span className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <Scale className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-indigo-900 font-mono">
            {totalWeightMt.toFixed(1)} <span className="text-xs font-semibold text-slate-500">MT</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Weighbridge net metric tons</p>
        </div>

        {/* Total Billed Value */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 font-mono">
              Total Value
            </span>
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-emerald-900 font-mono">
            ৳{totalAmountBdt.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Total trip billing amount</p>
        </div>

        {/* Average CFT per Trip */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-purple-600 font-mono">
              Avg Trip CFT
            </span>
            <span className="p-2 rounded-xl bg-purple-50 text-purple-600">
              <Layers className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-purple-900 font-mono">
            {avgCftPerTrip} <span className="text-xs font-semibold text-slate-500">CFT</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Avg capacity / trip</p>
        </div>
      </div>

      {/* ================= 4. Search, Filter & Quick Truck Chips ================= */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl shadow-xs border border-slate-200/80 space-y-3">
        {/* Top Controls Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          
          {/* Main Truck Search Input with Autocomplete */}
          <div className="md:col-span-5 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder="Search by truck number (e.g. Dhaka Metro-Ta 18-4512)..."
              value={searchTruckNo}
              onChange={(e) => setSearchTruckNo(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-2xs"
            />
            {searchTruckNo && (
              <button
                type="button"
                onClick={() => setSearchTruckNo('')}
                className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Customer Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none shadow-2xs"
            >
              <option value="All">All Customers</option>
              {customers.map(c => (
                <option key={c.id} value={c.tradeName || c.name}>
                  {c.tradeName || c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Product Filter */}
          <div className="md:col-span-2">
            <select
              value={productFilter}
              onChange={(e) => setProductFilter(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none shadow-2xs"
            >
              <option value="All">All Stone Types</option>
              <option value="20MM">20MM Crushed Stone</option>
              <option value="Boulder">Bhutan Boulder Stone</option>
              <option value="River">River Stone</option>
              <option value="Down">3/4 Down Stone</option>
            </select>
          </div>

          {/* Date Filter */}
          <div className="md:col-span-2">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value as any)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none shadow-2xs"
            >
              <option value="All">All Dates</option>
              <option value="Today">Today</option>
              <option value="7days">Last 7 Days</option>
              <option value="30days">Last 30 Days</option>
            </select>
          </div>
        </div>

        {/* Quick Truck Select Chips */}
        <div className="pt-2 border-t border-slate-100 flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <span className="text-[10px] font-mono text-slate-400 uppercase font-bold shrink-0">
            Quick Select Truck:
          </span>
          <button
            type="button"
            onClick={() => setSearchTruckNo('')}
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors shrink-0 cursor-pointer ${
              searchTruckNo === ''
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Trucks ({uniqueTrucks.length})
          </button>
          {uniqueTrucks.map(t => (
            <button
              key={t.truckNo}
              type="button"
              onClick={() => setSearchTruckNo(t.truckNo)}
              className={`px-2.5 py-1 rounded-lg font-mono text-[11px] transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
                searchTruckNo.toLowerCase() === t.truckNo.toLowerCase()
                  ? 'bg-blue-600 text-white font-bold shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200/60'
              }`}
            >
              <Truck className="w-3 h-3" />
              <span>{t.truckNo}</span>
              <span className="text-[10px] opacity-75 font-sans">({t.count} trips)</span>
            </button>
          ))}
        </div>
      </div>

      {/* ================= 5. Active Truck Profile Banner (When a truck is chosen) ================= */}
      {activeTruckProfile && (
        <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white p-5 rounded-2xl shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-xs flex items-center justify-center font-bold text-xl border border-white/20">
              🚛
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold tracking-tight font-mono">
                  {activeTruckProfile.truckNo}
                </h3>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono">
                  Active Carrier
                </span>
              </div>
              <p className="text-xs text-blue-200 mt-0.5 flex items-center gap-2">
                <span>Driver: <strong>{activeTruckProfile.driverName}</strong></span>
                <span>•</span>
                <span>Dedicated Stone Hauler</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="bg-white/10 px-3 py-2 rounded-xl border border-white/10">
              <span className="text-[10px] text-blue-200 block">Total Dispatches:</span>
              <span className="text-base font-bold">{activeTruckProfile.count} Trips</span>
            </div>
            <div className="bg-white/10 px-3 py-2 rounded-xl border border-white/10">
              <span className="text-[10px] text-blue-200 block">Total Volume Carried:</span>
              <span className="text-base font-bold text-amber-300">{activeTruckProfile.totalCft.toLocaleString()} CFT</span>
            </div>
          </div>
        </div>
      )}

      {/* ================= 6. Measurement Ledger Table ================= */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200/80 overflow-hidden">
        <div className="p-4 sm:px-5 sm:py-3.5 bg-slate-50/80 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 uppercase font-mono tracking-wider">
              Vehicle Dispatch & Measurement Ledger ({filteredRecords.length} Records)
            </h3>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 font-mono text-[11px] uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-3.5 font-bold">DATE & TIME</th>
                <th className="py-3 px-3.5 font-bold">TRUCK NO</th>
                <th className="py-3 px-3.5 font-bold">DRIVER & CONTACT</th>
                <th className="py-3 px-3.5 font-bold">CHALLAN / INV</th>
                <th className="py-3 px-3.5 font-bold">CUSTOMER & DESTINATION</th>
                <th className="py-3 px-3.5 font-bold">PRODUCT</th>
                <th className="py-3 px-3.5 font-bold text-center">MEASUREMENT (L × W × H)</th>
                <th className="py-3 px-3.5 font-bold text-right">VOLUME (CFT)</th>
                <th className="py-3 px-3.5 font-bold text-right">WEIGHT (MT)</th>
                <th className="py-3 px-3.5 font-bold text-right">RATE (BDT)</th>
                <th className="py-3 px-3.5 font-bold text-right">TOTAL (BDT)</th>
                <th className="py-3 px-3.5 font-bold text-center">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-12 text-center text-slate-400">
                    <Truck className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-sm">No truck measurement records found</p>
                    <p className="text-xs text-slate-400 mt-0.5">Search with another truck number or create a new measurement record</p>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r, idx) => (
                  <tr key={r.id} className="hover:bg-slate-50/60 transition-colors">
                    {/* Date & Time */}
                    <td className="py-3 px-3.5 font-mono text-slate-700 whitespace-nowrap">
                      <div className="font-bold">{r.date}</div>
                      <div className="text-[10px] text-slate-400">{r.time || '10:00 AM'}</div>
                    </td>

                    {/* Truck No */}
                    <td className="py-3 px-3.5 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => setSearchTruckNo(r.truckNo)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-800 font-mono font-bold text-xs border border-blue-200 transition-colors cursor-pointer"
                        title="Click to view all trips of this truck"
                      >
                        <Truck className="w-3 h-3 text-blue-600" />
                        <span>{r.truckNo}</span>
                      </button>
                    </td>

                    {/* Driver */}
                    <td className="py-3 px-3.5 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{r.driverName}</div>
                      <div className="text-[10px] font-mono text-slate-400">{r.driverPhone || '017XX-XXXXXX'}</div>
                    </td>

                    {/* Challan / Invoice */}
                    <td className="py-3 px-3.5 font-mono whitespace-nowrap">
                      <div className="font-bold text-slate-800">{r.challanNo}</div>
                      {r.invoiceNo && (
                        <div className="text-[10px] text-blue-600 font-semibold">{r.invoiceNo}</div>
                      )}
                    </td>

                    {/* Customer & Destination */}
                    <td className="py-3 px-3.5">
                      <div className="font-semibold text-slate-900 line-clamp-1">{r.customerName}</div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1">
                        <MapPin className="w-2.5 h-2.5 shrink-0" />
                        <span className="truncate max-w-[140px]">{r.destination || 'Project Depot'}</span>
                      </div>
                    </td>

                    {/* Product */}
                    <td className="py-3 px-3.5">
                      <span className="font-medium text-slate-800 text-[11px] block line-clamp-1">
                        {r.itemName}
                      </span>
                    </td>

                    {/* Dimensions (L × W × H) */}
                    <td className="py-3 px-3.5 text-center font-mono whitespace-nowrap">
                      {r.downInches && r.downInches > 0 ? (
                        <div className="space-y-1">
                          <div className="text-[10px] text-slate-500 font-medium">
                            Original: {r.measurementLength}'{r.measurementLengthInches || 0}" × {r.measurementWidth}'{r.measurementWidthInches || 0}" × {r.originalHeightFeet || r.measurementHeight}'{r.originalHeightInches !== undefined ? r.originalHeightInches : (r.measurementHeightInches || 0)}"
                            <span className="text-slate-400 ml-1">({r.originalVolumeCft || 460} CFT)</span>
                          </div>
                          <div className="flex items-center justify-center gap-1">
                            <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[9px] font-bold">
                              {r.downLabel || `${r.downInches}″ Down`}
                            </span>
                            <span className="bg-blue-50 text-blue-900 px-2 py-0.5 rounded text-[11px] font-bold border border-blue-200">
                              {r.measurementLength}'{r.measurementLengthInches || 0}" × {r.measurementWidth}'{r.measurementWidthInches || 0}" × {r.effectiveHeightFeet || r.measurementHeight}'{r.effectiveHeightInches !== undefined ? r.effectiveHeightInches : (r.measurementHeightInches || 0)}"
                            </span>
                          </div>
                          {r.formulaDisplay && (
                            <span className="text-[9px] text-slate-400 font-mono block">
                              {r.formulaDisplay}
                            </span>
                          )}
                        </div>
                      ) : (
                        <div>
                          <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-[11px] font-bold border border-slate-200 block">
                            {r.measurementLength}' {r.measurementLengthInches ? `${r.measurementLengthInches}"` : ''} × {r.measurementWidth}' {r.measurementWidthInches ? `${r.measurementWidthInches}"` : ''} × {r.measurementHeight}' {r.measurementHeightInches ? `${r.measurementHeightInches}"` : ''}
                          </span>
                          {r.formulaDisplay && (
                            <span className="text-[9px] text-slate-400 font-mono mt-0.5 block">
                              {r.formulaDisplay}
                            </span>
                          )}
                        </div>
                      )}
                    </td>

                    {/* Volume (CFT) */}
                    <td className="py-3 px-3.5 text-right font-mono whitespace-nowrap">
                      <span className="font-black text-amber-900 text-xs bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                        {r.volumeCft.toLocaleString()} CFT
                      </span>
                      {r.exactCft && r.exactCft !== r.volumeCft && (
                        <div className="text-[9px] text-slate-400 mt-0.5">
                          Exact: {r.exactCft}
                        </div>
                      )}
                    </td>

                    {/* Weight (MT) */}
                    <td className="py-3 px-3.5 text-right font-mono text-slate-700 whitespace-nowrap">
                      {r.netWeightMt ? `${r.netWeightMt.toFixed(1)} MT` : '—'}
                    </td>

                    {/* Rate */}
                    <td className="py-3 px-3.5 text-right font-mono text-slate-700 whitespace-nowrap">
                      ৳{r.ratePerCftOrMt.toLocaleString()}
                    </td>

                    {/* Total Amount */}
                    <td className="py-3 px-3.5 text-right font-mono font-black text-slate-900 whitespace-nowrap">
                      ৳{r.totalAmount.toLocaleString()}
                    </td>

                    {/* Action */}
                    <td className="py-3 px-3.5 text-center whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => setSelectedSlipRecord(r)}
                        className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-300 text-[11px] font-bold transition-colors shadow-2xs inline-flex items-center gap-1 cursor-pointer"
                        title="Print Vehicle Measurement Slip"
                      >
                        <Printer className="w-3 h-3 text-slate-500" />
                        <span>Slip</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= 7. Modal: Printable Truck Measurement Slip ================= */}
      {selectedSlipRecord && (
        <ModalWrapper
          isOpen={!!selectedSlipRecord}
          onClose={() => setSelectedSlipRecord(null)}
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in"
        >
          <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            {/* Header Action Bar */}
            <div className="bg-slate-900 text-white px-5 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-xs uppercase tracking-wider">
                  Truck Measurement Slip & Delivery Gate-Pass
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Slip</span>
                </button>
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={() => setSelectedSlipRecord(null)}
                  className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer shrink-0"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Body */}
            <div className="p-6 space-y-4 text-xs font-sans text-slate-800 bg-white">
              {/* Slip Company Header */}
              <div className="text-center border-b border-slate-200 pb-3">
                <h2 className="font-extrabold text-base text-slate-900 uppercase">
                  {companyProfile.companyName}
                </h2>
                <p className="text-[11px] text-slate-500">
                  {companyProfile.address} • Mobile: {companyProfile.mobile}
                </p>
                <div className="inline-block mt-1 px-3 py-0.5 rounded-full bg-slate-100 font-mono font-bold text-[10px] text-slate-700 border border-slate-200">
                  OFFICIAL TRUCK MEASUREMENT & GATE PASS
                </div>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200/80 font-mono">
                <div>
                  <span className="text-[10px] text-slate-400 block">CHALLAN NO:</span>
                  <span className="font-bold text-slate-900">{selectedSlipRecord.challanNo}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">DATE & TIME:</span>
                  <span className="font-bold text-slate-900">{selectedSlipRecord.date} ({selectedSlipRecord.time || '10:00 AM'})</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">TRUCK NO:</span>
                  <span className="font-black text-blue-700 text-sm">{selectedSlipRecord.truckNo}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">DRIVER NAME:</span>
                  <span className="font-bold text-slate-900">{selectedSlipRecord.driverName}</span>
                </div>
              </div>

              {/* Customer & Destination */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Customer:</span>
                  <span className="font-bold text-slate-900">{selectedSlipRecord.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Delivery Destination:</span>
                  <span className="font-semibold text-slate-800">{selectedSlipRecord.destination || 'Project Site'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Consignment:</span>
                  <span className="font-semibold text-slate-800">{selectedSlipRecord.itemName}</span>
                </div>
              </div>

              {/* Measurement Section (Highlight) */}
              <div className="bg-amber-50/70 border border-amber-300 rounded-xl p-4 text-center space-y-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-800 block">
                  VEHICLE BODY VOLUMETRIC MEASUREMENT
                </span>
                
                {selectedSlipRecord.downInches && selectedSlipRecord.downInches > 0 ? (
                  <div className="space-y-1.5">
                    <div className="text-xs font-mono text-slate-600">
                      Original Truck Measurement: {selectedSlipRecord.measurementLength}' {selectedSlipRecord.measurementLengthInches || 0}" × {selectedSlipRecord.measurementWidth}' {selectedSlipRecord.measurementWidthInches || 0}" × {selectedSlipRecord.originalHeightFeet || selectedSlipRecord.measurementHeight}' {selectedSlipRecord.originalHeightInches !== undefined ? selectedSlipRecord.originalHeightInches : (selectedSlipRecord.measurementHeightInches || 0)}" 
                      <span className="font-bold ml-1 text-slate-800">({selectedSlipRecord.originalVolumeCft || 460} CFT)</span>
                    </div>
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-200 border border-amber-400 text-amber-950 text-xs font-bold font-mono">
                      <span>Down Deduction: {selectedSlipRecord.downLabel || `${selectedSlipRecord.downInches}″ Down`}</span>
                    </div>
                    <div className="text-sm font-mono text-blue-950 font-bold">
                      Effective Measurement: {selectedSlipRecord.measurementLength}' {selectedSlipRecord.measurementLengthInches || 0}" × {selectedSlipRecord.measurementWidth}' {selectedSlipRecord.measurementWidthInches || 0}" × {selectedSlipRecord.effectiveHeightFeet || selectedSlipRecord.measurementHeight}' {selectedSlipRecord.effectiveHeightInches !== undefined ? selectedSlipRecord.effectiveHeightInches : (selectedSlipRecord.measurementHeightInches || 0)}"
                    </div>
                  </div>
                ) : (
                  <div className="text-sm font-mono text-slate-800 font-bold">
                    Length: {selectedSlipRecord.measurementLength}' {selectedSlipRecord.measurementLengthInches ? `${selectedSlipRecord.measurementLengthInches}"` : ''} &nbsp;|&nbsp; 
                    Width: {selectedSlipRecord.measurementWidth}' {selectedSlipRecord.measurementWidthInches ? `${selectedSlipRecord.measurementWidthInches}"` : ''} &nbsp;|&nbsp; 
                    Height: {selectedSlipRecord.measurementHeight}' {selectedSlipRecord.measurementHeightInches ? `${selectedSlipRecord.measurementHeightInches}"` : ''}
                  </div>
                )}

                {selectedSlipRecord.formulaDisplay && (
                  <div className="text-[11px] font-mono text-blue-900 bg-white/70 py-1 px-2 rounded border border-amber-200 inline-block">
                    Effective Formula: {selectedSlipRecord.formulaDisplay}
                    {selectedSlipRecord.exactCft && ` = ${selectedSlipRecord.exactCft} CFT`}
                  </div>
                )}
                <div className="pt-2 border-t border-amber-200/80 flex items-center justify-center gap-6">
                  <div>
                    <span className="text-[10px] text-slate-500 block">BILLED VOLUME (CFT):</span>
                    <span className="text-xl font-black font-mono text-amber-950">
                      {selectedSlipRecord.volumeCft.toLocaleString()} CFT
                    </span>
                    {selectedSlipRecord.exactCft && selectedSlipRecord.exactCft !== selectedSlipRecord.volumeCft && (
                      <span className="text-[9px] text-slate-500 block">
                        (Exact: {selectedSlipRecord.exactCft})
                      </span>
                    )}
                  </div>
                  {selectedSlipRecord.netWeightMt && (
                    <div>
                      <span className="text-[10px] text-slate-500 block">NET WEIGHT:</span>
                      <span className="text-xl font-black font-mono text-slate-900">
                        {selectedSlipRecord.netWeightMt.toFixed(1)} MT
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Financial Section */}
              <div className="border border-slate-200 rounded-xl p-3 flex justify-between items-center font-mono">
                <div>
                  <span className="text-slate-500 text-[11px]">Unit Rate: </span>
                  <span className="font-bold">৳{selectedSlipRecord.ratePerCftOrMt} / CFT</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 text-[11px]">Total Value: </span>
                  <span className="text-base font-black text-slate-900">৳{selectedSlipRecord.totalAmount.toLocaleString()}</span>
                </div>
              </div>

              {/* Signature Lines */}
              <div className="grid grid-cols-3 gap-4 pt-8 text-center text-[10px] text-slate-500 font-mono">
                <div className="border-t border-slate-300 pt-1">
                  Driver's Signature
                </div>
                <div className="border-t border-slate-300 pt-1">
                  Weighbridge In-Charge
                </div>
                <div className="border-t border-slate-300 pt-1">
                  Gate Security Clearance
                </div>
              </div>
            </div>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
