import React, { useState } from 'react';
import { 
  Printer, 
  Share2, 
  X, 
  Building2, 
  CreditCard,
  Sun,
  Moon,
  CheckCircle2,
  AlertCircle,
  Clock,
  FileText
} from 'lucide-react';
import { Customer, SalesInvoice, SalesOrder } from '../../types/erp';
import { getBankAccounts } from '../../utils/bankAccountStorage';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface PrintableInvoiceModalProps {
  invoice: SalesInvoice;
  customer?: Customer;
  order?: SalesOrder;
  onClose: () => void;
  onPaymentCollect?: (invoice: SalesInvoice) => void;
}

// Convert numbers to words (BDT)
function numberToBDTWords(num: number): string {
  if (num === 0) return 'Zero Taka Only';
  const units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertBelowThousand(n: number): string {
    let str = '';
    if (n >= 100) {
      str += units[Math.floor(n / 100)] + ' Hundred ';
      n %= 100;
    }
    if (n >= 20) {
      str += tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + units[n % 10] : '');
    } else if (n > 0) {
      str += units[n];
    }
    return str.trim();
  }

  let crore = Math.floor(num / 10000000);
  let remainder = num % 10000000;
  let lakh = Math.floor(remainder / 100000);
  remainder %= 100000;
  let thousand = Math.floor(remainder / 1000);
  let rest = remainder % 1000;

  let words = '';
  if (crore > 0) words += convertBelowThousand(crore) + ' Crore ';
  if (lakh > 0) words += convertBelowThousand(lakh) + ' Lakh ';
  if (thousand > 0) words += convertBelowThousand(thousand) + ' Thousand ';
  if (rest > 0) words += convertBelowThousand(rest);

  return (words.trim() + ' Taka Only');
}

export const PrintableInvoiceModal: React.FC<PrintableInvoiceModalProps> = ({
  invoice,
  customer,
  order,
  onClose,
  onPaymentCollect
}) => {
  const [copied, setCopied] = useState(false);
  const [themeMode, setThemeMode] = useState<'light' | 'dark'>('light');
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  React.useEffect(() => {
    return subscribeCompanyProfile(setCompanyProfile);
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const handleCopySummary = () => {
    const text = `*COMMERCIAL INVOICE: ${invoice.invoiceNumber}*\nCustomer: ${customer?.tradeName || invoice.customerName}\nDate: ${invoice.invoiceDate}\nTotal Amount: BDT ${invoice.totalAmount.toLocaleString()}\nPaid: BDT ${invoice.paidAmount.toLocaleString()}\nDue Balance: BDT ${invoice.dueAmount.toLocaleString()}\nStatus: ${invoice.status}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const isFullyPaid = invoice.dueAmount === 0 || invoice.status === 'Paid';
  const isOverdue = invoice.status === 'Overdue';

  // Subtotal of items
  const subtotal = invoice.items.reduce((sum, itm) => sum + (itm.amount || itm.quantity * itm.unitPrice), 0);
  const vatAmount = invoice.totalAmount > subtotal ? invoice.totalAmount - subtotal : 0;

  return (
    <ModalWrapper
      onClose={onClose}
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex flex-col items-center justify-start p-2 sm:p-4 overflow-y-auto animate-in fade-in"
    >
      {/* Top Action Bar (No-Print) */}
      <div className="w-full max-w-4xl bg-white border border-slate-200 rounded-t-2xl p-3.5 flex items-center justify-between shadow-xl no-print mb-2 sticky top-2 z-20">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-xs">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-2">
                Invoice #{invoice.invoiceNumber}
              </h3>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                isFullyPaid ? 'bg-emerald-50 text-emerald-700 border-emerald-300' :
                isOverdue ? 'bg-rose-50 text-rose-700 border-rose-300' :
                'bg-amber-50 text-amber-700 border-amber-300'
              }`}>
                {invoice.status}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {invoice.dueAmount > 0 && onPaymentCollect && (
            <button
              type="button"
              onClick={() => onPaymentCollect(invoice)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              title="Collect payment for this invoice"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Collect Payment</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleCopySummary}
            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-200 cursor-pointer"
            title="Copy invoice summary"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{copied ? 'Copied!' : 'Share / Copy'}</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-extrabold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            title="Print or Save as PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Invoice</span>
          </button>

          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors ml-1 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Invoice Sheet Canvas (Clean Minimal Print Ready) */}
      <div 
        id="printable-invoice"
        className="w-full max-w-4xl bg-white border border-slate-200 rounded-2xl shadow-xl p-6 sm:p-10 mb-12 select-text text-slate-900 space-y-6"
      >
        {/* Header: Company Info + Invoice Details */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 border-b-2 border-slate-900">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center font-black text-lg">
                {(companyProfile.companyName || 'J').replace(/^M\/S\s+/i, '').charAt(0).toUpperCase() || 'J'}
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
                  {companyProfile.companyName}
                </h2>
                <p className="text-[11px] text-slate-500 font-mono">
                  {companyProfile.address}
                </p>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 space-y-0.5">
              <div>Mobile: {companyProfile.mobile}</div>
            </div>
          </div>

          <div className="sm:text-right">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 uppercase tracking-tight">
              INVOICE
            </h1>
            <div className="mt-1 font-mono space-y-0.5 text-xs">
              <div className="font-bold text-sm text-blue-700">{invoice.invoiceNumber}</div>
              <div className="text-slate-500">Date: {invoice.invoiceDate}</div>
              <div className="text-slate-500">Due: <strong className="text-rose-600">{invoice.dueDate}</strong></div>
              <div className="pt-1">
                <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${
                  isFullyPaid ? 'bg-emerald-50 text-emerald-700 border-emerald-300' :
                  isOverdue ? 'bg-rose-50 text-rose-700 border-rose-300' :
                  'bg-amber-50 text-amber-700 border-amber-300'
                }`}>
                  {invoice.status.toUpperCase()}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bill To & Dispatch Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pb-6 border-b border-slate-200 text-xs">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-1">
            <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block">
              BILL TO (CUSTOMER)
            </span>
            <div className="font-bold text-sm text-slate-900">
              {customer?.tradeName || invoice.customerName}
            </div>
            {customer?.name && customer.name !== customer.tradeName && (
              <div className="text-slate-700 font-medium">{customer.name}</div>
            )}
            <div className="text-slate-500">
              {customer?.address || 'Plot 45, BSCIC Industrial Area'}, {customer?.city || 'Dhaka'}
            </div>
            <div className="text-slate-500 font-mono text-[11px]">
              Phone: {customer?.phone || '+880 1711-XXXXXX'} | Code: {customer?.code || invoice.customerId}
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-1 sm:text-right">
            <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block">
              ORDER & PAYMENT TERMS
            </span>
            <div className="text-slate-700">
              Order Ref: <span className="font-mono font-bold text-slate-900">{invoice.soNumber || 'SO-DIRECT'}</span>
            </div>
            <div className="text-slate-700">
              Payment Terms: <span className="font-semibold">{order?.paymentTerm || (isFullyPaid ? 'Paid in Full' : '30 Days Credit')}</span>
            </div>
            <div className="text-slate-700">
              Settlement Method: <span className="font-semibold">{invoice.paymentMethod || 'Bank Transfer'}</span>
            </div>
          </div>
        </div>

        {/* Transport & Stone Measurement Details (if recorded) */}
        {(invoice.truckNo || invoice.measurementCft || invoice.driverName) && (
          <div className="bg-amber-50/50 border border-amber-200/80 rounded-xl p-3 text-xs flex flex-wrap items-center justify-between gap-3 font-mono">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded">
                TRUCK DISPATCH & MEASUREMENT
              </span>
              {invoice.truckNo && (
                <span className="text-slate-800">
                  Vehicle: <strong>{invoice.truckNo}</strong>
                </span>
              )}
              {invoice.driverName && (
                <span className="text-slate-600">
                  | Driver: <strong>{invoice.driverName}</strong> {invoice.driverPhone ? `(${invoice.driverPhone})` : ''}
                </span>
              )}
            </div>

            {(invoice.measurementCft || (invoice.measurementLength && invoice.measurementWidth && invoice.measurementHeight)) && (
              <div className="flex items-center gap-2 text-amber-950 font-bold bg-white px-2.5 py-1 rounded border border-amber-200">
                {invoice.downInches && invoice.downInches > 0 ? (
                  <span className="bg-amber-100 text-amber-900 border border-amber-300 px-1.5 py-0.5 rounded text-[10px]">
                    {invoice.downLabel || `${invoice.downInches}″ Down`}
                  </span>
                ) : null}
                {invoice.measurementLength && invoice.measurementWidth && invoice.measurementHeight && (
                  <span className="text-slate-500 font-normal">
                    {invoice.downInches ? `Load Size: ` : `Size: `}
                    {invoice.measurementLength}'{invoice.measurementLengthInches ? `${invoice.measurementLengthInches}"` : ''} × {invoice.measurementWidth}'{invoice.measurementWidthInches ? `${invoice.measurementWidthInches}"` : ''} × {invoice.effectiveHeightFeet || invoice.measurementHeight}'{invoice.effectiveHeightInches !== undefined ? `${invoice.effectiveHeightInches}"` : (invoice.measurementHeightInches ? `${invoice.measurementHeightInches}"` : '')} =
                  </span>
                )}
                <span>Volume: {invoice.billedCft || invoice.measurementCft || (Number(invoice.measurementLength || 0) * Number(invoice.measurementWidth || 0) * Number(invoice.measurementHeight || 0))} CFT</span>
              </div>
            )}
          </div>
        )}

        {/* Product Items Table */}
        <div className="overflow-hidden border border-slate-200 rounded-xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 font-mono text-[11px] uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-4 font-bold">#</th>
                <th className="py-2.5 px-4 font-bold">DESCRIPTION / ITEM</th>
                <th className="py-2.5 px-4 font-bold text-center">UOM</th>
                <th className="py-2.5 px-4 font-bold text-right">QTY</th>
                <th className="py-2.5 px-4 font-bold text-right">RATE (BDT)</th>
                <th className="py-2.5 px-4 font-bold text-right">AMOUNT (BDT)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoice.items.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-mono text-slate-400">{idx + 1}</td>
                  <td className="py-3 px-4 font-semibold text-slate-900">
                    {item.itemName}
                  </td>
                  <td className="py-3 px-4 text-center font-mono text-slate-600">
                    {item.uom || 'MT'}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {item.quantity.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-700">
                    ৳{item.unitPrice.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    ৳{(item.amount || (item.quantity * item.unitPrice)).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Financial Summary & In Words */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-2">
          <div className="md:col-span-7 space-y-3 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block mb-1">
                AMOUNT IN WORDS
              </span>
              <p className="font-semibold text-slate-800 italic">
                {numberToBDTWords(invoice.totalAmount)}
              </p>
            </div>

            {(() => {
              const isBankMethod = invoice.paymentMethod === 'Bank Transfer' || invoice.paymentMethod === 'Cheque';
              const allAccounts = getBankAccounts();
              const depositAcc = allAccounts.find(a => a.id === invoice.depositAccountId) || 
                (invoice.depositAccountId ? null : allAccounts.find(a => a.accountCategory === 'Bank' || a.accountType === 'Current'));

              return (
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1 text-slate-600">
                  <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block mb-1">
                    {isBankMethod ? 'BANK SETTLEMENT DETAILS' : 'SETTLEMENT DETAILS'}
                  </span>
                  {isBankMethod ? (
                    depositAcc ? (
                      <>
                        <div>Bank: <strong>{depositAcc.bankName}</strong> | {depositAcc.branch || 'Principal Branch'}</div>
                        <div className="font-mono text-[11px]">A/C No: <strong>{depositAcc.accountNumber}</strong> {depositAcc.routingNumber ? `| Routing: ${depositAcc.routingNumber}` : ''}</div>
                      </>
                    ) : (
                      <div>Bank: <strong>{invoice.depositAccountName || 'Bank Transfer / Cheque Settlement'}</strong> {invoice.paymentRef ? `| Ref: ${invoice.paymentRef}` : ''}</div>
                    )
                  ) : (
                    <div className="font-medium text-slate-800">
                      Payment Mode: <strong>Cash</strong> {invoice.paidAmount > 0 ? `| Received: ৳${invoice.paidAmount.toLocaleString()}` : ''}
                    </div>
                  )}
                </div>
              );
            })()}
          </div>

          <div className="md:col-span-5 bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-2 text-xs">
            <div className="flex justify-between items-center text-slate-600 font-mono">
              <span>Subtotal:</span>
              <span className="font-bold text-slate-900">৳{subtotal.toLocaleString()}</span>
            </div>

            {vatAmount > 0 && (
              <div className="flex justify-between items-center text-slate-600 font-mono">
                <span>Tax / VAT:</span>
                <span className="font-semibold text-slate-800">৳{vatAmount.toLocaleString()}</span>
              </div>
            )}

            <div className="flex justify-between items-baseline pt-3 pb-2 border-t-2 border-b border-slate-200">
              <span className="font-black text-slate-900 uppercase font-mono">TOTAL:</span>
              <span className="text-xl font-black text-slate-900 font-mono">৳{invoice.totalAmount.toLocaleString()}</span>
            </div>

            {(() => {
              const advAmt = Math.max(0, Number(invoice.adjustedAdvanceAmount ?? invoice.advanceAdjusted ?? 0));
              const cashPaid = invoice.cashPaidAmount !== undefined
                ? Number(invoice.cashPaidAmount)
                : Math.max(0, Number(invoice.paidAmount || 0) - advAmt);
              const totalSettled = Math.max(Number(invoice.paidAmount || 0), cashPaid + advAmt);
              return (
                <>
                  {advAmt > 0 && (
                    <div className="flex justify-between items-center text-[11px] font-mono text-indigo-700">
                      <span>Advance Adjusted{invoice.adjustmentVoucherNo ? ` (${invoice.adjustmentVoucherNo})` : ''}:</span>
                      <span className="font-bold">৳{advAmt.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center text-[11px] font-mono text-emerald-700">
                    <span>{advAmt > 0 ? 'Total Settled / Paid:' : 'Paid Amount:'}</span>
                    <span className="font-bold">৳{totalSettled.toLocaleString()}</span>
                  </div>
                </>
              );
            })()}

            <div className="flex justify-between items-center text-xs font-mono text-rose-600 font-bold">
              <span>Net Due Balance:</span>
              <span className="text-sm font-black">৳{invoice.dueAmount.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Signatures */}
        <div className="grid grid-cols-3 gap-6 pt-12 text-center text-xs text-slate-500 border-t border-slate-200">
          <div>
            <div className="border-t border-dashed border-slate-400 pt-2 font-medium">Customer Acceptance</div>
          </div>
          <div>
            <div className="border-t border-dashed border-slate-400 pt-2 font-medium">Store & Dispatch Officer</div>
          </div>
          <div>
            <div className="border-t border-dashed border-slate-400 pt-2 font-medium">Authorized Commercial Signatory</div>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};
