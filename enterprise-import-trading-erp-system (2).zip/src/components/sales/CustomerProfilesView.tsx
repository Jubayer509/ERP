import React, { useState, useMemo } from 'react';
import { 
  Users, 
  UserPlus, 
  Edit3, 
  Search, 
  Phone, 
  MapPin, 
  Building2, 
  ShieldCheck, 
  Clock, 
  FileText, 
  CreditCard, 
  Receipt, 
  Printer, 
  ChevronRight, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  Filter,
  ArrowUpDown,
  Download
} from 'lucide-react';
import { Customer, SalesInvoice } from '../../types/erp';

export interface CustomerProfilesViewProps {
  customers: Customer[];
  invoices?: SalesInvoice[];
  onAddCustomer: () => void;
  onEditCustomer: (customer: Customer) => void;
  onViewStatement: (customerId: string) => void;
  onCollectPayment?: (customerId: string, suggestedAmount: number) => void;
  onCreateInvoice?: (customerId: string) => void;
}

export const CustomerProfilesView: React.FC<CustomerProfilesViewProps> = ({
  customers,
  invoices = [],
  onAddCustomer,
  onEditCustomer,
  onViewStatement,
  onCollectPayment,
  onCreateInvoice
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [termsFilter, setTermsFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<'name' | 'code' | 'balance'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // KPI Calculations
  const stats = useMemo(() => {
    let totalReceivables = 0;
    let totalAdvances = 0;
    let activeCount = 0;
    let inactiveCount = 0;

    customers.forEach(c => {
      const active = c.isActive !== false && c.status !== 'Inactive';
      if (active) activeCount++;
      else inactiveCount++;

      const bal = c.currentBalance || 0;
      if (bal > 0) totalReceivables += bal;
      else if (bal < 0) totalAdvances += Math.abs(bal);
    });

    return {
      total: customers.length,
      activeCount,
      inactiveCount,
      totalReceivables,
      totalAdvances
    };
  }, [customers]);

  // Unique terms list
  const availableTerms = useMemo(() => {
    const set = new Set<string>();
    customers.forEach(c => {
      if (c.paymentTerms) set.add(c.paymentTerms);
    });
    return Array.from(set);
  }, [customers]);

  // Filtered and sorted customers
  const filteredCustomers = useMemo(() => {
    return customers
      .filter(c => {
        const matchesSearch = 
          c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (c.tradeName && c.tradeName.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (c.companyName && c.companyName.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (c.phone && c.phone.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (c.mobile && c.mobile.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (c.code && c.code.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (c.city && c.city.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (c.address && c.address.toLowerCase().includes(searchTerm.toLowerCase()));

        const isActive = c.isActive !== false && c.status !== 'Inactive';
        const matchesStatus = 
          statusFilter === 'all' ? true :
          statusFilter === 'active' ? isActive : !isActive;

        const matchesTerms = termsFilter === 'all' || c.paymentTerms === termsFilter;

        return matchesSearch && matchesStatus && matchesTerms;
      })
      .sort((a, b) => {
        let cmp = 0;
        if (sortField === 'name') {
          cmp = (a.tradeName || a.name).localeCompare(b.tradeName || b.name);
        } else if (sortField === 'code') {
          cmp = (a.code || '').localeCompare(b.code || '');
        } else if (sortField === 'balance') {
          cmp = (a.currentBalance || 0) - (b.currentBalance || 0);
        }
        return sortDirection === 'asc' ? cmp : -cmp;
      });
  }, [customers, searchTerm, statusFilter, termsFilter, sortField, sortDirection]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">Customers Profile</h2>
                <span className="text-xs bg-blue-100 text-blue-700 font-semibold px-2.5 py-0.5 rounded-full">
                  {customers.length} Profiles
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handlePrint}
            type="button"
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print List</span>
          </button>
          
          <button
            onClick={onAddCustomer}
            type="button"
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm shadow-blue-500/20 transition flex items-center gap-1.5"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ Add Customer</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Total Profiles</span>
            <Users className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{stats.total}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
            <span className="text-emerald-600 font-semibold">{stats.activeCount} Active</span>
            <span>•</span>
            <span className="text-slate-400">{stats.inactiveCount} Inactive</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Total Receivables</span>
            <CreditCard className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-bold text-rose-600 font-mono">
            ৳ {stats.totalReceivables.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[11px] text-rose-600/80 mt-1">Debit Balance (Accounts Receivable)</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Total Advances</span>
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-emerald-600 font-mono">
            ৳ {stats.totalAdvances.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[11px] text-emerald-600/80 mt-1">Credit Balance (Advance Deposit)</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Payment Terms Available</span>
            <Clock className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold text-indigo-600">
            {availableTerms.length || 1} <span className="text-xs font-normal text-slate-500">term types</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Net 30, Net 15, COD, etc.</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by customer name, company, code, mobile (+880), address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Status Filter */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setStatusFilter('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${statusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                All ({customers.length})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('active')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${statusFilter === 'active' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Active
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('inactive')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${statusFilter === 'inactive' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Inactive
              </button>
            </div>

            {/* Terms Filter */}
            {availableTerms.length > 0 && (
              <select
                value={termsFilter}
                onChange={(e) => setTermsFilter(e.target.value)}
                className="py-1.5 px-3 border border-slate-200 rounded-lg text-xs text-slate-700 bg-white outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Terms</option>
                {availableTerms.map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            )}

            {/* Sort Filter */}
            <select
              value={`${sortField}-${sortDirection}`}
              onChange={(e) => {
                const [f, d] = e.target.value.split('-');
                setSortField(f as any);
                setSortDirection(d as any);
              }}
              className="py-1.5 px-3 border border-slate-200 rounded-lg text-xs text-slate-700 bg-white outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="name-asc">Name (A → Z)</option>
              <option value="name-desc">Name (Z → A)</option>
              <option value="code-asc">Code (Asc)</option>
              <option value="balance-desc">Balance (Highest Due)</option>
              <option value="balance-asc">Balance (Lowest)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Customer Directory Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        {filteredCustomers.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
              <Users className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">No Customers Found</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              {searchTerm ? 'No customer matches your search criteria. Try a different query.' : 'No customer profiles have been added yet. Click "+ Add Customer" to create the first profile.'}
            </p>
            <button
              onClick={onAddCustomer}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition inline-flex items-center gap-1.5"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add First Customer</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                  <th className="py-3 px-4">Code</th>
                  <th className="py-3 px-4">Customer Name / Company</th>
                  <th className="py-3 px-4">Mobile & Address</th>
                  <th className="py-3 px-4">Payment Terms</th>
                  <th className="py-3 px-4 text-right">Opening Bal</th>
                  <th className="py-3 px-4 text-right">Current Bal</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredCustomers.map((cust) => {
                  const isActive = cust.isActive !== false && cust.status !== 'Inactive';
                  const rawMobile = cust.mobile || cust.phone || '';
                  const cleanMobile = rawMobile.replace('+880', '').trim();
                  const bal = cust.currentBalance || 0;
                  const isDue = bal > 0;
                  const isAdv = bal < 0;

                  return (
                    <tr key={cust.id} className="hover:bg-blue-50/40 transition group">
                      {/* Code */}
                      <td className="py-3.5 px-4 font-mono font-bold text-blue-700 text-[11px] whitespace-nowrap">
                        {cust.code || 'CUST-000'}
                      </td>

                      {/* Name / Company */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 group-hover:text-blue-700 transition">
                          {cust.tradeName || cust.name}
                        </div>
                        {(cust.companyName || (cust.name && cust.name !== cust.tradeName)) && (
                          <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                            <Building2 className="w-3 h-3 text-slate-400" />
                            <span>{cust.companyName || cust.name}</span>
                          </div>
                        )}
                        {cust.contactPerson && (
                          <div className="text-[10px] text-slate-400">
                            Attn: {cust.contactPerson}
                          </div>
                        )}
                      </td>

                      {/* Mobile & Address */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 text-slate-700 font-mono text-[11px]">
                          <span className="text-[10px]">🇧🇩</span>
                          <span className="font-semibold">+880 {cleanMobile}</span>
                        </div>
                        {(cust.address || cust.city) && (
                          <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5 max-w-xs truncate">
                            <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                            <span className="truncate">{cust.address || cust.city}</span>
                          </div>
                        )}
                      </td>

                      {/* Payment Terms */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>{cust.paymentTerms || (cust.creditDays ? `Net ${cust.creditDays} Days` : 'Net 30 Days')}</span>
                        </span>
                      </td>

                      {/* Opening Balance */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="font-mono text-slate-600 font-medium">
                          ৳ {(cust.openingBalance || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                        </div>
                        <span className={`text-[10px] font-semibold px-1 rounded ${cust.balanceType === 'CR' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                          {cust.balanceType || 'DR'}
                        </span>
                      </td>

                      {/* Current Balance */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className={`font-mono font-bold ${isDue ? 'text-rose-600' : isAdv ? 'text-emerald-600' : 'text-slate-600'}`}>
                          ৳ {Math.abs(bal).toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] font-medium">
                          {isDue ? (
                            <span className="text-rose-600">Due</span>
                          ) : isAdv ? (
                            <span className="text-emerald-600">Advance</span>
                          ) : (
                            <span className="text-slate-400">Nil</span>
                          )}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        {isActive ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-500 border border-slate-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                            Inactive
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* EDIT PROFILE BUTTON - Primary request from user */}
                          <button
                            type="button"
                            onClick={() => onEditCustomer(cust)}
                            className="p-1.5 text-blue-600 hover:text-white hover:bg-blue-600 border border-blue-200 hover:border-blue-600 rounded-lg transition shadow-xs flex items-center gap-1 px-2 text-[11px] font-medium"
                            title="Edit Customer Profile"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit Profile</span>
                          </button>

                          {/* Statement button */}
                          <button
                            type="button"
                            onClick={() => onViewStatement(cust.id)}
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 rounded-lg transition"
                            title="View Statement"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>

                          {/* Collect payment button if due */}
                          {onCollectPayment && (
                            <button
                              type="button"
                              onClick={() => onCollectPayment(cust.id, cust.currentBalance || 0)}
                              className="p-1.5 text-emerald-600 hover:text-white hover:bg-emerald-600 border border-emerald-200 hover:border-emerald-600 rounded-lg transition"
                              title="Collect Payment"
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Create invoice button */}
                          {onCreateInvoice && (
                            <button
                              type="button"
                              onClick={() => onCreateInvoice(cust.id)}
                              className="p-1.5 text-indigo-600 hover:text-white hover:bg-indigo-600 border border-indigo-200 hover:border-indigo-600 rounded-lg transition"
                              title="Create Invoice"
                            >
                              <Receipt className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
