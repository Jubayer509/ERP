import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  CreditCard, 
  Calendar, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Receipt, 
  Landmark, 
  Wallet, 
  Users, 
  FileText, 
  Truck, 
  BarChart2, 
  ExternalLink, 
  Plus, 
  Printer, 
  Filter,
  DollarSign,
  ChevronRight,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { Customer, SalesInvoice, CustomerPayment, SalesOrder } from '../../types/erp';

interface SalesOverviewDashboardProps {
  invoices: SalesInvoice[];
  payments: CustomerPayment[];
  customers: Customer[];
  orders?: SalesOrder[];
  onNavigateTab: (tab: 'invoices' | 'payments' | 'balance_report' | 'challans' | 'customers' | 'statement' | 'aging' | 'profitability' | 'truck_report') => void;
  onOpenNewInvoiceModal: () => void;
  onOpenCollectPaymentModal: () => void;
  onViewInvoice?: (invoice: SalesInvoice) => void;
  onViewCustomerStatement?: (customerId: string) => void;
}

export const SalesOverviewDashboard: React.FC<SalesOverviewDashboardProps> = ({
  invoices,
  payments,
  customers,
  orders = [],
  onNavigateTab,
  onOpenNewInvoiceModal,
  onOpenCollectPaymentModal,
  onViewInvoice,
  onViewCustomerStatement
}) => {
  // Selected date for "Today" (default to today's business date 2026-09-21)
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-21');
  const [dateFilterMode, setDateFilterMode] = useState<'today' | 'this_month' | 'all'>('today');

  // Today's Invoices & Payments
  const todayInvoices = useMemo(() => {
    return invoices.filter(inv => inv.invoiceDate === selectedDate);
  }, [invoices, selectedDate]);

  const todayPayments = useMemo(() => {
    return payments.filter(pay => pay.paymentDate === selectedDate);
  }, [payments, selectedDate]);

  // Calculations for Today's Stats
  const todayStats = useMemo(() => {
    const totalSales = todayInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const salesPaidPortion = todayInvoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
    const salesDuePortion = todayInvoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);

    const totalCollection = todayPayments.reduce((sum, pay) => sum + pay.amount, 0);
    const bankCollection = todayPayments
      .filter(p => p.paymentMethod === 'Bank Transfer')
      .reduce((sum, p) => sum + p.amount, 0);
    const chequeCollection = todayPayments
      .filter(p => p.paymentMethod === 'Cheque')
      .reduce((sum, p) => sum + p.amount, 0);
    const cashCollection = todayPayments
      .filter(p => p.paymentMethod === 'Cash')
      .reduce((sum, p) => sum + p.amount, 0);
    const mobileCollection = todayPayments
      .filter(p => p.paymentMethod === 'Mobile Banking')
      .reduce((sum, p) => sum + p.amount, 0);

    const collectionRatio = totalSales > 0 ? ((totalCollection / totalSales) * 100).toFixed(1) : '100.0';

    return {
      totalSales,
      salesPaidPortion,
      salesDuePortion,
      invoiceCount: todayInvoices.length,
      totalCollection,
      bankCollection,
      chequeCollection,
      cashCollection,
      mobileCollection,
      paymentCount: todayPayments.length,
      collectionRatio
    };
  }, [todayInvoices, todayPayments]);

  // Overall Month-to-Date & Total Receivables Stats
  const overallStats = useMemo(() => {
    // Current month MTD (September 2026)
    const mtdInvoices = invoices.filter(inv => inv.invoiceDate.startsWith('2026-09'));
    const mtdPayments = payments.filter(pay => pay.paymentDate.startsWith('2026-09'));

    const mtdSales = mtdInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const mtdCollection = mtdPayments.reduce((sum, pay) => sum + pay.amount, 0);

    // Total Receivables from customer balances
    const totalReceivables = customers.reduce((sum, c) => sum + Math.max(0, c.currentBalance), 0);
    const totalAdvances = customers.reduce((sum, c) => sum + (c.currentBalance < 0 ? Math.abs(c.currentBalance) : 0), 0);

    // Overdue Invoices
    const overdueInvoices = invoices.filter(i => i.status === 'Overdue');
    const overdueAmount = overdueInvoices.reduce((sum, i) => sum + i.dueAmount, 0);

    return {
      mtdSales,
      mtdCollection,
      mtdInvoiceCount: mtdInvoices.length,
      mtdPaymentCount: mtdPayments.length,
      totalReceivables,
      totalAdvances,
      overdueAmount,
      overdueCount: overdueInvoices.length
    };
  }, [invoices, payments, customers]);

  // Top Customers by Current Balance
  const topReceivableCustomers = useMemo(() => {
    return [...customers]
      .sort((a, b) => b.currentBalance - a.currentBalance)
      .slice(0, 5);
  }, [customers]);

  return (
    <div className="space-y-6">
      {/* Top Banner: Date Selector & Live Status */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl p-5 shadow-sm border border-slate-700/60 relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl md:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              Executive Sales & Collection Dashboard
            </h1>
          </div>

          {/* Quick Date Control */}
          <div className="bg-slate-800/90 border border-slate-700 rounded-xl p-2 flex items-center gap-2 shrink-0 shadow-inner">
            <div className="flex items-center gap-1.5 px-2 py-1 text-xs text-slate-300">
              <Calendar className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span className="font-semibold text-slate-300">Date:</span>
            </div>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-slate-900 text-white text-xs font-mono font-semibold px-2.5 py-1.5 rounded-lg border border-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-400"
            />
            {selectedDate === '2026-09-21' ? (
              <span className="px-2 py-1 bg-blue-600/30 text-blue-300 border border-blue-500/40 rounded-lg text-[10px] font-bold uppercase">
                Today
              </span>
            ) : (
              <button
                onClick={() => setSelectedDate('2026-09-21')}
                className="px-2 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-[10px] font-semibold transition-colors"
                title="Reset to today's date"
              >
                Reset to Today
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Primary Highlight Cards: Today's Total Sales vs Today's Total Payment */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Today's Total Sales */}
        <div className="bg-white border-2 border-blue-500/40 rounded-2xl p-4 shadow-sm relative overflow-hidden group hover:border-blue-500 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
              Today's Sales
            </span>
            <span className="text-[10px] font-mono font-bold text-slate-500">
              {todayStats.invoiceCount} Invoices
            </span>
          </div>

          <div className="mt-2.5">
            <div className="text-2xl font-black font-mono text-slate-900 tracking-tight">
              BDT {todayStats.totalSales.toLocaleString()}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
              <span className="flex items-center gap-1 text-emerald-600 font-semibold text-[11px]">
                <CheckCircle2 className="w-3 h-3" />
                Collected: BDT {todayStats.salesPaidPortion.toLocaleString()}
              </span>
              <span className="text-rose-600 font-semibold text-[11px]">
                Due: BDT {todayStats.salesDuePortion.toLocaleString()}
              </span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100">
            <button
              onClick={() => onNavigateTab('invoices')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 hover:underline"
            >
              View Invoices →
            </button>
            <button
              onClick={onOpenNewInvoiceModal}
              className="text-[11px] font-bold text-white bg-blue-600 hover:bg-blue-500 px-2 py-1 rounded-md transition-colors"
            >
              + New Invoice
            </button>
          </div>
        </div>

        {/* 2. Today's Total Collections */}
        <div className="bg-white border-2 border-emerald-500/40 rounded-2xl p-4 shadow-sm relative overflow-hidden group hover:border-emerald-500 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100 flex items-center gap-1">
              <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
              Today's Collections
            </span>
            <span className="text-[10px] font-mono font-bold text-slate-500">
              {todayStats.paymentCount} Receipts
            </span>
          </div>

          <div className="mt-2.5">
            <div className="text-2xl font-black font-mono text-emerald-700 tracking-tight">
              BDT {todayStats.totalCollection.toLocaleString()}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
              <span className="text-indigo-700 font-medium text-[11px]">
                Bank: BDT {todayStats.bankCollection.toLocaleString()}
              </span>
              <span className="text-amber-700 font-medium text-[11px]">
                Cheque: BDT {todayStats.chequeCollection.toLocaleString()}
              </span>
              <span className="text-teal-700 font-medium text-[11px]">
                Cash: BDT {todayStats.cashCollection.toLocaleString()}
              </span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100">
            <button
              onClick={() => onNavigateTab('payments')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline"
            >
              View Collections →
            </button>
            <button
              onClick={onOpenCollectPaymentModal}
              className="text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-500 px-2 py-1 rounded-md transition-colors"
            >
              + Collect Payment
            </button>
          </div>
        </div>

        {/* 3. Month-to-Date Performance */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-indigo-600" />
              Month-to-Date (MTD)
            </span>
            <span className="text-[10px] font-bold text-slate-500">Sept 2026</span>
          </div>

          <div className="mt-2.5 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Total Monthly Sales:</span>
              <span className="font-mono font-bold text-slate-900">
                BDT {overallStats.mtdSales.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Total Monthly Collections:</span>
              <span className="font-mono font-bold text-emerald-700">
                BDT {overallStats.mtdCollection.toLocaleString()}
              </span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-1.5">
              <div 
                className="bg-indigo-600 h-full rounded-full transition-all"
                style={{ 
                  width: `${Math.min(100, overallStats.mtdSales > 0 ? (overallStats.mtdCollection / overallStats.mtdSales) * 100 : 0)}%` 
                }}
              />
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-500">
            <span>Recovery Rate:</span>
            <span className="font-bold text-indigo-700 font-mono">
              {overallStats.mtdSales > 0 ? ((overallStats.mtdCollection / overallStats.mtdSales) * 100).toFixed(1) : 0}%
            </span>
          </div>
        </div>

        {/* 4. Total Market Receivables / Balance */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100 flex items-center gap-1">
              <Landmark className="w-3.5 h-3.5 text-rose-600" />
              Total Receivables
            </span>
            <span className="text-[10px] font-bold text-slate-500">{customers.length} Customers</span>
          </div>

          <div className="mt-2.5">
            <div className="text-2xl font-black font-mono text-rose-700 tracking-tight">
              BDT {overallStats.totalReceivables.toLocaleString()}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
              <span className="text-rose-600 font-semibold text-[11px] flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                Overdue: BDT {overallStats.overdueAmount.toLocaleString()}
              </span>
              <span className="text-emerald-700 font-medium text-[11px]">
                Advances: BDT {overallStats.totalAdvances.toLocaleString()}
              </span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100">
            <button
              onClick={() => onNavigateTab('balance_report')}
              className="text-xs font-semibold text-rose-700 hover:text-rose-800 flex items-center gap-1 hover:underline"
            >
              View Balance Report →
            </button>
            <button
              onClick={() => onNavigateTab('aging')}
              className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1 hover:underline"
            >
              Aging Analysis →
            </button>
          </div>
        </div>
      </div>

      {/* Quick Transport & Truck Measurement Shortcut Card */}
      <div className="bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 border border-amber-200/90 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold shadow-xs shrink-0">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-amber-950">
                Truck & Stone Measurement Report
              </h4>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900">
                CFT Formula
              </span>
            </div>
          </div>
        </div>
        <button
          onClick={() => onNavigateTab('truck_report')}
          className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-all shrink-0 cursor-pointer"
        >
          <span>View Truck Measurements</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Side-by-Side Today's Operations: Today's Invoices vs Today's Payments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Today's Sales Invoices */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                <Receipt className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Today's Sales Invoices
                </h3>
                <span className="text-[11px] text-slate-500 font-mono">Date: {selectedDate}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded font-bold text-xs">
                {todayInvoices.length} Invoices
              </span>
              <button
                onClick={() => onNavigateTab('invoices')}
                className="text-xs text-blue-700 hover:underline font-semibold ml-1"
              >
                View All →
              </button>
            </div>
          </div>

          <div className="divide-y divide-slate-100 max-h-[360px] overflow-y-auto">
            {todayInvoices.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                <Receipt className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <p className="font-semibold text-xs text-slate-600">No sales invoices recorded for this date</p>
                <button
                  onClick={onOpenNewInvoiceModal}
                  className="mt-2.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1 shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Create Sales Invoice
                </button>
              </div>
            ) : (
              todayInvoices.map((inv) => (
                <div 
                  key={inv.id} 
                  className="p-3.5 hover:bg-blue-50/30 transition-colors flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-blue-700 text-xs">
                        {inv.invoiceNumber}
                      </span>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        inv.status === 'Paid' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : inv.status === 'Partially Paid' 
                          ? 'bg-amber-100 text-amber-800' 
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {inv.status}
                      </span>
                    </div>
                    <div className="font-semibold text-slate-800 text-xs mt-0.5 truncate">
                      {inv.customerName}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                      {inv.items.map(i => `${i.itemName} (${i.quantity})`).join(', ')}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-mono font-bold text-slate-900 text-xs">
                      BDT {inv.totalAmount.toLocaleString()}
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      {inv.paidAmount > 0 && (
                        <span className="text-emerald-600 font-semibold">Paid: BDT {inv.paidAmount.toLocaleString()}</span>
                      )}
                      {inv.dueAmount > 0 && (
                        <span className="text-rose-600 font-semibold ml-1">Due: BDT {inv.dueAmount.toLocaleString()}</span>
                      )}
                    </div>
                    {onViewInvoice && (
                      <button
                        onClick={() => onViewInvoice(inv)}
                        className="text-[10px] font-semibold text-blue-600 hover:text-blue-800 hover:underline mt-1 inline-flex items-center gap-0.5"
                      >
                        <Printer className="w-2.5 h-2.5" /> Print Invoice
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs font-semibold text-slate-700">
            <span>Today's Total Sales:</span>
            <span className="font-mono font-bold text-blue-700">
              BDT {todayStats.totalSales.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Right: Today's Customer Payments */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                <CreditCard className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Today's Collections & Money Receipts
                </h3>
                <span className="text-[11px] text-slate-500 font-mono">Date: {selectedDate}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-bold text-xs">
                {todayPayments.length} Receipts
              </span>
              <button
                onClick={() => onNavigateTab('payments')}
                className="text-xs text-emerald-700 hover:underline font-semibold ml-1"
              >
                View All →
              </button>
            </div>
          </div>

          <div className="divide-y divide-slate-100 max-h-[360px] overflow-y-auto">
            {todayPayments.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                <CreditCard className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <p className="font-semibold text-xs text-slate-600">No payment receipts recorded for this date</p>
                <button
                  onClick={onOpenCollectPaymentModal}
                  className="mt-2.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1 shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Record New Payment
                </button>
              </div>
            ) : (
              todayPayments.map((pay) => (
                <div 
                  key={pay.id} 
                  className="p-3.5 hover:bg-emerald-50/30 transition-colors flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-emerald-700 text-xs">
                        {pay.receiptNumber}
                      </span>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        pay.paymentMethod === 'Bank Transfer' 
                          ? 'bg-indigo-100 text-indigo-800' 
                          : pay.paymentMethod === 'Cheque'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-teal-100 text-teal-800'
                      }`}>
                        {pay.paymentMethod}
                      </span>
                    </div>
                    <div className="font-semibold text-slate-800 text-xs mt-0.5 truncate">
                      {pay.customerTradeName || pay.customerName}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono mt-0.5 truncate">
                      {pay.bankName ? `${pay.bankName} (${pay.refNumber || pay.chequeNo || 'Deposit'})` : pay.note || 'Direct Payment'}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-mono font-bold text-emerald-700 text-xs">
                      BDT {pay.amount.toLocaleString()}
                    </div>
                    <span className="text-[10px] text-emerald-600 font-sans font-medium block mt-0.5">
                      ✓ Cleared
                    </span>
                    <button
                      onClick={() => onNavigateTab('payments')}
                      className="text-[10px] font-semibold text-emerald-700 hover:text-emerald-900 hover:underline mt-1 inline-flex items-center gap-0.5"
                    >
                      <Printer className="w-2.5 h-2.5" /> Money Receipt
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs font-semibold text-slate-700">
            <span>Today's Total Collections:</span>
            <span className="font-mono font-bold text-emerald-700">
              BDT {todayStats.totalCollection.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Sub-Category Navigation Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Sales & Distribution Modules
            </h2>
            <span className="text-xs text-slate-500 font-mono">(Click card to navigate directly)</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Card 1: Sales Invoices */}
          <div 
            onClick={() => onNavigateTab('invoices')}
            className="bg-white border border-slate-200 hover:border-blue-500 rounded-xl p-4 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors flex items-center justify-center">
                <Receipt className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                {invoices.length} Bills
              </span>
            </div>
            <h3 className="text-xs font-bold text-slate-900 mt-2.5 group-hover:text-blue-600 transition-colors">
              Sales Invoices
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
              Direct cash and credit sales invoices, commercial VAT challans, and printable views.
            </p>
          </div>

          {/* Card 2: Customer Payments */}
          <div 
            onClick={() => onNavigateTab('payments')}
            className="bg-white border border-slate-200 hover:border-emerald-500 rounded-xl p-4 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors flex items-center justify-center">
                <CreditCard className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                {payments.length} Receipts
              </span>
            </div>
            <h3 className="text-xs font-bold text-slate-900 mt-2.5 group-hover:text-emerald-600 transition-colors">
              Customer Payments
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
              Customer cheques, bank transfers, cash collections register, and money receipt printing.
            </p>
          </div>

          {/* Card 3: Customer Balance Report */}
          <div 
            onClick={() => onNavigateTab('balance_report')}
            className="bg-white border border-slate-200 hover:border-indigo-500 rounded-xl p-4 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors flex items-center justify-center">
                <Landmark className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                BDT {(overallStats.totalReceivables / 1000000).toFixed(1)}M
              </span>
            </div>
            <h3 className="text-xs font-bold text-slate-900 mt-2.5 group-hover:text-indigo-600 transition-colors">
              Customer Balance Report
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
              Comprehensive report of total receivables, dues, advances, and net ledger balances.
            </p>
          </div>

          {/* Card 4: Customer Statement */}
          <div 
            onClick={() => onNavigateTab('statement')}
            className="bg-white border border-slate-200 hover:border-blue-500 rounded-xl p-4 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                Statement
              </span>
            </div>
            <h3 className="text-xs font-bold text-slate-900 mt-2.5 group-hover:text-blue-600 transition-colors">
              Customer Statements
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
              Date-wise debit, credit, running balance accounts, and formal statement printing.
            </p>
          </div>

          {/* Card 6: Auto Delivery & Invoices */}
          <div 
            onClick={() => onNavigateTab('invoices')}
            className="bg-white border border-slate-200 hover:border-teal-500 rounded-xl p-4 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-600 group-hover:bg-teal-600 group-hover:text-white transition-colors flex items-center justify-center">
                <Truck className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-teal-600 bg-teal-50 px-2 py-0.5 rounded">
                Auto Delivery
              </span>
            </div>
            <h3 className="text-xs font-bold text-slate-900 mt-2.5 group-hover:text-teal-600 transition-colors">
              Auto Dispatch Invoices
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
              Every sales invoice automatically dispatches goods with truck measurement and driver records.
            </p>
          </div>

          {/* Card 7: Receivable Aging Report */}
          <div 
            onClick={() => onNavigateTab('aging')}
            className="bg-white border border-slate-200 hover:border-amber-500 rounded-xl p-4 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition-colors flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">
                Aging Buckets
              </span>
            </div>
            <h3 className="text-xs font-bold text-slate-900 mt-2.5 group-hover:text-amber-600 transition-colors">
              Receivable Aging Report
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
              Due balance age analysis: 30 days, 60 days, 90+ days, and recovery alerts.
            </p>
          </div>

          {/* Card 8: Profitability Analysis */}
          <div 
            onClick={() => onNavigateTab('profitability')}
            className="bg-white border border-slate-200 hover:border-emerald-500 rounded-xl p-4 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors flex items-center justify-center">
                <BarChart2 className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                Margin %
              </span>
            </div>
            <h3 className="text-xs font-bold text-slate-900 mt-2.5 group-hover:text-emerald-600 transition-colors">
              Gross Profitability
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
              Item-level gross profit margin, landed cost comparison, and net profitability analysis.
            </p>
          </div>
        </div>
      </div>

      {/* Top 5 Market Receivable Accounts */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/60">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Top Receivables Accounts
            </h3>
          </div>
          <button
            onClick={() => onNavigateTab('balance_report')}
            className="text-xs font-semibold text-indigo-700 hover:text-indigo-800 hover:underline"
          >
            View Full Balance Report →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3.5">Customer / Company</th>
                <th className="py-2.5 px-3">Location / City</th>
                <th className="py-2.5 px-3 text-center">Payment Terms</th>
                <th className="py-2.5 px-3.5 text-right">Current Due Balance</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {topReceivableCustomers.map((cust) => {
                return (
                  <tr key={cust.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3.5">
                      <span className="font-semibold text-slate-900 block">{cust.tradeName || cust.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{cust.code} • {cust.name}</span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {cust.city || 'Chittagong'}
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono">
                      <span className="px-2 py-0.5 bg-slate-100 rounded text-[11px]">
                        {cust.creditDays} Days
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5 text-right font-mono">
                      <span className="font-bold text-rose-700 text-sm">
                        BDT {cust.currentBalance.toLocaleString()}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        cust.status === 'Active' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {cust.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onOpenCollectPaymentModal()}
                          className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded text-[11px] font-semibold transition-colors"
                        >
                          Collect
                        </button>
                        {onViewCustomerStatement && (
                          <button
                            onClick={() => onViewCustomerStatement(cust.id)}
                            className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded text-[11px] font-semibold transition-colors"
                          >
                            Statement
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
