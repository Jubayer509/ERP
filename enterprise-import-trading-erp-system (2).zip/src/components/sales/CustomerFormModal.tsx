import React, { useState, useEffect } from 'react';
import { 
  User, 
  Building2, 
  MapPin, 
  Calculator, 
  Check, 
  X, 
  Monitor, 
  Smartphone, 
  Columns2, 
  Minus, 
  Square, 
  FilePlus2, 
  Save, 
  RefreshCw, 
  FileSpreadsheet, 
  Building, 
  RotateCcw,
  BadgeCheck,
  ChevronLeft,
  Wifi,
  BatteryMedium,
  WalletCards,
  AlertCircle
} from 'lucide-react';
import { Customer } from '../../types/erp';
import { ModalWrapper } from '../common/ModalWrapper';

export interface CustomerFormModalProps {
  isOpen: boolean;
  customerToEdit?: Customer | null;
  onClose: () => void;
  onSave: (customer: Customer) => void;
}

export const CustomerFormModal: React.FC<CustomerFormModalProps> = ({
  isOpen,
  customerToEdit,
  onClose,
  onSave
}) => {
  const [viewMode, setViewMode] = useState<'windows' | 'mobile' | 'sidebyside'>('windows');

  // Unified Form State matching user provided code
  const [customerName, setCustomerName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [mobile, setMobile] = useState('');
  const [address, setAddress] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('');
  const [customTermsDays, setCustomTermsDays] = useState('');
  const [openingBalance, setOpeningBalance] = useState<string>('');
  const [balanceType, setBalanceType] = useState<'DR' | 'CR'>('DR');
  const [isActive, setIsActive] = useState(true);

  // Validation errors
  const [nameError, setNameError] = useState(false);
  const [mobileError, setMobileError] = useState(false);

  // Toast notification
  const [toast, setToast] = useState<{ title: string; message: string } | null>(null);

  const resetAllFields = () => {
    setCustomerName('');
    setCompanyName('');
    setMobile('');
    setAddress('');
    setPaymentTerms('');
    setCustomTermsDays('');
    setOpeningBalance('');
    setBalanceType('DR');
    setIsActive(true);
    setNameError(false);
    setMobileError(false);
  };

  const isDirty = customerToEdit
    ? Boolean(
        customerName !== (customerToEdit.name || customerToEdit.tradeName || '') ||
        address !== (customerToEdit.address || '')
      )
    : Boolean(
        customerName.trim() ||
        companyName.trim() ||
        mobile.trim() ||
        address.trim() ||
        (openingBalance !== '' && Number(openingBalance) > 0)
      );

  const handleCloseModal = () => {
    resetAllFields();
    onClose();
  };

  // Populate when editing
  useEffect(() => {
    if (customerToEdit) {
      setCustomerName(customerToEdit.name || customerToEdit.tradeName || '');
      setCompanyName(customerToEdit.companyName || (customerToEdit.tradeName !== customerToEdit.name ? customerToEdit.tradeName : ''));
      
      const rawMobile = customerToEdit.mobile || customerToEdit.phone || '';
      const cleanMobile = rawMobile.replace(/^\+880\s?/, '').replace(/[^0-9]/g, '');
      setMobile(cleanMobile);

      setAddress(customerToEdit.address || '');
      
      const terms = customerToEdit.paymentTerms || (customerToEdit.creditDays ? `Net ${customerToEdit.creditDays} Days` : 'Net 30 Days');
      if (['Cash / COD', 'Net 7 Days', 'Net 15 Days', 'Net 30 Days', 'Net 60 Days'].includes(terms)) {
        setPaymentTerms(terms);
        setCustomTermsDays('');
      } else if (terms.includes('Custom') || terms.includes('Days')) {
        setPaymentTerms('Custom');
        const match = terms.match(/\d+/);
        setCustomTermsDays(match ? match[0] : (String(customerToEdit.creditDays || '')));
      } else {
        setPaymentTerms('Net 30 Days');
      }

      const bal = customerToEdit.openingBalance !== undefined 
        ? customerToEdit.openingBalance 
        : Math.abs(customerToEdit.currentBalance || 0);
      setOpeningBalance(bal > 0 ? String(bal) : '');
      
      const bType = customerToEdit.balanceType || ((customerToEdit.currentBalance || 0) < 0 ? 'CR' : 'DR');
      setBalanceType(bType);

      setIsActive(customerToEdit.status === 'Active' || customerToEdit.isActive !== false);
    } else {
      resetAllFields();
    }
  }, [customerToEdit, isOpen]);

  const handleMobileChange = (val: string) => {
    const cleaned = val.trim();
    setMobile(cleaned);

    if (cleaned.length > 0) {
      const digits = cleaned.replace(/\D/g, '');
      const isValid = (digits.length >= 10 && digits.length <= 11);
      setMobileError(!isValid);
    } else {
      setMobileError(false);
    }
  };

  const showToast = (title: string, msg: string) => {
    setToast({ title, message: msg });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const trimmedName = customerName.trim();
    if (!trimmedName) {
      setNameError(true);
      return;
    }
    setNameError(false);

    if (mobile.trim().length > 0) {
      const digits = mobile.replace(/\D/g, '');
      if (digits.length < 10 || digits.length > 11) {
        setMobileError(true);
        return;
      }
    }

    const numBal = parseFloat(openingBalance) || 0;
    const formattedBalance = openingBalance ? `৳ ${numBal.toFixed(2)}` : '৳ 0.00';

    let resolvedCreditDays = 30;
    let resolvedTermsLabel = paymentTerms;

    if (paymentTerms === 'Cash / COD') {
      resolvedCreditDays = 0;
    } else if (paymentTerms === 'Net 7 Days') {
      resolvedCreditDays = 7;
    } else if (paymentTerms === 'Net 15 Days') {
      resolvedCreditDays = 15;
    } else if (paymentTerms === 'Net 30 Days') {
      resolvedCreditDays = 30;
    } else if (paymentTerms === 'Net 60 Days') {
      resolvedCreditDays = 60;
    } else if (paymentTerms === 'Custom') {
      const days = parseInt(customTermsDays, 10) || 30;
      resolvedCreditDays = days;
      resolvedTermsLabel = `Net ${days} Days (Custom)`;
    }

    const formattedMobile = mobile.trim() ? `+880 ${mobile.trim().replace(/^0+/, '')}` : '';

    const updatedCustomer: Customer = {
      id: customerToEdit ? customerToEdit.id : `cust-${Date.now()}`,
      code: customerToEdit ? customerToEdit.code : `CUST-${Math.floor(100 + Math.random() * 900)}`,
      name: trimmedName,
      tradeName: companyName.trim() || trimmedName,
      companyName: companyName.trim(),
      contactPerson: trimmedName,
      email: customerToEdit?.email || `${trimmedName.toLowerCase().replace(/[^a-z0-9]/g, '')}@gmail.com`,
      phone: formattedMobile || customerToEdit?.phone || '',
      mobile: mobile.trim(),
      address: address.trim() || 'Dhaka, Bangladesh',
      city: customerToEdit?.city || 'Dhaka',
      creditDays: resolvedCreditDays,
      paymentTerms: resolvedTermsLabel,
      openingBalance: numBal,
      balanceType: balanceType,
      currentBalance: balanceType === 'DR' ? numBal : -numBal,
      advanceBalance: balanceType === 'CR' ? numBal : 0,
      status: isActive ? 'Active' : 'Inactive',
      isActive: isActive
    };

    if (paymentTerms === 'Custom' && customTermsDays) {
      updatedCustomer.customTermsDays = customTermsDays;
    }

    onSave(updatedCustomer);
    showToast(
      customerToEdit ? 'Customer Updated Successfully' : 'Customer Saved Successfully',
      `Record for "${trimmedName}" saved with BDT (${balanceType}) balance.`
    );

    setTimeout(() => {
      onClose();
    }, 400);
  };

  // Preview computations
  const dispName = customerName.trim() || 'Tanvir Ahmed';
  const dispCompany = companyName.trim() || 'Optional Company';
  const dispAddress = address.trim() || 'Not provided';
  const dispTerms = paymentTerms === 'Custom' 
    ? (customTermsDays ? `Net ${customTermsDays} Days (Custom)` : 'Custom Days')
    : paymentTerms;
  const numBal = parseFloat(openingBalance);
  const dispBdtAmount = isNaN(numBal)
    ? '৳ 0.00'
    : '৳ ' + numBal.toLocaleString('en-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const initials = (customerName.trim() || 'C')
    .split(' ')
    .map(n => n[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase();

  if (!isOpen) return null;

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleCloseModal}
      isDirty={isDirty}
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto"
    >
      <div className="w-full max-w-6xl my-auto flex flex-col items-center">
        
        {/* TOP VIEWPORT SWITCHER TOOLBAR */}
        <header className="w-full mb-3 flex flex-wrap items-center justify-between gap-3 bg-slate-800/90 border border-slate-700/80 px-4 py-2.5 rounded-2xl shadow-xl backdrop-blur-md text-white">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h1 className="text-xs font-semibold text-white tracking-wide flex items-center gap-2">
                {customerToEdit ? 'Edit Customer Profile' : 'Customer Ledger ERP'}
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  BDT (৳) Edition
                </span>
              </h1>
              <p className="text-[11px] text-slate-400">Bangladesh Ledger Accounting & Customer Intake</p>
            </div>
          </div>

          {/* Mode Selector Controls */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 p-1.5 rounded-xl border border-slate-700">
            <button 
              type="button" 
              onClick={() => setViewMode('windows')} 
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                viewMode === 'windows' ? 'text-white bg-blue-600 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Windows View</span>
            </button>
            <button 
              type="button" 
              onClick={() => setViewMode('mobile')} 
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                viewMode === 'mobile' ? 'text-white bg-blue-600 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile View</span>
            </button>
            <button 
              type="button" 
              onClick={() => setViewMode('sidebyside')} 
              className={`hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                viewMode === 'sidebyside' ? 'text-white bg-blue-600 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Columns2 className="w-3.5 h-3.5" />
              <span>Side by Side</span>
            </button>
            <button
              type="button"
              data-modal-close="true"
              onClick={handleCloseModal}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-rose-600 transition-colors ml-1 shrink-0 cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* MAIN CONTAINER */}
        <div className={`w-full transition-all duration-300 ${
          viewMode === 'sidebyside' ? 'grid grid-cols-1 lg:grid-cols-12 gap-6 items-start' : 'flex justify-center'
        }`}>

          {/* ======================================================== */}
          {/* WINDOWS 11 FLUENT DESKTOP VIEWPORT                       */}
          {/* ======================================================== */}
          {(viewMode === 'windows' || viewMode === 'sidebyside') && (
            <div className={`transition-all duration-300 ${
              viewMode === 'sidebyside' ? 'lg:col-span-7 w-full' : 'w-full'
            }`}>
              <div className="bg-slate-100 rounded-xl overflow-hidden border border-slate-600/50 shadow-2xl shadow-black/60 flex flex-col">
                
                {/* Windows 11 Title Bar */}
                <div className="bg-slate-200/90 border-b border-slate-300/80 px-3.5 py-1.5 flex items-center justify-between select-none">
                  <div className="flex items-center gap-2.5">
                    <div className="grid grid-cols-2 gap-0.5 w-3.5 h-3.5">
                      <span className="bg-blue-600 rounded-xs"></span>
                      <span className="bg-blue-600 rounded-xs"></span>
                      <span className="bg-blue-600 rounded-xs"></span>
                      <span className="bg-blue-600 rounded-xs"></span>
                    </div>
                    <span className="text-xs font-medium text-slate-700">
                      Accounts & Ledger ERP - [{customerToEdit ? `Edit Profile - ${customerToEdit.code}` : 'Add Customer Entry - Bangladesh Hub'}]
                    </span>
                  </div>

                  {/* Window Controls */}
                  <div className="flex items-center">
                    <button type="button" className="w-8 h-6 hover:bg-slate-300/70 flex items-center justify-center text-slate-600 rounded text-xs transition">
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <button type="button" className="w-8 h-6 hover:bg-slate-300/70 flex items-center justify-center text-slate-600 rounded text-xs transition">
                      <Square className="w-3 h-3" />
                    </button>
                    <button 
                      type="button" 
                      data-modal-close="true"
                      onClick={handleCloseModal}
                      className="w-8 h-6 hover:bg-rose-600 hover:text-white flex items-center justify-center text-slate-600 rounded text-xs transition cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Ribbon Menu */}
                <div className="bg-white border-b border-slate-200 px-4 py-2 flex items-center justify-between text-xs text-slate-600">
                  <div className="flex items-center gap-4">
                    <span onClick={resetAllFields} className="font-semibold text-blue-700 flex items-center gap-1.5 cursor-pointer hover:underline">
                      <FilePlus2 className="w-4 h-4" /> {customerToEdit ? 'Reset to Blank' : 'New Customer'}
                    </span>
                    <span onClick={() => handleSubmit()} className="hover:text-slate-900 cursor-pointer flex items-center gap-1">
                      <Save className="w-3.5 h-3.5" /> Post Record (Ctrl+S)
                    </span>
                    <span onClick={resetAllFields} className="hover:text-slate-900 cursor-pointer flex items-center gap-1">
                      <RefreshCw className="w-3.5 h-3.5" /> Reset Form
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      Currency: BDT (৳)
                    </span>
                  </div>
                </div>

                {/* Main Content Area */}
                <div className="p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-5 bg-slate-50/70 max-h-[75vh] overflow-y-auto">
                  
                  {/* Left Column: Form */}
                  <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
                    <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                      <div>
                        <h2 className="text-sm font-bold text-slate-800">Customer Identification & Ledger Setup</h2>
                        <p className="text-[11px] text-slate-500">Provide the client details and configure credit terms.</p>
                      </div>
                      <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded">Form Mode: WinUI 3</span>
                    </div>

                    <form onSubmit={handleSubmit} autoComplete="off" className="space-y-3.5 text-xs">
                      {/* Customer Name */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="font-semibold text-slate-700">Customer Name <span className="text-rose-500 font-bold">*</span></label>
                          <span className="text-[10px] text-slate-400">Primary Account Holder</span>
                        </div>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <User className="w-4 h-4" />
                          </div>
                          <input 
                            type="text" 
                            required
                            value={customerName}
                            onChange={(e) => { setCustomerName(e.target.value); setNameError(false); }}
                            placeholder="e.g. Tanvir Ahmed Chowdhury" 
                            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition bg-white"
                          />
                        </div>
                        {nameError && (
                          <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" /> Customer name is required.
                          </p>
                        )}
                      </div>

                      {/* Company Name (Optional) */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="font-semibold text-slate-700">Company Name</label>
                          <span className="text-[10px] font-medium text-slate-500 px-1.5 py-0.2 bg-slate-100 rounded">Optional</span>
                        </div>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <Building2 className="w-4 h-4" />
                          </div>
                          <input 
                            type="text" 
                            value={companyName}
                            onChange={(e) => setCompanyName(e.target.value)}
                            placeholder="e.g. Bengal Traders & Export Ltd." 
                            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition bg-white"
                          />
                        </div>
                      </div>

                      {/* Mobile Number (Optional, fixed +880) */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="font-semibold text-slate-700">Mobile Number</label>
                          <span className="text-[10px] font-medium text-slate-500 px-1.5 py-0.2 bg-slate-100 rounded">Optional</span>
                        </div>
                        <div className="flex rounded-lg border border-slate-200 overflow-hidden focus-within:ring-2 focus-within:ring-blue-600 focus-within:border-transparent bg-white">
                          <div className="bg-slate-100 px-3 py-2 border-r border-slate-200 flex items-center gap-1.5 text-xs text-slate-700 shrink-0 select-none">
                            <span className="text-sm">🇧🇩</span>
                            <span className="font-bold text-slate-800">+880</span>
                          </div>
                          <input 
                            type="tel" 
                            value={mobile}
                            onChange={(e) => handleMobileChange(e.target.value)}
                            placeholder="017XXXXXXXX / 019XXXXXXXX" 
                            className="w-full px-3 py-2 text-xs focus:outline-none bg-white font-mono"
                          />
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">Leave empty or enter a valid 11-digit Bangladeshi mobile number.</p>
                        {mobileError && (
                          <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" /> Please enter a valid Bangladeshi mobile number (11 digits, e.g. 01712345678).
                          </p>
                        )}
                      </div>

                      {/* Address */}
                      <div>
                        <label className="font-semibold text-slate-700 block mb-1">Address</label>
                        <div className="relative">
                          <textarea 
                            rows={2} 
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                            placeholder="Holding No, Road, Motijheel C/A, Dhaka-1000..." 
                            className="w-full p-2.5 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent resize-none bg-white"
                          ></textarea>
                          <div className="absolute bottom-2 right-2 text-slate-300 pointer-events-none">
                            <MapPin className="w-3.5 h-3.5" />
                          </div>
                        </div>
                      </div>

                      {/* Payment Terms & Ledger Section */}
                      <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200/80 space-y-3">
                        <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                            <Calculator className="w-3.5 h-3.5 text-blue-600" /> Payment Terms & Ledger
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium">Accounting Baseline</span>
                        </div>

                        {/* Credit Payment Terms */}
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Credit Payment Terms</label>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <select 
                              value={paymentTerms}
                              onChange={(e) => setPaymentTerms(e.target.value)}
                              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                            >
                              <option value="">Select Payment Terms...</option>
                              <option value="Cash / COD">Cash / COD (No Credit)</option>
                              <option value="Net 7 Days">Net 7 Days</option>
                              <option value="Net 15 Days">Net 15 Days</option>
                              <option value="Net 30 Days">Net 30 Days (Standard)</option>
                              <option value="Net 60 Days">Net 60 Days</option>
                              <option value="Custom">Custom Days...</option>
                            </select>

                            {paymentTerms === 'Custom' && (
                              <div className="relative">
                                <input 
                                  type="number" 
                                  min="1"
                                  value={customTermsDays}
                                  onChange={(e) => setCustomTermsDays(e.target.value)}
                                  placeholder="e.g. 45" 
                                  className="w-full px-3 py-2 pr-12 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-white"
                                />
                                <span className="absolute right-3 top-2 text-[10px] text-slate-400 font-semibold pointer-events-none">Days</span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Opening Balance in BDT & Dr / Cr Switch */}
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Opening Balance (BDT ৳)</label>
                          <div className="grid grid-cols-12 gap-2">
                            <div className="col-span-7 relative">
                              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none font-bold text-slate-500 text-xs">
                                ৳
                              </div>
                              <input 
                                type="number" 
                                step="0.01"
                                min="0"
                                value={openingBalance}
                                onChange={(e) => setOpeningBalance(e.target.value)}
                                placeholder="0.00" 
                                className="w-full pl-7 pr-3 py-2 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium font-mono"
                              />
                            </div>
                            
                            <div className="col-span-5 flex rounded-lg p-0.5 bg-slate-200 border border-slate-300">
                              <button 
                                type="button" 
                                onClick={() => setBalanceType('DR')}
                                className={`flex-1 py-1 text-[11px] font-bold rounded transition ${
                                  balanceType === 'DR' 
                                    ? 'text-slate-800 bg-white shadow-xs' 
                                    : 'text-slate-500 hover:text-slate-800'
                                }`}
                              >
                                Debit (Dr)
                              </button>
                              <button 
                                type="button" 
                                onClick={() => setBalanceType('CR')}
                                className={`flex-1 py-1 text-[11px] font-bold rounded transition ${
                                  balanceType === 'CR' 
                                    ? 'text-slate-800 bg-white shadow-xs' 
                                    : 'text-slate-500 hover:text-slate-800'
                                }`}
                              >
                                Credit (Cr)
                              </button>
                            </div>
                          </div>
                          <p className="text-[10px] text-slate-400 mt-1">Debit (Dr) = Customer owes BDT. Credit (Cr) = Advance deposit.</p>
                        </div>

                        {/* Active / Deactive Switch */}
                        <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                          <div>
                            <span className="text-xs font-semibold text-slate-800">Status</span>
                            <p className="text-[10px] text-slate-400">
                              {isActive ? 'Customer can receive invoices & sales orders' : 'Customer is disabled for billing'}
                            </p>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={isActive}
                              onChange={(e) => setIsActive(e.target.checked)}
                              className="sr-only peer" 
                            />
                            <div className="w-10 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                            <span className={`ml-2 text-xs font-bold min-w-[55px] ${isActive ? 'text-emerald-700' : 'text-slate-400'}`}>
                              {isActive ? 'Active' : 'Deactive'}
                            </span>
                          </label>
                        </div>
                      </div>

                      {/* Desktop Bottom Actions */}
                      <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                        <button 
                          type="button" 
                          data-modal-close="true"
                          onClick={handleCloseModal}
                          className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-100 transition cursor-pointer"
                        >
                          Discard Changes
                        </button>
                        <button 
                          type="submit" 
                          className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>{customerToEdit ? 'Update Customer Profile' : 'Post Customer Record'}</span>
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* Right Column: Live Ledger Inspector */}
                  <div className="lg:col-span-5 flex flex-col gap-4">
                    
                    {/* Ledger Account Preview Card */}
                    <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5 rounded-xl border border-slate-700 shadow-md">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-700/80 mb-4">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
                          <FileSpreadsheet className="w-3.5 h-3.5" />
                          Customer Ledger Preview
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isActive 
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                            : 'bg-slate-600/40 text-slate-400 border border-slate-600'
                        }`}>
                          {isActive ? 'ACTIVE' : 'DEACTIVE'}
                        </span>
                      </div>

                      {/* Customer Tag */}
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-11 h-11 rounded-lg bg-blue-600 border border-blue-400/40 flex items-center justify-center font-bold text-base text-white shrink-0">
                          {initials}
                        </div>
                        <div className="min-w-0">
                          <h3 className="text-sm font-bold text-white truncate">{dispName}</h3>
                          <p className="text-xs text-slate-400 truncate flex items-center gap-1 mt-0.5">
                            <Building className="w-3 h-3 text-slate-400 shrink-0" />
                            <span className="truncate">{dispCompany}</span>
                          </p>
                        </div>
                      </div>

                      {/* Specs Box */}
                      <div className="bg-slate-800/80 rounded-lg p-3 text-xs space-y-2 border border-slate-700/60 mb-4">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Mobile (BD):</span>
                          <span className="font-medium text-slate-200 font-mono">
                            {mobile.trim() ? `+880 ${mobile.trim()}` : 'Not provided'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Payment Terms:</span>
                          <span className="font-medium text-slate-200">{dispTerms}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Address:</span>
                          <span className="font-medium text-slate-200 truncate max-w-[170px]">{dispAddress}</span>
                        </div>
                      </div>

                      {/* Balance Display in BDT */}
                      <div className="bg-blue-950/60 border border-blue-500/30 rounded-lg p-3 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Opening Balance</span>
                          <div className="flex items-baseline gap-1 mt-0.5 font-mono">
                            <span className="text-lg font-bold text-white tracking-tight">{dispBdtAmount}</span>
                            <span className="text-xs font-bold text-blue-300">{balanceType}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                            balanceType === 'DR'
                              ? 'bg-blue-500/20 text-blue-200 border-blue-400/20'
                              : 'bg-amber-500/20 text-amber-200 border-amber-400/20'
                          }`}>
                            {balanceType === 'DR' ? 'Accounts Receivable' : 'Advance / Payable Deposit'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Windows ERP Quick Actions */}
                    <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs text-xs space-y-3">
                      <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">Bangladeshi Financial Defaults</span>
                      <div className="space-y-2 text-slate-500">
                        <p className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          Prefix locked to <strong>+880</strong> (BTRC Standard).
                        </p>
                        <p className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          Currency calculated in <strong>Bangladeshi Taka (৳ BDT)</strong>.
                        </p>
                        <p className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          Real-time sync to Windows Accounting and Mobile Apps.
                        </p>
                      </div>
                    </div>

                  </div>

                </div>

                {/* Windows Status Bar Footer */}
                <div className="bg-slate-200/90 border-t border-slate-300/80 px-4 py-1 flex items-center justify-between text-[11px] text-slate-600">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1 text-emerald-700 font-medium">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span> Connected: Dhaka Main Ledger
                    </span>
                    <span>UTF-8</span>
                  </div>
                  <div>
                    <span>ERP Client v4.8 (x64)</span>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* MOBILE SMARTPHONE VIEWPORT                               */}
          {/* ======================================================== */}
          {(viewMode === 'mobile' || viewMode === 'sidebyside') && (
            <div className={`transition-all duration-300 flex justify-center ${
              viewMode === 'sidebyside' ? 'lg:col-span-5 w-full' : 'w-full max-w-sm'
            }`}>
              <div className="w-[360px] bg-slate-900 p-3 rounded-[40px] shadow-2xl border-4 border-slate-700 relative">
                
                {/* Phone Screen */}
                <div className="w-full bg-slate-50 rounded-[32px] overflow-hidden flex flex-col h-[650px] relative">
                  
                  {/* Status Bar */}
                  <div className="bg-white px-5 pt-2.5 pb-2 flex items-center justify-between text-xs text-slate-800 shrink-0">
                    <span className="font-semibold text-[11px]">9:41</span>
                    <div className="w-16 h-3.5 bg-slate-900 rounded-full mx-auto"></div>
                    <div className="flex items-center gap-1 text-slate-700">
                      <Wifi className="w-3 h-3" />
                      <BatteryMedium className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  {/* Header */}
                  <div className="bg-white border-b border-slate-100 px-4 py-2.5 flex items-center justify-between shrink-0">
                    <div className="flex items-center gap-2">
                      <button 
                        type="button" 
                        data-modal-close="true"
                        onClick={handleCloseModal}
                        className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200 cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <div>
                        <h2 className="text-xs font-bold text-slate-900 leading-tight">
                          {customerToEdit ? 'Edit Customer' : 'Add Customer'}
                        </h2>
                        <p className="text-[9px] text-slate-500">BD Ledger Mobile</p>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-blue-50 text-blue-700">৳ BDT</span>
                  </div>

                  {/* Scrollable Form */}
                  <div className="flex-1 overflow-y-auto p-3.5 space-y-3 custom-scroll text-xs">
                    
                    {/* Name Card */}
                    <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                      <div className="flex justify-between items-center mb-1">
                        <label className="font-semibold text-slate-700">Customer Name <span className="text-rose-500">*</span></label>
                        <span className="text-[9px] text-slate-400">Required</span>
                      </div>
                      <div className="relative">
                        <input 
                          type="text" 
                          required
                          value={customerName}
                          onChange={(e) => { setCustomerName(e.target.value); setNameError(false); }}
                          placeholder="Enter customer name" 
                          className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-slate-50/50"
                        />
                        <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                          <User className="w-3.5 h-3.5" />
                        </div>
                      </div>
                    </div>

                    {/* Company Card */}
                    <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                      <div className="flex justify-between items-center mb-1">
                        <label className="font-semibold text-slate-700">Company</label>
                        <span className="text-[9px] text-slate-400">Optional</span>
                      </div>
                      <div className="relative">
                        <input 
                          type="text" 
                          value={companyName}
                          onChange={(e) => setCompanyName(e.target.value)}
                          placeholder="Company / Business name" 
                          className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-slate-50/50"
                        />
                        <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                          <Building className="w-3.5 h-3.5" />
                        </div>
                      </div>
                    </div>

                    {/* Mobile Card */}
                    <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                      <div className="flex justify-between items-center mb-1">
                        <label className="font-semibold text-slate-700">Mobile Number</label>
                        <span className="text-[9px] text-slate-400">Optional</span>
                      </div>
                      <div className="flex rounded-lg border border-slate-200 overflow-hidden bg-slate-50/50 focus-within:ring-2 focus-within:ring-blue-600">
                        <div className="bg-slate-100 px-2.5 py-1.5 border-r border-slate-200 flex items-center gap-1 text-[11px] text-slate-700 shrink-0 select-none">
                          <span>🇧🇩</span>
                          <span className="font-bold text-slate-800">+880</span>
                        </div>
                        <input 
                          type="tel" 
                          value={mobile}
                          onChange={(e) => handleMobileChange(e.target.value)}
                          placeholder="01XXXXXXXXX" 
                          className="w-full px-2.5 py-1.5 text-xs bg-transparent focus:outline-none font-mono"
                        />
                      </div>
                    </div>

                    {/* Address Card */}
                    <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                      <label className="font-semibold text-slate-700 block mb-1">Address</label>
                      <textarea 
                        rows={2} 
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="Street / Area / District address" 
                        className="w-full p-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-slate-50/50 resize-none"
                      ></textarea>
                    </div>

                    {/* Payment Terms & Ledger Section */}
                    <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs space-y-2.5">
                      <div className="flex items-center gap-1.5 pb-1.5 border-b border-slate-100">
                        <WalletCards className="w-3.5 h-3.5 text-blue-600" />
                        <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wide">Payment Terms & Ledger</span>
                      </div>

                      {/* Terms */}
                      <div>
                        <label className="text-[10px] font-semibold text-slate-700 block mb-1">Credit Payment Terms</label>
                        <select 
                          value={paymentTerms}
                          onChange={(e) => setPaymentTerms(e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50/50 focus:outline-none focus:ring-2 focus:ring-blue-600"
                        >
                          <option value="">Select Payment Terms...</option>
                          <option value="Cash / COD">Cash / COD</option>
                          <option value="Net 7 Days">Net 7 Days</option>
                          <option value="Net 15 Days">Net 15 Days</option>
                          <option value="Net 30 Days">Net 30 Days</option>
                          <option value="Net 60 Days">Net 60 Days</option>
                          <option value="Custom">Custom Days...</option>
                        </select>
                      </div>

                      {/* Opening Balance */}
                      <div>
                        <label className="text-[10px] font-semibold text-slate-700 block mb-1">Opening Balance (BDT ৳)</label>
                        <div className="relative mb-2">
                          <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none font-bold text-slate-500 text-xs">
                            ৳
                          </div>
                          <input 
                            type="number" 
                            step="0.01"
                            min="0"
                            value={openingBalance}
                            onChange={(e) => setOpeningBalance(e.target.value)}
                            placeholder="0.00" 
                            className="w-full pl-6 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50/50 focus:outline-none focus:ring-2 focus:ring-blue-600 font-semibold font-mono"
                          />
                        </div>

                        {/* DR / CR Toggle */}
                        <div className="flex rounded-lg p-0.5 bg-slate-100 border border-slate-200">
                          <button 
                            type="button" 
                            onClick={() => setBalanceType('DR')}
                            className={`flex-1 py-1 text-[11px] font-bold rounded-md transition ${
                              balanceType === 'DR' ? 'text-slate-800 bg-white shadow-2xs' : 'text-slate-500'
                            }`}
                          >
                            Debit (Dr)
                          </button>
                          <button 
                            type="button" 
                            onClick={() => setBalanceType('CR')}
                            className={`flex-1 py-1 text-[11px] font-bold rounded-md transition ${
                              balanceType === 'CR' ? 'text-slate-800 bg-white shadow-2xs' : 'text-slate-500'
                            }`}
                          >
                            Credit (Cr)
                          </button>
                        </div>
                      </div>

                      {/* Status */}
                      <div className="flex items-center justify-between pt-1.5 border-t border-slate-100">
                        <div>
                          <span className="text-xs font-semibold text-slate-800">Status</span>
                          <p className="text-[9px] text-slate-400">Available for billing</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={isActive}
                            onChange={(e) => setIsActive(e.target.checked)}
                            className="sr-only peer" 
                          />
                          <div className="w-9 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-600"></div>
                          <span className={`ml-1.5 text-[11px] font-bold ${isActive ? 'text-emerald-700' : 'text-slate-400'}`}>
                            {isActive ? 'Active' : 'Deactive'}
                          </span>
                        </label>
                      </div>
                    </div>

                    {/* Quick Mini Card */}
                    <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white p-3 rounded-xl shadow-xs text-xs">
                      <div className="flex justify-between items-center mb-0.5">
                        <span className="text-[9px] text-blue-200">Current Ledger Total</span>
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-blue-800/80">
                          {balanceType === 'DR' ? 'Dr (Receivable)' : 'Cr (Advance Deposit)'}
                        </span>
                      </div>
                      <div className="text-sm font-extrabold font-mono">{dispBdtAmount}</div>
                    </div>

                  </div>

                  {/* Fixed Bottom Bar */}
                  <div className="bg-white border-t border-slate-200 p-2.5 flex items-center gap-2 shrink-0">
                    <button 
                      type="button" 
                      onClick={resetAllFields} 
                      className="w-9 h-9 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-slate-200"
                      title="Reset"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <button 
                      type="button" 
                      onClick={() => handleSubmit()} 
                      className="flex-1 py-2 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-md shadow-blue-500/20 flex items-center justify-center gap-1.5 active:scale-95 transition"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{customerToEdit ? 'Update Customer' : 'Save Customer'}</span>
                    </button>
                  </div>

                  {/* Home Indicator */}
                  <div className="bg-white pb-1 pt-0.5 flex justify-center shrink-0">
                    <div className="w-24 h-1 bg-slate-300 rounded-full"></div>
                  </div>

                </div>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-5">
          <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-2xl flex items-center gap-3 border border-slate-700 max-w-sm">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <BadgeCheck className="w-5 h-5" />
            </div>
            <div>
              <h5 className="text-xs font-bold text-white">{toast.title}</h5>
              <p className="text-[11px] text-slate-300">{toast.message}</p>
            </div>
            <button type="button" onClick={() => setToast(null)} className="text-slate-400 hover:text-white ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

    </ModalWrapper>
  );
};
