import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Calendar, 
  CreditCard, 
  Banknote, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  Building2, 
  Check, 
  Printer, 
  FileText,
  DollarSign,
  ArrowRight,
  ShieldCheck,
  ChevronDown,
  Truck,
  Scale,
  Ruler,
  Sparkles,
  AlertTriangle,
  ArrowDown,
  Search,
  Loader2
} from 'lucide-react';
import { Customer, InventoryItem, SalesInvoice, SalesOrder, CustomerPayment, BankAccount, Warehouse } from '../../types/erp';
import { MOCK_ITEMS } from '../../data/mockErpData';
import { getUOMs, addUOM, subscribeUOMs } from '../../utils/uomStorage';
import {
  getItems,
  getActiveItems,
  subscribeItems,
  getAvailableStockForWarehouse,
  validateStockAvailabilityForLines,
  isStockItem,
  resolveWarehouseId
} from '../../utils/itemStorage';
import { getWarehouses, subscribeWarehouses } from '../../utils/locationStorage';
import { getSystemInventorySettings } from '../../utils/systemSettingsStorage';
import { getCustomerAvailableAdvance } from '../../utils/customerStorage';
import { getBankAccounts, subscribeBankAccounts, isCashAccount } from '../../utils/bankAccountStorage';
import { useAuth } from '../../contexts/AuthContext';
import { ModalWrapper } from '../common/ModalWrapper';
import { 
  calculateStoneCft, 
  STONE_INCH_OPTIONS, 
  STONE_DOWN_OPTIONS,
  getStoneInchDecimal,
  calculateEffectiveStoneFeet,
  parseStoneDimensionInput
} from '../../utils/stoneMeasurement';

interface InteractiveInvoiceFormModalProps {
  customers: Customer[];
  items?: InventoryItem[];
  invoicesCount: number;
  ordersCount: number;
  onClose: () => void;
  onSaveInvoice: (newInvoice: SalesInvoice, newOrder: SalesOrder, upfrontPayment?: CustomerPayment, adjustedAdvance?: number) => Promise<boolean | void> | void;
  onSaveAndPrint?: (newInvoice: SalesInvoice, newOrder: SalesOrder, upfrontPayment?: CustomerPayment, adjustedAdvance?: number) => Promise<boolean | void> | void;
  onOpenCustomerModal?: () => void;
  onQuickCreateCustomer?: (newCustomer: Customer) => void;
}

export interface InvoiceItemRow {
  id: string;
  itemId: string;
  itemName: string;
  uom: string;
  quantity: number;
  unitPrice: number;
  amount: number;
}

export type InvoiceTypeOption = 'Cash Only' | 'Due 30 Days' | 'Partial Payment' | 'Payment 10 Days';

export const InteractiveInvoiceFormModal: React.FC<InteractiveInvoiceFormModalProps> = ({
  customers,
  items: propItems,
  invoicesCount,
  ordersCount,
  onClose,
  onSaveInvoice,
  onSaveAndPrint,
  onOpenCustomerModal,
  onQuickCreateCustomer,
}) => {
  // Always ensure only ACTIVE items are available (excludes inactive and deleted items)
  const [liveActiveItems, setLiveActiveItems] = useState<InventoryItem[]>(() => {
    if (propItems && propItems.length > 0) {
      return propItems.filter(i => (i.status || 'Active') === 'Active');
    }
    return getActiveItems();
  });

  useEffect(() => {
    const unsubItems = subscribeItems((all) => {
      setLiveActiveItems(all.filter(i => (i.status || 'Active') === 'Active'));
    });
    return unsubItems;
  }, []);

  const items = liveActiveItems;
  // Current dates
  const todayStr = new Date().toISOString().split('T')[0];
  const defaultDue = new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];

  // Dynamic UOMs and Items from central storage
  const [availableUoms, setAvailableUoms] = useState<string[]>(() => getUOMs());

  useEffect(() => {
    const unsubUoms = subscribeUOMs(setAvailableUoms);
    return () => unsubUoms();
  }, []);

  // Auto Invoice Number
  const autoInvNumber = `INV-2026-00${420 + invoicesCount}`;
  const [invoiceNumber, setInvoiceNumber] = useState(autoInvNumber);
  const [invoiceDate, setInvoiceDate] = useState(todayStr);
  const [dueDate, setDueDate] = useState('');

  // Transport & Vehicle Measurement Details
  const [truckNo, setTruckNo] = useState<string>('');
  const [driverName, setDriverName] = useState<string>('');
  const [driverPhone, setDriverPhone] = useState<string>('');
  
  // Feet and Inches dimensions
  const [measDownInches, setMeasDownInches] = useState<number>(0);
  const [measLengthFt, setMeasLengthFt] = useState<number | ''>('');
  const [measLengthIn, setMeasLengthIn] = useState<number | ''>('');
  const [measWidthFt, setMeasWidthFt] = useState<number | ''>('');
  const [measWidthIn, setMeasWidthIn] = useState<number | ''>('');
  const [measHeightFt, setMeasHeightFt] = useState<number | ''>('');
  const [measHeightIn, setMeasHeightIn] = useState<number | ''>('');
  const [manualCft, setManualCft] = useState<number | ''>(''); // manual CFT override

  // Calculate using Bangladesh Stone formula with Down option support
  const stoneCalcResult = calculateStoneCft(
    Number(measLengthFt) || 0,
    Number(measLengthIn) || 0,
    Number(measWidthFt) || 0,
    Number(measWidthIn) || 0,
    Number(measHeightFt) || 0,
    Number(measHeightIn) || 0,
    measDownInches
  );

  // Effective CFT for billing: manual override if typed, otherwise billed rounded CFT
  const effectiveCft = manualCft !== '' ? Number(manualCft) : stoneCalcResult.billedCft;

  // Handler for Invoice Date change (Automatically sets +30 days due date)
  const handleInvoiceDateChange = (newDate: string) => {
    setInvoiceDate(newDate);
    if (newDate) {
      const autoDue = new Date(new Date(newDate).getTime() + 30 * 86400000).toISOString().split('T')[0];
      setDueDate(autoDue);
    }
  };

  // 1-Click apply calculated CFT to the first active line item quantity
  const handleApplyCftToActiveRow = () => {
    if (effectiveCft <= 0) return;
    setItemRows(prev => {
      const copy = [...prev];
      if (copy.length > 0) {
        copy[0] = {
          ...copy[0],
          quantity: effectiveCft,
          uom: 'CFT',
          amount: Math.round(effectiveCft * (copy[0].unitPrice || 0))
        };
      }
      return copy;
    });
  };

  // Customer Search & Creatable Combobox State
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);
  const [newlyCreatedCustomerId, setNewlyCreatedCustomerId] = useState<string | null>(null);
  const customerComboboxRef = useRef<HTMLDivElement>(null);

  // Close customer dropdown on outside click or Escape key without blocking modal interaction
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent | TouchEvent) => {
      if (
        customerComboboxRef.current &&
        !customerComboboxRef.current.contains(event.target as Node)
      ) {
        setIsCustomerDropdownOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsCustomerDropdownOpen(false);
      }
    };

    if (isCustomerDropdownOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
      document.addEventListener('touchstart', handleOutsideClick);
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isCustomerDropdownOpen]);

  // Selected Customer (Initially Empty - User must choose)
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const selectedCustomer = customers.find(c => c.id === selectedCustomerId);

  // Multi-Product Line Items (Initially 1 Blank Row - Starts Empty)
  const [itemRows, setItemRows] = useState<InvoiceItemRow[]>([
    {
      id: `row-${Date.now()}-1`,
      itemId: '',
      itemName: '',
      uom: '',
      quantity: '' as any,
      unitPrice: '' as any,
      amount: 0
    }
  ]);

  // Tax / VAT & Discount
  const [vatPercent, setVatPercent] = useState<number | ''>('');
  const [discountAmount, setDiscountAmount] = useState<number | ''>('');

  // Invoice Type: 'Cash Only' | 'Partial' | 'Due 30 Days' | 'Advance'
  const [invoiceType, setInvoiceType] = useState<InvoiceTypeOption>('Due 30 Days');
  const [salesType, setSalesType] = useState<'Paid' | 'Partial' | 'Due'>('Due');
  const [paidAmount, setPaidAmount] = useState<number | ''>('');
  const [paymentMethod, setPaymentMethod] = useState<'Bank Transfer' | 'Cash' | 'Cheque' | 'Mobile Banking'>('' as any);
  const [paymentRef, setPaymentRef] = useState<string>('');
  const [selectedDepositAccountId, setSelectedDepositAccountId] = useState<string>('');
  const [postingError, setPostingError] = useState<string | null>(null);

  // Bank Info from real Accounts module
  const { currentUser } = useAuth();
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());

  useEffect(() => {
    const unsub = subscribeBankAccounts(setBankAccounts);
    return () => unsub();
  }, []);

  // Filter accounts: Managers see only their branch accounts; admin sees all
  const accessibleAccounts = React.useMemo(() => {
    if (currentUser?.role === 'admin') {
      return bankAccounts;
    }
    const userBranch = currentUser?.branch;
    if (!userBranch || userBranch === 'All Branches') {
      return bankAccounts;
    }
    const branchKey = userBranch.toLowerCase().replace(' office', '');
    return bankAccounts.filter(acc => 
      !acc.branch || acc.branch.toLowerCase().includes(branchKey) || acc.branch === 'Head Office'
    );
  }, [bankAccounts, currentUser]);

  // Payment method controls default list: Cash shows cash; Bank Transfer & Cheque show bank; bKash/Nagad shows mobile banking
  const filteredDepositAccounts = React.useMemo(() => {
    if (paymentMethod === 'Cash') {
      const cashList = accessibleAccounts.filter(acc => isCashAccount(acc));
      return cashList.length > 0 ? cashList : accessibleAccounts;
    } else if (paymentMethod === 'Bank Transfer' || paymentMethod === 'Cheque') {
      const bankList = accessibleAccounts.filter(acc => !isCashAccount(acc));
      return bankList.length > 0 ? bankList : accessibleAccounts;
    } else if (paymentMethod === 'Mobile Banking') {
      const mobList = accessibleAccounts.filter(acc => 
        acc.bankName.toLowerCase().includes('bkash') ||
        acc.bankName.toLowerCase().includes('nagad') ||
        acc.bankName.toLowerCase().includes('rocket') ||
        acc.bankName.toLowerCase().includes('mobile') ||
        acc.accountType === 'POS Cash'
      );
      return mobList.length > 0 ? mobList : accessibleAccounts;
    }
    return accessibleAccounts;
  }, [accessibleAccounts, paymentMethod]);

  // Clear selected account if it is no longer in the filtered list
  useEffect(() => {
    if (selectedDepositAccountId && !filteredDepositAccounts.some(a => a.id === selectedDepositAccountId)) {
      setSelectedDepositAccountId('');
    }
  }, [filteredDepositAccounts, selectedDepositAccountId]);

  // Bank Info (Empty by default with placeholders)
  const [bankName, setBankName] = useState<string>('');
  const [bankAccount, setBankAccount] = useState<string>('');
  const [bankRouting, setBankRouting] = useState<string>('');

  // Notes (Empty by default with placeholders)
  const [invoiceNotes, setInvoiceNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const submitLockRef = useRef<boolean>(false);

  // Warehouses & Negative Stock Admin Setting
  const [warehouses, setWarehouses] = useState<Warehouse[]>(() => getWarehouses());
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('');
  const [allowNegativeStock, setAllowNegativeStock] = useState<boolean>(
    () => getSystemInventorySettings().allowNegativeStock
  );
  const [negativeStockReason, setNegativeStockReason] = useState<string>('');
  const [customAdvanceInput, setCustomAdvanceInput] = useState<string>('');

  useEffect(() => {
    const unsubWh = subscribeWarehouses(setWarehouses);
    const handleSettingsChange = () => {
      setAllowNegativeStock(getSystemInventorySettings().allowNegativeStock);
    };
    window.addEventListener('systemSettingsUpdated', handleSettingsChange);
    return () => {
      unsubWh();
      window.removeEventListener('systemSettingsUpdated', handleSettingsChange);
    };
  }, []);

  const isAdmin = currentUser?.role === 'admin';
  const canSellNegativeStock = Boolean(allowNegativeStock && isAdmin);
  const selectedWarehouseObj = warehouses.find(w => w.id === selectedWarehouseId);

  // Check if form is dirty
  const isFormDirty = Boolean(
    selectedCustomerId || 
    truckNo || 
    driverName || 
    driverPhone || 
    paidAmount !== '' || 
    invoiceNotes || 
    itemRows.some(r => r.itemId || r.itemName || (r.quantity && Number(r.quantity) > 0))
  );

  const handleSafeClose = () => {
    if (isSubmitting || submitLockRef.current) return;
    onClose();
  };

  // Financial calculations - start at 0 until inputs entered
  const subtotal = itemRows.reduce((sum, row) => sum + row.amount, 0);
  const vatAmount = Math.round((subtotal * (Number(vatPercent) || 0)) / 100);
  const grandTotal = Math.max(0, subtotal + vatAmount - (Number(discountAmount) || 0));

  // Customer advance balance: read authoritative available advance
  const hasPriorDue = (selectedCustomer?.currentBalance || 0) > 0;
  const customerAdvance = hasPriorDue ? 0 : getCustomerAvailableAdvance(selectedCustomer);

  const maxAdjustableAdvance = Math.min(customerAdvance, grandTotal);
  const requestedAdvanceAdjustment =
    customAdvanceInput !== '' ? Math.max(0, Number(customAdvanceInput) || 0) : maxAdjustableAdvance;
  const advanceValidationError =
    customerAdvance > 0 && requestedAdvanceAdjustment > customerAdvance + 0.001
      ? `Adjusted advance (BDT ${requestedAdvanceAdjustment.toLocaleString()}) cannot exceed available customer advance (BDT ${customerAdvance.toLocaleString()}).`
      : customerAdvance > 0 && requestedAdvanceAdjustment > grandTotal + 0.001
      ? `Adjusted advance (BDT ${requestedAdvanceAdjustment.toLocaleString()}) cannot exceed the invoice total (BDT ${grandTotal.toLocaleString()}).`
      : null;

  // Determine actual paid, adjusted advance, remaining advance, cash received now, and invoice due:
  let actualPaid = 0;
  let actualDue = grandTotal;
  let adjustedAdvance = 0;
  let remainingCustomerAdvance = customerAdvance;
  let cashReceivedNow = 0;

  if (customerAdvance > 0) {
    adjustedAdvance = requestedAdvanceAdjustment;
    remainingCustomerAdvance = Math.max(0, Number((customerAdvance - adjustedAdvance).toFixed(2)));
    const remainingAfterAdvance = Math.max(0, Number((grandTotal - adjustedAdvance).toFixed(2)));

    if (invoiceType === 'Cash Only') {
      cashReceivedNow = remainingAfterAdvance;
    } else if (invoiceType === 'Due 30 Days') {
      cashReceivedNow = 0;
    } else {
      // Partial Payment or Payment 10 Days
      cashReceivedNow = Math.min(remainingAfterAdvance, Math.max(0, Number(paidAmount) || 0));
    }
    actualPaid = Number((adjustedAdvance + cashReceivedNow).toFixed(2));
    actualDue = Math.max(0, Number((grandTotal - actualPaid).toFixed(2)));
  } else {
    // Customer does NOT have a prior advance deposit:
    if (invoiceType === 'Cash Only') {
      actualPaid = grandTotal;
      actualDue = 0;
      cashReceivedNow = grandTotal;
    } else if (invoiceType === 'Due 30 Days') {
      actualPaid = 0;
      actualDue = grandTotal;
      cashReceivedNow = 0;
    } else if (invoiceType === 'Partial Payment') {
      cashReceivedNow = Math.min(grandTotal, Math.max(0, Number(paidAmount) || 0));
      actualPaid = cashReceivedNow;
      actualDue = Math.max(0, grandTotal - actualPaid);
    } else if (invoiceType === 'Payment 10 Days') {
      cashReceivedNow = Math.min(grandTotal, Math.max(0, Number(paidAmount) || 0));
      actualPaid = cashReceivedNow;
      actualDue = Math.max(0, grandTotal - actualPaid);
    }
  }

  // Live stock validation for all item rows in the selected warehouse
  const stockValidation = React.useMemo(() => {
    return validateStockAvailabilityForLines(
      itemRows.map(r => ({
        itemId: r.itemId,
        itemName: r.itemName,
        quantity: Number(r.quantity) || 0,
        uom: r.uom,
      })),
      selectedWarehouseId,
      {
        allowNegativeStock,
        isAdmin,
        negativeStockReason,
        itemsSnapshot: items,
      }
    );
  }, [itemRows, selectedWarehouseId, allowNegativeStock, isAdmin, negativeStockReason, items]);

  // Handle Invoice Type Change from Top Dropdown
  const handleInvoiceTypeChange = (type: InvoiceTypeOption) => {
    if (type === 'Payment 10 Days' && (selectedCustomer?.currentBalance || 0) > 0) {
      alert("⚠️ This customer has a previous due balance. Advance or Payment 10 Days is not applicable when there is a prior due balance. Use Cash Only, Due 30 Days, or Partial Payment.");
      return;
    }
    setInvoiceType(type);
    if (type === 'Cash Only') {
      setSalesType('Paid');
      setPaidAmount(grandTotal);
      setPaymentMethod('Cash');
      setDueDate(invoiceDate);
    } else if (type === 'Due 30 Days') {
      setSalesType('Due');
      setPaidAmount(0);
      const calculatedDue = new Date(new Date(invoiceDate).getTime() + (selectedCustomer?.creditDays || 30) * 86400000)
        .toISOString()
        .split('T')[0];
      setDueDate(calculatedDue);
    } else if (type === 'Partial Payment') {
      setSalesType('Partial');
      const defaultPartial = Math.round(grandTotal * 0.5);
      setPaidAmount(defaultPartial > 0 ? defaultPartial : 0);
      const calculatedDue = new Date(new Date(invoiceDate).getTime() + (selectedCustomer?.creditDays || 30) * 86400000)
        .toISOString()
        .split('T')[0];
      setDueDate(calculatedDue);
    } else if (type === 'Payment 10 Days') {
      // 10 Days credit term / advance
      const tenDaysDue = new Date(new Date(invoiceDate).getTime() + 10 * 86400000)
        .toISOString()
        .split('T')[0];
      setDueDate(tenDaysDue);
      setPaidAmount(grandTotal); // default full advance, editable by user
      setSalesType('Paid');
      setPaymentMethod('Bank Transfer');
      if (!paymentRef) {
        setPaymentRef('PAY-10D-ADV');
      }
    }
  };

  // Filter customers for creatable search combobox
  const filteredCustomers = customers.filter(c => {
    const q = customerSearchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      c.name.toLowerCase().includes(q) ||
      (c.tradeName && c.tradeName.toLowerCase().includes(q)) ||
      c.code.toLowerCase().includes(q) ||
      (c.phone && c.phone.includes(q))
    );
  });

  const hasExactCustomerMatch = customers.some(c => 
    c.name.trim().toLowerCase() === customerSearchQuery.trim().toLowerCase() ||
    (c.tradeName && c.tradeName.trim().toLowerCase() === customerSearchQuery.trim().toLowerCase())
  );

  // Fast Initial Customer Profile Creation directly by name
  const handleCreateInitialCustomer = (nameToCreate: string) => {
    const trimmed = nameToCreate.trim();
    if (!trimmed) return;
    const nextNum = customers.length + 1;
    const code = `CUST-${nextNum < 10 ? '00' : nextNum < 100 ? '0' : ''}${nextNum}`;
    const newCust: Customer = {
      id: `cust-${Date.now()}`,
      code,
      name: trimmed,
      tradeName: trimmed,
      contactPerson: trimmed,
      email: '',
      phone: '',
      address: 'Sales Counter',
      city: 'Dhaka',
      creditDays: 30,
      currentBalance: 0,
      advanceBalance: 0,
      status: 'Active'
    };
    if (onQuickCreateCustomer) {
      onQuickCreateCustomer(newCust);
    }
    setSelectedCustomerId(newCust.id);
    setNewlyCreatedCustomerId(newCust.id);
    setCustomerSearchQuery('');
    setIsCustomerDropdownOpen(false);
  };

  // Handle Customer Selection
  const handleCustomerChange = (custId: string) => {
    setSelectedCustomerId(custId);
    setCustomAdvanceInput('');
    const cust = customers.find(c => c.id === custId);
    if (!cust) return;

    // Walk In Customer has zero credit - always Cash Only!
    if (custId === 'cust-walkin') {
      setInvoiceType('Cash Only');
      setSalesType('Paid');
      setPaidAmount(grandTotal);
      setPaymentMethod('Cash');
      setDueDate(invoiceDate);
      return;
    }

    const due = cust.currentBalance || 0;
    if (due > 0) {
      setInvoiceType('Due 30 Days');
      setSalesType('Due');
      setPaidAmount(0);
      const days = cust.creditDays || 30;
      const newDue = new Date(new Date(invoiceDate).getTime() + days * 86400000)
        .toISOString()
        .split('T')[0];
      setDueDate(newDue);
    } else {
      if (invoiceType === 'Due 30 Days') {
        const days = cust.creditDays || 30;
        const newDue = new Date(new Date(invoiceDate).getTime() + days * 86400000)
          .toISOString()
          .split('T')[0];
        setDueDate(newDue);
      }
    }
  };

  // Handle Item Row Changes
  const handleRowItemSelect = (rowId: string, itemId: string) => {
    if (itemId === '') {
      setItemRows(prev => prev.map(row => {
        if (row.id !== rowId) return row;
        return {
          ...row,
          itemId: '',
          itemName: '',
          quantity: 0,
          unitPrice: 0,
          amount: 0
        };
      }));
      return;
    }
    if (itemId === 'custom') {
      setItemRows(prev => prev.map(row => {
        if (row.id !== rowId) return row;
        const qty = row.quantity > 0 ? row.quantity : 1;
        return {
          ...row,
          itemId: 'custom',
          itemName: '',
          uom: 'Job',
          quantity: qty,
          unitPrice: row.unitPrice,
          amount: Math.round(qty * row.unitPrice)
        };
      }));
      return;
    }
    const itm = items.find(i => i.id === itemId);
    if (itm && isStockItem(itm, itm.id, itm.name, itm.uom)) {
      const stockInfo = getAvailableStockForWarehouse(itm, selectedWarehouseId);
      if (stockInfo.availableInBaseUom <= 0 && !canSellNegativeStock) {
        setPostingError(
          `"${itm.name}" is Out of stock (0 ${itm.uom} available in ${selectedWarehouseObj?.name || 'selected warehouse'}) and cannot be added.`
        );
        return;
      }
    }
    setPostingError(null);
    setItemRows(prev => prev.map(row => {
      if (row.id !== rowId) return row;
      if (itm) {
        const rate = itm.sellingPrice || 0;
        const qty = row.quantity > 0 ? row.quantity : 1;
        return {
          ...row,
          itemId: itm.id,
          itemName: itm.name,
          uom: itm.uom || 'Ton',
          quantity: qty,
          unitPrice: rate,
          amount: Math.round(qty * rate)
        };
      }
      return row;
    }));
  };

  const handleRowQtyChange = (rowId: string, qty: number) => {
    const validQty = Math.max(0, isNaN(qty) ? 0 : qty);
    setItemRows(prev => prev.map(row => {
      if (row.id !== rowId) return row;
      return {
        ...row,
        quantity: validQty,
        amount: Math.round(validQty * row.unitPrice)
      };
    }));
  };

  const handleRowRateChange = (rowId: string, rate: number) => {
    const validRate = Math.max(0, isNaN(rate) ? 0 : rate);
    setItemRows(prev => prev.map(row => {
      if (row.id !== rowId) return row;
      return {
        ...row,
        unitPrice: validRate,
        amount: Math.round(row.quantity * validRate)
      };
    }));
  };

  const handleRowUomChange = (rowId: string, uom: string) => {
    setItemRows(prev => prev.map(row => row.id === rowId ? { ...row, uom } : row));
  };

  const handleRowDescChange = (rowId: string, desc: string) => {
    setItemRows(prev => prev.map(row => row.id === rowId ? { ...row, itemName: desc } : row));
  };

  // Add Item Row (Multi-Product - starts blank)
  const handleAddRow = () => {
    const newRow: InvoiceItemRow = {
      id: `row-${Date.now()}-${itemRows.length + 1}`,
      itemId: '',
      itemName: '',
      uom: '',
      quantity: '' as any,
      unitPrice: '' as any,
      amount: 0
    };
    setItemRows(prev => [...prev, newRow]);
  };

  // Remove Item Row
  const handleRemoveRow = (rowId: string) => {
    if (itemRows.length <= 1) return;
    setItemRows(itemRows.filter(r => r.id !== rowId));
  };

  // Save / Submit Handlers
  const handleBuildAndSubmit = async (andPrint: boolean = false) => {
    if (isSubmitting || submitLockRef.current) return;

    if (!selectedCustomer) {
      setPostingError('Please select a customer first.');
      return;
    }
    const validItems = itemRows.filter(r => (r.itemName || r.itemId) && Number(r.quantity) > 0 && Number(r.unitPrice) > 0);
    if (validItems.length === 0) {
      setPostingError('Please enter at least one product description, quantity, and unit rate.');
      return;
    }

    if (advanceValidationError) {
      setPostingError(advanceValidationError);
      return;
    }

    if (!stockValidation.valid) {
      setPostingError(stockValidation.summaryError || 'Insufficient stock for one or more items.');
      return;
    }

    if (cashReceivedNow > 0 && !selectedDepositAccountId) {
      setPostingError('Please select a deposit cash/bank account for received payment.');
      return;
    }

    submitLockRef.current = true;
    setPostingError(null);
    setIsSubmitting(true);

    const soNumber = `SO-2026-0${830 + ordersCount}`;

    // Create Sales Order (Automated Delivery: immediately marked Delivered upon invoice creation)
    const newSO: SalesOrder = {
      id: `so-${Date.now()}`,
      soNumber,
      customerId: selectedCustomer.id,
      customerName: selectedCustomer.tradeName || selectedCustomer.name,
      orderDate: invoiceDate,
      invoiceDate: invoiceDate,
      deliveryDate: invoiceDate,
      paymentTerm: invoiceType === 'Cash Only' 
        ? `Cash Only (${paymentMethod})` 
        : invoiceType === 'Due 30 Days'
          ? `Due 30 Days (${selectedCustomer.creditDays || 30} Days Credit)`
          : invoiceType === 'Partial Payment' 
            ? `Partial Payment (৳${actualPaid.toLocaleString()} Paid, ৳${actualDue.toLocaleString()} Due in 30 Days)` 
            : `Payment 10 Days (${actualDue === 0 ? 'Full Advance Paid' : `৳${actualPaid.toLocaleString()} Paid, ৳${actualDue.toLocaleString()} Due in 10 Days`})`,
      salesType: actualDue === 0 ? 'Paid' : actualPaid > 0 ? 'Partial' : 'Due',
      paidAmount: actualPaid,
      dueAmount: actualDue,
      paymentMethod: actualPaid > 0 ? paymentMethod : undefined,
      items: validItems.map(r => ({
        itemId: r.itemId === 'custom' ? 'srv-custom' : (r.itemId || 'srv-custom'),
        itemName: r.itemName,
        sku: items.find(i => i.id === r.itemId)?.sku || 'IND-MAT',
        quantity: Number(r.quantity),
        uom: r.uom || 'Ton',
        unitPrice: Number(r.unitPrice),
        discountPercent: 0,
        totalAmount: r.amount
      })),
      subtotal,
      taxAmount: vatAmount,
      grandTotal,
      status: 'Delivered'
    };

    const selectedAcc = accessibleAccounts.find(a => a.id === selectedDepositAccountId);

    // Create Sales Invoice (Auto-delivering goods and logging truck/challan information)
    const newInvoice: SalesInvoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: invoiceNumber.trim() || autoInvNumber,
      soNumber,
      customerId: selectedCustomer.id,
      customerName: selectedCustomer.tradeName || selectedCustomer.name,
      invoiceDate,
      dueDate,
      warehouseId: selectedWarehouseId,
      warehouseName: selectedWarehouseObj?.name,
      negativeStockReason: stockValidation.requiresNegativeStockApproval ? negativeStockReason.trim() : undefined,
      negativeStockApprovedBy: stockValidation.requiresNegativeStockApproval ? (currentUser?.name || 'Admin') : undefined,
      truckNo: truckNo.trim() || undefined,
      driverName: driverName.trim() || undefined,
      driverPhone: driverPhone.trim() || undefined,
      measurementLength: typeof measLengthFt === 'number' ? measLengthFt : undefined,
      measurementLengthInches: measLengthIn || undefined,
      measurementWidth: typeof measWidthFt === 'number' ? measWidthFt : undefined,
      measurementWidthInches: measWidthIn || undefined,
      measurementHeight: typeof measHeightFt === 'number' ? measHeightFt : undefined,
      measurementHeightInches: measHeightIn || undefined,
      measurementLengthEffective: stoneCalcResult.lengthEffective || undefined,
      measurementWidthEffective: stoneCalcResult.widthEffective || undefined,
      measurementHeightEffective: stoneCalcResult.heightEffective || undefined,
      exactCft: stoneCalcResult.exactCft > 0 ? stoneCalcResult.exactCft : undefined,
      billedCft: stoneCalcResult.billedCft > 0 ? stoneCalcResult.billedCft : undefined,
      formulaDisplay: stoneCalcResult.formulaDisplay,
      measurementCft: effectiveCft > 0 ? effectiveCft : undefined,
      downInches: measDownInches > 0 ? measDownInches : undefined,
      downLabel: measDownInches > 0 ? `${measDownInches} Inch Down` : 'Full Load',
      originalHeightFeet: typeof measHeightFt === 'number' ? measHeightFt : undefined,
      originalHeightInches: typeof measHeightIn === 'number' ? measHeightIn : undefined,
      originalBilledCft: stoneCalcResult.originalBilledCft > 0 ? stoneCalcResult.originalBilledCft : undefined,
      effectiveHeightFeet: stoneCalcResult.heightFeet || undefined,
      effectiveHeightInches: stoneCalcResult.heightInches || undefined,
      items: validItems.map(r => ({
        itemId: r.itemId === 'custom' ? 'srv-custom' : (r.itemId || 'srv-custom'),
        itemName: r.itemName,
        quantity: Number(r.quantity),
        uom: r.uom || 'Ton',
        unitPrice: Number(r.unitPrice),
        amount: r.amount
      })),
      totalAmount: grandTotal,
      paidAmount: actualPaid,
      cashPaidAmount: cashReceivedNow,
      advanceAdjusted: adjustedAdvance,
      adjustedAdvanceAmount: adjustedAdvance,
      dueAmount: actualDue,
      paymentMethod: cashReceivedNow > 0 ? paymentMethod : (adjustedAdvance > 0 ? 'Advance Adjustment' : undefined),
      depositAccountId: cashReceivedNow > 0 ? selectedDepositAccountId : undefined,
      depositAccountName: cashReceivedNow > 0 && selectedAcc ? `${selectedAcc.bankName} (${selectedAcc.accountNumber})` : undefined,
      paymentRef: cashReceivedNow > 0 && paymentRef.trim() ? paymentRef.trim() : undefined,
      status: actualDue === 0 ? 'Paid' : actualPaid > 0 ? 'Partially Paid' : 'Unpaid'
    };

    // Upfront Payment record if cash received now
    let upfrontPayment: CustomerPayment | undefined;
    if (cashReceivedNow > 0) {
      upfrontPayment = {
        id: `pay-inv-${Date.now()}`,
        receiptNumber: '', // Filled upon real voucher posting
        customerId: selectedCustomer.id,
        customerName: selectedCustomer.name,
        customerTradeName: selectedCustomer.tradeName || selectedCustomer.name,
        paymentDate: invoiceDate,
        amount: cashReceivedNow,
        paymentMethod,
        paymentType: 'Invoice Payment',
        bankAccountId: selectedDepositAccountId,
        bankName: selectedAcc?.bankName,
        branchName: selectedAcc?.branch,
        refNumber: paymentRef.trim() || undefined,
        invoiceNumber: newInvoice.invoiceNumber,
        note: `Direct Sales payment (${invoiceType}) against ${newInvoice.invoiceNumber}`,
        status: 'Cleared',
        collectedBy: currentUser?.name || 'Commercial Desk'
      };
    }

    try {
      if (andPrint && onSaveAndPrint) {
        await onSaveAndPrint(newInvoice, newSO, upfrontPayment, adjustedAdvance);
      } else {
        await onSaveInvoice(newInvoice, newSO, upfrontPayment, adjustedAdvance);
      }
    } catch (err: any) {
      console.error('Invoice posting error:', err);
      setPostingError(err?.message || 'Failed to post invoice and vouchers.');
    } finally {
      submitLockRef.current = false;
      setIsSubmitting(false);
    }
  };

  return (
    <ModalWrapper
      onClose={handleSafeClose}
      isDirty={isFormDirty}
      isSaving={isSubmitting}
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in"
    >
      {/* Outer Modal Container with Defined Max Height & Smooth Scrolling */}
      <div className="w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-200/80 flex flex-col max-h-[95vh] overflow-hidden">
        
        {/* ================= 1. Top Minimal Sticky Action Bar ================= */}
        <div className="bg-slate-50/90 border-b border-slate-200 px-5 py-3.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-xs shadow-xs">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm font-bold text-slate-900">
                  New Sales Invoice & Delivery Challan
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-800 border border-teal-300">
                  Auto Delivery Integrated
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              data-modal-close="true"
              onClick={handleSafeClose}
              disabled={isSubmitting}
              className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => handleBuildAndSubmit(true)}
              disabled={isSubmitting}
              className="px-3.5 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Save & Print</span>
            </button>
            <button
              type="button"
              onClick={() => handleBuildAndSubmit(false)}
              disabled={isSubmitting}
              className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>{isSubmitting ? 'Saving...' : 'Create Invoice'}</span>
            </button>
            <button
              type="button"
              data-modal-close="true"
              onClick={handleSafeClose}
              disabled={isSubmitting}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors ml-1 cursor-pointer disabled:opacity-50 shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ================= 2. Scrollable Minimal Invoice Canvas ================= */}
        <div className="overflow-y-auto p-4 sm:p-7 space-y-6 bg-white text-slate-800 text-xs">
          
          {/* Top Invoice Header (Minimal & Elegant) */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block"></span>
                <span className="text-[11px] font-mono uppercase tracking-widest text-slate-400 font-semibold">
                  Commercial Sales Voucher
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
                COMMERCIAL INVOICE
              </h1>
              <p className="text-slate-500 text-xs mt-0.5">
                Bengal Industrial Imports & Commodities PLC
              </p>
            </div>

            {/* Invoice Meta Badges (INV DATE, Invoice #, Invoice Type) */}
            <div className="flex flex-wrap sm:flex-col sm:items-end gap-2 text-right">
              {/* 1. Invoice Date (as indicated by the user's INV DATE red box above Invoice No) */}
              <div className="flex items-center gap-1.5 justify-end">
                <span className="text-[11px] font-mono text-slate-600 font-bold uppercase flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  INV DATE:
                </span>
                <input
                  type="date"
                  value={invoiceDate}
                  onChange={(e) => handleInvoiceDateChange(e.target.value)}
                  className="bg-white border border-slate-300 font-mono font-bold text-slate-900 px-2 py-1 rounded text-xs text-right focus:outline-none focus:ring-1 focus:ring-slate-900 w-36 shadow-2xs cursor-pointer"
                  title="Invoice Date"
                />
              </div>

              {/* 2. Invoice No (Auto System Generated) */}
              <div className="flex items-center gap-1.5 justify-end">
                <span className="text-[11px] font-mono text-slate-500 font-bold uppercase">INVOICE NO:</span>
                <div className="flex items-center gap-1 bg-slate-50 border border-slate-300 rounded px-2.5 py-1 shadow-2xs">
                  <span className="font-mono font-black text-slate-900 text-xs">
                    {invoiceNumber}
                  </span>
                  <span className="text-[9px] font-mono font-bold bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded">
                    Auto Generated
                  </span>
                </div>
              </div>

              {/* 3. Invoice Type Dropdown */}
              <div className="flex items-center gap-2 justify-end">
                <label htmlFor="invoice-type-select" className="text-xs font-bold text-slate-700 whitespace-nowrap">
                  Invoice Type:
                </label>
                <div className="relative">
                  <select
                    id="invoice-type-select"
                    value={invoiceType}
                    onChange={(e) => handleInvoiceTypeChange(e.target.value as InvoiceTypeOption)}
                    className={`appearance-none font-bold text-xs py-1.5 pl-3 pr-8 rounded-lg border shadow-2xs focus:outline-none focus:ring-2 cursor-pointer transition-all ${
                      invoiceType === 'Cash Only'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300 focus:ring-emerald-400'
                        : invoiceType === 'Due 30 Days'
                          ? 'bg-rose-50 text-rose-800 border-rose-300 focus:ring-rose-400'
                          : invoiceType === 'Partial Payment'
                            ? 'bg-amber-50 text-amber-800 border-amber-300 focus:ring-amber-400'
                            : 'bg-indigo-50 text-indigo-800 border-indigo-300 focus:ring-indigo-400'
                    }`}
                  >
                    <option value="Cash Only">1. Cash Only</option>
                    <option value="Due 30 Days">2. Due 30 Days</option>
                    <option value="Partial Payment">3. Partial Payment</option>
                    <option 
                      value="Payment 10 Days"
                      disabled={(selectedCustomer?.currentBalance || 0) > 0}
                    >
                      4. Payment 10 Days
                    </option>
                  </select>
                  <ChevronDown className={`w-3.5 h-3.5 pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 ${
                    invoiceType === 'Cash Only' ? 'text-emerald-700' :
                    invoiceType === 'Due 30 Days' ? 'text-rose-700' :
                    invoiceType === 'Partial Payment' ? 'text-amber-700' : 'text-indigo-700'
                  }`} />
                </div>
              </div>

              <div className="flex items-center gap-2 justify-end text-[10px] font-mono">
                <span className="text-slate-500 font-bold">
                  {invoiceType === 'Cash Only' ? 'Immediate Settlement' :
                   invoiceType === 'Payment 10 Days' ? `Terms: 10 Days (${dueDate})` :
                   `Terms: 30 Days (${dueDate})`}
                </span>
                {selectedCustomer && (selectedCustomer.currentBalance || 0) > 0 && (
                  <span className="px-2 py-0.5 rounded font-bold bg-rose-50 text-rose-700 border border-rose-200">
                    Previous Due: ৳{(selectedCustomer.currentBalance || 0).toLocaleString()}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* ================= 3. FROM, BILL TO, & DATES CARDS ================= */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* FROM Column */}
            <div className="bg-slate-50/70 border border-slate-200/90 rounded-xl p-3.5 space-y-1">
              <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block">
                FROM (SELLER)
              </span>
              <div className="font-bold text-xs text-slate-900">
                Bengal Industrial Imports & Commodities PLC
              </div>
              <div className="text-slate-500 text-[11px]">
                Agrabad Commercial Area, Chittagong-4100
              </div>
              <div className="text-slate-500 text-[11px]">
                sales@bengalindustrial.com.bd | +880-31-712891
              </div>
              <div className="text-slate-400 text-[10px] font-mono pt-1">
                BIN/VAT: 001928374-0201 | TIN: 882910394819
              </div>
            </div>

            {/* BILL TO Column (Customer Selection) */}
            <div className="bg-blue-50/40 border border-blue-200/80 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold font-mono tracking-wider text-blue-700 uppercase">
                  BILL TO (CUSTOMER) <span className="text-rose-500">*</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    handleCustomerChange('cust-walkin');
                    setCustomerSearchQuery('');
                    setIsCustomerDropdownOpen(false);
                  }}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedCustomerId === 'cust-walkin'
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                      : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-300'
                  }`}
                  title="Select Walk-In Customer for cash retail sale"
                >
                  <span>⚡ Walk In Customer</span>
                </button>
              </div>

              {/* Customer Creatable & Searchable Combobox */}
              <div ref={customerComboboxRef} className="relative">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Select customer or type name..."
                    value={
                      isCustomerDropdownOpen
                        ? customerSearchQuery
                        : (selectedCustomer ? (selectedCustomer.tradeName || selectedCustomer.name) : '')
                    }
                    onFocus={() => {
                      setIsCustomerDropdownOpen(true);
                      setCustomerSearchQuery('');
                    }}
                    onClick={() => {
                      setIsCustomerDropdownOpen(true);
                    }}
                    onChange={(e) => {
                      setCustomerSearchQuery(e.target.value);
                      setIsCustomerDropdownOpen(true);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        if (filteredCustomers.length > 0 && customerSearchQuery.trim()) {
                          handleCustomerChange(filteredCustomers[0].id);
                          setIsCustomerDropdownOpen(false);
                          setCustomerSearchQuery('');
                        } else if (customerSearchQuery.trim()) {
                          handleCreateInitialCustomer(customerSearchQuery.trim());
                        }
                      }
                    }}
                    className={`w-full bg-white border rounded-lg px-2.5 py-1.5 font-bold text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none shadow-2xs pr-8 ${
                      !selectedCustomerId ? 'border-amber-400 text-slate-500 italic' : 'border-slate-300 text-slate-900'
                    }`}
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setIsCustomerDropdownOpen(prev => !prev)}
                    className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer transition-colors"
                    title="Toggle customer list"
                  >
                    <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-150 ${isCustomerDropdownOpen ? 'rotate-180 text-blue-600' : ''}`} />
                  </button>
                </div>

                {/* Dropdown Menu - Clean Floating Popover (No blocking fixed overlay) */}
                {isCustomerDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-300 rounded-xl shadow-2xl z-30 max-h-60 overflow-y-auto divide-y divide-slate-100">
                    {/* Auto Create Prompt if search term typed */}
                    {customerSearchQuery.trim() && !hasExactCustomerMatch && (
                      <button
                        type="button"
                        onClick={() => handleCreateInitialCustomer(customerSearchQuery.trim())}
                        className="w-full text-left p-2.5 bg-blue-50 hover:bg-blue-100 text-blue-900 text-xs font-bold flex items-center gap-2 border-b border-blue-200 cursor-pointer transition-colors"
                      >
                        <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
                          <Plus className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div>Create new customer: <span className="underline">"{customerSearchQuery.trim()}"</span></div>
                          <div className="text-[10px] font-normal text-blue-700">An initial profile will be created automatically</div>
                        </div>
                      </button>
                    )}

                    {/* Filtered Customer List */}
                    {filteredCustomers.map(c => {
                      const isWalkIn = c.id === 'cust-walkin';
                      const cHasDue = (c.currentBalance || 0) > 0;
                      const cAdv = cHasDue ? 0 : (c.advanceBalance || 0);
                      return (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => {
                            handleCustomerChange(c.id);
                            setIsCustomerDropdownOpen(false);
                            setCustomerSearchQuery('');
                          }}
                          className={`w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer ${
                            c.id === selectedCustomerId ? 'bg-blue-50/70 font-bold' : ''
                          }`}
                        >
                          <div>
                            <div className="text-slate-900 font-semibold flex items-center gap-1.5">
                              {isWalkIn && <span className="text-emerald-600 font-bold">⚡</span>}
                              <span>{c.tradeName || c.name}</span>
                              <span className="text-[10px] text-slate-400 font-mono">({c.code})</span>
                            </div>
                            <div className="text-[10px] text-slate-500">
                              {isWalkIn ? 'Counter Cash Buyer (No credit ledger)' : (c.city || 'Dhaka')}
                            </div>
                          </div>
                          <div className="text-right">
                            {isWalkIn ? (
                              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                                Cash
                              </span>
                            ) : cHasDue ? (
                              <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                                Due ৳{c.currentBalance.toLocaleString()}
                              </span>
                            ) : cAdv > 0 ? (
                              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                                Advance ৳{cAdv.toLocaleString()}
                              </span>
                            ) : (
                              <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                                Settled
                              </span>
                            )}
                          </div>
                        </button>
                      );
                    })}

                    {filteredCustomers.length === 0 && !customerSearchQuery.trim() && (
                      <div className="p-3 text-center text-xs text-slate-400">No customers found</div>
                    )}
                  </div>
                )}
              </div>

              {/* Selected Customer Details */}
              {!selectedCustomer ? (
                <div className="text-slate-500 italic text-[11px] py-3 px-3 border border-dashed border-blue-200 rounded-lg bg-white/70 text-center">
                  Select a customer or type a name directly to create an automatic profile
                </div>
              ) : (
                <div className="text-slate-600 text-[11px] space-y-1.5 pt-0.5">
                  <div className="font-semibold text-slate-800 flex items-center justify-between">
                    <span>{selectedCustomer.name !== selectedCustomer.tradeName ? selectedCustomer.name : 'Procurement Desk'}</span>
                    <span className="text-[10px] font-mono text-slate-400">{selectedCustomer.code}</span>
                  </div>

                  {selectedCustomer.id === 'cust-walkin' ? (
                    <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-900 font-medium">
                      ⚡ <strong>Walk In Customer</strong>: No credit ledger applies. The full invoice amount will be settled in cash.
                    </div>
                  ) : (
                    <>
                      <div className="text-slate-500">
                        {selectedCustomer.address || 'Plot 45, BSCIC Industrial Area'}, {selectedCustomer.city || 'Dhaka'}
                      </div>
                      <div className="text-slate-500 font-mono text-[10px]">
                        Phone: {selectedCustomer.phone || '+880 1711-XXXXXX'} | Terms: {selectedCustomer.creditDays || 30} Days
                      </div>

                      {/* If newly created by name */}
                      {newlyCreatedCustomerId === selectedCustomer.id && (
                        <div className="p-1.5 bg-blue-50 border border-blue-200 rounded text-[10px] text-blue-800 font-medium">
                          ✓ Initial profile created. You can update the address and phone number later from Customer Profiles.
                        </div>
                      )}

                      {/* Immediate Balances Display */}
                      <div className="grid grid-cols-2 gap-2 pt-1 border-t border-blue-200/70 font-mono text-[11px]">
                        <div className="p-1.5 bg-white rounded border border-slate-200">
                          <span className="text-[9px] text-slate-400 block uppercase font-sans">Due:</span>
                          <strong className={(selectedCustomer.currentBalance || 0) > 0 ? 'text-rose-600 font-bold' : 'text-slate-600'}>
                            ৳{(selectedCustomer.currentBalance || 0).toLocaleString()}
                          </strong>
                        </div>
                        <div className={`p-1.5 rounded border ${customerAdvance > 0 ? 'bg-emerald-50 border-emerald-300' : 'bg-white border-slate-200'}`}>
                          <span className="text-[9px] text-emerald-800 block uppercase font-sans font-bold">Advance:</span>
                          <strong className={customerAdvance > 0 ? 'text-emerald-700 text-xs font-black' : 'text-slate-400'}>
                            ৳{customerAdvance.toLocaleString()}
                          </strong>
                        </div>
                      </div>

                      {/* Customer Status Prompt */}
                      {selectedCustomer && (selectedCustomer.currentBalance || 0) > 0 ? (
                        <div className="p-2 bg-rose-50/70 border border-rose-200 rounded-lg text-[11px] text-rose-900 flex items-center justify-between font-mono">
                          <span className="font-medium font-sans">Previous Due:</span>
                          <strong className="font-bold text-rose-700">৳{(selectedCustomer.currentBalance || 0).toLocaleString()}</strong>
                        </div>
                      ) : customerAdvance > 0 && grandTotal > 0 ? (
                        <div className="p-2 bg-emerald-50 border border-emerald-300 rounded-lg text-[11px] text-emerald-950 flex items-start gap-1.5 shadow-2xs">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <div className="flex-1">
                            <div className="flex justify-between items-center font-bold">
                              <span>Advance Adjusted: ৳{adjustedAdvance.toLocaleString()}</span>
                              <span className="font-mono text-emerald-700 font-bold">Remaining: ৳{remainingCustomerAdvance.toLocaleString()}</span>
                            </div>
                            <span className="text-[10px] text-emerald-800 block mt-0.5">
                              This invoice amount is deducted directly from the customer's advance balance.
                            </span>
                          </div>
                        </div>
                      ) : null}
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Column 3: TRANSPORT & VEHICLE DETAILS */}
            <div className="bg-slate-50/80 border border-slate-200/90 rounded-xl p-3.5 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold font-mono tracking-wider text-slate-700 uppercase flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-blue-600" />
                  TRANSPORT & VEHICLE DETAILS
                </span>
                <span className="text-[9px] bg-blue-50 text-blue-700 border border-blue-200 px-1.5 py-0.5 rounded font-mono font-bold">
                  Stone / CFT
                </span>
              </div>

              {/* Truck No & Driver Name */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-semibold text-slate-600 block mb-1">
                    Truck No:
                  </label>
                  <input
                    type="text"
                    placeholder="Dhaka Metro-Ta 11-5678"
                    value={truckNo}
                    onChange={(e) => setTruckNo(e.target.value)}
                    className="w-full bg-white border border-slate-300 px-2 py-1 rounded-lg text-xs font-mono text-slate-900 focus:ring-1 focus:ring-slate-900 outline-none shadow-2xs placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-slate-600 block mb-1">
                    Driver Name:
                  </label>
                  <input
                    type="text"
                    placeholder="Driver Name"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full bg-white border border-slate-300 px-2 py-1 rounded-lg text-xs text-slate-900 focus:ring-1 focus:ring-slate-900 outline-none shadow-2xs placeholder:text-slate-400"
                  />
                </div>
              </div>

              {/* Driver Mobile */}
              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-1">
                  Driver Mobile:
                </label>
                <input
                  type="text"
                  placeholder="017XX-XXXXXX"
                  value={driverPhone}
                  onChange={(e) => setDriverPhone(e.target.value)}
                  className="w-full bg-white border border-slate-300 px-2 py-1 rounded-lg text-xs font-mono text-slate-900 focus:ring-1 focus:ring-slate-900 outline-none shadow-2xs placeholder:text-slate-400"
                />
              </div>

              {/* Vehicle Measurement Section */}
              <div className="pt-2 border-t border-slate-200 space-y-2">
                
                {/* 1. Down Option Selector right at the beginning */}
                <div className="bg-amber-50/90 border border-amber-300/80 rounded-lg p-2 space-y-1.5 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-amber-950 flex items-center gap-1">
                      <ArrowDown className="w-3.5 h-3.5 text-amber-700" />
                      Load Measurement / Down Option:
                    </label>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded font-mono ${
                      measDownInches > 0 ? 'bg-amber-200 text-amber-950 border border-amber-400' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {measDownInches === 0 ? 'Full Truck' : `${measDownInches}″ Down`}
                    </span>
                  </div>
                  <select
                    value={measDownInches}
                    onChange={(e) => setMeasDownInches(Number(e.target.value))}
                    className="w-full bg-white border border-amber-300 rounded-lg px-2 py-1 text-xs font-bold text-slate-900 focus:ring-1 focus:ring-amber-500 outline-none shadow-2xs"
                  >
                    {STONE_DOWN_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-800 flex items-center gap-1">
                    <Scale className="w-3.5 h-3.5 text-blue-600" />
                    Truck Dimensions (Feet & Inches):
                  </span>
                  <span className="text-[9px] text-slate-500 font-medium">
                    Half inch (.5) supported
                  </span>
                </div>

                {/* 3 Dimension Rows: Length, Width, Height */}
                <div className="space-y-1.5 bg-white p-2.5 rounded-lg border border-slate-200 text-xs">
                  {/* Length Row */}
                  <div className="space-y-0.5">
                    <div className="grid grid-cols-12 gap-1.5 items-center">
                      <span className="col-span-3 text-[10px] font-bold text-slate-700">Length (L):</span>
                      <div className="col-span-4 flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          placeholder="0"
                          value={measLengthFt}
                          onChange={(e) => setMeasLengthFt(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-300 px-1.5 py-1 rounded text-center text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-1 focus:ring-slate-900 outline-none"
                          title="Length in Feet"
                        />
                        <span className="text-[10px] text-slate-400 font-medium shrink-0">ft</span>
                      </div>
                      <div className="col-span-5 flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          max="11.5"
                          step="0.5"
                          placeholder="0"
                          value={measLengthIn}
                          onChange={(e) => setMeasLengthIn(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-300 px-1.5 py-1 rounded text-center text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-1 focus:ring-slate-900 outline-none"
                          title="Length in Inches (e.g. 2 or 2.5)"
                        />
                        <span className="text-[10px] text-slate-400 font-medium shrink-0">in</span>
                      </div>
                    </div>
                    {measLengthFt !== '' && (
                      <div className="text-[9px] text-slate-500 font-mono text-right pr-1">
                        Val: {stoneCalcResult.lengthEffective} (e.g. 15' 2.5" = 15.21)
                      </div>
                    )}
                  </div>

                  {/* Width Row */}
                  <div className="space-y-0.5">
                    <div className="grid grid-cols-12 gap-1.5 items-center">
                      <span className="col-span-3 text-[10px] font-bold text-slate-700">Width (W):</span>
                      <div className="col-span-4 flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          placeholder="0"
                          value={measWidthFt}
                          onChange={(e) => setMeasWidthFt(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-300 px-1.5 py-1 rounded text-center text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-1 focus:ring-slate-900 outline-none"
                          title="Width in Feet"
                        />
                        <span className="text-[10px] text-slate-400 font-medium shrink-0">ft</span>
                      </div>
                      <div className="col-span-5 flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          max="11.5"
                          step="0.5"
                          placeholder="0"
                          value={measWidthIn}
                          onChange={(e) => setMeasWidthIn(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-300 px-1.5 py-1 rounded text-center text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-1 focus:ring-slate-900 outline-none"
                          title="Width in Inches (e.g. 9 or 9.5)"
                        />
                        <span className="text-[10px] text-slate-400 font-medium shrink-0">in</span>
                      </div>
                    </div>
                    {measWidthFt !== '' && (
                      <div className="text-[9px] text-slate-500 font-mono text-right pr-1">
                        Val: {stoneCalcResult.widthEffective} (e.g. 6' 9.5" = 6.79)
                      </div>
                    )}
                  </div>

                  {/* Height Row */}
                  <div className="space-y-0.5">
                    <div className="grid grid-cols-12 gap-1.5 items-center">
                      <span className="col-span-3 text-[10px] font-bold text-slate-700">Height (H):</span>
                      <div className="col-span-4 flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          placeholder="0"
                          value={measHeightFt}
                          onChange={(e) => setMeasHeightFt(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-300 px-1.5 py-1 rounded text-center text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-1 focus:ring-slate-900 outline-none"
                          title="Height in Feet"
                        />
                        <span className="text-[10px] text-slate-400 font-medium shrink-0">ft</span>
                      </div>
                      <div className="col-span-5 flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          max="11.5"
                          step="0.5"
                          placeholder="0"
                          value={measHeightIn}
                          onChange={(e) => setMeasHeightIn(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-300 px-1.5 py-1 rounded text-center text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-1 focus:ring-slate-900 outline-none"
                          title="Height in Inches (e.g. 9)"
                        />
                        <span className="text-[10px] text-slate-400 font-medium shrink-0">in</span>
                      </div>
                    </div>
                    {measHeightFt !== '' && (
                      <div className="text-[9px] text-slate-500 font-mono text-right pr-1">
                        Orig Val: {stoneCalcResult.originalHeightEffective}
                      </div>
                    )}
                  </div>
                </div>

                {/* Down Measurement Summary Breakdown */}
                {measDownInches > 0 && stoneCalcResult.originalBilledCft > 0 && (
                  <div className="bg-amber-50/90 border border-amber-300 rounded-lg p-2 text-[10px] space-y-1 font-mono">
                    <div className="flex justify-between items-center text-slate-700 font-sans">
                      <span>Original Truck Capacity (Full):</span>
                      <strong className="text-slate-900 font-mono">{stoneCalcResult.originalBilledCft} CFT</strong>
                    </div>
                    <div className="flex justify-between items-center bg-white p-1 rounded border border-amber-200">
                      <span className="font-bold text-amber-900 font-sans">Effective Billed ({measDownInches}″ Down):</span>
                      <strong className="text-emerald-700 text-xs font-bold font-mono">{stoneCalcResult.billedCft} CFT</strong>
                    </div>
                    <div className="text-[9px] text-slate-500 italic pt-0.5">
                      Height reduced from {stoneCalcResult.originalHeightFeet}' {stoneCalcResult.originalHeightInches}" by {measDownInches}" down to {stoneCalcResult.heightFeet}' {stoneCalcResult.heightInches}".
                    </div>
                  </div>
                )}
              </div>

              {/* CFT Output & Apply Button */}
              <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] text-slate-600 font-bold block">Calculated Volume:</span>
                    <div className="flex items-center gap-1.5 font-mono font-bold text-sm text-slate-900 mt-0.5">
                      <input
                        type="number"
                        step="1"
                        placeholder={stoneCalcResult.billedCft > 0 ? String(stoneCalcResult.billedCft) : "0"}
                        value={manualCft}
                        onChange={(e) => setManualCft(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-24 bg-slate-50 border border-slate-300 px-2 py-0.5 rounded text-sm font-mono font-extrabold text-blue-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                        title="Auto billed CFT or manual override"
                      />
                      <span className="text-[11px] text-slate-600 font-semibold">CFT</span>
                    </div>
                  </div>

                  {effectiveCft > 0 && (
                    <button
                      type="button"
                      onClick={handleApplyCftToActiveRow}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer shrink-0 flex items-center gap-1"
                      title="Apply this CFT to the invoice item quantity"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Apply Qty ({effectiveCft} CFT)
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* ================= 4. PRODUCT SELECTION SECTOR (Multi-Product Table) ================= */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            {/* Table Action Bar */}
            <div className="bg-slate-50 px-4 py-3 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-xs sm:text-sm text-slate-900">
                    Product Items & Pricing
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-200 text-slate-700">
                    {itemRows.length} Item{itemRows.length > 1 ? 's' : ''}
                  </span>
                </div>

                {/* Dispatch Warehouse / Stock Yard Selector */}
                <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-lg px-2.5 py-1 shadow-2xs">
                  <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span className="text-[10px] font-bold text-slate-600 uppercase">Warehouse / Yard:</span>
                  <select
                    value={selectedWarehouseId}
                    onChange={(e) => setSelectedWarehouseId(e.target.value)}
                    className="bg-transparent text-xs font-bold text-slate-900 outline-none cursor-pointer"
                  >
                    <option value="">Select Warehouse / Yard...</option>
                    {warehouses.map(wh => (
                      <option key={wh.id} value={wh.id}>
                        {wh.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="button"
                onClick={handleAddRow}
                className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>+ Add Product / Item</span>
              </button>
            </div>

            {/* Table Header */}
            <div className="grid grid-cols-12 gap-2 px-4 py-2.5 bg-slate-100/70 border-b border-slate-200 text-[11px] font-bold text-slate-600 font-mono uppercase tracking-wider">
              <div className="col-span-5 sm:col-span-5">PRODUCT / DESCRIPTION</div>
              <div className="col-span-2 sm:col-span-2 text-center">UOM (UNIT)</div>
              <div className="col-span-2 sm:col-span-2 text-right">QUANTITY</div>
              <div className="col-span-2 sm:col-span-2 text-right">RATE (BDT)</div>
              <div className="col-span-1 sm:col-span-1 text-right">ACTION</div>
            </div>

            {/* Table Rows */}
            <div className="divide-y divide-slate-100">
              {itemRows.map((row, index) => {
                const selectedItemObj = items.find(i => i.id === row.itemId);
                const rowIsStock = isStockItem(selectedItemObj, row.itemId, row.itemName, row.uom);
                const rowStockInfo = selectedItemObj
                  ? getAvailableStockForWarehouse(selectedItemObj, selectedWarehouseId, row.uom || selectedItemObj.uom)
                  : null;
                const lineError = stockValidation.lineErrors[index];

                return (
                <div 
                  key={row.id}
                  className={`grid grid-cols-12 gap-2 px-4 py-3 items-start hover:bg-slate-50/80 transition-colors ${lineError ? 'bg-rose-50/40' : ''}`}
                >
                  {/* Col 1: Product Selector */}
                  <div className="col-span-5 sm:col-span-5 space-y-1">
                    <select
                      value={row.itemId}
                      onChange={(e) => handleRowItemSelect(row.id, e.target.value)}
                      className={`w-full bg-white border rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none ${
                        lineError
                          ? 'border-rose-400 text-rose-900 font-semibold'
                          : !row.itemId
                          ? 'border-amber-300 text-slate-500 italic'
                          : 'border-slate-300 text-slate-900 font-medium'
                      }`}
                    >
                      <option value="">-- Select Product --</option>
                      {items
                        .filter(item => (item.status || 'Active') === 'Active')
                        .map(item => {
                          const whStock = getAvailableStockForWarehouse(item, selectedWarehouseId);
                          const isOut = isStockItem(item, item.id, item.name, item.uom) && whStock.availableInBaseUom <= 0;
                          return (
                            <option
                              key={item.id}
                              value={item.id}
                              disabled={isOut && !canSellNegativeStock}
                              className={isOut ? 'text-rose-600 font-medium not-italic' : 'text-slate-900 font-medium not-italic'}
                            >
                              {item.name} ({isOut ? `0 ${item.uom} — Out of stock` : `Available: ${whStock.availableInBaseUom.toLocaleString()} ${item.uom}`})
                            </option>
                          );
                        })}
                      <option value="custom" className="text-blue-600 font-bold not-italic">
                        + Enter Custom Service / Non-Stock Description...
                      </option>
                    </select>

                    {row.itemId === 'custom' && (
                      <input
                        type="text"
                        placeholder="Type custom service description..."
                        value={row.itemName}
                        onChange={(e) => handleRowDescChange(row.id, e.target.value)}
                        className="w-full bg-white border border-blue-300 rounded px-2 py-1 text-slate-900 text-xs focus:outline-none"
                      />
                    )}

                    {rowIsStock && rowStockInfo && (
                      <div className="flex flex-wrap items-center gap-2 text-[10px] font-mono">
                        <span className={rowStockInfo.availableInBaseUom <= 0 ? 'text-rose-600 font-bold' : 'text-emerald-700 font-semibold'}>
                          Available in {selectedWarehouseObj?.name || 'Yard'}: {rowStockInfo.availableInTargetUom.toLocaleString()} {row.uom || selectedItemObj?.uom}
                          {rowStockInfo.targetUom !== rowStockInfo.baseUom ? ` (${rowStockInfo.availableInBaseUom.toLocaleString()} ${rowStockInfo.baseUom})` : ''}
                        </span>
                      </div>
                    )}

                    {lineError && (
                      <div className="text-[11px] text-rose-600 font-semibold bg-rose-50 border border-rose-200 rounded px-2 py-1 flex items-start gap-1">
                        <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                        <span>{lineError.message}</span>
                      </div>
                    )}
                  </div>

                  {/* Col 2: UOM Selector */}
                  <div className="col-span-2 sm:col-span-2 text-center">
                    <select
                      value={row.uom}
                      onChange={(e) => {
                        if (e.target.value === '__add_new__') {
                          const custom = window.prompt('Enter new UOM name (e.g. Bag, Sqft, Trip, Truck):');
                          if (custom && custom.trim()) {
                            addUOM(custom.trim());
                            handleRowUomChange(row.id, custom.trim());
                          }
                        } else {
                          handleRowUomChange(row.id, e.target.value);
                        }
                      }}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-mono text-xs text-center focus:ring-1 focus:ring-blue-500 outline-none"
                    >
                      <option value="">Select UOM...</option>
                      {availableUoms.map(u => (
                        <option key={u} value={u}>{u}</option>
                      ))}
                      <option value="__add_new__">+ New UOM...</option>
                    </select>
                  </div>

                  {/* Col 3: Quantity */}
                  <div className="col-span-2 sm:col-span-2 text-right">
                    <input
                      type="number"
                      min="0"
                      step="any"
                      placeholder="0"
                      value={row.quantity === 0 ? '' : row.quantity}
                      onChange={(e) => handleRowQtyChange(row.id, e.target.value === '' ? 0 : Number(e.target.value))}
                      className={`w-full bg-white border rounded-lg p-2 text-right font-mono font-bold text-xs focus:ring-1 outline-none ${
                        lineError
                          ? 'border-rose-400 text-rose-700 focus:ring-rose-500 bg-rose-50/40'
                          : 'border-slate-300 text-slate-900 focus:ring-blue-500'
                      }`}
                    />
                    <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                      {row.uom}
                    </span>
                  </div>

                  {/* Col 4: Unit Rate & Computed Amount */}
                  <div className="col-span-2 sm:col-span-2 text-right">
                    <input
                      type="number"
                      min="0"
                      step="any"
                      placeholder="0"
                      value={row.unitPrice === 0 ? '' : row.unitPrice}
                      onChange={(e) => handleRowRateChange(row.id, e.target.value === '' ? 0 : Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-right font-mono font-semibold text-slate-900 text-xs focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                    <span className="text-[10px] font-mono font-bold text-blue-700 block mt-0.5">
                      = ৳{(row.amount || 0).toLocaleString()}
                    </span>
                  </div>

                  {/* Col 5: Delete Row */}
                  <div className="col-span-1 sm:col-span-1 text-right">
                    {itemRows.length > 1 ? (
                      <button
                        type="button"
                        onClick={() => handleRemoveRow(row.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Delete product row"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-300 font-mono pr-2">1</span>
                    )}
                  </div>
                </div>
              );
              })}
            </div>

            {/* Admin Negative Stock Reason Box (Only shown when Allow Negative Stock is ON, user is Admin, and stock is exceeded) */}
            {stockValidation.requiresNegativeStockApproval && canSellNegativeStock && (
              <div className="p-3.5 bg-amber-50 border-t border-amber-200 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Admin Negative Stock Override — Mandatory Reason Required *</span>
                </div>
                <input
                  type="text"
                  value={negativeStockReason}
                  onChange={(e) => setNegativeStockReason(e.target.value)}
                  placeholder="Enter mandatory reason for selling above available stock (saved on invoice audit trail)..."
                  className="w-full bg-white border border-amber-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:ring-1 focus:ring-amber-500 outline-none"
                />
              </div>
            )}

            {/* Quick Add Footer inside table */}
            <div className="bg-slate-50/60 p-3 px-4 border-t border-slate-200 flex items-center justify-between">
              <button
                type="button"
                onClick={handleAddRow}
                className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add another product item line</span>
              </button>

              <div className="text-slate-600 font-mono text-xs">
                Line Items Subtotal: <strong className="text-slate-900 text-sm">৳{subtotal.toLocaleString()}</strong>
              </div>
            </div>
          </div>

          {/* ================= 5. PAYMENT & SETTLEMENT TERMS ================= */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 pt-2">
            
            {/* Left: Dynamic Settlement Panel matching selected Invoice Type */}
            <div className="md:col-span-7 bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3.5">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-slate-900 flex items-center gap-1.5">
                    <Banknote className="w-4 h-4 text-blue-600" />
                    Payment & Settlement Terms
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Selected Mode: <strong className="text-slate-800">{invoiceType}</strong> (Changed via top Invoice Type dropdown)
                  </p>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                  invoiceType === 'Cash Only' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' :
                  invoiceType === 'Partial Payment' ? 'bg-amber-100 text-amber-800 border-amber-300' :
                  invoiceType === 'Due 30 Days' ? 'bg-rose-100 text-rose-800 border-rose-300' :
                  'bg-indigo-100 text-indigo-800 border-indigo-300'
                }`}>
                  {invoiceType}
                </span>
              </div>

              {/* 1. Cash Only */}
              {invoiceType === 'Cash Only' && (
                <div className="p-3.5 bg-white border border-emerald-200 rounded-xl space-y-3 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span className="font-bold text-xs text-emerald-900">
                        Cash Only Settlement
                      </span>
                    </div>
                    <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">
                      100% Fully Settled
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600">
                    This invoice is settled in full upon delivery / billing. No outstanding debt will be added to the customer ledger.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Settlement Method:
                      </label>
                      <select
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value as any)}
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 font-medium text-slate-800 text-xs focus:ring-1 focus:ring-emerald-500 outline-none"
                      >
                        <option value="">Select Settlement Method...</option>
                        <option value="Cash">Cash in Hand</option>
                        <option value="Bank Transfer">Bank Transfer (RTGS / BEFTN)</option>
                        <option value="Cheque">Bank Cheque</option>
                        <option value="Mobile Banking">bKash / Nagad</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        {paymentMethod === 'Cheque' ? 'Cheque No.:' : 'Reference / Trx No. (Optional):'}
                      </label>
                      <input
                        type="text"
                        placeholder={paymentMethod === 'Cheque' ? 'e.g. CQ-902812' : 'e.g. MR-2026-0812 / Cash Slip'}
                        value={paymentRef}
                        onChange={(e) => setPaymentRef(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono text-slate-800 text-xs focus:ring-1 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  {/* Required Deposit To Account dropdown for Cash Only (shown ONLY when cashReceivedNow > 0) */}
                  {cashReceivedNow > 0 && (
                    <div className="pt-2 border-t border-slate-100">
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Deposit To Account <span className="text-rose-500">*</span>:
                      </label>
                      <select
                        value={selectedDepositAccountId}
                        onChange={(e) => setSelectedDepositAccountId(e.target.value)}
                        required
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 font-medium text-slate-800 text-xs focus:ring-1 focus:ring-emerald-500 outline-none"
                      >
                        <option value="">Select Deposit Account...</option>
                        {filteredDepositAccounts.length === 0 ? (
                          <option value="">No account found</option>
                        ) : (
                          filteredDepositAccounts.map(acc => (
                            <option key={acc.id} value={acc.id}>
                              {acc.bankName} ({acc.accountNumber}) {acc.branch ? `— ${acc.branch}` : ''} | Balance: ৳{(acc.ledgerBalance || 0).toLocaleString()}
                            </option>
                          ))
                        )}
                      </select>
                      <span className="text-[10px] text-slate-400 mt-0.5 block">
                        {currentUser?.role === 'admin' ? 'Admin View: All accounts visible' : `Branch Account: ${currentUser?.branch || 'Local'}`}
                      </span>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100 font-mono">
                    <span className="text-emerald-700">Immediate Collection: <strong>৳{cashReceivedNow.toLocaleString()}</strong></span>
                    {adjustedAdvance > 0 && (
                      <span className="text-blue-700">Advance Adjusted: <strong>৳{adjustedAdvance.toLocaleString()}</strong></span>
                    )}
                    <span className="text-slate-500">Customer Due Balance: <strong>৳{actualDue.toLocaleString()}</strong></span>
                  </div>
                </div>
              )}

              {/* 2. Partial Payment */}
              {invoiceType === 'Partial Payment' && (
                <div className="p-3.5 bg-white border border-amber-200 rounded-xl space-y-3 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-600" />
                      <span className="font-bold text-xs text-amber-900">
                        Partial Payment
                      </span>
                    </div>
                    <span className="text-[10px] font-mono bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-bold">
                      Partial Cash + Credit
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-semibold text-slate-700">
                          Cash/Advance Received:
                        </label>
                        <div className="flex gap-1">
                          <button
                            type="button"
                            onClick={() => setPaidAmount(Math.round(grandTotal * 0.25))}
                            className="text-[9px] px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded hover:bg-slate-200 font-mono text-slate-700 cursor-pointer"
                          >
                            25%
                          </button>
                          <button
                            type="button"
                            onClick={() => setPaidAmount(Math.round(grandTotal * 0.5))}
                            className="text-[9px] px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded hover:bg-slate-200 font-mono text-slate-700 cursor-pointer"
                          >
                            50%
                          </button>
                          <button
                            type="button"
                            onClick={() => setPaidAmount(Math.round(grandTotal * 0.75))}
                            className="text-[9px] px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded hover:bg-slate-200 font-mono text-slate-700 cursor-pointer"
                          >
                            75%
                          </button>
                        </div>
                      </div>
                      <input
                        type="number"
                        min="0"
                        max={grandTotal}
                        value={paidAmount}
                        onChange={(e) => setPaidAmount(Number(e.target.value))}
                        className="w-full bg-slate-50 border border-amber-300 rounded-lg p-2 font-mono font-bold text-slate-900 text-xs focus:ring-1 focus:ring-amber-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Payment Method:
                      </label>
                      <select
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value as any)}
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 font-medium text-slate-800 text-xs focus:ring-1 focus:ring-amber-500 outline-none"
                      >
                        <option value="">Select Payment Method...</option>
                        <option value="Cash">Cash in Hand</option>
                        <option value="Bank Transfer">Bank Transfer (RTGS / BEFTN)</option>
                        <option value="Cheque">Bank Cheque</option>
                        <option value="Mobile Banking">bKash / Nagad</option>
                      </select>
                    </div>
                  </div>

                  {/* Required Deposit To dropdown shown ONLY when cashReceivedNow > 0 */}
                  {cashReceivedNow > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                      <div>
                        <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                          Deposit To Account <span className="text-rose-500">*</span>:
                        </label>
                        <select
                          value={selectedDepositAccountId}
                          onChange={(e) => setSelectedDepositAccountId(e.target.value)}
                          required
                          className="w-full bg-white border border-slate-300 rounded-lg p-2 font-medium text-slate-800 text-xs focus:ring-1 focus:ring-amber-500 outline-none"
                        >
                          <option value="">Select Deposit Account...</option>
                          {filteredDepositAccounts.length === 0 ? (
                            <option value="">No account found</option>
                          ) : (
                            filteredDepositAccounts.map(acc => (
                              <option key={acc.id} value={acc.id}>
                                {acc.bankName} ({acc.accountNumber}) {acc.branch ? `— ${acc.branch}` : ''} | Balance: ৳{(acc.ledgerBalance || 0).toLocaleString()}
                              </option>
                            ))
                          )}
                        </select>
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          {currentUser?.role === 'admin' ? 'Admin View: All accounts visible' : `Branch Account: ${currentUser?.branch || 'Local'}`}
                        </span>
                      </div>

                      <div>
                        <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                          {paymentMethod === 'Cheque' ? 'Cheque No.:' : 'Reference / Trx No. (Optional):'}
                        </label>
                        <input
                          type="text"
                          placeholder={paymentMethod === 'Cheque' ? 'e.g. CQ-902812' : 'e.g. MR-2026-0812 / Trx Ref'}
                          value={paymentRef}
                          onChange={(e) => setPaymentRef(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono text-slate-800 text-xs focus:ring-1 focus:ring-amber-500 outline-none"
                        />
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100 font-mono">
                    <span className="text-emerald-700">Cash Received Now: <strong>৳{actualPaid.toLocaleString()}</strong></span>
                    <span className="text-rose-600">Remaining Due Balance: <strong>৳{actualDue.toLocaleString()}</strong></span>
                  </div>

                  <p className="text-[11px] text-slate-500">
                    Remaining balance of ৳{actualDue.toLocaleString()} will be posted to the customer ledger with credit grace period until <strong className="text-slate-800">{dueDate}</strong>.
                  </p>
                </div>
              )}

              {/* 3. Due 30 Days */}
              {invoiceType === 'Due 30 Days' && (
                <div className="p-3.5 bg-white border border-rose-200 rounded-xl space-y-3 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-600" />
                      <span className="font-bold text-xs text-rose-900">
                        100% Credit Sales — Due 30 Days
                      </span>
                    </div>
                    <span className="text-[10px] font-mono bg-rose-100 text-rose-800 px-2 py-0.5 rounded font-bold">
                      Terms: 30 Days
                    </span>
                  </div>

                  <div className="p-2.5 bg-rose-50/70 border border-rose-200 rounded-lg text-rose-800 text-[11px] flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>Customer Ledger will be debited with <strong>৳{grandTotal.toLocaleString()}</strong></span>
                    </div>
                    <span className="font-mono text-[10px] bg-white px-2 py-0.5 rounded border border-rose-200">
                      Due: {dueDate}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 font-mono">
                      <span className="text-[10px] text-slate-500 block uppercase font-bold">Current Due:</span>
                      <strong className="text-sm text-slate-800">৳{selectedCustomer?.currentBalance?.toLocaleString() || 0}</strong>
                    </div>
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 font-mono">
                      <span className="text-[10px] text-slate-500 block uppercase font-bold">+ This Invoice:</span>
                      <strong className="text-sm text-rose-700">৳{grandTotal.toLocaleString()}</strong>
                    </div>
                    <div className="p-2.5 bg-rose-50/60 rounded-lg border border-rose-200 font-mono">
                      <span className="text-[10px] text-rose-800 block uppercase font-bold">Total Due:</span>
                      <strong className="text-sm text-rose-900 font-black">৳{((selectedCustomer?.currentBalance || 0) + grandTotal).toLocaleString()}</strong>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. Payment 10 Days */}
              {invoiceType === 'Payment 10 Days' && (
                customerAdvance > 0 ? (
                  /* Customer already has an Advance Deposit: Show Advance Fund Settlement Card */
                  <div className="p-3.5 bg-gradient-to-br from-emerald-50/90 to-teal-50/70 border border-emerald-300 rounded-xl space-y-2.5 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-emerald-600" />
                        <span className="font-bold text-xs text-emerald-950">
                          Advance Fund Adjustment
                        </span>
                      </div>
                      <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
                        Advance Available
                      </span>
                    </div>

                    <p className="text-[11px] text-emerald-900 leading-snug">
                      <strong>৳{adjustedAdvance.toLocaleString()}</strong> is being automatically deducted and adjusted from the customer's advance balance against this invoice.
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono pt-1">
                      <div className="bg-white p-2 rounded-lg border border-emerald-200 shadow-2xs">
                        <span className="text-[10px] text-slate-500 block font-sans">Customer Advance:</span>
                        <span className="font-bold text-slate-800">৳{customerAdvance.toLocaleString()}</span>
                      </div>
                      <div className="bg-white p-2 rounded-lg border border-emerald-200 shadow-2xs">
                        <span className="text-[10px] text-slate-500 block font-sans">Current Invoice:</span>
                        <span className="font-bold text-slate-800">৳{grandTotal.toLocaleString()}</span>
                      </div>
                      <div className="bg-indigo-50 p-2 rounded-lg border border-indigo-200 shadow-2xs">
                        <span className="text-[10px] text-indigo-700 block font-sans">Advance Deducted:</span>
                        <span className="font-bold text-indigo-900">- ৳{adjustedAdvance.toLocaleString()}</span>
                      </div>
                      <div className="bg-emerald-100/90 p-2 rounded-lg border border-emerald-300 shadow-2xs">
                        <span className="text-[10px] text-emerald-800 block font-sans font-bold">Remaining Advance:</span>
                        <span className="font-black text-emerald-950">৳{remainingCustomerAdvance.toLocaleString()}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] pt-1 border-t border-emerald-200/80 font-mono">
                      <span className="text-emerald-900 font-semibold">
                        Paid from Advance: <strong>৳{actualPaid.toLocaleString()}</strong>
                      </span>
                      <span className={actualDue === 0 ? "text-emerald-700 font-bold" : "text-amber-700 font-bold"}>
                        Invoice Due: <strong>৳{actualDue.toLocaleString()} {actualDue === 0 ? '(Fully Paid)' : `(Due within 10 days: ${dueDate})`}</strong>
                      </span>
                    </div>
                  </div>
                ) : (
                  /* Customer does NOT have prior advance: Show standard upfront/10-day inputs */
                  <div className="p-3.5 bg-white border border-indigo-200 rounded-xl space-y-3 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-indigo-600" />
                        <span className="font-bold text-xs text-indigo-900">
                          Payment 10 Days
                        </span>
                      </div>
                      <span className="text-[10px] font-mono bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded font-bold">
                        10 Days Term
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-600">
                      Applicable for customers with no prior due balance or under a 10-day payment agreement. Payment must be settled within <strong>10 days ({dueDate})</strong> of the invoice date.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[11px] font-semibold text-slate-700">
                            Advance / Upfront Paid Amount:
                          </label>
                          <div className="flex gap-1">
                            <button
                              type="button"
                              onClick={() => setPaidAmount(grandTotal)}
                              className="text-[9px] px-1.5 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-800 rounded font-bold hover:bg-emerald-200 cursor-pointer"
                            >
                              Full Advance
                            </button>
                            <button
                              type="button"
                              onClick={() => setPaidAmount(0)}
                              className="text-[9px] px-1.5 py-0.5 bg-slate-100 border border-slate-200 text-slate-700 rounded font-mono hover:bg-slate-200 cursor-pointer"
                            >
                              0 Paid (10 Days Due)
                            </button>
                          </div>
                        </div>
                        <input
                          type="number"
                          min="0"
                          max={grandTotal}
                          value={paidAmount}
                          onChange={(e) => setPaidAmount(Number(e.target.value))}
                          className="w-full bg-slate-50 border border-indigo-300 rounded-lg p-2 font-mono font-bold text-slate-900 text-xs focus:ring-1 focus:ring-indigo-500 outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                          Payment Method:
                        </label>
                        <select
                          value={paymentMethod}
                          onChange={(e) => setPaymentMethod(e.target.value as any)}
                          className="w-full bg-white border border-slate-300 rounded-lg p-2 font-medium text-slate-800 text-xs focus:ring-1 focus:ring-indigo-500 outline-none"
                        >
                          <option value="">Select Payment Method...</option>
                          <option value="Bank Transfer">Bank Transfer (RTGS / BEFTN)</option>
                          <option value="Cash">Cash in Hand</option>
                          <option value="Cheque">Bank Cheque</option>
                          <option value="Mobile Banking">bKash / Nagad</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100 font-mono">
                      <span className="text-indigo-800">
                        Paid Now: <strong>৳{actualPaid.toLocaleString()}</strong>
                      </span>
                      <span className={actualDue === 0 ? "text-emerald-700 font-bold" : "text-amber-700 font-bold"}>
                        Remaining Due: <strong>৳{actualDue.toLocaleString()} {actualDue === 0 ? '(Fully Paid)' : `(Due within 10 days: ${dueDate})`}</strong>
                      </span>
                    </div>
                  </div>
                )
              )}
            </div>

            {/* Right: Financial Summary Totals */}
            <div className="md:col-span-5 bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
              <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block">
                FINANCIAL SUMMARY
              </span>

              {/* Subtotal */}
              <div className="flex justify-between items-center text-slate-600 font-mono">
                <span>Items Subtotal:</span>
                <span className="font-bold text-slate-900 text-xs">
                  ৳{subtotal.toLocaleString()}
                </span>
              </div>

              {/* Tax / VAT % */}
              <div className="flex justify-between items-center text-slate-600 font-mono">
                <div className="flex items-center gap-1.5">
                  <span>Tax / VAT:</span>
                  <select
                    value={vatPercent}
                    onChange={(e) => setVatPercent(e.target.value === '' ? '' : Number(e.target.value))}
                    className="bg-white border border-slate-300 rounded px-1.5 py-0.5 text-slate-800 font-mono text-[10px] outline-none"
                  >
                    <option value="">Select %</option>
                    <option value={0}>0%</option>
                    <option value={5}>5%</option>
                    <option value={7.5}>7.5%</option>
                    <option value={15}>15%</option>
                  </select>
                </div>
                <span className="text-slate-800 font-semibold">
                  ৳{vatAmount.toLocaleString()}
                </span>
              </div>

              {/* Discount */}
              <div className="flex justify-between items-center text-slate-600 font-mono">
                <div className="flex items-center gap-1.5">
                  <span>Discount:</span>
                  <input
                    type="number"
                    min="0"
                    value={discountAmount}
                    onChange={(e) => setDiscountAmount(Math.max(0, Number(e.target.value)))}
                    className="w-20 bg-white border border-slate-300 rounded px-1.5 py-0.5 text-right text-slate-800 font-mono text-[10px] outline-none"
                  />
                </div>
                <span className="text-slate-700">
                  - ৳{discountAmount.toLocaleString()}
                </span>
              </div>

              {/* Grand Total (Prominent & Clear) */}
              <div className="flex justify-between items-baseline pt-3 pb-2 border-t-2 border-b border-slate-200">
                <span className="text-sm font-extrabold text-slate-900 uppercase tracking-wide font-mono">
                  TOTAL AMOUNT:
                </span>
                <span className="text-2xl font-black text-slate-900 font-mono">
                  ৳{grandTotal.toLocaleString()}
                </span>
              </div>

              {/* Advance Deducted / Adjusted */}
              {customerAdvance > 0 && (
                <div className="space-y-1.5 bg-indigo-50/80 p-2.5 rounded-lg border border-indigo-200">
                  <div className="flex justify-between items-center text-[11px] font-mono text-slate-700">
                    <span>Available Customer Advance:</span>
                    <span className="font-bold text-emerald-700">৳{customerAdvance.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-mono text-indigo-900 font-bold">
                    <span>Advance Adjusted (Dr 2050 / Cr 1050):</span>
                    <div className="flex items-center gap-1">
                      <span>৳</span>
                      <input
                        type="number"
                        min="0"
                        max={maxAdjustableAdvance}
                        value={customAdvanceInput !== '' ? customAdvanceInput : maxAdjustableAdvance}
                        onChange={(e) => setCustomAdvanceInput(e.target.value)}
                        className="w-24 bg-white border border-indigo-300 rounded px-1.5 py-0.5 text-right text-indigo-900 font-mono text-xs font-bold outline-none"
                      />
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-[11px] font-mono text-emerald-800 pt-1 border-t border-indigo-200/60">
                    <span>Remaining Customer Advance:</span>
                    <span className="font-black">৳{remainingCustomerAdvance.toLocaleString()}</span>
                  </div>
                  {advanceValidationError && (
                    <div className="text-[10px] text-rose-600 font-semibold pt-1">
                      {advanceValidationError}
                    </div>
                  )}
                </div>
              )}

              {/* Paid and Net Due */}
              <div className="flex justify-between items-center text-[11px] font-mono text-emerald-700 pt-1">
                <span>Paid / Settled:</span>
                <span className="font-bold">৳{actualPaid.toLocaleString()}</span>
              </div>

              <div className="flex justify-between items-center text-xs font-mono font-bold">
                <span className={actualDue === 0 ? "text-slate-600" : "text-rose-600"}>
                  Net Invoice Due:
                </span>
                <span className={`text-sm font-black ${actualDue === 0 ? "text-emerald-700" : "text-rose-600"}`}>
                  ৳{actualDue.toLocaleString()} {actualDue === 0 ? '(Fully Paid)' : ''}
                </span>
              </div>

              {/* PROMINENT REMAINING ADVANCE BALANCE HIGHLIGHT */}
              {customerAdvance > 0 && remainingCustomerAdvance > 0 && (
                <div className="pt-2 border-t-2 border-emerald-300">
                  <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-xl p-3 shadow-md space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold flex items-center gap-1.5 text-emerald-100">
                        <Sparkles className="w-4 h-4 text-emerald-300 animate-pulse" />
                        Remaining Advance Balance:
                      </span>
                      <span className="text-lg font-black font-mono tracking-tight text-white">
                        ৳{remainingCustomerAdvance.toLocaleString()}
                      </span>
                    </div>
                    <p className="text-[10px] text-emerald-100 font-medium leading-tight pt-0.5 border-t border-emerald-500/60">
                      Previous Advance ৳{customerAdvance.toLocaleString()} - Adjusted ৳{adjustedAdvance.toLocaleString()} = Remaining <strong>৳{remainingCustomerAdvance.toLocaleString()} credited to customer advance</strong>.
                    </p>
                  </div>
                </div>
              )}

              {/* If Advance is exhausted and there is remaining due */}
              {customerAdvance > 0 && remainingCustomerAdvance === 0 && actualDue > 0 && (
                <div className="pt-2 border-t-2 border-rose-300">
                  <div className="bg-rose-50 border border-rose-300 text-rose-950 rounded-xl p-3 shadow-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-rose-900">
                        Remaining Customer Due:
                      </span>
                      <span className="text-base font-black font-mono text-rose-700">
                        ৳{actualDue.toLocaleString()}
                      </span>
                    </div>
                    <p className="text-[10px] text-rose-700 leading-tight">
                      After adjusting the full prior advance of ৳{customerAdvance.toLocaleString()}, the remaining ৳{actualDue.toLocaleString()} will be added as due.
                    </p>
                  </div>
                </div>
              )}

              {/* Prior Customer Balance if any */}
              {selectedCustomer && (selectedCustomer.currentBalance || 0) > 0 && (
                <div className="pt-2 border-t border-slate-200 space-y-1">
                  <div className="flex justify-between items-center text-[11px] font-mono text-slate-600">
                    <span>Previous Due:</span>
                    <span className="font-bold text-slate-800">৳{(selectedCustomer.currentBalance || 0).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-mono text-rose-800 bg-rose-50 p-1.5 rounded-lg border border-rose-200 font-bold">
                    <span>Total Customer Balance:</span>
                    <span className="font-black text-sm">৳{((selectedCustomer.currentBalance || 0) + actualDue).toLocaleString()}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ================= 6. PAYMENT DETAILS & NOTES ================= */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-200 text-xs">
            {/* Bank Details */}
            {(() => {
              const activeAcc = accessibleAccounts.find(a => a.id === selectedDepositAccountId);
              return (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1">
                  <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block">
                    SETTLEMENT / DEPOSIT ACCOUNT DETAILS
                  </span>
                  <div className="text-slate-700 font-medium">
                    Method: <span className="font-bold text-slate-900">{cashReceivedNow > 0 ? paymentMethod : 'Credit / Advance'}</span>
                  </div>
                  {cashReceivedNow > 0 && activeAcc ? (
                    <>
                      <div className="text-slate-700 font-medium">
                        Account: <span className="font-bold text-slate-900">{activeAcc.bankName} {activeAcc.branch ? `(${activeAcc.branch})` : ''}</span>
                      </div>
                      <div className="text-slate-600 font-mono text-[11px]">
                        A/C: <span className="font-bold text-slate-900">{activeAcc.accountNumber}</span> {activeAcc.routingNumber ? `| Routing: ${activeAcc.routingNumber}` : ''}
                      </div>
                    </>
                  ) : (
                    <div className="text-slate-500 italic text-[11px]">
                      {cashReceivedNow > 0 ? 'Cash in Hand' : customerAdvance > 0 ? 'Advance Balance Adjustment' : '30 Days Credit'}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* Notes & Terms */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1">
              <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block">
                INVOICE NOTES & REMARKS
              </span>
              <textarea
                rows={2}
                value={invoiceNotes}
                onChange={(e) => setInvoiceNotes(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-700 text-xs focus:ring-1 focus:ring-blue-500 outline-none"
                placeholder="Enter invoice notes or terms..."
              />
            </div>
          </div>
        </div>

        {/* Posting Error Banner */}
        {postingError && (
          <div className="mx-5 mb-2 p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs flex items-start gap-2 shadow-xs animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <strong className="block font-bold">Posting Error:</strong>
              <p className="mt-0.5 font-medium">{postingError}</p>
            </div>
            <button
              type="button"
              onClick={() => setPostingError(null)}
              className="text-rose-500 hover:text-rose-700 font-bold p-1"
            >
              ✕
            </button>
          </div>
        )}

        {/* ================= 7. Sticky Bottom Confirmation Footer ================= */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-600 font-mono">
            {itemRows.length} Product(s) Selected | Grand Total: <strong className="text-slate-900 font-bold">BDT {grandTotal.toLocaleString()}</strong>
            {customerAdvance > 0 ? (
              remainingCustomerAdvance > 0 ? (
                <> | Adjusted: <strong className="text-indigo-700 font-bold">BDT {adjustedAdvance.toLocaleString()}</strong> | Remaining Advance: <strong className="text-emerald-700 font-black">BDT {remainingCustomerAdvance.toLocaleString()}</strong></>
              ) : (
                <> | Adjusted: <strong className="text-indigo-700 font-bold">BDT {adjustedAdvance.toLocaleString()}</strong> | Invoice Due: <strong className="text-rose-600 font-bold">BDT {actualDue.toLocaleString()}</strong></>
              )
            ) : (
              <> | Due: <strong className="text-rose-600 font-bold">BDT {actualDue.toLocaleString()}</strong></>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              data-modal-close="true"
              onClick={handleSafeClose}
              disabled={isSubmitting}
              className="flex-1 sm:flex-initial px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleBuildAndSubmit(true)}
              className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Printer className="w-3.5 h-3.5" />}
              <span>Save & Print</span>
            </button>
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleBuildAndSubmit(false)}
              className="flex-1 sm:flex-initial px-6 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <span>Create Invoice</span>
                  <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};
