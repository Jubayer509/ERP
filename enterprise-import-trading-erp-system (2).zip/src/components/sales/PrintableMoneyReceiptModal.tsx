import React, { useState } from 'react';
import { Printer, X, CheckCircle2, Building2, CreditCard, Share2, FileCheck } from 'lucide-react';
import { Customer, CustomerPayment } from '../../types/erp';
import { getBankAccounts } from '../../utils/bankAccountStorage';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface PrintableMoneyReceiptModalProps {
  payment: CustomerPayment;
  customer?: Customer;
  onClose: () => void;
}

// Convert numbers to words (English/Bengali standard)
function numberToBDTWords(num: number): string {
  if (num === 0) return 'Zero Taka Only';
  const units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertBelowThousand(n: number): string {
    let str = '';
    if (n >= 100) {
      str += units[Math.floor(n / 100)] + ' Hundred ';
      n %= 100;
    }
    if (n >= 20) {
      str += tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + units[n % 10] : '');
    } else if (n > 0) {
      str += units[n];
    }
    return str.trim();
  }

  let crore = Math.floor(num / 10000000);
  let remainder = num % 10000000;
  let lakh = Math.floor(remainder / 100000);
  remainder %= 100000;
  let thousand = Math.floor(remainder / 1000);
  let rest = remainder % 1000;

  let words = '';
  if (crore > 0) words += convertBelowThousand(crore) + ' Crore ';
  if (lakh > 0) words += convertBelowThousand(lakh) + ' Lakh ';
  if (thousand > 0) words += convertBelowThousand(thousand) + ' Thousand ';
  if (rest > 0) words += convertBelowThousand(rest);

  return (words.trim() + ' Taka Only');
}

export const PrintableMoneyReceiptModal: React.FC<PrintableMoneyReceiptModalProps> = ({
  payment,
  customer,
  onClose
}) => {
  const [copied, setCopied] = useState(false);
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  React.useEffect(() => {
    return subscribeCompanyProfile(setCompanyProfile);
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const handleCopy = () => {
    const text = `*MONEY RECEIPT: ${payment.receiptNumber}*\nCustomer: ${customer?.tradeName || payment.customerTradeName || payment.customerName}\nDate: ${payment.paymentDate}\nAmount: BDT ${payment.amount.toLocaleString()}\nMethod: ${payment.paymentMethod}${payment.bankName ? ` (${payment.bankName})` : ''}\nStatus: ${payment.status}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <ModalWrapper
      onClose={onClose}
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in"
    >
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden flex flex-col my-auto max-h-[95vh]">
        {/* Modal Toolbar (hidden in print) */}
        <div className="print:hidden px-4 py-3 bg-slate-800 text-white flex items-center justify-between border-b border-slate-700 shrink-0">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold font-mono tracking-wide">
              OFFICIAL MONEY RECEIPT: {payment.receiptNumber}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopy}
              className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              {copied ? 'Copied!' : 'Copy Summary'}
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Receipt / PDF
            </button>
            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors shrink-0 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper */}
        <div className="p-6 sm:p-8 bg-white text-slate-900 overflow-y-auto font-sans leading-normal">
          <div className="border-2 border-slate-800 rounded-lg p-6 sm:p-7 relative">
            {/* Watermark / Seal */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03] select-none">
              <span className="text-8xl font-black tracking-widest text-slate-900 uppercase">RECEIVED</span>
            </div>

            {/* Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start border-b-2 border-slate-800 pb-4 gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-indigo-700" />
                  <span className="text-lg font-black tracking-tight text-slate-900">{companyProfile.companyName}</span>
                </div>
                <p className="text-[11px] text-slate-600 font-medium">
                  {companyProfile.address}
                </p>
                <p className="text-[11px] text-slate-500 font-mono">
                  Mobile: {companyProfile.mobile}
                </p>
              </div>
              <div className="text-right shrink-0">
                <div className="inline-block px-3 py-1 bg-emerald-100 text-emerald-800 font-extrabold text-sm uppercase tracking-wider rounded border border-emerald-300">
                  OFFICIAL MONEY RECEIPT
                </div>
                <div className="mt-2 text-xs font-mono">
                  <span className="text-slate-500">Receipt No: </span>
                  <span className="font-bold text-slate-900">{payment.receiptNumber}</span>
                </div>
                <div className="text-xs font-mono">
                  <span className="text-slate-500">Date: </span>
                  <span className="font-bold text-slate-900">{payment.paymentDate}</span>
                </div>
              </div>
            </div>

            {/* Receipt Body */}
            <div className="py-5 space-y-4 text-xs">
              {/* Customer line */}
              <div className="flex items-baseline gap-2 border-b border-dashed border-slate-300 pb-2">
                <span className="text-slate-500 font-semibold whitespace-nowrap">Received with thanks from:</span>
                <span className="font-bold text-slate-900 text-sm flex-1">
                  {customer?.name || payment.customerName} {customer?.tradeName ? `(${customer.tradeName})` : ''}
                </span>
              </div>

              {/* Address */}
              <div className="flex items-baseline gap-2 border-b border-dashed border-slate-300 pb-2">
                <span className="text-slate-500 font-semibold whitespace-nowrap">Address / City:</span>
                <span className="text-slate-800 flex-1">
                  {customer?.address ? `${customer.address}, ${customer.city}` : 'Corporate Customer Account'}
                </span>
              </div>

              {/* Amount In Figures & Words */}
              <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                  <span className="text-[11px] text-slate-500 block uppercase tracking-wider font-semibold">Amount In Words:</span>
                  <span className="font-bold text-slate-900 text-xs sm:text-sm italic">
                    {numberToBDTWords(payment.amount)}
                  </span>
                </div>
                <div className="text-right shrink-0 bg-emerald-600 text-white px-4 py-2 rounded-md shadow-xs">
                  <span className="text-[10px] uppercase tracking-wider block opacity-90 font-medium">Total Received Amount</span>
                  <span className="text-base font-mono font-black">
                    BDT {payment.amount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Payment Details Grid */}
              {(() => {
                const isBank = payment.paymentMethod === 'Bank Transfer' || payment.paymentMethod === 'Cheque';
                const allAccounts = getBankAccounts();
                const matchedAcc = allAccounts.find(a => a.id === payment.bankAccountId) ||
                  allAccounts.find(a => payment.bankName && a.bankName.toLowerCase().includes(payment.bankName.toLowerCase()));

                return (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div className="p-3 bg-white rounded border border-slate-200 space-y-1.5">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Payment Mode:</span>
                        <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                          {isBank ? payment.paymentMethod : 'Cash'}
                        </span>
                      </div>
                      {isBank && (matchedAcc || payment.bankName) && (
                        <>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Bank & Branch:</span>
                            <span className="font-semibold text-slate-800 text-right">
                              {matchedAcc?.bankName || payment.bankName} {matchedAcc?.branch ? `(${matchedAcc.branch})` : payment.branchName ? `(${payment.branchName})` : ''}
                            </span>
                          </div>
                          {matchedAcc?.accountNumber && (
                            <div className="flex justify-between font-mono text-[11px]">
                              <span className="text-slate-500">Account No:</span>
                              <span className="font-bold text-slate-900">
                                {matchedAcc.accountNumber}
                              </span>
                            </div>
                          )}
                        </>
                      )}
                      {payment.chequeNo && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Cheque / PO Number:</span>
                          <span className="font-mono font-bold text-slate-900">
                            {payment.chequeNo}
                          </span>
                        </div>
                      )}
                      {payment.refNumber && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Transaction Ref / TrxID:</span>
                          <span className="font-mono text-slate-700">
                            {payment.refNumber}
                          </span>
                        </div>
                      )}
                    </div>

                <div className="p-3 bg-white rounded border border-slate-200 space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-500">On Account Of / Particulars:</span>
                    <span className="font-medium text-slate-800 text-right">
                      {payment.note || 'Against Sales Invoice / Outstanding Due'}
                    </span>
                  </div>
                  {payment.invoiceNumber && (
                    <div className="flex justify-between">
                      <span className="text-slate-500">Invoice Adjusted:</span>
                      <span className="font-mono font-bold text-blue-700">
                        {payment.invoiceNumber}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-slate-500">Payment Status:</span>
                    <span className="inline-flex items-center gap-1 font-bold text-emerald-700">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      {payment.status === 'Cleared' ? 'Cleared & Credited to Ledger' : payment.status}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Collected By:</span>
                    <span className="text-slate-700">
                      {payment.collectedBy || 'Finance & Accounts Desk'}
                    </span>
                  </div>
                  </div>
                </div>
              );
            })()}

              {/* Note */}
              <p className="text-[10px] text-slate-500 italic pt-1 border-t border-slate-200">
                * Note: Cheque / Pay-Order payments are received subject to realization in our bank account. This computer-generated Money Receipt is legally valid under the VAT and Companies Act.
              </p>
            </div>

            {/* Signature Area */}
            <div className="pt-10 flex justify-between items-end text-center text-xs">
              <div className="w-36 border-t border-slate-400 pt-1.5">
                <span className="text-slate-600 font-medium block">Customer / Payer</span>
                <span className="text-[10px] text-slate-400">Received Copy / Signature</span>
              </div>
              <div className="w-36 border-t border-slate-400 pt-1.5">
                <span className="text-slate-600 font-medium block">Accountant / Cashier</span>
                <span className="text-[10px] text-slate-400">Verified & Posted</span>
              </div>
              <div className="w-36 border-t border-slate-400 pt-1.5">
                <span className="text-slate-900 font-bold block">Authorized Officer</span>
                <span className="text-[10px] text-slate-400">For {companyProfile.companyName}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="print:hidden px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs">
          <span className="text-slate-500 font-mono">
            System Voucher ID: {payment.id}
          </span>
          <div className="flex gap-2">
            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Receipt
            </button>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};
