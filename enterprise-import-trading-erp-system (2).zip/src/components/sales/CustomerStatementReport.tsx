import React, { useState, useMemo } from 'react';
import { 
  Printer, 
  Download, 
  Share2, 
  Search, 
  Calendar, 
  Building2, 
  Landmark, 
  ArrowDownRight, 
  ArrowUpRight, 
  CheckCircle2, 
  Clock, 
  Filter, 
  CreditCard,
  FileText,
  User,
  ShieldCheck,
  Send,
  MapPin,
  Truck,
  Eye,
  Layers,
  Sparkles
} from 'lucide-react';
import { Customer, CustomerTransaction, CustomerTransactionItem, SalesInvoice, SalesOrder, FiscalYear } from '../../types/erp';
import { MOCK_CUSTOMER_TRANSACTIONS } from '../../data/mockErpData';
import { useAuth } from '../../contexts/AuthContext';
import { 
  getFiscalYears, 
  getActiveFiscalYear, 
  formatFiscalYearDisplay, 
  subscribeFiscalYears 
} from '../../utils/fiscalYearStorage';
import { getAccountTransactions, subscribeAccountTransactions } from '../../services/accountService';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';
import { AccountTransaction } from '../../types/erp';

interface CustomerStatementReportProps {
  customers: Customer[];
  selectedCustomerId?: string;
  onSelectCustomer?: (customerId: string) => void;
  invoices?: SalesInvoice[];
  orders?: SalesOrder[];
  extraCustomerTransactions?: CustomerTransaction[];
}

export const CustomerStatementReport: React.FC<CustomerStatementReportProps> = ({
  customers,
  selectedCustomerId,
  onSelectCustomer,
  invoices = [],
  orders = [],
  extraCustomerTransactions = []
}) => {
  const { currentUser } = useAuth();
  // State for Customer selection
  const [activeCustomerId, setActiveCustomerId] = useState<string>(
    selectedCustomerId || customers.find(c => c.id === 'cust-106')?.id || customers[0]?.id || 'cust-101'
  );

  // Fiscal Year System Integration
  const [fiscalYears, setFiscalYears] = useState<FiscalYear[]>(() => getFiscalYears());
  const [selectedFYId, setSelectedFYId] = useState<string>(() => getActiveFiscalYear().id);
  const [liveAccountTxns, setLiveAccountTxns] = useState<AccountTransaction[]>(() => getAccountTransactions());
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  React.useEffect(() => {
    const unsubFY = subscribeFiscalYears((updated) => {
      setFiscalYears(updated);
    });
    const unsubAcc = subscribeAccountTransactions((updated) => {
      setLiveAccountTxns(updated);
    });
    const unsubComp = subscribeCompanyProfile(setCompanyProfile);
    return () => {
      unsubFY();
      unsubAcc();
      unsubComp();
    };
  }, []);

  const selectedFY = useMemo(() => {
    return fiscalYears.find(f => f.id === selectedFYId) || getActiveFiscalYear();
  }, [fiscalYears, selectedFYId]);

  // Sync if prop changes
  React.useEffect(() => {
    if (selectedCustomerId) {
      setActiveCustomerId(selectedCustomerId);
    }
  }, [selectedCustomerId]);

  // Date range filters (Default to active Fiscal Year range)
  const [startDate, setStartDate] = useState<string>(() => getActiveFiscalYear().startDate || '2025-07-01');
  const [endDate, setEndDate] = useState<string>(() => getActiveFiscalYear().endDate || '2026-06-30');
  const [txTypeFilter, setTxTypeFilter] = useState<'All' | 'Debit' | 'Credit'>('All');
  const [siteFilter, setSiteFilter] = useState<string>('All');
  const [userFilter, setUserFilter] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'detail' | 'statement'>('detail');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [shareSuccess, setShareSuccess] = useState<boolean>(false);

  // Switch Fiscal Year
  const handleSelectFiscalYear = (fyId: string) => {
    setSelectedFYId(fyId);
    const targetFY = fiscalYears.find(f => f.id === fyId);
    if (targetFY) {
      setStartDate(targetFY.startDate);
      setEndDate(targetFY.endDate);
    }
  };

  // Quick Date Presets
  const applyDatePreset = (preset: 'reference_period' | 'this_month' | 'last_30' | 'last_90' | 'fiscal_year' | 'all') => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (preset === 'reference_period') {
      setStartDate('2026-07-02');
      setEndDate('2026-09-12');
    } else if (preset === 'this_month') {
      setStartDate('2026-09-01');
      setEndDate('2026-09-30');
    } else if (preset === 'last_30') {
      const past30 = new Date(today.getTime() - 30 * 86400000).toISOString().split('T')[0];
      setStartDate(past30);
      setEndDate(todayStr);
    } else if (preset === 'last_90') {
      const past90 = new Date(today.getTime() - 90 * 86400000).toISOString().split('T')[0];
      setStartDate(past90);
      setEndDate(todayStr);
    } else if (preset === 'fiscal_year') {
      if (selectedFY) {
        setStartDate(selectedFY.startDate);
        setEndDate(selectedFY.endDate);
      } else {
        setStartDate('2025-07-01');
        setEndDate('2026-06-30');
      }
    } else if (preset === 'all') {
      setStartDate('2025-07-01');
      setEndDate('2027-06-30');
    }
  };

  const currentCustomer = useMemo(() => {
    return customers.find(c => c.id === activeCustomerId) || customers[0];
  }, [customers, activeCustomerId]);

  // Merge static transactions with any dynamically generated invoices/orders for this customer
  const allCustomerTransactions = useMemo(() => {
    if (!currentCustomer) return [];

    // Base mock transactions for this customer
    const baseTxList = MOCK_CUSTOMER_TRANSACTIONS.filter(t => t.customerId === currentCustomer.id);
    const existingRefNos = new Set(baseTxList.map(t => t.refNo));

    // Active accounting transactions for this customer
    const customerAccTxns = liveAccountTxns.filter(
      t => t.partyId === currentCustomer.id && t.status === 'active'
    );
    const depositTxnIds = new Set(
      customerAccTxns.filter(t => t.transactionType === 'DEPOSIT').map(t => t.id)
    );
    const hasAdvanceDepositTxnsInLedger = customerAccTxns.some(
      t => t.transactionType === 'DEPOSIT' && t.subType === 'Customer Advance'
    );
    const recordedAdjInvoiceRefs = new Set(
      customerAccTxns
        .filter(t => t.transactionType === 'JOURNAL' && t.subType === 'Customer Advance Adjustment')
        .map(t => t.referenceNo || '')
    );

    // Dynamic invoices
    const dynamicTxList: CustomerTransaction[] = [];
    invoices
      .filter(inv => inv.customerId === currentCustomer.id)
      .forEach(inv => {
        if (!existingRefNos.has(inv.invoiceNumber)) {
          const mappedItems: CustomerTransactionItem[] = (inv.items && inv.items.length > 0)
            ? inv.items.map(i => ({
                itemId: i.itemId,
                itemName: i.itemName,
                quantity: i.quantity,
                uom: i.uom || 'CFT',
                unitPrice: i.unitPrice,
                total: i.amount || Math.round(i.quantity * i.unitPrice)
              }))
            : [
                {
                  itemName: 'Crushed Stone',
                  quantity: inv.billedCft || inv.measurementCft || 800,
                  uom: 'CFT',
                  unitPrice: Math.round(inv.totalAmount / (inv.billedCft || 800)),
                  total: inv.totalAmount
                }
              ];

          const siteName = inv.branch?.includes('Sonahat') 
            ? 'Sonahat' 
            : inv.branch?.includes('Burimari') 
              ? 'Burimari' 
              : inv.branch || 'Burimari';

          dynamicTxList.push({
            id: `dyn-inv-${inv.id}`,
            customerId: inv.customerId,
            date: inv.invoiceDate,
            refNo: `${inv.invoiceNumber}`,
            type: 'Invoice',
            description: `Sales Invoice: ${mappedItems.map(m => m.itemName).join(', ')}`,
            memoNo: inv.soNumber ? `Memo ${inv.soNumber.slice(-3)}` : (inv.truckNo ? `Memo (${inv.truckNo})` : 'Memo'),
            challanNo: inv.weighbridgeSlipNo || inv.invoiceNumber,
            truckNo: inv.truckNo,
            measurementFormula: inv.formulaDisplay,
            downLabel: inv.downLabel,
            salesPerson: inv.cashierName || 'jubayer',
            site: siteName,
            items: mappedItems,
            shippingCost: 0,
            discountAmount: 0,
            totalInvoiceAmount: inv.totalAmount,
            debit: inv.totalAmount,
            credit: 0
          });

          const advAdjusted = Math.max(0, Number(inv.adjustedAdvanceAmount ?? inv.advanceAdjusted ?? 0));
          const cashPaid = inv.cashPaidAmount !== undefined
            ? Math.max(0, Number(inv.cashPaidAmount))
            : Math.max(0, Number(inv.paidAmount || 0) - advAdjusted);

          // If cash paid on invoice creation AND not already represented by a DEPOSIT voucher in account_transactions
          if (cashPaid > 0 && !(inv.depositTransactionId && depositTxnIds.has(inv.depositTransactionId))) {
            dynamicTxList.push({
              id: `dyn-pay-${inv.id}`,
              customerId: inv.customerId,
              date: inv.invoiceDate,
              refNo: inv.depositVoucherNo || `MR-${inv.invoiceNumber}`,
              type: 'Payment',
              description: `Payment Received against ${inv.invoiceNumber} (${inv.paymentMethod || 'Direct'})`,
              salesPerson: inv.cashierName || 'jubayer',
              site: siteName,
              paymentMethod: inv.paymentMethod || 'Bank Transfer',
              bankName: inv.paymentMethod === 'Cash' ? 'Cash Depot Counter' : 'Eastern Bank PLC',
              debit: 0,
              credit: cashPaid
            });
          }

          // If invoice adjusted advance but has no separate JOURNAL voucher in account_transactions yet (legacy invoice)
          if (advAdjusted > 0 && !recordedAdjInvoiceRefs.has(inv.invoiceNumber)) {
            dynamicTxList.push({
              id: `dyn-adv-adj-${inv.id}`,
              customerId: inv.customerId,
              date: inv.invoiceDate,
              refNo: inv.adjustmentVoucherNo || `ADV-ADJ-${inv.invoiceNumber}`,
              type: 'Adjustment',
              description: `Customer Advance Adjusted against ${inv.invoiceNumber} (Dr Customer Advance 2050 / Cr Accounts Receivable 1050: BDT ${advAdjusted.toLocaleString()})`,
              salesPerson: inv.cashierName || 'Accounts Officer',
              site: siteName,
              debit: 0,
              credit: hasAdvanceDepositTxnsInLedger ? 0 : advAdjusted,
              totalInvoiceAmount: advAdjusted
            });
          }
        }
      });

    // Extra collected payments or manual transactions for this customer
    const extraForCustomer = extraCustomerTransactions.filter(t => t.customerId === currentCustomer.id);

    // Dynamic Account Payments, Advance Deposits & Advance Adjustments for this Customer
    const accountTxList: CustomerTransaction[] = [];
    customerAccTxns.forEach(t => {
      // Skip 'Sales Invoice' journal vouchers because invoices are already included above with itemized lines
      if (t.transactionType === 'JOURNAL' && t.subType === 'Sales Invoice') {
        return;
      }

      if (t.transactionType === 'JOURNAL' && t.subType === 'Customer Advance Adjustment') {
        accountTxList.push({
          id: `acc-tx-${t.id}`,
          customerId: currentCustomer.id,
          date: t.date,
          refNo: t.voucherNo,
          type: 'Adjustment',
          description: `Customer Advance Adjustment against ${t.referenceNo || 'Invoice'} — Dr Customer Advance (2050) / Cr Accounts Receivable (1050): BDT ${t.amount.toLocaleString()}`,
          salesPerson: t.createdBy?.name || 'Accounts Officer',
          site: t.branch || 'Corporate HQ',
          paymentMethod: 'Advance Adjustment',
          // If the source Advance Deposit (DV) is already credited in this ledger, reclassifying Advance -> A/R has 0 net change on combined balance; otherwise it credits A/R.
          debit: 0,
          credit: hasAdvanceDepositTxnsInLedger ? 0 : t.amount,
          totalInvoiceAmount: t.amount
        });
        return;
      }

      const isDep = t.transactionType === 'DEPOSIT';
      accountTxList.push({
        id: `acc-tx-${t.id}`,
        customerId: currentCustomer.id,
        date: t.date,
        refNo: t.voucherNo,
        type: isDep ? 'Payment' : 'Adjustment',
        description: `${t.subType}: ${t.note || t.paymentMethod} (Voucher: ${t.voucherNo})`,
        salesPerson: t.createdBy?.name || 'Accounts Officer',
        site: t.branch || 'Corporate HQ',
        paymentMethod: t.paymentMethod,
        debit: isDep ? 0 : t.amount,
        credit: isDep ? t.amount : 0
      });
    });

    // Combine and sort chronologically
    const combined = [...baseTxList, ...dynamicTxList, ...extraForCustomer, ...accountTxList];
    combined.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    return combined;
  }, [currentCustomer, invoices, extraCustomerTransactions, liveAccountTxns]);

  // Extract available sites and users for filter dropdowns
  const availableSites = useMemo(() => {
    const set = new Set<string>();
    allCustomerTransactions.forEach(t => {
      if (t.site) set.add(t.site);
    });
    set.add('Burimari');
    set.add('Sonahat');
    return Array.from(set);
  }, [allCustomerTransactions]);

  const availableUsers = useMemo(() => {
    const set = new Set<string>();
    allCustomerTransactions.forEach(t => {
      if (t.salesPerson) set.add(t.salesPerson);
    });
    set.add('jubayer');
    set.add('admin');
    return Array.from(set);
  }, [allCustomerTransactions]);

  // Calculate opening balance before `startDate` and running balances
  const statementData = useMemo(() => {
    if (!currentCustomer) {
      return {
        openingBalance: 0,
        transactionsWithBalance: [],
        totalDebit: 0,
        totalCredit: 0,
        closingBalance: 0
      };
    }

    let priorBalance = 0;
    const inPeriodTx: CustomerTransaction[] = [];

    allCustomerTransactions.forEach(tx => {
      const txDate = tx.date;
      if (txDate < startDate) {
        priorBalance += (tx.debit - tx.credit);
      } else if (txDate <= endDate) {
        inPeriodTx.push(tx);
      }
    });

    const openingBalance = priorBalance;
    let running = openingBalance;
    let periodDebit = 0;
    let periodCredit = 0;

    const transactionsWithBalance = inPeriodTx.map(tx => {
      running += (tx.debit - tx.credit);
      periodDebit += tx.debit;
      periodCredit += tx.credit;

      return {
        ...tx,
        balance: running
      };
    });

    // Filter by type, site, user, or search query
    const filtered = transactionsWithBalance.filter(tx => {
      if (txTypeFilter === 'Debit' && tx.debit <= 0) return false;
      if (txTypeFilter === 'Credit' && tx.credit <= 0) return false;

      if (siteFilter !== 'All') {
        const txSite = (tx.site || '').toLowerCase();
        if (!txSite.includes(siteFilter.toLowerCase())) return false;
      }

      if (userFilter !== 'All') {
        const txUser = (tx.salesPerson || '').toLowerCase();
        if (!txUser.includes(userFilter.toLowerCase())) return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesRef = tx.refNo.toLowerCase().includes(q);
        const matchesDesc = tx.description.toLowerCase().includes(q);
        const matchesMemo = (tx.memoNo || '').toLowerCase().includes(q);
        const matchesBank = (tx.bankName || '').toLowerCase().includes(q);
        const matchesChq = (tx.chequeNo || '').toLowerCase().includes(q);
        const matchesItems = tx.items?.some(i => i.itemName.toLowerCase().includes(q)) || false;
        return matchesRef || matchesDesc || matchesMemo || matchesBank || matchesChq || matchesItems;
      }
      return true;
    });

    return {
      openingBalance,
      transactionsWithBalance: filtered,
      totalDebit: periodDebit,
      totalCredit: periodCredit,
      closingBalance: running
    };
  }, [currentCustomer, allCustomerTransactions, startDate, endDate, txTypeFilter, siteFilter, userFilter, searchQuery]);

  const handlePrint = () => {
    window.print();
  };

  const handleShareSummary = () => {
    if (!currentCustomer) return;
    const summary = `*CUSTOMER DETAIL TRANSACTION STATEMENT*\nClient: ${currentCustomer.tradeName} (${currentCustomer.code})\nPeriod: ${startDate} to ${endDate}\n----------------------------------\nOpening Balance: BDT ${statementData.openingBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}\nTotal Charges (Sales): BDT ${statementData.totalDebit.toLocaleString('en-US', { minimumFractionDigits: 2 })}\nTotal Credits (Receipts): BDT ${statementData.totalCredit.toLocaleString('en-US', { minimumFractionDigits: 2 })}\nNet Closing Balance: BDT ${statementData.closingBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}\n----------------------------------\nJUBAYER OVERSEAS • jubayer-overseas.com`;

    navigator.clipboard.writeText(summary);
    setShareSuccess(true);
    setTimeout(() => setShareSuccess(false), 3000);
  };

  // Convert numbers to words (Bengali/English)
  function numberToWords(num: number): string {
    if (num <= 0) return 'Zero Taka Only';
    const units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 
      'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

    function convertBelowThousand(n: number): string {
      let str = '';
      if (n >= 100) {
        str += units[Math.floor(n / 100)] + ' Hundred ';
        n %= 100;
      }
      if (n >= 20) {
        str += tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + units[n % 10] : '');
      } else if (n > 0) {
        str += units[n];
      }
      return str.trim();
    }

    let rounded = Math.round(num);
    let crore = Math.floor(rounded / 10000000);
    let remainder = rounded % 10000000;
    let lakh = Math.floor(remainder / 100000);
    remainder %= 100000;
    let thousand = Math.floor(remainder / 1000);
    let rest = remainder % 1000;

    let words = '';
    if (crore > 0) words += convertBelowThousand(crore) + ' Crore ';
    if (lakh > 0) words += convertBelowThousand(lakh) + ' Lakh ';
    if (thousand > 0) words += convertBelowThousand(thousand) + ' Thousand ';
    if (rest > 0) words += convertBelowThousand(rest);

    return (words.trim() + ' Taka Only');
  }

  // Format date helper for metadata DD/MM/YYYY
  const formatDateSlash = (dStr: string) => {
    if (!dStr) return '';
    const parts = dStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dStr;
  };

  const currentDateTimeFormatted = useMemo(() => {
    const d = new Date();
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  }, []);

  return (
    <div className="space-y-6">
      {/* 1. Filter and Customer Selector Controls (Hidden when printing) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4 no-print">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-1.5 bg-indigo-100 text-indigo-800 rounded-xl">
                <FileText className="w-5 h-5" />
              </span>
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <span>Customer Detail Transaction Statement</span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-mono px-2 py-0.5 rounded-full font-bold">
                    Standard Format
                  </span>
                </h2>
              </div>
            </div>
          </div>

          {/* Action Buttons: View Toggle, Print, PDF, Share */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              <button
                type="button"
                onClick={() => setViewMode('detail')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'detail'
                    ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Detail View</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('statement')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'statement'
                    ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Landmark className="w-3.5 h-3.5" />
                <span>Bank Format</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleShareSummary}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Copy summary for WhatsApp or Email"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{shareSuccess ? 'Copied!' : 'Copy Summary'}</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              title="Print Customer Detail Transaction"
            >
              <Printer className="w-4 h-4" />
              <span>Print Statement</span>
            </button>
          </div>
        </div>

        {/* Filter Inputs Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-xs">
          {/* Customer Selection */}
          <div className="sm:col-span-2 lg:col-span-2">
            <label className="font-semibold text-slate-700 block mb-1">
              Select Customer <span className="text-rose-500">*</span>
            </label>
            <select
              value={activeCustomerId}
              onChange={(e) => {
                setActiveCustomerId(e.target.value);
                if (onSelectCustomer) onSelectCustomer(e.target.value);
              }}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              {customers.map(c => (
                <option key={c.id} value={c.id}>
                  {c.tradeName} ({c.code}) - Due: ৳{(c.currentBalance).toLocaleString()}
                </option>
              ))}
            </select>
          </div>

          {/* Fiscal Year (FY) Selector */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1 flex items-center justify-between">
              <span>Fiscal Year</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold font-mono ${
                selectedFY?.status === 'Active' 
                  ? 'bg-emerald-100 text-emerald-800' 
                  : 'bg-slate-100 text-slate-600'
              }`}>
                {selectedFY?.status}
              </span>
            </label>
            <select
              value={selectedFYId}
              onChange={(e) => handleSelectFiscalYear(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              {fiscalYears.map(fy => (
                <option key={fy.id} value={fy.id}>
                  {fy.name} ({fy.status})
                </option>
              ))}
            </select>
          </div>

          {/* Date From */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1">Period From</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>

          {/* Date To */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1">Period To</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>

          {/* Site / Location Filter (As Requested by User) */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Loading Site
            </label>
            <select
              value={siteFilter}
              onChange={(e) => setSiteFilter(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              <option value="All">All Sites</option>
              {availableSites.map(site => (
                <option key={site} value={site}>{site}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Date Presets & Search */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-1.5 flex-wrap text-xs">
            <span className="text-slate-500 text-[11px] font-semibold mr-1">Quick Presets:</span>
            <button
              type="button"
              onClick={() => applyDatePreset('reference_period')}
              className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-[11px] font-bold border border-indigo-200 cursor-pointer"
            >
              ★ Reference (02/07 - 12/09)
            </button>
            <button
              type="button"
              onClick={() => applyDatePreset('this_month')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-medium cursor-pointer"
            >
              This Month
            </button>
            <button
              type="button"
              onClick={() => applyDatePreset('last_30')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-medium cursor-pointer"
            >
              Last 30 Days
            </button>
            <button
              type="button"
              onClick={() => applyDatePreset('fiscal_year')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-medium cursor-pointer"
            >
              {selectedFY?.name || 'Active FY'} ({selectedFY?.status})
            </button>
            <button
              type="button"
              onClick={() => applyDatePreset('all')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-medium cursor-pointer"
            >
              All Records
            </button>
          </div>

          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search memo, item, invoice, bank..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-7 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. THE MASTER PRINT & DISPLAY SHEET: Customer Detail Transaction          */}
      {/*    (Exact Parity with User Reference Image & Jubayer Overseas Design)      */}
      {/* ========================================================================= */}
      <div 
        id="customer-statement-sheet"
        className="bg-white border border-slate-300 rounded-2xl shadow-sm p-6 sm:p-10 text-slate-900 print:p-0 print:border-none print:shadow-none print:m-0"
      >
        {/* Document Header (Dynamic Corporate Enterprise Layout) */}
        <div className="flex flex-col sm:flex-row justify-between items-start pb-4 border-b-2 border-slate-900 gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Customer Detail Transaction
            </h1>
          </div>

          <div className="text-left sm:text-right">
            <h2 className="text-lg sm:text-xl font-black tracking-tight text-slate-900 uppercase">
              {companyProfile.companyName}
            </h2>
            <p className="text-xs text-slate-600 font-medium">
              {companyProfile.address} • Mobile: {companyProfile.mobile}
            </p>
            <p className="text-xs text-slate-700 font-semibold">
              Authorized: {currentUser?.displayName || 'Finance & Accounts Officer'}
            </p>
          </div>
        </div>

        {/* Metadata Key-Value Block (Matches 2-column layout from screenshot) */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-y-1 gap-x-6 py-4 text-xs font-sans border-b border-slate-200">
          <div className="sm:col-span-8 grid grid-cols-3 gap-y-1">
            <div className="text-slate-700 font-medium">Print Out Date:</div>
            <div className="col-span-2 font-mono font-semibold text-slate-900">
              {currentDateTimeFormatted}
            </div>

            <div className="text-slate-700 font-medium">Fiscal Year:</div>
            <div className="col-span-2 font-medium text-slate-900 flex items-center gap-2">
              <span className="font-semibold text-slate-900 font-mono">{formatFiscalYearDisplay(selectedFY)}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold font-mono ${
                selectedFY?.status === 'Active' 
                  ? 'bg-emerald-100 text-emerald-800' 
                  : selectedFY?.status === 'Closed'
                    ? 'bg-slate-100 text-slate-600'
                    : 'bg-blue-100 text-blue-800'
              }`}>
                {selectedFY?.status}
              </span>
            </div>

            <div className="text-slate-700 font-medium">Period:</div>
            <div className="col-span-2 font-mono font-semibold text-slate-900">
              {formatDateSlash(startDate)} - {formatDateSlash(endDate)}
            </div>

            <div className="text-slate-700 font-medium">Customer:</div>
            <div className="col-span-2 font-bold text-slate-900">
              {currentCustomer?.tradeName || currentCustomer?.name}
            </div>

            <div className="text-slate-700 font-medium">Show Balance:</div>
            <div className="col-span-2 font-medium text-slate-900">
              Yes
            </div>

            <div className="text-slate-700 font-medium">Currency:</div>
            <div className="col-span-2 font-medium text-slate-900">
              Balances in Home Currency (BDT)
            </div>

            <div className="text-slate-700 font-medium">Suppress Zeros:</div>
            <div className="col-span-2 font-medium text-slate-900">
              No
            </div>
          </div>

          <div className="sm:col-span-4 flex flex-col justify-between sm:items-end pt-2 sm:pt-0">
            <div className="font-mono text-xs text-slate-500 font-semibold">
              Page 1 of 1
            </div>

            <div className="text-left sm:text-right mt-2 sm:mt-0 p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 text-[11px]">
              <span className="text-slate-500 block">Customer Account Code:</span>
              <span className="font-mono font-bold text-indigo-900 text-xs">{currentCustomer?.code}</span>
              <span className="text-slate-500 block mt-1">Contact Phone:</span>
              <span className="font-mono text-slate-700">{currentCustomer?.phone || 'N/A'}</span>
            </div>
          </div>
        </div>

        {/* ===================================================================== */}
        {/* Core Table: Date | Ref | User / LOC or Bank | Charges | Credits | Bal  */}
        {/* ===================================================================== */}
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b-2 border-slate-900 text-slate-900 font-bold text-xs uppercase tracking-wider">
                <th className="py-2.5 px-2 w-24">Date</th>
                <th className="py-2.5 px-3">Ref (Type - Trans No.)</th>
                <th className="py-2.5 px-3">User / LOC or Bank</th>
                <th className="py-2.5 px-3 text-right w-28">Charges</th>
                <th className="py-2.5 px-3 text-right w-28">Credits</th>
                <th className="py-2.5 px-3 text-right w-32">Balance</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-300 text-slate-900 font-normal">
              {/* Opening Balance Line */}
              <tr className="bg-slate-50/70 font-semibold border-b border-slate-200">
                <td className="py-2.5 px-2 font-mono text-slate-700">
                  {formatDateSlash(startDate)}
                </td>
                <td className="py-2.5 px-3 text-slate-800 italic">
                  Opening Balance Brought Forward
                </td>
                <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px]">
                  jubayer / Burimari
                </td>
                <td className="py-2.5 px-3 text-right font-mono text-slate-400">-</td>
                <td className="py-2.5 px-3 text-right font-mono text-slate-400">-</td>
                <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                  {statementData.openingBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
              </tr>

              {/* Transactions Loop */}
              {statementData.transactionsWithBalance.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 italic">
                    No transactions found matching the selected timeframe and filters.
                  </td>
                </tr>
              ) : (
                statementData.transactionsWithBalance.map((tx) => {
                  const isDebit = tx.debit > 0;
                  const isCredit = tx.credit > 0;

                  return (
                    <React.Fragment key={tx.id}>
                      {/* Main Transaction Row */}
                      <tr className="align-top hover:bg-slate-50/50 transition-colors">
                        <td className="py-2 px-2 font-mono text-slate-800 whitespace-nowrap pt-3">
                          {formatDateSlash(tx.date)}
                        </td>

                        <td className="py-2 px-3 font-bold text-slate-900 pt-3">
                          <span className="font-mono text-xs">{tx.refNo}</span>
                        </td>

                        <td className="py-2 px-3 font-mono text-slate-700 text-xs whitespace-nowrap pt-3">
                          {/* User / LOC or Bank (Exactly as seen in Reference: e.g. "jubayer / Burimari") */}
                          <span className="font-semibold text-slate-900">
                            {tx.salesPerson || 'jubayer'}
                          </span>
                          <span className="text-slate-400 mx-1">/</span>
                          <span className="font-semibold text-blue-900">
                            {tx.type === 'Payment' 
                              ? (tx.bankName || tx.paymentMethod || 'Bank') 
                              : (tx.site || 'Burimari')}
                          </span>
                        </td>

                        {/* Charges (Debit) */}
                        <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 pt-3 whitespace-nowrap">
                          {isDebit 
                            ? tx.debit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) 
                            : ''}
                        </td>

                        {/* Credits */}
                        <td className="py-2 px-3 text-right font-mono font-bold text-emerald-800 pt-3 whitespace-nowrap">
                          {isCredit 
                            ? tx.credit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) 
                            : (tx.type === 'Adjustment' && tx.totalInvoiceAmount)
                              ? `(${tx.totalInvoiceAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} Adj)`
                              : ''}
                        </td>

                        {/* Balance */}
                        <td className="py-2 px-3 text-right font-mono font-black text-slate-950 pt-3 whitespace-nowrap">
                          {(tx.balance || 0) < 0 ? (
                            <span className="text-emerald-700">
                              {Math.abs(tx.balance || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} Cr
                            </span>
                          ) : (
                            (tx.balance || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                          )}
                        </td>
                      </tr>

                      {/* Under-Row Details: Memo No, Item Breakdown, Price, Subtotal, Shipping */}
                      <tr className="border-b border-slate-200">
                        <td></td>
                        <td colSpan={5} className="pb-3 pt-0.5 px-3">
                          {/* Invoice Itemized Sub-table (Matches Reference Image layout) */}
                          {tx.type === 'Invoice' && (
                            <div className="text-xs space-y-1.5 pl-2 border-l-2 border-slate-300">
                              {/* Memo Number tag */}
                              {tx.memoNo && (
                                <div className="italic text-slate-700 font-medium text-[11px]">
                                  {tx.memoNo}
                                  {tx.truckNo && <span className="ml-2 font-mono not-italic text-slate-500 font-bold">• {tx.truckNo}</span>}
                                </div>
                              )}

                              {/* Item Breakdown Table */}
                              <div className="max-w-xl">
                                <table className="w-full text-xs text-left">
                                  <thead>
                                    <tr className="text-slate-500 font-semibold border-b border-slate-200 text-[11px]">
                                      <th className="py-1 w-7/12">Item / QTY</th>
                                      <th className="py-1 text-right w-2/12">Price</th>
                                      <th className="py-1 text-right w-3/12">Total</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100 font-mono">
                                    {(tx.items && tx.items.length > 0) ? (
                                      tx.items.map((itm, idx) => (
                                        <tr key={idx} className="text-slate-800">
                                          <td className="py-1 font-sans">
                                            <span className="font-semibold text-slate-900">{itm.itemName}</span>
                                            <span className="text-slate-500 ml-1">
                                              x {itm.quantity.toFixed(2)} {itm.uom}
                                            </span>
                                          </td>
                                          <td className="py-1 text-right">
                                            {itm.unitPrice.toFixed(2)}
                                          </td>
                                          <td className="py-1 text-right font-bold text-slate-900">
                                            {itm.total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                          </td>
                                        </tr>
                                      ))
                                    ) : (
                                      <tr className="text-slate-800">
                                        <td className="py-1 font-sans">
                                          <span className="font-semibold text-slate-900">{tx.description}</span>
                                          {tx.quantity && (
                                            <span className="text-slate-500 ml-1">
                                              x {tx.quantity.toFixed(2)} {tx.uom || 'CFT'}
                                            </span>
                                          )}
                                        </td>
                                        <td className="py-1 text-right">
                                          {(tx.unitPrice || tx.debit).toFixed(2)}
                                        </td>
                                        <td className="py-1 text-right font-bold text-slate-900">
                                          {tx.debit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                        </td>
                                      </tr>
                                    )}
                                  </tbody>
                                </table>

                                {/* Subtotals strip: Shipping, Discount, Total Amount */}
                                <div className="mt-1 pt-1 border-t border-slate-200 text-[11px] flex justify-end gap-6 text-slate-600 font-mono">
                                  <div>Shipping: <span className="font-bold text-slate-900">{(tx.shippingCost || 0).toFixed(2)}</span></div>
                                  <div>Discount: <span className="font-bold text-slate-900">{(tx.discountAmount || 0).toFixed(2)}</span></div>
                                  <div>Total Amount: <span className="font-bold text-slate-900">{tx.debit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Payment / Receipt Details */}
                          {tx.type === 'Payment' && (
                            <div className="text-xs space-y-1 pl-2 border-l-2 border-emerald-400">
                              <div className="text-slate-700 font-medium">
                                <span className="text-emerald-700 font-bold">Receipt Settlement:</span>{' '}
                                {tx.description}
                              </div>
                              <div className="text-[11px] text-slate-500 font-mono flex items-center gap-3 flex-wrap">
                                {tx.paymentMethod && <span>Method: <strong className="text-slate-800">{tx.paymentMethod}</strong></span>}
                                {tx.bankName && <span>Bank: <strong className="text-slate-800">{tx.bankName}</strong></span>}
                                {tx.chequeNo && <span>Cheque #: <strong className="text-indigo-800">{tx.chequeNo}</strong></span>}
                                {tx.chequeDate && <span>Date: <strong className="text-slate-800">{tx.chequeDate}</strong></span>}
                              </div>
                            </div>
                          )}

                          {/* Advance Adjustment / Journal Details */}
                          {tx.type === 'Adjustment' && (
                            <div className="text-xs space-y-1 pl-2 border-l-2 border-indigo-400">
                              <div className="text-slate-700 font-medium">
                                <span className="text-indigo-700 font-bold">Ledger Adjustment:</span>{' '}
                                {tx.description}
                              </div>
                            </div>
                          )}
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })
              )}

              {/* Total Summary Row */}
              <tr className="border-t-2 border-slate-900 bg-slate-50 font-bold text-xs">
                <td colSpan={3} className="py-3 px-3 text-right uppercase tracking-wider text-slate-800">
                  Total Activity in Selected Period:
                </td>
                <td className="py-3 px-3 text-right font-mono text-slate-950 text-sm whitespace-nowrap">
                  {statementData.totalDebit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="py-3 px-3 text-right font-mono text-emerald-800 text-sm whitespace-nowrap">
                  {statementData.totalCredit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="py-3 px-3 text-right font-mono text-slate-950 text-sm whitespace-nowrap">
                  {statementData.closingBalance < 0 ? (
                    <span className="text-emerald-700">
                      {Math.abs(statementData.closingBalance).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} Cr
                    </span>
                  ) : (
                    statementData.closingBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Footer Notes & Total in Words */}
        <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <span className="font-bold text-slate-700 block mb-0.5">NET RECEIVABLE BALANCE IN WORDS:</span>
            <p className="font-semibold text-slate-900 italic font-serif">
              {numberToWords(statementData.closingBalance)}
            </p>
            <p className="text-[11px] text-slate-500 mt-2">
              Note: This statement is computer-generated by {companyProfile.companyName}. Any questions or discrepancies should be directed to the billing & audit department within 7 business days.
            </p>
          </div>

          <div className="flex flex-col justify-end sm:items-end text-slate-600 text-[11px] font-mono">
            <div>Authorized Signatory • {companyProfile.companyName}</div>
            <div className="w-48 border-b border-slate-400 mt-8 mb-1"></div>
            <div className="text-slate-400">Accounts & Treasury In-Charge ({currentUser?.displayName || 'Accounts Officer'})</div>
          </div>
        </div>
      </div>
    </div>
  );
};
