import React, { useState, useRef, useEffect } from 'react';
import { 
  TrendingUp, 
  FileText, 
  Users, 
  CreditCard, 
  Truck, 
  Plus, 
  Search, 
  CheckCircle2, 
  DollarSign, 
  Calendar, 
  Building, 
  BarChart2,
  Receipt,
  AlertCircle,
  UserPlus,
  Phone,
  Mail,
  MapPin,
  ShieldCheck,
  Building2,
  Wallet,
  Banknote,
  Clock,
  ArrowRight,
  Printer,
  Landmark,
  Eye,
  ChevronDown,
  LayoutDashboard,
  Home,
  Layers,
  Sparkles,
  ChevronRight,
  FileSpreadsheet,
  Edit,
  Trash2,
  RotateCcw
} from 'lucide-react';
import { Customer, SalesOrder, SalesInvoice, CustomerTransaction, CustomerPayment, InventoryItem, BankAccount } from '../../types/erp';
import { getItems, getActiveItems, subscribeItems, saveItems, validateStockAvailabilityForLines, deductStockForInvoiceLines, restoreStockForInvoiceLines } from '../../utils/itemStorage';
import { 
  getSalesInvoices, 
  saveSalesInvoices, 
  subscribeSalesInvoices,
  getSalesOrders,
  saveSalesOrders,
  subscribeSalesOrders,
  getCustomerPayments,
  saveCustomerPayments,
  subscribeCustomerPayments
} from '../../utils/salesStorage';
import { getCustomers, subscribeCustomers, updateCustomerBalance, saveCustomers, updateCustomer } from '../../utils/customerStorage';
import { getBankAccounts, subscribeBankAccounts, isCashAccount } from '../../utils/bankAccountStorage';
import { postVoucher, voidAccountTransaction, postSalesInvoiceAtomic, reverseSalesInvoiceAccounting } from '../../services/accountService';
import { useAuth } from '../../contexts/AuthContext';
import { getUOMs, subscribeUOMs } from '../../utils/uomStorage';
import { PrintableInvoiceModal } from './PrintableInvoiceModal';
import { InteractiveInvoiceFormModal } from './InteractiveInvoiceFormModal';
import { CustomerStatementReport } from './CustomerStatementReport';
import { CustomerBalanceReport } from './CustomerBalanceReport';
import { CustomerPaymentList } from './CustomerPaymentList';
import { SalesOverviewDashboard } from './SalesOverviewDashboard';
import { TruckVehiclesReport } from './TruckVehiclesReport';
import { EditSalesInvoiceModal } from './EditSalesInvoiceModal';
import { EditCustomerPaymentModal } from './EditCustomerPaymentModal';
import { CustomerProfilesView } from './CustomerProfilesView';
import { CustomerFormModal } from './CustomerFormModal';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { RecycleBinModal } from '../common/RecycleBinModal';
import { ModalWrapper } from '../common/ModalWrapper';
import { saveDeletedRecord, getDeletedRecords, subscribeRecycleBin } from '../../utils/recycleBinStorage';

const AVAILABLE_UOMS = [
  { id: 'MT', label: 'MT (Metric Ton)' },
  { id: 'CFT', label: 'CFT (Cubic Feet)' },
  { id: '1 Truck', label: '1 Truck Load' },
  { id: 'Bag', label: 'Bag' },
  { id: 'Pcs', label: 'Pcs' },
  { id: 'Kg', label: 'Kg (Kilogram)' },
  { id: 'Ton', label: 'Ton' },
  { id: 'Liter', label: 'Liter' },
  { id: 'Sqft', label: 'Sqft' },
  { id: 'Custom', label: '+ Custom UOM' },
];

const SUB_MODULE_OPTIONS = [
  { id: 'overview', label: 'Sales Dashboard', icon: LayoutDashboard },
  { id: 'invoices', label: 'Sales Invoices', icon: Receipt },
  { id: 'payments', label: 'Customer Payments', icon: CreditCard },
  { id: 'customer_profiles', label: 'Customers Profile', icon: Users },
  { id: 'balance_report', label: 'Customer Balance Report', icon: Landmark },
  { id: 'statement', label: 'Customer Statement', icon: FileText },
  { id: 'aging', label: 'Aging Analysis', icon: Calendar },
  { id: 'profitability', label: 'Profitability Analysis', icon: TrendingUp },
  { id: 'truck_report', label: 'Truck/Vehicles Details', icon: Truck },
];

export type SalesSubTab = 'overview' | 'invoices' | 'payments' | 'customer_profiles' | 'balance_report' | 'challans' | 'customers' | 'statement' | 'aging' | 'profitability' | 'truck_report';

export interface SalesModuleProps {
  activeSubTab?: SalesSubTab;
  onSubTabChange?: (tab: SalesSubTab) => void;
}

export const SalesModule: React.FC<SalesModuleProps> = ({
  activeSubTab,
  onSubTabChange
}) => {
  const [internalTab, setInternalTab] = useState<SalesSubTab>('overview');
  const rawActiveTab = activeSubTab || internalTab;
  // If 'challans' was passed resolve to 'invoices', if 'customers' was passed smoothly resolve to 'customer_profiles'
  const activeTab = rawActiveTab === 'challans' ? 'invoices' : rawActiveTab === 'customers' ? 'customer_profiles' : rawActiveTab;

  const setActiveTab = (tab: SalesSubTab) => {
    const targetTab = tab === 'challans' ? 'invoices' : tab === 'customers' ? 'customer_profiles' : tab;
    setInternalTab(targetTab);
    if (onSubTabChange) {
      onSubTabChange(targetTab);
    }
  };
  
  // State for Sales Orders, Customers & Payments (Live Storage & Firestore synced)
  const { currentUser } = useAuth();
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  const [orders, setOrders] = useState<SalesOrder[]>(() => getSalesOrders());
  const [customers, setCustomers] = useState<Customer[]>(() => getCustomers());
  const [invoices, setInvoices] = useState<SalesInvoice[]>(() => getSalesInvoices());
  const [payments, setPayments] = useState<CustomerPayment[]>(() => getCustomerPayments());
  const [selectedPrintInvoice, setSelectedPrintInvoice] = useState<SalesInvoice | null>(null);

  // Sync with live storage & Firestore
  useEffect(() => {
    const unsubInvoices = subscribeSalesInvoices(setInvoices);
    const unsubOrders = subscribeSalesOrders(setOrders);
    const unsubCustomers = subscribeCustomers(setCustomers);
    const unsubPayments = subscribeCustomerPayments(setPayments);
    const unsubBankAccounts = subscribeBankAccounts(setBankAccounts);
    return () => {
      unsubInvoices();
      unsubOrders();
      unsubCustomers();
      unsubPayments();
      unsubBankAccounts();
    };
  }, []);

  const setInvoicesAndPersist = (newOrUpdater: SalesInvoice[] | ((prev: SalesInvoice[]) => SalesInvoice[])) => {
    setInvoices(prev => {
      const next = typeof newOrUpdater === 'function' ? newOrUpdater(prev) : newOrUpdater;
      saveSalesInvoices(next);
      return next;
    });
  };

  const setOrdersAndPersist = (newOrUpdater: SalesOrder[] | ((prev: SalesOrder[]) => SalesOrder[])) => {
    setOrders(prev => {
      const next = typeof newOrUpdater === 'function' ? newOrUpdater(prev) : newOrUpdater;
      saveSalesOrders(next);
      return next;
    });
  };

  const setPaymentsAndPersist = (newOrUpdater: CustomerPayment[] | ((prev: CustomerPayment[]) => CustomerPayment[])) => {
    setPayments(prev => {
      const next = typeof newOrUpdater === 'function' ? newOrUpdater(prev) : newOrUpdater;
      saveCustomerPayments(next);
      return next;
    });
  };

  // Branch filtering for bank/cash accounts: Manager sees branch accounts; Admin sees all
  const accessibleAccounts = React.useMemo(() => {
    if (currentUser?.role === 'admin') {
      return bankAccounts;
    }
    const userBranch = currentUser?.branch;
    if (!userBranch || userBranch === 'All Branches') {
      return bankAccounts;
    }
    const branchKey = userBranch.toLowerCase().replace(' office', '');
    return bankAccounts.filter(acc => 
      !acc.branch || acc.branch.toLowerCase().includes(branchKey) || acc.branch === 'Head Office'
    );
  }, [bankAccounts, currentUser]);

  // Auto Goods Delivery: Automatically deduct inventory stock when sales invoices/challans are issued
  const deductInventoryStockForInvoice = (soldLines: { itemId?: string; itemName: string; quantity: number }[]) => {
    try {
      const allItems = getItems();
      let hasChanges = false;
      const updated = allItems.map(item => {
        const match = soldLines.find(line => (line.itemId && line.itemId === item.id) || line.itemName.toLowerCase().trim() === item.name.toLowerCase().trim());
        if (match && Number(match.quantity) > 0) {
          hasChanges = true;
          const qty = Number(match.quantity);
          const newTotal = Math.max(0, Number(((item.totalStock || 0) - qty).toFixed(2)));
          const whEntries = Object.entries(item.stockByWarehouse || {});
          let remainingToDeduct = qty;
          const updatedWhMap: Record<string, number> = { ...(item.stockByWarehouse || {}) };
          for (const [whId, stockVal] of whEntries) {
            if (stockVal > 0 && remainingToDeduct > 0) {
              const deductFromThisWh = Math.min(stockVal, remainingToDeduct);
              updatedWhMap[whId] = Math.max(0, Number((stockVal - deductFromThisWh).toFixed(2)));
              remainingToDeduct -= deductFromThisWh;
            }
          }
          return {
            ...item,
            totalStock: newTotal,
            stockByWarehouse: updatedWhMap
          };
        }
        return item;
      });

      if (hasChanges) {
        saveItems(updated);
      }
    } catch (err) {
      console.error('Failed to auto-deduct inventory on invoice delivery', err);
    }
  };

  // Edit, Delete & Recycle Bin State
  const [editingInvoice, setEditingInvoice] = useState<SalesInvoice | null>(null);
  const [deletingInvoice, setDeletingInvoice] = useState<SalesInvoice | null>(null);
  const [isRecycleBinOpen, setIsRecycleBinOpen] = useState(false);
  const [recycleBinType, setRecycleBinType] = useState<'all' | 'sales_invoice' | 'customer_payment'>('sales_invoice');
  const [salesTrashCount, setSalesTrashCount] = useState<number>(() => {
    return getDeletedRecords().filter(r => r.recordType === 'sales_invoice' || r.recordType === 'customer_payment').length;
  });

  useEffect(() => {
    const unsub = subscribeRecycleBin(() => {
      setSalesTrashCount(getDeletedRecords().filter(r => r.recordType === 'sales_invoice' || r.recordType === 'customer_payment').length);
    });
    return unsub;
  }, []);

  const invoiceSubmitLockRef = useRef<boolean>(false);

  const handleUpdateSalesInvoice = async (updatedInv: SalesInvoice) => {
    const prevInv = invoices.find(i => i.id === updatedInv.id);
    const userBranch = currentUser?.branch || 'Head Office';
    const auditUser = {
      uid: currentUser?.uid || 'admin',
      name: currentUser?.name || 'Commercial Officer',
      email: currentUser?.email
    };

    if (prevInv) {
      const prevAdvance = Math.max(0, Number(prevInv.adjustedAdvanceAmount ?? prevInv.advanceAdjusted ?? 0));
      const nextAdvance = Math.max(0, Number(updatedInv.adjustedAdvanceAmount ?? updatedInv.advanceAdjusted ?? prevAdvance));

      // Do not allow silently changing the adjusted advance amount or reducing invoice total below adjusted advance
      if (Math.abs(nextAdvance - prevAdvance) > 0.01) {
        triggerToast(`⚠️ Adjusted advance amount (৳${prevAdvance.toLocaleString()}) cannot be changed silently. Void this invoice to reverse the advance adjustment first.`);
        return;
      }
      if (prevAdvance > 0 && updatedInv.totalAmount < prevAdvance) {
        triggerToast(`⚠️ Invoice total (৳${updatedInv.totalAmount.toLocaleString()}) cannot be less than the adjusted advance (৳${prevAdvance.toLocaleString()}).`);
        return;
      }

      // Enforce stock check on net increase over original invoice lines
      const targetWh = updatedInv.warehouseId || prevInv.warehouseId || updatedInv.branch || userBranch;
      const stockCheck = validateStockAvailabilityForLines(
        (updatedInv.items || []).map(it => ({
          itemId: it.itemId,
          itemName: it.itemName,
          quantity: it.quantity,
          uom: it.uom
        })),
        targetWh,
        {
          isAdmin: currentUser?.role === 'admin',
          negativeStockReason: updatedInv.negativeStockReason,
          originalLines: (prevInv.items || []).map(it => ({
            itemId: it.itemId,
            itemName: it.itemName,
            quantity: it.quantity,
            uom: it.uom
          }))
        }
      );

      if (!stockCheck.valid) {
        triggerToast(`⚠️ ${stockCheck.errors[0]}`);
        return;
      }

      // Apply net stock difference (restore original lines then deduct updated lines)
      const itemsChanged = JSON.stringify(prevInv.items || []) !== JSON.stringify(updatedInv.items || []);
      if (itemsChanged) {
        restoreStockForInvoiceLines(
          (prevInv.items || []).map(it => ({
            itemId: it.itemId,
            itemName: it.itemName,
            quantity: it.quantity,
            uom: it.uom
          })),
          prevInv.warehouseId || prevInv.branch || userBranch
        );
        deductStockForInvoiceLines(
          (updatedInv.items || []).map(it => ({
            itemId: it.itemId,
            itemName: it.itemName,
            quantity: it.quantity,
            uom: it.uom
          })),
          targetWh
        );
        updatedInv.stockDeducted = true;
      }

      // If totalAmount changed, re-post the Sales Invoice journal entry so Accounts Receivable matches
      if (prevInv.totalAmount !== updatedInv.totalAmount) {
        if (prevInv.salesTransactionId) {
          try {
            await voidAccountTransaction(
              prevInv.salesTransactionId,
              `Invoice ${updatedInv.invoiceNumber} total revised from ৳${prevInv.totalAmount} to ৳${updatedInv.totalAmount}`,
              auditUser
            );
          } catch (err) {
            console.warn('Failed to void previous sales voucher on invoice update:', err);
          }
        }
        try {
          const newSalesTxn = await postVoucher({
            transactionType: 'JOURNAL',
            subType: 'Sales Invoice',
            date: updatedInv.invoiceDate,
            amount: updatedInv.totalAmount,
            partyType: 'Customer',
            partyId: updatedInv.customerId,
            partyName: updatedInv.customerName,
            referenceNo: updatedInv.invoiceNumber,
            note: `Revised Sales Invoice ${updatedInv.invoiceNumber} (${updatedInv.items.length} items)`,
            branch: userBranch,
            user: auditUser
          });
          updatedInv.salesVoucherNo = newSalesTxn.voucherNo;
          updatedInv.salesTransactionId = newSalesTxn.id;
        } catch (err: any) {
          triggerToast(`⚠️ Sales voucher update failed: ${err.message}`);
          return;
        }
      }

      const prevCashPaid = prevInv.cashPaidAmount !== undefined
        ? prevInv.cashPaidAmount
        : Math.max(0, (prevInv.paidAmount || 0) - prevAdvance);
      const nextCashPaid = updatedInv.cashPaidAmount !== undefined
        ? updatedInv.cashPaidAmount
        : Math.max(0, (updatedInv.paidAmount || 0) - prevAdvance);

      updatedInv.cashPaidAmount = nextCashPaid;
      updatedInv.advanceAdjusted = prevAdvance;
      updatedInv.adjustedAdvanceAmount = prevAdvance;
      updatedInv.paidAmount = nextCashPaid + prevAdvance;
      updatedInv.dueAmount = Math.max(0, updatedInv.totalAmount - updatedInv.paidAmount);
      updatedInv.status = updatedInv.dueAmount === 0 ? 'Paid' : updatedInv.paidAmount > 0 ? 'Partially Paid' : 'Unpaid';

      // Requirement 5: Editing an invoice's cash paid amount or deposit account must void the old receipt voucher and post a new one.
      if (prevCashPaid !== nextCashPaid || prevInv.depositAccountId !== updatedInv.depositAccountId) {
        if (prevInv.depositTransactionId) {
          try {
            await voidAccountTransaction(
              prevInv.depositTransactionId,
              `Invoice ${updatedInv.invoiceNumber} cash payment modified: was ৳${prevCashPaid}, now ৳${nextCashPaid}`,
              auditUser
            );
          } catch (err) {
            console.warn('Failed to void previous deposit voucher on invoice update:', err);
          }
        }

        if (nextCashPaid > 0 && updatedInv.depositAccountId) {
          try {
            const newDepositTxn = await postVoucher({
              transactionType: 'DEPOSIT',
              subType: 'Customer Collection',
              date: updatedInv.invoiceDate,
              amount: nextCashPaid,
              bankAccountId: updatedInv.depositAccountId,
              paymentMethod: updatedInv.paymentMethod as any,
              partyType: 'Customer',
              partyId: updatedInv.customerId,
              partyName: updatedInv.customerName,
              referenceNo: updatedInv.paymentRef || updatedInv.invoiceNumber,
              note: `Revised Collection against Sales Invoice ${updatedInv.invoiceNumber}`,
              branch: userBranch,
              user: auditUser
            });

            updatedInv.depositVoucherNo = newDepositTxn.voucherNo;
            updatedInv.depositTransactionId = newDepositTxn.id;
            updatedInv.moneyReceiptNumber = newDepositTxn.voucherNo;

            // Also update or add the corresponding Customer Payment entry
            setPaymentsAndPersist(prev => {
              const hasExisting = prev.some(p => p.invoiceNumber === updatedInv.invoiceNumber);
              if (hasExisting) {
                return prev.map(p => p.invoiceNumber === updatedInv.invoiceNumber ? {
                  ...p,
                  amount: nextCashPaid,
                  receiptNumber: newDepositTxn.voucherNo,
                  voucherNo: newDepositTxn.voucherNo,
                  transactionId: newDepositTxn.id,
                  bankAccountId: updatedInv.depositAccountId,
                  bankName: updatedInv.depositAccountName
                } : p);
              } else {
                const newP: CustomerPayment = {
                  id: `pay-inv-${Date.now()}`,
                  receiptNumber: newDepositTxn.voucherNo,
                  voucherNo: newDepositTxn.voucherNo,
                  transactionId: newDepositTxn.id,
                  customerId: updatedInv.customerId,
                  customerName: updatedInv.customerName,
                  customerTradeName: updatedInv.customerName,
                  paymentDate: updatedInv.invoiceDate,
                  amount: nextCashPaid,
                  paymentMethod: updatedInv.paymentMethod as any,
                  paymentType: 'Invoice Payment',
                  bankAccountId: updatedInv.depositAccountId,
                  bankName: updatedInv.depositAccountName,
                  invoiceNumber: updatedInv.invoiceNumber,
                  note: `Collection against ${updatedInv.invoiceNumber}`,
                  status: 'Cleared',
                  collectedBy: currentUser?.name || 'Commercial Desk'
                };
                return [newP, ...prev];
              }
            });
          } catch (err: any) {
            triggerToast(`⚠️ Voucher posting failed: ${err.message}`);
            return;
          }
        } else {
          // If cashPaidAmount became 0, clear deposit voucher refs and remove payment record
          updatedInv.depositVoucherNo = undefined;
          updatedInv.depositTransactionId = undefined;
          if (!prevAdvance) {
            updatedInv.moneyReceiptNumber = undefined;
          }
          setPaymentsAndPersist(prev => prev.filter(p => p.invoiceNumber !== updatedInv.invoiceNumber));
        }
      }
    }

    setInvoicesAndPersist(prev => prev.map(i => i.id === updatedInv.id ? updatedInv : i));
    setCustomers(getCustomers());
    triggerToast(`✓ Sales Invoice ${updatedInv.invoiceNumber} updated successfully!`);
  };

  const handleDeleteSalesInvoice = async (inv: SalesInvoice, reason: string) => {
    const auditUser = {
      uid: currentUser?.uid || 'admin',
      name: currentUser?.name || 'Sales Lead',
      email: currentUser?.email
    };

    // Requirement 5 (Part A & Part B): Deleting/voiding an invoice reverses the advance adjustment voucher (restoring customer advance),
    // voids the receipt and sales vouchers, and restores physical stock in the warehouse.
    try {
      await reverseSalesInvoiceAccounting(inv, reason, auditUser);
    } catch (err) {
      console.warn('Voucher & stock reversal notice on invoice delete:', err);
    }

    saveDeletedRecord({
      recordType: 'sales_invoice',
      originalId: inv.id,
      referenceNumber: inv.invoiceNumber,
      title: `Sales Invoice (${inv.customerName})`,
      partyName: inv.customerName,
      amount: inv.totalAmount,
      date: inv.invoiceDate,
      deletedBy: currentUser?.name || 'Sales Lead',
      reason,
      data: inv
    });

    setInvoicesAndPersist(prev => prev.filter(i => i.id !== inv.id));
    setPaymentsAndPersist(prev => prev.filter(p => p.invoiceNumber !== inv.invoiceNumber));
    setCustomers(getCustomers());
    setDeletingInvoice(null);
    triggerToast(`✓ Sales Invoice ${inv.invoiceNumber} voided, advance & stock restored, and moved to Trash.`);
  };

  const handleUpdateCustomerPayment = async (updatedPay: CustomerPayment) => {
    const prevPay = payments.find(p => p.id === updatedPay.id);
    const auditUser = {
      uid: currentUser?.uid || 'admin',
      name: currentUser?.name || 'Finance Desk',
      email: currentUser?.email
    };
    const userBranch = currentUser?.branch || 'Head Office';

    // Requirement 6: Void old receipt voucher and post new one if amount or deposit account changed
    if (prevPay?.transactionId && (prevPay.amount !== updatedPay.amount || prevPay.bankAccountId !== updatedPay.bankAccountId)) {
      try {
        await voidAccountTransaction(prevPay.transactionId, `Customer payment updated: amount or account changed`, auditUser);
        
        // Post new deposit voucher
        const depositTxn = await postVoucher({
          transactionType: 'DEPOSIT',
          subType: 'Customer Collection',
          date: updatedPay.paymentDate,
          amount: updatedPay.amount,
          bankAccountId: updatedPay.bankAccountId!,
          paymentMethod: updatedPay.paymentMethod as any,
          partyType: 'Customer',
          partyId: updatedPay.customerId,
          partyName: updatedPay.customerName,
          referenceNo: updatedPay.refNumber || undefined,
          note: updatedPay.note || `Updated collection from ${updatedPay.customerName}`,
          branch: userBranch,
          user: auditUser
        });

        updatedPay.voucherNo = depositTxn.voucherNo;
        updatedPay.transactionId = depositTxn.id;
        updatedPay.receiptNumber = depositTxn.voucherNo;
      } catch (err: any) {
        console.error('Error re-posting payment voucher on update:', err);
        triggerToast(`⚠️ Voucher update failed: ${err.message}`);
        return;
      }
    }

    setPaymentsAndPersist(prev => prev.map(p => p.id === updatedPay.id ? updatedPay : p));
    triggerToast(`✓ Money Receipt ${updatedPay.receiptNumber} updated!`);
  };

  const handleDeleteCustomerPayment = async (id: string) => {
    const target = payments.find(p => p.id === id);
    const auditUser = {
      uid: currentUser?.uid || 'admin',
      name: currentUser?.name || 'Finance Desk',
      email: currentUser?.email
    };

    if (target?.transactionId) {
      try {
        await voidAccountTransaction(target.transactionId, `Customer payment ${target.receiptNumber} deleted`, auditUser);
      } catch (voidErr) {
        console.warn('Voucher void notice on payment delete:', voidErr);
      }
    }

    setPaymentsAndPersist(prev => prev.filter(p => p.id !== id));
    triggerToast(`✓ Payment Receipt ${target?.receiptNumber || ''} moved to Recycle Bin. Accounting entry voided.`);
  };

  // Listen to Recycle Bin restore events
  useEffect(() => {
    const handleRestore = (e: any) => {
      const detail = e.detail;
      if (detail && detail.action === 'restore' && detail.record) {
        const rec = detail.record;
        if (rec.recordType === 'sales_invoice' && rec.data) {
          const inv: SalesInvoice = rec.data;
          setInvoicesAndPersist(prev => {
            if (prev.some(i => i.id === inv.id)) return prev;
            return [inv, ...prev];
          });
          if (inv.dueAmount > 0) {
            setCustomers(prev => prev.map(c => {
              if (c.id === inv.customerId) {
                return { ...c, currentBalance: c.currentBalance + inv.dueAmount };
              }
              return c;
            }));
          }
          triggerToast(`✓ Sales Invoice ${inv.invoiceNumber} restored successfully!`);
        } else if (rec.recordType === 'customer_payment' && rec.data) {
          const pay: CustomerPayment = rec.data;
          setPayments(prev => {
            if (prev.some(p => p.id === pay.id)) return prev;
            return [pay, ...prev];
          });
          setCustomers(prev => prev.map(c => {
            if (c.id === pay.customerId) {
              return { ...c, currentBalance: Math.max(0, c.currentBalance - pay.amount) };
            }
            return c;
          }));
          triggerToast(`✓ Money Receipt ${pay.receiptNumber} restored!`);
        }
      }
    };

    window.addEventListener('tradecore_recycle_bin_changed', handleRestore);
    return () => window.removeEventListener('tradecore_recycle_bin_changed', handleRestore);
  }, []);

  // Modal State
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);
  const [liveItems, setLiveItems] = useState<InventoryItem[]>(() => getActiveItems());

  useEffect(() => {
    const unsub = subscribeItems((items) => {
      setLiveItems(items.filter(i => (i.status || 'Active') === 'Active'));
    });
    return () => unsub();
  }, []);

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [paymentType, setPaymentType] = useState<'Invoice Payment' | 'Advance Payment'>('Invoice Payment');
  const [paymentAmount, setPaymentAmount] = useState<number | ''>('');
  const [paymentChannel, setPaymentChannel] = useState<'Cash' | 'Cheque' | 'Bank Transfer' | 'Mobile Banking'>('' as any);
  const [paymentDate, setPaymentDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [paymentRefNumber, setPaymentRefNumber] = useState<string>('');
  const [paymentBankAccountId, setPaymentBankAccountId] = useState<string>('');
  const [paymentNote, setPaymentNote] = useState<string>('');
  const [isSavingPayment, setIsSavingPayment] = useState<boolean>(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [extraTransactions, setExtraTransactions] = useState<CustomerTransaction[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Filter accounts for Customer Payment collection modal based on payment method
  const filteredCollectionAccounts = React.useMemo(() => {
    if (paymentChannel === 'Cash') {
      const cashList = accessibleAccounts.filter(acc => isCashAccount(acc));
      return cashList.length > 0 ? cashList : accessibleAccounts;
    } else if (paymentChannel === 'Bank Transfer' || paymentChannel === 'Cheque') {
      const bankList = accessibleAccounts.filter(acc => !isCashAccount(acc));
      return bankList.length > 0 ? bankList : accessibleAccounts;
    } else if (paymentChannel === 'Mobile Banking') {
      const mobList = accessibleAccounts.filter(acc => 
        acc.bankName.toLowerCase().includes('bkash') ||
        acc.bankName.toLowerCase().includes('nagad') ||
        acc.bankName.toLowerCase().includes('rocket') ||
        acc.bankName.toLowerCase().includes('mobile') ||
        acc.accountType === 'POS Cash'
      );
      return mobList.length > 0 ? mobList : accessibleAccounts;
    }
    return accessibleAccounts;
  }, [accessibleAccounts, paymentChannel]);

  useEffect(() => {
    if (paymentBankAccountId && !filteredCollectionAccounts.some(a => a.id === paymentBankAccountId)) {
      setPaymentBankAccountId('');
    }
  }, [filteredCollectionAccounts, paymentBankAccountId]);

  // Reset Helpers
  const resetPaymentForm = () => {
    setSelectedCustomerId('');
    setPaymentType('Invoice Payment');
    setPaymentAmount('');
    setPaymentChannel('' as any);
    setPaymentDate(new Date().toISOString().split('T')[0]);
    setPaymentRefNumber('');
    setPaymentBankAccountId('');
    setPaymentNote('');
    setPaymentError(null);
    setIsSavingPayment(false);
  };

  const isPaymentDirty = Boolean(
    selectedCustomerId ||
    (paymentAmount !== '' && Number(paymentAmount) > 0) ||
    paymentRefNumber.trim() ||
    paymentNote.trim()
  );
  const handleClosePaymentModal = () => {
    if (isSavingPayment) return;
    resetPaymentForm();
    setShowPaymentModal(false);
  };

  // New Order / Invoice Form State (Starts Empty)
  const [orderModalKey, setOrderModalKey] = useState<number>(0);
  const [newOrderInvoiceDate, setNewOrderInvoiceDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [newOrderCustomer, setNewOrderCustomer] = useState<string>('');
  const [newOrderItem, setNewOrderItem] = useState<string>('');
  const [newOrderUom, setNewOrderUom] = useState<string>('');
  const [newOrderCustomUom, setNewOrderCustomUom] = useState<string>('');
  const [newOrderQty, setNewOrderQty] = useState<number | ''>('');
  const [newOrderRate, setNewOrderRate] = useState<number | ''>('');
  const [newOrderSalesType, setNewOrderSalesType] = useState<'Paid' | 'Partial' | 'Due'>('Due');
  const [newOrderPaidAmount, setNewOrderPaidAmount] = useState<number | ''>('');
  const [newOrderPaymentMethod, setNewOrderPaymentMethod] = useState<'Bank Transfer' | 'Cash' | 'Cheque' | 'Mobile Banking'>('Bank Transfer');
  const [newOrderPaymentRef, setNewOrderPaymentRef] = useState<string>('');
  const [orderSalesTypeFilter, setOrderSalesTypeFilter] = useState<'All' | 'Paid' | 'Partial' | 'Due'>('All');

  const handleItemChange = (itemId: string) => {
    setNewOrderItem(itemId);
    const item = liveItems.find(i => i.id === itemId);
    if (item) {
      if (item.uom) {
        setNewOrderUom(item.uom);
      }
      if (item.sellingPrice) {
        setNewOrderRate(item.sellingPrice);
      }
    }
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleSaveCustomer = (savedCustomer: Customer) => {
    if (customerToEdit) {
      const updated = updateCustomer(savedCustomer);
      setCustomers(updated);
      triggerToast(`✓ Customer "${savedCustomer.tradeName || savedCustomer.name}" (${savedCustomer.code}) updated successfully!`);
    } else {
      const current = getCustomers();
      const updated = [savedCustomer, ...current];
      saveCustomers(updated);
      setCustomers(updated);
      setNewOrderCustomer(savedCustomer.id);
      setSelectedCustomerId(savedCustomer.id);
      triggerToast(`✓ New Customer "${savedCustomer.tradeName || savedCustomer.name}" (${savedCustomer.code}) added successfully!`);
    }
    setShowCustomerModal(false);
    setCustomerToEdit(null);
  };

  const handleQuickCreateCustomer = (newCustomer: Customer) => {
    saveCustomers([newCustomer, ...getCustomers()]);
    setCustomers(prev => [newCustomer, ...prev]);
    triggerToast(`✓ New Customer Profile "${newCustomer.name}" (${newCustomer.code}) created automatically!`);
  };

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const cust = customers.find(c => c.id === newOrderCustomer);
    const item = liveItems.find(i => i.id === newOrderItem);
    if (!cust || !item) {
      triggerToast('⚠️ Please select both a Customer and an Item.');
      return;
    }

    const qty = Number(newOrderQty) || 0;
    const rate = Number(newOrderRate) || 0;
    if (qty <= 0 || rate <= 0) {
      triggerToast('⚠️ Please enter valid Quantity and Unit Price.');
      return;
    }

    const total = qty * rate;
    const invDate = newOrderInvoiceDate || new Date().toISOString().split('T')[0];
    const selectedUom = newOrderUom === 'Custom' ? (newOrderCustomUom.trim() || 'Unit') : newOrderUom;

    // Calculate paid and due amounts based on salesType
    let paid = 0;
    let due = 0;
    if (newOrderSalesType === 'Paid') {
      paid = total;
      due = 0;
    } else if (newOrderSalesType === 'Due') {
      paid = 0;
      due = total;
    } else {
      // Partial
      paid = Math.min(total, Math.max(0, Number(newOrderPaidAmount) || 0));
      due = Math.max(0, total - paid);
    }

    const newSO: SalesOrder = {
      id: `so-${Date.now()}`,
      soNumber: `SO-2026-0${822 + orders.length}`,
      customerId: cust.id,
      customerName: cust.tradeName || cust.name,
      orderDate: invDate,
      invoiceDate: invDate,
      deliveryDate: '2026-09-30',
      paymentTerm: newOrderSalesType === 'Paid' 
        ? `Paid in Full (${newOrderPaymentMethod})` 
        : newOrderSalesType === 'Partial' 
          ? `Partial Paid (${cust.creditDays} Days Credit for balance)` 
          : `${cust.creditDays} Days Credit`,
      salesType: newOrderSalesType,
      paidAmount: paid,
      dueAmount: due,
      paymentMethod: newOrderSalesType !== 'Due' ? newOrderPaymentMethod : undefined,
      items: [
        {
          itemId: item.id,
          itemName: item.name,
          sku: item.sku,
          quantity: qty,
          uom: selectedUom,
          unitPrice: rate,
          discountPercent: 0,
          totalAmount: total
        }
      ],
      subtotal: total,
      taxAmount: 0,
      grandTotal: total,
      status: 'Approved'
    };

    // Update customer current ledger balance with the DUE portion
    if (due > 0) {
      setCustomers(customers.map(c => 
        c.id === cust.id ? { ...c, currentBalance: c.currentBalance + due } : c
      ));
    }

    // Auto-create matching invoice in Sales Invoices
    const dueDateCalculated = new Date(new Date(invDate).getTime() + (cust.creditDays || 30) * 86400000).toISOString().split('T')[0];
    const newInvoice: SalesInvoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: `INV-2026-00${414 + invoices.length}`,
      soNumber: newSO.soNumber,
      customerId: cust.id,
      customerName: cust.tradeName || cust.name,
      invoiceDate: invDate,
      dueDate: dueDateCalculated,
      items: [
        { itemId: item.id, itemName: item.name, quantity: qty, uom: selectedUom, unitPrice: rate, amount: total }
      ],
      totalAmount: total,
      paidAmount: paid,
      dueAmount: due,
      paymentMethod: newOrderSalesType !== 'Due' ? newOrderPaymentMethod : undefined,
      status: due === 0 ? 'Paid' : paid > 0 ? 'Partially Paid' : 'Unpaid'
    };

    setOrders([newSO, ...orders]);
    setInvoicesAndPersist(prev => [newInvoice, ...prev]);

    // Auto Goods Delivery: Deduct physical stock from inventory immediately
    deductInventoryStockForInvoice([{ itemId: item.id, itemName: item.name, quantity: qty }]);

    // If payment was made upfront (Paid or Partial), record in Customer Payments
    if (paid > 0) {
      const upfrontReceipt = `MR-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const upfrontPayment: CustomerPayment = {
        id: `pay-inv-${Date.now()}`,
        receiptNumber: upfrontReceipt,
        customerId: cust.id,
        customerName: cust.name,
        customerTradeName: cust.tradeName || cust.name,
        paymentDate: invDate,
        amount: paid,
        paymentMethod: newOrderPaymentMethod,
        bankName: newOrderPaymentMethod === 'Bank Transfer' ? 'Corporate Bank A/C' : undefined,
        refNumber: newOrderPaymentRef || `INV-${newInvoice.invoiceNumber}`,
        invoiceNumber: newInvoice.invoiceNumber,
        note: `Direct Sales upfront payment (${newOrderSalesType}) against ${newInvoice.invoiceNumber}`,
        status: 'Cleared',
        collectedBy: 'Sales Counter'
      };
      setPayments(prev => [upfrontPayment, ...prev]);
    }

    setShowOrderModal(false);

    // Reset inputs cleanly
    setNewOrderCustomer('');
    setNewOrderItem('');
    setNewOrderUom('');
    setNewOrderCustomUom('');
    setNewOrderQty('');
    setNewOrderRate('');
    setNewOrderSalesType('Due');
    setNewOrderPaidAmount('');
    setNewOrderPaymentRef('');

    triggerToast(`✓ Direct Sales Invoice ${newInvoice.invoiceNumber} (${invDate}) [${newOrderSalesType}] created successfully! (${qty} ${selectedUom})`);
  };

  const handlePersistAndPostSalesInvoice = async (
    newInvoice: SalesInvoice,
    newSO: SalesOrder,
    upfrontPayment?: CustomerPayment,
    adjustedAdvance?: number
  ) => {
    if (invoiceSubmitLockRef.current) {
      throw new Error('Invoice submission is already in progress. Please wait.');
    }
    invoiceSubmitLockRef.current = true;

    try {
      const userBranch = currentUser?.branch || 'Head Office';
      const auditUser = {
        uid: currentUser?.uid || 'admin',
        name: currentUser?.name || 'Commercial Desk',
        email: currentUser?.email
      };

      const effectiveAdjustedAdvance = Math.max(
        0,
        Number(adjustedAdvance ?? newInvoice.adjustedAdvanceAmount ?? newInvoice.advanceAdjusted ?? 0)
      );
      const effectiveCashReceived = newInvoice.cashPaidAmount !== undefined
        ? Math.max(0, Number(newInvoice.cashPaidAmount))
        : Math.max(0, Number(newInvoice.paidAmount || 0) - effectiveAdjustedAdvance);

      const atomicResult = await postSalesInvoiceAtomic({
        invoice: newInvoice,
        adjustedAdvanceAmount: effectiveAdjustedAdvance,
        cashReceivedAmount: effectiveCashReceived,
        depositAccountId: newInvoice.depositAccountId,
        paymentMethod: newInvoice.paymentMethod as any,
        paymentRef: newInvoice.paymentRef,
        warehouseId: newInvoice.warehouseId || newInvoice.branch || userBranch,
        isAdmin: currentUser?.role === 'admin',
        negativeStockReason: newInvoice.negativeStockReason,
        branch: userBranch,
        user: auditUser,
        idempotencyKey: `sales-inv-${newInvoice.id || newInvoice.invoiceNumber}`
      });

      const finalizedInvoice = atomicResult.invoice;
      Object.assign(newInvoice, finalizedInvoice);

      if (upfrontPayment && atomicResult.depositTransaction) {
        upfrontPayment.receiptNumber = atomicResult.depositTransaction.voucherNo;
        upfrontPayment.voucherNo = atomicResult.depositTransaction.voucherNo;
        upfrontPayment.transactionId = atomicResult.depositTransaction.id;
        upfrontPayment.bankAccountId = finalizedInvoice.depositAccountId;
      }

      // Persist order & finalized invoice
      setOrdersAndPersist(prev => [newSO, ...prev]);
      setInvoicesAndPersist(prev => {
        const filtered = prev.filter(i => i.id !== finalizedInvoice.id);
        return [finalizedInvoice, ...filtered];
      });
      setCustomers(getCustomers());

      // Add upfront cash payment record if cash received
      if (upfrontPayment && effectiveCashReceived > 0) {
        setPaymentsAndPersist(prev => [upfrontPayment, ...prev]);
      }
    } finally {
      invoiceSubmitLockRef.current = false;
    }
  };

  const handleCollectPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSavingPayment) return;

    const cust = customers.find(c => c.id === selectedCustomerId);
    if (!cust) {
      setPaymentError('Please select a customer.');
      return;
    }

    const payAmount = Number(paymentAmount) || 0;
    if (payAmount <= 0) {
      setPaymentError('Please enter a valid payment amount greater than 0.');
      return;
    }

    if (!paymentBankAccountId) {
      setPaymentError('Please select a deposit account.');
      return;
    }

    const selectedDepositAcc = accessibleAccounts.find(a => a.id === paymentBankAccountId);
    if (!selectedDepositAcc) {
      setPaymentError('Selected deposit account not found.');
      return;
    }

    const effectiveDate = paymentDate || new Date().toISOString().split('T')[0];
    const userBranch = currentUser?.branch || 'Head Office';
    const auditUser = {
      uid: currentUser?.uid || 'admin',
      name: currentUser?.name || 'Finance Desk',
      email: currentUser?.email
    };

    setIsSavingPayment(true);
    setPaymentError(null);

    try {
      const depositTxn = await postVoucher({
        transactionType: 'DEPOSIT',
        subType: paymentType === 'Advance Payment' ? 'Customer Advance' : 'Customer Collection',
        date: effectiveDate,
        amount: payAmount,
        bankAccountId: paymentBankAccountId,
        paymentMethod: paymentChannel as any,
        partyType: 'Customer',
        partyId: cust.id,
        partyName: cust.name,
        referenceNo: paymentRefNumber.trim() || undefined,
        note: paymentNote.trim() || `${paymentType === 'Advance Payment' ? 'Advance Deposit' : 'Due Bill Collection'} via ${paymentChannel}`,
        branch: userBranch,
        user: auditUser
      });

      // Construct payment record with REAL voucher number from counter
      const newPaymentRecord: CustomerPayment = {
        id: `pay-${Date.now()}`,
        receiptNumber: depositTxn.voucherNo,
        voucherNo: depositTxn.voucherNo,
        transactionId: depositTxn.id,
        customerId: cust.id,
        customerName: cust.name,
        customerTradeName: cust.tradeName || cust.name,
        paymentDate: effectiveDate,
        amount: payAmount,
        paymentMethod: paymentChannel,
        paymentType,
        bankAccountId: paymentBankAccountId,
        bankAccountName: `${selectedDepositAcc.bankName} (${selectedDepositAcc.accountNumber})`,
        bankName: selectedDepositAcc.bankName,
        branchName: selectedDepositAcc.branch,
        chequeNo: paymentChannel === 'Cheque' ? (paymentRefNumber.trim() || undefined) : undefined,
        refNumber: paymentRefNumber.trim() || depositTxn.voucherNo,
        note: paymentNote.trim() || `${paymentType === 'Advance Payment' ? 'Advance Deposit' : 'Due Bill Collection'} via ${paymentChannel}`,
        status: 'Cleared',
        collectedBy: currentUser?.name || 'Finance & Accounts Desk'
      };

      setPaymentsAndPersist(prev => [newPaymentRecord, ...prev]);

      // If due payment, settle due invoices and orders proportionally
      let remainingForInv = payAmount;
      setInvoicesAndPersist(prevInvoices => 
        prevInvoices.map(inv => {
          if (inv.customerId === selectedCustomerId && inv.dueAmount > 0 && remainingForInv > 0) {
            const payThis = Math.min(inv.dueAmount, remainingForInv);
            remainingForInv -= payThis;
            const newPaid = inv.paidAmount + payThis;
            const newDue = inv.dueAmount - payThis;
            return {
              ...inv,
              paidAmount: newPaid,
              dueAmount: newDue,
              status: newDue === 0 ? 'Paid' : 'Partially Paid'
            };
          }
          return inv;
        })
      );

      let remainingForOrders = payAmount;
      setOrdersAndPersist(prevOrders =>
        prevOrders.map(ord => {
          const ordDue = ord.dueAmount ?? (ord.grandTotal - (ord.paidAmount ?? 0));
          if (ord.customerId === selectedCustomerId && ordDue > 0 && remainingForOrders > 0) {
            const payThis = Math.min(ordDue, remainingForOrders);
            remainingForOrders -= payThis;
            const newPaid = (ord.paidAmount ?? 0) + payThis;
            const newDue = ordDue - payThis;
            return {
              ...ord,
              paidAmount: newPaid,
              dueAmount: newDue,
              salesType: newDue === 0 ? 'Paid' : 'Partial'
            };
          }
          return ord;
        })
      );

      setShowPaymentModal(false);
      setActiveTab('payments');
      triggerToast(`✓ Money Receipt ${depositTxn.voucherNo} (BDT ${payAmount.toLocaleString()}) posted to account!`);
      resetPaymentForm();
    } catch (err: any) {
      console.error('Error posting customer payment:', err);
      setPaymentError(err?.message || 'Failed to post payment voucher.');
    } finally {
      setIsSavingPayment(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-xl border border-slate-700 flex items-center gap-2">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner with Sub-Category Dropdown Navigation */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Title & Active Subcategory Indicator */}
          <div>
            {/* Sales & Distribution Title with Current Subcategory Indicator */}
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="flex items-center gap-2">
                <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">
                  Sales & Distribution
                </h1>
                <span className="text-slate-300 font-normal text-xl hidden sm:inline">/</span>
              </div>

              {/* Subcategory Indicator Badge */}
              <div className="flex items-center gap-1.5 bg-blue-50 border border-blue-200 text-blue-800 px-3 py-1.5 rounded-xl shadow-2xs">
                {activeTab === 'overview' && <LayoutDashboard className="w-4 h-4 text-blue-600 shrink-0" />}
                {activeTab === 'invoices' && <Receipt className="w-4 h-4 text-blue-600 shrink-0" />}
                {activeTab === 'payments' && <CreditCard className="w-4 h-4 text-emerald-600 shrink-0" />}
                {activeTab === 'customer_profiles' && <Users className="w-4 h-4 text-blue-600 shrink-0" />}
                {activeTab === 'balance_report' && <Landmark className="w-4 h-4 text-indigo-600 shrink-0" />}
                {activeTab === 'statement' && <FileText className="w-4 h-4 text-blue-600 shrink-0" />}
                {activeTab === 'aging' && <Clock className="w-4 h-4 text-amber-600 shrink-0" />}
                {activeTab === 'profitability' && <BarChart2 className="w-4 h-4 text-emerald-600 shrink-0" />}
                {activeTab === 'truck_report' && <Truck className="w-4 h-4 text-amber-600 shrink-0" />}
                <span className="text-xs md:text-sm font-bold truncate max-w-[200px] sm:max-w-[280px]">
                  {activeTab === 'overview' && 'Sales Dashboard & Daily Summary'}
                  {activeTab === 'invoices' && 'Direct Sales Invoice Billing (Auto Goods Delivery)'}
                  {activeTab === 'payments' && 'Customer Payments & Advance Receipts'}
                  {activeTab === 'customer_profiles' && 'Customers Profile Directory & Profile Editing'}
                  {activeTab === 'balance_report' && 'Customer Balance & Ledger Report'}
                  {activeTab === 'statement' && 'Customer Statement of Account'}
                  {activeTab === 'aging' && 'Receivable Aging Analysis'}
                  {activeTab === 'profitability' && 'Gross Profit & Margin Analysis'}
                  {activeTab === 'truck_report' && 'Truck / Vehicles Measurement Report'}
                </span>
              </div>
            </div>
          </div>

          {/* Action Buttons Right - Only shown on Sales Invoice page ('invoices') */}
          {activeTab === 'invoices' && (
            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={() => setShowCustomerModal(true)}
                className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5 text-indigo-600" />
                + Add Customer
              </button>
              <button
                type="button"
                onClick={() => {
                  resetPaymentForm();
                  setShowPaymentModal(true);
                }}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <CreditCard className="w-3.5 h-3.5" />
                + Collect Payment
              </button>
              <button
                type="button"
                onClick={() => {
                  setOrderModalKey(k => k + 1);
                  setShowOrderModal(true);
                }}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
                title="Create New Sales Invoice & Auto-Delivery Challan"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ New Challan & Invoice (Auto Delivery)</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Tab: Executive Sales Dashboard (Main Dashboard & Today's Summary) */}
      {activeTab === 'overview' && (
        <SalesOverviewDashboard
          invoices={invoices}
          payments={payments}
          customers={customers}
          orders={orders}
          onNavigateTab={(tab) => setActiveTab(tab)}
          onOpenNewInvoiceModal={() => setShowOrderModal(true)}
          onOpenCollectPaymentModal={() => setShowPaymentModal(true)}
          onViewInvoice={(inv) => setSelectedPrintInvoice(inv)}
          onViewCustomerStatement={(custId) => {
            setSelectedCustomerId(custId);
            setActiveTab('statement');
          }}
        />
      )}

      {/* Tab: Customer Payments (Customer Payment Collection Register) */}
      {activeTab === 'payments' && (
        <CustomerPaymentList
          payments={payments}
          customers={customers}
          invoices={invoices}
          onCollectNewPayment={() => {
            resetPaymentForm();
            setShowPaymentModal(true);
          }}
          onUpdatePayment={handleUpdateCustomerPayment}
          onDeletePayment={handleDeleteCustomerPayment}
          onViewCustomerStatement={(custId) => {
            setSelectedCustomerId(custId);
            setActiveTab('statement');
          }}
          onViewInvoice={(invNum) => {
            const inv = invoices.find(i => i.invoiceNumber === invNum);
            if (inv) {
              setSelectedPrintInvoice(inv);
            }
          }}
        />
      )}

      {/* Tab: Customers Profile */}
      {activeTab === 'customer_profiles' && (
        <CustomerProfilesView
          customers={customers}
          invoices={invoices}
          onAddCustomer={() => {
            setCustomerToEdit(null);
            setShowCustomerModal(true);
          }}
          onEditCustomer={(customer) => {
            setCustomerToEdit(customer);
            setShowCustomerModal(true);
          }}
          onViewStatement={(custId) => {
            setSelectedCustomerId(custId);
            setActiveTab('statement');
          }}
          onCollectPayment={(custId, suggestedAmt) => {
            setSelectedCustomerId(custId);
            setPaymentAmount(suggestedAmt);
            setShowPaymentModal(true);
          }}
          onCreateInvoice={(custId) => {
            setNewOrderCustomer(custId);
            setShowOrderModal(true);
          }}
        />
      )}

      {/* Tab: Customer Balance Report (Total Due and Advance Balance Report) */}
      {activeTab === 'balance_report' && (
        <CustomerBalanceReport
          customers={customers}
          invoices={invoices}
          extraTransactions={extraTransactions}
          onSelectCustomerForStatement={(custId) => {
            setSelectedCustomerId(custId);
            setActiveTab('statement');
          }}
          onCollectPayment={(custId, suggestedAmt) => {
            setSelectedCustomerId(custId);
            setPaymentAmount(suggestedAmt);
            setShowPaymentModal(true);
          }}
          onCreateInvoiceForCustomer={(custId) => {
            setNewOrderCustomer(custId);
            setShowOrderModal(true);
          }}
          onAddCustomer={() => {
            setCustomerToEdit(null);
            setShowCustomerModal(true);
          }}
          onEditCustomer={(cust) => {
            setCustomerToEdit(cust);
            setShowCustomerModal(true);
          }}
        />
      )}

      {/* Tab: Direct Sales Invoices */}
      {activeTab === 'invoices' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-slate-900">Direct Sales Invoices</h2>
                <span className="px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded text-[10px] font-semibold">
                  Direct Invoicing
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('payments')}
                className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                Customer Payments ({payments.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('balance_report')}
                className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Landmark className="w-3.5 h-3.5 text-indigo-600" />
                Customer Balance Report
              </button>
              <button
                type="button"
                onClick={() => {
                  setRecycleBinType('sales_invoice');
                  setIsRecycleBinOpen(true);
                }}
                className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Recycle Bin"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                <span>Trash ({salesTrashCount})</span>
              </button>

              <button
                type="button"
                onClick={() => setShowOrderModal(true)}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                + New Sales Invoice
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Invoice No</th>
                  <th className="py-2.5 px-3">Invoice Date</th>
                  <th className="py-2.5 px-3">Due Date</th>
                  <th className="py-2.5 px-3">Customer & Item</th>
                  <th className="py-2.5 px-3 text-right">Total (BDT)</th>
                  <th className="py-2.5 px-3 text-right">Paid (BDT)</th>
                  <th className="py-2.5 px-3 text-right">Due Balance</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3 text-right">Action / Print</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-700">
                {invoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/50">
                    <td className="py-2.5 px-3 font-mono font-bold text-blue-700">{inv.invoiceNumber}</td>
                    <td className="py-2.5 px-3 text-slate-700 font-medium">{inv.invoiceDate}</td>
                    <td className="py-2.5 px-3 text-slate-500">{inv.dueDate}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-slate-900">{inv.customerName}</div>
                      {inv.items?.[0] && (
                        <div className="text-[10px] text-slate-500 font-mono">
                          {inv.items[0].itemName} ({inv.items[0].quantity} {inv.items[0].uom || 'MT'})
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">{inv.totalAmount.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-600 font-semibold">
                      {(() => {
                        const advAmt = Math.max(0, Number(inv.adjustedAdvanceAmount ?? inv.advanceAdjusted ?? 0));
                        const displayPaid = Math.max(Number(inv.paidAmount || 0), (Number(inv.cashPaidAmount || 0) + advAmt));
                        return (
                          <div>
                            <div>{displayPaid.toLocaleString()}</div>
                            {advAmt > 0 && (
                              <div className="text-[10px] text-indigo-700 font-semibold">
                                Adv. Adjusted: ৳{advAmt.toLocaleString()}
                              </div>
                            )}
                          </div>
                        );
                      })()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-rose-600 font-bold">{inv.dueAmount.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' :
                        inv.status === 'Overdue' ? 'bg-rose-100 text-rose-800' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {inv.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5 flex-wrap">
                        {inv.dueAmount > 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedCustomerId(inv.customerId);
                              setPaymentAmount(inv.dueAmount);
                              setShowPaymentModal(true);
                            }}
                            className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-md text-[11px] font-semibold inline-flex items-center gap-1 transition-colors border border-emerald-200 cursor-pointer"
                            title="Collect outstanding payment"
                          >
                            <CreditCard className="w-3 h-3 text-emerald-600" />
                            <span>Collect</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setEditingInvoice(inv)}
                          className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-md text-[11px] font-semibold inline-flex items-center gap-1 transition-colors border border-blue-200 cursor-pointer"
                          title="Edit Sales Invoice"
                        >
                          <Edit className="w-3 h-3 text-blue-600" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedPrintInvoice(inv)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-[11px] font-semibold inline-flex items-center gap-1.5 transition-colors border border-slate-200 cursor-pointer"
                          title="View and print invoice"
                        >
                          <Printer className="w-3 h-3 text-slate-600" />
                          <span>Print</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeletingInvoice(inv)}
                          className="p-1 rounded-md hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer border border-transparent hover:border-rose-200"
                          title="Move to Recycle Bin / Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Bottom Quick Customer Payments Preview */}
          <div className="border-t border-slate-200 bg-slate-50/70 p-3.5">
            <div className="flex items-center justify-between mb-2.5 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                  Recent Customer Collections
                </span>
                <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-bold">
                  {payments.length} Payments
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(true)}
                  className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded border border-emerald-200 transition-colors"
                >
                  + Collect New Payment
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('payments')}
                  className="text-xs font-semibold text-blue-700 hover:text-blue-800 flex items-center gap-1 hover:underline ml-1"
                >
                  View all in Customer Payments →
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
              {payments.slice(0, 4).map((p) => (
                <div 
                  key={p.id}
                  onClick={() => setActiveTab('payments')}
                  className="bg-white border border-slate-200 hover:border-emerald-300 rounded-lg p-2.5 shadow-2xs cursor-pointer transition-all hover:shadow-xs group"
                  title="Click to view payment details"
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-mono font-bold text-emerald-700 group-hover:underline">
                      {p.receiptNumber}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{p.paymentDate}</span>
                  </div>
                  <div className="font-semibold text-slate-800 text-xs mt-1 truncate">
                    {p.customerTradeName || p.customerName}
                  </div>
                  <div className="flex items-center justify-between mt-1 pt-1 border-t border-slate-100 text-[11px]">
                    <span className="text-slate-500 text-[10px]">{p.paymentMethod}</span>
                    <span className="font-mono font-bold text-emerald-700">BDT {p.amount.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Receivable Aging Report */}
      {activeTab === 'aging' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Accounts Receivable Aging Analysis (Days Overdue)</h2>
            </div>
            <span className="text-xs font-mono font-bold bg-slate-100 px-3 py-1 rounded text-slate-700">
              Total Outstanding: BDT 25.34M
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3 text-right">Current (0-30d)</th>
                  <th className="py-2.5 px-3 text-right">31 - 60 Days</th>
                  <th className="py-2.5 px-3 text-right">61 - 90 Days</th>
                  <th className="py-2.5 px-3 text-right text-rose-700">90+ Days (Critical)</th>
                  <th className="py-2.5 px-3 text-right font-bold">Total Due (BDT)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono text-slate-800">
                <tr>
                  <td className="py-2.5 px-3 font-sans font-semibold">Rahman Steel & Re-Rolling</td>
                  <td className="py-2.5 px-3 text-right text-emerald-700">4,700,000</td>
                  <td className="py-2.5 px-3 text-right text-slate-600">1,750,000</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right font-bold">6,450,000</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-sans font-semibold">Apex Polymers & Plastics</td>
                  <td className="py-2.5 px-3 text-right text-emerald-700">4,200,000</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right font-bold">4,200,000</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-sans font-semibold">Bengal Agro Feeds</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right text-amber-600">1,280,000</td>
                  <td className="py-2.5 px-3 text-right text-amber-700 font-semibold">8,520,000</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right font-bold">9,800,000</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-sans font-semibold">Pioneer Construction</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right text-rose-600 font-bold">4,890,000</td>
                  <td className="py-2.5 px-3 text-right font-bold">4,890,000</td>
                </tr>
              </tbody>
              <tfoot className="bg-slate-50 font-mono font-bold text-slate-900 border-t-2 border-slate-300">
                <tr>
                  <td className="py-2.5 px-3 font-sans">PORTFOLIO TOTALS:</td>
                  <td className="py-2.5 px-3 text-right text-emerald-700">8,900,000</td>
                  <td className="py-2.5 px-3 text-right text-amber-600">3,030,000</td>
                  <td className="py-2.5 px-3 text-right text-amber-700">8,520,000</td>
                  <td className="py-2.5 px-3 text-right text-rose-600">4,890,000</td>
                  <td className="py-2.5 px-3 text-right font-bold">25,340,000</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* Tab 6: Profitability Report */}
      {activeTab === 'profitability' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Gross & Net Trading Margin Profitability Analysis</h2>
            </div>
            <span className="text-xs font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-3 py-1 rounded">
              Blended Gross Margin: 13.9%
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
              <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Item Name</th>
                  <th className="py-2.5 px-3">SKU</th>
                  <th className="py-2.5 px-3 text-right">Landed Cost/MT</th>
                  <th className="py-2.5 px-3 text-right">Wholesale Price/MT</th>
                  <th className="py-2.5 px-3 text-right">Gross Margin/MT</th>
                  <th className="py-2.5 px-3 text-right">Margin %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {liveItems.map((item) => {
                  const sPrice = item.sellingPrice || 0;
                  const uCost = item.avgUnitCost || 0;
                  const grossMargin = sPrice - uCost;
                  const marginPct = sPrice > 0 ? (grossMargin / sPrice) * 100 : 0;
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{item.name}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-500">{item.sku}</td>
                      <td className="py-2.5 px-3 text-right font-mono">BDT {uCost.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-right font-mono">BDT {sPrice.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">BDT {grossMargin.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">{marginPct.toFixed(1)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Customer Statement Report (Bank Account Statement Format) */}
      {activeTab === 'statement' && (
        <CustomerStatementReport
          customers={customers}
          selectedCustomerId={selectedCustomerId}
          onSelectCustomer={(id) => setSelectedCustomerId(id)}
          invoices={invoices}
          orders={orders}
          extraCustomerTransactions={extraTransactions}
        />
      )}

      {/* Tab: Truck / Vehicles Measurement Report */}
      {activeTab === 'truck_report' && (
        <TruckVehiclesReport
          invoices={invoices}
          customers={customers}
          onOpenNewInvoiceModal={() => setShowOrderModal(true)}
          onViewInvoice={(inv) => setSelectedPrintInvoice(inv)}
        />
      )}

      {/* Modal: Interactive Live Commercial Invoice (Dark Luxury Style matching photo, Multi-Product Enabled) */}
      {showOrderModal && (
        <InteractiveInvoiceFormModal
          key={orderModalKey}
          customers={customers}
          items={liveItems}
          invoicesCount={invoices.length}
          ordersCount={orders.length}
          onClose={() => setShowOrderModal(false)}
          onQuickCreateCustomer={handleQuickCreateCustomer}
          onSaveInvoice={async (newInvoice, newSO, upfrontPayment, adjustedAdvance) => {
            await handlePersistAndPostSalesInvoice(newInvoice, newSO, upfrontPayment, adjustedAdvance);
            setShowOrderModal(false);
            if (adjustedAdvance && adjustedAdvance > 0) {
              const currentAdv = customers.find(c => c.id === newInvoice.customerId)?.advanceBalance || 0;
              const remAdv = Math.max(0, currentAdv - adjustedAdvance);
              triggerToast(`✓ Challan ${newInvoice.invoiceNumber} created! Auto-delivery & stock deduction complete. ৳${adjustedAdvance.toLocaleString()} deducted from advance. Remaining advance: ৳${remAdv.toLocaleString()}`);
            } else {
              triggerToast(`✓ Challan & Invoice ${newInvoice.invoiceNumber} complete! Auto Goods Delivery & stock deduction completed (${newInvoice.items.length} items)`);
            }
          }}
          onSaveAndPrint={async (newInvoice, newSO, upfrontPayment, adjustedAdvance) => {
            await handlePersistAndPostSalesInvoice(newInvoice, newSO, upfrontPayment, adjustedAdvance);
            setShowOrderModal(false);
            setSelectedPrintInvoice(newInvoice);
            if (adjustedAdvance && adjustedAdvance > 0) {
              const currentAdv = customers.find(c => c.id === newInvoice.customerId)?.advanceBalance || 0;
              const remAdv = Math.max(0, currentAdv - adjustedAdvance);
              triggerToast(`✓ Challan ${newInvoice.invoiceNumber} complete! Auto-delivery & stock deduction complete. ৳${adjustedAdvance.toLocaleString()} deducted from advance.`);
            } else {
              triggerToast(`✓ Challan & Invoice ${newInvoice.invoiceNumber} complete! Auto-delivery & stock deduction complete. Opening print copy...`);
            }
          }}
          onOpenCustomerModal={() => {
            setShowOrderModal(false);
            setShowCustomerModal(true);
          }}
        />
      )}

      {/* Modal: Customer Payment Collection */}
      {showPaymentModal && (
        <ModalWrapper
          isOpen={showPaymentModal}
          onClose={handleClosePaymentModal}
          isDirty={isPaymentDirty}
          isSaving={isSavingPayment}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
        >
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-5 space-y-4 max-h-[95vh] overflow-y-auto">
            <div className="sticky top-0 z-10 bg-white flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                  Collect Customer Payment
                </h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                disabled={isSavingPayment}
                onClick={handleClosePaymentModal}
                className="text-slate-400 hover:text-slate-600 text-xs disabled:opacity-50 shrink-0 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCollectPayment} autoComplete="off" className="space-y-3.5 text-xs">
              {/* Payment Type Toggle: Invoice Payment vs Advance Payment */}
              {(() => {
                const selectedCustObj = customers.find(c => c.id === selectedCustomerId);
                const hasDue = (selectedCustObj?.currentBalance || 0) > 0;

                return (
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 space-y-1.5">
                    <label className="font-bold text-slate-800 block text-xs">
                      Payment Type <span className="text-rose-500">*</span>
                    </label>

                    {hasDue ? (
                      /* When customer has dues: Only Invoice Due Payment option is shown without disabled advance or policy notes */
                      <div className="p-2 rounded-lg border border-blue-500 bg-blue-50 text-blue-900 ring-1 ring-blue-500 shadow-2xs font-semibold flex items-center gap-2">
                        <Receipt className="w-4 h-4 text-blue-600 shrink-0" />
                        <div>
                          <div className="font-bold text-xs">Invoice Due Payment</div>
                        </div>
                      </div>
                    ) : (
                      /* When customer has NO dues: Can select between Invoice Payment or Advance Payment */
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setPaymentType('Invoice Payment')}
                          className={`p-2 rounded-lg border text-left flex items-start gap-2 transition-all cursor-pointer ${
                            paymentType === 'Invoice Payment'
                              ? 'bg-blue-50 border-blue-500 text-blue-900 ring-1 ring-blue-500 shadow-2xs font-semibold'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <Receipt className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                          <div>
                            <div className="font-bold text-xs">Invoice Due Payment</div>
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setPaymentType('Advance Payment')}
                          className={`p-2 rounded-lg border text-left flex items-start gap-2 transition-all cursor-pointer ${
                            paymentType === 'Advance Payment'
                              ? 'bg-emerald-50 border-emerald-500 text-emerald-900 ring-1 ring-emerald-500 shadow-2xs font-semibold'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <div>
                            <div className="font-bold text-xs">Advance Payment</div>
                          </div>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Row 1: Customer Selection */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Customer Account <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedCustomerId}
                  onChange={(e) => {
                    const newCustId = e.target.value;
                    setSelectedCustomerId(newCustId);
                    const selected = customers.find(c => c.id === newCustId);
                    if (selected && selected.currentBalance > 0) {
                      setPaymentType('Invoice Payment');
                    } else if (selected && selected.currentBalance === 0) {
                      setPaymentType('Advance Payment');
                    }
                  }}
                  className="w-full p-2 border border-slate-200 rounded font-medium focus:ring-1 focus:ring-emerald-500 outline-none bg-slate-50/50"
                >
                  <option value="">-- Select Customer Account --</option>
                  {customers.map(c => {
                    const hasDue = c.currentBalance > 0;
                    const adv = hasDue ? 0 : (c.advanceBalance || 0);
                    return (
                      <option key={c.id} value={c.id}>
                        {c.tradeName} ({c.code}) — {hasDue ? `Due: BDT ${c.currentBalance.toLocaleString()}` : adv > 0 ? `Advance: BDT ${adv.toLocaleString()}` : 'Clean (0 Due)'}
                      </option>
                    );
                  })}
                </select>
                {(() => {
                  const currCust = customers.find(c => c.id === selectedCustomerId);
                  if (!currCust) return null;
                  const hasDue = currCust.currentBalance > 0;
                  const adv = hasDue ? 0 : (currCust.advanceBalance || 0);
                  return (
                    <div className="flex items-center justify-between mt-1 px-1 text-[11px]">
                      <span className="text-slate-500">Customer Code: <strong className="font-mono text-slate-700">{currCust.code}</strong></span>
                      <div className="flex items-center gap-2 font-mono">
                        <span className={hasDue ? 'text-rose-600 font-bold' : 'text-slate-500'}>
                          Due: BDT {currCust.currentBalance.toLocaleString()}
                        </span>
                        <span className="text-slate-300">|</span>
                        <span className={adv > 0 ? 'text-emerald-700 font-black' : 'text-slate-500'}>
                          Advance: BDT {adv.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Advance Explanation Banner */}
              {paymentType === 'Advance Payment' && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-lg text-emerald-900 text-xs flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-emerald-950">Advance Deposit Protocol:</p>
                    <p className="text-[11px] text-emerald-800 mt-0.5">
                      This amount will be credited to the customer's advance balance and can be adjusted against future sales invoices.
                    </p>
                    <div className="mt-1 font-mono text-[11px] font-bold text-emerald-900">
                      Current Advance: ৳{(customers.find(c => c.id === selectedCustomerId)?.advanceBalance || 0).toLocaleString()} ➔ New Advance: ৳{((customers.find(c => c.id === selectedCustomerId)?.advanceBalance || 0) + (Number(paymentAmount) || 0)).toLocaleString()}
                    </div>
                  </div>
                </div>
              )}

              {/* Row 2: Custom Date & Payment Channel */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 flex items-center justify-between mb-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                      Payment Date
                    </span>
                    <button
                      type="button"
                      onClick={() => setPaymentDate(new Date().toISOString().split('T')[0])}
                      className="text-[10px] text-emerald-600 hover:underline font-normal"
                    >
                      Today
                    </button>
                  </label>
                  <input
                    type="date"
                    required
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full p-2 border border-slate-200 rounded font-mono font-bold text-slate-800 bg-white focus:ring-1 focus:ring-emerald-500 outline-none shadow-2xs"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Select collection or deposit date
                  </span>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Payment Channel
                  </label>
                  <select
                    value={paymentChannel}
                    onChange={(e) => setPaymentChannel(e.target.value as any)}
                    className="w-full p-2 border border-slate-200 rounded font-medium focus:ring-1 focus:ring-emerald-500 outline-none bg-white"
                  >
                    <option value="">-- Select Payment Channel --</option>
                    <option value="Bank Transfer">Bank Transfer (RTGS / BEFTN / NPSB)</option>
                    <option value="Cheque">Bank Cheque (Deposit / Clearing)</option>
                    <option value="Cash">Cash in Hand</option>
                    <option value="Mobile Banking">Mobile Banking (bKash / Nagad)</option>
                  </select>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {paymentChannel === 'Cash' ? 'Cash Receipt Voucher' : paymentChannel === 'Cheque' ? 'Clearing Cheque' : 'Electronic Funds Transfer'}
                  </span>
                </div>
              </div>

              {/* Row 3: Amount & Reference / Voucher */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 flex items-center justify-between mb-1">
                    <span>{paymentType === 'Advance Payment' ? 'Advance Amount (BDT)' : 'Collection Amount (BDT)'} <span className="text-rose-500">*</span></span>
                    {paymentType === 'Invoice Payment' && (() => {
                      const c = customers.find(item => item.id === selectedCustomerId);
                      if (c && c.currentBalance > 0) {
                        return (
                          <button
                            type="button"
                            onClick={() => setPaymentAmount(c.currentBalance)}
                            className="text-[10px] text-blue-600 hover:underline font-normal"
                          >
                            Full Due ({c.currentBalance.toLocaleString()})
                          </button>
                        );
                      }
                      return null;
                    })()}
                  </label>
                  <div className="relative">
                    <span className="absolute left-2.5 top-2 text-slate-400 font-mono text-xs">BDT</span>
                    <input
                      type="number"
                      required
                      min="1"
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(Number(e.target.value))}
                      className="w-full pl-10 pr-2.5 py-2 border border-slate-200 rounded font-mono font-bold text-slate-900 text-sm focus:ring-1 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    BDT {paymentAmount.toLocaleString()}
                  </span>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {paymentChannel === 'Cheque' ? 'Cheque Number' : 'Voucher / Trx Reference ID'}
                  </label>
                  <input
                    type="text"
                    placeholder={paymentChannel === 'Cheque' ? 'e.g. CQ-98745210' : 'e.g. MR-2026-8941 or TXN-ID'}
                    value={paymentRefNumber}
                    onChange={(e) => setPaymentRefNumber(e.target.value)}
                    className="w-full p-2 border border-slate-200 rounded font-mono focus:ring-1 focus:ring-emerald-500 outline-none"
                  />
                  <span className="text-[10px] text-slate-400">
                    Money Receipt (MR) or clearing reference
                  </span>
                </div>
              </div>

              {/* Row 4: Deposit To Account & Particulars Note */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Deposit To Account <span className="text-rose-500">*</span>:
                  </label>
                  <select
                    value={paymentBankAccountId}
                    onChange={(e) => setPaymentBankAccountId(e.target.value)}
                    required
                    className="w-full border border-slate-300 rounded-lg p-2 bg-white text-xs font-medium text-slate-800 focus:ring-1 focus:ring-emerald-500 outline-none"
                  >
                    <option value="">-- Select Deposit Account --</option>
                    {filteredCollectionAccounts.map(acc => (
                      <option key={acc.id} value={acc.id}>
                        {acc.bankName} ({acc.accountNumber}) {acc.branch ? `— ${acc.branch}` : ''} | Balance: ৳{(acc.ledgerBalance || 0).toLocaleString()}
                      </option>
                    ))}
                  </select>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {currentUser?.role === 'admin' ? 'Admin View: All accounts visible' : `Branch Account: ${currentUser?.branch || 'Local'}`}
                  </span>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Particulars / Payment Note</label>
                  <input
                    type="text"
                    placeholder="e.g. Due collection / Advance deposit against supply"
                    value={paymentNote}
                    onChange={(e) => setPaymentNote(e.target.value)}
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-1 focus:ring-emerald-500 outline-none text-xs"
                  />
                </div>
              </div>

              {/* Error Banner */}
              {paymentError && (
                <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs flex items-start gap-2 shadow-xs">
                  <span className="font-bold text-rose-600">✕</span>
                  <span>{paymentError}</span>
                </div>
              )}

              <div className="p-2.5 bg-emerald-50/80 rounded-lg border border-emerald-200 text-emerald-800 text-[11px] flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Automatic Ledger & Statement Reconciliation:</p>
                  <p className="text-emerald-700 text-[10px] mt-0.5">
                    This payment will be posted atomically via real Deposit Voucher (<span className="font-mono font-bold">DV</span>) across bank accounts, customer receivables ledger, and cash books.
                  </p>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={handleClosePaymentModal}
                  disabled={isSavingPayment}
                  className="px-3.5 py-1.5 border border-slate-200 rounded text-slate-600 hover:bg-slate-50 disabled:opacity-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingPayment}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  {isSavingPayment ? 'Posting Voucher...' : 'Confirm Receipt'}
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* Modal: Add & Edit Customer (Matching Windows 11 / Mobile / Side-by-side design from HTML attachment) */}
      <CustomerFormModal
        isOpen={showCustomerModal}
        customerToEdit={customerToEdit}
        onClose={() => {
          setShowCustomerModal(false);
          setCustomerToEdit(null);
        }}
        onSave={handleSaveCustomer}
      />

      {/* Modal: Printable Invoice (Modern Clean Design) */}
      {selectedPrintInvoice && (
        <PrintableInvoiceModal
          invoice={selectedPrintInvoice}
          customer={customers.find(c => c.id === selectedPrintInvoice.customerId)}
          order={orders.find(o => o.soNumber === selectedPrintInvoice.soNumber)}
          onClose={() => setSelectedPrintInvoice(null)}
          onPaymentCollect={(inv) => {
            setSelectedCustomerId(inv.customerId);
            setPaymentAmount(inv.dueAmount);
            setShowPaymentModal(true);
            setSelectedPrintInvoice(null);
          }}
        />
      )}

      {/* Edit Sales Invoice Modal */}
      {editingInvoice && (
        <EditSalesInvoiceModal
          isOpen={!!editingInvoice}
          invoice={editingInvoice}
          customers={customers}
          onClose={() => setEditingInvoice(null)}
          onSave={(updated) => {
            handleUpdateSalesInvoice(updated);
            setEditingInvoice(null);
          }}
        />
      )}

      {/* Delete Confirmation Modal with Soft Delete Notice */}
      {deletingInvoice && (
        <DeleteConfirmModal
          isOpen={!!deletingInvoice}
          title="Sales Invoice"
          referenceNumber={deletingInvoice.invoiceNumber}
          partyName={deletingInvoice.customerName}
          amount={deletingInvoice.totalAmount}
          onClose={() => setDeletingInvoice(null)}
          onConfirm={(reason) => handleDeleteSalesInvoice(deletingInvoice, reason)}
        />
      )}

      {/* Module Recycle Bin & Restore Hub */}
      <RecycleBinModal
        isOpen={isRecycleBinOpen}
        initialType={recycleBinType}
        onClose={() => setIsRecycleBinOpen(false)}
      />
    </div>
  );
};
