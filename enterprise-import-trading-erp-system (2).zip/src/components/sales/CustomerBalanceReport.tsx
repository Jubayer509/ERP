import React, { useState, useMemo } from 'react';
import { 
  Printer, 
  Download, 
  Search, 
  Filter, 
  CreditCard, 
  Landmark, 
  ArrowUpRight, 
  ArrowDownRight, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Users, 
  Phone, 
  Mail, 
  MapPin, 
  Building2,
  FileText,
  ShieldAlert,
  Wallet,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Share2,
  UserPlus,
  Edit3
} from 'lucide-react';
import { Customer, SalesInvoice, CustomerTransaction } from '../../types/erp';
import { PrintHeader } from '../common/PrintHeader';

interface CustomerBalanceReportProps {
  customers: Customer[];
  invoices: SalesInvoice[];
  extraTransactions?: CustomerTransaction[];
  onSelectCustomerForStatement?: (customerId: string) => void;
  onCollectPayment?: (customerId: string, suggestedAmount: number) => void;
  onCreateInvoiceForCustomer?: (customerId: string) => void;
  onAddCustomer?: () => void;
  onEditCustomer?: (customer: Customer) => void;
}

export const CustomerBalanceReport: React.FC<CustomerBalanceReportProps> = ({
  customers,
  invoices,
  extraTransactions = [],
  onSelectCustomerForStatement,
  onCollectPayment,
  onCreateInvoiceForCustomer,
  onAddCustomer,
  onEditCustomer
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [balanceFilter, setBalanceFilter] = useState<'All' | 'DueOnly' | 'AdvanceOnly' | 'NilOnly'>('All');
  const [cityFilter, setCityFilter] = useState<string>('All');
  const [sortField, setSortField] = useState<'balance' | 'name' | 'code'>('balance');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [copied, setCopied] = useState(false);

  // Available unique cities for filter
  const availableCities = useMemo(() => {
    const cities = Array.from(new Set(customers.map(c => c.city))).filter(Boolean);
    return ['All', ...cities];
  }, [customers]);

  // Compute calculated metrics per customer
  const enrichedCustomers = useMemo(() => {
    return customers.map(cust => {
      // Net balance: positive means Company will receive from Customer (Due/Receivable)
      // advanceBalance holds the customer's unadjusted advance credit balance (Liability 2050)
      const balance = Number(cust.currentBalance || 0);
      const explicitAdvance = Number(cust.advanceBalance || 0);
      const advanceDeposit = explicitAdvance > 0
        ? explicitAdvance
        : (balance < 0 ? Math.abs(balance) : 0);
      const dueAmount = balance > 0 ? balance : 0;
      const isDue = dueAmount > 0;
      const isAdvance = advanceDeposit > 0;
      const isNil = dueAmount === 0 && advanceDeposit === 0;

      // Calculate invoice breakdown for this customer
      const custInvoices = invoices.filter(inv => inv.customerId === cust.id);
      const totalInvoiced = custInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
      const totalPaid = custInvoices.reduce((sum, inv) => {
        const adv = Math.max(0, Number(inv.adjustedAdvanceAmount ?? inv.advanceAdjusted ?? 0));
        const cash = inv.cashPaidAmount !== undefined ? Number(inv.cashPaidAmount) : Math.max(0, Number(inv.paidAmount || 0) - adv);
        return sum + Math.max(Number(inv.paidAmount || 0), cash + adv);
      }, 0);
      const invoiceDue = custInvoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);
      const overdueInvoices = custInvoices.filter(inv => inv.status === 'Overdue');
      const overdueAmount = overdueInvoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);

      return {
        ...cust,
        balance,
        isDue,
        isAdvance,
        isNil,
        dueAmount,
        advanceAmount: advanceDeposit,
        totalInvoiced,
        totalPaid,
        invoiceDue,
        overdueAmount,
        hasOverdue: overdueAmount > 0
      };
    });
  }, [customers, invoices]);

  // Aggregate Company-Wide Totals
  const aggregateMetrics = useMemo(() => {
    let totalReceivableDue = 0; // Total receivable due from customers
    let totalCustomerAdvance = 0; // Advance deposits received from customers
    let dueCustomersCount = 0;
    let advanceCustomersCount = 0;
    let nilCustomersCount = 0;
    let totalInvoicedAll = 0;

    enrichedCustomers.forEach(c => {
      totalInvoicedAll += c.totalInvoiced;
      if (c.dueAmount > 0) {
        totalReceivableDue += c.dueAmount;
        dueCustomersCount++;
      }
      if (c.advanceAmount > 0) {
        totalCustomerAdvance += c.advanceAmount;
        advanceCustomersCount++;
      }
      if (c.isNil) {
        nilCustomersCount++;
      }
    });

    const netReceivables = totalReceivableDue - totalCustomerAdvance;

    return {
      totalReceivableDue,
      totalCustomerAdvance,
      netReceivables,
      dueCustomersCount,
      advanceCustomersCount,
      nilCustomersCount,
      totalInvoicedAll,
      totalCustomers: enrichedCustomers.length
    };
  }, [enrichedCustomers]);

  // Filtered and Sorted customers list
  const filteredCustomers = useMemo(() => {
    return enrichedCustomers
      .filter(c => {
        // Text search
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matches = 
            c.tradeName.toLowerCase().includes(q) ||
            c.name.toLowerCase().includes(q) ||
            c.code.toLowerCase().includes(q) ||
            c.city.toLowerCase().includes(q) ||
            c.phone.toLowerCase().includes(q) ||
            c.contactPerson.toLowerCase().includes(q);
          if (!matches) return false;
        }

        // City filter
        if (cityFilter !== 'All' && c.city !== cityFilter) {
          return false;
        }

        // Balance condition filter
        if (balanceFilter === 'DueOnly') return c.isDue;
        if (balanceFilter === 'AdvanceOnly') return c.isAdvance;
        if (balanceFilter === 'NilOnly') return c.isNil;

        return true;
      })
      .sort((a, b) => {
        let diff = 0;
        if (sortField === 'balance') {
          diff = a.balance - b.balance;
        } else if (sortField === 'name') {
          diff = a.tradeName.localeCompare(b.tradeName);
        } else if (sortField === 'code') {
          diff = a.code.localeCompare(b.code);
        }
        return sortOrder === 'desc' ? -diff : diff;
      });
  }, [enrichedCustomers, searchQuery, cityFilter, balanceFilter, sortField, sortOrder]);

  const handlePrint = () => {
    window.print();
  };

  const handleShareSummary = () => {
    const summaryText = `[Customer Balance Summary]\nTotal Company Receivables (Total Due): BDT ${aggregateMetrics.totalReceivableDue.toLocaleString()}\nCustomer Advances: BDT ${aggregateMetrics.totalCustomerAdvance.toLocaleString()}\nNet Balance: BDT ${aggregateMetrics.netReceivables.toLocaleString()}\nTotal Customers: ${aggregateMetrics.totalCustomers}\nReport Date: ${new Date().toLocaleDateString('en-GB')}`;
    navigator.clipboard.writeText(summaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-5">
      {/* Official Print Header */}
      <PrintHeader
        title="Customer Balance Sheet & Overall Receivables Ledger"
        metadata={[
          { label: 'Total Accounts', value: `${aggregateMetrics.totalCustomers} Accounts` },
          { label: 'Total Due', value: `BDT ${aggregateMetrics.totalReceivableDue.toLocaleString()}` },
          { label: 'Total Advance', value: `BDT ${aggregateMetrics.totalCustomerAdvance.toLocaleString()}` },
          { label: 'Net Due', value: `BDT ${aggregateMetrics.netReceivables.toLocaleString()}` }
        ]}
      />

      {/* 1. Header Banner & Executive KPI Cards (Hidden when printing) */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 no-print print:hidden">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Landmark className="w-5 h-5 text-indigo-600" />
            Customer Balance & Total Due Report
          </h1>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 shrink-0 flex-wrap no-print">
          {onAddCustomer && (
            <button
              type="button"
              onClick={onAddCustomer}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              title="Add a new customer account"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>+ Add Customer</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleShareSummary}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200"
            title="Copy balance summary to clipboard"
          >
            <Share2 className="w-3.5 h-3.5 text-slate-600" />
            <span>{copied ? 'Copied!' : 'Share Summary'}</span>
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
            title="Print report or save as PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF Report</span>
          </button>
        </div>
      </div>

      {/* 2. Key Financial KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Total Due / Receivable */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-semibold uppercase tracking-wider text-rose-700">Total Receivables (Due)</span>
            <div className="p-1.5 bg-rose-50 text-rose-600 rounded-lg">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono text-rose-600">
              BDT {aggregateMetrics.totalReceivableDue.toLocaleString()}
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
              <span>Due Accounts: <strong className="text-slate-800">{aggregateMetrics.dueCustomersCount}</strong></span>
              <span className="text-[10px] bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded font-medium">Receivable</span>
            </div>
          </div>
        </div>

        {/* Card 2: Customer Advance / Credit */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-semibold uppercase tracking-wider text-emerald-700">Customer Advances</span>
            <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono text-emerald-600">
              BDT {aggregateMetrics.totalCustomerAdvance.toLocaleString()}
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
              <span>Advance Accounts: <strong className="text-slate-800">{aggregateMetrics.advanceCustomersCount}</strong></span>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded font-medium">
                {aggregateMetrics.totalCustomerAdvance > 0 ? 'Credit Balance' : 'No Advances'}
              </span>
            </div>
          </div>
        </div>

        {/* Card 3: Net Outstanding Receivable */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-semibold uppercase tracking-wider text-blue-700">Net Receivable Due</span>
            <div className="p-1.5 bg-blue-50 text-blue-600 rounded-lg">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono text-blue-700">
              BDT {aggregateMetrics.netReceivables.toLocaleString()}
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
              <span>Due less Advance</span>
              <span className="text-blue-700 font-mono text-[10px] font-semibold">Net Ledger</span>
            </div>
          </div>
        </div>

        {/* Card 4: Total Invoiced Sales Volume */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-semibold uppercase tracking-wider text-slate-700">Total Invoiced Sales</span>
            <div className="p-1.5 bg-slate-100 text-slate-600 rounded-lg">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono text-slate-900">
              BDT {(aggregateMetrics.totalInvoicedAll / 1000000).toFixed(2)}M
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
              <span>Customer Accounts:</span>
              <span className="font-mono text-slate-800 font-semibold">{aggregateMetrics.totalCustomers} Accounts</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Search & Filter Toolbars */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3 no-print">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by customer trade name, code, phone, or region..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 outline-none"
            />
          </div>

          {/* City Filter & Sort Selection */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <span className="font-medium">Region/City:</span>
              <select
                value={cityFilter}
                onChange={(e) => setCityFilter(e.target.value)}
                className="p-1.5 border border-slate-200 rounded text-xs bg-white focus:ring-1 focus:ring-indigo-500 outline-none"
              >
                {availableCities.map(city => (
                  <option key={city} value={city}>{city === 'All' ? 'All Regions' : city}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <span className="font-medium">Sort By:</span>
              <select
                value={`${sortField}-${sortOrder}`}
                onChange={(e) => {
                  const [f, o] = e.target.value.split('-');
                  setSortField(f as any);
                  setSortOrder(o as any);
                }}
                className="p-1.5 border border-slate-200 rounded text-xs bg-white focus:ring-1 focus:ring-indigo-500 outline-none"
              >
                <option value="balance-desc">Highest Due First</option>
                <option value="balance-asc">Lowest Due First</option>
                <option value="name-asc">Customer Name (A to Z)</option>
                <option value="code-asc">Customer Code</option>
              </select>
            </div>
          </div>
        </div>

        {/* Quick Filter Badges */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-100 overflow-x-auto text-xs font-semibold">
          <span className="text-slate-400 text-[11px] font-medium mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Filter:
          </span>
          <button
            type="button"
            onClick={() => setBalanceFilter('All')}
            className={`px-3 py-1 rounded-lg transition-colors ${
              balanceFilter === 'All' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Customers ({aggregateMetrics.totalCustomers})
          </button>
          <button
            type="button"
            onClick={() => setBalanceFilter('DueOnly')}
            className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1 ${
              balanceFilter === 'DueOnly' ? 'bg-rose-600 text-white' : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            <AlertCircle className="w-3 h-3" />
            Due Only ({aggregateMetrics.dueCustomersCount})
          </button>
          <button
            type="button"
            onClick={() => setBalanceFilter('AdvanceOnly')}
            className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1 ${
              balanceFilter === 'AdvanceOnly' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
            }`}
          >
            <CheckCircle2 className="w-3 h-3" />
            Advance Only ({aggregateMetrics.advanceCustomersCount})
          </button>
          <button
            type="button"
            onClick={() => setBalanceFilter('NilOnly')}
            className={`px-3 py-1 rounded-lg transition-colors ${
              balanceFilter === 'NilOnly' ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Settled / Zero Balance ({aggregateMetrics.nilCustomersCount})
          </button>
        </div>
      </div>

      {/* 4. Customer Balance Master Ledger Table (Printable Document Card) */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs printable-card">

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-3.5">Customer Code</th>
                <th className="py-3 px-3.5">Account & Trade Name</th>
                <th className="py-3 px-3.5">Address & Region</th>
                <th className="py-3 px-3.5 text-center">Terms</th>
                <th className="py-3 px-3.5 text-center">Status</th>
                <th className="py-3 px-3.5 text-right">Company Receives (Due BDT)</th>
                <th className="py-3 px-3.5 text-right">Customer Advance (BDT)</th>
                <th className="py-3 px-3.5 text-right">Total Invoiced (BDT)</th>
                <th className="py-3 px-3.5 text-right no-print">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-700">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    No customer accounts found matching search or filter criteria.
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((c) => {
                  return (
                    <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                      {/* Code */}
                      <td className="py-3 px-3.5 font-mono font-bold text-slate-800">
                        {c.code}
                      </td>

                      {/* Customer Name & Contact */}
                      <td className="py-3 px-3.5">
                        <div className="font-bold text-slate-900 text-[13px] flex items-center gap-1.5">
                          {c.tradeName}
                        </div>
                        <div className="text-[11px] text-slate-500">{c.name}</div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                          <span>{c.contactPerson}</span>
                          <span>•</span>
                          <span className="font-mono">{c.phone}</span>
                        </div>
                      </td>

                      {/* City & Address */}
                      <td className="py-3 px-3.5 text-slate-600">
                        <div className="font-medium text-slate-800 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          {c.city}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[150px]" title={c.address}>
                          {c.address}
                        </div>
                      </td>

                      {/* Terms */}
                      <td className="py-3 px-3.5 text-center font-mono text-slate-700 font-medium">
                        {c.creditDays} Days
                      </td>

                      {/* Balance Status Badge */}
                      <td className="py-3 px-3.5 text-center">
                        {c.isDue ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            <AlertCircle className="w-3 h-3 text-rose-600" />
                            Receivable Due
                          </span>
                        ) : c.isAdvance ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Customer Advance
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                            ✓ Settled / Nil
                          </span>
                        )}
                      </td>

                      {/* Due Balance */}
                      <td className="py-3 px-3.5 text-right font-mono font-bold">
                        {c.isDue ? (
                          <span className="text-rose-600">
                            BDT {c.dueAmount.toLocaleString()}
                          </span>
                        ) : (
                          <span className="text-slate-300">-</span>
                        )}
                      </td>

                      {/* Advance Balance */}
                      <td className="py-3 px-3.5 text-right font-mono font-bold">
                        {c.isAdvance ? (
                          <span className="text-emerald-700 text-sm">
                            BDT {c.advanceAmount.toLocaleString()} <span className="text-[10px] font-bold text-emerald-600">(Cr)</span>
                          </span>
                        ) : (
                          <span className="text-slate-300">-</span>
                        )}
                      </td>

                      {/* Total Invoiced Sales */}
                      <td className="py-3 px-3.5 text-right font-mono font-bold text-slate-800">
                        BDT {c.totalInvoiced.toLocaleString()}
                      </td>

                      {/* Quick Actions (Non-print) */}
                      <td className="py-3 px-3.5 text-right no-print">
                        <div className="flex items-center justify-end gap-1.5">
                          {onEditCustomer && (
                            <button
                              type="button"
                              onClick={() => {
                                const original = customers.find(orig => orig.id === c.id);
                                if (original) onEditCustomer(original);
                              }}
                              className="px-2 py-1 bg-slate-50 hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-200 hover:border-blue-300 rounded text-[11px] font-semibold transition-colors flex items-center gap-1"
                              title="Edit Customer Profile"
                            >
                              <Edit3 className="w-3 h-3 text-blue-600" />
                              <span>Edit</span>
                            </button>
                          )}

                          {c.isDue && onCollectPayment && (
                            <button
                              type="button"
                              onClick={() => onCollectPayment(c.id, c.dueAmount)}
                              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded text-[11px] font-semibold transition-colors flex items-center gap-1"
                              title="Collect payment from this customer"
                            >
                              <CreditCard className="w-3 h-3 text-emerald-600" />
                              <span>Pay</span>
                            </button>
                          )}

                          {onCreateInvoiceForCustomer && (
                            <button
                              type="button"
                              onClick={() => onCreateInvoiceForCustomer(c.id)}
                              className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded text-[11px] font-semibold transition-colors"
                              title="Create direct sales invoice"
                            >
                              + Invoice
                            </button>
                          )}

                          {onSelectCustomerForStatement && (
                            <button
                              type="button"
                              onClick={() => onSelectCustomerForStatement(c.id)}
                              className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded text-[11px] font-semibold transition-colors flex items-center gap-1"
                              title="Open customer bank statement & ledger report"
                            >
                              <Landmark className="w-3 h-3 text-indigo-600" />
                              <span>Statement</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {/* Grand Total Footer Row */}
            <tfoot className="bg-slate-100/90 font-bold border-t-2 border-slate-300 text-slate-900 text-xs">
              <tr>
                <td colSpan={5} className="py-3 px-3.5 text-right font-sans">
                  Grand Total ({filteredCustomers.length} Accounts):
                </td>
                <td className="py-3 px-3.5 text-right font-mono text-rose-700 text-sm">
                  BDT {filteredCustomers.reduce((acc, c) => acc + c.dueAmount, 0).toLocaleString()}
                </td>
                <td className="py-3 px-3.5 text-right font-mono text-emerald-700 text-sm">
                  BDT {filteredCustomers.reduce((acc, c) => acc + c.advanceAmount, 0).toLocaleString()}
                </td>
                <td colSpan={2} className="py-3 px-3.5 text-left text-slate-500 font-mono text-[11px]">
                  Net Due: BDT {(filteredCustomers.reduce((acc, c) => acc + c.dueAmount, 0) - filteredCustomers.reduce((acc, c) => acc + c.advanceAmount, 0)).toLocaleString()}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Report Footer & Certification */}
        <div className="p-4 bg-slate-50/50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Automatically synchronized with General Ledger and Collections modules.</span>
          </div>
          <div className="font-mono text-[11px]">
            Showing {filteredCustomers.length} of {customers.length} Accounts
          </div>
        </div>

        {/* Print Signature Block */}
        <div className="hidden print:grid grid-cols-3 gap-8 pt-12 pb-6 px-6 text-center text-xs">
          <div>
            <div className="border-t border-slate-400 pt-1 font-semibold text-slate-800">Prepared By</div>
            <span className="text-[10px] text-slate-400">Accounts Executive</span>
          </div>
          <div>
            <div className="border-t border-slate-400 pt-1 font-semibold text-slate-800">Checked & Verified By</div>
            <span className="text-[10px] text-slate-400">Head of Commercial Credit</span>
          </div>
          <div>
            <div className="border-t border-slate-800 pt-1 font-bold text-slate-900">Managing Director / CFO</div>
            <span className="text-[10px] text-slate-400">Authorized Signatory</span>
          </div>
        </div>
      </div>
    </div>
  );
};
