import React, { useState } from 'react';
import { 
  Receipt, 
  X, 
  Plus, 
  Trash2, 
  Save, 
  Calendar, 
  DollarSign, 
  FileText,
  AlertCircle
} from 'lucide-react';
import { SalesInvoice, Customer, InventoryItem, BankAccount } from '../../types/erp';
import { MOCK_ITEMS } from '../../data/mockErpData';
import { 
  getItems, 
  getActiveItems, 
  resolveWarehouseId, 
  isStockItem, 
  getAvailableStockForWarehouse, 
  convertQuantityBetweenUoms, 
  validateStockAvailabilityForLines 
} from '../../utils/itemStorage';
import { getSystemInventorySettings } from '../../utils/systemSettingsStorage';
import { getBankAccounts, isCashAccount } from '../../utils/bankAccountStorage';
import { useAuth } from '../../contexts/AuthContext';
import { ModalWrapper } from '../common/ModalWrapper';

interface EditSalesInvoiceModalProps {
  isOpen: boolean;
  invoice: SalesInvoice | null;
  customers: Customer[];
  onClose: () => void;
  onSave: (updated: SalesInvoice) => void;
}

export const EditSalesInvoiceModal: React.FC<EditSalesInvoiceModalProps> = ({
  isOpen,
  invoice,
  customers,
  onClose,
  onSave
}) => {
  if (!isOpen || !invoice) return null;

  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';
  const allowNegativeStock = getSystemInventorySettings().allowNegativeStock;
  const [bankAccounts] = useState<BankAccount[]>(() => getBankAccounts());

  const lockedAdvance = Math.max(0, Number(invoice.adjustedAdvanceAmount ?? invoice.advanceAdjusted ?? 0));
  const initialCashPaid = invoice.cashPaidAmount !== undefined
    ? Number(invoice.cashPaidAmount)
    : Math.max(0, Number(invoice.paidAmount || 0) - lockedAdvance);

  const [customerId, setCustomerId] = useState(invoice.customerId);
  const [invoiceDate, setInvoiceDate] = useState(invoice.invoiceDate);
  const [dueDate, setDueDate] = useState(invoice.dueDate);
  const [paymentMethod, setPaymentMethod] = useState<'Bank Transfer' | 'Cheque' | 'Cash' | 'Mobile Banking'>(
    invoice.paymentMethod || 'Bank Transfer'
  );
  const [cashPaidAmount, setCashPaidAmount] = useState(initialCashPaid);
  const [depositAccountId, setDepositAccountId] = useState(invoice.depositAccountId || '');
  const [paymentRef, setPaymentRef] = useState(invoice.paymentRef || '');
  const [negativeStockReason, setNegativeStockReason] = useState(invoice.negativeStockReason || '');
  const [formError, setFormError] = useState<string | null>(null);
  const [items, setItems] = useState(
    invoice.items?.length > 0 
      ? invoice.items 
      : [{ itemId: 'item-01', itemName: '20MM Stone Boulder', quantity: 20, unitPrice: 3800, amount: 76000, uom: 'MT' }]
  );

  const warehouseId = resolveWarehouseId(invoice.warehouseId || invoice.branch || currentUser?.branch || 'Head Office');

  // Filter accounts: Managers see only their branch accounts; admin sees all
  const accessibleAccounts = React.useMemo(() => {
    if (currentUser?.role === 'admin') {
      return bankAccounts;
    }
    const userBranch = currentUser?.branch;
    if (!userBranch || userBranch === 'All Branches') {
      return bankAccounts;
    }
    const branchKey = userBranch.toLowerCase().replace(' office', '');
    return bankAccounts.filter(acc => 
      !acc.branch || acc.branch.toLowerCase().includes(branchKey) || acc.branch === 'Head Office'
    );
  }, [bankAccounts, currentUser]);

  // Payment method controls default list
  const filteredDepositAccounts = React.useMemo(() => {
    if (paymentMethod === 'Cash') {
      const cashList = accessibleAccounts.filter(acc => isCashAccount(acc));
      return cashList.length > 0 ? cashList : accessibleAccounts;
    } else if (paymentMethod === 'Bank Transfer' || paymentMethod === 'Cheque') {
      const bankList = accessibleAccounts.filter(acc => !isCashAccount(acc));
      return bankList.length > 0 ? bankList : accessibleAccounts;
    } else if (paymentMethod === 'Mobile Banking') {
      const mobList = accessibleAccounts.filter(acc => 
        acc.bankName.toLowerCase().includes('bkash') ||
        acc.bankName.toLowerCase().includes('nagad') ||
        acc.bankName.toLowerCase().includes('rocket') ||
        acc.bankName.toLowerCase().includes('mobile') ||
        acc.accountType === 'POS Cash'
      );
      return mobList.length > 0 ? mobList : accessibleAccounts;
    }
    return accessibleAccounts;
  }, [accessibleAccounts, paymentMethod]);

  React.useEffect(() => {
    if (filteredDepositAccounts.length > 0) {
      if (!depositAccountId || !filteredDepositAccounts.some(a => a.id === depositAccountId)) {
        setDepositAccountId(filteredDepositAccounts[0].id);
      }
    }
  }, [filteredDepositAccounts, depositAccountId]);

  const allStoredItems = getActiveItems();

  const handleItemChange = (index: number, field: string, value: any) => {
    setFormError(null);
    const updated = [...items];
    const current = { ...updated[index], [field]: value };

    if (field === 'itemId') {
      const selected = allStoredItems.find(i => i.id === value) || MOCK_ITEMS.find(i => i.id === value);
      if (selected) {
        current.itemName = selected.name;
        if (selected.uom) current.uom = selected.uom;
        if (selected.sellingPrice) current.unitPrice = selected.sellingPrice;
      }
    }

    if (field === 'quantity' || field === 'unitPrice') {
      const qty = field === 'quantity' ? Number(value) : current.quantity;
      const rate = field === 'unitPrice' ? Number(value) : current.unitPrice;
      current.amount = Math.round(qty * rate);
    }

    updated[index] = current;
    setItems(updated);
  };

  const handleAddItem = () => {
    setFormError(null);
    const firstInStock = allStoredItems.find(i => !isStockItem(i) || getAvailableStockForWarehouse(i, warehouseId) > 0) || allStoredItems[0] || MOCK_ITEMS[0];
    setItems([
      ...items,
      {
        itemId: firstInStock?.id || 'item-01',
        itemName: firstInStock?.name || 'Stone Boulder',
        quantity: 1,
        unitPrice: firstInStock?.sellingPrice || 3800,
        amount: (firstInStock?.sellingPrice || 3800) * 1,
        uom: firstInStock?.uom || 'MT'
      }
    ]);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) return;
    setFormError(null);
    setItems(items.filter((_, i) => i !== index));
  };

  const totalAmount = items.reduce((acc, curr) => acc + (curr.amount || 0), 0);
  const totalPaidAmount = cashPaidAmount + lockedAdvance;
  const dueAmount = Math.max(0, totalAmount - totalPaidAmount);

  // Stock check on net increase over original invoice lines
  const stockValidation = React.useMemo(() => {
    return validateStockAvailabilityForLines(
      items.map(it => ({
        itemId: it.itemId,
        itemName: it.itemName,
        quantity: it.quantity,
        uom: it.uom
      })),
      warehouseId,
      {
        isAdmin,
        negativeStockReason,
        originalLines: (invoice.items || []).map(it => ({
          itemId: it.itemId,
          itemName: it.itemName,
          quantity: it.quantity,
          uom: it.uom
        }))
      }
    );
  }, [items, warehouseId, isAdmin, negativeStockReason, invoice.items]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (lockedAdvance > 0 && customerId !== invoice.customerId) {
      setFormError('Cannot change customer on an invoice with an adjusted advance. Void this invoice first.');
      return;
    }

    if (lockedAdvance > 0 && totalAmount < lockedAdvance) {
      setFormError(`Invoice total (BDT ${totalAmount.toLocaleString()}) cannot be reduced below the adjusted advance (BDT ${lockedAdvance.toLocaleString()}). Void the invoice to reverse the advance adjustment.`);
      return;
    }

    if (totalPaidAmount > totalAmount) {
      setFormError(`Total paid + advance adjusted (BDT ${totalPaidAmount.toLocaleString()}) cannot exceed the invoice total (BDT ${totalAmount.toLocaleString()}).`);
      return;
    }

    if (!stockValidation.valid) {
      setFormError(stockValidation.errors[0]);
      return;
    }

    const cust = customers.find(c => c.id === customerId);
    const selectedAcc = accessibleAccounts.find(a => a.id === depositAccountId);

    const updated: SalesInvoice = {
      ...invoice,
      customerId,
      customerName: cust ? cust.tradeName || cust.name : invoice.customerName,
      invoiceDate,
      dueDate,
      items,
      totalAmount,
      cashPaidAmount,
      advanceAdjusted: lockedAdvance,
      adjustedAdvanceAmount: lockedAdvance,
      paidAmount: totalPaidAmount,
      dueAmount,
      paymentMethod: cashPaidAmount > 0 ? paymentMethod : invoice.paymentMethod,
      depositAccountId: cashPaidAmount > 0 ? depositAccountId : undefined,
      depositAccountName: cashPaidAmount > 0 && selectedAcc ? `${selectedAcc.bankName} (${selectedAcc.accountNumber})` : undefined,
      paymentRef: cashPaidAmount > 0 && paymentRef.trim() ? paymentRef.trim() : undefined,
      negativeStockReason: stockValidation.requiresNegativeStockReason ? negativeStockReason.trim() : invoice.negativeStockReason,
      negativeStockApprovedBy: stockValidation.requiresNegativeStockReason ? (currentUser?.name || currentUser?.email || 'Admin') : invoice.negativeStockApprovedBy,
      status: dueAmount === 0 ? 'Paid' : totalPaidAmount > 0 ? 'Partially Paid' : 'Unpaid'
    };

    onSave(updated);
  };

  const isDirty = Boolean(
    customerId !== invoice.customerId ||
    invoiceDate !== invoice.invoiceDate ||
    dueDate !== invoice.dueDate ||
    Number(cashPaidAmount) !== Number(initialCashPaid) ||
    paymentRef !== (invoice.paymentRef || '') ||
    JSON.stringify(items) !== JSON.stringify(invoice.items || [])
  );

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      isDirty={isDirty}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-blue-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-300 flex items-center justify-center border border-blue-400/20">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">Edit Sales Invoice</h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-blue-500/30 text-blue-200">
                  {invoice.invoiceNumber}
                </span>
              </div>
            </div>
          </div>
          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-xs">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span className="font-semibold">{formError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Customer <span className="text-rose-500">*</span>
              </label>
              <select
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                disabled={lockedAdvance > 0}
                required
                className="w-full border border-slate-300 rounded-xl p-2 font-medium text-slate-800 bg-white disabled:bg-slate-100 disabled:text-slate-500"
              >
                {customers.map(c => (
                  <option key={c.id} value={c.id}>{c.tradeName} ({c.code})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Invoice Date</label>
              <input
                type="date"
                required
                value={invoiceDate}
                onChange={(e) => setInvoiceDate(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Due Date</label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2 font-mono"
              />
            </div>
          </div>

          {/* Items Section */}
          <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                Invoiced Products & Materials
              </span>
              <button
                type="button"
                onClick={handleAddItem}
                className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add Item</span>
              </button>
            </div>

            <div className="space-y-2">
              {items.map((item, idx) => {
                const catalogItem = allStoredItems.find(it => it.id === item.itemId);
                const availInItemUom = catalogItem ? getAvailableStockForWarehouse(catalogItem, warehouseId) : 0;
                const origLineQtyInItemUom = (invoice.items || [])
                  .filter(ol => ol.itemId === item.itemId)
                  .reduce((sum, ol) => sum + convertQuantityBetweenUoms(ol.quantity, ol.uom || catalogItem?.uom || 'MT', catalogItem?.uom || 'MT'), 0);
                const maxAllowedInLineUom = catalogItem
                  ? convertQuantityBetweenUoms(availInItemUom + origLineQtyInItemUom, catalogItem.uom, item.uom || catalogItem.uom)
                  : Infinity;
                const isLineExceeding = catalogItem && isStockItem(catalogItem) && Number(item.quantity) > maxAllowedInLineUom + 0.0001;

                return (
                  <div key={idx} className="bg-white p-2 rounded-xl border border-slate-200 space-y-1">
                    <div className="grid grid-cols-12 gap-2 items-center">
                      <div className="col-span-5">
                        <label className="text-[10px] text-slate-400 block mb-0.5">Product</label>
                        <select
                          value={item.itemId}
                          onChange={(e) => handleItemChange(idx, 'itemId', e.target.value)}
                          className="w-full border border-slate-200 rounded-lg p-1.5 font-medium text-slate-800"
                        >
                          {allStoredItems
                            .filter(it => (it.status || 'Active') === 'Active' || it.id === item.itemId)
                            .map(it => {
                              const whAvail = getAvailableStockForWarehouse(it, warehouseId);
                              const wasOnOrig = (invoice.items || []).some(ol => ol.itemId === it.id);
                              const outOfStock = isStockItem(it) && whAvail <= 0 && !wasOnOrig;
                              return (
                                <option
                                  key={it.id}
                                  value={it.id}
                                  disabled={outOfStock && !(allowNegativeStock && isAdmin)}
                                >
                                  {it.name} ({it.sku}) — {outOfStock ? 'Out of stock (0 ' + it.uom + ')' : `Avail: ${whAvail} ${it.uom}`}
                                </option>
                              );
                            })}
                        </select>
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">Quantity ({item.uom || 'MT'})</label>
                        <input
                          type="number"
                          min={0.1}
                          step="any"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                          className={`w-full border rounded-lg p-1.5 font-mono font-bold ${
                            isLineExceeding ? 'border-rose-400 bg-rose-50 text-rose-800' : 'border-slate-200 text-slate-800'
                          }`}
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">Rate (৳)</label>
                        <input
                          type="number"
                          min={0}
                          value={item.unitPrice}
                          onChange={(e) => handleItemChange(idx, 'unitPrice', e.target.value)}
                          className="w-full border border-slate-200 rounded-lg p-1.5 font-mono font-bold text-slate-800"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">Total (৳)</label>
                        <div className="p-1.5 font-mono font-bold text-blue-700 bg-slate-50 rounded-lg text-right">
                          {(item.amount || 0).toLocaleString()}
                        </div>
                      </div>

                      <div className="col-span-1 text-center">
                        <button
                          type="button"
                          disabled={items.length <= 1}
                          onClick={() => handleRemoveItem(idx)}
                          className={`p-1.5 rounded-lg text-slate-400 hover:text-rose-600 transition-colors ${items.length <= 1 ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {catalogItem && isStockItem(catalogItem) && (
                      <div className="flex items-center justify-between text-[10px] font-mono px-1">
                        <span className="text-slate-500">
                          Available in yard: <strong>{availInItemUom} {catalogItem.uom}</strong> (Max allowed on line: <strong>{Number(maxAllowedInLineUom.toFixed(2))} {item.uom || catalogItem.uom}</strong>)
                        </span>
                        {isLineExceeding && (
                          <span className="text-rose-600 font-bold">
                            Exceeds available stock by {Number((Number(item.quantity) - maxAllowedInLineUom).toFixed(2))} {item.uom || catalogItem.uom}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {stockValidation.requiresNegativeStockReason && allowNegativeStock && isAdmin && (
              <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-xl space-y-1">
                <label className="block text-[11px] font-bold text-amber-900">
                  Admin Negative Stock Override Reason <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Enter reason for selling above available warehouse stock..."
                  value={negativeStockReason}
                  onChange={(e) => setNegativeStockReason(e.target.value)}
                  className="w-full p-1.5 bg-white border border-amber-300 rounded-lg text-xs text-slate-900"
                />
              </div>
            )}
          </div>

          {/* Pricing bottom */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Payment Channel</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full border border-slate-300 rounded-xl p-2 bg-white text-xs"
                >
                  <option value="Cash">Cash in Hand</option>
                  <option value="Bank Transfer">Bank Transfer (RTGS / BEFTN)</option>
                  <option value="Cheque">Bank Cheque</option>
                  <option value="Mobile Banking">Mobile Banking (bKash/Nagad)</option>
                </select>
              </div>

              <div className="space-y-2 font-mono text-xs">
                <div className="flex justify-between text-sm font-bold text-slate-900">
                  <span>Invoice Total:</span>
                  <span>BDT {totalAmount.toLocaleString()}</span>
                </div>

                {lockedAdvance > 0 && (
                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200 text-indigo-700">
                    <span className="font-bold">
                      Advance Adjusted {invoice.adjustmentVoucherNo ? `(${invoice.adjustmentVoucherNo})` : ''} [Locked]:
                    </span>
                    <span className="font-bold">BDT {lockedAdvance.toLocaleString()}</span>
                  </div>
                )}

                <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200">
                  <span className="text-emerald-700 font-bold">Cash / Bank Paid (BDT):</span>
                  <input
                    type="number"
                    min={0}
                    max={Math.max(0, totalAmount - lockedAdvance)}
                    value={cashPaidAmount}
                    onChange={(e) => setCashPaidAmount(Number(e.target.value))}
                    className="w-32 p-1 border border-emerald-300 rounded text-right font-bold text-emerald-700"
                  />
                </div>

                <div className="flex justify-between text-xs font-bold text-rose-600 pt-1 border-t border-slate-200">
                  <span>Receivable Due:</span>
                  <span>BDT {dueAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Required Deposit To dropdown shown ONLY when cashPaidAmount > 0 */}
            {cashPaidAmount > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Deposit To Account <span className="text-rose-500">*</span>:
                  </label>
                  <select
                    value={depositAccountId}
                    onChange={(e) => setDepositAccountId(e.target.value)}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2 bg-white text-xs font-medium text-slate-800"
                  >
                    {filteredDepositAccounts.length === 0 ? (
                      <option value="">No account found</option>
                    ) : (
                      filteredDepositAccounts.map(acc => (
                        <option key={acc.id} value={acc.id}>
                          {acc.bankName} ({acc.accountNumber}) {acc.branch ? `— ${acc.branch}` : ''} | Balance: ৳{(acc.ledgerBalance || 0).toLocaleString()}
                        </option>
                      ))
                    )}
                  </select>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {currentUser?.role === 'admin' ? 'Admin View: All accounts visible' : `Branch Account: ${currentUser?.branch || 'Local'}`}
                  </span>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {paymentMethod === 'Cheque' ? 'Cheque No.:' : 'Reference / Trx No.:'}
                  </label>
                  <input
                    type="text"
                    placeholder={paymentMethod === 'Cheque' ? 'e.g. CQ-902812' : 'e.g. MR-2026-0812 / Slip Ref'}
                    value={paymentRef}
                    onChange={(e) => setPaymentRef(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2 bg-white font-mono text-xs"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
