import React, { useState } from 'react';
import { 
  CreditCard, 
  X, 
  Save, 
  Calendar, 
  DollarSign, 
  Building2, 
  FileText 
} from 'lucide-react';
import { CustomerPayment, Customer, BankAccount } from '../../types/erp';
import { getBankAccounts, isCashAccount } from '../../utils/bankAccountStorage';
import { useAuth } from '../../contexts/AuthContext';
import { ModalWrapper } from '../common/ModalWrapper';

interface EditCustomerPaymentModalProps {
  isOpen: boolean;
  payment: CustomerPayment | null;
  customers: Customer[];
  onClose: () => void;
  onSave: (updated: CustomerPayment) => void;
}

export const EditCustomerPaymentModal: React.FC<EditCustomerPaymentModalProps> = ({
  isOpen,
  payment,
  customers,
  onClose,
  onSave
}) => {
  if (!isOpen || !payment) return null;

  const { currentUser } = useAuth();
  const [bankAccounts] = useState<BankAccount[]>(() => getBankAccounts());

  const [paymentDate, setPaymentDate] = useState(payment.paymentDate);
  const [amount, setAmount] = useState(payment.amount);
  const [paymentType, setPaymentType] = useState<'Invoice Payment' | 'Advance Payment'>(payment.paymentType || 'Invoice Payment');
  const [paymentMethod, setPaymentMethod] = useState<'Bank Transfer' | 'Cheque' | 'Cash' | 'Mobile Banking'>(
    payment.paymentMethod || 'Cash'
  );
  const [bankAccountId, setBankAccountId] = useState(payment.bankAccountId || '');
  const [chequeNo, setChequeNo] = useState(payment.chequeNo || '');
  const [refNumber, setRefNumber] = useState(payment.refNumber || '');
  const [note, setNote] = useState(payment.note || '');

  // Filter accounts: Managers see only their branch accounts; admin sees all
  const accessibleAccounts = React.useMemo(() => {
    if (currentUser?.role === 'admin') {
      return bankAccounts;
    }
    const userBranch = currentUser?.branch;
    if (!userBranch || userBranch === 'All Branches') {
      return bankAccounts;
    }
    const branchKey = userBranch.toLowerCase().replace(' office', '');
    return bankAccounts.filter(acc => 
      !acc.branch || acc.branch.toLowerCase().includes(branchKey) || acc.branch === 'Head Office'
    );
  }, [bankAccounts, currentUser]);

  // Payment method controls default list: Cash shows cash; Bank Transfer & Cheque show bank; bKash/Nagad shows mobile banking
  const filteredDepositAccounts = React.useMemo(() => {
    if (paymentMethod === 'Cash') {
      const cashList = accessibleAccounts.filter(acc => isCashAccount(acc));
      return cashList.length > 0 ? cashList : accessibleAccounts;
    } else if (paymentMethod === 'Bank Transfer' || paymentMethod === 'Cheque') {
      const bankList = accessibleAccounts.filter(acc => !isCashAccount(acc));
      return bankList.length > 0 ? bankList : accessibleAccounts;
    } else if (paymentMethod === 'Mobile Banking') {
      const mobList = accessibleAccounts.filter(acc => 
        acc.bankName.toLowerCase().includes('bkash') ||
        acc.bankName.toLowerCase().includes('nagad') ||
        acc.bankName.toLowerCase().includes('rocket') ||
        acc.bankName.toLowerCase().includes('mobile') ||
        acc.accountType === 'POS Cash'
      );
      return mobList.length > 0 ? mobList : accessibleAccounts;
    }
    return accessibleAccounts;
  }, [accessibleAccounts, paymentMethod]);

  // Auto-select first matching account if none selected
  React.useEffect(() => {
    if (filteredDepositAccounts.length > 0) {
      if (!bankAccountId || !filteredDepositAccounts.some(a => a.id === bankAccountId)) {
        setBankAccountId(filteredDepositAccounts[0].id);
      }
    }
  }, [filteredDepositAccounts, bankAccountId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedAcc = accessibleAccounts.find(a => a.id === bankAccountId);

    const updated: CustomerPayment = {
      ...payment,
      paymentDate,
      amount,
      paymentType,
      paymentMethod,
      bankAccountId: selectedAcc?.id,
      bankName: selectedAcc?.bankName,
      branchName: selectedAcc?.branch,
      bankAccountName: selectedAcc ? `${selectedAcc.bankName} (${selectedAcc.accountNumber})` : undefined,
      chequeNo: paymentMethod === 'Cheque' ? chequeNo : undefined,
      refNumber: refNumber.trim() || undefined,
      note
    };
    onSave(updated);
  };

  const isDirty = Boolean(
    Number(amount) !== Number(payment.amount) ||
    paymentDate !== payment.paymentDate ||
    paymentMethod !== (payment.paymentMethod || 'Cash') ||
    refNumber !== (payment.refNumber || '') ||
    note !== (payment.note || '')
  );

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      isDirty={isDirty}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        <div className="sticky top-0 z-10 p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-emerald-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center border border-emerald-400/20">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">Edit Money Receipt</h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-emerald-500/30 text-emerald-200">
                  {payment.receiptNumber}
                </span>
              </div>
              <p className="text-xs text-slate-400">Customer: {payment.customerTradeName || payment.customerName}</p>
            </div>
          </div>
          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Collected Amount (৳) <span className="text-rose-500">*</span>
            </label>
            <input
              type="number"
              min={1}
              required
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-base text-emerald-700 focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Receipt Date</label>
              <input
                type="date"
                required
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full border border-slate-300 rounded-xl p-2 bg-white"
              >
                <option value="Bank Transfer">Bank Transfer (RTGS / BEFTN)</option>
                <option value="Cheque">Bank Cheque</option>
                <option value="Cash">Cash in Hand</option>
                <option value="Mobile Banking">Mobile Banking (bKash/Nagad)</option>
              </select>
            </div>
          </div>

          {/* Required Deposit To Account */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Deposit To Account <span className="text-rose-500">*</span>:
              </label>
              <select
                value={bankAccountId}
                onChange={(e) => setBankAccountId(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-xl p-2 bg-white text-xs font-medium text-slate-800"
              >
                {filteredDepositAccounts.length === 0 ? (
                  <option value="">No account found</option>
                ) : (
                  filteredDepositAccounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.bankName} ({acc.accountNumber}) {acc.branch ? `— ${acc.branch}` : ''} | Balance: ৳{(acc.ledgerBalance || 0).toLocaleString()}
                    </option>
                  ))
                )}
              </select>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                {currentUser?.role === 'admin' ? 'Admin View: All accounts visible' : `Branch Account: ${currentUser?.branch || 'Local'}`}
              </span>
            </div>

            {paymentMethod === 'Cheque' && (
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Cheque Number</label>
                <input
                  type="text"
                  value={chequeNo}
                  onChange={(e) => setChequeNo(e.target.value)}
                  placeholder="e.g. CQ-77821"
                  className="w-full border border-slate-300 rounded-xl p-2 font-mono text-xs"
                />
              </div>
            )}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Reference / Slip Number</label>
            <input
              type="text"
              value={refNumber}
              onChange={(e) => setRefNumber(e.target.value)}
              placeholder="e.g. TR-2026-904"
              className="w-full border border-slate-300 rounded-xl p-2 font-mono"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Remarks / Note</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g. Clearing confirmed by accounts"
              className="w-full border border-slate-300 rounded-xl p-2"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
