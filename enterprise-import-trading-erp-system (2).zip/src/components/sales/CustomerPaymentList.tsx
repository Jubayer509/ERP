import React, { useState, useMemo, useEffect } from 'react';
import { 
  CreditCard, 
  Search, 
  Filter, 
  Printer, 
  Plus, 
  FileText, 
  Calendar, 
  Building2, 
  ArrowDownRight, 
  CheckCircle2, 
  Clock, 
  Landmark, 
  Wallet,
  Receipt,
  Download,
  Share2,
  ExternalLink,
  Edit,
  Trash2,
  RotateCcw,
  Sparkles
} from 'lucide-react';
import { Customer, CustomerPayment, SalesInvoice } from '../../types/erp';
import { PrintableMoneyReceiptModal } from './PrintableMoneyReceiptModal';
import { EditCustomerPaymentModal } from './EditCustomerPaymentModal';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { RecycleBinModal } from '../common/RecycleBinModal';
import { saveDeletedRecord, getDeletedRecords, subscribeRecycleBin } from '../../utils/recycleBinStorage';

interface CustomerPaymentListProps {
  payments: CustomerPayment[];
  customers: Customer[];
  invoices?: SalesInvoice[];
  onCollectNewPayment: () => void;
  onUpdatePayment?: (payment: CustomerPayment) => void;
  onDeletePayment?: (id: string) => void;
  onViewCustomerStatement: (customerId: string) => void;
  onViewInvoice?: (invoiceNumber: string) => void;
}

export const CustomerPaymentList: React.FC<CustomerPaymentListProps> = ({
  payments,
  customers,
  invoices = [],
  onCollectNewPayment,
  onUpdatePayment,
  onDeletePayment,
  onViewCustomerStatement,
  onViewInvoice
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomerFilter, setSelectedCustomerFilter] = useState('All');
  const [selectedMethodFilter, setSelectedMethodFilter] = useState('All');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<'All' | 'Advance Payment' | 'Invoice Payment'>('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedPrintPayment, setSelectedPrintPayment] = useState<CustomerPayment | null>(null);

  // Edit, Delete & Recycle Bin state
  const [editingPayment, setEditingPayment] = useState<CustomerPayment | null>(null);
  const [deletingPayment, setDeletingPayment] = useState<CustomerPayment | null>(null);
  const [isRecycleBinOpen, setIsRecycleBinOpen] = useState(false);
  const [trashCount, setTrashCount] = useState<number>(() => {
    return getDeletedRecords().filter(r => r.recordType === 'customer_payment').length;
  });

  useEffect(() => {
    const unsub = subscribeRecycleBin(() => {
      setTrashCount(getDeletedRecords().filter(r => r.recordType === 'customer_payment').length);
    });
    return unsub;
  }, []);

  const handleConfirmDelete = (reason: string) => {
    if (!deletingPayment) return;
    saveDeletedRecord({
      recordType: 'customer_payment',
      originalId: deletingPayment.id,
      referenceNumber: deletingPayment.receiptNumber,
      title: `Customer Money Receipt (${deletingPayment.customerTradeName || deletingPayment.customerName})`,
      partyName: deletingPayment.customerTradeName || deletingPayment.customerName,
      amount: deletingPayment.amount,
      date: deletingPayment.paymentDate,
      deletedBy: 'Current User',
      reason,
      data: deletingPayment
    });
    if (onDeletePayment) {
      onDeletePayment(deletingPayment.id);
    }
    setDeletingPayment(null);
  };

  // Quick Date presets
  const applyDatePreset = (preset: 'today' | 'this_month' | 'last_30' | 'all') => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (preset === 'today') {
      setStartDate(todayStr);
      setEndDate(todayStr);
    } else if (preset === 'this_month') {
      setStartDate('2026-09-01');
      setEndDate('2026-09-30');
    } else if (preset === 'last_30') {
      const past30 = new Date(today.getTime() - 30 * 86400000).toISOString().split('T')[0];
      setStartDate(past30);
      setEndDate(todayStr);
    } else {
      setStartDate('');
      setEndDate('');
    }
  };

  // Filtered Payments
  const filteredPayments = useMemo(() => {
    return payments.filter(pay => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchReceipt = pay.receiptNumber.toLowerCase().includes(q);
        const matchCustomer = pay.customerName.toLowerCase().includes(q) || 
          (pay.customerTradeName && pay.customerTradeName.toLowerCase().includes(q));
        const matchBank = pay.bankName && pay.bankName.toLowerCase().includes(q);
        const matchCheque = pay.chequeNo && pay.chequeNo.toLowerCase().includes(q);
        const matchRef = pay.refNumber && pay.refNumber.toLowerCase().includes(q);
        const matchNote = pay.note && pay.note.toLowerCase().includes(q);
        const matchInv = pay.invoiceNumber && pay.invoiceNumber.toLowerCase().includes(q);
        if (!matchReceipt && !matchCustomer && !matchBank && !matchCheque && !matchRef && !matchNote && !matchInv) {
          return false;
        }
      }

      // Customer Filter
      if (selectedCustomerFilter !== 'All' && pay.customerId !== selectedCustomerFilter) {
        return false;
      }

      // Method Filter
      if (selectedMethodFilter !== 'All' && pay.paymentMethod !== selectedMethodFilter) {
        return false;
      }

      // Payment Type Filter (Advance Payment vs Due Invoice Payment)
      if (selectedTypeFilter !== 'All') {
        const isAdv = pay.paymentType === 'Advance Payment' || pay.note?.toLowerCase().includes('advance') || pay.refNumber?.toLowerCase().includes('adv');
        if (selectedTypeFilter === 'Advance Payment' && !isAdv) return false;
        if (selectedTypeFilter === 'Invoice Payment' && isAdv) return false;
      }

      // Date Range
      if (startDate && pay.paymentDate < startDate) {
        return false;
      }
      if (endDate && pay.paymentDate > endDate) {
        return false;
      }

      return true;
    });
  }, [payments, searchQuery, selectedCustomerFilter, selectedMethodFilter, selectedTypeFilter, startDate, endDate]);

  // Calculations for KPI Cards
  const stats = useMemo(() => {
    let totalAmount = 0;
    let bankAmount = 0;
    let chequeAmount = 0;
    let cashAmount = 0;
    let mobileAmount = 0;

    payments.forEach(p => {
      totalAmount += p.amount;
      if (p.paymentMethod === 'Bank Transfer') bankAmount += p.amount;
      else if (p.paymentMethod === 'Cheque') chequeAmount += p.amount;
      else if (p.paymentMethod === 'Cash') cashAmount += p.amount;
      else if (p.paymentMethod === 'Mobile Banking') mobileAmount += p.amount;
    });

    return {
      totalAmount,
      bankAmount,
      chequeAmount,
      cashAmount,
      mobileAmount,
      totalCount: payments.length
    };
  }, [payments]);

  const customerMap = useMemo(() => {
    const map = new Map<string, Customer>();
    customers.forEach(c => map.set(c.id, c));
    return map;
  }, [customers]);

  return (
    <div className="space-y-4">
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Total Collections
            </span>
            <span className="text-xl font-bold text-slate-900 font-mono mt-0.5 block">
              BDT {stats.totalAmount.toLocaleString()}
            </span>
            <span className="text-[11px] text-emerald-600 font-medium flex items-center gap-1 mt-0.5">
              <CheckCircle2 className="w-3 h-3" />
              {stats.totalCount} Money Receipts
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 border border-emerald-100">
            <CreditCard className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Bank Wire & Transfers
            </span>
            <span className="text-xl font-bold text-indigo-700 font-mono mt-0.5 block">
              BDT {stats.bankAmount.toLocaleString()}
            </span>
            <span className="text-[11px] text-slate-500 mt-0.5 block">
              BEFTN, RTGS & Funds Transfer
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 border border-indigo-100">
            <Landmark className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Cheque Collections
            </span>
            <span className="text-xl font-bold text-amber-700 font-mono mt-0.5 block">
              BDT {stats.chequeAmount.toLocaleString()}
            </span>
            <span className="text-[11px] text-amber-600 font-medium flex items-center gap-1 mt-0.5">
              <Clock className="w-3 h-3" />
              Clearing & Settlement Receipts
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 border border-amber-100">
            <Receipt className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Cash Receipts
            </span>
            <span className="text-xl font-bold text-teal-700 font-mono mt-0.5 block">
              BDT {stats.cashAmount.toLocaleString()}
            </span>
            <span className="text-[11px] text-slate-500 mt-0.5 block">
              Direct Counter & Branch Deposits
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0 border border-teal-100">
            <Wallet className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        {/* Header & Actions */}
        <div className="p-4 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900">
                Customer Payments & Money Receipts
              </h2>
              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 border border-emerald-200 rounded text-[10px] font-bold">
                {filteredPayments.length} Receipts
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            <button
              type="button"
              onClick={() => setIsRecycleBinOpen(true)}
              className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
              title="Recycle Bin"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
              <span>Trash ({trashCount})</span>
            </button>

            <button
              onClick={onCollectNewPayment}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Collect Payment
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center gap-2.5 text-xs">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by receipt no, customer, bank, cheque..."
              className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Customer Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-500 font-medium">Customer:</span>
            <select
              value={selectedCustomerFilter}
              onChange={(e) => setSelectedCustomerFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Customers ({customers.length})</option>
              {customers.map(c => (
                <option key={c.id} value={c.id}>
                  {c.tradeName || c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Method Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-500 font-medium">Method:</span>
            <select
              value={selectedMethodFilter}
              onChange={(e) => setSelectedMethodFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Methods</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cheque">Cheque</option>
              <option value="Cash">Cash</option>
              <option value="Mobile Banking">Mobile Banking</option>
            </select>
          </div>

          {/* Payment Type Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-500 font-medium">Type:</span>
            <select
              value={selectedTypeFilter}
              onChange={(e) => setSelectedTypeFilter(e.target.value as any)}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Types</option>
              <option value="Advance Payment">Advance Payment</option>
              <option value="Invoice Payment">Invoice / Due Clearance</option>
            </select>
          </div>

          {/* Quick Date Presets */}
          <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-300">
            <button
              onClick={() => applyDatePreset('all')}
              className={`px-2 py-1 rounded text-[11px] font-semibold transition-colors ${
                !startDate && !endDate ? 'bg-slate-200 text-slate-900' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All
            </button>
            <button
              onClick={() => applyDatePreset('this_month')}
              className={`px-2 py-1 rounded text-[11px] font-semibold transition-colors ${
                startDate === '2026-09-01' ? 'bg-slate-200 text-slate-900' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              This Month
            </button>
            <button
              onClick={() => applyDatePreset('last_30')}
              className="px-2 py-1 rounded text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition-colors"
            >
              Last 30 Days
            </button>
          </div>

          {/* Active Filter Clear */}
          {(searchQuery || selectedCustomerFilter !== 'All' || selectedMethodFilter !== 'All' || startDate || endDate) && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCustomerFilter('All');
                setSelectedMethodFilter('All');
                setStartDate('');
                setEndDate('');
              }}
              className="px-2 py-1 text-[11px] text-rose-600 hover:text-rose-700 font-semibold underline ml-auto"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Payments Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-3.5">MR Number</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3.5">Customer Account</th>
                <th className="py-3 px-3.5 text-right">Collected Amount</th>
                <th className="py-3 px-3">Payment Method</th>
                <th className="py-3 px-3">Bank / Instrument</th>
                <th className="py-3 px-3">Invoice Ref</th>
                <th className="py-3 px-3">Narration</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-700">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    <CreditCard className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600 text-sm">No payment records found</p>
                    <p className="text-xs text-slate-400 mt-0.5">Adjust filter options or record a new customer collection</p>
                    <button
                      onClick={onCollectNewPayment}
                      className="mt-3 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 shadow-xs transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Collect Payment
                    </button>
                  </td>
                </tr>
              ) : (
                filteredPayments.map((pay) => {
                  const cust = customerMap.get(pay.customerId);
                  return (
                    <tr 
                      key={pay.id} 
                      className="hover:bg-emerald-50/30 transition-colors group"
                    >
                      {/* Receipt No */}
                      <td className="py-3 px-3.5 font-mono">
                        <button
                          type="button"
                          onClick={() => setSelectedPrintPayment(pay)}
                          className="font-bold text-emerald-700 hover:text-emerald-800 hover:underline flex items-center gap-1 text-left"
                          title="View and print official money receipt"
                        >
                          <Receipt className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{pay.receiptNumber}</span>
                        </button>
                        <span className="text-[10px] text-slate-400 block font-sans">
                          {pay.collectedBy || 'Accounts Desk'}
                        </span>
                      </td>

                      {/* Date */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="font-medium text-slate-800 block">{pay.paymentDate}</span>
                        <span className="text-[10px] text-slate-400 font-mono">Deposit Date</span>
                      </td>

                      {/* Customer */}
                      <td className="py-3 px-3.5">
                        <div className="font-semibold text-slate-900 text-[13px] leading-tight">
                          {cust?.tradeName || pay.customerTradeName || pay.customerName}
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                          <span>{pay.customerName}</span>
                          {cust?.city && (
                            <span className="text-slate-400">• {cust.city}</span>
                          )}
                        </div>
                      </td>

                      {/* Amount */}
                      <td className="py-3 px-3.5 text-right font-mono">
                        <div className="text-sm font-black text-emerald-700">
                          BDT {pay.amount.toLocaleString()}
                        </div>
                        {pay.paymentType === 'Advance Payment' || pay.note?.toLowerCase().includes('advance') || pay.refNumber?.toLowerCase().includes('adv') ? (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 font-sans">
                            <Sparkles className="w-2.5 h-2.5 text-emerald-600" />
                            Advance
                          </span>
                        ) : (
                          <span className="text-[10px] text-emerald-600 font-sans font-medium">
                            ✓ Credited
                          </span>
                        )}
                      </td>

                      {/* Payment Method Badge */}
                      <td className="py-3 px-3">
                        {pay.paymentMethod === 'Bank Transfer' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                            <Landmark className="w-3 h-3 text-indigo-600" />
                            Bank Wire
                          </span>
                        )}
                        {pay.paymentMethod === 'Cheque' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                            <Receipt className="w-3 h-3 text-amber-600" />
                            Cheque
                          </span>
                        )}
                        {pay.paymentMethod === 'Cash' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-teal-50 text-teal-800 border border-teal-200">
                            <Wallet className="w-3 h-3 text-teal-600" />
                            Cash
                          </span>
                        )}
                        {pay.paymentMethod === 'Mobile Banking' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-pink-50 text-pink-800 border border-pink-200">
                            <CreditCard className="w-3 h-3 text-pink-600" />
                            bKash / Nagad
                          </span>
                        )}
                      </td>

                      {/* Bank / Instrument Details */}
                      <td className="py-3 px-3">
                        {pay.bankName ? (
                          <div>
                            <span className="font-semibold text-slate-800 block text-[11px] truncate max-w-[180px]">
                              {pay.bankName}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {pay.chequeNo ? `Chq # ${pay.chequeNo}` : pay.branchName || pay.refNumber || 'Online RTGS/BEFTN'}
                            </span>
                          </div>
                        ) : pay.refNumber ? (
                          <span className="font-mono text-[11px] text-slate-600 block truncate max-w-[150px]">
                            Ref: {pay.refNumber}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px]">Direct Counter Receipt</span>
                        )}
                      </td>

                      {/* Invoice Reference */}
                      <td className="py-3 px-3">
                        {pay.invoiceNumber ? (
                          <button
                            type="button"
                            onClick={() => onViewInvoice && onViewInvoice(pay.invoiceNumber!)}
                            className="inline-flex items-center gap-1 font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 hover:bg-blue-100 transition-colors text-[10px]"
                            title="View Invoice"
                          >
                            <FileText className="w-2.5 h-2.5 text-blue-600" />
                            <span>{pay.invoiceNumber}</span>
                          </button>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-mono">
                            On Account Due
                          </span>
                        )}
                      </td>

                      {/* Narration */}
                      <td className="py-3 px-3 text-slate-600 text-[11px] max-w-[190px] truncate" title={pay.note}>
                        {pay.note || 'Payment received and credited to customer ledger'}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Cleared
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5 flex-wrap">
                          <button
                            type="button"
                            onClick={() => setEditingPayment(pay)}
                            className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded text-[11px] font-semibold inline-flex items-center gap-1 transition-colors border border-blue-200 cursor-pointer"
                            title="Edit Money Receipt"
                          >
                            <Edit className="w-3 h-3 text-blue-600" />
                            <span>Edit</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setSelectedPrintPayment(pay)}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded text-[11px] font-bold inline-flex items-center gap-1 transition-colors border border-emerald-200 shadow-2xs cursor-pointer"
                            title="Print official money receipt"
                          >
                            <Printer className="w-3 h-3 text-emerald-600" />
                            <span>Receipt</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onViewCustomerStatement(pay.customerId)}
                            className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-semibold inline-flex items-center gap-1 transition-colors cursor-pointer"
                            title="View customer statement ledger"
                          >
                            <FileText className="w-3 h-3 text-slate-500" />
                            <span>Statement</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setDeletingPayment(pay)}
                            className="p-1 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer border border-transparent hover:border-rose-200"
                            title="Move to Recycle Bin"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Summary Bar */}
        {filteredPayments.length > 0 && (
          <div className="p-3 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-600 gap-2">
            <div>
              <span>Showing: </span>
              <span className="font-bold text-slate-900">{filteredPayments.length}</span>
              <span> Receipts (out of </span>
              <span className="font-bold text-slate-900">{payments.length}</span>
              <span> total)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-500">Filtered Collection Total:</span>
              <span className="font-mono font-bold text-emerald-700 text-sm bg-emerald-100/70 px-2.5 py-0.5 rounded border border-emerald-200">
                BDT {filteredPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Printable Money Receipt Modal */}
      {selectedPrintPayment && (
        <PrintableMoneyReceiptModal
          payment={selectedPrintPayment}
          customer={customerMap.get(selectedPrintPayment.customerId)}
          onClose={() => setSelectedPrintPayment(null)}
        />
      )}

      {/* Edit Customer Payment Modal */}
      {editingPayment && (
        <EditCustomerPaymentModal
          isOpen={!!editingPayment}
          payment={editingPayment}
          customers={customers}
          onClose={() => setEditingPayment(null)}
          onSave={(updated) => {
            if (onUpdatePayment) {
              onUpdatePayment(updated);
            }
            setEditingPayment(null);
          }}
        />
      )}

      {/* Delete Confirmation Modal with Soft Delete Notice */}
      {deletingPayment && (
        <DeleteConfirmModal
          isOpen={!!deletingPayment}
          title="Customer Money Receipt"
          referenceNumber={deletingPayment.receiptNumber}
          partyName={deletingPayment.customerTradeName || deletingPayment.customerName}
          amount={deletingPayment.amount}
          onClose={() => setDeletingPayment(null)}
          onConfirm={handleConfirmDelete}
        />
      )}

      {/* Module Recycle Bin & Restore Hub */}
      <RecycleBinModal
        isOpen={isRecycleBinOpen}
        initialType="customer_payment"
        onClose={() => setIsRecycleBinOpen(false)}
      />
    </div>
  );
};
