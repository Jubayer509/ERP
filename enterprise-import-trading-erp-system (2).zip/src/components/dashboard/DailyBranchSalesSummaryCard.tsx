import React, { useState, useEffect, useMemo } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Building2, 
  Calendar, 
  Filter, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  SlidersHorizontal, 
  Store, 
  Truck, 
  DollarSign, 
  ChevronRight,
  Info,
  Maximize2,
  RefreshCw,
  Edit3
} from 'lucide-react';
import { ModuleTab, POSSale } from '../../types/erp';
import { MOCK_POS_SALES } from '../../data/mockErpData';
import { getSalesInvoices } from '../../utils/salesStorage';

interface DailyBranchSalesSummaryCardProps {
  onNavigate: (tab: ModuleTab) => void;
  currency?: string;
}

interface BranchDailyData {
  id: string;
  name: string;
  banglaName: string;
  code: string;
  revenue: number;
  target: number;
  transactionsCount: number;
  trucksCount: number;
  cashCollection: number;
  dueAmount: number;
  managerName: string;
  color: string;
  lightBg: string;
  borderColor: string;
}

const LOCAL_STORAGE_POS_KEY = 'tradecore_pos_sales_v1';
const LOCAL_STORAGE_TARGETS_KEY = 'tradecore_daily_targets_v1';

export const DailyBranchSalesSummaryCard: React.FC<DailyBranchSalesSummaryCardProps> = ({
  onNavigate,
  currency = 'BDT'
}) => {
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-22');
  const [chartMode, setChartMode] = useState<'vertical' | 'horizontal'>('vertical');
  const [selectedBranchDetail, setSelectedBranchDetail] = useState<BranchDailyData | null>(null);
  const [hoveredBranchId, setHoveredBranchId] = useState<string | null>(null);
  const [isEditingTargets, setIsEditingTargets] = useState<boolean>(false);

  // Editable Daily Targets (in BDT)
  const defaultTargets: Record<string, number> = {
    burimari: 450000,     // 4.5 Lakh BDT
    sonahat: 420000,      // 4.2 Lakh BDT
    dhaka: 2000000,       // 20.0 Lakh BDT
    chittagong: 1800000   // 18.0 Lakh BDT
  };

  const [targets, setTargets] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_TARGETS_KEY);
      if (saved) return { ...defaultTargets, ...JSON.parse(saved) };
    } catch (e) {
      console.error('Failed to parse saved targets', e);
    }
    return defaultTargets;
  });

  const handleSaveTargets = (newTargets: Record<string, number>) => {
    setTargets(newTargets);
    localStorage.setItem(LOCAL_STORAGE_TARGETS_KEY, JSON.stringify(newTargets));
    setIsEditingTargets(false);
  };

  // Live POS Sales read from storage (or fallback mock)
  const [posSales, setPosSales] = useState<POSSale[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_POS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse POS sales', e);
    }
    return MOCK_POS_SALES;
  });

  // Re-read storage on focus or visibility change to ensure fresh sync
  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const saved = localStorage.getItem(LOCAL_STORAGE_POS_KEY);
        if (saved) setPosSales(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Compute Branch Data for Selected Date
  const branchDataList: BranchDailyData[] = useMemo(() => {
    // 1. Burimari Office Calculations
    const burimariSales = posSales.filter(
      s => s.branch.toLowerCase().includes('burimari') && (s.date === selectedDate || !s.date)
    );
    const burimariRevenue = burimariSales.reduce((acc, s) => acc + s.grandTotal, 0);
    const burimariCash = burimariSales.reduce((acc, s) => acc + s.paidAmount, 0);
    const burimariDue = burimariSales.reduce((acc, s) => acc + s.dueAmount, 0);
    const burimariTrucks = burimariSales.filter(s => s.truckNo && s.truckNo !== 'Spot Handover / Yard Release').length;

    // 2. Sonahat Office Calculations
    const sonahatSales = posSales.filter(
      s => s.branch.toLowerCase().includes('sonahat') && (s.date === selectedDate || !s.date)
    );
    const sonahatRevenue = sonahatSales.reduce((acc, s) => acc + s.grandTotal, 0);
    const sonahatCash = sonahatSales.reduce((acc, s) => acc + s.paidAmount, 0);
    const sonahatDue = sonahatSales.reduce((acc, s) => acc + s.dueAmount, 0);
    const sonahatTrucks = sonahatSales.filter(s => s.truckNo && s.truckNo !== 'Spot Handover / Yard Release').length;

    // Real Sales Invoices for the date
    const allInvoices = getSalesInvoices();

    // 3. Dhaka Central Distribution Hub (Bulk Institutional / RMC orders)
    const dhakaPos = posSales.filter(
      s => (s.branch.toLowerCase().includes('dhaka') || s.branch.toLowerCase().includes('central') || s.branch.toLowerCase().includes('head')) &&
           (s.date === selectedDate || !s.date)
    );
    const dhakaInvoices = allInvoices.filter(
      i => (i.invoiceDate === selectedDate) && (!i.branch || i.branch.toLowerCase().includes('dhaka') || i.branch.toLowerCase().includes('principal') || i.branch.toLowerCase().includes('head'))
    );
    const dhakaRevenue = dhakaPos.reduce((acc, s) => acc + s.grandTotal, 0) + dhakaInvoices.reduce((acc, i) => acc + (i.totalAmount || 0), 0);
    const dhakaCash = dhakaPos.reduce((acc, s) => acc + s.paidAmount, 0) + dhakaInvoices.reduce((acc, i) => acc + (i.paidAmount || 0), 0);
    const dhakaDue = dhakaPos.reduce((acc, s) => acc + s.dueAmount, 0) + dhakaInvoices.reduce((acc, i) => acc + (i.dueAmount || 0), 0);
    const dhakaTrucks = dhakaPos.filter(s => s.truckNo && s.truckNo !== 'Spot Handover / Yard Release').length + dhakaInvoices.length;

    // 4. Chittagong Port & Customs Terminal (Direct imported coils, chemicals, vessel cargo)
    const ctgPos = posSales.filter(
      s => (s.branch.toLowerCase().includes('chittagong') || s.branch.toLowerCase().includes('ctg') || s.branch.toLowerCase().includes('port') || s.branch.toLowerCase().includes('agrabad')) &&
           (s.date === selectedDate || !s.date)
    );
    const ctgInvoices = allInvoices.filter(
      i => (i.invoiceDate === selectedDate) && (i.branch && (i.branch.toLowerCase().includes('chittagong') || i.branch.toLowerCase().includes('ctg') || i.branch.toLowerCase().includes('agrabad')))
    );
    const ctgRevenue = ctgPos.reduce((acc, s) => acc + s.grandTotal, 0) + ctgInvoices.reduce((acc, i) => acc + (i.totalAmount || 0), 0);
    const ctgCash = ctgPos.reduce((acc, s) => acc + s.paidAmount, 0) + ctgInvoices.reduce((acc, i) => acc + (i.paidAmount || 0), 0);
    const ctgDue = ctgPos.reduce((acc, s) => acc + s.dueAmount, 0) + ctgInvoices.reduce((acc, i) => acc + (i.dueAmount || 0), 0);
    const ctgTrucks = ctgPos.filter(s => s.truckNo && s.truckNo !== 'Spot Handover / Yard Release').length + ctgInvoices.length;

    return [
      {
        id: 'burimari',
        name: 'Burimari Land Port Office',
        banglaName: 'Burimari Land Port Branch',
        code: 'BUR',
        revenue: burimariRevenue,
        target: targets.burimari,
        transactionsCount: burimariSales.length,
        trucksCount: burimariTrucks || burimariSales.length,
        cashCollection: burimariCash,
        dueAmount: burimariDue,
        managerName: 'Burimari Branch Manager',
        color: '#f59e0b', // Amber
        lightBg: 'bg-amber-50',
        borderColor: 'border-amber-400'
      },
      {
        id: 'sonahat',
        name: 'Sonahat Land Port Office',
        banglaName: 'Sonahat Land Port Branch',
        code: 'SON',
        revenue: sonahatRevenue,
        target: targets.sonahat,
        transactionsCount: sonahatSales.length,
        trucksCount: sonahatTrucks || sonahatSales.length,
        cashCollection: sonahatCash,
        dueAmount: sonahatDue,
        managerName: 'Sonahat Branch Manager',
        color: '#10b981', // Emerald
        lightBg: 'bg-emerald-50',
        borderColor: 'border-emerald-400'
      },
      {
        id: 'dhaka',
        name: 'Dhaka Central Hub',
        banglaName: 'Dhaka Central Distribution Hub',
        code: 'DHK',
        revenue: dhakaRevenue,
        target: targets.dhaka,
        transactionsCount: 8,
        trucksCount: dhakaTrucks,
        cashCollection: dhakaCash,
        dueAmount: dhakaDue,
        managerName: 'Nafis Fuad (Distribution Lead)',
        color: '#3b82f6', // Blue
        lightBg: 'bg-blue-50',
        borderColor: 'border-blue-400'
      },
      {
        id: 'chittagong',
        name: 'Chittagong Port Terminal',
        banglaName: 'Chittagong Customs & Port Terminal',
        code: 'CTG',
        revenue: ctgRevenue,
        target: targets.chittagong,
        transactionsCount: 6,
        trucksCount: ctgTrucks,
        cashCollection: ctgCash,
        dueAmount: ctgDue,
        managerName: 'Tanvir Ahmed (Port Commercial)',
        color: '#6366f1', // Indigo
        lightBg: 'bg-indigo-50',
        borderColor: 'border-indigo-400'
      }
    ];
  }, [posSales, targets, selectedDate]);

  // Aggregate Figures
  const totalConsolidatedRevenue = branchDataList.reduce((acc, b) => acc + b.revenue, 0);
  const totalConsolidatedTarget = branchDataList.reduce((acc, b) => acc + b.target, 0);
  const overallAchievementRate = totalConsolidatedTarget > 0 
    ? (totalConsolidatedRevenue / totalConsolidatedTarget) * 100 
    : 0;
  const varianceAmount = totalConsolidatedRevenue - totalConsolidatedTarget;

  // Find Best Performing Branch
  const bestBranch = useMemo(() => {
    return [...branchDataList].sort((a, b) => (b.revenue / b.target) - (a.revenue / a.target))[0];
  }, [branchDataList]);

  // Max value for bar chart scaling (add 15% headroom)
  const maxBarValue = useMemo(() => {
    const highest = Math.max(
      ...branchDataList.map(b => Math.max(b.revenue, b.target))
    );
    return Math.ceil((highest * 1.15) / 100000) * 100000;
  }, [branchDataList]);

  // Formatter helper (respects currency switch)
  const formatBDT = (amount: number, short = false) => {
    if (currency === 'USD') {
      const usd = amount / 122.5;
      if (short) {
        if (usd >= 1000000) return `$${(usd / 1000000).toFixed(2)}M`;
        if (usd >= 1000) return `$${(usd / 1000).toFixed(1)}K`;
        return `$${Math.round(usd)}`;
      }
      return `$${Math.round(usd).toLocaleString('en-US')}`;
    }
    if (short) {
      if (amount >= 10000000) return `৳${(amount / 10000000).toFixed(2)} Cr`;
      if (amount >= 100000) return `৳${(amount / 100000).toFixed(2)} L`;
      return `৳${(amount / 1000).toFixed(0)} K`;
    }
    return `৳${Math.round(amount).toLocaleString('en-IN')}`;
  };

  return (
    <div className="bg-white border border-white/60 rounded-[28px] p-5 sm:p-6 shadow-xs space-y-5 transition-all">
      {/* 1. Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-blue-50 text-blue-600 rounded-xl border border-blue-200">
              <BarChart3 className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                  Daily Sales Summary: Revenue vs Target by Branch
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Live Sync
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Controls: Date Selector, Chart Mode, Target Config */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Date Selector */}
          <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-700">
            <Calendar className="w-3.5 h-3.5 text-slate-400 mr-1.5" />
            <select
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent font-semibold text-slate-800 outline-none cursor-pointer text-xs"
            >
              <option value="2026-09-22">Today: 22 Sep 2026</option>
              <option value="2026-09-21">Yesterday: 21 Sep 2026</option>
              <option value="2026-09-20">20 Sep 2026</option>
            </select>
          </div>

          {/* Chart Orientation Switcher */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
            <button
              type="button"
              onClick={() => setChartMode('vertical')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all flex items-center gap-1 ${
                chartMode === 'vertical'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Grouped Vertical Bar Chart"
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Vertical</span>
            </button>
            <button
              type="button"
              onClick={() => setChartMode('horizontal')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all flex items-center gap-1 ${
                chartMode === 'horizontal'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Horizontal Comparison Bars"
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Horizontal</span>
            </button>
          </div>

          {/* Target Editor Toggle */}
          <button
            type="button"
            onClick={() => setIsEditingTargets(!isEditingTargets)}
            className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5"
            title="Configure Daily Targets"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">Set Targets</span>
          </button>
        </div>
      </div>

      {/* Target Editing Drawer / Form if open */}
      {isEditingTargets && (
        <div className="p-4 bg-slate-50 border border-blue-200 rounded-2xl animate-in fade-in slide-in-from-top-2 text-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-blue-600" />
              <h4 className="font-bold text-slate-900">
                Configure Daily Sales Targets
              </h4>
            </div>
            <span className="text-[11px] text-slate-500">Figures in BDT</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {branchDataList.map((branch) => (
              <div key={branch.id} className="bg-white p-2.5 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800 block text-[11px] truncate">
                  {branch.name}
                </span>
                <div className="flex items-center gap-1">
                  <span className="text-slate-400 font-bold">{currency === 'USD' ? '$' : '৳'}</span>
                  <input
                    type="number"
                    step="10000"
                    defaultValue={targets[branch.id]}
                    id={`target-input-${branch.id}`}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 font-mono font-bold text-slate-900 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsEditingTargets(false)}
              className="px-3 py-1.5 text-slate-600 hover:text-slate-800 font-semibold"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => {
                const updated: Record<string, number> = {};
                branchDataList.forEach(b => {
                  const input = document.getElementById(`target-input-${b.id}`) as HTMLInputElement;
                  updated[b.id] = input ? Number(input.value) : targets[b.id];
                });
                handleSaveTargets(updated);
              }}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-xs transition-colors"
            >
              Save Targets & Re-render Chart
            </button>
          </div>
        </div>
      )}

      {/* 2. Consolidated High-Level KPI Summary Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Metric 1: Total Revenue */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-500 font-semibold">
            <span>Total Actual Revenue</span>
            <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-900">
            {formatBDT(totalConsolidatedRevenue)}
          </div>
          <div className="text-[10px] text-slate-500">
            Consolidated 4 Operating Branches
          </div>
        </div>

        {/* Metric 2: Total Target */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-500 font-semibold">
            <span>Consolidated Target</span>
            <Target className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-700">
            {formatBDT(totalConsolidatedTarget)}
          </div>
          <div className="text-[10px] text-slate-500">
            Assigned Daily Quota
          </div>
        </div>

        {/* Metric 3: Target Achievement % */}
        <div className={`border rounded-xl p-3.5 space-y-1 ${
          overallAchievementRate >= 100 
            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900' 
            : overallAchievementRate >= 80 
            ? 'bg-blue-50/70 border-blue-200 text-blue-900'
            : 'bg-amber-50/70 border-amber-200 text-amber-900'
        }`}>
          <div className="flex items-center justify-between text-[11px] font-semibold">
            <span>Overall Attainment</span>
            {overallAchievementRate >= 100 ? (
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <ArrowDownRight className="w-3.5 h-3.5 text-amber-600" />
            )}
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono">
            {overallAchievementRate.toFixed(1)}%
          </div>
          <div className="text-[10px] font-medium flex items-center gap-1">
            {varianceAmount >= 0 ? (
              <span className="text-emerald-700 font-bold">+{formatBDT(Math.abs(varianceAmount))} Surplus</span>
            ) : (
              <span className="text-amber-700 font-bold">-{formatBDT(Math.abs(varianceAmount))} Deficit</span>
            )}
          </div>
        </div>

        {/* Metric 4: Top Branch Badge */}
        <div className="bg-gradient-to-br from-indigo-50 to-slate-50 border border-indigo-200/80 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-[11px] text-indigo-700 font-bold">
            <span>🏆 Top Performing Unit</span>
            <span className="text-[10px] bg-indigo-100 text-indigo-800 px-1.5 py-0.2 rounded font-mono font-bold">
              {((bestBranch.revenue / bestBranch.target) * 100).toFixed(0)}%
            </span>
          </div>
          <div className="text-xs sm:text-sm font-bold text-slate-900 truncate">
            {bestBranch.name}
          </div>
          <div className="text-[10px] text-indigo-600 font-mono font-semibold">
            {formatBDT(bestBranch.revenue)} / {formatBDT(bestBranch.target, true)} Target
          </div>
        </div>
      </div>

      {/* 3. Bar Chart Legend */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-xs bg-blue-600 shadow-xs" />
            <span className="font-bold text-slate-800">Actual Revenue</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-xs bg-slate-300 border border-dashed border-slate-500" />
            <span className="font-semibold text-slate-600">Daily Target</span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-[11px] text-slate-400">
          <span>Click any branch bar for detailed invoice breakdown</span>
        </div>
      </div>

      {/* 4. The Bar Chart Visualization */}
      {chartMode === 'vertical' ? (
        /* ==================== VERTICAL GROUPED BAR CHART ==================== */
        <div className="relative pt-6 pb-2">
          {/* Background Reference Grid Lines */}
          <div className="absolute inset-x-0 top-6 bottom-10 flex flex-col justify-between pointer-events-none opacity-40">
            <div className="border-b border-dashed border-slate-300 w-full flex justify-between text-[9px] font-mono text-slate-400">
              <span>{formatBDT(maxBarValue, true)}</span>
            </div>
            <div className="border-b border-dashed border-slate-300 w-full flex justify-between text-[9px] font-mono text-slate-400">
              <span>{formatBDT(maxBarValue * 0.75, true)}</span>
            </div>
            <div className="border-b border-dashed border-slate-300 w-full flex justify-between text-[9px] font-mono text-slate-400">
              <span>{formatBDT(maxBarValue * 0.5, true)}</span>
            </div>
            <div className="border-b border-dashed border-slate-300 w-full flex justify-between text-[9px] font-mono text-slate-400">
              <span>{formatBDT(maxBarValue * 0.25, true)}</span>
            </div>
            <div className="border-b border-slate-300 w-full" />
          </div>

          {/* Grouped Bars Area */}
          <div className="relative grid grid-cols-4 gap-3 sm:gap-6 h-64 items-end px-3 sm:px-6">
            {branchDataList.map((branch) => {
              const revPercent = Math.min(100, Math.max(8, (branch.revenue / maxBarValue) * 100));
              const targetPercent = Math.min(100, Math.max(8, (branch.target / maxBarValue) * 100));
              const attainment = (branch.revenue / branch.target) * 100;
              const isExceeded = attainment >= 100;
              const isHovered = hoveredBranchId === branch.id;

              return (
                <div
                  key={branch.id}
                  className="flex flex-col items-center h-full justify-end group cursor-pointer"
                  onMouseEnter={() => setHoveredBranchId(branch.id)}
                  onMouseLeave={() => setHoveredBranchId(null)}
                  onClick={() => setSelectedBranchDetail(branch)}
                >
                  {/* Floating Percentage Badge On Top */}
                  <div className={`mb-2 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold shadow-xs transition-transform ${
                    isHovered ? 'scale-110' : ''
                  } ${
                    isExceeded 
                      ? 'bg-emerald-600 text-white' 
                      : attainment >= 80 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-amber-500 text-white'
                  }`}>
                    {attainment.toFixed(0)}%
                  </div>

                  {/* Dual Bars Container */}
                  <div className="flex items-end justify-center gap-1.5 sm:gap-3 w-full h-full pb-2">
                    {/* Revenue Bar */}
                    <div
                      style={{ height: `${revPercent}%` }}
                      className={`w-5 sm:w-10 rounded-t-lg transition-all duration-500 relative flex flex-col justify-between items-center py-1 shadow-md ${
                        isExceeded
                          ? 'bg-gradient-to-t from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400'
                          : 'bg-gradient-to-t from-blue-700 to-sky-500 hover:from-blue-600 hover:to-sky-400'
                      }`}
                    >
                      {/* Tooltip on Hover */}
                      {isHovered && (
                        <div className="absolute -top-16 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-2.5 py-1.5 rounded-xl text-[10px] font-mono font-semibold shadow-2xl z-30 whitespace-nowrap pointer-events-none border border-slate-700 animate-in fade-in zoom-in-95">
                          <div className="text-emerald-400 font-bold">Revenue: {formatBDT(branch.revenue)}</div>
                          <div className="text-slate-300">Target: {formatBDT(branch.target)}</div>
                          <div className="text-[9px] text-slate-400 mt-0.5">Click to inspect breakdown</div>
                        </div>
                      )}
                    </div>

                    {/* Target Reference Bar */}
                    <div
                      style={{ height: `${targetPercent}%` }}
                      className="w-5 sm:w-10 rounded-t-lg bg-slate-200 border-2 border-dashed border-slate-400/80 hover:border-slate-600 transition-all duration-500 relative flex items-center justify-center opacity-85"
                    />
                  </div>

                  {/* Branch Labels */}
                  <div className="pt-2 text-center w-full">
                    <span className="font-bold text-xs text-slate-900 block truncate group-hover:text-blue-600 transition-colors">
                      {branch.code}
                    </span>
                    <span className="text-[10px] text-slate-500 hidden sm:block truncate">
                      {branch.name.replace(' Office', '').replace(' Land Port', '')}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-blue-900 mt-0.5 block">
                      {formatBDT(branch.revenue, true)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* ==================== HORIZONTAL COMPARISON BARS ==================== */
        <div className="space-y-4 pt-2">
          {branchDataList.map((branch) => {
            const attainment = (branch.revenue / branch.target) * 100;
            const revBarWidth = Math.min(100, (branch.revenue / maxBarValue) * 100);
            const targetBarWidth = Math.min(100, (branch.target / maxBarValue) * 100);
            const isExceeded = attainment >= 100;

            return (
              <div 
                key={branch.id} 
                onClick={() => setSelectedBranchDetail(branch)}
                className="p-3 bg-slate-50/80 hover:bg-slate-100/80 rounded-xl border border-slate-200 transition-all cursor-pointer space-y-2 group"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full`} style={{ backgroundColor: branch.color }} />
                    <span className="font-bold text-slate-900 group-hover:text-blue-600">
                      {branch.name}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 font-mono text-xs">
                    <span className="text-slate-600">
                      Target: <strong>{formatBDT(branch.target)}</strong>
                    </span>
                    <span className="text-slate-900 font-bold">
                      Revenue: <strong className="text-blue-700">{formatBDT(branch.revenue)}</strong>
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isExceeded 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : attainment >= 80 
                        ? 'bg-blue-100 text-blue-800' 
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {attainment.toFixed(1)}% Attained
                    </span>
                  </div>
                </div>

                {/* Progress Tracks */}
                <div className="space-y-1.5 pt-1">
                  {/* Revenue Bar */}
                  <div className="w-full bg-slate-200 h-3 rounded-full overflow-hidden relative">
                    <div
                      style={{ width: `${revBarWidth}%` }}
                      className={`h-full rounded-full transition-all duration-500 ${
                        isExceeded ? 'bg-emerald-600' : 'bg-blue-600'
                      }`}
                    />
                  </div>
                  {/* Target Guide Pin */}
                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono px-0.5">
                    <span>0</span>
                    <span>Target Pin ({formatBDT(branch.target, true)})</span>
                    <span>Max {formatBDT(maxBarValue, true)}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 5. Quick Insights & Action Links Footer */}
      <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-blue-600 shrink-0" />
          <span>
            Cash and bank payment figures are synced live from the <strong>Sales & Distribution</strong> module.
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('sales')}
            className="px-3.5 py-1.5 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 rounded-xl font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>View All Sales Orders</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ==================== BRANCH DRILL-DOWN MODAL ==================== */}
      {selectedBranchDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 animate-in fade-in zoom-in-95 border border-slate-200 space-y-4">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-200">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-blue-600" />
                  <h3 className="font-bold text-slate-900 text-base">
                    {selectedBranchDetail.name}
                  </h3>
                </div>
                <p className="text-xs text-slate-500">
                  In-Charge: {selectedBranchDetail.managerName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedBranchDetail(null)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm p-1"
              >
                ✕
              </button>
            </div>

            {/* Performance Snapshot */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Daily Revenue</span>
                <div className="text-base font-bold font-mono text-slate-900">
                  {formatBDT(selectedBranchDetail.revenue)}
                </div>
                <div className="text-[10px] text-slate-500">
                  Target: {formatBDT(selectedBranchDetail.target)}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Quota Attained</span>
                <div className={`text-base font-bold font-mono ${
                  selectedBranchDetail.revenue >= selectedBranchDetail.target
                    ? 'text-emerald-600'
                    : 'text-amber-600'
                }`}>
                  {((selectedBranchDetail.revenue / selectedBranchDetail.target) * 100).toFixed(1)}%
                </div>
                <div className="text-[10px] text-slate-500">
                  {selectedBranchDetail.revenue >= selectedBranchDetail.target ? 'Target Exceeded ✓' : 'Under Target'}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Cash Collected</span>
                <div className="text-base font-bold font-mono text-emerald-700">
                  {formatBDT(selectedBranchDetail.cashCollection)}
                </div>
                <div className="text-[10px] text-slate-500">Ready in Drawer</div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Pending Due</span>
                <div className="text-base font-bold font-mono text-amber-700">
                  {formatBDT(selectedBranchDetail.dueAmount)}
                </div>
                <div className="text-[10px] text-slate-500">Receivable on Delivery</div>
              </div>
            </div>

            {/* Logistical Facts */}
            <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-xs space-y-2 text-slate-700">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-blue-600" />
                  <span>Trucks Weighed & Dispatched:</span>
                </span>
                <strong className="font-mono text-blue-900">{selectedBranchDetail.trucksCount} Trucks</strong>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Store className="w-3.5 h-3.5 text-blue-600" />
                  <span>Invoices / Challans Created:</span>
                </span>
                <strong className="font-mono text-blue-900">{selectedBranchDetail.transactionsCount} Invoices</strong>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setSelectedBranchDetail(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50 transition-colors"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  setSelectedBranchDetail(null);
                  onNavigate('sales');
                }}
                className="px-4 py-2 bg-[#def645] hover:bg-[#d0ea35] text-slate-950 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Go to {selectedBranchDetail.code} Sales Orders</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
