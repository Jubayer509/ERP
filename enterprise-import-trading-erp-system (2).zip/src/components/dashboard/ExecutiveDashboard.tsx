import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight,
  Package, 
  Users, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  ShieldAlert, 
  ChevronRight,
  ArrowRight,
  Wallet,
  Landmark,
  FileText,
  Boxes,
  AlertCircle,
  Truck,
  CreditCard,
  Building2,
  Calendar
} from 'lucide-react';
import { ModuleTab, SalesInvoice, Customer, Supplier, BankAccount } from '../../types/erp';
import { useAuth, hasPermission } from '../../contexts/AuthContext';
import { getBankAccounts, subscribeBankAccounts } from '../../utils/bankAccountStorage';
import { getCustomers, subscribeCustomers } from '../../utils/customerStorage';
import { getSuppliers, subscribeSuppliers } from '../../utils/supplierStorage';
import { getSalesInvoices, subscribeSalesInvoices } from '../../utils/salesStorage';
import { getAccountTransactions } from '../../services/accountService';
import { AccountTransaction } from '../../types/accounts';
import { DailyBranchSalesSummaryCard } from './DailyBranchSalesSummaryCard';

interface DashboardProps {
  onNavigate: (tab: ModuleTab) => void;
  currency: string;
}

export const ExecutiveDashboard: React.FC<DashboardProps> = ({ onNavigate, currency }) => {
  const { currentUser } = useAuth();

  // Real Database Subscriptions
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  const [customers, setCustomers] = useState<Customer[]>(() => getCustomers());
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => getSuppliers());
  const [invoices, setInvoices] = useState<SalesInvoice[]>(() => getSalesInvoices());
  const [transactions, setTransactions] = useState<AccountTransaction[]>(() => getAccountTransactions());

  useEffect(() => {
    const unsubBank = subscribeBankAccounts(setBankAccounts);
    const unsubCust = subscribeCustomers(setCustomers);
    const unsubSupp = subscribeSuppliers(setSuppliers);
    const unsubInv = subscribeSalesInvoices(setInvoices);

    return () => {
      unsubBank();
      unsubCust();
      unsubSupp();
      unsubInv();
    };
  }, []);

  // Compute Real Metrics
  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.substring(0, 7);

  // 1. Cash & Bank Balance
  const totalCashAndBank = useMemo(() => {
    return bankAccounts.reduce((sum, b) => sum + (Number(b.ledgerBalance) || 0), 0);
  }, [bankAccounts]);

  // 2. Total Receivables (Customer Dues)
  const totalReceivable = useMemo(() => {
    return customers.reduce((sum, c) => sum + (Number(c.currentBalance) || 0), 0);
  }, [customers]);

  // 3. Total Payables (Supplier Dues)
  const totalPayable = useMemo(() => {
    return suppliers.reduce((sum, s) => sum + (Number(s.currentPayable) || 0), 0);
  }, [suppliers]);

  // 4. Today's Sales
  const todaySales = useMemo(() => {
    return invoices
      .filter(i => i.invoiceDate === todayStr)
      .reduce((sum, i) => sum + (Number(i.totalAmount) || 0), 0);
  }, [invoices, todayStr]);

  const todayInvoicesCount = useMemo(() => {
    return invoices.filter(i => i.invoiceDate === todayStr).length;
  }, [invoices, todayStr]);

  // 5. This Month's Sales
  const thisMonthSales = useMemo(() => {
    return invoices
      .filter(i => i.invoiceDate && i.invoiceDate.startsWith(currentMonthStr))
      .reduce((sum, i) => sum + (Number(i.totalAmount) || 0), 0);
  }, [invoices, currentMonthStr]);

  // 6. Total All-time Sales
  const totalSalesAllTime = useMemo(() => {
    return invoices.reduce((sum, i) => sum + (Number(i.totalAmount) || 0), 0);
  }, [invoices]);

  // 7. Pending / Due Invoices
  const pendingInvoices = useMemo(() => {
    return invoices.filter(i => (Number(i.dueAmount) || 0) > 0);
  }, [invoices]);

  // Recent Invoices (up to 5)
  const recentInvoices = useMemo(() => {
    return [...invoices].slice(0, 6);
  }, [invoices]);

  // Format amount
  const formatAmount = (num: number) => {
    if (currency === 'USD') return `$${Math.round(num / 122.5).toLocaleString()}`;
    return `৳${Math.round(num).toLocaleString('en-IN')}`;
  };

  // Permission Checks
  const canViewSales = hasPermission(currentUser, 'sales');
  const canViewAccounts = hasPermission(currentUser, 'accounts');
  const canViewPurchase = hasPermission(currentUser, 'purchase');
  const canViewReports = hasPermission(currentUser, 'reports');

  return (
    <div className="space-y-6">
      {/* Top Welcome & KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Cash & Bank Balance */}
        {canViewAccounts && (
          <div 
            onClick={() => onNavigate('accounts')}
            className="bg-white rounded-2xl p-5 shadow-xs border border-slate-200/90 hover:border-blue-400 transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500">Cash & Bank Balance</span>
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <Landmark className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {formatAmount(totalCashAndBank)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1 font-medium">
              <span>{bankAccounts.length} Active Bank & Cash Accounts</span>
            </div>
          </div>
        )}

        {/* Card 2: Total Receivable (Customer Due) */}
        {canViewSales && (
          <div 
            onClick={() => onNavigate('sales')}
            className="bg-white rounded-2xl p-5 shadow-xs border border-slate-200/90 hover:border-amber-400 transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500">Total Receivable</span>
              <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition-colors">
                <ArrowDownRight className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-amber-700 tracking-tight">
              {formatAmount(totalReceivable)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1 font-medium">
              <span>{customers.filter(c => (c.currentBalance || 0) > 0).length} Customers with Pending Balance</span>
            </div>
          </div>
        )}

        {/* Card 3: Total Payable (Supplier Due) */}
        {canViewPurchase && (
          <div 
            onClick={() => onNavigate('purchase')}
            className="bg-white rounded-2xl p-5 shadow-xs border border-slate-200/90 hover:border-rose-400 transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500">Total Payable</span>
              <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-colors">
                <ArrowUpRight className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-rose-700 tracking-tight">
              {formatAmount(totalPayable)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1 font-medium">
              <span>{suppliers.filter(s => (s.currentPayable || 0) > 0).length} Suppliers with Pending Bills</span>
            </div>
          </div>
        )}

        {/* Card 4: Today's Sales */}
        {canViewSales && (
          <div 
            onClick={() => onNavigate('sales')}
            className="bg-white rounded-2xl p-5 shadow-xs border border-slate-200/90 hover:border-emerald-400 transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500">Today's Sales</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-emerald-700 tracking-tight">
              {formatAmount(todaySales)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1 font-medium">
              <span>Today's Invoices: {todayInvoicesCount}</span>
            </div>
          </div>
        )}
      </div>

      {/* Sales Overview Banner & Monthly Metrics */}
      {canViewSales && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white p-5 rounded-2xl shadow-sm space-y-2">
            <span className="text-xs text-indigo-200 font-semibold uppercase tracking-wider block">
              This Month's Sales
            </span>
            <div className="text-2xl sm:text-3xl font-black text-[#def645] tracking-tight">
              {formatAmount(thisMonthSales)}
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <span className="text-xs text-slate-500 font-semibold block">
              Total Invoices Issued
            </span>
            <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {invoices.length}
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <span className="text-xs text-slate-500 font-semibold block">
              All-Time Sales Turnover
            </span>
            <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {formatAmount(totalSalesAllTime)}
            </div>
          </div>
        </div>
      )}

      {/* Daily Branch Sales Summary Card (Requirement 7: Live data from sales invoices & pos sales) */}
      {canViewSales && (
        <DailyBranchSalesSummaryCard onNavigate={onNavigate} currency={currency} />
      )}

      {/* Main Content Grid: Recent Transactions & Pending Items */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column: Recent Sales Invoices / Transactions (8 Cols) */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Recent Invoices & Transactions
              </h2>
            </div>
            {canViewSales && (
              <button
                type="button"
                onClick={() => onNavigate('sales')}
                className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
              >
                <span>View All</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {recentInvoices.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No sales invoices found.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Invoice No</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3 text-right">Total Amount</th>
                    <th className="py-2.5 px-3 text-right">Paid</th>
                    <th className="py-2.5 px-3 text-right">Due</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {recentInvoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                        {inv.invoiceNumber}
                      </td>
                      <td className="py-2.5 px-3 font-medium">
                        {inv.customerName}
                      </td>
                      <td className="py-2.5 px-3 text-slate-500 font-mono">
                        {inv.invoiceDate}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-900 font-mono">
                        {formatAmount(inv.totalAmount)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-emerald-700 font-mono">
                        {formatAmount(inv.paidAmount || 0)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-amber-700 font-mono font-bold">
                        {formatAmount(inv.dueAmount || 0)}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          inv.dueAmount === 0 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : (inv.paidAmount || 0) > 0 
                              ? 'bg-amber-100 text-amber-800' 
                              : 'bg-rose-100 text-rose-800'
                        }`}>
                          {inv.status || (inv.dueAmount === 0 ? 'Paid' : 'Due')}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Right Column: Pending Items & Quick Links (4 Cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Pending Due Invoices Card */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>Pending Due Items</span>
              </h3>
              <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-full font-mono">
                {pendingInvoices.length}
              </span>
            </div>

            {pendingInvoices.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400">
                No pending due invoices. All bills settled.
              </div>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {pendingInvoices.slice(0, 6).map((p) => (
                  <div key={p.id} className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between gap-2 text-xs">
                    <div className="min-w-0">
                      <div className="font-bold text-slate-900 truncate">{p.customerName}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{p.invoiceNumber} • {p.invoiceDate}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-black text-amber-700 font-mono">{formatAmount(p.dueAmount)}</div>
                      <div className="text-[10px] text-slate-400">Due</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick System Navigation */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2.5">
            <h3 className="text-xs font-bold text-slate-900 pb-2 border-b border-slate-100">
              Quick Navigation
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {canViewSales && (
                <button
                  type="button"
                  onClick={() => onNavigate('sales')}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl font-semibold text-left transition-colors flex items-center justify-between cursor-pointer"
                >
                  <span>Sales</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                </button>
              )}
              {canViewPurchase && (
                <button
                  type="button"
                  onClick={() => onNavigate('purchase')}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl font-semibold text-left transition-colors flex items-center justify-between cursor-pointer"
                >
                  <span>Purchase</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                </button>
              )}
              {canViewAccounts && (
                <button
                  type="button"
                  onClick={() => onNavigate('accounts')}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl font-semibold text-left transition-colors flex items-center justify-between cursor-pointer"
                >
                  <span>Accounts</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                </button>
              )}
              {canViewReports && (
                <button
                  type="button"
                  onClick={() => onNavigate('reports')}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl font-semibold text-left transition-colors flex items-center justify-between cursor-pointer"
                >
                  <span>Reports</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
