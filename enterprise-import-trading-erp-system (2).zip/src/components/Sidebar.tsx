import React, { useState, useEffect, useRef } from 'react';
import { 
  TrendingUp, 
  ShoppingCart, 
  Boxes, 
  Receipt, 
  Users, 
  ShieldCheck, 
  CreditCard, 
  FileText, 
  Settings, 
  HelpCircle, 
  LayoutGrid, 
  Truck,
  ChevronDown,
  Ship,
  ArrowDownToLine,
  LogOut
} from 'lucide-react';
import { ModuleTab, InventorySubTab } from '../types/erp';
import { useAuth, hasPermission } from '../contexts/AuthContext';
import { ModalWrapper } from './common/ModalWrapper';

export interface SidebarSubItem {
  id: string;
  label: string;
  bengali?: string;
}

export interface SidebarProps {
  currentTab: ModuleTab;
  onSelectTab: (tab: ModuleTab) => void;
  // Sub-tab states
  activeSalesSubTab?: string;
  onSelectSalesSubTab?: (subTab: string) => void;
  activePurchaseSubTab?: string;
  onSelectPurchaseSubTab?: (subTab: string) => void;
  activeInventorySubTab?: InventorySubTab;
  onSelectInventorySubTab?: (subTab: InventorySubTab) => void;
  activeReportsSubTab?: string;
  onSelectReportsSubTab?: (subTab: string) => void;
  activeAccountsSubTab?: string;
  onSelectAccountsSubTab?: (subTab: string) => void;
  activeHrmSubTab?: string;
  onSelectHrmSubTab?: (subTab: string) => void;
  activeAdminSubTab?: string;
  onSelectAdminSubTab?: (subTab: string) => void;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  currentTab, 
  onSelectTab,
  activeSalesSubTab = 'invoices',
  onSelectSalesSubTab,
  activePurchaseSubTab = 'purchase_invoice',
  onSelectPurchaseSubTab,
  activeInventorySubTab = 'items',
  onSelectInventorySubTab,
  activeReportsSubTab = 'truck',
  onSelectReportsSubTab,
  activeAccountsSubTab = 'vouchers',
  onSelectAccountsSubTab,
  activeHrmSubTab = 'employees',
  onSelectHrmSubTab,
  activeAdminSubTab = 'users',
  onSelectAdminSubTab,
  isMobileOpen = false,
  onCloseMobile,
}) => {
  const { currentUser, logout } = useAuth();
  const [showHelpModal, setShowHelpModal] = useState(false);
  const sidebarNavRef = useRef<HTMLDivElement>(null);

  const resolveGroupForTab = (tab: ModuleTab): string | null => {
    if (tab === 'dashboard') return null;
    if (tab === 'hr') return 'hrm';
    if (tab === 'truck_report') return 'reports';
    if (tab === 'pos') return 'sales';
    return tab;
  };

  const [openSubMenu, setOpenSubMenu] = useState<string | null>(() => resolveGroupForTab(currentTab));

  // Sync openSubMenu whenever currentTab changes (e.g. from top nav, App.tsx, or external navigation)
  useEffect(() => {
    setOpenSubMenu(resolveGroupForTab(currentTab));
  }, [currentTab]);

  // Keep background page locked when mobile/tablet drawer is open
  useEffect(() => {
    if (!isMobileOpen) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isMobileOpen]);

  // Ensure the active menu/sub-menu item stays visible without resetting sidebar scroll position
  useEffect(() => {
    const rafId = window.requestAnimationFrame(() => {
      const container = sidebarNavRef.current;
      if (!container) return;
      const target =
        container.querySelector<HTMLElement>('[data-active-sub-item="true"]') ||
        container.querySelector<HTMLElement>('[data-active-nav-item="true"]');
      if (!target) return;

      const containerRect = container.getBoundingClientRect();
      const targetRect = target.getBoundingClientRect();
      const isAbove = targetRect.top < containerRect.top;
      const isBelow = targetRect.bottom > containerRect.bottom;

      if (isAbove || isBelow) {
        target.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      }
    });
    return () => window.cancelAnimationFrame(rafId);
  }, [
    currentTab,
    activeSalesSubTab,
    activePurchaseSubTab,
    activeInventorySubTab,
    activeReportsSubTab,
    activeAccountsSubTab,
    activeHrmSubTab,
    activeAdminSubTab,
  ]);

  // Sub-category definitions for each main module
  const salesSubItems: SidebarSubItem[] = [
    { id: 'overview', label: 'Sales Dashboard' },
    { id: 'invoices', label: 'Sales Invoices' },
    { id: 'payments', label: 'Customer Payments' },
    { id: 'customer_profiles', label: 'Customers Profile' },
    { id: 'balance_report', label: 'Customer Balance' },
    { id: 'statement', label: 'Customer Statement' },
    { id: 'aging', label: 'Aging Analysis' },
    { id: 'profitability', label: 'Profitability' },
    { id: 'truck_report', label: 'Truck Measurement' },
  ];

  const purchaseSubItems: SidebarSubItem[] = [
    { id: 'overview', label: 'Purchase Dashboard' },
    { id: 'purchase_invoice', label: 'Purchase Invoices' },
    { id: 'supplier_payments', label: 'All Payments' },
    { id: 'supplier_profiles', label: 'Supplier Profile' },
    { id: 'po', label: 'Purchase Orders' },
    { id: 'grn', label: 'Goods Receipt GRN' },
    { id: 'suppliers', label: 'Supplier Ledger' },
  ];

  const lcSubItems: SidebarSubItem[] = [
    { id: 'lc_status_summary', label: 'Status Summary' },
    { id: 'lc_product_receiving', label: 'LC Product Receiving' },
    { id: 'lc_tracking', label: 'LC Tracking & Workflow' },
    { id: 'lc_balance_sheet', label: 'LC Balance Sheet & Khata' },
    { id: 'lc_owner_report', label: 'Owner Wise LC Report' },
    { id: 'lc_register', label: 'LC Register & Instruments' },
    { id: 'lc_expenses', label: 'LC Expenses & Landed Cost' },
    { id: 'lc_exporter_bills', label: 'Exporter Bills & Settlement' },
  ];

  const inventorySubItems: SidebarSubItem[] = [
    { id: 'items', label: 'Items Catalog' },
    { id: 'stone_crushing', label: 'Stone Crushing' },
    { id: 'locations', label: 'Location & Yards' },
    { id: 'stock_transfers', label: 'Stock Transfers' },
    { id: 'stock_adjustments', label: 'Stock Adjustments' },
    { id: 'inventory_ledgers', label: 'Inventory Ledgers' },
    { id: 'inventory_movement', label: 'Movement Report' },
  ];

  const reportsSubItems: SidebarSubItem[] = [
    { id: 'sales_reports', label: 'Sales Reports' },
    { id: 'purchase_reports', label: 'Purchase Reports' },
    { id: 'expense_reports', label: 'Expense Report (COA)' },
    { id: 'stock_reports', label: 'Stock Report' },
  ];

  const accountsSubItems: SidebarSubItem[] = [
    { id: 'payment', label: 'Payment' },
    { id: 'deposit', label: 'Deposit' },
    { id: 'history', label: 'Transaction History' },
    { id: 'bank_transfer', label: 'Bank Account Transfer' },
    { id: 'coa', label: 'Chart of Accounts' },
    { id: 'fiscal_year', label: 'Fiscal Year (FY)' },
    { id: 'trial_balance', label: 'Trial Balance' },
    { id: 'pnl', label: 'Profit & Loss' },
    { id: 'balance_sheet', label: 'Balance Sheet' },
    { id: 'brs', label: 'Bank Reconciliation' },
  ];

  const hrmSubItems: SidebarSubItem[] = [
    { id: 'employees', label: 'Employee List' },
    { id: 'salary_sheet', label: 'Monthly Salary Sheet' },
  ];

  const adminSubItems: SidebarSubItem[] = [
    { id: 'users', label: 'User Accounts' },
    { id: 'rbac', label: 'Role Permissions RBAC' },
    { id: 'banking', label: 'Bank & Cash Accounts' },
    { id: 'fiscal_year', label: 'Fiscal Year (FY)' },
    { id: 'company', label: 'Company Profile' },
    { id: 'sequences', label: 'Invoice Sequences' },
    { id: 'audit', label: 'System Audit Trail' },
    { id: 'backup_restore', label: 'Backup & Restore' },
  ];

  const navItems: { 
    id: ModuleTab | 'help'; 
    label: string; 
    icon: React.FC<{ className?: string }>;
    actualTab?: ModuleTab;
    badge?: string;
    subItems?: SidebarSubItem[];
    activeSubId?: string;
    onSelectSubItem?: (id: string) => void;
  }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutGrid, actualTab: 'dashboard' },
    { 
      id: 'sales', 
      label: 'Sales', 
      icon: TrendingUp, 
      actualTab: 'sales',
      subItems: salesSubItems,
      activeSubId: activeSalesSubTab,
      onSelectSubItem: onSelectSalesSubTab
    },
    { 
      id: 'lc', 
      label: 'LC & Import Hub', 
      icon: Ship, 
      actualTab: 'lc',
      badge: 'Border',
      subItems: lcSubItems,
      activeSubId: activePurchaseSubTab,
      onSelectSubItem: onSelectPurchaseSubTab
    },
    { 
      id: 'purchase', 
      label: 'Purchase & Store', 
      icon: ShoppingCart, 
      actualTab: 'purchase',
      subItems: purchaseSubItems,
      activeSubId: activePurchaseSubTab,
      onSelectSubItem: onSelectPurchaseSubTab
    },
    { 
      id: 'inventory', 
      label: 'Item & Inventory', 
      icon: Boxes, 
      actualTab: 'inventory',
      subItems: inventorySubItems,
      activeSubId: activeInventorySubTab,
      onSelectSubItem: (id) => onSelectInventorySubTab?.(id as InventorySubTab)
    },
    { 
      id: 'reports', 
      label: 'All Reports', 
      icon: FileText, 
      actualTab: 'reports',
      subItems: reportsSubItems,
      activeSubId: activeReportsSubTab,
      onSelectSubItem: onSelectReportsSubTab
    },
    { 
      id: 'accounts', 
      label: 'Accounting', 
      icon: Receipt, 
      actualTab: 'accounts',
      subItems: accountsSubItems,
      activeSubId: activeAccountsSubTab,
      onSelectSubItem: onSelectAccountsSubTab
    },
    { 
      id: 'hrm', 
      label: 'HRM', 
      icon: Users, 
      actualTab: 'hrm',
      subItems: hrmSubItems,
      activeSubId: activeHrmSubTab,
      onSelectSubItem: onSelectHrmSubTab
    },
    { 
      id: 'admin', 
      label: 'Settings', 
      icon: Settings, 
      actualTab: 'admin',
      subItems: adminSubItems,
      activeSubId: activeAdminSubTab,
      onSelectSubItem: onSelectAdminSubTab
    },
    { id: 'help', label: 'Help', icon: HelpCircle },
  ];

  // Filter navigation items by Manager tickmark permissions (Admin has full access)
  const filteredNavItems = navItems.filter((item) => {
    if (item.id === 'help') return true;
    const tabKey = (item.actualTab || item.id) as any;
    return hasPermission(currentUser, tabKey);
  });

  const handleItemClick = (item: typeof navItems[0]) => {
    if (item.id === 'help') {
      setShowHelpModal(true);
      return;
    }

    if (item.subItems && item.subItems.length > 0) {
      if (openSubMenu === item.id) {
        // Clicked the currently open module -> TOGGLE CLOSE sub-categories!
        setOpenSubMenu(null);
      } else {
        // Open sub-categories for this module and navigate to it
        setOpenSubMenu(item.id);
        if (item.actualTab) {
          onSelectTab(item.actualTab);
        }
      }
    } else {
      setOpenSubMenu(null);
      if (item.actualTab) {
        onSelectTab(item.actualTab);
        onCloseMobile?.();
      }
    }
  };

  const handleSubItemClick = (
    tab: ModuleTab,
    subId: string,
    subItemCallback?: (id: string) => void
  ) => {
    onSelectTab(tab);
    if (subItemCallback) {
      subItemCallback(subId);
    }
    onCloseMobile?.();
  };

  return (
    <>
      {/* Mobile Drawer Backdrop */}
      {isMobileOpen && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 md:hidden animate-in fade-in touch-none"
        />
      )}

      <aside className={`
        ${isMobileOpen 
          ? 'fixed inset-y-0 left-0 z-50 bg-[#dfe3e8] p-4 shadow-2xl w-64 animate-in slide-in-from-left duration-200 flex flex-col overflow-hidden erp-mobile-drawer' 
          : 'hidden md:flex h-full max-h-full min-h-0 overflow-hidden'
        }
        w-56 lg:w-60 flex flex-col shrink-0 select-none pb-4
      `}>
        {/* Brand / Logo: Starline with 8-pointed starburst icon (Pinned Top) */}
        <div 
          onClick={() => {
            onSelectTab('dashboard');
            onCloseMobile?.();
          }}
          className="shrink-0 flex items-center gap-3 px-3 py-4 mb-2 cursor-pointer hover:opacity-85 transition-opacity"
          title="Go to Dashboard"
        >
          <div className="text-slate-900 shrink-0">
            <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24">
              <path d="M12 1L13.8 8.6L20.8 4.8L16.2 11.2L23 12L16.2 12.8L20.8 19.2L13.8 15.4L12 23L10.2 15.4L3.2 19.2L7.8 12.8L1 12L7.8 11.2L3.2 4.8L10.2 8.6Z" />
            </svg>
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900 font-sans">
            Starline
          </span>
        </div>

        {/* Navigation Items (Middle Scrollable Menu List) */}
        <div
          ref={sidebarNavRef}
          className="sidebar-scroll flex-1 min-h-0 overflow-y-auto overflow-x-hidden space-y-2 px-1 pb-2"
        >
          {filteredNavItems.map((item) => {
            const Icon = item.icon;
            const isItemActive = 
              (item.id === 'dashboard' && currentTab === 'dashboard') ||
              (item.id === 'sales' && (currentTab === 'sales' || currentTab === 'pos')) ||
              (item.id === 'lc' && currentTab === 'lc') ||
              (item.id === 'purchase' && currentTab === 'purchase') ||
              (item.id === 'inventory' && currentTab === 'inventory') ||
              (item.id === 'accounts' && currentTab === 'accounts') ||
              (item.id === 'hrm' && (currentTab === 'hrm' || currentTab === 'hr')) ||
              (item.id === 'reports' && (currentTab === 'reports' || currentTab === 'truck_report')) ||
              (item.id === 'admin' && currentTab === 'admin');

            const isSubMenuOpen = openSubMenu === item.id;

            return (
              <div key={item.id} className="space-y-1">
                {/* Main Category Button */}
                <button
                  type="button"
                  data-active-nav-item={isItemActive ? 'true' : undefined}
                  onClick={() => handleItemClick(item)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl text-xs sm:text-sm font-semibold transition-all duration-150 cursor-pointer ${
                    isItemActive
                      ? 'bg-[#def645] text-slate-950 shadow-xs font-bold'
                      : 'bg-white/60 hover:bg-white text-slate-700 hover:text-slate-950 shadow-xs border border-white/80'
                  }`}
                  title={item.subItems && item.subItems.length > 0 ? (isSubMenuOpen ? 'Click to close sub-categories' : 'Click to open sub-categories') : undefined}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <Icon className={`w-4 h-4 shrink-0 ${isItemActive ? 'text-slate-950 stroke-[2.2]' : 'text-slate-600'}`} />
                    <span className="truncate tracking-tight">{item.label}</span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {item.badge && (
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-extrabold uppercase font-mono tracking-wider ${
                        isItemActive ? 'bg-slate-950 text-white' : 'bg-amber-100 text-amber-900 border border-amber-200'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                    {item.subItems && item.subItems.length > 0 && (
                      <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${
                        isSubMenuOpen ? 'rotate-180 text-slate-950' : isItemActive ? 'text-slate-800' : 'text-slate-400'
                      }`} />
                    )}
                  </div>
                </button>

                {/* Subcategories open directly underneath when main category is clicked/open */}
                {isSubMenuOpen && item.subItems && item.subItems.length > 0 && (
                  <div className="pl-3 pr-1 py-1 space-y-0.5 animate-in fade-in slide-in-from-top-1 duration-150">
                    {item.subItems.map((sub) => {
                      const isSubActive = isItemActive && item.activeSubId === sub.id;
                      return (
                        <button
                          key={sub.id}
                          type="button"
                          data-active-sub-item={isSubActive ? 'true' : undefined}
                          onClick={() => handleSubItemClick(item.actualTab || (item.id as ModuleTab), sub.id, item.onSelectSubItem)}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-[11px] font-medium transition-all flex items-center justify-between cursor-pointer ${
                            isSubActive
                              ? 'bg-slate-900 text-white font-bold shadow-2xs'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
                          }`}
                        >
                          <span className="truncate">{sub.label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* User Profile Capsule & Logout (Pinned Bottom) */}
        <div className="shrink-0 mt-auto pt-4 border-t border-slate-800 space-y-2.5">
          <div className="flex items-center gap-2.5 px-2 py-2 bg-slate-900/80 rounded-xl border border-slate-800/80">
            <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-xs">
              {currentUser?.displayName ? currentUser.displayName.charAt(0) : 'U'}
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-xs font-bold text-white block truncate leading-tight">
                {currentUser?.displayName || 'User'}
              </span>
              <span className="text-[10px] text-blue-400 block leading-tight font-medium">
                {currentUser?.role === 'admin' ? 'Super Admin' : 'Manager'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => logout()}
              className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Log Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          {/* Small version info */}
          <div className="px-2 text-[10px] text-slate-500 font-mono flex items-center justify-between">
            <span>TradeCore ERP v2.4</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </div>
        </div>
      </aside>

      {/* Help Modal */}
      {showHelpModal && (
        <ModalWrapper
          isOpen={showHelpModal}
          onClose={() => setShowHelpModal(false)}
          isDirty={false}
          backdropClassName="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-base">Starline Help & Support</h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setShowHelpModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer p-1 shrink-0"
              >
                ✕
              </button>
            </div>
            <div className="text-xs text-slate-600 space-y-2">
              <p>Welcome to <strong>Starline ERP</strong>!</p>
              <p>• <strong>Dashboard:</strong> Executive summary of sales, orders, and branch metrics.</p>
              <p>• <strong>Sales & Distribution:</strong> Direct sales, orders, customer ledger khata, and payment reports.</p>
              <p>• <strong>Purchase:</strong> Procurement, vendors, and import tracking.</p>
              <p>• <strong>Item & Inventory:</strong> Multi-yard inventory, stone crushing batches, and stock ledgers.</p>
              <p>• <strong>Accounting:</strong> Ledgers, journal entries, and cash drawer management.</p>
              <p>• <strong>HRM:</strong> Employee management, designations, monthly payroll, and salary reports.</p>
            </div>
            <div className="pt-2 flex justify-end">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setShowHelpModal(false)}
                className="px-4 py-2 bg-[#def645] text-slate-900 font-bold rounded-xl text-xs shadow-xs cursor-pointer"
              >
                Got it
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}
    </>
  );
};
