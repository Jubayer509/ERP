import React, { useState, useMemo } from 'react';
import { 
  ShoppingCart, 
  CreditCard, 
  Calendar, 
  DollarSign, 
  Receipt, 
  Building2, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  ArrowUpRight, 
  ArrowDownRight, 
  Plus, 
  FileText, 
  Search, 
  Filter, 
  ChevronRight, 
  TrendingUp, 
  Ship, 
  Printer, 
  Truck,
  ExternalLink,
  ShieldCheck,
  Eye,
  Percent
} from 'lucide-react';
import { DirectPurchaseInvoice, SupplierPaymentRecord, Supplier, LetterOfCredit } from '../../types/erp';
import { PurchaseSubTab } from './PurchaseModule';

export interface PurchaseOverviewDashboardProps {
  invoices: DirectPurchaseInvoice[];
  payments: SupplierPaymentRecord[];
  suppliers: Supplier[];
  lcs?: LetterOfCredit[];
  onNavigateTab: (tab: PurchaseSubTab) => void;
  onOpenNewInvoiceModal: () => void;
  onOpenPaymentModal: (supplierId?: string, invoice?: DirectPurchaseInvoice) => void;
  onViewInvoiceSlip?: (invoice: DirectPurchaseInvoice) => void;
  onOpenSupplierKhata?: (supplierId: string) => void;
  currentBranch?: string;
}

export const PurchaseOverviewDashboard: React.FC<PurchaseOverviewDashboardProps> = ({
  invoices,
  payments,
  suppliers,
  lcs = [],
  onNavigateTab,
  onOpenNewInvoiceModal,
  onOpenPaymentModal,
  onViewInvoiceSlip,
  onOpenSupplierKhata,
  currentBranch
}) => {
  // Current calendar dates for calculations
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const currentMonthPrefix = useMemo(() => todayStr.slice(0, 7), [todayStr]); // e.g., "2026-09"

  // Selected date filter mode
  const [filterMode, setFilterMode] = useState<'today' | 'this_month' | 'last_30' | 'all'>('this_month');
  const [selectedCustomDate, setSelectedCustomDate] = useState<string>(todayStr);
  const [searchQuery, setSearchQuery] = useState('');

  // 1. Total Unpaid Purchases Statistics (All Time Outstanding)
  const unpaidStats = useMemo(() => {
    const unpaidInvoices = invoices.filter(inv => (inv.dueAmount || 0) > 0);
    const totalUnpaidAmount = unpaidInvoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);
    const totalInvoicedAmount = invoices.reduce((sum, inv) => sum + (inv.grandTotal || 0), 0);
    const totalPaidAmount = invoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);

    const suppliersWithDue = suppliers.filter(s => (s.currentPayable || 0) > 0);
    const totalSupplierPayables = suppliers.reduce((sum, s) => sum + (s.currentPayable || 0), 0);

    return {
      unpaidInvoicesCount: unpaidInvoices.length,
      totalUnpaidAmount,
      totalInvoicedAmount,
      totalPaidAmount,
      suppliersWithDueCount: suppliersWithDue.length,
      totalSupplierPayables,
      unpaidInvoices
    };
  }, [invoices, suppliers]);

  // 2. Today's Purchase Invoices Statistics
  const todayStats = useMemo(() => {
    // Invoices matching today's date
    const todayInvoicesList = invoices.filter(inv => inv.invoiceDate === selectedCustomDate);
    const totalTodayAmount = todayInvoicesList.reduce((sum, inv) => sum + (inv.grandTotal || 0), 0);
    const todayPaidPortion = todayInvoicesList.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
    const todayDuePortion = todayInvoicesList.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);

    // Payments disbursed today
    const todayPaymentsList = payments.filter(p => p.paymentDate === selectedCustomDate);
    const totalDisbursedToday = todayPaymentsList.reduce((sum, p) => sum + (p.amount || 0), 0);

    // Volume calculation (MT)
    const todayVolumeMT = todayInvoicesList.reduce((sum, inv) => {
      const itemsVol = inv.items?.reduce((iSum, item) => iSum + (item.quantity || 0), 0) || 0;
      return sum + itemsVol;
    }, 0);

    return {
      invoicesCount: todayInvoicesList.length,
      totalTodayAmount,
      todayPaidPortion,
      todayDuePortion,
      todayVolumeMT,
      todayPaymentsCount: todayPaymentsList.length,
      totalDisbursedToday,
      todayInvoicesList,
      todayPaymentsList
    };
  }, [invoices, payments, selectedCustomDate]);

  // 3. This Month's Purchase Total Statistics
  const monthStats = useMemo(() => {
    const monthInvoices = invoices.filter(inv => (inv.invoiceDate || '').startsWith(currentMonthPrefix));
    const totalMonthAmount = monthInvoices.reduce((sum, inv) => sum + (inv.grandTotal || 0), 0);
    const monthPaidAmount = monthInvoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
    const monthDueAmount = monthInvoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);

    const monthPayments = payments.filter(p => (p.paymentDate || '').startsWith(currentMonthPrefix));
    const totalMonthPayments = monthPayments.reduce((sum, p) => sum + (p.amount || 0), 0);

    const monthVolumeMT = monthInvoices.reduce((sum, inv) => {
      const itemsVol = inv.items?.reduce((iSum, item) => iSum + (item.quantity || 0), 0) || 0;
      return sum + itemsVol;
    }, 0);

    return {
      monthInvoicesCount: monthInvoices.length,
      totalMonthAmount,
      monthPaidAmount,
      monthDueAmount,
      monthPaymentsCount: monthPayments.length,
      totalMonthPayments,
      monthVolumeMT,
      monthInvoices
    };
  }, [invoices, payments, currentMonthPrefix]);

  // Filtered invoices for the preview table based on filterMode
  const displayedInvoices = useMemo(() => {
    let list: DirectPurchaseInvoice[] = [];
    if (filterMode === 'today') {
      list = invoices.filter(inv => inv.invoiceDate === selectedCustomDate);
    } else if (filterMode === 'this_month') {
      list = invoices.filter(inv => (inv.invoiceDate || '').startsWith(currentMonthPrefix));
    } else if (filterMode === 'last_30') {
      const d = new Date();
      d.setDate(d.getDate() - 30);
      const cutoff = d.toISOString().split('T')[0];
      list = invoices.filter(inv => (inv.invoiceDate || '') >= cutoff);
    } else {
      list = invoices;
    }

    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase().trim();
    return list.filter(inv => 
      inv.invoiceNumber.toLowerCase().includes(q) ||
      inv.supplierName.toLowerCase().includes(q) ||
      (inv.challanNumber && inv.challanNumber.toLowerCase().includes(q)) ||
      inv.items.some(it => it.itemName.toLowerCase().includes(q))
    );
  }, [invoices, filterMode, selectedCustomDate, currentMonthPrefix, searchQuery]);

  // Top Suppliers with Payables / Dues Concentration
  const topPayableSuppliers = useMemo(() => {
    return [...suppliers]
      .filter(s => (s.currentPayable || 0) > 0)
      .sort((a, b) => (b.currentPayable || 0) - (a.currentPayable || 0))
      .slice(0, 5);
  }, [suppliers]);

  // Current Month Name
  const currentMonthName = useMemo(() => {
    try {
      const date = new Date();
      return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    } catch {
      return 'This Month';
    }
  }, []);

  return (
    <div className="space-y-6">
      {/* ========================================================================= */}
      {/* 1. EXECUTIVE KPI HERO CARDS: Total Unpaid, Today's Purchases, Month's Total */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Total Unpaid Purchases */}
        <div className="bg-gradient-to-br from-rose-900 via-slate-900 to-slate-950 text-white rounded-2xl p-5 shadow-lg border border-rose-800/40 relative overflow-hidden flex flex-col justify-between group">
          {/* Subtle luxury glow effect */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-rose-300 flex items-center gap-1.5 font-mono">
                <Clock className="w-3.5 h-3.5 text-rose-400" />
                Total Unpaid Purchases
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500/20 text-rose-200 border border-rose-400/30 font-mono">
                {unpaidStats.unpaidInvoicesCount} Pending Invoices
              </span>
            </div>

            <div className="mt-1">
              <div className="text-2xl sm:text-3xl font-black tracking-tight font-mono text-white">
                ৳ {(unpaidStats.totalUnpaidAmount / 100000).toFixed(2)}{' '}
                <span className="text-xs font-normal text-rose-200/80 font-sans">Lakh</span>
              </div>
              <p className="text-xs text-rose-200/70 font-mono mt-0.5">
                BDT {unpaidStats.totalUnpaidAmount.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-rose-800/30 flex items-center justify-between text-xs">
            <span className="text-rose-200/80 text-[11px]">
              {unpaidStats.suppliersWithDueCount} Suppliers with Outstanding Due
            </span>
            <button
              type="button"
              onClick={() => onOpenPaymentModal()}
              className="text-[11px] font-bold text-white bg-rose-600 hover:bg-rose-500 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 cursor-pointer shadow-xs"
            >
              <CreditCard className="w-3 h-3" />
              Pay Due →
            </button>
          </div>
        </div>

        {/* Card 2: Today's Purchase Invoices */}
        <div className="bg-gradient-to-br from-blue-900 via-slate-900 to-slate-950 text-white rounded-2xl p-5 shadow-lg border border-blue-800/40 relative overflow-hidden flex flex-col justify-between group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-300 flex items-center gap-1.5 font-mono">
                <Calendar className="w-3.5 h-3.5 text-blue-400" />
                Today's Purchase Invoices
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-200 border border-blue-400/30 font-mono">
                {selectedCustomDate === todayStr ? 'Today' : selectedCustomDate}
              </span>
            </div>

            <div className="mt-1">
              <div className="text-2xl sm:text-3xl font-black tracking-tight font-mono text-white">
                {todayStats.invoicesCount}{' '}
                <span className="text-xs font-normal text-blue-200/80 font-sans">
                  Invoices ({todayStats.todayVolumeMT > 0 ? `${todayStats.todayVolumeMT.toLocaleString()} MT` : 'Bills'})
                </span>
              </div>
              <p className="text-xs text-blue-200/70 font-mono mt-0.5">
                Total Value: ৳ {todayStats.totalTodayAmount.toLocaleString()} BDT
              </p>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-blue-800/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-[11px]">
              <span className="text-emerald-300 font-mono">Paid: ৳{(todayStats.todayPaidPortion / 1000).toFixed(0)}k</span>
              <span className="text-slate-500">•</span>
              <span className="text-rose-300 font-mono">Due: ৳{(todayStats.todayDuePortion / 1000).toFixed(0)}k</span>
            </div>
            <button
              type="button"
              onClick={() => {
                setFilterMode('today');
                onNavigateTab('purchase_invoice');
              }}
              className="text-[11px] font-bold text-white bg-blue-600 hover:bg-blue-500 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 cursor-pointer shadow-xs"
            >
              <Eye className="w-3 h-3" />
              View →
            </button>
          </div>
        </div>

        {/* Card 3: This Month's Purchase Total */}
        <div className="bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 text-white rounded-2xl p-5 shadow-lg border border-emerald-800/40 relative overflow-hidden flex flex-col justify-between group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1.5 font-mono">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                This Month's Purchase Total
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 font-mono">
                {currentMonthName}
              </span>
            </div>

            <div className="mt-1">
              <div className="text-2xl sm:text-3xl font-black tracking-tight font-mono text-white">
                ৳ {(monthStats.totalMonthAmount / 100000).toFixed(2)}{' '}
                <span className="text-xs font-normal text-emerald-200/80 font-sans">Lakh</span>
              </div>
              <p className="text-xs text-emerald-200/70 font-mono mt-0.5">
                BDT {monthStats.totalMonthAmount.toLocaleString()} ({monthStats.monthInvoicesCount} Invoices)
              </p>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-emerald-800/30 flex items-center justify-between text-xs">
            <span className="text-emerald-200/80 text-[11px] font-mono">
              Paid: ৳{(monthStats.monthPaidAmount / 100000).toFixed(2)}L • Disbursed: ৳{(monthStats.totalMonthPayments / 100000).toFixed(2)}L
            </span>
            <button
              type="button"
              onClick={() => onOpenNewInvoiceModal()}
              className="text-[11px] font-bold text-slate-950 bg-[#def645] hover:bg-[#cde534] px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 cursor-pointer shadow-xs"
            >
              <Plus className="w-3 h-3" />
              + New Invoice
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. SECONDARY KPI STRIP: Today's Disbursements, Settle Ratio & L/C Margin  */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold">Today's Disbursements</span>
            <CreditCard className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-black font-mono text-slate-900">
            ৳ {todayStats.totalDisbursedToday.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
            {todayStats.todayPaymentsCount} Payment Vouchers Today
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold">Procurement Settlement</span>
            <Percent className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-xl font-black font-mono text-indigo-700">
            {unpaidStats.totalInvoicedAmount > 0 
              ? `${((unpaidStats.totalPaidAmount / unpaidStats.totalInvoicedAmount) * 100).toFixed(1)}%` 
              : '100%'}
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
            Paid: ৳{(unpaidStats.totalPaidAmount / 100000).toFixed(1)}L of ৳{(unpaidStats.totalInvoicedAmount / 100000).toFixed(1)}L
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold">Suppliers With Dues</span>
            <Building2 className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-black font-mono text-amber-700">
            {unpaidStats.suppliersWithDueCount} <span className="text-xs font-normal text-slate-400">/ {suppliers.length}</span>
          </div>
          <div className="text-[10px] text-amber-600 font-mono font-semibold mt-0.5">
            Total Payable: ৳{(unpaidStats.totalSupplierPayables / 100000).toFixed(2)} Lakh
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold">Active Import LCs</span>
            <Ship className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-black font-mono text-blue-700">
            {lcs.length} <span className="text-xs font-normal text-slate-400">Shipments</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">
            CFR: ${lcs.filter(lc => lc.status !== 'Cancelled' && !lc.isCancelled).reduce((sum, lc) => sum + (lc.cfrAmount || 0), 0).toLocaleString()} USD
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. FILTER BAR & QUICK ACTION BUTTONS HUB                                */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-bold text-slate-700 mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            Timeframe:
          </span>
          <button
            type="button"
            onClick={() => setFilterMode('today')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterMode === 'today'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            Today
          </button>

          <button
            type="button"
            onClick={() => setFilterMode('this_month')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterMode === 'this_month'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            This Month ({currentMonthName.split(' ')[0]})
          </button>

          <button
            type="button"
            onClick={() => setFilterMode('last_30')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterMode === 'last_30'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            Last 30 Days
          </button>

          <button
            type="button"
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterMode === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            All Purchases ({invoices.length})
          </button>

          {/* Custom Date selector if Today is picked */}
          {filterMode === 'today' && (
            <input
              type="date"
              value={selectedCustomDate}
              onChange={(e) => setSelectedCustomDate(e.target.value)}
              className="px-2.5 py-1 text-xs font-mono font-bold border border-slate-200 rounded-lg bg-slate-50 focus:ring-1 focus:ring-blue-500 outline-none"
            />
          )}
        </div>

        {/* Quick Search */}
        <div className="relative min-w-[220px]">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search invoice / supplier..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 outline-none"
          />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. MAIN WORKSPACE: Invoices Table Preview & Top Supplier Payables Breakdown */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Invoices List for Selected Period */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 flex-wrap gap-2">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-indigo-600" />
                <span>
                  {filterMode === 'today' && `Today's Purchase Invoices (${selectedCustomDate})`}
                  {filterMode === 'this_month' && `This Month's Invoices (${currentMonthName})`}
                  {filterMode === 'last_30' && 'Recent 30 Days Purchase Invoices'}
                  {filterMode === 'all' && 'All Purchase Invoices Directory'}
                </span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Showing {displayedInvoices.length} invoices • Total BDT {displayedInvoices.reduce((s, i) => s + i.grandTotal, 0).toLocaleString()}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onNavigateTab('purchase_invoice')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-0.5"
              >
                Open Full Register →
              </button>
            </div>
          </div>

          {displayedInvoices.length === 0 ? (
            <div className="p-8 text-center bg-slate-50/50 rounded-xl border border-dashed border-slate-200 space-y-2">
              <ShoppingCart className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="text-xs font-semibold text-slate-600">No purchase invoices found for this timeframe.</p>
              <button
                type="button"
                onClick={onOpenNewInvoiceModal}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-colors inline-flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Create New Purchase Invoice
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Invoice No</th>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Supplier Name</th>
                    <th className="py-2.5 px-3 text-right">Total (BDT)</th>
                    <th className="py-2.5 px-3 text-right text-rose-700">Due (BDT)</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-slate-800">
                  {displayedInvoices.slice(0, 8).map((inv) => {
                    const isPaid = inv.dueAmount <= 0;
                    const isPartial = inv.dueAmount > 0 && inv.paidAmount > 0;
                    return (
                      <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-2.5 px-3 font-bold text-blue-700 font-mono">
                          {inv.invoiceNumber}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 font-mono text-[11px]">
                          {inv.invoiceDate}
                        </td>
                        <td className="py-2.5 px-3 font-sans font-semibold text-slate-900 max-w-[160px] truncate">
                          {inv.supplierName}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold font-mono">
                          ৳ {inv.grandTotal.toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold font-mono text-rose-700">
                          {inv.dueAmount > 0 ? `৳ ${inv.dueAmount.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            isPaid ? 'bg-emerald-100 text-emerald-800' :
                            isPartial ? 'bg-amber-100 text-amber-800' :
                            'bg-rose-100 text-rose-800'
                          }`}>
                            {isPaid ? 'Paid' : isPartial ? 'Partial' : 'Unpaid'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5 font-sans">
                            {inv.dueAmount > 0 && (
                              <button
                                type="button"
                                onClick={() => onOpenPaymentModal(inv.supplierId, inv)}
                                className="px-2 py-0.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded text-[10px] font-bold transition-colors cursor-pointer"
                                title="Pay this invoice due"
                              >
                                Pay
                              </button>
                            )}
                            {onViewInvoiceSlip && (
                              <button
                                type="button"
                                onClick={() => onViewInvoiceSlip(inv)}
                                className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[10px] font-semibold transition-colors cursor-pointer inline-flex items-center gap-1 border border-slate-200"
                                title="Print / View Purchase Invoice"
                              >
                                <Printer className="w-3 h-3 text-slate-600" />
                                <span>Print</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {displayedInvoices.length > 8 && (
            <div className="pt-2 text-center border-t border-slate-100">
              <button
                type="button"
                onClick={() => onNavigateTab('purchase_invoice')}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:underline"
              >
                View remaining {displayedInvoices.length - 8} purchase invoices in full register →
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Top Supplier Dues & Quick Actions */}
        <div className="space-y-4">
          {/* Top Suppliers by Due Amount */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-amber-600" />
                <span>Supplier Payables Ranking</span>
              </h3>
              <button
                type="button"
                onClick={() => onNavigateTab('suppliers')}
                className="text-[11px] font-semibold text-blue-600 hover:underline"
              >
                All Suppliers →
              </button>
            </div>

            <div className="space-y-3">
              {topPayableSuppliers.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400">
                  ✓ No outstanding dues across any supplier!
                </div>
              ) : (
                topPayableSuppliers.map((supp) => {
                  const duePercent = unpaidStats.totalSupplierPayables > 0 
                    ? ((supp.currentPayable || 0) / unpaidStats.totalSupplierPayables) * 100 
                    : 0;
                  return (
                    <div 
                      key={supp.id}
                      className="p-2.5 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-100/60 transition-all space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-900 truncate max-w-[160px]">
                          {supp.name}
                        </span>
                        <span className="font-mono font-bold text-rose-700">
                          ৳ {(supp.currentPayable || 0).toLocaleString()}
                        </span>
                      </div>

                      <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                        <div 
                          className="bg-rose-500 h-full rounded-full transition-all duration-300"
                          style={{ width: `${Math.min(100, Math.max(8, duePercent))}%` }}
                        />
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>{supp.category || 'General Supplier'}</span>
                        <div className="flex items-center gap-2">
                          {onOpenSupplierKhata && (
                            <button
                              type="button"
                              onClick={() => onOpenSupplierKhata(supp.id)}
                              className="text-blue-600 hover:underline font-semibold"
                            >
                              Ledger
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => onOpenPaymentModal(supp.id)}
                            className="text-emerald-700 hover:underline font-bold"
                          >
                            Pay
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Quick Navigation Cards */}
          <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-xs space-y-3">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-400">
              Procurement Shortcuts & Hubs
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => onNavigateTab('purchase_invoice')}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-medium text-left transition-colors flex items-center justify-between group cursor-pointer"
              >
                <span>Purchase Invoices</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateTab('supplier_payments')}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-medium text-left transition-colors flex items-center justify-between group cursor-pointer"
              >
                <span>Payment Register</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateTab('suppliers')}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-medium text-left transition-colors flex items-center justify-between group cursor-pointer"
              >
                <span>Supplier Ledger</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateTab('lc_balance_sheet')}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-medium text-left transition-colors flex items-center justify-between group cursor-pointer"
              >
                <span>LC Balance Sheet</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
