import React, { useState, useEffect, useMemo } from 'react';
import { 
  Building2, 
  User, 
  MapPin, 
  Globe2, 
  Save, 
  RotateCcw, 
  UserPlus, 
  Minus, 
  Square, 
  X, 
  Check, 
  AlertCircle, 
  ChevronsUpDown, 
  ChevronDown, 
  Lock, 
  FileSpreadsheet, 
  ShieldCheck, 
  Monitor, 
  Smartphone, 
  Columns2, 
  Signal, 
  Wifi, 
  BatteryMedium, 
  ArrowLeft, 
  CheckCircle2, 
  AlertTriangle,
  PlusCircle,
  Boxes
} from 'lucide-react';
import { Supplier } from '../../types/erp';
import { getUniqueCompanyOwners } from '../../utils/supplierStorage';
import { ModalWrapper } from '../common/ModalWrapper';

export interface AddSupplierModalProps {
  isOpen: boolean;
  supplierToEdit?: Supplier | null;
  onClose: () => void;
  onSupplierSaved: (supplier: Supplier) => void;
  defaultOwner?: string;
}

interface SupplierOwnerOption {
  id: string;
  name: string;
  country: string;
}

export const AddSupplierModal: React.FC<AddSupplierModalProps> = ({
  isOpen,
  supplierToEdit,
  onClose,
  onSupplierSaved,
  defaultOwner = ''
}) => {
  const [viewMode, setViewMode] = useState<'windows' | 'mobile' | 'split'>('windows');

  // Registered Supplier Owners list
  const [registeredOwners, setRegisteredOwners] = useState<SupplierOwnerOption[]>(() => {
    const existing = getUniqueCompanyOwners();
    const defaults: SupplierOwnerOption[] = [
      { id: '1', name: 'Tshering Pelden', country: 'Bhutan (Exporter)' },
      { id: '2', name: 'Rafiqul Islam', country: 'Bangladesh (Local)' },
      { id: '3', name: 'Vikram Singhania', country: 'India (Exporter)' }
    ];
    existing.forEach((name, idx) => {
      if (!defaults.some(d => d.name.toLowerCase() === name.toLowerCase())) {
        defaults.push({ id: `owner-${idx + 4}`, name, country: 'Bhutan (Exporter)' });
      }
    });
    return defaults;
  });

  // Sub-modal state for + New Supplier Owner
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState(false);
  const [modalOwnerName, setModalOwnerName] = useState('');
  const [modalOwnerCountry, setModalOwnerCountry] = useState('');
  const [modalOwnerNote, setModalOwnerNote] = useState('');

  // Form State
  const [companyName, setCompanyName] = useState('');
  const [supplierOwner, setSupplierOwner] = useState(defaultOwner || '');
  const [supplierType, setSupplierType] = useState<'Local' | 'Exporter'>('Local');
  const [phoneCode, setPhoneCode] = useState('+880');
  const [mobile, setMobile] = useState('');
  const [address, setAddress] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('');
  const [customDays, setCustomDays] = useState('');
  const [currency, setCurrency] = useState<'BDT' | 'USD' | 'RS'>('BDT');
  const [openingBalance, setOpeningBalance] = useState<string>('');
  const [balanceType, setBalanceType] = useState<'CR' | 'DR'>('CR');
  const [isActive, setIsActive] = useState(true);

  // Validation & Toast
  const [companyError, setCompanyError] = useState(false);
  const [toast, setToast] = useState<{ title: string; message: string; type?: 'success' | 'warning' } | null>(null);

  // Clear / Reset form
  const resetAllForms = () => {
    setCompanyName('');
    setSupplierOwner('');
    setSupplierType('Local');
    setPhoneCode('+880');
    setMobile('');
    setAddress('');
    setPaymentTerms('');
    setCustomDays('');
    setCurrency('BDT');
    setOpeningBalance('');
    setBalanceType('CR');
    setIsActive(true);
    setCompanyError(false);
  };

  const handleCloseMainModal = () => {
    resetAllForms();
    onClose();
  };

  const handleCloseOwnerModal = () => {
    setModalOwnerName('');
    setModalOwnerCountry('');
    setModalOwnerNote('');
    setIsOwnerModalOpen(false);
  };

  const isMainDirty = supplierToEdit
    ? (companyName !== (supplierToEdit.name || supplierToEdit.tradeName || '') ||
       mobile !== (supplierToEdit.mobile || supplierToEdit.phone || '') ||
       address !== (supplierToEdit.address || ''))
    : (companyName.trim() !== '' || mobile.trim() !== '' || address.trim() !== '' || openingBalance !== '');

  const isOwnerDirty = modalOwnerName.trim() !== '' || modalOwnerNote.trim() !== '';

  // Populate when editing or opening
  useEffect(() => {
    if (supplierToEdit) {
      setCompanyName(supplierToEdit.name || supplierToEdit.tradeName || '');
      
      const ownerVal = supplierToEdit.companyOwner || '';
      const matched = registeredOwners.find(o => o.name.toLowerCase() === ownerVal.toLowerCase() || o.id === ownerVal);
      if (matched) {
        setSupplierOwner(matched.id);
      } else if (ownerVal) {
        const newOwnerObj: SupplierOwnerOption = {
          id: `owner-${Date.now()}`,
          name: ownerVal,
          country: supplierToEdit.country.includes('Bangladesh') ? 'Bangladesh (Local)' : `${supplierToEdit.country} (Exporter)`
        };
        setRegisteredOwners(prev => [...prev, newOwnerObj]);
        setSupplierOwner(newOwnerObj.id);
      }

      const isExp = supplierToEdit.supplierType === 'Exporter' || 
        (supplierToEdit.country && !supplierToEdit.country.toLowerCase().includes('bangladesh')) ||
        (supplierToEdit.currency && supplierToEdit.currency !== 'BDT');
      setSupplierType(isExp ? 'Exporter' : 'Local');

      setPhoneCode(supplierToEdit.phoneCode || '+880');
      setMobile(supplierToEdit.mobile || supplierToEdit.phone || '');
      setAddress(supplierToEdit.address || '');

      const terms = supplierToEdit.paymentTerms || 'Net 30 Days';
      if (['Cash / Advance', 'Net 7 Days', 'Net 15 Days', 'Net 30 Days', 'Net 60 Days'].includes(terms)) {
        setPaymentTerms(terms);
        setCustomDays('');
      } else if (terms.includes('Custom') || terms.includes('Days')) {
        setPaymentTerms('Custom');
        const match = terms.match(/\d+/);
        setCustomDays(match ? match[0] : (String(supplierToEdit.customTermsDays || '')));
      } else {
        setPaymentTerms(terms);
      }

      const curr = (supplierToEdit.currency || 'BDT') as 'BDT' | 'USD' | 'RS';
      setCurrency(['BDT', 'USD', 'RS'].includes(curr) ? curr : 'BDT');

      const bal = supplierToEdit.openingBalance !== undefined 
        ? supplierToEdit.openingBalance 
        : Math.abs(supplierToEdit.currentPayable || 0);
      setOpeningBalance(bal > 0 ? String(bal) : '');

      const bType = supplierToEdit.balanceType || ((supplierToEdit.currentPayable || 0) < 0 ? 'DR' : 'CR');
      setBalanceType(bType);

      setIsActive(supplierToEdit.status === 'Active' || supplierToEdit.isActive !== false);
      setCompanyError(false);
    } else {
      resetAllForms();
      if (defaultOwner) {
        const found = registeredOwners.find(o => o.name.toLowerCase() === defaultOwner.toLowerCase());
        if (found) setSupplierOwner(found.id);
      }
    }
  }, [supplierToEdit, isOpen]);

  // Handle supplier type toggle (Local vs Exporter)
  const handleSupplierTypeChange = (type: 'Local' | 'Exporter') => {
    setSupplierType(type);
    if (type === 'Local' && (currency === 'USD' || currency === 'RS')) {
      setCurrency('BDT');
    }
  };

  // Currency select with business rule enforcement
  const handleSelectCurrency = (curr: 'BDT' | 'USD' | 'RS') => {
    if (supplierType === 'Local' && (curr === 'USD' || curr === 'RS')) {
      showToast('Currency Restriction', 'USD and RS are reserved for Exporters only.', 'warning');
      return;
    }
    setCurrency(curr);
  };

  // Toast utility
  const showToast = (title: string, message: string, type: 'success' | 'warning' = 'success') => {
    setToast({ title, message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Sub-modal: add new supplier owner
  const handleNewOwnerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const name = modalOwnerName.trim();
    if (!name) return;

    const newId = String(Date.now());
    const newOwner: SupplierOwnerOption = {
      id: newId,
      name,
      country: modalOwnerCountry
    };

    setRegisteredOwners(prev => [...prev, newOwner]);
    setSupplierOwner(newId);

    if (modalOwnerCountry.includes('Exporter')) {
      setSupplierType('Exporter');
    }

    setIsOwnerModalOpen(false);
    setModalOwnerName('');
    setModalOwnerCountry('');
    setModalOwnerNote('');
    showToast('Owner Added', `${name} is now linked as registered supplier principle.`);
  };

  // Submit / Save Action
  const handleSaveAction = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const cName = companyName.trim();
    if (!cName) {
      setCompanyError(true);
      showToast('Validation Error', 'Please provide a valid company trade name.', 'warning');
      return;
    }
    setCompanyError(false);

    if (!supplierOwner) {
      showToast('Owner Required', 'Please select or add a supplier owner.', 'warning');
      return;
    }

    const matchedOwner = registeredOwners.find(o => o.id === supplierOwner);
    const ownerName = matchedOwner ? matchedOwner.name : 'Commercial Exporter';
    const ownerCountry = matchedOwner?.country || (supplierType === 'Exporter' ? 'Bhutan' : 'Bangladesh');
    const cleanCountry = ownerCountry.replace(/\s*\(.*?\)\s*/g, '').trim() || (supplierType === 'Exporter' ? 'Bhutan' : 'Bangladesh');

    let resolvedTerms = paymentTerms;
    if (paymentTerms === 'Custom') {
      const days = parseInt(customDays, 10) || 30;
      resolvedTerms = `Net ${days} Days (Custom)`;
    }

    const numBal = parseFloat(openingBalance) || 0;
    const finalPayable = balanceType === 'CR' ? numBal : -numBal;

    const savedSupplier: Supplier = {
      id: supplierToEdit ? supplierToEdit.id : `supp-${Date.now()}`,
      code: supplierToEdit ? supplierToEdit.code : `SUPP-${supplierType === 'Exporter' ? 'EX' : 'LOC'}-${Math.floor(10 + Math.random() * 90)}`,
      name: cName,
      tradeName: cName,
      companyOwner: ownerName,
      country: cleanCountry,
      category: supplierType === 'Exporter' ? 'Stone Exporter' : 'Local Distributor',
      supplierType: supplierType,
      phoneCode: phoneCode,
      mobile: mobile.trim(),
      phone: mobile.trim() ? `${phoneCode} ${mobile.trim()}` : (supplierToEdit?.phone || ''),
      address: address.trim() || `${cleanCountry} Trade Zone`,
      city: supplierToEdit?.city || 'Dhaka',
      paymentTerms: resolvedTerms,
      currency: currency,
      bankDetails: supplierToEdit?.bankDetails || 'Bank details to be updated upon LC issuance',
      currentPayable: finalPayable,
      openingBalance: numBal,
      balanceType: balanceType,
      status: isActive ? 'Active' : 'Inactive',
      isActive: isActive,
      borderLandPort: supplierToEdit?.borderLandPort || 'Burimari'
    };

    if (paymentTerms === 'Custom' && customDays) {
      savedSupplier.customTermsDays = customDays;
    }

    onSupplierSaved(savedSupplier);
    showToast(
      supplierToEdit ? 'Supplier Updated' : 'Supplier Registered',
      `${cName} committed to ledger database with ${currency} terms.`
    );

    setTimeout(() => {
      onClose();
    }, 400);
  };

  // Preview computations for live inspector
  const previewCompany = companyName.trim() || 'Pelden Enterprise Ltd.';
  const matchedOwner = registeredOwners.find(o => o.id === supplierOwner);
  const previewOwner = matchedOwner ? `Owner: ${matchedOwner.name}` : 'Owner: Not Selected';
  const previewTerms = paymentTerms === 'Custom' 
    ? (customDays ? `Net ${customDays} Days (Custom)` : 'Custom Days') 
    : paymentTerms;
  const symbolMap: Record<string, string> = { BDT: '৳', USD: '$', RS: '₹' };
  const curSym = symbolMap[currency] || '৳';
  const numBal = parseFloat(openingBalance);
  const formattedBal = isNaN(numBal) 
    ? '0.00' 
    : numBal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const avatarLetter = (companyName.trim() || 'P').charAt(0).toUpperCase();

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={handleCloseMainModal}
      isDirty={isMainDirty}
      backdropClassName="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto"
    >
      <div className="w-full max-w-[1650px] my-auto flex flex-col items-center">
        
        {/* TOP VIEWPORT SWITCHER TOOLBAR */}
        <header className="w-full mb-3 bg-slate-900 text-white border border-slate-800 px-4 py-2.5 rounded-2xl shadow-xl flex flex-wrap items-center justify-between gap-3 select-none">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-sm">
              <Boxes className="w-4 h-4" />
            </div>
            <div>
              <span className="text-sm font-semibold tracking-tight text-white block leading-tight">
                Nexus ERP Suite • {supplierToEdit ? `Edit Supplier Profile (${supplierToEdit.code})` : 'Supplier & Company Registry'}
              </span>
              <span className="text-[11px] text-slate-400">Multi-Company Architecture & Commercial Ledger Baseline</span>
            </div>
          </div>

          {/* View Switcher */}
          <div className="flex items-center bg-slate-800 p-1 rounded-xl border border-slate-700/80">
            <button 
              type="button" 
              onClick={() => setViewMode('windows')} 
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                viewMode === 'windows' ? 'text-white bg-blue-600 shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Windows ERP</span>
            </button>
            <button 
              type="button" 
              onClick={() => setViewMode('mobile')} 
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                viewMode === 'mobile' ? 'text-white bg-blue-600 shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile App</span>
            </button>
            <button 
              type="button" 
              onClick={() => setViewMode('split')} 
              className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                viewMode === 'split' ? 'text-white bg-blue-600 shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <Columns2 className="w-3.5 h-3.5" />
              <span>Side by Side</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping mr-0.5"></span>
              Live Sync Active
            </span>
            <button 
              type="button" 
              data-modal-close="true"
              onClick={handleCloseMainModal} 
              className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-rose-600 text-slate-400 hover:text-white flex items-center justify-center transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* WORKSPACE VIEWS WRAPPER */}
        <div className={`w-full ${viewMode === 'split' ? 'grid grid-cols-1 xl:grid-cols-12 gap-6 items-start' : 'flex flex-col items-center'}`}>
          
          {/* ========================================== */}
          {/* VIEW 1: WINDOWS 11 DESKTOP ERP APPLICATION */}
          {/* ========================================== */}
          {(viewMode === 'windows' || viewMode === 'split') && (
            <div className={`w-full bg-white rounded-xl shadow-2xl border border-slate-300 overflow-hidden flex flex-col ${viewMode === 'split' ? 'xl:col-span-8' : 'max-w-7xl'}`}>
              
              {/* Windows 11 Title Bar */}
              <div className="bg-slate-900 text-slate-200 px-4 py-2 flex items-center justify-between border-b border-slate-800 select-none">
                <div className="flex items-center gap-2.5">
                  <span className="w-3.5 h-3.5 bg-blue-500 rounded-xs flex items-center justify-center text-[10px] text-white font-bold">N</span>
                  <span className="text-xs font-medium text-slate-300 tracking-wide">
                    Nexus ERP v24.2 • [{supplierToEdit ? `Edit Supplier Profile - ${supplierToEdit.code}` : 'Supplier Ledger & Trade Entity Enrollment'}]
                  </span>
                </div>
                {/* Window Controls */}
                <div className="flex items-center gap-1 -mr-2">
                  <button type="button" className="w-8 h-6 flex items-center justify-center hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded">
                    <Minus className="w-3 h-3" />
                  </button>
                  <button type="button" className="w-8 h-6 flex items-center justify-center hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded">
                    <Square className="w-2.5 h-2.5" />
                  </button>
                  <button type="button" data-modal-close="true" onClick={handleCloseMainModal} className="w-8 h-6 flex items-center justify-center hover:bg-rose-600 text-slate-400 hover:text-white rounded transition">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Desktop Action Ribbon Toolbar */}
              <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs">
                  <button 
                    type="button" 
                    onClick={() => handleSaveAction()} 
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-md font-medium shadow-sm transition"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{supplierToEdit ? 'Update Record (Ctrl+S)' : 'Save Record (Ctrl+S)'}</span>
                  </button>
                  <button 
                    type="button" 
                    onClick={resetAllForms} 
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-md font-medium shadow-sm transition"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Clear Form</span>
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setIsOwnerModalOpen(true)} 
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md font-medium shadow-sm transition"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>+ New Supplier Owner</span>
                  </button>
                </div>
                <div className="text-[11px] text-slate-500 flex items-center gap-3">
                  <span>Branch: <strong>Main Trade Depot</strong></span>
                  <span>Fiscal Year: <strong>2026-2027</strong></span>
                </div>
              </div>

              {/* Windows Work Area: Form + Ledger Preview */}
              <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[580px]">
                
                {/* Left Main Form (8 Cols) */}
                <div className="lg:col-span-8 p-6 lg:p-7 border-r border-slate-200 overflow-y-auto max-h-[75vh]">
                  <form onSubmit={handleSaveAction} autoComplete="off" className="space-y-6">
                    
                    {/* 1. Company & Owner Setup */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                        <div className="w-6 h-6 rounded bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">1</div>
                        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">Company & Supplier Owner</h3>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Company / Supplier Trade Name */}
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <label className="text-xs font-semibold text-slate-700">
                              Company / Supplier Trade Name <span className="text-rose-500 font-bold">*</span>
                            </label>
                            <span className="text-[11px] text-slate-400">Trade Entity</span>
                          </div>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                              <Building2 className="w-4 h-4" />
                            </div>
                            <input 
                              type="text" 
                              required
                              value={companyName}
                              onChange={(e) => { setCompanyName(e.target.value); setCompanyError(false); }}
                              placeholder="e.g. Pelden Enterprise Ltd." 
                              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition bg-white"
                            />
                          </div>
                          {companyError && (
                            <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" /> Company trade name is required.
                            </p>
                          )}
                        </div>

                        {/* Supplier / Owner Selector with "+ New Supplier" Link */}
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <label className="text-xs font-semibold text-slate-700 flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-blue-600" />
                              Company Owner / Supplier <span className="text-rose-500 font-bold">*</span>
                            </label>
                            <button 
                              type="button" 
                              onClick={() => setIsOwnerModalOpen(true)} 
                              className="text-xs font-semibold text-blue-600 hover:text-blue-800 underline decoration-blue-400 hover:decoration-blue-700 flex items-center gap-0.5 cursor-pointer"
                            >
                              <PlusCircle className="w-3 h-3" />
                              + New Supplier
                            </button>
                          </div>
                          <div className="relative">
                            <select 
                              value={supplierOwner}
                              onChange={(e) => setSupplierOwner(e.target.value)}
                              className="w-full pl-3 pr-8 py-2 text-sm rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer"
                              required
                            >
                              <option value="">-- Select Registered Owner --</option>
                              {registeredOwners.map(owner => (
                                <option key={owner.id} value={owner.id}>
                                  {owner.name} ({owner.country})
                                </option>
                              ))}
                            </select>
                            <div className="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none text-slate-400">
                              <ChevronsUpDown className="w-4 h-4" />
                            </div>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1">One supplier owner can operate multiple registered trade companies.</p>
                        </div>
                      </div>

                      {/* Supplier Type: Local vs Exporter */}
                      <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
                        <label className="block text-xs font-semibold text-slate-700 mb-2">
                          Supplier Classification
                        </label>
                        <div className="grid grid-cols-2 gap-3">
                          <button
                            type="button"
                            onClick={() => handleSupplierTypeChange('Local')}
                            className={`flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium rounded-lg border-2 transition select-none ${
                              supplierType === 'Local' 
                                ? 'border-blue-600 bg-blue-50 text-blue-700 font-bold' 
                                : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                            }`}
                          >
                            <MapPin className="w-3.5 h-3.5" />
                            <span>Local Supplier</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSupplierTypeChange('Exporter')}
                            className={`flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium rounded-lg border-2 transition select-none ${
                              supplierType === 'Exporter' 
                                ? 'border-blue-600 bg-blue-50 text-blue-700 font-bold' 
                                : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                            }`}
                          >
                            <Globe2 className="w-3.5 h-3.5" />
                            <span>International Exporter</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* 2. Contact Information */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                        <div className="w-6 h-6 rounded bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">2</div>
                        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">Contact & Address</h3>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Mobile Number (Optional) */}
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <label className="text-xs font-semibold text-slate-700">Mobile Number</label>
                            <span className="text-[11px] font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">Optional</span>
                          </div>
                          <div className="flex rounded-lg border border-slate-300 overflow-hidden focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500 bg-white">
                            <div className="bg-slate-100 px-3 py-2 border-r border-slate-300 flex items-center gap-1 text-xs text-slate-600 select-none shrink-0">
                              <span>🇧🇩</span>
                              <input 
                                type="text" 
                                value={phoneCode} 
                                onChange={(e) => setPhoneCode(e.target.value)}
                                className="w-12 bg-transparent text-xs font-semibold text-slate-700 focus:outline-none"
                              />
                            </div>
                            <input 
                              type="text" 
                              value={mobile}
                              onChange={(e) => setMobile(e.target.value)}
                              placeholder="1700-000000" 
                              className="w-full px-3 py-2 text-sm focus:outline-none font-mono"
                            />
                          </div>
                        </div>

                        {/* Address Field */}
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <label className="text-xs font-semibold text-slate-700">Operating Address</label>
                            <span className="text-[11px] text-slate-400">Warehouse / Office</span>
                          </div>
                          <div className="relative">
                            <textarea 
                              rows={2} 
                              value={address}
                              onChange={(e) => setAddress(e.target.value)}
                              placeholder="Street, Industrial Zone, Port or City location..." 
                              className="w-full p-2.5 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none bg-white"
                            ></textarea>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* 3. Payment Terms & Ledger */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                        <div className="w-6 h-6 rounded bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">3</div>
                        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">Payment Terms & Ledger Baseline</h3>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Payment Terms Dropdown */}
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">Credit Payment Terms</label>
                          <div className="relative">
                            <select 
                              value={paymentTerms}
                              onChange={(e) => setPaymentTerms(e.target.value)}
                              className="w-full pl-3 pr-8 py-2 text-sm rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer"
                            >
                              <option value="">-- Select Credit Payment Terms --</option>
                              <option value="Cash / Advance">Cash on Delivery / Advance (Immediate)</option>
                              <option value="Net 7 Days">Net 7 Days</option>
                              <option value="Net 15 Days">Net 15 Days</option>
                              <option value="Net 30 Days">Net 30 Days (Standard Commercial)</option>
                              <option value="Net 60 Days">Net 60 Days</option>
                              <option value="Custom">Custom Credit Term...</option>
                            </select>
                            <div className="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none text-slate-400">
                              <ChevronDown className="w-4 h-4" />
                            </div>
                          </div>

                          {/* Custom Days Input */}
                          {paymentTerms === 'Custom' && (
                            <div className="mt-2 relative">
                              <input 
                                type="number" 
                                min="1" 
                                value={customDays}
                                onChange={(e) => setCustomDays(e.target.value)}
                                placeholder="Enter terms in days (e.g. 45)" 
                                className="w-full pl-3 pr-14 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                              />
                              <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs text-slate-400 pointer-events-none">Days</span>
                            </div>
                          )}
                        </div>

                        {/* Dynamic Currency Selection (Rule Enforced) */}
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <label className="text-xs font-semibold text-slate-700">Billing Currency</label>
                            <span className={`text-[10px] px-2 py-0.5 rounded border ${
                              supplierType === 'Exporter' 
                                ? 'text-emerald-700 bg-emerald-50 border-emerald-200' 
                                : 'text-blue-700 bg-blue-50 border-blue-200'
                            }`}>
                              {supplierType === 'Exporter' ? 'International: USD, RS & BDT Available' : 'Local Entity: BDT Only'}
                            </span>
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            {/* BDT */}
                            <button 
                              type="button" 
                              onClick={() => handleSelectCurrency('BDT')} 
                              className={`py-2 px-2 text-xs font-bold rounded-lg border-2 transition flex items-center justify-center gap-1 ${
                                currency === 'BDT' 
                                  ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-xs' 
                                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                              }`}
                            >
                              <span>৳</span> BDT
                            </button>

                            {/* USD (Exporter Only) */}
                            <button 
                              type="button" 
                              disabled={supplierType === 'Local'}
                              onClick={() => handleSelectCurrency('USD')} 
                              className={`py-2 px-2 text-xs font-bold rounded-lg border transition flex items-center justify-center gap-1 ${
                                supplierType === 'Local'
                                  ? 'border-slate-200 bg-slate-100 text-slate-400 opacity-60 cursor-not-allowed'
                                  : currency === 'USD'
                                    ? 'border-blue-600 bg-blue-50 text-blue-700 border-2 shadow-xs'
                                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                              }`}
                              title={supplierType === 'Local' ? 'Available for Exporters only' : 'Click to select USD billing'}
                            >
                              {supplierType === 'Local' && <Lock className="w-3 h-3 text-slate-400" />}
                              <span>$</span> USD
                            </button>

                            {/* RS (Exporter Only) */}
                            <button 
                              type="button" 
                              disabled={supplierType === 'Local'}
                              onClick={() => handleSelectCurrency('RS')} 
                              className={`py-2 px-2 text-xs font-bold rounded-lg border transition flex items-center justify-center gap-1 ${
                                supplierType === 'Local'
                                  ? 'border-slate-200 bg-slate-100 text-slate-400 opacity-60 cursor-not-allowed'
                                  : currency === 'RS'
                                    ? 'border-blue-600 bg-blue-50 text-blue-700 border-2 shadow-xs'
                                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                              }`}
                              title={supplierType === 'Local' ? 'Available for Exporters only' : 'Click to select RS billing'}
                            >
                              {supplierType === 'Local' && <Lock className="w-3 h-3 text-slate-400" />}
                              <span>₹</span> RS
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Opening Balance & Debit/Credit Indicator */}
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end pt-2">
                        <div className="md:col-span-8">
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">Opening Balance Amount</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 font-bold text-sm">
                              <span>{curSym}</span>
                            </div>
                            <input 
                              type="number" 
                              step="0.01" 
                              value={openingBalance}
                              onChange={(e) => setOpeningBalance(e.target.value)}
                              placeholder="0.00" 
                              className="w-full pl-9 pr-3 py-2 text-sm font-semibold rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                            />
                          </div>
                        </div>

                        {/* Ledger Type: Dr vs Cr */}
                        <div className="md:col-span-4 flex bg-slate-100 p-1 rounded-lg border border-slate-200">
                          <button 
                            type="button" 
                            onClick={() => setBalanceType('CR')} 
                            className={`flex-1 py-1.5 text-xs font-bold rounded-md transition ${
                              balanceType === 'CR' 
                                ? 'bg-white text-slate-800 shadow-sm' 
                                : 'text-slate-500 hover:text-slate-800'
                            }`}
                          >
                            Credit (Cr) - Payable
                          </button>
                          <button 
                            type="button" 
                            onClick={() => setBalanceType('DR')} 
                            className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition ${
                              balanceType === 'DR' 
                                ? 'bg-white text-slate-800 shadow-sm font-bold' 
                                : 'text-slate-500 hover:text-slate-800'
                            }`}
                          >
                            Debit (Dr) - Advance
                          </button>
                        </div>
                      </div>

                      {/* Account Status: Active / Inactive */}
                      <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-lg border border-slate-200">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-emerald-500' : 'bg-slate-400'}`}></div>
                          <div>
                            <span className="text-xs font-bold text-slate-800">Account Status</span>
                            <p className="text-[11px] text-slate-500">
                              {isActive 
                                ? 'Active entities can issue purchase orders, LCs, and receipts' 
                                : 'Entity is archived and frozen for commercial invoicing'}
                            </p>
                          </div>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer select-none">
                          <input 
                            type="checkbox" 
                            checked={isActive} 
                            onChange={(e) => setIsActive(e.target.checked)} 
                            className="sr-only peer"
                          />
                          <div className="w-10 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                          <span className={`ml-2 text-xs font-bold min-w-[55px] ${isActive ? 'text-emerald-700' : 'text-slate-500'}`}>
                            {isActive ? 'Active' : 'Deactive'}
                          </span>
                        </label>
                      </div>
                    </div>

                  </form>
                </div>

                {/* Right Column: Windows Live Ledger Inspector (4 Cols) */}
                <div className="lg:col-span-4 bg-slate-50 p-6 flex flex-col justify-between border-t lg:border-t-0 border-slate-200">
                  <div className="space-y-4">
                    
                    <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                        <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                        Ledger Voucher Preview
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        supplierType === 'Exporter' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {supplierType === 'Exporter' ? 'International Exporter' : 'Local Entity'}
                      </span>
                    </div>

                    {/* Commercial Entity Summary Card */}
                    <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm space-y-3">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-base shrink-0 shadow-sm">
                          {avatarLetter}
                        </div>
                        <div className="min-w-0 flex-1">
                          <h4 className="text-sm font-bold text-slate-900 truncate">{previewCompany}</h4>
                          <p className="text-xs text-blue-600 truncate flex items-center gap-1 font-medium mt-0.5">
                            <User className="w-3 h-3 opacity-70" />
                            <span>{previewOwner}</span>
                          </p>
                        </div>
                      </div>

                      <div className="border-t border-slate-100 pt-3 grid grid-cols-2 gap-2 text-[11px]">
                        <div>
                          <span className="text-slate-400 block font-medium">Billing Terms</span>
                          <span className="font-semibold text-slate-700">{previewTerms}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block font-medium">Currency</span>
                          <span className="font-bold text-slate-800">{currency} ({curSym})</span>
                        </div>
                        <div className="col-span-2">
                          <span className="text-slate-400 block font-medium">Contact Phone</span>
                          <span className="font-medium text-slate-700 font-mono">
                            {mobile.trim() ? `${phoneCode} ${mobile.trim()}` : 'None Provided'}
                          </span>
                        </div>
                        <div className="col-span-2">
                          <span className="text-slate-400 block font-medium">Address</span>
                          <span className="font-medium text-slate-700 truncate block">
                            {address.trim() || 'None Provided'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Accounting Ledger Voucher Card */}
                    <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-xl p-4 shadow-md space-y-3 border border-slate-700">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>General Ledger Baseline</span>
                        <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded border ${
                          isActive 
                            ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' 
                            : 'text-slate-400 bg-slate-600/20 border-slate-600/30'
                        }`}>
                          {isActive ? 'Active' : 'Deactive'}
                        </span>
                      </div>

                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Opening Balance</span>
                        <div className="flex items-baseline gap-1.5 mt-0.5">
                          <span className="text-2xl font-bold tracking-tight text-white font-mono">
                            {curSym} {formattedBal}
                          </span>
                          <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                            balanceType === 'CR' ? 'text-amber-300 bg-amber-400/20' : 'text-emerald-300 bg-emerald-400/20'
                          }`}>
                            {balanceType === 'CR' ? 'Cr' : 'Dr'}
                          </span>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400">Account Classification:</span>
                          <span className={`font-semibold ${balanceType === 'CR' ? 'text-amber-300' : 'text-emerald-300'}`}>
                            {balanceType === 'CR' ? 'Trade Payable (We Owe)' : 'Advance Deposit (Receivable)'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Information helper */}
                    <div className="p-3 bg-blue-50/60 rounded-lg border border-blue-100 text-slate-600 text-xs space-y-1.5">
                      <div className="font-semibold text-blue-900 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                        Multi-Company Relationship Rules
                      </div>
                      <p className="text-[11px] leading-relaxed text-slate-600">
                        Multiple corporate identities can be mapped to a singular Supplier Owner profile to consolidate audit trails while preserving separate trade vouchers.
                      </p>
                    </div>

                  </div>

                  {/* Bottom Actions */}
                  <div className="pt-4 border-t border-slate-200 mt-4 flex items-center gap-2">
                    <button 
                      type="button" 
                      onClick={() => handleSaveAction()} 
                      className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{supplierToEdit ? 'Commit Updates To Database' : 'Commit To Database'}</span>
                    </button>
                  </div>
                </div>

              </div>

              {/* Windows Status Bar Footer */}
              <div className="bg-slate-100 border-t border-slate-200 px-4 py-1.5 flex items-center justify-between text-[11px] text-slate-500 select-none">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500"></span> Ready</span>
                  <span>Record Status: Validating</span>
                </div>
                <div>UTF-8 • Connected: Master ERP Database</div>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* VIEW 2: SMARTPHONE MOBILE APPLICATION VIEW */}
          {/* ========================================== */}
          {(viewMode === 'mobile' || viewMode === 'split') && (
            <div className={`w-full max-w-[390px] mx-auto bg-slate-900 rounded-[44px] p-3.5 shadow-2xl border-4 border-slate-800 relative ${viewMode === 'split' ? 'xl:col-span-4' : ''}`}>
              
              {/* Mobile Screen Bezel Content */}
              <div className="bg-white rounded-[32px] overflow-hidden flex flex-col min-h-[720px] max-h-[800px] relative border border-slate-200">
                
                {/* Smartphone Status Bar */}
                <div className="bg-white px-6 pt-3 pb-1 flex items-center justify-between text-xs font-semibold text-slate-800 select-none shrink-0">
                  <span>9:41</span>
                  <div className="w-[110px] h-[22px] bg-slate-900 rounded-b-[14px] absolute left-1/2 -translate-x-1/2 top-0 flex items-center justify-center">
                    <div className="w-3 h-3 rounded-full bg-slate-800 border border-slate-700 mr-2"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-blue-900/60"></div>
                  </div>
                  <div className="flex items-center gap-1 text-[11px]">
                    <Signal className="w-3 h-3" />
                    <Wifi className="w-3 h-3" />
                    <BatteryMedium className="w-4 h-4" />
                  </div>
                </div>

                {/* Mobile App Header */}
                <div className="bg-white px-4 py-3 border-b border-slate-100 flex items-center justify-between shrink-0">
                  <div className="flex items-center gap-2">
                    <button 
                      type="button" 
                      data-modal-close="true"
                      onClick={handleCloseMainModal}
                      className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <div>
                      <h2 className="text-sm font-bold text-slate-900">{supplierToEdit ? 'Edit Supplier' : 'Add Supplier'}</h2>
                      <p className="text-[10px] text-slate-400">Trade Entity Enrollment</p>
                    </div>
                  </div>
                  <button type="button" onClick={resetAllForms} className="text-xs text-blue-600 font-semibold">
                    Reset
                  </button>
                </div>

                {/* Mobile Scrollable Content Area */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
                  
                  {/* Company Name */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Company / Trade Name <span className="text-rose-500">*</span>
                    </label>
                    <input 
                      type="text" 
                      required
                      value={companyName}
                      onChange={(e) => { setCompanyName(e.target.value); setCompanyError(false); }}
                      placeholder="e.g. Pelden Enterprise Ltd." 
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
                    />
                  </div>

                  {/* Owner Selection + Quick Add Button */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-700">Company Owner <span className="text-rose-500">*</span></label>
                      <button 
                        type="button" 
                        onClick={() => setIsOwnerModalOpen(true)} 
                        className="text-[11px] font-bold text-blue-600 hover:text-blue-800 flex items-center gap-0.5 underline"
                      >
                        + New Supplier
                      </button>
                    </div>
                    <div className="relative">
                      <select 
                        value={supplierOwner}
                        onChange={(e) => setSupplierOwner(e.target.value)}
                        className="w-full pl-3 pr-8 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer"
                      >
                        <option value="">-- Select Owner --</option>
                        {registeredOwners.map(o => (
                          <option key={o.id} value={o.id}>{o.name}</option>
                        ))}
                      </select>
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                        <ChevronDown className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>

                  {/* Supplier Classification */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Supplier Type</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button 
                        type="button" 
                        onClick={() => handleSupplierTypeChange('Local')} 
                        className={`py-2 px-2 text-xs font-bold rounded-xl border flex items-center justify-center gap-1 ${
                          supplierType === 'Local' ? 'border-2 border-blue-600 bg-blue-50 text-blue-700' : 'border-slate-200 bg-slate-50 text-slate-600'
                        }`}
                      >
                        <MapPin className="w-3 h-3" />
                        <span>Local</span>
                      </button>
                      <button 
                        type="button" 
                        onClick={() => handleSupplierTypeChange('Exporter')} 
                        className={`py-2 px-2 text-xs font-bold rounded-xl border flex items-center justify-center gap-1 ${
                          supplierType === 'Exporter' ? 'border-2 border-blue-600 bg-blue-50 text-blue-700' : 'border-slate-200 bg-slate-50 text-slate-600'
                        }`}
                      >
                        <Globe2 className="w-3 h-3" />
                        <span>Exporter</span>
                      </button>
                    </div>
                  </div>

                  {/* Mobile Number (Optional) */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-700">Mobile Number</label>
                      <span className="text-[10px] text-slate-400">Optional</span>
                    </div>
                    <div className="flex rounded-xl border border-slate-200 overflow-hidden bg-slate-50">
                      <span className="px-2.5 py-2 text-xs text-slate-600 font-bold border-r border-slate-200 bg-slate-100 flex items-center shrink-0">
                        +880
                      </span>
                      <input 
                        type="text" 
                        value={mobile}
                        onChange={(e) => setMobile(e.target.value)}
                        placeholder="1700-000000" 
                        className="w-full px-2.5 py-2 text-xs bg-transparent focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  {/* Address */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Address</label>
                    <textarea 
                      rows={2} 
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Street, City, Port location..." 
                      className="w-full p-2.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                    ></textarea>
                  </div>

                  {/* Credit Payment Terms */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Payment Terms</label>
                    <select 
                      value={paymentTerms}
                      onChange={(e) => setPaymentTerms(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">-- Select Payment Terms --</option>
                      <option value="Cash / Advance">Cash / Advance</option>
                      <option value="Net 7 Days">Net 7 Days</option>
                      <option value="Net 15 Days">Net 15 Days</option>
                      <option value="Net 30 Days">Net 30 Days</option>
                      <option value="Net 60 Days">Net 60 Days</option>
                      <option value="Custom">Custom Days...</option>
                    </select>

                    {paymentTerms === 'Custom' && (
                      <div className="mt-1.5">
                        <input 
                          type="number" 
                          min="1"
                          value={customDays}
                          onChange={(e) => setCustomDays(e.target.value)}
                          placeholder="Days (e.g. 45)" 
                          className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50"
                        />
                      </div>
                    )}
                  </div>

                  {/* Currency (Rule Enforced) */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-700">Currency</label>
                      <span className="text-[10px] text-slate-400">
                        {supplierType === 'Exporter' ? 'USD / RS Unlocked' : 'BDT for Local'}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button 
                        type="button" 
                        onClick={() => handleSelectCurrency('BDT')} 
                        className={`py-1.5 text-xs font-bold rounded-lg border ${
                          currency === 'BDT' ? 'border-2 border-blue-600 bg-blue-50 text-blue-700' : 'border-slate-200 bg-white text-slate-700'
                        }`}
                      >
                        ৳ BDT
                      </button>
                      <button 
                        type="button" 
                        disabled={supplierType === 'Local'}
                        onClick={() => handleSelectCurrency('USD')} 
                        className={`py-1.5 text-xs font-bold rounded-lg border ${
                          supplierType === 'Local'
                            ? 'border-slate-200 bg-slate-100 text-slate-400 opacity-50 cursor-not-allowed'
                            : currency === 'USD'
                              ? 'border-2 border-blue-600 bg-blue-50 text-blue-700'
                              : 'border-slate-200 bg-white text-slate-700'
                        }`}
                      >
                        $ USD
                      </button>
                      <button 
                        type="button" 
                        disabled={supplierType === 'Local'}
                        onClick={() => handleSelectCurrency('RS')} 
                        className={`py-1.5 text-xs font-bold rounded-lg border ${
                          supplierType === 'Local'
                            ? 'border-slate-200 bg-slate-100 text-slate-400 opacity-50 cursor-not-allowed'
                            : currency === 'RS'
                              ? 'border-2 border-blue-600 bg-blue-50 text-blue-700'
                              : 'border-slate-200 bg-white text-slate-700'
                        }`}
                      >
                        ₹ RS
                      </button>
                    </div>
                  </div>

                  {/* Opening Balance & Dr/Cr */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Opening Balance</label>
                    <div className="grid grid-cols-12 gap-2">
                      <div className="col-span-7 relative">
                        <span className="absolute left-2.5 top-2 text-xs font-bold text-slate-400">{curSym}</span>
                        <input 
                          type="number" 
                          step="0.01" 
                          value={openingBalance}
                          onChange={(e) => setOpeningBalance(e.target.value)}
                          placeholder="0.00" 
                          className="w-full pl-6 pr-2 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 bg-slate-50 font-mono"
                        />
                      </div>
                      <div className="col-span-5 flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                        <button 
                          type="button" 
                          onClick={() => setBalanceType('CR')} 
                          className={`flex-1 py-1 text-[11px] font-bold rounded ${
                            balanceType === 'CR' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500'
                          }`}
                        >
                          Cr
                        </button>
                        <button 
                          type="button" 
                          onClick={() => setBalanceType('DR')} 
                          className={`flex-1 py-1 text-[11px] font-medium rounded ${
                            balanceType === 'DR' ? 'bg-white text-slate-800 shadow-xs font-bold' : 'text-slate-500'
                          }`}
                        >
                          Dr
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Active Status */}
                  <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-xs font-semibold text-slate-700">Active Status</span>
                    <input 
                      type="checkbox" 
                      checked={isActive} 
                      onChange={(e) => setIsActive(e.target.checked)} 
                      className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
                    />
                  </div>

                </div>

                {/* Mobile Fixed Bottom Action Bar */}
                <div className="p-3 bg-white border-t border-slate-200 shrink-0">
                  <button 
                    type="button" 
                    onClick={() => handleSaveAction()} 
                    className="w-full py-2.5 bg-blue-600 active:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>{supplierToEdit ? 'Update Supplier' : 'Save Supplier'}</span>
                  </button>
                </div>

              </div>
            </div>
          )}

        </div>

      </div>

      {/* ======================================================== */}
      {/* SUB-MODAL: + NEW SUPPLIER / OWNER REGISTRATION           */}
      {/* ======================================================== */}
      {isOwnerModalOpen && (
        <ModalWrapper
          isOpen={isOwnerModalOpen}
          onClose={handleCloseOwnerModal}
          isDirty={isOwnerDirty}
          backdropClassName="fixed inset-0 z-60 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div 
            className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md my-auto overflow-hidden animate-in fade-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-slate-900 text-white px-5 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white">
                  <UserPlus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Register New Supplier / Owner</h3>
                  <p className="text-[11px] text-slate-400">Parent Person / Trade Principle</p>
                </div>
              </div>
              <button 
                type="button" 
                data-modal-close="true"
                onClick={handleCloseOwnerModal} 
                className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleNewOwnerSubmit} autoComplete="off" className="p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Supplier Owner Full Name <span className="text-rose-500">*</span>
                </label>
                <input 
                  type="text" 
                  required
                  autoFocus
                  value={modalOwnerName}
                  onChange={(e) => setModalOwnerName(e.target.value)}
                  placeholder="e.g. Tshering Pelden or John Vance" 
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Primary Country / Region
                </label>
                <select 
                  value={modalOwnerCountry}
                  onChange={(e) => setModalOwnerCountry(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                >
                  <option value="">-- Select Country / Region --</option>
                  <option value="Bangladesh (Local)">Bangladesh (Local)</option>
                  <option value="Bhutan (Exporter)">Bhutan (Exporter)</option>
                  <option value="India (Exporter)">India (Exporter)</option>
                  <option value="United States (Exporter)">United States (Exporter)</option>
                  <option value="China (Exporter)">China (Exporter)</option>
                  <option value="Other International">Other International</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Direct Contact Note (Optional)
                </label>
                <input 
                  type="text" 
                  value={modalOwnerNote}
                  onChange={(e) => setModalOwnerNote(e.target.value)}
                  placeholder="e.g. Managing Partner, Main Shareholder" 
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Clarification Box */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500 space-y-1">
                <p className="font-semibold text-slate-700">Notice:</p>
                <p>Once registered, this Supplier Owner will be permanently available in your company registry dropdown. You can attach multiple distinct businesses to this single owner.</p>
              </div>

              {/* Modal Actions */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button 
                  type="button" 
                  data-modal-close="true"
                  onClick={handleCloseOwnerModal} 
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition active:scale-[0.98]"
                >
                  <Check className="w-3.5 h-3.5" />
                  Register & Select
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* MODERN TOAST NOTIFICATION */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-70 animate-in fade-in slide-in-from-bottom-5">
          <div className="bg-slate-900 text-white rounded-xl px-5 py-4 shadow-2xl flex items-center gap-3.5 border border-slate-700 max-w-sm">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
              toast.type === 'warning' ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'
            }`}>
              {toast.type === 'warning' ? <AlertTriangle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
            </div>
            <div>
              <h5 className="text-xs font-bold text-white">{toast.title}</h5>
              <p className="text-[11px] text-slate-300">{toast.message}</p>
            </div>
            <button type="button" onClick={() => setToast(null)} className="text-slate-400 hover:text-white ml-2">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

    </ModalWrapper>
  );
};
