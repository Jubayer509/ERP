import React, { useState, useEffect } from 'react';
import { 
  Receipt, 
  Search, 
  Plus, 
  Filter, 
  Building2, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  FileText, 
  DollarSign, 
  Truck, 
  Printer, 
  Trash2, 
  CreditCard, 
  Warehouse, 
  Ship, 
  Eye, 
  ArrowUpRight,
  Sparkles,
  PackageCheck,
  Edit,
  RotateCcw,
  Loader2
} from 'lucide-react';
import { DirectPurchaseInvoice, Supplier, LetterOfCredit, SupplierPaymentRecord, InventoryItem, BankAccount } from '../../types/erp';
import { MOCK_ITEMS } from '../../data/mockErpData';
import { getUOMs, addUOM, subscribeUOMs } from '../../utils/uomStorage';
import { getItems, getActiveItems, subscribeItems } from '../../utils/itemStorage';
import { EditPurchaseInvoiceModal } from './EditPurchaseInvoiceModal';
import { PrintablePurchaseInvoiceModal } from './PrintablePurchaseInvoiceModal';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { RecycleBinModal } from '../common/RecycleBinModal';
import { ModalWrapper } from '../common/ModalWrapper';
import { saveDeletedRecord, getDeletedRecords, subscribeRecycleBin } from '../../utils/recycleBinStorage';
import { getBankAccounts, subscribeBankAccounts, isCashAccount } from '../../utils/bankAccountStorage';
import { postVoucher, voidAccountTransaction, getAccountTransactions } from '../../services/accountService';
import { useAuth } from '../../contexts/AuthContext';

export type PurchaseInvoiceTypeOption = 'Due 30 Days' | 'Cash Only' | 'Payment 10 Days' | 'Partial Payment';

interface DirectPurchaseInvoiceViewProps {
  invoices: DirectPurchaseInvoice[];
  suppliers: Supplier[];
  lcs: LetterOfCredit[];
  recentPayments?: SupplierPaymentRecord[];
  onCreateInvoice: (newInv: DirectPurchaseInvoice) => void;
  onUpdateInvoice: (updatedInv: DirectPurchaseInvoice) => void;
  onDeleteInvoice: (id: string) => void;
  onSelectLc?: (lc: LetterOfCredit) => void;
  onOpenPaymentModal?: (supplierId?: string, invoice?: DirectPurchaseInvoice) => void;
  onOpenSupplierKhata?: (supplierId: string) => void;
  onOpenAddSupplierModal?: () => void;
  onNavigateToPayments?: () => void;
  isCreateModalOpenExternal?: boolean;
  onCloseCreateModal?: () => void;
  currentBranch?: string;
}

export const DirectPurchaseInvoiceView: React.FC<DirectPurchaseInvoiceViewProps> = ({
  invoices,
  suppliers,
  lcs,
  recentPayments = [],
  onCreateInvoice,
  onUpdateInvoice,
  onDeleteInvoice,
  onSelectLc,
  onOpenPaymentModal,
  onOpenSupplierKhata,
  onOpenAddSupplierModal,
  onNavigateToPayments,
  isCreateModalOpenExternal = false,
  onCloseCreateModal,
  currentBranch = 'All Branches'
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [quickDateFilter, setQuickDateFilter] = useState<'ALL' | 'TODAY' | 'THIS_MONTH' | 'UNPAID' | 'PAID'>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [warehouseFilter, setWarehouseFilter] = useState<string>('ALL');
  const [currencyFilter, setCurrencyFilter] = useState<string>('ALL');

  // Modals state
  const [showCreateModalInternal, setShowCreateModalInternal] = useState(false);
  const showCreateModal = showCreateModalInternal || isCreateModalOpenExternal;
  const [viewInvoiceSlip, setViewInvoiceSlip] = useState<DirectPurchaseInvoice | null>(null);
  const [paymentModalInvoice, setPaymentModalInvoice] = useState<DirectPurchaseInvoice | null>(null);
  const [payAmountInput, setPayAmountInput] = useState<number>(0);
  const [paymentNote, setPaymentNote] = useState('');

  // Edit, Delete & Recycle Bin state
  const [editingInvoice, setEditingInvoice] = useState<DirectPurchaseInvoice | null>(null);
  const [deletingInvoice, setDeletingInvoice] = useState<DirectPurchaseInvoice | null>(null);
  const [isRecycleBinOpen, setIsRecycleBinOpen] = useState(false);
  const [trashCount, setTrashCount] = useState<number>(() => {
    return getDeletedRecords().filter(r => r.recordType === 'purchase_invoice').length;
  });

  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  // Real Bank & Cash Accounts
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  useEffect(() => {
    const unsub = subscribeBankAccounts(setBankAccounts);
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsub = subscribeRecycleBin(() => {
      setTrashCount(getDeletedRecords().filter(r => r.recordType === 'purchase_invoice').length);
    });
    return unsub;
  }, []);

  const handleConfirmDelete = async (reason: string) => {
    if (!deletingInvoice) return;
    if (!isAdmin) return;

    const allTxns = getAccountTransactions();
    const userObj = {
      uid: currentUser?.id || 'usr-admin',
      name: currentUser?.name || 'Admin',
      email: currentUser?.email
    };

    try {
      // 1. Reverse payment voucher if present and active
      const payTxnId =
        deletingInvoice.paymentVoucherId ||
        (deletingInvoice.paymentVoucherNumber
          ? allTxns.find(t => t.voucherNo === deletingInvoice.paymentVoucherNumber && t.status !== 'voided')?.id
          : undefined);
      if (payTxnId) {
        const payTxn = allTxns.find(t => t.id === payTxnId);
        if (payTxn && payTxn.status !== 'voided') {
          await voidAccountTransaction(payTxnId, `Void Invoice ${deletingInvoice.invoiceNumber}: ${reason}`, userObj);
        }
      }

      // 2. Reverse purchase journal voucher if present and active
      const billTxnId =
        deletingInvoice.purchaseVoucherId ||
        (deletingInvoice.purchaseVoucherNumber
          ? allTxns.find(t => t.voucherNo === deletingInvoice.purchaseVoucherNumber && t.status !== 'voided')?.id
          : undefined);
      if (billTxnId) {
        const billTxn = allTxns.find(t => t.id === billTxnId);
        if (billTxn && billTxn.status !== 'voided') {
          await voidAccountTransaction(billTxnId, `Void Invoice ${deletingInvoice.invoiceNumber}: ${reason}`, userObj);
        }
      }
    } catch (err) {
      console.warn('Voucher void notice during invoice delete:', err);
    }

    saveDeletedRecord({
      recordType: 'purchase_invoice',
      originalId: deletingInvoice.id,
      referenceNumber: deletingInvoice.invoiceNumber,
      title: `Direct Purchase Invoice (${deletingInvoice.supplierName})`,
      partyName: deletingInvoice.supplierName,
      amount: deletingInvoice.grandTotal,
      date: deletingInvoice.invoiceDate,
      deletedBy: currentUser?.name || 'Admin',
      reason,
      data: { ...deletingInvoice, isVoided: true, status: 'Voided', paymentStatus: 'Voided', voidReason: reason }
    });
    onDeleteInvoice(deletingInvoice.id);
    setDeletingInvoice(null);
  };

  // Form State for New Direct Purchase Invoice
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [challanNo, setChallanNo] = useState('');
  const [supplierBillNo, setSupplierBillNo] = useState('');
  const [invDate, setInvDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState('');
  const [warehouseName, setWarehouseName] = useState('');
  const [linkedLcNumber, setLinkedLcNumber] = useState('');
  
  // Dynamic Items and UOMs (connected with Inventory and Sales) - STRICTLY ONLY ACTIVE ITEMS
  const [availableItems, setAvailableItems] = useState<InventoryItem[]>(() => getActiveItems());
  const [availableUoms, setAvailableUoms] = useState<string[]>(() => getUOMs());
  const [selectedItemId, setSelectedItemId] = useState('');
  const [selectedUom, setSelectedUom] = useState<string>('');
  const [showNewUomPrompt, setShowNewUomPrompt] = useState(false);
  const [newUomInput, setNewUomInput] = useState('');

  useEffect(() => {
    const unsubItems = subscribeItems((items) => {
      const activeOnly = items.filter(i => (i.status || 'Active') === 'Active');
      setAvailableItems(activeOnly);
    });
    const unsubUoms = subscribeUOMs(setAvailableUoms);
    return () => {
      unsubItems();
      unsubUoms();
    };
  }, []);

  const [qty, setQty] = useState<number>(0);
  const [unitRate, setUnitRate] = useState<number>(0);
  const [taxVatRate, setTaxVatRate] = useState<number>(0);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  
  // Payment Type: Default is 'Due 30 Days'
  const [paymentType, setPaymentType] = useState<PurchaseInvoiceTypeOption>('Due 30 Days');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank Transfer / Cheque' | 'Credit' | 'LC Settlement'>('' as any);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paidFromAccountId, setPaidFromAccountId] = useState<string>('');
  const [adminApprovedOverdraft, setAdminApprovedOverdraft] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isSubmittingRef = React.useRef(false);
  const [pendingInvoiceId, setPendingInvoiceId] = useState(() => `dpi-${Date.now()}`);
  const [truckNo, setTruckNo] = useState('');
  const [invoiceNotes, setInvoiceNotes] = useState('');

  const resetCreateForm = () => {
    setSelectedSupplierId('');
    setChallanNo('');
    setSupplierBillNo('');
    setInvDate(new Date().toISOString().split('T')[0]);
    setDueDate('');
    setWarehouseName('');
    setLinkedLcNumber('');
    setSelectedItemId('');
    setSelectedUom('');
    setShowNewUomPrompt(false);
    setNewUomInput('');
    setQty(0);
    setUnitRate(0);
    setTaxVatRate(0);
    setDiscountAmount(0);
    setPaymentType('Due 30 Days');
    setPaymentMethod('' as any);
    setPaidAmount(0);
    setPaidFromAccountId('');
    setAdminApprovedOverdraft(false);
    setSubmitError(null);
    setPendingInvoiceId(`dpi-${Date.now()}`);
    setTruckNo('');
    setInvoiceNotes('');
  };

  const handleCloseCreateModal = () => {
    resetCreateForm();
    setShowCreateModalInternal(false);
    if (onCloseCreateModal) onCloseCreateModal();
  };

  // Inline Record Payment Modal states
  const [inlinePayMethod, setInlinePayMethod] = useState<'Cash' | 'Bank Transfer' | 'Cheque'>('' as any);
  const [inlinePaidFromAccountId, setInlinePaidFromAccountId] = useState<string>('');
  const [inlineAdminOverdraft, setInlineAdminOverdraft] = useState(false);
  const [inlinePayError, setInlinePayError] = useState<string | null>(null);
  const [isInlinePaying, setIsInlinePaying] = useState(false);
  const isInlinePayingRef = React.useRef(false);

  // Calculations for Create Modal
  const itemSubtotal = qty * unitRate;
  const calculatedTax = Math.round((itemSubtotal * taxVatRate) / 100);
  const grandTotal = Math.max(0, itemSubtotal + calculatedTax - discountAmount);

  // Calculate actual paid & due based on paymentType
  const actualPaidAmount = paymentType === 'Cash Only' 
    ? grandTotal 
    : paymentType === 'Due 30 Days' || paymentType === 'Payment 10 Days'
      ? (paidAmount > 0 ? Math.min(grandTotal, paidAmount) : 0)
      : Math.min(grandTotal, Math.max(0, paidAmount));

  const dueAmount = Math.max(0, grandTotal - actualPaidAmount);

  // Filter Paid From accounts using isCashAccount
  const filteredPaidFromAccounts = React.useMemo(() => {
    if (paymentMethod === 'Cash' || paymentType === 'Cash Only') {
      return bankAccounts.filter(acc => isCashAccount(acc));
    }
    if (paymentMethod === 'Bank Transfer / Cheque' || paymentMethod === 'LC Settlement') {
      return bankAccounts.filter(acc => !isCashAccount(acc));
    }
    // When Credit is selected but user entered a paidAmount > 0, show all Cash & Bank accounts
    return bankAccounts;
  }, [bankAccounts, paymentMethod, paymentType]);

  useEffect(() => {
    if (paidFromAccountId && !filteredPaidFromAccounts.some(a => a.id === paidFromAccountId)) {
      setPaidFromAccountId('');
    }
    setAdminApprovedOverdraft(false);
    setSubmitError(null);
  }, [filteredPaidFromAccounts, paymentMethod, paymentType]);

  const selectedPaidFromAccount = React.useMemo(
    () => bankAccounts.find(a => a.id === paidFromAccountId),
    [bankAccounts, paidFromAccountId]
  );

  // Filtered accounts for inline Record Payment modal
  const filteredInlineAccounts = React.useMemo(() => {
    if (inlinePayMethod === 'Cash') {
      return bankAccounts.filter(acc => isCashAccount(acc));
    }
    return bankAccounts.filter(acc => !isCashAccount(acc));
  }, [bankAccounts, inlinePayMethod]);

  useEffect(() => {
    if (inlinePaidFromAccountId && !filteredInlineAccounts.some(a => a.id === inlinePaidFromAccountId)) {
      setInlinePaidFromAccountId('');
    }
  }, [filteredInlineAccounts, inlinePayMethod]);

  const selectedInlineAccount = React.useMemo(
    () => bankAccounts.find(a => a.id === inlinePaidFromAccountId),
    [bankAccounts, inlinePaidFromAccountId]
  );

  // Helper to calculate due date
  const computeDueDate = (baseDate: string, days: number) => {
    const d = new Date(baseDate);
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  };

  // Handle invoice date change and adjust due date accordingly
  const handleInvoiceDateChange = (newDate: string) => {
    setInvDate(newDate);
    if (paymentType === 'Due 30 Days') {
      setDueDate(computeDueDate(newDate, 30));
    } else if (paymentType === 'Payment 10 Days') {
      setDueDate(computeDueDate(newDate, 10));
    } else if (paymentType === 'Cash Only') {
      setDueDate(newDate);
    }
  };

  // Handle Payment Type Change (Exact parity with Sales invoice system)
  const handlePaymentTypeChange = (type: PurchaseInvoiceTypeOption) => {
    setPaymentType(type);
    if (type === 'Due 30 Days') {
      setPaidAmount(0);
      setDueDate(computeDueDate(invDate, 30));
      setPaymentMethod('Credit');
    } else if (type === 'Cash Only') {
      setPaidAmount(grandTotal);
      setDueDate(invDate);
      setPaymentMethod('Cash');
    } else if (type === 'Payment 10 Days') {
      setPaidAmount(0);
      setDueDate(computeDueDate(invDate, 10));
      setPaymentMethod('Credit');
    } else if (type === 'Partial Payment') {
      const defaultHalf = Math.round(grandTotal * 0.5);
      setPaidAmount(defaultHalf);
      setDueDate(computeDueDate(invDate, 30));
      setPaymentMethod('Bank Transfer / Cheque');
    }
  };

  // Auto-adjust paid amount when payment method changes
  const handlePaymentMethodChange = (method: 'Cash' | 'Bank Transfer / Cheque' | 'Credit' | 'LC Settlement') => {
    setPaymentMethod(method);
    if (method === 'Cash') {
      setPaymentType('Cash Only');
      setPaidAmount(grandTotal);
      setDueDate(invDate);
    } else if (method === 'Credit') {
      if (paymentType === 'Cash Only') {
        setPaymentType('Due 30 Days');
        setPaidAmount(0);
        setDueDate(computeDueDate(invDate, 30));
      }
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.substring(0, 7);

  // Quick Metric counts
  const todayInvoicesCount = invoices.filter(i => i.invoiceDate === todayStr).length;
  const thisMonthInvoicesCount = invoices.filter(i => i.invoiceDate.startsWith(currentMonthStr)).length;
  const unpaidInvoicesCount = invoices.filter(i => i.dueAmount > 0).length;
  const paidInvoicesCount = invoices.filter(i => i.dueAmount <= 0).length;

  // Filtered Invoices
  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = 
      inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.challanNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (inv.supplierBillNumber || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.items.some(i => i.itemName.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus = 
      statusFilter === 'ALL' || 
      inv.paymentStatus === statusFilter || 
      inv.status === statusFilter;

    const matchesWarehouse = 
      warehouseFilter === 'ALL' || 
      inv.warehouseName.toLowerCase().includes(warehouseFilter.toLowerCase());

    const matchesCurrency = 
      currencyFilter === 'ALL' || 
      inv.currency === currencyFilter;

    let matchesDate = true;
    if (quickDateFilter === 'TODAY') {
      matchesDate = inv.invoiceDate === todayStr;
    } else if (quickDateFilter === 'THIS_MONTH') {
      matchesDate = inv.invoiceDate.startsWith(currentMonthStr);
    } else if (quickDateFilter === 'UNPAID') {
      matchesDate = inv.dueAmount > 0;
    } else if (quickDateFilter === 'PAID') {
      matchesDate = inv.dueAmount <= 0;
    }

    return matchesSearch && matchesStatus && matchesWarehouse && matchesCurrency && matchesDate;
  });

  // KPI Metrics
  const totalInvoicedBDT = invoices
    .filter(i => i.currency === 'BDT')
    .reduce((sum, i) => sum + i.grandTotal, 0);

  const totalPaidBDT = invoices
    .filter(i => i.currency === 'BDT')
    .reduce((sum, i) => sum + i.paidAmount, 0);

  const totalDueBDT = invoices
    .filter(i => i.currency === 'BDT')
    .reduce((sum, i) => sum + i.dueAmount, 0);

  const totalInvoicedUSD = invoices
    .filter(i => i.currency === 'USD')
    .reduce((sum, i) => sum + i.grandTotal, 0);

  // Submit New Direct Purchase Invoice (Flow A: posts Purchase Journal + optional Payment Voucher atomically)
  const handleSubmitInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingRef.current) return;
    setSubmitError(null);

    if (grandTotal <= 0) {
      setSubmitError('Invoice grand total must be greater than 0.');
      return;
    }

    const supp = suppliers.find(s => s.id === selectedSupplierId) || suppliers[0];
    if (!supp) {
      setSubmitError('Please select a valid supplier.');
      return;
    }

    const itm = availableItems.find(i => i.id === selectedItemId) || availableItems[0] || MOCK_ITEMS[0];
    const generatedInvNumber = `DPI-2026-0${126 + invoices.length}`;
    const branchStr = currentBranch && currentBranch !== 'All Branches' ? currentBranch : 'Dhaka Head Office';

    // Pre-validate Paid From account & Overdraft rules before posting any voucher
    let paidFromAccount: BankAccount | undefined;
    if (actualPaidAmount > 0) {
      if (!paidFromAccountId) {
        setSubmitError('Please select a "Paid From" Cash or Bank account for the paid amount.');
        return;
      }
      paidFromAccount = bankAccounts.find(a => a.id === paidFromAccountId);
      if (!paidFromAccount) {
        setSubmitError('Selected "Paid From" account was not found.');
        return;
      }

      const currentBal = Number(paidFromAccount.ledgerBalance) || 0;
      const projectedBal = currentBal - actualPaidAmount;
      const isCash = isCashAccount(paidFromAccount);

      if (isCash && projectedBal < 0) {
        setSubmitError(
          `Insufficient Cash balance in ${paidFromAccount.bankName}. Current balance: BDT ${currentBal.toLocaleString()}, required: BDT ${actualPaidAmount.toLocaleString()}. Cash accounts cannot go negative.`
        );
        return;
      }

      if (!isCash && projectedBal < 0 && !(isAdmin && adminApprovedOverdraft)) {
        setSubmitError(
          isAdmin
            ? `Bank balance in ${paidFromAccount.bankName} (BDT ${currentBal.toLocaleString()}) is less than paid amount. Please check "Admin Overdraft Approval" below to proceed.`
            : `Insufficient Bank balance in ${paidFromAccount.bankName} (BDT ${currentBal.toLocaleString()}). Bank overdraft requires Administrator approval.`
        );
        return;
      }
    }

    isSubmittingRef.current = true;
    setIsSubmitting(true);

    const userObj = {
      uid: currentUser?.id || 'usr-admin',
      name: currentUser?.name || 'Accounts Dept',
      email: currentUser?.email
    };

    let purchaseVoucherTxn: any = null;

    try {
      // (i) Post Purchase Entry: Dr 13100 Raw Material Inventory (Landed Stock) / Cr 21100 Accounts Payable (Supplier Sub-ledger)
      purchaseVoucherTxn = await postVoucher({
        transactionType: 'JOURNAL',
        subType: 'Pay to Supplier',
        date: invDate,
        amount: grandTotal,
        accountHeadId: '13100',
        accountHeadCode: '13100',
        accountHeadName: 'Raw Material Inventory (Landed Stock)',
        partyType: 'Supplier',
        partyId: supp.id,
        partyName: supp.name,
        partyCode: supp.code,
        partyPhone: supp.phone,
        referenceNo: generatedInvNumber,
        note: `Direct Purchase Invoice ${generatedInvNumber} - ${itm.name} (${qty} ${selectedUom || itm.uom || 'MT'}) [Challan: ${challanNo.trim()}]`,
        branch: branchStr,
        user: userObj,
        idempotencyKey: `dpi-bill-${pendingInvoiceId}`
      });

      // (ii) If actualPaidAmount > 0, post Payment Voucher from selected Paid From account
      let paymentVoucherTxn: any = null;
      if (actualPaidAmount > 0 && paidFromAccount) {
        try {
          paymentVoucherTxn = await postVoucher({
            transactionType: 'PAYMENT',
            subType: 'Pay to Supplier',
            date: invDate,
            amount: actualPaidAmount,
            partyType: 'Supplier',
            partyId: supp.id,
            partyName: supp.name,
            partyCode: supp.code,
            partyPhone: supp.phone,
            bankAccountId: paidFromAccount.id,
            paymentMethod: isCashAccount(paidFromAccount) ? 'Cash' : 'Bank Transfer',
            referenceNo: generatedInvNumber,
            note: `Payment against Direct Purchase Invoice ${generatedInvNumber} (${supp.name})`,
            branch: branchStr,
            user: userObj,
            adminApprovedOverdraft: isAdmin && adminApprovedOverdraft,
            idempotencyKey: `dpi-pay-${pendingInvoiceId}`
          });
        } catch (payErr: any) {
          // Roll back (void) purchase journal (i) so no half-posted state remains
          if (purchaseVoucherTxn?.id) {
            try {
              await voidAccountTransaction(
                purchaseVoucherTxn.id,
                'Automatic rollback: payment voucher failed during invoice creation',
                userObj
              );
            } catch (rbErr) {
              console.warn('Rollback notice:', rbErr);
            }
          }
          throw payErr;
        }
      }

      const finalPaid = paymentVoucherTxn ? paymentVoucherTxn.amount : 0;
      const finalDue = Math.max(0, grandTotal - finalPaid);
      const curPaymentStatus: DirectPurchaseInvoice['paymentStatus'] =
        finalDue <= 0 ? 'Paid' : finalPaid > 0 ? 'Partial' : 'Unpaid';

      const newInvoice: DirectPurchaseInvoice = {
        id: pendingInvoiceId,
        invoiceNumber: generatedInvNumber,
        challanNumber: challanNo.trim() || `CH-${Math.floor(10000 + Math.random() * 90000)}`,
        supplierBillNumber: supplierBillNo.trim() || undefined,
        supplierId: supp.id,
        supplierName: supp.name,
        lcNumber: linkedLcNumber || undefined,
        invoiceDate: invDate,
        dueDate: dueDate,
        currency: supp.country === 'Bangladesh' ? 'BDT' : 'USD',
        branch: branchStr,
        items: [
          {
            itemId: itm.id,
            itemName: itm.name,
            quantity: qty,
            unitPrice: unitRate,
            totalPrice: itemSubtotal,
            uom: selectedUom || itm.uom || 'MT'
          }
        ],
        subTotal: itemSubtotal,
        taxVatRate: taxVatRate,
        taxVatAmount: calculatedTax,
        discountAmount: discountAmount,
        grandTotal: grandTotal,
        paidAmount: finalPaid,
        dueAmount: finalDue,
        paymentType: paymentType,
        paymentMethod: paymentMethod,
        paymentStatus: curPaymentStatus,
        warehouseName: warehouseName,
        status: finalDue > 0 ? 'Payment Pending' : 'Posted & In Stock',
        notes: `${invoiceNotes} (Truck: ${truckNo})`,
        purchaseVoucherId: purchaseVoucherTxn.id,
        purchaseVoucherNumber: purchaseVoucherTxn.voucherNo,
        paymentVoucherId: paymentVoucherTxn?.id,
        paymentVoucherNumber: paymentVoucherTxn?.voucherNo,
        paidFromAccountId: paidFromAccount?.id,
        paidFromAccountName: paidFromAccount ? `${paidFromAccount.bankName} (${paidFromAccount.accountNumber})` : undefined
      };

      onCreateInvoice(newInvoice);
      setQuickDateFilter('ALL');
      isSubmittingRef.current = false;
      setIsSubmitting(false);
      handleCloseCreateModal();
    } catch (err: any) {
      isSubmittingRef.current = false;
      setIsSubmitting(false);
      setSubmitError(err?.message || 'Failed to post purchase invoice vouchers.');
    }
  };

  // Submit Payment for Invoice Due (Inline Modal -> posts PAYMENT voucher via postVoucher)
  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentModalInvoice || payAmountInput <= 0 || isInlinePayingRef.current) return;
    setInlinePayError(null);

    if (!inlinePaidFromAccountId) {
      setInlinePayError('Please select a "Paid From" account.');
      return;
    }

    const accountObj = bankAccounts.find(a => a.id === inlinePaidFromAccountId);
    if (!accountObj) {
      setInlinePayError('Selected "Paid From" account was not found.');
      return;
    }

    const currentBal = Number(accountObj.ledgerBalance) || 0;
    const projectedBal = currentBal - payAmountInput;
    const isCash = isCashAccount(accountObj);

    if (isCash && projectedBal < 0) {
      setInlinePayError(
        `Insufficient Cash balance in ${accountObj.bankName}. Current balance: BDT ${currentBal.toLocaleString()}. Cash accounts cannot go negative.`
      );
      return;
    }

    if (!isCash && projectedBal < 0 && !(isAdmin && inlineAdminOverdraft)) {
      setInlinePayError(
        isAdmin
          ? `Bank balance in ${accountObj.bankName} is insufficient. Please check "Admin Overdraft Approval" below.`
          : `Insufficient Bank balance in ${accountObj.bankName}. Bank overdraft requires Administrator approval.`
      );
      return;
    }

    isInlinePayingRef.current = true;
    setIsInlinePaying(true);

    try {
      const postedTxn = await postVoucher({
        transactionType: 'PAYMENT',
        subType: 'Pay to Supplier',
        date: new Date().toISOString().split('T')[0],
        amount: payAmountInput,
        partyType: 'Supplier',
        partyId: paymentModalInvoice.supplierId,
        partyName: paymentModalInvoice.supplierName,
        bankAccountId: accountObj.id,
        paymentMethod: inlinePayMethod,
        referenceNo: paymentModalInvoice.invoiceNumber,
        note: `Due settlement for ${paymentModalInvoice.invoiceNumber}: ${paymentNote || 'Settlement'}`,
        branch: paymentModalInvoice.branch || 'Dhaka Head Office',
        user: {
          uid: currentUser?.id || 'usr-admin',
          name: currentUser?.name || 'Accounts Dept',
          email: currentUser?.email
        },
        adminApprovedOverdraft: isAdmin && inlineAdminOverdraft,
        idempotencyKey: `dpi-due-pay-${paymentModalInvoice.id}-${Date.now()}`
      });

      const newPaid = paymentModalInvoice.paidAmount + postedTxn.amount;
      const newDue = Math.max(0, paymentModalInvoice.grandTotal - newPaid);
      const newStatus: DirectPurchaseInvoice['paymentStatus'] = newDue <= 0 ? 'Paid' : 'Partial';

      const updated: DirectPurchaseInvoice = {
        ...paymentModalInvoice,
        paidAmount: newPaid,
        dueAmount: newDue,
        paymentStatus: newStatus,
        paymentVoucherId: postedTxn.id,
        paymentVoucherNumber: postedTxn.voucherNo,
        status: newDue <= 0 ? 'Posted & In Stock' : 'Payment Pending',
        notes: `${paymentModalInvoice.notes || ''} | [Payment of ${paymentModalInvoice.currency} ${postedTxn.amount.toLocaleString()} via ${postedTxn.voucherNo}: ${paymentNote || 'Settlement'}]`
      };

      onUpdateInvoice(updated);
      isInlinePayingRef.current = false;
      setIsInlinePaying(false);
      setPaymentModalInvoice(null);
      setPayAmountInput(0);
      setPaymentNote('');
      setInlineAdminOverdraft(false);
    } catch (err: any) {
      isInlinePayingRef.current = false;
      setIsInlinePaying(false);
      setInlinePayError(err?.message || 'Failed to post payment voucher.');
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner & KPI Summary (Interactive Quick Filters) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <button
          type="button"
          onClick={() => {
            setQuickDateFilter('ALL');
            setStatusFilter('ALL');
          }}
          className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
            quickDateFilter === 'ALL' && statusFilter === 'ALL'
              ? 'bg-indigo-50/80 border-indigo-300 shadow-xs ring-2 ring-indigo-500/20'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Direct Invoices</span>
            <Receipt className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-xl font-black text-slate-900 font-mono">
            {invoices.length} <span className="text-xs font-normal text-slate-500">Invoices</span>
          </p>
          <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
            Click to view all purchase invoices
          </p>
        </button>

        <button
          type="button"
          onClick={() => setQuickDateFilter('TODAY')}
          className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
            quickDateFilter === 'TODAY'
              ? 'bg-blue-50/80 border-blue-300 shadow-xs ring-2 ring-blue-500/20'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Today's Invoices</span>
            <Calendar className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-xl font-black text-blue-900 font-mono">
            {todayInvoicesCount} <span className="text-xs font-normal text-slate-500">Today</span>
          </p>
          <p className="text-[11px] text-blue-600 mt-1 font-mono font-semibold">
            {todayInvoicesCount > 0 ? '✓ Live Inward Today' : 'No Invoices Today Yet'}
          </p>
        </button>

        <button
          type="button"
          onClick={() => {
            setQuickDateFilter('PAID');
            setStatusFilter('ALL');
          }}
          className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
            quickDateFilter === 'PAID'
              ? 'bg-emerald-50/80 border-emerald-300 shadow-xs ring-2 ring-emerald-500/20'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Paid to Suppliers</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-xl font-black text-emerald-700 font-mono">
            ৳ {(totalPaidBDT / 100000).toFixed(2)} <span className="text-xs text-slate-500 font-normal">Lakh</span>
          </p>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div 
              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${totalInvoicedBDT > 0 ? (totalPaidBDT / totalInvoicedBDT) * 100 : 0}%` }}
            />
          </div>
        </button>

        <button
          type="button"
          onClick={() => {
            setQuickDateFilter('UNPAID');
            setStatusFilter('ALL');
          }}
          className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
            quickDateFilter === 'UNPAID'
              ? 'bg-rose-50/80 border-rose-300 shadow-xs ring-2 ring-rose-500/20'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Supplier Dues</span>
            <Clock className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-xl font-black text-rose-700 font-mono">
            ৳ {(totalDueBDT / 100000).toFixed(2)} <span className="text-xs text-slate-500 font-normal">Lakh</span>
          </p>
          <p className="text-[11px] text-rose-600 mt-1 font-medium flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{unpaidInvoicesCount} Unpaid Invoices (Click to view)</span>
          </p>
        </button>
      </div>

      {/* Control Header & Filters */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm md:text-base font-bold text-slate-900 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-indigo-600" />
                <span>Direct Purchase Invoices</span>
              </h2>
              <span className="text-[10px] font-bold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full font-mono">
                {filteredInvoices.length} Registered
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
            {onOpenAddSupplierModal && (
              <button
                type="button"
                onClick={onOpenAddSupplierModal}
                className="px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
                title="Add new supplier or exporter company"
              >
                <Plus className="w-3.5 h-3.5 text-emerald-400" />
                <span>+ Add Supplier</span>
              </button>
            )}

            {onOpenSupplierKhata && (
              <button
                type="button"
                onClick={() => onOpenSupplierKhata(suppliers[0]?.id || '')}
                className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200"
              >
                <FileText className="w-3.5 h-3.5 text-indigo-600" />
                <span>Supplier Ledger</span>
              </button>
            )}

            {onOpenPaymentModal && (
              <button
                type="button"
                onClick={() => onOpenPaymentModal()}
                className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>+ Pay Supplier</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                resetCreateForm();
                setShowCreateModalInternal(true);
              }}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Purchase Invoice</span>
            </button>
          </div>
        </div>

        {/* Quick Date Tabs Strip */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 select-none text-xs font-semibold">
          <button
            type="button"
            onClick={() => setQuickDateFilter('ALL')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              quickDateFilter === 'ALL'
                ? 'bg-indigo-600 text-white shadow-2xs font-bold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>All Invoices ({invoices.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setQuickDateFilter('TODAY')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              quickDateFilter === 'TODAY'
                ? 'bg-blue-600 text-white shadow-2xs font-bold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Today's Invoices ({todayInvoicesCount})</span>
          </button>
          <button
            type="button"
            onClick={() => setQuickDateFilter('THIS_MONTH')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              quickDateFilter === 'THIS_MONTH'
                ? 'bg-blue-600 text-white shadow-2xs font-bold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>This Month ({thisMonthInvoicesCount})</span>
          </button>
          <button
            type="button"
            onClick={() => setQuickDateFilter('UNPAID')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              quickDateFilter === 'UNPAID'
                ? 'bg-rose-600 text-white shadow-2xs font-bold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Due / Unpaid ({unpaidInvoicesCount})</span>
          </button>
          <button
            type="button"
            onClick={() => setQuickDateFilter('PAID')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              quickDateFilter === 'PAID'
                ? 'bg-emerald-600 text-white shadow-2xs font-bold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Paid ({paidInvoicesCount})</span>
          </button>

          <button
            type="button"
            onClick={() => setIsRecycleBinOpen(true)}
            className="ml-auto px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold text-xs shadow-2xs"
            title="Recycle Bin"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-600" />
            <span>Trash / Recycle Bin ({trashCount})</span>
          </button>
        </div>

        {/* Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 pt-2 border-t border-slate-100 text-xs">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search Invoice #, Challan, Supplier..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Payment Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">Payment Status: All</option>
              <option value="Paid">✓ Paid</option>
              <option value="Partial">⏳ Partial Paid</option>
              <option value="Unpaid">⚠️ Unpaid / Credit</option>
            </select>
          </div>

          {/* Warehouse Yard Filter */}
          <div>
            <select
              value={warehouseFilter}
              onChange={(e) => setWarehouseFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All Receiving Depots & Yards</option>
              <option value="Chittagong">Chittagong Port Yard</option>
              <option value="Burimari">Burimari Land Port Unit</option>
              <option value="Tejgaon">Tejgaon Central Depot</option>
              <option value="Bogra">Bogra Regional Depot</option>
            </select>
          </div>

          {/* Currency Filter */}
          <div>
            <select
              value={currencyFilter}
              onChange={(e) => setCurrencyFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">Currency: All (BDT / USD)</option>
              <option value="BDT">BDT</option>
              <option value="USD">USD</option>
            </select>
          </div>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-3.5">Invoice # & Challan</th>
                <th className="py-3 px-3.5">Date & Due</th>
                <th className="py-3 px-3.5">Supplier / Vendor</th>
                <th className="py-3 px-3.5">Receiving Depot / Yard</th>
                <th className="py-3 px-3.5">Items & Quantity</th>
                <th className="py-3 px-3.5 text-right">Invoice Amount</th>
                <th className="py-3 px-3.5 text-center">Payment Status</th>
                <th className="py-3 px-3.5 text-center">LC Ref / Source</th>
                <th className="py-3 px-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    <Receipt className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600">No Direct Purchase Invoices Found</p>
                    <p className="text-[11px] text-slate-400">Try adjusting search filters or click "Create Purchase Invoice".</p>
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => {
                  const isPaid = inv.paymentStatus === 'Paid';
                  const isPartial = inv.paymentStatus === 'Partial';
                  const isCredit = inv.paymentMethod.startsWith('Credit');

                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Invoice & Challan */}
                      <td className="py-3 px-3.5">
                        <div className="font-mono font-bold text-indigo-700 flex items-center gap-1.5">
                          <Receipt className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                          <span>{inv.invoiceNumber}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                          Challan: <span className="font-bold text-slate-700">{inv.challanNumber}</span>
                        </div>
                        {inv.supplierBillNumber && (
                          <div className="text-[10px] text-slate-400 font-mono">
                            Bill: {inv.supplierBillNumber}
                          </div>
                        )}
                      </td>

                      {/* Date & Due */}
                      <td className="py-3 px-3.5">
                        <div className="font-medium text-slate-800">{inv.invoiceDate}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1">
                          <span>Due:</span>
                          <span className={inv.dueAmount > 0 ? 'text-amber-700 font-semibold' : 'text-slate-500'}>
                            {inv.dueDate}
                          </span>
                        </div>
                      </td>

                      {/* Supplier */}
                      <td className="py-3 px-3.5">
                        <div className="font-bold text-slate-900 truncate max-w-[180px]">
                          {inv.supplierName}
                        </div>
                        <div className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Building2 className="w-3 h-3 text-slate-400" />
                          <span>Terms: {inv.paymentMethod.split(' ')[0]}</span>
                        </div>
                      </td>

                      {/* Receiving Depot / Yard */}
                      <td className="py-3 px-3.5">
                        <div className="flex items-center gap-1 text-slate-700 font-medium">
                          <Warehouse className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                          <span className="truncate max-w-[160px]">{inv.warehouseName}</span>
                        </div>
                        <div className="text-[10px] text-emerald-600 font-medium mt-0.5">
                          ✓ Stock Inward Posted
                        </div>
                      </td>

                      {/* Items */}
                      <td className="py-3 px-3.5">
                        <div className="font-semibold text-slate-900 truncate max-w-[190px]">
                          {inv.items[0]?.itemName}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500">
                          {inv.items[0]?.quantity.toLocaleString()} {inv.items[0]?.uom || 'MT'} @ {inv.currency} {inv.items[0]?.unitPrice.toLocaleString()}
                        </div>
                      </td>

                      {/* Invoice Amount */}
                      <td className="py-3 px-3.5 text-right font-mono">
                        <div className="font-bold text-slate-900 text-xs">
                          {inv.currency} {inv.grandTotal.toLocaleString()}
                        </div>
                        {inv.taxVatAmount > 0 && (
                          <div className="text-[10px] text-slate-400">
                            +VAT {inv.taxVatRate}%: {inv.currency} {inv.taxVatAmount.toLocaleString()}
                          </div>
                        )}
                        <div className="text-[10px] font-semibold mt-0.5">
                          {inv.dueAmount > 0 ? (
                            <span className="text-rose-600 font-bold">Due: {inv.currency} {inv.dueAmount.toLocaleString()}</span>
                          ) : (
                            <span className="text-emerald-600">Fully Paid</span>
                          )}
                        </div>
                      </td>

                      {/* Payment Status & Progress */}
                      <td className="py-3 px-3.5 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          isPaid 
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
                            : isPartial 
                              ? 'bg-amber-50 text-amber-700 border-amber-300' 
                              : 'bg-rose-50 text-rose-700 border-rose-300'
                        }`}>
                          {isPaid ? '✓ Paid' : isPartial ? '⏳ Partial' : '⚠️ Unpaid / Due'}
                        </span>
                        <div className="text-[10px] text-slate-500 font-mono mt-1">
                          Paid: {Math.round((inv.paidAmount / (inv.grandTotal || 1)) * 100)}%
                        </div>
                      </td>

                      {/* LC Ref / Source */}
                      <td className="py-3 px-3.5 text-center font-mono">
                        {inv.lcNumber ? (
                          <button
                            type="button"
                            onClick={() => {
                              const match = lcs.find(l => l.lcNumber === inv.lcNumber);
                              if (match && onSelectLc) onSelectLc(match);
                            }}
                            className="text-blue-700 hover:underline font-bold inline-flex items-center gap-1 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 text-[11px]"
                          >
                            <Ship className="w-3 h-3 text-blue-600" />
                            <span>{inv.lcNumber}</span>
                          </button>
                        ) : (
                          <span className="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                            Spot Local Purchase
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5 flex-wrap">
                          {/* Record Payment (if due) */}
                          {inv.dueAmount > 0 && (
                            <button
                              type="button"
                              onClick={() => {
                                if (onOpenPaymentModal) {
                                  onOpenPaymentModal(inv.supplierId, inv);
                                } else {
                                  setPaymentModalInvoice(inv);
                                  setPayAmountInput(inv.dueAmount);
                                }
                              }}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-md text-[11px] font-bold border border-emerald-200 transition-colors inline-flex items-center gap-1 shadow-2xs cursor-pointer"
                              title="Pay Due / Settle Payment"
                            >
                              <CreditCard className="w-3 h-3 text-emerald-600" />
                              <span>Pay</span>
                            </button>
                          )}

                          {/* View Supplier Ledger */}
                          {onOpenSupplierKhata && (
                            <button
                              type="button"
                              onClick={() => onOpenSupplierKhata(inv.supplierId)}
                              className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-md text-[11px] font-semibold border border-indigo-200 transition-colors inline-flex items-center gap-1 cursor-pointer"
                              title="View Supplier Ledger & Invoices"
                            >
                              <FileText className="w-3 h-3 text-indigo-600" />
                              <span>Ledger</span>
                            </button>
                          )}

                          {/* Edit Invoice */}
                          <button
                            type="button"
                            onClick={() => setEditingInvoice(inv)}
                            className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-md text-[11px] font-semibold transition-colors cursor-pointer inline-flex items-center gap-1 border border-blue-200"
                            title="Edit Purchase Invoice"
                          >
                            <Edit className="w-3 h-3 text-blue-600" />
                            <span>Edit</span>
                          </button>

                          {/* View & Print Invoice */}
                          <button
                            type="button"
                            onClick={() => setViewInvoiceSlip(inv)}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-[11px] font-semibold transition-colors cursor-pointer inline-flex items-center gap-1.5 border border-slate-200"
                            title="View and print purchase invoice"
                          >
                            <Printer className="w-3 h-3 text-slate-600" />
                            <span>Print</span>
                          </button>

                          {/* Delete Invoice */}
                          <button
                            type="button"
                            onClick={() => setDeletingInvoice(inv)}
                            className="p-1.5 rounded-md hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer border border-transparent hover:border-rose-200"
                            title="Move to Recycle Bin / Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Bottom Quick Supplier Payments Preview (Sales module parity) */}
        <div className="border-t border-slate-200 bg-slate-50/70 p-3.5">
          <div className="flex items-center justify-between mb-2.5 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                Recent Supplier Payments
              </span>
              <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-bold">
                {recentPayments.length} Payments
              </span>
            </div>
            <div className="flex items-center gap-2">
              {onOpenPaymentModal && (
                <button
                  type="button"
                  onClick={() => onOpenPaymentModal()}
                  className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>+ Make New Payment</span>
                </button>
              )}
              {onNavigateToPayments && (
                <button
                  type="button"
                  onClick={onNavigateToPayments}
                  className="text-xs font-semibold text-blue-700 hover:text-blue-800 flex items-center gap-1 hover:underline ml-1 cursor-pointer"
                >
                  View all in Supplier Payments →
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
            {recentPayments.slice(0, 4).map((pay) => (
              <div key={pay.id} className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs space-y-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-slate-800">{pay.voucherNumber || pay.paymentNumber}</span>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded">
                    ৳{pay.amount.toLocaleString()}
                  </span>
                </div>
                <div className="text-[11px] text-slate-600 truncate font-semibold">
                  {pay.supplierName}
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span>{pay.paymentMethod}</span>
                  <span>{pay.paymentDate}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ===================== MODAL: CREATE DIRECT PURCHASE INVOICE ===================== */}
      {showCreateModal && (
        <ModalWrapper
          isOpen={showCreateModal}
          onClose={handleCloseCreateModal}
          isDirty={Boolean(
            selectedSupplierId ||
            challanNo ||
            supplierBillNo ||
            selectedItemId ||
            qty > 0 ||
            unitRate > 0 ||
            discountAmount > 0 ||
            paidAmount > 0
          )}
          backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto border border-slate-200 animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-4 bg-slate-900 text-white rounded-t-2xl flex items-center justify-between sticky top-0 z-10 shrink-0">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-indigo-600 rounded-lg">
                  <Receipt className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">
                    Create Direct Purchase Invoice
                  </h3>
                </div>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={handleCloseCreateModal}
                className="text-slate-400 hover:text-white font-bold text-sm cursor-pointer p-1 shrink-0"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitInvoice} autoComplete="off" className="p-5 space-y-4 text-xs text-slate-700">
              {/* Auto Generated Purchase Invoice Number Bar */}
              <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <span className="text-[10px] font-mono text-slate-500 font-bold uppercase block">
                    PURCHASE INVOICE NO:
                  </span>
                  <span className="font-mono font-black text-slate-900 text-sm">
                    {`DPI-2026-0${126 + invoices.length}`}
                  </span>
                </div>
                <span className="text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-0.5 rounded-full">
                  Auto System Generated
                </span>
              </div>

              {/* Row 1: Supplier & Challan */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-semibold text-slate-800">
                      Select Supplier / Vendor *
                    </label>
                    {onOpenAddSupplierModal && (
                      <button
                        type="button"
                        onClick={onOpenAddSupplierModal}
                        className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                        title="Add new supplier"
                      >
                        <Plus className="w-3 h-3 text-indigo-600" />
                        <span>+ New Supplier</span>
                      </button>
                    )}
                  </div>
                  <select
                    value={selectedSupplierId}
                    onChange={(e) => setSelectedSupplierId(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 bg-white text-slate-900 font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  >
                    <option value="">-- Select Supplier / Vendor --</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.country} • {s.category}{s.companyOwner ? ` • 👤 ${s.companyOwner}` : ''})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Delivery Challan No *
                  </label>
                  <input
                    type="text"
                    value={challanNo}
                    onChange={(e) => setChallanNo(e.target.value)}
                    placeholder="e.g. CH-PORT-88910"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              {/* Row 2: Supplier Bill No & Warehouse */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Supplier Bill / Cash Memo No
                  </label>
                  <input
                    type="text"
                    value={supplierBillNo}
                    onChange={(e) => setSupplierBillNo(e.target.value)}
                    placeholder="e.g. BILL-2026-9021"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Receiving Warehouse / Stock Yard *
                  </label>
                  <select
                    value={warehouseName}
                    onChange={(e) => setWarehouseName(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 bg-white text-slate-900 font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  >
                    <option value="">-- Select Receiving Warehouse / Stock Yard --</option>
                    <option value="Chittagong Port Bonded Yard">Chittagong Port Bonded Yard</option>
                    <option value="Burimari Land Port Unit">Burimari Land Port Unit (Stone & Coal)</option>
                    <option value="Tejgaon Central Depot">Tejgaon Central Depot (Dhaka)</option>
                    <option value="Bogra Regional Depot">Bogra Northern Regional Depot</option>
                  </select>
                </div>
              </div>

              {/* Row 3: Invoice Date & Payment Due Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Invoice Date *
                  </label>
                  <input
                    type="date"
                    value={invDate}
                    onChange={(e) => handleInvoiceDateChange(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 mb-1 flex items-center justify-between">
                    <span>Payment Due Date *</span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {paymentType === 'Cash Only' ? 'Same Day' : paymentType === 'Payment 10 Days' ? '+10 Days' : '+30 Days Term'}
                    </span>
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              {/* Row 4: Item Selection & Pricing */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <span className="font-bold text-slate-900 text-xs block flex items-center gap-1.5">
                  <PackageCheck className="w-4 h-4 text-indigo-600" />
                  <span>Purchased Item & Rate Details</span>
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div className="sm:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">Item / Commodity</label>
                    <select
                      value={selectedItemId}
                      onChange={(e) => {
                        setSelectedItemId(e.target.value);
                        const match = availableItems.find(i => i.id === e.target.value);
                        if (match) {
                          setUnitRate(match.avgUnitCost || 3500);
                          if (match.uom) setSelectedUom(match.uom);
                        }
                      }}
                      className="w-full border border-slate-300 rounded-xl p-2 bg-white text-slate-900 font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none text-xs"
                    >
                      <option value="">-- Select Item / Commodity --</option>
                      {availableItems
                        .filter(i => (i.status || 'Active') === 'Active')
                        .map(i => (
                          <option key={i.id} value={i.id}>
                            {i.name} ({i.uom || 'MT'})
                          </option>
                        ))}
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-semibold text-slate-700">UOM</label>
                      <button
                        type="button"
                        onClick={() => setShowNewUomPrompt(!showNewUomPrompt)}
                        className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-1.5 py-0.5 rounded cursor-pointer"
                      >
                        + New
                      </button>
                    </div>

                    {showNewUomPrompt && (
                      <div className="mb-2 p-1.5 bg-indigo-50 border border-indigo-200 rounded-lg flex items-center gap-1 animate-in fade-in">
                        <input
                          type="text"
                          autoFocus
                          placeholder="New UOM..."
                          value={newUomInput}
                          onChange={(e) => setNewUomInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              if (newUomInput.trim()) {
                                addUOM(newUomInput.trim());
                                setSelectedUom(newUomInput.trim());
                                setNewUomInput('');
                                setShowNewUomPrompt(false);
                              }
                            }
                          }}
                          className="flex-1 p-1 bg-white border border-indigo-300 rounded text-xs font-semibold outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (newUomInput.trim()) {
                              addUOM(newUomInput.trim());
                              setSelectedUom(newUomInput.trim());
                              setNewUomInput('');
                              setShowNewUomPrompt(false);
                            }
                          }}
                          className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-bold cursor-pointer"
                        >
                          Save
                        </button>
                      </div>
                    )}

                    <select
                      value={selectedUom}
                      onChange={(e) => {
                        if (e.target.value === '__add_new__') {
                          setShowNewUomPrompt(true);
                        } else {
                          setSelectedUom(e.target.value);
                        }
                      }}
                      className="w-full border border-slate-300 rounded-xl p-2 bg-white text-slate-900 font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none text-xs font-mono"
                    >
                      <option value="">Select UOM...</option>
                      {availableUoms.map(u => (
                        <option key={u} value={u}>{u}</option>
                      ))}
                      <option value="__add_new__">+ New UOM...</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Quantity ({selectedUom || 'UOM'})</label>
                    <input
                      type="number"
                      value={qty || ''}
                      onChange={(e) => setQty(Math.max(0, Number(e.target.value)))}
                      min={1}
                      className="w-full border border-slate-300 rounded-xl p-2 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-xs"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Unit Rate (BDT)</label>
                    <input
                      type="number"
                      value={unitRate || ''}
                      onChange={(e) => setUnitRate(Math.max(0, Number(e.target.value)))}
                      min={0}
                      className="w-full border border-slate-300 rounded-xl p-2 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-xs"
                      required
                    />
                  </div>
                </div>

                {/* Subtotal, VAT & Discount */}
                <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-200">
                  <div>
                    <label className="block font-medium text-slate-600 mb-1">Subtotal:</label>
                    <div className="font-mono font-bold text-slate-800 text-xs py-1.5 px-2 bg-white rounded-lg border border-slate-200">
                      ৳ {itemSubtotal.toLocaleString()}
                    </div>
                  </div>

                  <div>
                    <label className="block font-medium text-slate-600 mb-1">VAT / Tax (%):</label>
                    <select
                      value={taxVatRate}
                      onChange={(e) => setTaxVatRate(Number(e.target.value))}
                      className="w-full border border-slate-300 rounded-lg p-1.5 bg-white font-mono text-slate-900"
                    >
                      <option value={0}>0% (Tax Exempt / Nil)</option>
                      <option value={5}>5% Standard VAT</option>
                      <option value={7.5}>7.5% Port AIT/VAT</option>
                      <option value={15}>15% Standard</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium text-slate-600 mb-1">Discount:</label>
                    <input
                      type="number"
                      value={discountAmount || ''}
                      onChange={(e) => setDiscountAmount(Math.max(0, Number(e.target.value)))}
                      className="w-full border border-slate-300 rounded-lg p-1.5 font-mono text-slate-900"
                    />
                  </div>
                </div>
              </div>

              {/* Row 5: Payment Type & Terms (Sales Invoice Parity - Default Due 30 Days) */}
              <div className="p-3.5 bg-slate-50/90 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-1">
                  <span className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    <span>Payment Type & Terms *</span>
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    paymentType === 'Cash Only'
                      ? 'bg-emerald-100 text-emerald-800'
                      : paymentType === 'Payment 10 Days'
                        ? 'bg-blue-100 text-blue-800'
                        : paymentType === 'Partial Payment'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                  }`}>
                    {paymentType === 'Due 30 Days' && '⚠️ Default: 30 Days Credit'}
                    {paymentType === 'Cash Only' && '✓ 100% Cash Settlement'}
                    {paymentType === 'Payment 10 Days' && '⏳ 10 Days Credit Term'}
                    {paymentType === 'Partial Payment' && '⏳ Partial Payment & Due'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Payment Type Selection (Default Due 30 Days) */}
                  <div>
                    <label className="block font-semibold text-slate-800 mb-1">
                      Payment Type *
                    </label>
                    <select
                      value={paymentType}
                      onChange={(e) => handlePaymentTypeChange(e.target.value as PurchaseInvoiceTypeOption)}
                      className="w-full border border-indigo-300 rounded-xl p-2.5 bg-white text-indigo-950 font-bold focus:ring-2 focus:ring-indigo-500 focus:outline-none shadow-2xs"
                    >
                      <option value="Due 30 Days">Due 30 Days</option>
                      <option value="Cash Only">Cash Only</option>
                      <option value="Payment 10 Days">Payment 10 Days</option>
                      <option value="Partial Payment">Partial Payment</option>
                    </select>
                  </div>

                  {/* Payment Method */}
                  <div>
                    <label className="block font-semibold text-slate-800 mb-1">
                      Payment Method
                    </label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => handlePaymentMethodChange(e.target.value as any)}
                      className="w-full border border-slate-300 rounded-xl p-2.5 bg-white text-slate-900 font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    >
                      <option value="">-- Select Payment Method --</option>
                      <option value="Credit">Credit</option>
                      <option value="Cash">Cash</option>
                      <option value="Bank Transfer / Cheque">Bank Transfer / Cheque</option>
                      <option value="LC Settlement">LC Margin / Settlement</option>
                    </select>
                  </div>

                  {/* Paid Amount */}
                  <div>
                    <label className="block font-semibold text-slate-800 mb-1 flex items-center justify-between">
                      <span>Paid Amount</span>
                      {paymentType === 'Cash Only' && (
                        <span className="text-[10px] text-emerald-600 font-bold">100% Paid</span>
                      )}
                    </label>
                    <input
                      type="number"
                      value={actualPaidAmount || ''}
                      disabled={paymentType === 'Cash Only'}
                      onChange={(e) => setPaidAmount(Math.min(grandTotal, Math.max(0, Number(e.target.value))))}
                      className={`w-full border rounded-xl p-2.5 font-mono font-bold text-base focus:ring-2 focus:ring-indigo-500 focus:outline-none ${
                        paymentType === 'Cash Only'
                          ? 'border-emerald-300 bg-emerald-50 text-emerald-800 cursor-not-allowed'
                          : 'border-slate-300 bg-white text-emerald-700'
                      }`}
                    />
                  </div>
                </div>

                {/* Required "Paid From" Account when actualPaidAmount > 0 */}
                {actualPaidAmount > 0 && (
                  <div className="pt-2 border-t border-slate-200 space-y-2.5">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-bold text-slate-800 text-xs">
                          Paid From ({paymentMethod === 'Cash' || paymentType === 'Cash Only' ? 'Cash Account' : 'Bank / Cash Account'}) <span className="text-rose-500">*</span>
                        </label>
                        {selectedPaidFromAccount && (
                          <span className={`text-[11px] font-mono font-bold ${
                            (selectedPaidFromAccount.ledgerBalance || 0) < actualPaidAmount ? 'text-rose-600' : 'text-emerald-700'
                          }`}>
                            Balance: BDT {(selectedPaidFromAccount.ledgerBalance || 0).toLocaleString()}
                          </span>
                        )}
                      </div>
                      <select
                        value={paidFromAccountId}
                        onChange={(e) => setPaidFromAccountId(e.target.value)}
                        required
                        className="w-full border border-slate-300 rounded-xl p-2.5 bg-white text-slate-900 font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none text-xs"
                      >
                        <option value="">-- Select Cash / Bank Account --</option>
                        {filteredPaidFromAccounts.map(acc => (
                          <option key={acc.id} value={acc.id}>
                            {acc.bankName} ({acc.accountNumber}) — Bal: BDT {(acc.ledgerBalance || 0).toLocaleString()}
                          </option>
                        ))}
                      </select>
                    </div>

                    {selectedPaidFromAccount && (selectedPaidFromAccount.ledgerBalance || 0) - actualPaidAmount < 0 && (
                      isCashAccount(selectedPaidFromAccount) ? (
                        <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-[11px] text-rose-800 font-semibold flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                          <span>
                            Cash account balance cannot become negative (Shortfall: BDT {Math.abs((selectedPaidFromAccount.ledgerBalance || 0) - actualPaidAmount).toLocaleString()}).
                          </span>
                        </div>
                      ) : (
                        <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 space-y-1.5">
                          <div className="font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                            <span>
                              Bank Overdraft Warning: Post-payment balance will be -BDT {Math.abs((selectedPaidFromAccount.ledgerBalance || 0) - actualPaidAmount).toLocaleString()}
                            </span>
                          </div>
                          {isAdmin ? (
                            <label className="flex items-center gap-2 cursor-pointer font-semibold text-amber-950">
                              <input
                                type="checkbox"
                                checked={adminApprovedOverdraft}
                                onChange={(e) => setAdminApprovedOverdraft(e.target.checked)}
                                className="rounded border-amber-400 text-indigo-600 focus:ring-indigo-500"
                              />
                              <span>Admin Overdraft Approval: Authorize negative bank balance</span>
                            </label>
                          ) : (
                            <p className="text-rose-700 font-semibold">
                              Only an Administrator can approve a bank overdraft.
                            </p>
                          )}
                        </div>
                      )
                    )}
                  </div>
                )}
              </div>

              {/* Row 6: Link to Import LC & Transport */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Link to Import LC
                  </label>
                  <select
                    value={linkedLcNumber}
                    onChange={(e) => setLinkedLcNumber(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 bg-white text-slate-900 font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="">None (Direct Spot Local Procurement)</option>
                    {lcs.map(l => (
                      <option key={l.id} value={l.lcNumber}>
                        {l.lcNumber} - ${l.cfrAmount.toLocaleString()} ({l.beneficiaryCountry})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Truck / Vehicle No
                  </label>
                  <input
                    type="text"
                    value={truckNo}
                    onChange={(e) => setTruckNo(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Final Calculation Summary Card */}
              <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-semibold">Subtotal:</span>
                  <span className="font-mono font-bold text-slate-900">৳ {itemSubtotal.toLocaleString()}</span>
                </div>
                {calculatedTax > 0 && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600">VAT ({taxVatRate}%):</span>
                    <span className="font-mono text-slate-700">+ ৳ {calculatedTax.toLocaleString()}</span>
                  </div>
                )}
                {discountAmount > 0 && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-emerald-700">Discount:</span>
                    <span className="font-mono text-emerald-700">- ৳ {discountAmount.toLocaleString()}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-indigo-200 flex items-center justify-between font-bold text-sm">
                  <span className="text-indigo-950">Grand Total Invoice:</span>
                  <span className="font-mono text-indigo-900 text-base">৳ {grandTotal.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-xs pt-1 font-semibold">
                  <span className="text-emerald-700">Amount Paid Now:</span>
                  <span className="font-mono text-emerald-700">৳ {paidAmount.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className={dueAmount > 0 ? 'text-rose-700' : 'text-slate-500'}>Remaining Due:</span>
                  <span className={`font-mono ${dueAmount > 0 ? 'text-rose-700' : 'text-slate-500'}`}>
                    ৳ {dueAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Auto Stock Inward Notice */}
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-900 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>Auto Stock &amp; Accounting Entry:</strong> Creating this invoice will post <strong>{qty} {selectedUom}</strong> into stock and record Dr Inventory (13100) / Cr Accounts Payable (21100){actualPaidAmount > 0 ? ' plus a Payment Voucher' : ''}.
                </span>
              </div>

              {submitError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{submitError}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  disabled={isSubmitting}
                  data-modal-close="true"
                  onClick={handleCloseCreateModal}
                  className="px-4 py-2.5 border border-slate-300 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition-colors cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white rounded-xl font-bold transition-all shadow-xs hover:shadow flex items-center gap-1.5 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Posting Vouchers...</span>
                    </>
                  ) : (
                    <>
                      <Receipt className="w-4 h-4" />
                      <span>Generate Purchase Invoice</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* ===================== MODAL: VIEW / PRINT PURCHASE INVOICE ===================== */}
      {viewInvoiceSlip && (
        <PrintablePurchaseInvoiceModal
          invoice={viewInvoiceSlip}
          supplier={suppliers.find(s => s.id === viewInvoiceSlip.supplierId || s.name === viewInvoiceSlip.supplierName)}
          onClose={() => setViewInvoiceSlip(null)}
          onPaymentCollect={(inv) => {
            if (onOpenPaymentModal) {
              onOpenPaymentModal(inv.supplierId, inv);
            } else {
              setPaymentModalInvoice(inv);
              setPayAmountInput(inv.dueAmount);
            }
            setViewInvoiceSlip(null);
          }}
        />
      )}

      {/* ===================== MODAL: RECORD PAYMENT ===================== */}
      {paymentModalInvoice && (
        <ModalWrapper
          isOpen={!!paymentModalInvoice}
          onClose={() => setPaymentModalInvoice(null)}
          isDirty={payAmountInput !== paymentModalInvoice.dueAmount || paymentNote !== ''}
          backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-5 border border-slate-200 animate-in fade-in zoom-in-95 text-xs text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3 shrink-0">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-sm text-slate-900">
                  Record Supplier Due Payment
                </h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setPaymentModalInvoice(null)}
                className="text-slate-400 hover:text-slate-600 font-bold p-1 cursor-pointer shrink-0"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRecordPayment} autoComplete="off" className="space-y-3">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-600">Invoice Number:</span>
                  <span className="font-mono text-indigo-700">{paymentModalInvoice.invoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Supplier:</span>
                  <span className="font-semibold text-slate-900">{paymentModalInvoice.supplierName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Total Bill:</span>
                  <span className="font-mono">{paymentModalInvoice.currency} {paymentModalInvoice.grandTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold text-rose-700 pt-1 border-t border-slate-200">
                  <span>Current Due:</span>
                  <span className="font-mono">{paymentModalInvoice.currency} {paymentModalInvoice.dueAmount.toLocaleString()}</span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Payment Amount to Pay ({paymentModalInvoice.currency}) *
                </label>
                <input
                  type="number"
                  value={payAmountInput || ''}
                  onChange={(e) => setPayAmountInput(Math.min(paymentModalInvoice.dueAmount, Math.max(0, Number(e.target.value))))}
                  max={paymentModalInvoice.dueAmount}
                  min={1}
                  className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-base text-emerald-700 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Payment Method *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Bank Transfer', 'Cheque', 'Cash'] as const).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setInlinePayMethod(m)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border cursor-pointer ${
                        inlinePayMethod === m
                          ? 'bg-emerald-600 text-white border-emerald-700'
                          : 'bg-slate-50 text-slate-700 border-slate-200'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700">
                    Paid From ({inlinePayMethod === 'Cash' ? 'Cash Account' : 'Bank Account'}) *
                  </label>
                  {selectedInlineAccount && (
                    <span className="font-mono text-[11px] font-bold text-emerald-700">
                      Bal: BDT {(selectedInlineAccount.ledgerBalance || 0).toLocaleString()}
                    </span>
                  )}
                </div>
                <select
                  value={inlinePaidFromAccountId}
                  onChange={(e) => setInlinePaidFromAccountId(e.target.value)}
                  required
                  className="w-full border border-slate-300 rounded-xl p-2 bg-white text-slate-900 font-semibold"
                >
                  <option value="">-- Select Cash / Bank Account --</option>
                  {filteredInlineAccounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.bankName} ({acc.accountNumber}) — Bal: BDT {(acc.ledgerBalance || 0).toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              {selectedInlineAccount && (selectedInlineAccount.ledgerBalance || 0) - payAmountInput < 0 && !isCashAccount(selectedInlineAccount) && isAdmin && (
                <label className="flex items-center gap-2 p-2 bg-amber-50 border border-amber-200 rounded-lg text-[11px] font-semibold text-amber-900 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={inlineAdminOverdraft}
                    onChange={(e) => setInlineAdminOverdraft(e.target.checked)}
                  />
                  <span>Admin Overdraft Approval: Authorize negative bank balance</span>
                </label>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Payment Reference / Cheque No / Notes
                </label>
                <input
                  type="text"
                  value={paymentNote}
                  onChange={(e) => setPaymentNote(e.target.value)}
                  placeholder="e.g. City Bank Cheque #99102"
                  className="w-full border border-slate-300 rounded-xl p-2 font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {inlinePayError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-[11px] font-semibold">
                  {inlinePayError}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  disabled={isInlinePaying}
                  data-modal-close="true"
                  onClick={() => setPaymentModalInvoice(null)}
                  className="px-3.5 py-2 border border-slate-300 rounded-lg font-semibold hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isInlinePaying}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white rounded-lg font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  {isInlinePaying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                  <span>Confirm Payment</span>
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* Edit Purchase Invoice Modal */}
      {editingInvoice && (
        <EditPurchaseInvoiceModal
          isOpen={!!editingInvoice}
          invoice={editingInvoice}
          suppliers={suppliers}
          onClose={() => setEditingInvoice(null)}
          onSave={(updated) => {
            onUpdateInvoice(updated);
            setEditingInvoice(null);
          }}
        />
      )}

      {/* Delete Confirmation Modal with Soft Delete Notice */}
      {deletingInvoice && (
        <DeleteConfirmModal
          isOpen={!!deletingInvoice}
          title="Purchase Invoice"
          referenceNumber={deletingInvoice.invoiceNumber}
          partyName={deletingInvoice.supplierName}
          amount={deletingInvoice.grandTotal}
          onClose={() => setDeletingInvoice(null)}
          onConfirm={handleConfirmDelete}
        />
      )}

      {/* Module Recycle Bin & Restore Hub */}
      <RecycleBinModal
        isOpen={isRecycleBinOpen}
        initialType="purchase_invoice"
        onClose={() => setIsRecycleBinOpen(false)}
      />
    </div>
  );
};
