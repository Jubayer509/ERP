import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  User, 
  Search, 
  Filter, 
  Printer, 
  Download, 
  Ship, 
  Layers, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  MapPin,
  Calendar,
  Sparkles,
  Coins,
  ShieldCheck
} from 'lucide-react';
import { LetterOfCredit, Supplier } from '../../types/erp';
import { computeLcBill } from '../../utils/lcBillingHelper';

interface CompanyOwnerLcReportProps {
  lcs: LetterOfCredit[];
  suppliers: Supplier[];
  onSelectLc?: (lc: LetterOfCredit) => void;
  onOpenExpenses?: (lc: LetterOfCredit) => void;
  onOpenBills?: (lc: LetterOfCredit) => void;
}

export const CompanyOwnerLcReport: React.FC<CompanyOwnerLcReportProps> = ({
  lcs,
  suppliers,
  onSelectLc,
  onOpenExpenses,
  onOpenBills
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOwnerFilter, setSelectedOwnerFilter] = useState<string>('ALL');
  const [selectedPortFilter, setSelectedPortFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [expandedOwners, setExpandedOwners] = useState<Record<string, boolean>>({});

  // Toggle expansion of an owner's section
  const toggleOwner = (owner: string) => {
    setExpandedOwners(prev => ({
      ...prev,
      [owner]: !prev[owner]
    }));
  };

  // Group LCs by Company Owner
  const ownerGroups = useMemo(() => {
    const groups: Record<string, {
      ownerName: string;
      lcs: LetterOfCredit[];
      companies: Set<string>;
      totalCfrUSD: number;
      totalReceivedMt: number;
      totalLcs: number;
      totalBillUsd: number;
      totalDueUsd: number;
    }> = {};

    lcs.forEach(lc => {
      if (lc.status === 'Cancelled' || lc.isCancelled) return;
      // Find matching owner from LC or associated supplier
      let owner = lc.companyOwner;
      if (!owner) {
        const supp = suppliers.find(s => s.id === lc.supplierId || s.name === lc.supplierName);
        owner = supp?.companyOwner || 'Independent / Unassigned Exporter';
      }

      if (!groups[owner]) {
        groups[owner] = {
          ownerName: owner,
          lcs: [],
          companies: new Set(),
          totalCfrUSD: 0,
          totalReceivedMt: 0,
          totalLcs: 0,
          totalBillUsd: 0,
          totalDueUsd: 0
        };
      }

      const lcBill = computeLcBill(lc);
      groups[owner].lcs.push(lc);
      groups[owner].companies.add(lc.supplierName);
      groups[owner].totalCfrUSD += lcBill.officialBillForeign;
      groups[owner].totalReceivedMt += lcBill.receivedQty;
      groups[owner].totalLcs += 1;
      groups[owner].totalBillUsd += lcBill.commercialBillForeign;
      const balance = lcBill.remainingBankDueForeign + lcBill.remainingHundiDueForeign;
      if (balance > 0) {
        groups[owner].totalDueUsd += balance;
      }
    });

    return groups;
  }, [lcs, suppliers]);

  const allOwnerNames = useMemo(() => Object.keys(ownerGroups).sort(), [ownerGroups]);

  // Filter groups according to filters
  const filteredOwnerList = useMemo(() => {
    return allOwnerNames.filter(ownerName => {
      if (selectedOwnerFilter !== 'ALL' && ownerName !== selectedOwnerFilter) {
        return false;
      }

      const group = ownerGroups[ownerName];
      const matchesSearch = 
        ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        Array.from(group.companies).some(c => c.toLowerCase().includes(searchTerm.toLowerCase())) ||
        group.lcs.some(l => 
          l.lcNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (l.originQuarryItem || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
          (l.borderLandPort || '').toLowerCase().includes(searchTerm.toLowerCase())
        );

      if (!matchesSearch) return false;

      if (selectedPortFilter !== 'ALL') {
        const hasPort = group.lcs.some(l => (l.borderLandPort || 'Burimari') === selectedPortFilter);
        if (!hasPort) return false;
      }

      if (selectedStatusFilter !== 'ALL') {
        const hasStatus = group.lcs.some(l => l.status === selectedStatusFilter);
        if (!hasStatus) return false;
      }

      return true;
    });
  }, [allOwnerNames, ownerGroups, selectedOwnerFilter, selectedPortFilter, selectedStatusFilter, searchTerm]);

  // Summary Metrics
  const summaryTotals = useMemo(() => {
    let grandUSD = 0;
    let grandMT = 0;
    let grandLCs = 0;
    const allCompaniesSet = new Set<string>();

    filteredOwnerList.forEach(ownerName => {
      const g = ownerGroups[ownerName];
      grandUSD += g.totalCfrUSD;
      grandMT += g.totalReceivedMt;
      grandLCs += g.totalLcs;
      g.companies.forEach(c => allCompaniesSet.add(c));
    });

    return {
      totalOwners: filteredOwnerList.length,
      totalCompanies: allCompaniesSet.size,
      grandUSD,
      grandMT,
      grandLCs
    };
  }, [filteredOwnerList, ownerGroups]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-150">
      {/* Top Banner & Info */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 sm:p-6 rounded-3xl shadow-sm border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="p-1.5 bg-amber-400/20 text-amber-300 rounded-xl">
                <User className="w-5 h-5" />
              </span>
              <h2 className="text-lg sm:text-xl font-black tracking-tight text-white">
                Company Owner Wise LC Report
              </h2>
              <span className="text-[10px] font-bold uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Multi-Company Hub
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border border-white/20 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-amber-400" />
              <span>Print Owner Report</span>
            </button>
          </div>
        </div>

        {/* 4 Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-800/80">
          <div className="bg-white/5 border border-white/10 p-3 rounded-2xl">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Exporter Owners</span>
            <span className="text-xl font-black font-mono text-amber-400 mt-1 block">
              {summaryTotals.totalOwners}
            </span>
          </div>

          <div className="bg-white/5 border border-white/10 p-3 rounded-2xl">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Export Companies Owned</span>
            <span className="text-xl font-black font-mono text-white mt-1 block">
              {summaryTotals.totalCompanies} Companies
            </span>
          </div>

          <div className="bg-white/5 border border-white/10 p-3 rounded-2xl">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total LCs</span>
            <span className="text-xl font-black font-mono text-cyan-400 mt-1 block">
              {summaryTotals.grandLCs}
            </span>
          </div>

          <div className="bg-white/5 border border-white/10 p-3 rounded-2xl">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total LC Value (USD)</span>
            <span className="text-xl font-black font-mono text-emerald-400 mt-1 block">
              ${summaryTotals.grandUSD.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Owner Filter */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">Select Exporter Owner:</label>
            <select
              value={selectedOwnerFilter}
              onChange={(e) => setSelectedOwnerFilter(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:bg-white outline-none"
            >
              <option value="ALL">All Owners ({allOwnerNames.length})</option>
              {allOwnerNames.map(owner => (
                <option key={owner} value={owner}>
                  👤 {owner} ({ownerGroups[owner]?.companies.size} Companies, {ownerGroups[owner]?.lcs.length} LCs)
                </option>
              ))}
            </select>
          </div>

          {/* Port Filter */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">Border Port:</label>
            <select
              value={selectedPortFilter}
              onChange={(e) => setSelectedPortFilter(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-800 focus:bg-white outline-none"
            >
              <option value="ALL">All Border Ports</option>
              <option value="Burimari">📍 Burimari Land Port</option>
              <option value="Sonahat">📍 Sonahat Land Port</option>
              <option value="Banglabandha">📍 Banglabandha Land Port</option>
            </select>
          </div>

          {/* LC Status Filter */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">LC Status:</label>
            <select
              value={selectedStatusFilter}
              onChange={(e) => setSelectedStatusFilter(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-800 focus:bg-white outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="Confirmed">Confirmed</option>
              <option value="Shipment In-Transit">Shipment In-Transit</option>
              <option value="Customs Cleared">Customs Cleared</option>
              <option value="Costed & Closed">Costed & Closed</option>
            </select>
          </div>

          {/* Search Query */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">Search LC / Item / Firm:</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search LC #, firm, item..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-900 focus:bg-white outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Owner-Wise Groups List */}
      <div className="space-y-4">
        {filteredOwnerList.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-500 text-xs">
            No records found. Please adjust your filters or search.
          </div>
        ) : (
          filteredOwnerList.map(ownerName => {
            const group = ownerGroups[ownerName];
            const isExpanded = expandedOwners[ownerName] ?? true; // expanded by default
            const companiesList = Array.from(group.companies);

            return (
              <div 
                key={ownerName} 
                className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs overflow-hidden transition-all"
              >
                {/* Owner Header Capsule */}
                <div 
                  onClick={() => toggleOwner(ownerName)}
                  className="p-4 sm:p-5 bg-gradient-to-r from-slate-50 via-indigo-50/20 to-slate-50 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 cursor-pointer hover:bg-slate-100/60 transition-colors"
                >
                  <div className="flex items-start sm:items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white font-black text-sm flex items-center justify-center shrink-0 shadow-xs">
                      {ownerName.slice(0, 2).toUpperCase()}
                    </div>

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm sm:text-base font-black text-slate-900">
                          {ownerName}
                        </h3>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-900 font-mono">
                          {companiesList.length} Owned Companies
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-mono">
                          {group.totalLcs} LCs
                        </span>
                      </div>

                      {/* Owned Companies Chips */}
                      <div className="flex items-center gap-1.5 flex-wrap mt-1 text-slate-600 text-xs">
                        <span className="text-[11px] font-semibold text-slate-500">Owned Companies:</span>
                        {companiesList.map(comp => (
                          <span 
                            key={comp}
                            className="bg-white border border-slate-200 px-2 py-0.5 rounded-lg text-[10px] font-bold text-slate-800 shadow-2xs"
                          >
                            🏢 {comp}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Financials & Toggle */}
                  <div className="flex items-center gap-4 sm:gap-6 shrink-0 justify-between md:justify-end border-t md:border-t-0 pt-2 md:pt-0 border-slate-200">
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Total LC Value</span>
                      <span className="text-sm font-black font-mono text-emerald-700">
                        ${group.totalCfrUSD.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Import Volume</span>
                      <span className="text-sm font-black font-mono text-slate-900">
                        {group.totalReceivedMt.toLocaleString()} MT
                      </span>
                    </div>

                    <button 
                      type="button"
                      className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-600 hover:text-slate-900 transition-colors"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Expanded LCs Table */}
                {isExpanded && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-sans">
                      <thead className="bg-slate-50/80 text-slate-600 font-semibold border-b border-slate-200 text-[11px]">
                        <tr>
                          <th className="py-2.5 px-4">LC Number & Date</th>
                          <th className="py-2.5 px-3">Company / Beneficiary</th>
                          <th className="py-2.5 px-3">Commodity & Origin</th>
                          <th className="py-2.5 px-3">Port</th>
                          <th className="py-2.5 px-3">Bank & Rate</th>
                          <th className="py-2.5 px-3 text-right">Quantity</th>
                          <th className="py-2.5 px-3 text-right">CFR Value (USD)</th>
                          <th className="py-2.5 px-3 text-center">Status</th>
                          <th className="py-2.5 px-4 text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {group.lcs.map(lc => {
                          const rowBill = computeLcBill(lc);
                          const qty = rowBill.billableQty;
                          return (
                            <tr key={lc.id} className="hover:bg-indigo-50/30 transition-colors">
                              <td className="py-2.5 px-4 font-mono">
                                <div className="font-bold text-slate-900">{lc.lcNumber}</div>
                                <div className="text-[10px] text-slate-500 font-sans">{lc.openingDate}</div>
                              </td>

                              <td className="py-2.5 px-3">
                                <span className="font-bold text-slate-900 block truncate max-w-[200px]">
                                  {lc.supplierName}
                                </span>
                                <span className="text-[10px] text-slate-500">
                                  {lc.beneficiaryCountry || 'Bhutan'}
                                </span>
                              </td>

                              <td className="py-2.5 px-3">
                                <span className="font-medium text-slate-800 block truncate max-w-[180px]">
                                  {lc.originQuarryItem || lc.boulderCategory || 'Boulder Stone'}
                                </span>
                              </td>

                              <td className="py-2.5 px-3 font-medium text-slate-800">
                                <span className="inline-flex items-center gap-1">
                                  <MapPin className="w-3 h-3 text-slate-400" />
                                  <span>{lc.borderLandPort || 'Burimari'}</span>
                                </span>
                              </td>

                              <td className="py-2.5 px-3">
                                <div className="font-medium text-slate-800 truncate max-w-[140px]">{lc.issuingBank}</div>
                                <div className="text-[10px] text-slate-500 font-mono">
                                  Ex: ৳{rowBill.exchangeRate}
                                </div>
                              </td>

                              <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                                {qty.toLocaleString()} MT {rowBill.excessQty > 0 ? `(+${rowBill.excessQty} Excess)` : ''}
                              </td>

                              <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-800">
                                ${rowBill.officialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                              </td>

                              <td className="py-2.5 px-3 text-center">
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-mono ${
                                  lc.status === 'Costed & Closed' 
                                    ? 'bg-slate-100 text-slate-700' 
                                    : lc.status === 'Shipment In-Transit'
                                      ? 'bg-blue-100 text-blue-800'
                                      : 'bg-emerald-100 text-emerald-800'
                                }`}>
                                  {lc.status}
                                </span>
                              </td>

                              <td className="py-2.5 px-4 text-center">
                                <div className="flex items-center justify-center gap-1">
                                  {onSelectLc && (
                                    <button
                                      type="button"
                                      onClick={() => onSelectLc(lc)}
                                      className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                                      title="View LC Detail"
                                    >
                                      View
                                    </button>
                                  )}
                                  {onOpenBills && (
                                    <button
                                      type="button"
                                      onClick={() => onOpenBills(lc)}
                                      className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                                      title="Exporter Bills"
                                    >
                                      Bills
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
