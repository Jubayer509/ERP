import React, { useState, useMemo } from 'react';
import { 
  Ship, 
  Search, 
  Plus, 
  Filter, 
  Building2, 
  Calculator, 
  Receipt, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  FileText,
  DollarSign,
  AlertTriangle,
  Bell,
  User,
  Users,
  LayoutList,
  XCircle,
  Ban,
  ShieldAlert
} from 'lucide-react';
import { LetterOfCredit, LCStatus, LCType, Supplier, BankAccount } from '../../types/erp';
import { getDaysRemaining, getAlertSeverity } from '../../utils/lcAlertUtils';
import { CompanyOwnerLcReport } from './CompanyOwnerLcReport';
import { MarginReconciliationView } from './MarginReconciliationView';
import { useAuth } from '../../contexts/AuthContext';
import { computeLcBill } from '../../utils/lcBillingHelper';
import { computeExpectedLcMarginBDT } from '../../services/accountService';
import { ModalWrapper } from '../common/ModalWrapper';

interface LCRegisterViewProps {
  lcs: LetterOfCredit[];
  suppliers?: Supplier[];
  onSelectLc: (lc: LetterOfCredit) => void;
  onOpenExpenses: (lc: LetterOfCredit) => void;
  onOpenBills: (lc: LetterOfCredit) => void;
  onOpenCreateModal: () => void;
  onOpenAlertModal?: () => void;
  onOpenAmendment?: (lcId: string) => void;
  defaultExpiryFilter?: 'ALL' | 'CRITICAL' | 'UPCOMING';
  onPostMargin?: (lc: LetterOfCredit) => void;
  onCancelLc?: (lc: LetterOfCredit) => void;
  onOpenVoucher?: (voucherNo: string, transactionId?: string) => void;
  onCorrectByReversal?: (lc: LetterOfCredit, bankAccountId: string, reason: string) => Promise<any>;
  onVoidDuplicateLc?: (lc: LetterOfCredit, reason: string) => Promise<any>;
  onReverseVoucher?: (voucher: any, reason: string) => Promise<any>;
  bankAccounts?: BankAccount[];
}

export const LCRegisterView: React.FC<LCRegisterViewProps> = ({
  lcs,
  suppliers = [],
  onSelectLc,
  onOpenExpenses,
  onOpenBills,
  onOpenCreateModal,
  onOpenAlertModal,
  onOpenAmendment,
  defaultExpiryFilter = 'ALL',
  onPostMargin,
  onCancelLc,
  onOpenVoucher,
  onCorrectByReversal,
  onVoidDuplicateLc,
  onReverseVoucher,
  bankAccounts = []
}) => {
  const { currentUser } = useAuth();
  const isAdmin = Boolean(currentUser?.role === 'admin' || (currentUser as any)?.role === 'Admin' || (currentUser as any)?.role === 'SuperAdmin' || currentUser?.email?.includes('admin'));
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [ownerFilter, setOwnerFilter] = useState<string>('ALL');
  const [expiryFilter, setExpiryFilter] = useState<string>(defaultExpiryFilter);
  const [viewMode, setViewMode] = useState<'table' | 'owner_report' | 'margin_reconciliation'>('table');
  const [viewingDetailsLc, setViewingDetailsLc] = useState<LetterOfCredit | null>(null);

  // Requirement 5: Calculate issues count for reconciliation badge
  const reconciliationIssuesCount = useMemo(() => {
    const voucherCounts = new Map<string, number>();
    for (const lc of lcs) {
      const v = (lc.marginVoucherNo || '').trim();
      if (v) voucherCounts.set(v, (voucherCounts.get(v) || 0) + 1);
    }
    return lcs.filter(lc => {
      const v = (lc.marginVoucherNo || '').trim();
      if (!v) return false;
      const isDup = (voucherCounts.get(v) || 0) > 1;
      const storedAmt = lc.marginAmountBDT !== undefined ? lc.marginAmountBDT : (lc.marginAmountLocal ?? 0);
      const expectedAmt = computeExpectedLcMarginBDT(lc);
      return isDup || storedAmt !== expectedAmt;
    }).length;
  }, [lcs]);

  // Extract all unique company owners
  const uniqueOwners = useMemo(() => {
    const set = new Set<string>();
    lcs.forEach(l => {
      if (l.companyOwner && l.companyOwner.trim()) set.add(l.companyOwner.trim());
    });
    suppliers.forEach(s => {
      if (s.companyOwner && s.companyOwner.trim()) set.add(s.companyOwner.trim());
    });
    return Array.from(set).sort();
  }, [lcs, suppliers]);

  const filteredLcs = lcs.filter(lc => {
    const matchesSearch = 
      lc.lcNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lc.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lc.issuingBank.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (lc.companyOwner || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (lc.items[0]?.itemName || '').toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || lc.status === statusFilter;
    const matchesType = typeFilter === 'ALL' || lc.lcType === typeFilter;
    const matchesOwner = ownerFilter === 'ALL' || lc.companyOwner === ownerFilter;

    // Expiry filter logic
    let matchesExpiry = true;
    const shipDays = getDaysRemaining(lc.shipmentExpiryDate);
    const expDays = getDaysRemaining(lc.lcExpiryDate);
    const minDays = Math.min(shipDays, expDays);

    if (expiryFilter === 'CRITICAL') {
      matchesExpiry = minDays <= 7;
    } else if (expiryFilter === 'UPCOMING') {
      matchesExpiry = minDays <= 30;
    } else if (expiryFilter === 'EXPIRED') {
      matchesExpiry = minDays < 0;
    }

    return matchesSearch && matchesStatus && matchesType && matchesOwner && matchesExpiry;
  });

  // Exclude cancelled LCs from financial totals and KPI metrics (Requirement 3)
  const validLcs = lcs.filter(l => l.status !== 'Cancelled' && !l.isCancelled);
  const totalCfrUSD = validLcs.reduce((acc, curr) => acc + (curr.cfrAmount || 0), 0);
  const totalMarginBDT = validLcs.reduce((acc, curr) => acc + (curr.marginAmountLocal || 0), 0);
  const activeCount = validLcs.filter(l => l.status !== 'Costed & Closed').length;
  const inTransitCount = validLcs.filter(l => l.status === 'Shipment In-Transit' || l.status === 'Customs Cleared').length;

  // Count expiring LCs
  const criticalCount = validLcs.filter(lc => {
    const shipDays = getDaysRemaining(lc.shipmentExpiryDate);
    const expDays = getDaysRemaining(lc.lcExpiryDate);
    return Math.min(shipDays, expDays) <= 7;
  }).length;

  // Cancel LC eligibility check (Requirement 3)
  const canCancelLc = (lc: LetterOfCredit): { allowed: boolean; reason?: string } => {
    if (lc.status === 'Cancelled' || lc.isCancelled) {
      return { allowed: false, reason: 'This LC is already cancelled.' };
    }
    const activeBankSettlements = (lc.bankSettlements || []).filter(b => b.status !== 'Voided');
    if (activeBankSettlements.length > 0) {
      return { allowed: false, reason: 'Cannot cancel: Bank settlements exist.' };
    }
    const activeHundi = (lc.hundiPayments || []).filter(h => h.status !== 'Voided');
    if (activeHundi.length > 0) {
      return { allowed: false, reason: 'Cannot cancel: Hundi payments exist.' };
    }
    const hasReceivings = (lc.receivings && lc.receivings.length > 0) || (lc.receivedQuantity && lc.receivedQuantity > 0) || (lc.receivedQtyMt && lc.receivedQtyMt > 0);
    if (hasReceivings) {
      return { allowed: false, reason: 'Cannot cancel: Goods already received.' };
    }
    const otherPaidExpenses = (lc.expenses || []).filter(e => e.status === 'Paid' && e.voucherNo !== lc.marginVoucherNo);
    if (otherPaidExpenses.length > 0) {
      return { allowed: false, reason: 'Cannot cancel: Paid expenses exist.' };
    }
    return { allowed: true };
  };

  return (
    <div className="space-y-6">
      {/* 4 Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Total Active LCs
            </span>
            <Ship className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-1 font-mono">
            <span className="text-2xl font-black text-slate-900">{activeCount}</span>
            <span className="text-xs text-slate-500">/ {lcs.length} Total</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Live Documentary Credit Portfolios</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Total CFR Commitment
            </span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-1 font-mono">
            <span className="text-2xl font-black text-emerald-900">${(totalCfrUSD / 1000).toFixed(0)}k</span>
            <span className="text-xs text-emerald-700">USD</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1 font-mono">
            ৳{((totalCfrUSD * 118.5) / 1000000).toFixed(2)}M BDT Equiv
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Total Cash Margin Paid
            </span>
            <Building2 className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-1 font-mono">
            <span className="text-2xl font-black text-indigo-900">৳{(totalMarginBDT / 1000000).toFixed(2)}M</span>
            <span className="text-xs text-indigo-700">BDT</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Restricted Bank Margin Collateral</p>
        </div>

        <div 
          onClick={onOpenAlertModal}
          className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs cursor-pointer hover:border-amber-300 transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 font-semibold">
              Expiry Alerts (≤ 7 Days)
            </span>
            <Bell className={`w-4 h-4 ${criticalCount > 0 ? 'text-amber-600 animate-bounce' : 'text-slate-400'}`} />
          </div>
          <div className="mt-2 flex items-baseline gap-1 font-mono">
            <span className={`text-2xl font-black ${criticalCount > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {criticalCount}
            </span>
            <span className="text-xs text-slate-500">Critical Instruments</span>
          </div>
          <p className="text-[11px] text-amber-700 mt-1 group-hover:underline flex items-center gap-1">
            <span>Review Expiry Alert Center</span>
            <span>→</span>
          </p>
        </div>
      </div>

      {/* Main Register Table Card */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        {/* Table Toolbar */}
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            {/* View Mode Switch */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-xl text-xs font-semibold">
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'table' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <LayoutList className="w-3.5 h-3.5" />
                <span>LC List</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('owner_report')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'owner_report' ? 'bg-indigo-600 text-white shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Owner Wise Report</span>
              </button>
              {isAdmin && (
                <button
                  type="button"
                  onClick={() => setViewMode('margin_reconciliation')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                    viewMode === 'margin_reconciliation' ? 'bg-amber-600 text-white shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Margin Reconciliation</span>
                  {reconciliationIssuesCount > 0 && (
                    <span className="px-1.5 py-0.2 bg-rose-500 text-white text-[10px] rounded-full font-bold">
                      {reconciliationIssuesCount}
                    </span>
                  )}
                </button>
              )}
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search LC #, owner, supplier..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 w-44 sm:w-52"
              />
            </div>

            {/* Company Owner Filter */}
            <select
              value={ownerFilter}
              onChange={(e) => setOwnerFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
              title="Filter by Exporter Owner"
            >
              <option value="ALL">All Exporter Owners</option>
              {uniqueOwners.map(owner => (
                <option key={owner} value={owner}>
                  👤 {owner}
                </option>
              ))}
            </select>

            <select
              value={expiryFilter}
              onChange={(e) => setExpiryFilter(e.target.value)}
              className={`px-2.5 py-1.5 border rounded-xl text-xs font-bold focus:outline-none ${
                expiryFilter === 'CRITICAL' 
                  ? 'bg-rose-50 text-rose-800 border-rose-300' 
                  : expiryFilter === 'UPCOMING'
                  ? 'bg-amber-50 text-amber-900 border-amber-300'
                  : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              <option value="ALL">All Expiry Windows</option>
              <option value="CRITICAL">Critical (≤ 7 Days)</option>
              <option value="UPCOMING">Upcoming (≤ 30 Days)</option>
              <option value="EXPIRED">Expired Only</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="Confirmed">Confirmed</option>
              <option value="Discrepant">Discrepant</option>
              <option value="Customs Cleared">Customs Cleared</option>
              <option value="Shipment In-Transit">In-Transit</option>
              <option value="Draft">Draft</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          <button
            type="button"
            onClick={onOpenCreateModal}
            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs shrink-0 self-start sm:self-auto cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Open Import LC</span>
          </button>
        </div>

        {/* View Mode: Owner Report */}
        {viewMode === 'owner_report' ? (
          <div className="p-4">
            <CompanyOwnerLcReport
              lcs={filteredLcs}
              suppliers={suppliers}
              onSelectLc={onSelectLc}
              onOpenExpenses={onOpenExpenses}
              onOpenBills={onOpenBills}
            />
          </div>
        ) : viewMode === 'margin_reconciliation' ? (
          <div className="p-4">
            <MarginReconciliationView
              lcs={lcs}
              isAdmin={isAdmin}
              onOpenVoucher={onOpenVoucher}
              onCorrectByReversal={onCorrectByReversal}
              onVoidDuplicateLc={onVoidDuplicateLc}
              onReverseVoucher={onReverseVoucher}
              bankAccounts={bankAccounts}
            />
          </div>
        ) : (
          <>
            {/* Responsive Table */}
            <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-3.5">LC Number</th>
                  <th className="py-3 px-3">Issuing Bank & Branch</th>
                  <th className="py-3 px-3">Supplier & Company Owner</th>
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3 text-right">CFR Value (USD)</th>
                  <th className="py-3 px-3 text-right">Margin & Account</th>
                  <th className="py-3 px-3">Shipment & LC Expiry</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-700">
                {filteredLcs.map((lc) => {
                  const shipDays = getDaysRemaining(lc.shipmentExpiryDate);
                  const expDays = getDaysRemaining(lc.lcExpiryDate);
                  const minDays = Math.min(shipDays, expDays);
                  const isExpired = minDays < 0;
                  const isCritical = minDays >= 0 && minDays <= 7;
                  const isCancelled = lc.status === 'Cancelled' || lc.isCancelled;
                  const cancelCheck = canCancelLc(lc);
                  const rowBill = computeLcBill(lc);

                  return (
                    <tr 
                      key={lc.id} 
                      className={`hover:bg-slate-50/70 transition-colors ${
                        isCancelled ? 'bg-slate-100/70 opacity-75' : isExpired ? 'bg-rose-50/30' : isCritical ? 'bg-amber-50/20' : ''
                      }`}
                    >
                      <td className="py-3 px-3.5 font-mono font-bold text-blue-700">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <button
                            type="button"
                            onClick={() => setViewingDetailsLc(lc)}
                            className={`hover:underline cursor-pointer text-left font-bold ${
                              isCancelled ? 'line-through text-slate-500' : 'text-blue-700 hover:text-blue-900'
                            }`}
                            title="Click to view LC details & margin information"
                          >
                            {lc.lcNumber}
                          </button>
                          {isCancelled && (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-100 text-rose-800 border border-rose-300">
                              Cancelled
                            </span>
                          )}
                          {!isCancelled && isExpired && (
                            <span className="w-2 h-2 rounded-full bg-rose-600 animate-ping" title="Expired Instrument" />
                          )}
                          {!isCancelled && isCritical && (
                            <span className="w-2 h-2 rounded-full bg-amber-500" title="Expires ≤ 7 Days" />
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 font-normal">{lc.bankReference}</span>
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-semibold text-slate-900 block">{lc.issuingBank}</span>
                        <span className="text-[10px] text-slate-500">{lc.branch}</span>
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-semibold text-slate-900 block">{lc.supplierName}</span>
                        <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                          <span className="text-[10px] text-slate-500 truncate max-w-[130px]">{lc.items[0]?.itemName}</span>
                          {lc.companyOwner && (
                            <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200/80 px-1 py-0.2 rounded font-mono">
                              <User className="w-2.5 h-2.5" />
                              <span>{lc.companyOwner}</span>
                            </span>
                          )}
                        </div>
                      </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-slate-100 text-slate-800">
                        {lc.lcType}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                      <div>${rowBill.officialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                      <span className="text-[10px] text-slate-500 font-sans block">
                        {rowBill.billableQty.toLocaleString()} MT {rowBill.excessQty > 0 ? `(+${rowBill.excessQty} Excess)` : ''}
                      </span>
                    </td>

                    {/* Margin & Paid Account Column (Requirement 1 & 4) */}
                    <td className="py-3 px-3 text-right font-mono text-slate-700">
                      <div className="font-bold text-xs">
                        ৳{Math.round((lc.marginAmountBDT !== undefined ? lc.marginAmountBDT : lc.marginAmountLocal) || 0).toLocaleString()}
                      </div>
                      <span className="text-[10px] text-slate-500 block">
                        {(lc.marginPercent !== undefined ? lc.marginPercent : lc.marginDepositPercent) || 0}% margin
                      </span>

                      {lc.marginVoucherNo ? (
                        <div className="mt-1 text-left">
                          <span className="text-[9px] text-slate-500 block truncate max-w-[150px]">
                            Paid from: <strong className="text-slate-800">{lc.marginPaidFromAccountName || 'Bank/Cash'}</strong>
                          </span>
                          <button
                            type="button"
                            onClick={() => onOpenVoucher?.(lc.marginVoucherNo!, lc.marginVoucherId || lc.marginTransactionId)}
                            className="inline-flex items-center gap-0.5 text-[10px] font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
                            title="View Voucher"
                          >
                            <FileText className="w-2.5 h-2.5 text-blue-500" />
                            <span>{lc.marginVoucherNo}</span>
                          </button>
                        </div>
                      ) : (lc.marginStatus === 'external' || lc.marginStatus === 'accounted_earlier') ? (
                        <div className="mt-1">
                          <span 
                            className="inline-block text-[9px] font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200" 
                            title={lc.marginManualReason || 'Accounted prior to system'}
                          >
                            {lc.marginStatus === 'external' ? 'Paid Externally / Opening' : 'Accounted Earlier'}
                          </span>
                          {lc.marginManualReason && (
                            <span className="block text-[8px] text-slate-400 truncate max-w-[140px] italic">
                              {lc.marginManualReason}
                            </span>
                          )}
                        </div>
                      ) : !isCancelled ? (
                        <div className="mt-1 space-y-1">
                          <span className="inline-flex items-center gap-1 text-[9px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded">
                            <AlertTriangle className="w-2.5 h-2.5 text-amber-500" />
                            Margin not posted
                          </span>
                          {onPostMargin && (
                            <button
                              type="button"
                              onClick={() => onPostMargin(lc)}
                              className="w-full px-2 py-0.5 bg-amber-600 hover:bg-amber-700 text-white rounded text-[9px] font-bold transition-colors cursor-pointer shadow-2xs block text-center"
                            >
                              Post Margin Now
                            </button>
                          )}
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">Reversed / Cancelled</span>
                      )}
                    </td>

                    {/* Expiry Dates & Countdown Alerts */}
                    <td className="py-3 px-3 font-mono text-[11px]">
                      {/* Shipment Expiry */}
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-slate-400">Ship:</span>
                        <span className="font-bold text-slate-800">{lc.shipmentExpiryDate || 'N/A'}</span>
                        <span className={`text-[10px] px-1 py-0.2 rounded font-bold ${
                          shipDays < 0 
                            ? 'bg-rose-100 text-rose-900' 
                            : shipDays <= 7
                            ? 'bg-amber-100 text-amber-900'
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {shipDays < 0 ? `Lapsed ${Math.abs(shipDays)}d` : `${shipDays}d`}
                        </span>
                      </div>

                      {/* Presentation Expiry */}
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="text-[10px] text-slate-400">Exp:</span>
                        <span className="font-medium text-slate-700">{lc.lcExpiryDate || 'N/A'}</span>
                        <span className={`text-[10px] px-1 py-0.2 rounded font-bold ${
                          expDays < 0 
                            ? 'bg-rose-100 text-rose-900' 
                            : expDays <= 7
                            ? 'bg-amber-100 text-amber-900'
                            : 'bg-slate-100 text-slate-500'
                        }`}>
                          {expDays < 0 ? `Expired` : `${expDays}d`}
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-3 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        isCancelled ? 'bg-rose-100 text-rose-800 border border-rose-200' :
                        lc.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-800' :
                        lc.status === 'Discrepant' ? 'bg-rose-100 text-rose-800' :
                        lc.status === 'Customs Cleared' ? 'bg-teal-100 text-teal-800' :
                        lc.status === 'Shipment In-Transit' ? 'bg-blue-100 text-blue-800' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {lc.status}
                      </span>
                    </td>

                    <td className="py-3 px-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5 flex-wrap">
                        {onOpenAmendment && !isCancelled && (isExpired || isCritical) && (
                          <button
                            type="button"
                            onClick={() => onOpenAmendment(lc.id)}
                            title="Draft Swift MT707 Bank Amendment Extension"
                            className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-[11px] font-bold transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Bell className="w-3 h-3 text-amber-600" />
                            <span>MT707</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onOpenExpenses(lc)}
                          title="View Landed Cost & Customs Expenses"
                          className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-[11px] font-bold transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Calculator className="w-3 h-3" />
                          <span>Expenses</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onOpenBills(lc)}
                          title="View Exporter Commercial Bill"
                          className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-[11px] font-bold transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Receipt className="w-3 h-3" />
                          <span>Bill</span>
                        </button>

                        {/* Admin-only Cancel LC Button (Requirement 3) */}
                        {isAdmin && !isCancelled && onCancelLc && (
                          <button
                            type="button"
                            onClick={() => onCancelLc(lc)}
                            disabled={!cancelCheck.allowed}
                            title={cancelCheck.allowed ? "Cancel LC & Reverse Margin Deposit" : cancelCheck.reason}
                            className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-colors flex items-center gap-1 ${
                              cancelCheck.allowed
                                ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 cursor-pointer'
                                : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed opacity-60'
                            }`}
                          >
                            <XCircle className="w-3 h-3 text-rose-600" />
                            <span>Cancel</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredLcs.length === 0 && (
          <div className="p-8 text-center text-slate-500 text-xs">
            No Letters of Credit match your filter criteria.
          </div>
        )}
          </>
        )}
      </div>

      {/* LC Details Modal (Requirement 4: LC Details margin status & actions) */}
      {viewingDetailsLc && (
        <ModalWrapper
          isOpen={!!viewingDetailsLc}
          onClose={() => setViewingDetailsLc(null)}
          isDirty={false}
          backdropClassName="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden my-auto animate-in zoom-in-95"
          >
            {/* Header */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between shrink-0">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-base text-blue-400">
                    {viewingDetailsLc.lcNumber}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-200 border border-slate-700">
                    {viewingDetailsLc.lcType}
                  </span>
                  {viewingDetailsLc.status === 'Cancelled' ? (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-900/80 text-rose-300 border border-rose-700">
                      Cancelled
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-900/80 text-emerald-300 border border-emerald-700">
                      {viewingDetailsLc.status}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Ref: {viewingDetailsLc.bankReference} • Bank: {viewingDetailsLc.issuingBank} ({viewingDetailsLc.branch})
                </p>
              </div>

              <button
                type="button"
                data-modal-close="true"
                onClick={() => setViewingDetailsLc(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer shrink-0"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
              {/* Partner & Commodity Info */}
              <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Supplier & Beneficiary</span>
                  <div className="font-bold text-slate-900 text-sm mt-0.5">{viewingDetailsLc.supplierName}</div>
                  <div className="text-slate-500 text-[11px] mt-0.5">
                    Country: {viewingDetailsLc.beneficiaryCountry || 'Overseas'}
                    {viewingDetailsLc.companyOwner && ` • Owner: 👤 ${viewingDetailsLc.companyOwner}`}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Import Commodity & Port</span>
                  <div className="font-bold text-slate-900 text-sm mt-0.5">
                    {viewingDetailsLc.items[0]?.itemName || viewingDetailsLc.originQuarryItem || 'Boulder Stone'}
                  </div>
                  <div className="text-slate-500 text-[11px] mt-0.5">
                    Port: {viewingDetailsLc.portOfDischarge || `${viewingDetailsLc.borderLandPort} Land Port`}
                  </div>
                </div>
              </div>

              {/* Financial & Dual Pricing Summary (Requirement 1: uses computeLcBill) */}
              {(() => {
                const detailsBill = computeLcBill(viewingDetailsLc);
                return (
                  <div className="grid grid-cols-3 gap-2.5">
                    <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl">
                      <span className="text-[10px] font-bold uppercase text-blue-700 block">Bank LC Value (Billed)</span>
                      <div className="font-mono font-black text-slate-900 text-base mt-0.5">
                        ${detailsBill.officialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <span className="text-[10px] text-blue-600 font-mono">
                        ৳{Math.round(detailsBill.officialBillBdt).toLocaleString()} BDT
                      </span>
                    </div>

                    <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl">
                      <span className="text-[10px] font-bold uppercase text-indigo-700 block">Commercial Value (Billed)</span>
                      <div className="font-mono font-black text-indigo-950 text-base mt-0.5">
                        ${detailsBill.commercialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <span className="text-[10px] text-indigo-600 font-mono">
                        {detailsBill.billableQty.toLocaleString()} MT @ ${detailsBill.weightedActualRate.toFixed(2)}
                      </span>
                    </div>

                    <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl">
                      <span className="text-[10px] font-bold uppercase text-amber-800 block">Differential / Hundi Gap</span>
                      <div className="font-mono font-black text-amber-900 text-base mt-0.5">
                        ${detailsBill.hundiGapForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <span className="text-[10px] text-amber-700 font-mono font-bold">
                        ৳{Math.round(detailsBill.hundiGapBdt).toLocaleString()} BDT
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* Requirement 4: Margin Information & Status in LC Details */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                    <Building2 className="w-4 h-4 text-indigo-600" />
                    Bank Cash Margin Deposit Information
                  </span>
                  <span className="font-mono font-bold text-indigo-900">
                    {(viewingDetailsLc.marginPercent !== undefined ? viewingDetailsLc.marginPercent : viewingDetailsLc.marginDepositPercent) || 0}% (৳{Math.round((viewingDetailsLc.marginAmountBDT !== undefined ? viewingDetailsLc.marginAmountBDT : viewingDetailsLc.marginAmountLocal) || 0).toLocaleString()} BDT)
                  </span>
                </div>

                {viewingDetailsLc.marginVoucherNo ? (
                  <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
                    <div>
                      <div className="text-[11px] text-slate-600">
                        Paid From Account: <strong className="text-slate-900">{viewingDetailsLc.marginPaidFromAccountName || 'Bank/Cash Account'}</strong>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Payment Date: {viewingDetailsLc.marginPaymentDate || viewingDetailsLc.openingDate}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        onOpenVoucher?.(viewingDetailsLc.marginVoucherNo!, viewingDetailsLc.marginVoucherId || viewingDetailsLc.marginTransactionId);
                      }}
                      className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-300 rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer text-xs"
                    >
                      <FileText className="w-3.5 h-3.5 text-blue-600" />
                      <span>View Voucher ({viewingDetailsLc.marginVoucherNo})</span>
                    </button>
                  </div>
                ) : (viewingDetailsLc.marginStatus === 'external' || viewingDetailsLc.marginStatus === 'accounted_earlier') ? (
                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-slate-100 text-slate-800 border border-slate-300">
                        {viewingDetailsLc.marginStatus === 'external' ? 'Paid Externally / Opening Balance' : 'Accounted Earlier'}
                      </span>
                    </div>
                    {viewingDetailsLc.marginManualReason && (
                      <p className="text-[11px] text-slate-600">
                        <strong>Reason:</strong> {viewingDetailsLc.marginManualReason}
                      </p>
                    )}
                  </div>
                ) : viewingDetailsLc.status !== 'Cancelled' ? (
                  <div className="space-y-2 pt-1">
                    <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold">Margin not posted</div>
                        <div className="text-[11px] text-amber-700 mt-0.5">
                          Margin deposit has not been posted from a bank or cash account yet.
                        </div>
                      </div>
                    </div>

                    {onPostMargin && (
                      <button
                        type="button"
                        onClick={() => {
                          const target = viewingDetailsLc;
                          setViewingDetailsLc(null);
                          onPostMargin(target);
                        }}
                        className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer text-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Post Margin Now</span>
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl">
                    LC is Cancelled. Margin has been reversed.
                  </div>
                )}
              </div>

              {/* Cancellation Info if Cancelled */}
              {viewingDetailsLc.isCancelled && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <XCircle className="w-4 h-4 text-rose-600" />
                    Cancellation Record
                  </div>
                  <div className="text-[11px] text-rose-700">
                    <strong>Reason:</strong> {viewingDetailsLc.cancelReason || 'N/A'} • <strong>Date:</strong> {viewingDetailsLc.cancelledAt ? new Date(viewingDetailsLc.cancelledAt).toLocaleDateString() : 'N/A'}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer Actions */}
            <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                {/* Admin Cancel LC Button (Requirement 3) */}
                {isAdmin && !viewingDetailsLc.isCancelled && onCancelLc && (
                  (() => {
                    const check = canCancelLc(viewingDetailsLc);
                    return (
                      <button
                        type="button"
                        disabled={!check.allowed}
                        onClick={() => {
                          const target = viewingDetailsLc;
                          setViewingDetailsLc(null);
                          onCancelLc(target);
                        }}
                        title={check.allowed ? "Cancel LC" : check.reason}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                          check.allowed
                            ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 cursor-pointer'
                            : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed opacity-60'
                        }`}
                      >
                        <XCircle className="w-3.5 h-3.5 text-rose-600" />
                        <span>Cancel LC (Admin)</span>
                      </button>
                    );
                  })()
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const target = viewingDetailsLc;
                    setViewingDetailsLc(null);
                    onOpenExpenses(target);
                  }}
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl font-bold transition-colors text-xs flex items-center gap-1 cursor-pointer"
                >
                  <Calculator className="w-3.5 h-3.5" />
                  Expenses & Landed Cost
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const target = viewingDetailsLc;
                    setViewingDetailsLc(null);
                    onOpenBills(target);
                  }}
                  className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl font-bold transition-colors text-xs flex items-center gap-1 cursor-pointer"
                >
                  <Receipt className="w-3.5 h-3.5" />
                  Commercial Bills
                </button>

                <button
                  type="button"
                  data-modal-close="true"
                  onClick={() => setViewingDetailsLc(null)}
                  className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-bold transition-colors text-xs cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
