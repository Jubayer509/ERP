import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  User, 
  Plus, 
  Search, 
  Printer, 
  Edit3, 
  FileText, 
  CreditCard, 
  Receipt, 
  MapPin, 
  Globe2, 
  Phone, 
  Clock, 
  ShieldCheck, 
  Users, 
  Filter,
  DollarSign
} from 'lucide-react';
import { Supplier } from '../../types/erp';

export interface SupplierProfilesViewProps {
  suppliers: Supplier[];
  onAddSupplier: () => void;
  onEditSupplier: (supplier: Supplier) => void;
  onViewKhata: (supplierId: string) => void;
  onMakePayment?: (supplierId: string) => void;
  onCreateInvoice?: (supplierId: string) => void;
}

export const SupplierProfilesView: React.FC<SupplierProfilesViewProps> = ({
  suppliers,
  onAddSupplier,
  onEditSupplier,
  onViewKhata,
  onMakePayment,
  onCreateInvoice
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'Local' | 'Exporter'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [currencyFilter, setCurrencyFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<'name' | 'code' | 'payable'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // KPI Calculations
  const stats = useMemo(() => {
    let totalPayable = 0;
    let totalAdvance = 0;
    let localCount = 0;
    let exporterCount = 0;
    let activeCount = 0;
    let inactiveCount = 0;

    suppliers.forEach(s => {
      const active = s.isActive !== false && s.status !== 'Inactive';
      if (active) activeCount++;
      else inactiveCount++;

      const isExp = s.supplierType === 'Exporter' || 
        (s.country && !s.country.toLowerCase().includes('bangladesh')) ||
        (s.currency && s.currency !== 'BDT');
      if (isExp) exporterCount++;
      else localCount++;

      const bal = s.currentPayable || 0;
      if (bal > 0) totalPayable += bal;
      else if (bal < 0) totalAdvance += Math.abs(bal);
    });

    return {
      total: suppliers.length,
      activeCount,
      inactiveCount,
      localCount,
      exporterCount,
      totalPayable,
      totalAdvance
    };
  }, [suppliers]);

  // Filtered & sorted list
  const filteredSuppliers = useMemo(() => {
    return suppliers
      .filter(s => {
        const q = searchTerm.toLowerCase();
        const matchesSearch = 
          s.name.toLowerCase().includes(q) ||
          (s.tradeName && s.tradeName.toLowerCase().includes(q)) ||
          (s.companyOwner && s.companyOwner.toLowerCase().includes(q)) ||
          (s.code && s.code.toLowerCase().includes(q)) ||
          (s.country && s.country.toLowerCase().includes(q)) ||
          (s.city && s.city.toLowerCase().includes(q)) ||
          (s.phone && s.phone.toLowerCase().includes(q)) ||
          (s.mobile && s.mobile.toLowerCase().includes(q)) ||
          (s.address && s.address.toLowerCase().includes(q));

        const isExp = s.supplierType === 'Exporter' || 
          (s.country && !s.country.toLowerCase().includes('bangladesh')) ||
          (s.currency && s.currency !== 'BDT');
        const resolvedType = isExp ? 'Exporter' : 'Local';
        const matchesType = typeFilter === 'all' || resolvedType === typeFilter;

        const isActive = s.isActive !== false && s.status !== 'Inactive';
        const matchesStatus = 
          statusFilter === 'all' ? true :
          statusFilter === 'active' ? isActive : !isActive;

        const matchesCurrency = currencyFilter === 'all' || (s.currency || 'BDT') === currencyFilter;

        return matchesSearch && matchesType && matchesStatus && matchesCurrency;
      })
      .sort((a, b) => {
        let cmp = 0;
        if (sortField === 'name') {
          cmp = (a.tradeName || a.name).localeCompare(b.tradeName || b.name);
        } else if (sortField === 'code') {
          cmp = (a.code || '').localeCompare(b.code || '');
        } else if (sortField === 'payable') {
          cmp = (a.currentPayable || 0) - (b.currentPayable || 0);
        }
        return sortDirection === 'asc' ? cmp : -cmp;
      });
  }, [suppliers, searchTerm, typeFilter, statusFilter, currencyFilter, sortField, sortDirection]);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">Supplier Profile</h2>
                <span className="text-xs bg-blue-100 text-blue-700 font-semibold px-2.5 py-0.5 rounded-full">
                  {suppliers.length} Profiles
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => window.print()}
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print List</span>
          </button>
          
          <button
            type="button"
            onClick={onAddSupplier}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm shadow-blue-500/20 transition flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add Supplier</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Total Suppliers</span>
            <Users className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{stats.total}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
            <span className="text-emerald-600 font-semibold">{stats.activeCount} Active</span>
            <span>•</span>
            <span className="text-slate-400">{stats.inactiveCount} Inactive</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Classification</span>
            <Globe2 className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold text-indigo-600">
            {stats.exporterCount} <span className="text-xs font-normal text-slate-500">Exporters</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            <span>{stats.localCount} Local Suppliers</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Total Payables</span>
            <CreditCard className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-amber-600 font-mono">
            ৳ {stats.totalPayable.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[11px] text-amber-600/80 mt-1">Credit Balance (We Owe)</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Total Advances</span>
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-emerald-600 font-mono">
            ৳ {stats.totalAdvance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[11px] text-emerald-600/80 mt-1">Debit Balance (Advance Paid)</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by company name, owner, code, mobile, country, address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Type Filter */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setTypeFilter('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${typeFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                All ({suppliers.length})
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('Exporter')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${typeFilter === 'Exporter' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Exporters
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('Local')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${typeFilter === 'Local' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Local
              </button>
            </div>

            {/* Status Filter */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setStatusFilter('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${statusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('active')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${statusFilter === 'active' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Active
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('inactive')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${statusFilter === 'inactive' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Inactive
              </button>
            </div>

            {/* Currency Filter */}
            <select
              value={currencyFilter}
              onChange={(e) => setCurrencyFilter(e.target.value)}
              className="py-1.5 px-3 border border-slate-200 rounded-lg text-xs text-slate-700 bg-white outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Currencies</option>
              <option value="BDT">BDT (৳)</option>
              <option value="USD">USD ($)</option>
              <option value="RS">RS (₹)</option>
            </select>

            {/* Sort Filter */}
            <select
              value={`${sortField}-${sortDirection}`}
              onChange={(e) => {
                const [f, d] = e.target.value.split('-');
                setSortField(f as any);
                setSortDirection(d as any);
              }}
              className="py-1.5 px-3 border border-slate-200 rounded-lg text-xs text-slate-700 bg-white outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="name-asc">Name (A → Z)</option>
              <option value="name-desc">Name (Z → A)</option>
              <option value="code-asc">Code (Asc)</option>
              <option value="payable-desc">Payable (Highest First)</option>
              <option value="payable-asc">Payable (Lowest First)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Supplier Directory Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        {filteredSuppliers.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
              <Building2 className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">No Suppliers Found</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              {searchTerm ? 'No supplier matches your search criteria. Try a different query.' : 'No supplier profiles added yet. Click "+ Add Supplier" to enroll the first company.'}
            </p>
            <button
              type="button"
              onClick={onAddSupplier}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition inline-flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add First Supplier</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                  <th className="py-3 px-4">Code</th>
                  <th className="py-3 px-4">Company Trade Name & Owner</th>
                  <th className="py-3 px-4">Classification</th>
                  <th className="py-3 px-4">Contact & Country</th>
                  <th className="py-3 px-4">Payment Terms</th>
                  <th className="py-3 px-4 text-right">Opening Bal</th>
                  <th className="py-3 px-4 text-right">Current Payable</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredSuppliers.map((supp) => {
                  const isActive = supp.isActive !== false && supp.status !== 'Inactive';
                  const isExp = supp.supplierType === 'Exporter' || 
                    (supp.country && !supp.country.toLowerCase().includes('bangladesh')) ||
                    (supp.currency && supp.currency !== 'BDT');
                  const payable = supp.currentPayable || 0;
                  const isPayable = payable > 0;
                  const isAdvance = payable < 0;
                  const curr = supp.currency || (isExp ? 'USD' : 'BDT');
                  const curSym = curr === 'USD' ? '$' : curr === 'RS' ? '₹' : '৳';

                  return (
                    <tr key={supp.id} className="hover:bg-blue-50/40 transition group">
                      {/* Code */}
                      <td className="py-3.5 px-4 font-mono font-bold text-blue-700 text-[11px] whitespace-nowrap">
                        {supp.code || 'SUPP-00'}
                      </td>

                      {/* Name & Owner */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 group-hover:text-blue-700 transition">
                          {supp.tradeName || supp.name}
                        </div>
                        {supp.companyOwner && (
                          <div className="text-[11px] text-blue-600 flex items-center gap-1 mt-0.5 font-medium">
                            <User className="w-3 h-3 opacity-70" />
                            <span>Owner: {supp.companyOwner}</span>
                          </div>
                        )}
                        {supp.contactPerson && (
                          <div className="text-[10px] text-slate-400">
                            Attn: {supp.contactPerson}
                          </div>
                        )}
                      </td>

                      {/* Classification */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {isExp ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                            <Globe2 className="w-3 h-3 text-amber-600" />
                            <span>Exporter</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                            <MapPin className="w-3 h-3 text-blue-600" />
                            <span>Local</span>
                          </span>
                        )}
                      </td>

                      {/* Contact & Country */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 text-slate-700 font-mono text-[11px]">
                          <span>{supp.country.includes('Bangladesh') ? '🇧🇩' : supp.country.includes('Bhutan') ? '🇧🇹' : supp.country.includes('India') ? '🇮🇳' : '🌐'}</span>
                          <span className="font-semibold">{supp.phone || supp.mobile || 'No Phone'}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 max-w-xs truncate">
                          {supp.country} • {supp.address || supp.city || 'Trade Depot'}
                        </div>
                      </td>

                      {/* Payment Terms */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>{supp.paymentTerms || 'Net 30 Days'}</span>
                        </span>
                      </td>

                      {/* Opening Balance */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="font-mono text-slate-600 font-medium">
                          {curSym} {(supp.openingBalance || 0).toLocaleString('en-US', { maximumFractionDigits: 2 })}
                        </div>
                        <span className={`text-[10px] font-semibold px-1 rounded ${supp.balanceType === 'DR' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                          {supp.balanceType || 'CR'}
                        </span>
                      </td>

                      {/* Current Payable */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className={`font-mono font-bold ${isPayable ? 'text-amber-700' : isAdvance ? 'text-emerald-600' : 'text-slate-600'}`}>
                          {curSym} {Math.abs(payable).toLocaleString('en-US', { maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] font-medium">
                          {isPayable ? (
                            <span className="text-amber-700">Payable</span>
                          ) : isAdvance ? (
                            <span className="text-emerald-600">Advance</span>
                          ) : (
                            <span className="text-slate-400">Settled</span>
                          )}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        {isActive ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-500 border border-slate-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                            Inactive
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* EDIT PROFILE BUTTON - Primary feature */}
                          <button
                            type="button"
                            onClick={() => onEditSupplier(supp)}
                            className="p-1.5 text-blue-600 hover:text-white hover:bg-blue-600 border border-blue-200 hover:border-blue-600 rounded-lg transition shadow-xs flex items-center gap-1 px-2 text-[11px] font-medium cursor-pointer"
                            title="Edit Supplier Profile"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit Profile</span>
                          </button>

                          {/* Khata / Ledger Button */}
                          <button
                            type="button"
                            onClick={() => onViewKhata(supp.id)}
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 rounded-lg transition cursor-pointer"
                            title="View Supplier Khata & Ledger"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>

                          {/* Pay Button */}
                          {onMakePayment && (
                            <button
                              type="button"
                              onClick={() => onMakePayment(supp.id)}
                              className="p-1.5 text-emerald-600 hover:text-white hover:bg-emerald-600 border border-emerald-200 hover:border-emerald-600 rounded-lg transition cursor-pointer"
                              title="Make Payment / Settlement"
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* New Invoice Button */}
                          {onCreateInvoice && (
                            <button
                              type="button"
                              onClick={() => onCreateInvoice(supp.id)}
                              className="p-1.5 text-indigo-600 hover:text-white hover:bg-indigo-600 border border-indigo-200 hover:border-indigo-600 rounded-lg transition cursor-pointer"
                              title="Create Purchase Invoice"
                            >
                              <Receipt className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
