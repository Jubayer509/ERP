import React, { useState } from 'react';
import { 
  Receipt, 
  Save, 
  FileText,
  Lock,
  AlertTriangle,
  RotateCcw,
  Loader2
} from 'lucide-react';
import { DirectPurchaseInvoice, Supplier } from '../../types/erp';
import { ModalWrapper } from '../common/ModalWrapper';
import { useAuth } from '../../contexts/AuthContext';
import { voidAccountTransaction, editAccountTransaction, getAccountTransactions } from '../../services/accountService';

interface EditPurchaseInvoiceModalProps {
  isOpen: boolean;
  invoice: DirectPurchaseInvoice | null;
  suppliers: Supplier[];
  onClose: () => void;
  onSave: (updatedInvoice: DirectPurchaseInvoice) => void;
}

export const EditPurchaseInvoiceModal: React.FC<EditPurchaseInvoiceModalProps> = ({
  isOpen,
  invoice,
  suppliers,
  onClose,
  onSave
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  if (!isOpen || !invoice) return null;

  const isAlreadyVoided = invoice.isVoided || invoice.status === 'Voided' || invoice.paymentStatus === 'Voided';

  const [challanNumber, setChallanNumber] = useState(invoice.challanNumber);
  const [supplierBillNumber, setSupplierBillNumber] = useState(invoice.supplierBillNumber || '');
  const [invoiceDate, setInvoiceDate] = useState(invoice.invoiceDate);
  const [dueDate, setDueDate] = useState(invoice.dueDate);
  const [warehouseName, setWarehouseName] = useState(invoice.warehouseName || 'Burimari Land Port Stockyard');
  const [notes, setNotes] = useState(invoice.notes || '');
  const [voidReason, setVoidReason] = useState('');
  const [showVoidConfirm, setShowVoidConfirm] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isAlreadyVoided || isProcessing) return;
    setErrorMsg(null);
    setIsProcessing(true);

    try {
      if (invoice.purchaseVoucherId) {
        await editAccountTransaction(
          invoice.purchaseVoucherId,
          {
            date: invoiceDate,
            referenceNo: invoice.invoiceNumber,
            note: notes.trim()
          },
          {
            uid: currentUser?.id || 'usr-admin',
            name: currentUser?.name || 'Admin',
            email: currentUser?.email
          },
          'Updated purchase invoice metadata'
        );
      }

      const updated: DirectPurchaseInvoice = {
        ...invoice,
        challanNumber: challanNumber.trim(),
        supplierBillNumber: supplierBillNumber.trim() || undefined,
        invoiceDate,
        dueDate,
        warehouseName,
        notes: notes.trim()
      };

      onSave(updated);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to update purchase invoice metadata.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleVoidAndReverseInvoice = async () => {
    if (!isAdmin) {
      setErrorMsg('Only an Administrator can void a posted purchase invoice.');
      return;
    }
    if (!voidReason.trim()) {
      setErrorMsg('Please enter a mandatory reason for voiding this purchase invoice.');
      return;
    }
    setErrorMsg(null);
    setIsProcessing(true);

    try {
      const allTxns = getAccountTransactions();
      const userObj = {
        uid: currentUser?.id || 'usr-admin',
        name: currentUser?.name || 'Admin',
        email: currentUser?.email
      };

      // 1. Reverse payment voucher if present and active
      const payTxnId =
        invoice.paymentVoucherId ||
        (invoice.paymentVoucherNumber
          ? allTxns.find(t => t.voucherNo === invoice.paymentVoucherNumber && t.status !== 'voided')?.id
          : undefined);
      if (payTxnId) {
        const payTxn = allTxns.find(t => t.id === payTxnId);
        if (payTxn && payTxn.status !== 'voided') {
          await voidAccountTransaction(payTxnId, `Void Invoice ${invoice.invoiceNumber}: ${voidReason.trim()}`, userObj);
        }
      }

      // 2. Reverse purchase journal voucher if present and active
      const billTxnId =
        invoice.purchaseVoucherId ||
        (invoice.purchaseVoucherNumber
          ? allTxns.find(t => t.voucherNo === invoice.purchaseVoucherNumber && t.status !== 'voided')?.id
          : undefined);
      if (billTxnId) {
        const billTxn = allTxns.find(t => t.id === billTxnId);
        if (billTxn && billTxn.status !== 'voided') {
          await voidAccountTransaction(billTxnId, `Void Invoice ${invoice.invoiceNumber}: ${voidReason.trim()}`, userObj);
        }
      }

      const voidedInvoice: DirectPurchaseInvoice = {
        ...invoice,
        paidAmount: 0,
        dueAmount: 0,
        paymentStatus: 'Voided',
        status: 'Voided',
        isVoided: true,
        voidReason: voidReason.trim(),
        voidedAt: new Date().toISOString(),
        voidedBy: currentUser?.name || 'Admin',
        notes: `${invoice.notes || ''} | [VOIDED: ${voidReason.trim()}]`
      };

      onSave(voidedInvoice);
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to void purchase invoice vouchers.');
    } finally {
      setIsProcessing(false);
    }
  };

  const isDirty =
    challanNumber !== invoice.challanNumber ||
    supplierBillNumber !== (invoice.supplierBillNumber || '') ||
    invoiceDate !== invoice.invoiceDate ||
    dueDate !== invoice.dueDate ||
    warehouseName !== invoice.warehouseName ||
    notes !== (invoice.notes || '');

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      isDirty={isDirty}
      isSaving={isProcessing}
      backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-300 flex items-center justify-center border border-indigo-400/20">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">Edit Purchase Invoice</h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  {invoice.invoiceNumber}
                </span>
              </div>
              <p className="text-xs text-slate-400">Supplier: {invoice.supplierName}</p>
            </div>
          </div>
          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-xs">
          {/* Accounting Lock Notice */}
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-amber-900">
            <Lock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="font-bold text-xs">
                Accounting Lock: Invoice Total, Paid Amount &amp; Items Locked After Posting
              </div>
              <p className="text-[11px] text-amber-800">
                To change quantities, rates, supplier, or paid amounts, an Administrator must <strong>Void &amp; Reverse</strong> this invoice and create a new entry.
              </p>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Read-only Financial & Voucher Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div>
              <span className="text-slate-500 block text-[10px] font-semibold">Grand Total (Locked)</span>
              <span className="font-mono font-bold text-sm text-slate-900">
                {invoice.currency} {invoice.grandTotal.toLocaleString()}
              </span>
              {invoice.purchaseVoucherNumber && (
                <span className="block text-[10px] font-mono text-indigo-600">
                  Journal: {invoice.purchaseVoucherNumber}
                </span>
              )}
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-semibold">Paid Amount (Locked)</span>
              <span className="font-mono font-bold text-sm text-emerald-700">
                {invoice.currency} {invoice.paidAmount.toLocaleString()}
              </span>
              {invoice.paymentVoucherNumber && (
                <span className="block text-[10px] font-mono text-emerald-600">
                  Payment: {invoice.paymentVoucherNumber}
                </span>
              )}
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-semibold">Remaining Due</span>
              <span className="font-mono font-bold text-sm text-rose-600">
                {invoice.currency} {invoice.dueAmount.toLocaleString()}
              </span>
              <span className="block text-[10px] text-slate-500">
                Status: {invoice.paymentStatus}
              </span>
            </div>
          </div>

          {/* Read-only Items List */}
          <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-2">
            <span className="font-bold text-slate-700 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-600" />
              Posted Commodity Items (Locked)
            </span>
            {invoice.items.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between bg-white p-2 rounded-lg border border-slate-200 font-mono text-xs">
                <span className="font-sans font-semibold text-slate-800">{item.itemName}</span>
                <span className="text-slate-600">
                  {item.quantity.toLocaleString()} {item.uom || 'MT'} × {invoice.currency} {item.unitPrice.toLocaleString()} ={' '}
                  <strong className="text-indigo-700">{invoice.currency} {(item.totalPrice || 0).toLocaleString()}</strong>
                </span>
              </div>
            ))}
          </div>

          {/* Editable Metadata: Challan & Bill Ref */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Challan No / Port Gate Pass</label>
              <input
                type="text"
                disabled={isAlreadyVoided}
                value={challanNumber}
                onChange={(e) => setChallanNumber(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-xl p-2 font-mono font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none disabled:bg-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Supplier Bill Ref No</label>
              <input
                type="text"
                disabled={isAlreadyVoided}
                value={supplierBillNumber}
                onChange={(e) => setSupplierBillNumber(e.target.value)}
                placeholder="e.g. BILL-9921"
                className="w-full border border-slate-300 rounded-xl p-2 font-mono text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none disabled:bg-slate-100"
              />
            </div>
          </div>

          {/* Dates & Warehouse */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Invoice Date</label>
              <input
                type="date"
                disabled={isAlreadyVoided}
                value={invoiceDate}
                onChange={(e) => setInvoiceDate(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-xl p-2 font-mono text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none disabled:bg-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Due Date</label>
              <input
                type="date"
                disabled={isAlreadyVoided}
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-xl p-2 font-mono text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none disabled:bg-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Receiving Stockyard / Yard</label>
              <select
                disabled={isAlreadyVoided}
                value={warehouseName}
                onChange={(e) => setWarehouseName(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2 text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none disabled:bg-slate-100"
              >
                <option value="Chittagong Port Bonded Yard">Chittagong Port Bonded Yard</option>
                <option value="Burimari Land Port Unit">Burimari Land Port Unit</option>
                <option value="Burimari Land Port Stockyard">Burimari Land Port Stockyard</option>
                <option value="Sonahat Yard No 2">Sonahat Yard No 2</option>
                <option value="Tejgaon Central Depot">Tejgaon Central Depot</option>
                <option value="Dhaka Central Warehouse">Dhaka Central Warehouse</option>
                <option value="Bogra Regional Depot">Bogra Regional Depot</option>
                <option value="Chittagong Depot">Chittagong Depot</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Notes / Remarks</label>
            <input
              type="text"
              disabled={isAlreadyVoided}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Weighbridge slip verified, quality checked"
              className="w-full border border-slate-300 rounded-xl p-2 bg-white disabled:bg-slate-100"
            />
          </div>

          {/* Admin Void & Re-entry Section */}
          {!isAlreadyVoided && isAdmin && (
            <div className="pt-2 border-t border-slate-200">
              {!showVoidConfirm ? (
                <button
                  type="button"
                  onClick={() => setShowVoidConfirm(true)}
                  className="w-full py-2 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Admin: Void Invoice &amp; Reverse Vouchers (For Re-entry)</span>
                </button>
              ) : (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-2.5">
                  <div className="font-bold text-rose-900 text-xs">
                    Void Purchase Invoice ({invoice.invoiceNumber})
                  </div>
                  <p className="text-[11px] text-rose-700">
                    This posts reversing ledger entries for the purchase voucher{invoice.paymentVoucherNumber ? ` and payment voucher (${invoice.paymentVoucherNumber})` : ''}, reverses stock inward, and marks this invoice as Voided.
                  </p>
                  <input
                    type="text"
                    value={voidReason}
                    onChange={(e) => setVoidReason(e.target.value)}
                    placeholder="Mandatory void reason (e.g. Incorrect quantity/rate or duplicate entry)..."
                    className="w-full border border-rose-300 rounded-lg p-2 bg-white text-slate-900 text-xs outline-none"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setShowVoidConfirm(false);
                        setVoidReason('');
                      }}
                      className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-700 font-semibold text-xs cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={isProcessing || !voidReason.trim()}
                      onClick={handleVoidAndReverseInvoice}
                      className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-300 text-white rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      {isProcessing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
                      <span>Confirm Void &amp; Reverse</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Footer Submit */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 transition-colors font-semibold"
            >
              Cancel
            </button>
            {!isAlreadyVoided && (
              <button
                type="submit"
                disabled={isProcessing}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                <span>Save Metadata</span>
              </button>
            )}
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
