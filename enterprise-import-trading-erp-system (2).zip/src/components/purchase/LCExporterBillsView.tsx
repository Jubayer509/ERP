import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Receipt, 
  Landmark, 
  Zap, 
  Coins, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  Ship, 
  Plus, 
  Trash2, 
  Printer, 
  AlertCircle, 
  Calendar, 
  Building2, 
  ShieldCheck, 
  Layers, 
  Scale, 
  FileText, 
  Check, 
  X,
  HelpCircle,
  MapPin,
  TrendingUp, 
  FileCheck,
  Search,
  ChevronDown,
  ShieldAlert,
  Loader2,
  Lock,
  Unlock,
  AlertTriangle,
  RotateCcw,
  Edit3,
  Sliders
} from 'lucide-react';
import { LetterOfCredit, LCRateBatch, LCBankSettlement, LCHundiPayment, BankAccount } from '../../types/erp';
import { AccountTransaction } from '../../types/accounts';
import { useAuth } from '../../contexts/AuthContext';
import { getBankAccounts, subscribeBankAccounts } from '../../utils/bankAccountStorage';
import { 
  postVoucher, 
  voidAccountTransaction, 
  getAccountTransactions, 
  subscribeAccountTransactions, 
  getOrCreateAccountHead 
} from '../../services/accountService';
import { computeLCProgressAndStatus, LCProgressStatus } from '../../utils/lcStatusHelper';
import { computeLcBill, ensureRateBatchesForBillableQty } from '../../utils/lcBillingHelper';
import { VoucherPrintModal } from '../accounts/VoucherPrintModal';
import { db } from '../../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

interface LCExporterBillsViewProps {
  lcs: LetterOfCredit[];
  selectedLc: LetterOfCredit;
  onSelectLc: (lc: LetterOfCredit) => void;
  onUpdateLc?: (updatedLc: LetterOfCredit) => void;
  onSettleBill?: (lcId: string, settlementNote: string) => void;
  onNavigateToExpenses?: () => void;
}

export const LCExporterBillsView: React.FC<LCExporterBillsViewProps> = ({
  lcs,
  selectedLc,
  onSelectLc,
  onUpdateLc,
  onSettleBill,
  onNavigateToExpenses
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';
  const userBranch = currentUser?.branch;

  // Real Bank Accounts and Transactions State
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  const [transactions, setTransactions] = useState<AccountTransaction[]>(() => getAccountTransactions());
  const [selectedTxnForView, setSelectedTxnForView] = useState<AccountTransaction | null>(null);

  useEffect(() => {
    const unsubBank = subscribeBankAccounts((accs) => setBankAccounts(accs));
    const unsubTxn = subscribeAccountTransactions((txns) => setTransactions(txns));
    return () => {
      unsubBank();
      unsubTxn();
    };
  }, []);

  // Filter accounts accessible by role & branch
  const accessibleAccounts = useMemo(() => {
    if (isAdmin) return bankAccounts;
    if (userBranch && userBranch !== 'All Branches') {
      return bankAccounts.filter(b => !b.branch || b.branch === userBranch || b.branch === 'All Branches');
    }
    return bankAccounts;
  }, [bankAccounts, isAdmin, userBranch]);

  // Compute live LC progress and statuses (Requirements A.1, A.2, A.3, D.2, D.4)
  const lcProgress: LCProgressStatus = useMemo(() => {
    return computeLCProgressAndStatus(selectedLc);
  }, [selectedLc]);

  // Navigation & Modal States
  const [showBankSettleModal, setShowBankSettleModal] = useState(false);
  const [showHundiPaymentModal, setShowHundiPaymentModal] = useState(false);
  const [showAddBatchModal, setShowAddBatchModal] = useState(false);
  const [showEditBatchModal, setShowEditBatchModal] = useState(false);
  const [editingBatch, setEditingBatch] = useState<LCRateBatch | null>(null);
  const [editBatchOfficialRate, setEditBatchOfficialRate] = useState<number>(0);
  const [editBatchActualRate, setEditBatchActualRate] = useState<number>(0);
  const [editBatchQuantity, setEditBatchQuantity] = useState<number>(0);
  const [editBatchNotes, setEditBatchNotes] = useState<string>('');
  const [showPrintStatementModal, setShowPrintStatementModal] = useState(false);
  const [activeSubSection, setActiveSubSection] = useState<'all' | 'bank_settle' | 'hundi_settle' | 'rate_batches'>('all');

  // Voiding modal state (Requirement E.1)
  const [voidTarget, setVoidTarget] = useState<{ type: 'bank' | 'hundi'; item: LCBankSettlement | LCHundiPayment } | null>(null);
  const [voidReason, setVoidReason] = useState('');
  const [isVoiding, setIsVoiding] = useState(false);
  const [voidError, setVoidError] = useState<string | null>(null);

  // Reopen LC modal state (Requirement D.5)
  const [showReopenModal, setShowReopenModal] = useState(false);
  const [reopenReason, setReopenReason] = useState('');
  const [isReopening, setIsReopening] = useState(false);
  const [reopenError, setReopenError] = useState<string | null>(null);

  // Prevent background scroll when any modal is open
  useEffect(() => {
    const isAnyModalOpen = 
      showHundiPaymentModal || 
      showBankSettleModal || 
      showAddBatchModal || 
      showEditBatchModal ||
      showPrintStatementModal || 
      !!voidTarget || 
      showReopenModal;
    if (isAnyModalOpen) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow || 'unset';
      };
    }
  }, [showHundiPaymentModal, showBankSettleModal, showAddBatchModal, showEditBatchModal, showPrintStatementModal, voidTarget, showReopenModal]);

  // -------------------------------------------------------------------------
  // Bank Settlement Form State (Requirement A.5: fields start clean/empty)
  // -------------------------------------------------------------------------
  const [bankSettleDate, setBankSettleDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [selectedBankAccountId, setSelectedBankAccountId] = useState<string>('');
  const [isBankDropdownOpen, setIsBankDropdownOpen] = useState(false);
  const [bankSearchTerm, setBankSearchTerm] = useState('');
  const bankDropdownRef = useRef<HTMLDivElement>(null);

  const [bankSettleAmountForeign, setBankSettleAmountForeign] = useState<string>('');
  const [bankSettleExchangeRate, setBankSettleExchangeRate] = useState<number>(0);
  const [bankSettleMarginAdjusted, setBankSettleMarginAdjusted] = useState<string>('');
  const [bankSettleSwiftRef, setBankSettleSwiftRef] = useState('');
  const [bankSettleNotes, setBankSettleNotes] = useState('');
  const [bankOverdraftApproved, setBankOverdraftApproved] = useState(false);
  const [isSavingBankSettle, setIsSavingBankSettle] = useState(false);
  const [bankSettleError, setBankSettleError] = useState<string | null>(null);

  // Selected Bank Account object
  const selectedBankAccount = useMemo(() => {
    return bankAccounts.find(b => b.id === selectedBankAccountId);
  }, [bankAccounts, selectedBankAccountId]);

  // Close bank dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (bankDropdownRef.current && !bankDropdownRef.current.contains(e.target as Node)) {
        setIsBankDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filtered bank accounts for dropdown search
  const filteredBankAccounts = useMemo(() => {
    if (!bankSearchTerm.trim()) return accessibleAccounts;
    const q = bankSearchTerm.toLowerCase();
    return accessibleAccounts.filter(b => 
      b.bankName.toLowerCase().includes(q) ||
      b.accountNumber.toLowerCase().includes(q) ||
      (b.branch && b.branch.toLowerCase().includes(q))
    );
  }, [accessibleAccounts, bankSearchTerm]);

  // Margin calculation: unadjusted margin remaining (Requirement B.2 & Requirement 4)
  const isMarginPosted = Boolean(
    selectedLc.marginVoucherNo || 
    selectedLc.marginStatus === 'accounted_earlier' ||
    selectedLc.marginStatus === 'external'
  );

  const activeBankSettlements = useMemo(() => {
    return (selectedLc.bankSettlements || []).filter(b => b.status !== 'Voided');
  }, [selectedLc.bankSettlements]);

  const marginAlreadyAdjusted = useMemo(() => {
    return activeBankSettlements.reduce((sum, b) => sum + (b.marginAdjustedBdt || 0), 0);
  }, [activeBankSettlements]);

  const maxMarginAvailable = useMemo(() => {
    if (!isMarginPosted) return 0;
    const totalMargin = selectedLc.marginAmountLocal || 0;
    return Math.max(0, totalMargin - marginAlreadyAdjusted);
  }, [selectedLc.marginAmountLocal, marginAlreadyAdjusted, isMarginPosted]);

  // Bank calculations
  const numBankForeign = parseFloat(bankSettleAmountForeign) || 0;
  const numBankMargin = parseFloat(bankSettleMarginAdjusted) || 0;
  const bankBdtGross = numBankForeign * (bankSettleExchangeRate || selectedLc.rateBdt || selectedLc.exchangeRate || 1);
  const bankNetDebit = Math.max(0, bankBdtGross - numBankMargin);
  const isBankOverdraft = selectedBankAccount && bankNetDebit > (selectedBankAccount.ledgerBalance || 0);

  // Reset Bank Settle Form
  const resetBankSettleForm = () => {
    setBankSettleDate(new Date().toISOString().split('T')[0]);
    setSelectedBankAccountId('');
    setBankSearchTerm('');
    setIsBankDropdownOpen(false);
    setBankSettleAmountForeign('');
    setBankSettleExchangeRate(0);
    setBankSettleMarginAdjusted('');
    setBankSettleSwiftRef('');
    setBankSettleNotes('');
    setBankOverdraftApproved(false);
    setBankSettleError(null);
  };

  // -------------------------------------------------------------------------
  // Hundi / Side-Payment Form State (Requirement A.5: opens clean/empty)
  // -------------------------------------------------------------------------
  const [hundiDate, setHundiDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [hundiRateBdtToInr, setHundiRateBdtToInr] = useState<number>(0);
  const [hundiAmountBdt, setHundiAmountBdt] = useState<string>('');
  const [hundiBroker, setHundiBroker] = useState('');
  const [hundiRecipient, setHundiRecipient] = useState('');
  const [hundiPaymentMode, setHundiPaymentMode] = useState<'Cash (BDT)' | 'Bank Transfer (BDT)' | 'Angadia / Hawala'>('' as any);
  const [selectedHundiAccountId, setSelectedHundiAccountId] = useState<string>('');
  const [isHundiAccountDropdownOpen, setIsHundiAccountDropdownOpen] = useState(false);
  const [hundiAccountSearchTerm, setHundiAccountSearchTerm] = useState('');
  const hundiDropdownRef = useRef<HTMLDivElement>(null);
  const [hundiReceiptToken, setHundiReceiptToken] = useState('');
  const [hundiNotes, setHundiNotes] = useState('');
  const [hundiOverdraftApproved, setHundiOverdraftApproved] = useState(false);
  const [isSavingHundi, setIsSavingHundi] = useState(false);
  const [hundiError, setHundiError] = useState<string | null>(null);

  // Selected Hundi Account object
  const selectedHundiAccount = useMemo(() => {
    return bankAccounts.find(b => b.id === selectedHundiAccountId);
  }, [bankAccounts, selectedHundiAccountId]);

  // Close hundi dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (hundiDropdownRef.current && !hundiDropdownRef.current.contains(e.target as Node)) {
        setIsHundiAccountDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Accounts prioritized by payment mode (Cash vs Bank Transfer)
  const filteredHundiAccounts = useMemo(() => {
    let list = accessibleAccounts;
    if (hundiAccountSearchTerm.trim()) {
      const q = hundiAccountSearchTerm.toLowerCase();
      list = list.filter(b => 
        b.bankName.toLowerCase().includes(q) ||
        b.accountNumber.toLowerCase().includes(q) ||
        (b.branch && b.branch.toLowerCase().includes(q))
      );
    }
    // Sort so matching category comes first
    const isCashMode = hundiPaymentMode === 'Cash (BDT)';
    return [...list].sort((a, b) => {
      const aIsCash = a.accountCategory === 'Cash' || a.accountType === 'Petty Cash' || a.accountType === 'POS Cash' || a.bankName.toLowerCase().includes('cash');
      const bIsCash = b.accountCategory === 'Cash' || b.accountType === 'Petty Cash' || b.accountType === 'POS Cash' || b.bankName.toLowerCase().includes('cash');
      if (isCashMode) {
        if (aIsCash && !bIsCash) return -1;
        if (!aIsCash && bIsCash) return 1;
      } else {
        if (!aIsCash && bIsCash) return -1;
        if (aIsCash && !bIsCash) return 1;
      }
      return 0;
    });
  }, [accessibleAccounts, hundiAccountSearchTerm, hundiPaymentMode]);

  // Check cash deficit or bank overdraft for Hundi
  const numHundiBdt = parseFloat(hundiAmountBdt) || 0;
  const isHundiCashAccount = selectedHundiAccount && (
    selectedHundiAccount.accountCategory === 'Cash' || 
    selectedHundiAccount.accountType === 'Petty Cash' || 
    selectedHundiAccount.accountType === 'POS Cash' ||
    selectedHundiAccount.bankName.toLowerCase().includes('cash')
  );
  const isHundiCashDeficit = isHundiCashAccount && numHundiBdt > (selectedHundiAccount?.ledgerBalance || 0);
  const isHundiBankOverdraft = !isHundiCashAccount && selectedHundiAccount && numHundiBdt > (selectedHundiAccount.ledgerBalance || 0);

  // Reset Hundi Form
  const resetHundiForm = () => {
    setHundiDate(new Date().toISOString().split('T')[0]);
    setHundiRateBdtToInr(0);
    setHundiAmountBdt('');
    setHundiBroker('');
    setHundiRecipient('');
    setHundiPaymentMode('' as any);
    setSelectedHundiAccountId('');
    setHundiAccountSearchTerm('');
    setIsHundiAccountDropdownOpen(false);
    setHundiReceiptToken('');
    setHundiNotes('');
    setHundiOverdraftApproved(false);
    setHundiError(null);
  };

  // -------------------------------------------------------------------------
  // Rate Batch Form State & Synchronization (Requirement 1 & 2)
  // -------------------------------------------------------------------------
  const [newBatchName, setNewBatchName] = useState('');
  const [newBatchQuantity, setNewBatchQuantity] = useState<number>(0);
  const [newBatchActualRate, setNewBatchActualRate] = useState<number>(0);
  const [newBatchNotes, setNewBatchNotes] = useState('');

  // 1. ONE SHARED BILLING FUNCTION (Requirement 1)
  const lcBill = useMemo(() => computeLcBill(selectedLc), [selectedLc]);
  const totalLcQuantity = lcBill.billableQty;
  const officialLcRate = lcBill.weightedOfficialRate || Number(selectedLc.officialLcRate || selectedLc.lcBankRateUsd || 14.00);
  const currSym = selectedLc.currency === 'INR' ? '₹' : '$';
  const exchangeRate = lcBill.exchangeRate;

  // 2. RATE BATCHES FOLLOW RECEIVED QUANTITY (Requirement 2)
  // Total quantity of all rate batches must equal billableQty.
  // When receivedQty is more than sum of batches, auto-creates "অতিরিক্ত রিসিভ (Extra Received)".
  const activeRateBatches: LCRateBatch[] = useMemo(() => {
    return ensureRateBatchesForBillableQty(selectedLc, lcBill.billableQty);
  }, [selectedLc, lcBill.billableQty]);

  const totalAllocatedBatchQuantity = activeRateBatches.reduce((acc, b) => acc + b.quantity, 0);
  const totalCommercialBillForeign = lcBill.commercialBillForeign;
  const weightedAverageCommercialRate = lcBill.weightedActualRate;

  // Computed metrics from live progress helper
  const {
    officialBankLcTotalForeign,
    totalBankSettledForeign,
    remainingBankDueForeign,
    isBankSettled,
    totalDifferentialGapBdt,
    totalHundiPaidBdt,
    remainingHundiDueBdt,
    isHundiSettled,
    isGoodsReceived,
    isClosed
  } = lcProgress;

  const officialBankLcTotalBdt = officialBankLcTotalForeign * exchangeRate;
  const totalBankSettledBdt = activeBankSettlements.reduce((acc, b) => acc + b.amountLocalBdt, 0);
  const totalDifferentialGapForeign = lcBill.hundiGapForeign;
  const totalDifferentialGapInr = hundiRateBdtToInr > 0 ? Math.round(totalDifferentialGapBdt / hundiRateBdtToInr) : 0;
  const remainingHundiDueInr = hundiRateBdtToInr > 0 ? Math.round(remainingHundiDueBdt / hundiRateBdtToInr) : 0;

  // Active Hundi Payments (non-voided)
  const activeHundiPayments = useMemo(() => {
    return (selectedLc.hundiPayments || []).filter(h => h.status !== 'Voided');
  }, [selectedLc.hundiPayments]);

  // -------------------------------------------------------------------------
  // HANDLERS
  // -------------------------------------------------------------------------

  // 1. Rate Batch Handlers (Requirement 2)
  const handleAddRateBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (newBatchQuantity <= 0) return;

    const rateDiff = Math.max(0, newBatchActualRate - officialLcRate);
    const totalComm = newBatchQuantity * newBatchActualRate;
    const totalOff = newBatchQuantity * officialLcRate;
    const totalDiff = newBatchQuantity * rateDiff;

    const newBatch: LCRateBatch = {
      id: `rb-${Date.now()}`,
      batchName: newBatchName,
      quantity: newBatchQuantity,
      uom: selectedLc.uom || 'MT',
      officialRate: officialLcRate,
      actualRate: newBatchActualRate,
      rateDifference: rateDiff,
      totalCommercialAmount: totalComm,
      totalOfficialAmount: totalOff,
      differentialAmount: totalDiff,
      notes: newBatchNotes,
      date: new Date().toISOString().split('T')[0]
    };

    // Filter out previous auto-batch so ensureRateBatchesForBillableQty recalculates it
    const manualBatches = activeRateBatches.filter(b => !b.isAuto);
    const updatedBatches = [...manualBatches, newBatch];
    const baseLc: LetterOfCredit = {
      ...selectedLc,
      rateBatches: updatedBatches
    };

    const bill = computeLcBill(baseLc);
    const synchronizedBatches = ensureRateBatchesForBillableQty(baseLc, bill.billableQty);
    const nextProgress = computeLCProgressAndStatus({
      ...baseLc,
      rateBatches: synchronizedBatches
    });
    const updatedLc: LetterOfCredit = {
      ...baseLc,
      rateBatches: synchronizedBatches,
      status: nextProgress.computedStatus
    };

    if (onUpdateLc) onUpdateLc(updatedLc);
    setShowAddBatchModal(false);
  };

  const handleStartEditBatch = (batch: LCRateBatch) => {
    setEditingBatch(batch);
    setEditBatchOfficialRate(batch.officialRate);
    setEditBatchActualRate(batch.actualRate);
    setEditBatchQuantity(batch.quantity);
    setEditBatchNotes(batch.notes || '');
    setShowEditBatchModal(true);
  };

  const handleSaveEditBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBatch) return;

    const rateDiff = Math.max(0, editBatchActualRate - editBatchOfficialRate);
    const updatedBatches = activeRateBatches.map(b => {
      if (b.id === editingBatch.id) {
        const q = editingBatch.isAuto ? editingBatch.quantity : (editBatchQuantity > 0 ? editBatchQuantity : b.quantity);
        return {
          ...b,
          officialRate: editBatchOfficialRate,
          actualRate: editBatchActualRate,
          rateDifference: rateDiff,
          quantity: q,
          totalOfficialAmount: q * editBatchOfficialRate,
          totalCommercialAmount: q * editBatchActualRate,
          differentialAmount: q * rateDiff,
          notes: editBatchNotes
        };
      }
      return b;
    });

    const baseLc: LetterOfCredit = {
      ...selectedLc,
      rateBatches: updatedBatches
    };

    const bill = computeLcBill(baseLc);
    const synchronizedBatches = ensureRateBatchesForBillableQty(baseLc, bill.billableQty);
    const nextProgress = computeLCProgressAndStatus({
      ...baseLc,
      rateBatches: synchronizedBatches
    });
    const updatedLc: LetterOfCredit = {
      ...baseLc,
      rateBatches: synchronizedBatches,
      status: nextProgress.computedStatus
    };

    if (onUpdateLc) onUpdateLc(updatedLc);
    setShowEditBatchModal(false);
    setEditingBatch(null);
  };

  const handleDeleteRateBatch = (batchId: string) => {
    if (activeRateBatches.length <= 1) {
      alert('কমপক্ষে একটি রেট ব্যাচ বা স্ল্যাব থাকা বাধ্যতামূলক।');
      return;
    }
    const filtered = activeRateBatches.filter(b => b.id !== batchId && !b.isAuto);
    const baseLc: LetterOfCredit = {
      ...selectedLc,
      rateBatches: filtered
    };

    const bill = computeLcBill(baseLc);
    const synchronizedBatches = ensureRateBatchesForBillableQty(baseLc, bill.billableQty);
    const nextProgress = computeLCProgressAndStatus({
      ...baseLc,
      rateBatches: synchronizedBatches
    });
    const updatedLc: LetterOfCredit = {
      ...baseLc,
      rateBatches: synchronizedBatches,
      status: nextProgress.computedStatus
    };

    if (onUpdateLc) onUpdateLc(updatedLc);
  };

  // Requirement 3: Official Bank Bill Switch with Audit Log
  const handleToggleBankBillSetting = (newSetting: 'follow_received' | 'cap_at_lc') => {
    if (!isAdmin) {
      alert('এই সেটিং পরিবর্তনের অনুমতি শুধুমাত্র অ্যাডমিনের রয়েছে।');
      return;
    }
    const oldSetting = selectedLc.bankBillForExtraQty || 'follow_received';
    if (oldSetting === newSetting) return;

    const baseLc: LetterOfCredit = {
      ...selectedLc,
      bankBillForExtraQty: newSetting,
      auditLogs: [
        ...(selectedLc.auditLogs || []),
        {
          id: `audit-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: currentUser?.name || 'Admin',
          action: 'Bank bill for extra quantity setting updated',
          details: `Changed setting from "${oldSetting}" to "${newSetting}"`
        }
      ]
    };

    const bill = computeLcBill(baseLc);
    const synchronizedBatches = ensureRateBatchesForBillableQty(baseLc, bill.billableQty);
    const nextProgress = computeLCProgressAndStatus({
      ...baseLc,
      rateBatches: synchronizedBatches
    });
    const updatedLc: LetterOfCredit = {
      ...baseLc,
      rateBatches: synchronizedBatches,
      status: nextProgress.computedStatus
    };

    if (onUpdateLc) onUpdateLc(updatedLc);
  };

  // 2. Bank Settlement Submission (Requirements A.1, A.4, B.1, B.2, B.3, B.4, B.5, B.6, D.1, D.2, D.3)
  const handleRecordBankSettlement = async (e: React.FormEvent) => {
    e.preventDefault();
    setBankSettleError(null);

    // Validation
    if (isClosed) {
      setBankSettleError('This LC is Costed & Closed. New bank settlements are not allowed.');
      return;
    }

    if (!selectedBankAccount) {
      setBankSettleError('Please select a Bank Account for settlement');
      return;
    }

    if (numBankForeign <= 0) {
      setBankSettleError('Payment foreign currency amount must be greater than zero.');
      return;
    }

    if (numBankForeign > remainingBankDueForeign + 0.001) {
      setBankSettleError(`Payment amount cannot exceed remaining balance (${currSym}${remainingBankDueForeign.toLocaleString()}).`);
      return;
    }

    if (!isMarginPosted) {
      setBankSettleError('Cannot settle: LC margin has not been posted or marked paid');
      return;
    }

    if (numBankMargin > maxMarginAvailable + 0.001) {
      setBankSettleError(`Margin adjustment cannot exceed available margin balance (৳${maxMarginAvailable.toLocaleString()}).`);
      return;
    }

    if (numBankMargin > bankBdtGross) {
      setBankSettleError('Margin adjustment cannot exceed gross BDT bill amount.');
      return;
    }

    if (isBankOverdraft && !isAdmin) {
      setBankSettleError('Insufficient bank balance. Admin authorization required for overdraft.');
      return;
    }

    if (isBankOverdraft && isAdmin && !bankOverdraftApproved) {
      setBankSettleError('Please check the admin overdraft approval box.');
      return;
    }

    setIsSavingBankSettle(true);

    try {
      // Find or create account heads (Requirement B.3)
      const lcPayableHead = await getOrCreateAccountHead(
        'LC Payable (Exporter)',
        'EXP-LC-PAY',
        'Expense',
        'Foreign exporter bills settlement against import documentary credit'
      );

      const lcMarginHead = await getOrCreateAccountHead(
        'LC Margin Deposit',
        'OTH-LC-MRG',
        'Other',
        'Bank LC cash margin held and adjusted against final retirement of import bills'
      );

      // Narration format (Requirement B.4)
      const swiftNote = bankSettleSwiftRef.trim() ? `Swift: ${bankSettleSwiftRef.trim()}` : 'Swift: N/A';
      const voucherNarration = `LC ${selectedLc.lcNumber} Bank Settle - ${currSym}${numBankForeign.toLocaleString()} ${selectedLc.currency || 'USD'} @ ৳${bankSettleExchangeRate} (${swiftNote}, Exporter: ${selectedLc.supplierName})`;

      // Call single posting function in accountService (Requirement B.3, B.4)
      const postedTxn = await postVoucher({
        transactionType: 'PAYMENT',
        subType: 'Expense / General Payment',
        date: bankSettleDate,
        amount: bankNetDebit, // Net credit to bank account
        bankAccountId: selectedBankAccountId,
        paymentMethod: 'Bank Transfer',
        referenceNo: bankSettleSwiftRef.trim() ? `${bankSettleSwiftRef.trim()} (LC ${selectedLc.lcNumber})` : `LC ${selectedLc.lcNumber}`,
        note: voucherNarration,
        costCenter: 'LC Import Banking',
        branch: selectedBankAccount.branch || selectedLc.branch || 'Head Office',
        accountHeadId: lcPayableHead.id,
        accountHeadName: lcPayableHead.name,
        accountHeadCode: lcPayableHead.code,
        debitLines: [
          {
            accountCode: lcPayableHead.code || 'EXP-LC-PAY',
            particulars: `LC ${selectedLc.lcNumber} - ${currSym}${numBankForeign.toLocaleString()} @ ৳${bankSettleExchangeRate} (Exporter: ${selectedLc.supplierName})`,
            amount: bankBdtGross
          }
        ],
        creditLines: numBankMargin > 0 ? [
          {
            accountCode: lcMarginHead.code || 'OTH-LC-MRG',
            particulars: `LC ${selectedLc.lcNumber} - Margin Deposit Adjusted against import retirement`,
            amount: numBankMargin
          }
        ] : [],
        user: {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || 'Authorized Officer',
          email: currentUser?.email || 'admin@tradecore.local'
        },
        adminApprovedOverdraft: isBankOverdraft && isAdmin && bankOverdraftApproved
      });

      // Construct record (Requirement B.6)
      const newRecord: LCBankSettlement = {
        id: `bs-${Date.now()}`,
        settlementDate: bankSettleDate,
        bankName: selectedBankAccount.bankName,
        branch: selectedBankAccount.branch,
        debitAccount: `${selectedBankAccount.bankName} (${selectedBankAccount.accountNumber})`,
        bankAccountId: selectedBankAccount.id,
        bankAccountName: selectedBankAccount.bankName,
        amountForeign: numBankForeign,
        currency: selectedLc.currency || 'USD',
        exchangeRate: bankSettleExchangeRate,
        amountLocalBdt: bankBdtGross,
        marginAdjustedBdt: numBankMargin,
        netPaidBdt: bankNetDebit,
        swiftRef: bankSettleSwiftRef.trim() || undefined,
        voucherNumber: postedTxn.voucherNo,
        voucherNo: postedTxn.voucherNo,
        transactionId: postedTxn.id,
        postedBy: currentUser?.name || 'Authorized User',
        postedAt: new Date().toISOString(),
        notes: bankSettleNotes.trim() || undefined,
        status: 'Settled'
      };

      const updatedSettlements = [...(selectedLc.bankSettlements || []), newRecord];
      const baseLc: LetterOfCredit = {
        ...selectedLc,
        bankSettlements: updatedSettlements
      };

      // Recompute status (Requirement D.2, D.3)
      const nextProgress = computeLCProgressAndStatus(baseLc);
      const updatedLc: LetterOfCredit = {
        ...baseLc,
        status: nextProgress.computedStatus
      };

      if (onUpdateLc) onUpdateLc(updatedLc);
      if (onSettleBill) {
        onSettleBill(
          selectedLc.id,
          `Bank Settle: ${currSym}${numBankForeign.toLocaleString()} settled via ${selectedBankAccount.bankName} (Voucher: ${postedTxn.voucherNo})`
        );
      }

      resetBankSettleForm();
      setShowBankSettleModal(false);
    } catch (err: any) {
      console.error('Bank settlement posting error:', err);
      setBankSettleError(err.message || 'Bank settlement voucher posting failed.');
    } finally {
      setIsSavingBankSettle(false);
    }
  };

  // 3. Hundi Payment Submission (Requirements A.2, A.4, C.1, C.2, C.3, D.1, D.2, D.3)
  const handleRecordHundiPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setHundiError(null);

    if (isClosed) {
      setHundiError('এই এলসিটি সম্পূর্ণ ক্লোজড (Costed & Closed)। ক্লোজড এলসিতে নতুন হুন্ডি পেমেন্ট সম্পূর্ণ নিষিদ্ধ।');
      return;
    }

    if (!selectedHundiAccount) {
      setHundiError('পরিশোধের জন্য ক্যাশ বা ব্যাংক অ্যাকাউন্ট নির্বাচন আবশ্যক (Please select Paid From account)');
      return;
    }

    if (numHundiBdt <= 0) {
      setHundiError('হুন্ডি পরিশোধের পরিমাণ অবশ্যই শূন্যের চেয়ে বেশি হতে হবে।');
      return;
    }

    if (numHundiBdt > remainingHundiDueBdt + 1) {
      setHundiError(`হুন্ডি পরিশোধের পরিমাণ বর্তমান অবশিষ্ট বকেয়া (৳${remainingHundiDueBdt.toLocaleString()}) এর চেয়ে বেশি হতে পারবে না।`);
      return;
    }

    if (isHundiCashDeficit) {
      setHundiError(`ক্যাশ অ্যাকাউন্টে অপর্যাপ্ত ব্যালেন্স। বর্তমান ব্যালেন্স ৳${(selectedHundiAccount?.ledgerBalance || 0).toLocaleString()}, কিন্তু পেমেন্ট ৳${numHundiBdt.toLocaleString()}। ক্যাশ ব্যালেন্স ঋণাত্মক হতে পারবে না।`);
      return;
    }

    if (isHundiBankOverdraft && !isAdmin) {
      setHundiError('ব্যাংক অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই। ওভারড্রাফট পেমেন্ট অনুমোদনের জন্য অ্যাডমিন এক্সেস প্রয়োজন।');
      return;
    }

    if (isHundiBankOverdraft && isAdmin && !hundiOverdraftApproved) {
      setHundiError('ব্যাংক ওভারড্রাফটের কারণে অনুগ্রহ করে অ্যাডমিন অনুমোদন চেকবাক্সে টিক দিন।');
      return;
    }

    setIsSavingHundi(true);

    try {
      // Find or create LC Hundi head (Requirement C.3)
      const lcHundiHead = await getOrCreateAccountHead(
        'LC Hundi / Side-Payment',
        'EXP-LC-HND',
        'Expense',
        'Unofficial side payment or commercial differential gap settled through hundi'
      );

      const inrAmount = hundiRateBdtToInr > 0 ? Math.round(numHundiBdt / hundiRateBdtToInr) : 0;
      const usdEq = exchangeRate > 0 ? (numHundiBdt / exchangeRate) : 0;
      const tokenNote = hundiReceiptToken.trim() ? `Token: ${hundiReceiptToken.trim()}` : 'Token: N/A';
      const voucherNarration = `LC ${selectedLc.lcNumber} - Hundi / Side-Payment (${tokenNote}, Exporter: ${selectedLc.supplierName}, ₹${inrAmount.toLocaleString()} IC RS @ ${hundiRateBdtToInr})`;

      // Post ONE voucher atomically (Requirement C.3)
      const postedTxn = await postVoucher({
        transactionType: 'PAYMENT',
        subType: 'Expense / General Payment',
        date: hundiDate,
        amount: numHundiBdt,
        bankAccountId: selectedHundiAccountId,
        paymentMethod: isHundiCashAccount ? 'Cash' : 'Bank Transfer',
        referenceNo: hundiReceiptToken.trim() ? `${hundiReceiptToken.trim()} (LC ${selectedLc.lcNumber})` : `LC ${selectedLc.lcNumber}`,
        note: voucherNarration,
        costCenter: 'LC Commercial Differential',
        branch: selectedHundiAccount.branch || selectedLc.branch || 'Head Office',
        accountHeadId: lcHundiHead.id,
        accountHeadName: lcHundiHead.name,
        accountHeadCode: lcHundiHead.code,
        debitLines: [
          {
            accountCode: lcHundiHead.code || 'EXP-LC-HND',
            particulars: `LC ${selectedLc.lcNumber} Hundi - ৳${numHundiBdt.toLocaleString()} (₹${inrAmount.toLocaleString()} IC RS @ ${hundiRateBdtToInr})`,
            amount: numHundiBdt
          }
        ],
        user: {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || 'Authorized Officer',
          email: currentUser?.email || 'admin@tradecore.local'
        },
        adminApprovedOverdraft: isHundiBankOverdraft && isAdmin && hundiOverdraftApproved
      });

      // Construct record (Requirement C.3)
      const newHundiRecord: LCHundiPayment = {
        id: `hnd-${Date.now()}`,
        paymentDate: hundiDate,
        amountBdt: numHundiBdt,
        hundiRateBdtToInr: hundiRateBdtToInr,
        amountInr: inrAmount,
        usdDifferentialEquivalent: usdEq,
        hundiBroker: hundiBroker.trim() || 'Direct Exporter Settlement',
        recipientParty: hundiRecipient.trim() || selectedLc.supplierName,
        paymentMode: hundiPaymentMode,
        paidFromAccountId: selectedHundiAccount.id,
        paidFromAccountName: selectedHundiAccount.bankName,
        receiptToken: hundiReceiptToken.trim() || undefined,
        voucherNo: postedTxn.voucherNo,
        transactionId: postedTxn.id,
        postedBy: currentUser?.name || 'Authorized User',
        postedAt: new Date().toISOString(),
        notes: hundiNotes.trim() || undefined,
        status: 'Paid'
      };

      const updatedHundi = [...(selectedLc.hundiPayments || []), newHundiRecord];
      const baseLc: LetterOfCredit = {
        ...selectedLc,
        hundiPayments: updatedHundi
      };

      // Recompute status (Requirement D.2, D.3)
      const nextProgress = computeLCProgressAndStatus(baseLc);
      const updatedLc: LetterOfCredit = {
        ...baseLc,
        status: nextProgress.computedStatus
      };

      if (onUpdateLc) onUpdateLc(updatedLc);

      resetHundiForm();
      setShowHundiPaymentModal(false);
    } catch (err: any) {
      console.error('Hundi payment posting error:', err);
      setHundiError(err.message || 'হুন্ডি পেমেন্ট ভাউচার পোস্টিং ব্যর্থ হয়েছে।');
    } finally {
      setIsSavingHundi(false);
    }
  };

  // 4. Void Handler (Requirement E.1, E.2)
  const handleExecuteVoid = async () => {
    if (!voidTarget) return;
    if (!voidReason.trim()) {
      setVoidError('Void reason is required');
      return;
    }

    setIsVoiding(true);
    setVoidError(null);

    try {
      const { type, item } = voidTarget;

      // If linked voucher exists in Accounts, post reversing voucher via voidAccountTransaction
      if (item.transactionId) {
        await voidAccountTransaction(
          item.transactionId,
          voidReason.trim(),
          {
            uid: currentUser?.uid || 'admin',
            name: currentUser?.name || 'Admin Officer',
            email: currentUser?.email || 'admin@tradecore.local'
          }
        );
      }

      let updatedLc: LetterOfCredit;
      const nowIso = new Date().toISOString();

      if (type === 'bank') {
        const nextSettlements = (selectedLc.bankSettlements || []).map(b => {
          if (b.id === item.id) {
            return {
              ...b,
              status: 'Voided' as const,
              voidReason: voidReason.trim(),
              voidedBy: currentUser?.name || 'Admin',
              voidedAt: nowIso
            };
          }
          return b;
        });

        const baseLc: LetterOfCredit = {
          ...selectedLc,
          bankSettlements: nextSettlements
        };

        const nextProgress = computeLCProgressAndStatus(baseLc);
        updatedLc = {
          ...baseLc,
          status: nextProgress.computedStatus
        };
      } else {
        const nextHundi = (selectedLc.hundiPayments || []).map(h => {
          if (h.id === item.id) {
            return {
              ...h,
              status: 'Voided' as const,
              voidReason: voidReason.trim(),
              voidedBy: currentUser?.name || 'Admin',
              voidedAt: nowIso
            };
          }
          return h;
        });

        const baseLc: LetterOfCredit = {
          ...selectedLc,
          hundiPayments: nextHundi
        };

        const nextProgress = computeLCProgressAndStatus(baseLc);
        updatedLc = {
          ...baseLc,
          status: nextProgress.computedStatus
        };
      }

      if (onUpdateLc) onUpdateLc(updatedLc);
      setVoidTarget(null);
      setVoidReason('');
    } catch (err: any) {
      console.error('Void error:', err);
      setVoidError(err.message || 'Voucher voiding failed.');
    } finally {
      setIsVoiding(false);
    }
  };

  // 5. Reopen LC Handler (Requirement D.5)
  const handleExecuteReopen = async () => {
    if (!reopenReason.trim()) {
      setReopenError('Reason is required to re-open LC');
      return;
    }

    setIsReopening(true);
    setReopenError(null);

    try {
      const nowIso = new Date().toISOString();
      const adminName = currentUser?.name || 'Admin Officer';

      // Write security audit log to Firestore
      const auditRef = doc(db, 'audit_logs', `audit-reopen-lc-${Date.now()}`);
      await setDoc(auditRef, {
        userId: currentUser?.uid || 'admin',
        userEmail: currentUser?.email || 'admin@tradecore.local',
        action: 'REOPEN_CLOSED_LC',
        timestamp: nowIso,
        details: `Reopened Closed LC ${selectedLc.lcNumber}. Reason: ${reopenReason.trim()}`
      });

      const newLogs = [
        ...(selectedLc.reopenLogs || []),
        {
          reopenedAt: nowIso,
          reopenedBy: adminName,
          reason: reopenReason.trim()
        }
      ];

      // Revert status to nearest active stage
      const fallbackStatus = isGoodsReceived ? 'GRN Received' : 'Opened / Margin Paid';
      const updatedLc: LetterOfCredit = {
        ...selectedLc,
        status: fallbackStatus,
        reopenLogs: newLogs
      };

      if (onUpdateLc) onUpdateLc(updatedLc);
      setShowReopenModal(false);
      setReopenReason('');
    } catch (err: any) {
      console.error('Reopen LC error:', err);
      setReopenError(err.message || 'Re-opening LC failed.');
    } finally {
      setIsReopening(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Instrument Selector, Progress Chips & Actions */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1.5">
              <span className="text-[11px] font-black uppercase tracking-wider bg-indigo-100 text-indigo-800 px-3 py-0.5 rounded-full font-mono flex items-center gap-1">
                <Receipt className="w-3.5 h-3.5 text-indigo-600" />
                Exporter Bills & Dual LC Settlement Engine
              </span>
              <span className="text-xs bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-md font-bold flex items-center gap-1">
                <MapPin className="w-3 h-3 text-rose-500" />
                Entry Port: {selectedLc.borderLandPort ? `${selectedLc.borderLandPort} Land Port` : 'Burimari Land Port'}
              </span>
              <span className="text-xs text-slate-500">
                • {selectedLc.originQuarryItem || selectedLc.boulderCategory || 'Boulder Stone Import'}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
                <span>LC Payment & Exporter Bills Settlement</span>
                <span className="text-sm font-mono font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-xl border border-blue-200">
                  {selectedLc.lcNumber}
                </span>
              </h2>

              {/* Status Badge */}
              <span className={`text-xs font-bold px-3 py-1 rounded-xl border flex items-center gap-1.5 ${
                isClosed
                  ? 'bg-emerald-100 text-emerald-900 border-emerald-300 font-black'
                  : 'bg-blue-50 text-blue-800 border-blue-200'
              }`}>
                {isClosed ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-blue-600" />}
                <span>{selectedLc.status}</span>
              </span>

              {/* Admin Reopen Action (Requirement D.5) */}
              {isClosed && isAdmin && (
                <button
                  type="button"
                  onClick={() => setShowReopenModal(true)}
                  className="px-3 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Reopen this closed LC for corrections"
                >
                  <Unlock className="w-3.5 h-3.5 text-amber-700" />
                  <span>Reopen LC</span>
                </button>
              )}
            </div>

            {/* Requirement D.4: Three Progress Chips (Goods Received, Bank Settled, Hundi Settled) */}
            <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono mr-1">
                LC Lifecycle Progress:
              </span>

              {/* Chip 1: Goods Received */}
              <div className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 border ${
                isGoodsReceived 
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                  : 'bg-slate-50 text-slate-600 border-slate-200'
              }`}>
                {isGoodsReceived ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                )}
                <span>Goods Received</span>
                <span className="font-mono text-[10px] ml-0.5 opacity-80">
                  ({(selectedLc.receivedQuantity || 0).toLocaleString()}/{totalLcQuantity.toLocaleString()} {selectedLc.uom || 'MT'})
                </span>
              </div>

              {/* Chip 2: Bank Settled */}
              <div className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 border ${
                isBankSettled 
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                  : 'bg-slate-50 text-slate-600 border-slate-200'
              }`}>
                {isBankSettled ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                )}
                <span>Bank Settled</span>
                <span className="font-mono text-[10px] ml-0.5 opacity-80">
                  ({currSym}{totalBankSettledForeign.toLocaleString()}/{currSym}{officialBankLcTotalForeign.toLocaleString()})
                </span>
              </div>

              {/* Chip 3: Hundi Settled */}
              <div className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 border ${
                isHundiSettled 
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                  : 'bg-slate-50 text-slate-600 border-slate-200'
              }`}>
                {isHundiSettled ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                )}
                <span>Hundi Settled</span>
                {totalDifferentialGapBdt > 0 && (
                  <span className="font-mono text-[10px] ml-0.5 opacity-80">
                    (৳{totalHundiPaidBdt.toLocaleString()}/৳{totalDifferentialGapBdt.toLocaleString()})
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Target Instrument Selector */}
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-2xl px-3 py-2">
              <span className="text-xs font-bold text-slate-500 font-mono">Select LC:</span>
              <select
                value={selectedLc.id}
                onChange={(e) => {
                  const found = lcs.find(l => l.id === e.target.value);
                  if (found) onSelectLc(found);
                }}
                className="bg-transparent text-xs font-black font-mono text-indigo-700 focus:outline-none cursor-pointer max-w-xs truncate"
              >
                {lcs.map(l => (
                  <option key={l.id} value={l.id}>
                    {l.lcNumber} - {l.supplierName} ({currSym}{l.cfrAmount.toLocaleString()})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={() => setShowPrintStatementModal(true)}
              className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              Print Statement
            </button>

            {onNavigateToExpenses && (
              <button
                type="button"
                onClick={onNavigateToExpenses}
                className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Ship className="w-3.5 h-3.5 text-slate-500" />
                Landed Cost & Duty
              </button>
            )}
          </div>
        </div>

        {/* Closed Banner if Costed & Closed */}
        {isClosed && (
          <div className="mt-4 p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <strong className="block font-bold">LC Costed & Closed</strong>
                <span>Goods fully received, bank bill settled, and commercial differential settled.</span>
              </div>
            </div>
          </div>
        )}

        {/* Requirement 5: Additional Due Banner if extra receiving created new balance due */}
        {lcBill.totalAdditionalDueBdt > 0 && (lcBill.excessQty > 0 || isGoodsReceived) && (
          <div className="mt-4 p-4 bg-amber-50 border-2 border-amber-400 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-950 shadow-sm animate-in fade-in">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />
              <div>
                <strong className="block text-sm font-bold text-amber-900 font-mono">
                  Additional due: ৳{Math.round(lcBill.totalAdditionalDueBdt).toLocaleString()} BDT
                </strong>
                <span className="text-[11px] leading-relaxed">
                  Additional balance due created from excess goods receiving — Bank due: <strong className="font-mono">{currSym}{lcBill.remainingBankDueForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong> and Hundi due: <strong className="font-mono">৳{Math.round(lcBill.remainingHundiDueBdt).toLocaleString()}</strong>. Relevant settlement buttons are active.
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {lcBill.remainingBankDueForeign > 0.05 && (
                <button
                  type="button"
                  onClick={() => {
                    resetBankSettleForm();
                    setBankSettleAmountForeign(String(lcBill.remainingBankDueForeign));
                    setShowBankSettleModal(true);
                  }}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold font-mono transition-colors shadow-2xs cursor-pointer whitespace-nowrap text-xs"
                >
                  Settle Bank ({currSym}{lcBill.remainingBankDueForeign.toLocaleString()})
                </button>
              )}
              {lcBill.remainingHundiDueBdt > 5 && (
                <button
                  type="button"
                  onClick={() => {
                    resetHundiForm();
                    setHundiAmountBdt(String(Math.round(lcBill.remainingHundiDueBdt)));
                    setShowHundiPaymentModal(true);
                  }}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold font-mono transition-colors shadow-2xs cursor-pointer whitespace-nowrap text-xs"
                >
                  Pay Hundi (৳{Math.round(lcBill.remainingHundiDueBdt).toLocaleString()})
                </button>
              )}
            </div>
          </div>
        )}

        {/* Requirement 6: Comparison Table & Requirement 3: Bank Bill for Extra Quantity Switch */}
        <div className="mt-4 bg-slate-50/90 border border-slate-200 rounded-2xl p-4 space-y-3 shadow-2xs">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div className="flex items-center gap-2 flex-wrap">
              <Scale className="w-4 h-4 text-indigo-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 font-mono">
                Contract vs Received vs Billed Comparison
              </h3>
              {lcBill.excessQty > 0 && (
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-mono animate-pulse">
                  +{lcBill.excessQty.toLocaleString()} MT Excess Received
                </span>
              )}
            </div>

            {/* Requirement 3: Official Bank Bill Switch */}
            <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-300 text-xs shadow-2xs">
              <Sliders className="w-3.5 h-3.5 text-indigo-600" />
              <span className="font-bold text-slate-700 font-sans">Bank bill for extra quantity:</span>
              <div className="flex items-center gap-1 font-sans">
                <button
                  type="button"
                  onClick={() => handleToggleBankBillSetting('follow_received')}
                  disabled={!isAdmin}
                  className={`px-2 py-0.5 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                    (selectedLc.bankBillForExtraQty || 'follow_received') === 'follow_received'
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                  title={!isAdmin ? 'Admin only setting' : 'Follow received quantity: officialBill = billableQty x official rate'}
                >
                  Follow received quantity (Default)
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleBankBillSetting('cap_at_lc')}
                  disabled={!isAdmin}
                  className={`px-2 py-0.5 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                    selectedLc.bankBillForExtraQty === 'cap_at_lc'
                      ? 'bg-indigo-700 text-white shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                  title={!isAdmin ? 'Admin only setting' : 'Cap at LC amount: officialBill stays at contractQty x official rate; extra quantity goes to commercial bill only'}
                >
                  Cap at LC amount
                </button>
              </div>
              {!isAdmin && (
                <span className="text-[10px] text-slate-400 font-sans italic flex items-center gap-0.5">
                  <Lock className="w-2.5 h-2.5" /> (Admin only)
                </span>
              )}
            </div>
          </div>

          {/* Comparison Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono border-collapse">
              <thead>
                <tr className="bg-slate-100/90 text-slate-700 font-bold border-b border-slate-200">
                  <th className="py-2 px-3 font-sans">Metric</th>
                  <th className="py-2 px-3 text-right">Contract</th>
                  <th className="py-2 px-3 text-right">Received</th>
                  <th className="py-2 px-3 text-right">Billed</th>
                  <th className={`py-2 px-3 text-right font-black ${
                    lcBill.excessQty > 0 ? 'bg-amber-100 text-amber-950 font-bold border-l border-amber-300' : 'text-slate-500'
                  }`}>
                    Excess Quantity
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/80 bg-white">
                <tr>
                  <td className="py-2 px-3 font-bold text-slate-800 font-sans">
                    1. Material Weight / Quantity
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-slate-700">
                    {lcBill.contractQty.toLocaleString()} MT
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-slate-700">
                    {lcBill.receivedQty.toLocaleString()} MT
                  </td>
                  <td className="py-2 px-3 text-right font-black text-indigo-900 bg-indigo-50/40">
                    {lcBill.billableQty.toLocaleString()} MT
                  </td>
                  <td className={`py-2 px-3 text-right font-black ${
                    lcBill.excessQty > 0 ? 'bg-amber-100/90 text-amber-950 border-l border-amber-300' : 'text-slate-400'
                  }`}>
                    {lcBill.excessQty > 0 ? `+${lcBill.excessQty.toLocaleString()} MT (+${lcBill.excessPercent.toFixed(1)}%)` : '0 MT'}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-bold text-slate-800 font-sans">
                    2. Official Bank Bill
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-slate-700">
                    {currSym}{(lcBill.contractQty * lcBill.weightedOfficialRate).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-slate-700">
                    {currSym}{((selectedLc.bankBillForExtraQty === 'cap_at_lc' && lcBill.receivedQty > lcBill.contractQty ? lcBill.contractQty : lcBill.receivedQty) * lcBill.weightedOfficialRate).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="py-2 px-3 text-right font-black text-blue-900 bg-blue-50/40">
                    {currSym}{lcBill.officialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    <span className="block text-[10px] text-blue-700 font-normal">
                      ৳{Math.round(lcBill.officialBillBdt).toLocaleString()}
                    </span>
                  </td>
                  <td className={`py-2 px-3 text-right font-black ${
                    lcBill.excessQty > 0 ? 'bg-amber-100/90 text-amber-950 border-l border-amber-300' : 'text-slate-400'
                  }`}>
                    {lcBill.excessQty > 0 ? (
                      selectedLc.bankBillForExtraQty === 'cap_at_lc' ? (
                        <span className="text-[10px] text-slate-500 font-sans italic">Capped at LC ($0)</span>
                      ) : (
                        `+${currSym}${(lcBill.excessQty * lcBill.weightedOfficialRate).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                      )
                    ) : '$0.00'}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-bold text-slate-800 font-sans">
                    3. Commercial Bill
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-slate-700">
                    {currSym}{(lcBill.contractQty * lcBill.weightedActualRate).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-slate-700">
                    {currSym}{(lcBill.receivedQty * lcBill.weightedActualRate).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="py-2 px-3 text-right font-black text-slate-950 bg-slate-100/50">
                    {currSym}{lcBill.commercialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    <span className="block text-[10px] text-slate-600 font-normal">
                      ৳{Math.round(lcBill.commercialBillBdt).toLocaleString()}
                    </span>
                  </td>
                  <td className={`py-2 px-3 text-right font-black ${
                    lcBill.excessQty > 0 ? 'bg-amber-100/90 text-amber-950 border-l border-amber-300' : 'text-slate-400'
                  }`}>
                    {lcBill.excessQty > 0 ? `+${currSym}${(lcBill.excessQty * lcBill.weightedActualRate).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '$0.00'}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-bold text-slate-800 font-sans">
                    ৪. হুন্ডি গ্যাপ / বাণিজ্যিক ব্যবধান (Hundi Gap)
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-slate-700">
                    {currSym}{(Math.max(0, (lcBill.contractQty * lcBill.weightedActualRate) - (lcBill.contractQty * lcBill.weightedOfficialRate))).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-slate-700">
                    {currSym}{(Math.max(0, (lcBill.receivedQty * lcBill.weightedActualRate) - (selectedLc.bankBillForExtraQty === 'cap_at_lc' && lcBill.receivedQty > lcBill.contractQty ? (lcBill.contractQty * lcBill.weightedOfficialRate) : (lcBill.receivedQty * lcBill.weightedOfficialRate)))).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="py-2 px-3 text-right font-black text-amber-900 bg-amber-50/50">
                    {currSym}{lcBill.hundiGapForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    <span className="block text-[10px] text-amber-700 font-normal">
                      ৳{Math.round(lcBill.hundiGapBdt).toLocaleString()}
                    </span>
                  </td>
                  <td className={`py-2 px-3 text-right font-black ${
                    lcBill.excessQty > 0 ? 'bg-amber-100/90 text-amber-950 border-l border-amber-300' : 'text-slate-400'
                  }`}>
                    {lcBill.excessQty > 0 ? (
                      <div>
                        <span>+{currSym}{(Math.max(0, lcBill.hundiGapForeign - Math.max(0, (lcBill.contractQty * lcBill.weightedActualRate) - (lcBill.contractQty * lcBill.weightedOfficialRate)))).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                        <span className="block text-[9px] text-amber-800 font-normal">
                          (৳{Math.round((Math.max(0, lcBill.hundiGapForeign - Math.max(0, (lcBill.contractQty * lcBill.weightedActualRate) - (lcBill.contractQty * lcBill.weightedOfficialRate)))) * exchangeRate).toLocaleString()})
                        </span>
                      </div>
                    ) : '$0.00'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* ৩টি প্রধান ফাইনান্সিয়াল কার্ড: ১. ব্যাংক সেটেলমেন্ট, ২. প্রকৃত বাণিজ্যিক মূল্য, ৩. হুন্ডি/ক্যাশ গ্যাপ */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-4">
          {/* Card 1: 1st Part - Payment Settle By Bank */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50/70 border border-blue-200 rounded-2xl p-4 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black uppercase tracking-wider text-blue-800 flex items-center gap-1">
                <Landmark className="w-3.5 h-3.5 text-blue-600" />
                1. Payment Settle By Bank (Official)
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                isBankSettled ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
              }`}>
                {isBankSettled ? '✓ Bank Settled' : 'Payment In Progress'}
              </span>
            </div>

            <div className="flex items-baseline justify-between font-mono">
              <div>
                <span className="text-2xl font-black text-blue-950">
                  {currSym}{officialBankLcTotalForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className="text-xs text-blue-700 font-bold ml-1">{selectedLc.currency || 'USD'}</span>
              </div>
              <span className="text-xs font-bold text-blue-700">
                @ {currSym}{officialLcRate.toFixed(2)} / {selectedLc.uom || 'MT'}
              </span>
            </div>

            <div className="text-[11px] font-mono text-blue-900 bg-white/70 rounded-xl p-2 border border-blue-100 space-y-1">
              <div className="flex justify-between">
                <span>Gross BDT Total:</span>
                <span className="font-bold">৳{officialBankLcTotalBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
              </div>
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>Settled:</span>
                <span>{currSym}{totalBankSettledForeign.toLocaleString()} (৳{totalBankSettledBdt.toLocaleString()})</span>
              </div>
              <div className="flex justify-between text-rose-600 font-bold border-t border-blue-200/60 pt-0.5">
                <span>Due Remaining:</span>
                <span>{currSym}{remainingBankDueForeign.toLocaleString()}</span>
              </div>
            </div>

            {/* Requirement A.1: When remaining due is 0, disable button and show green badge */}
            {isBankSettled ? (
              <div className="w-full py-2 bg-emerald-100 border border-emerald-300 text-emerald-800 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Fully Settled ({currSym}{totalBankSettledForeign.toLocaleString()})</span>
              </div>
            ) : isClosed ? (
              <button
                type="button"
                disabled
                className="w-full py-2 bg-slate-200 text-slate-500 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-not-allowed"
              >
                <Lock className="w-3.5 h-3.5" />
                LC Closed (LOCKED)
              </button>
            ) : !isMarginPosted ? (
              <div className="space-y-2">
                <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="font-bold text-[11px]">Cannot settle: LC margin has not been posted or marked paid</span>
                </div>
                <button
                  type="button"
                  disabled
                  className="w-full py-2 bg-slate-200 text-slate-400 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-not-allowed border border-slate-300"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Bank Settlement Locked (Margin Unposted)
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setBankSettleAmountForeign(remainingBankDueForeign > 0 ? String(remainingBankDueForeign) : '');
                  setShowBankSettleModal(true);
                }}
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Record Bank Settlement
              </button>
            )}
          </div>

          {/* Card 2: Actual Commercial Value & Multi-Rate Slabs */}
          <div className="bg-gradient-to-br from-slate-50 to-indigo-50/40 border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1">
                <Scale className="w-3.5 h-3.5 text-indigo-600" />
                প্রকৃত বাণিজ্যিক মূল্য (Commercial Bill)
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                {activeRateBatches.length}টি রেট ব্যাচ
              </span>
            </div>

            <div className="flex items-baseline justify-between font-mono">
              <div>
                <span className="text-2xl font-black text-slate-900">
                  {currSym}{totalCommercialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className="text-xs text-slate-500 font-bold ml-1">{selectedLc.currency || 'USD'}</span>
              </div>
              <span className="text-xs font-bold text-indigo-700">
                গড় রেট: {currSym}{weightedAverageCommercialRate.toFixed(2)}
              </span>
            </div>

            <div className="text-[11px] font-mono text-slate-700 bg-white/70 rounded-xl p-2 border border-slate-200/80 space-y-1">
              <div className="flex justify-between">
                <span>মোট পরিমাণ (Quantity):</span>
                <span className="font-bold">{totalLcQuantity.toLocaleString()} {selectedLc.uom || 'MT'}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>স্ল্যাব বরাদ্দ:</span>
                <span className={totalAllocatedBatchQuantity === totalLcQuantity ? 'text-emerald-600 font-bold' : 'text-amber-600 font-bold'}>
                  {totalAllocatedBatchQuantity.toLocaleString()} / {totalLcQuantity.toLocaleString()} {selectedLc.uom || 'MT'}
                </span>
              </div>
              <div className="flex justify-between text-indigo-700 font-bold border-t border-slate-200/60 pt-0.5">
                <span>প্রকৃত টাকা (BDT Total):</span>
                <span>৳{(totalCommercialBillForeign * exchangeRate).toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
              </div>
            </div>

            <button
              type="button"
              disabled={isClosed}
              onClick={() => {
                const remainingQty = Math.max(0, totalLcQuantity - totalAllocatedBatchQuantity);
                setNewBatchQuantity(remainingQty > 0 ? remainingQty : 500);
                setShowAddBatchModal(true);
              }}
              className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed border border-indigo-200 text-indigo-800 font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              নতুন রেট স্ল্যাব / ব্যাচ যুক্ত করুন
            </button>
          </div>

          {/* Card 3: 2nd Part - Hundi / Side-Payment Difference */}
          <div className="bg-gradient-to-br from-amber-50 to-orange-50/70 border border-amber-300 rounded-2xl p-4 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black uppercase tracking-wider text-amber-900 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-600" />
                ২. Hundi / Unofficial Side-Payment
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                totalDifferentialGapBdt <= 0 ? 'bg-slate-100 text-slate-600' :
                isHundiSettled ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'
              }`}>
                {totalDifferentialGapBdt <= 0 ? 'গ্যাপ নেই' :
                 isHundiSettled ? '✓ হুন্ডি পরিশোধিত' : 'ক্যাশ বাকি রয়েছে'}
              </span>
            </div>

            <div className="flex items-baseline justify-between font-mono">
              <div>
                <span className="text-2xl font-black text-amber-950">
                  {currSym}{totalDifferentialGapForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className="text-xs text-amber-700 font-bold ml-1">{selectedLc.currency || 'USD'}</span>
              </div>
              <span className="text-xs font-bold text-amber-800">
                বাংলা টাকা ➔ হুন্ডি ➔ রুপি
              </span>
            </div>

            <div className="text-[11px] font-mono text-amber-950 bg-white/80 rounded-xl p-2 border border-amber-200 space-y-1">
              <div className="flex justify-between">
                <span>বাংলা টাকা (BDT Gap):</span>
                <span className="font-bold text-amber-950">৳{totalDifferentialGapBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
              </div>
              <div className="flex justify-between text-indigo-700 font-bold">
                <span>ইন্ডিয়ান রুপি (@{hundiRateBdtToInr}):</span>
                <span>₹{totalDifferentialGapInr.toLocaleString()} IC RS</span>
              </div>
              <div className="flex justify-between text-rose-600 font-bold border-t border-amber-200/80 pt-0.5">
                <span>পরিশোধ বাকি (Due):</span>
                <span>৳{remainingHundiDueBdt.toLocaleString()} (₹{remainingHundiDueInr.toLocaleString()})</span>
              </div>
            </div>

            {/* Requirement A.2: Cap amount, disable button and show status */}
            {totalDifferentialGapBdt <= 0 ? (
              <div className="w-full py-2 bg-slate-100 border border-slate-200 text-slate-600 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-2xs">
                <span>No hundi payable</span>
              </div>
            ) : isHundiSettled ? (
              <div className="w-full py-2 bg-emerald-100 border border-emerald-300 text-emerald-900 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Hundi Fully Paid (৳{totalHundiPaidBdt.toLocaleString()})</span>
              </div>
            ) : isClosed ? (
              <button
                type="button"
                disabled
                className="w-full py-2 bg-slate-200 text-slate-500 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-not-allowed"
              >
                <Lock className="w-3.5 h-3.5" />
                এলসি ক্লোজড (LOCKED)
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setHundiAmountBdt(remainingHundiDueBdt > 0 ? String(remainingHundiDueBdt) : '');
                  setShowHundiPaymentModal(true);
                }}
                className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <Coins className="w-3.5 h-3.5" />
                হুন্ডি / সাইড-পেমেন্ট এন্ট্রি করুন
              </button>
            )}
          </div>
        </div>
      </div>

      {/* SECTION 1: RATE SLABS / BATCHES (Preserved) */}
      {(activeSubSection === 'all' || activeSubSection === 'rate_batches') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-lg bg-indigo-600 text-white text-xs font-black flex items-center justify-center">
                  #
                </span>
                <h3 className="text-base font-black text-slate-900">
                  Multiple Commercial Rate Slabs & Batches (একাধিক বাণিজ্যিক দর বিভাজন)
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                একই এলসিতে কোয়ারি হতে মাল আনার সময়ে ভিন্ন ভিন্ন লটে পরিবর্তিত বাণিজ্যিক রেট নির্ধারণ।
              </p>
            </div>

            <button
              type="button"
              disabled={isClosed}
              onClick={() => {
                const rem = Math.max(0, totalLcQuantity - totalAllocatedBatchQuantity);
                setNewBatchQuantity(rem > 0 ? rem : 500);
                setShowAddBatchModal(true);
              }}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 self-start cursor-pointer shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              নতুন রেট স্ল্যাব যোগ করুন
            </button>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-2xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-3.5">লট / স্ল্যাব নাম</th>
                  <th className="py-3 px-3 text-right">পরিমাণ (Quantity)</th>
                  <th className="py-3 px-3 text-right">ব্যাংক রেট (LC Rate)</th>
                  <th className="py-3 px-3 text-right">আসল বাণিজ্যিক রেট</th>
                  <th className="py-3 px-3 text-right">রেটের পার্থক্য</th>
                  <th className="py-3 px-3 text-right">বাণিজ্যিক মোট মূল্য</th>
                  <th className="py-3 px-3 text-right">হুন্ডি ডিফারেন্সিয়াল</th>
                  <th className="py-3 px-3 text-center">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {activeRateBatches.map((batch, idx) => {
                  const rateDiff = Math.max(0, batch.actualRate - batch.officialRate);
                  const commercialTotal = batch.totalCommercialAmount || (batch.quantity * batch.actualRate);
                  const diffAmount = batch.differentialAmount || (batch.quantity * rateDiff);

                  return (
                    <tr key={batch.id || idx} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-3.5 font-sans font-bold text-slate-900">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-bold flex items-center justify-center shrink-0">
                            {idx + 1}
                          </span>
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span>{batch.batchName}</span>
                              {batch.isAuto && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 font-mono">
                                  Auto (অতিরিক্ত রিসিভ)
                                </span>
                              )}
                            </div>
                            {batch.notes && (
                              <span className="block text-[10px] font-normal text-slate-400 font-sans">{batch.notes}</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right font-black text-slate-900">
                        {batch.quantity.toLocaleString()} {batch.uom || 'MT'}
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-blue-700">
                        {currSym}{batch.officialRate.toFixed(2)}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-indigo-900 bg-indigo-50/30">
                        {currSym}{batch.actualRate.toFixed(2)}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-amber-700">
                        +{currSym}{rateDiff.toFixed(2)}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-slate-900">
                        {currSym}{commercialTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-amber-600 bg-amber-50/40">
                        {currSym}{diffAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        <span className="block text-[10px] text-amber-700 font-normal">
                          ৳{(diffAmount * exchangeRate).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {!isClosed && (
                            <button
                              type="button"
                              onClick={() => handleStartEditBatch(batch)}
                              className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                              title="দর / রেট পরিবর্তন করুন"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {activeRateBatches.length > 1 && !isClosed && !batch.isAuto && (
                            <button
                              type="button"
                              onClick={() => handleDeleteRateBatch(batch.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="স্ল্যাব মুছুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-50 font-mono font-bold text-slate-900 border-t border-slate-200">
                <tr>
                  <td className="py-2.5 px-3.5 font-sans">সর্বমোট (Weighted Total):</td>
                  <td className="py-2.5 px-3 text-right text-indigo-900">
                    {totalAllocatedBatchQuantity.toLocaleString()} {selectedLc.uom || 'MT'}
                  </td>
                  <td className="py-2.5 px-3 text-right text-blue-700">
                    {currSym}{officialLcRate.toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-indigo-900">
                    গড় {currSym}{weightedAverageCommercialRate.toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-amber-700">
                    +{(weightedAverageCommercialRate - officialLcRate).toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-950 font-black">
                    {currSym}{totalCommercialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="py-2.5 px-3 text-right text-amber-900 font-black">
                    {currSym}{totalDifferentialGapForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 2: PAYMENT SETTLE BY BANK */}
      {(activeSubSection === 'all' || activeSubSection === 'bank_settle') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-lg bg-blue-600 text-white text-xs font-black flex items-center justify-center">
                  1
                </span>
                <h3 className="text-base font-black text-slate-900">
                  Payment Settle By Bank (Official LC Settlement)
                </h3>
              </div>
            </div>

            {!isBankSettled && !isClosed && (
              !isMarginPosted ? (
                <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="font-bold text-[11px]">Cannot settle: LC margin has not been posted or marked paid</span>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    resetBankSettleForm();
                    setShowBankSettleModal(true);
                  }}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 self-start cursor-pointer shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Record Bank Settlement
                </button>
              )
            )}
          </div>

          {/* Bank Settle Ledger Table (Requirements B.6, E.1, E.2) */}
          {(selectedLc.bankSettlements || []).length === 0 ? (
            <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
              <Landmark className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-700">No bank settlements recorded yet</p>
            </div>
          ) : (
            <div className="overflow-x-auto border border-slate-200 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-3.5">Date</th>
                    <th className="py-3 px-3">Voucher No</th>
                    <th className="py-3 px-3">Debit Account</th>
                    <th className="py-3 px-3">SWIFT Ref</th>
                    <th className="py-3 px-3 text-right">Foreign Currency</th>
                    <th className="py-3 px-3 text-right">Rate</th>
                    <th className="py-3 px-3 text-right">Gross BDT</th>
                    <th className="py-3 px-3 text-right">Margin Adjusted</th>
                    <th className="py-3 px-3 text-right">Net Bank Debit</th>
                    <th className="py-3 px-3 text-center">Status</th>
                    <th className="py-3 px-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {(selectedLc.bankSettlements || []).map((bs, idx) => {
                    const isVoided = bs.status === 'Voided';
                    const vNo = bs.voucherNo || bs.voucherNumber;

                    return (
                      <tr 
                        key={bs.id || idx} 
                        className={`transition-colors ${isVoided ? 'bg-slate-100/70 text-slate-400' : 'hover:bg-blue-50/30'}`}
                      >
                        <td className={`py-3 px-3.5 font-bold ${isVoided ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                          {bs.settlementDate}
                        </td>

                        {/* Voucher No (Clickable to open Voucher Print Modal) */}
                        <td className="py-3 px-3">
                          {vNo ? (
                            <button
                              type="button"
                              onClick={() => {
                                const found = transactions.find(t => t.voucherNo === vNo || t.id === bs.transactionId);
                                if (found) setSelectedTxnForView(found);
                              }}
                              className={`font-mono font-bold text-xs inline-flex items-center gap-1 transition-colors cursor-pointer ${
                                isVoided ? 'line-through text-slate-400' : 'text-blue-600 hover:text-blue-800 underline'
                              }`}
                              title="Click to view voucher"
                            >
                              <FileText className="w-3 h-3 text-blue-500 shrink-0" />
                              <span>{vNo}</span>
                            </button>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>

                        {/* Debit Account */}
                        <td className="py-3 px-3 font-sans text-[11px]">
                          <span className={`font-semibold block ${isVoided ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                            {bs.bankAccountName || bs.bankName}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {bs.debitAccount || bs.branch || 'Head Office'}
                          </span>
                        </td>

                        <td className={`py-3 px-3 font-bold ${isVoided ? 'line-through text-slate-400' : 'text-blue-700'}`}>
                          {bs.swiftRef || 'N/A'}
                        </td>

                        <td className={`py-3 px-3 text-right font-black ${isVoided ? 'line-through text-slate-400' : 'text-blue-950'}`}>
                          {currSym}{bs.amountForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        <td className="py-3 px-3 text-right text-slate-600">
                          ৳{bs.exchangeRate.toFixed(2)}
                        </td>

                        <td className={`py-3 px-3 text-right font-black ${isVoided ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                          ৳{bs.amountLocalBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                        </td>

                        <td className="py-3 px-3 text-right text-emerald-700 font-bold">
                          ৳{(bs.marginAdjustedBdt || 0).toLocaleString()}
                        </td>

                        <td className={`py-3 px-3 text-right font-black ${isVoided ? 'line-through text-slate-400' : 'text-blue-900'}`}>
                          ৳{(bs.netPaidBdt || bs.amountLocalBdt).toLocaleString()}
                        </td>

                        {/* Status */}
                        <td className="py-3 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-sans ${
                            isVoided 
                              ? 'bg-slate-200 text-slate-600 line-through' 
                              : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {bs.status}
                          </span>
                        </td>

                        {/* Action: Void Button (Requirement E.1, E.2) */}
                        <td className="py-3 px-3 text-center">
                          {isVoided ? (
                            <span className="text-[10px] text-slate-400 font-sans italic" title={bs.voidReason}>
                              Voided
                            </span>
                          ) : isAdmin ? (
                            <button
                              type="button"
                              onClick={() => {
                                setVoidTarget({ type: 'bank', item: bs });
                                setVoidReason('');
                                setVoidError(null);
                              }}
                              className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-[11px] font-bold transition-colors cursor-pointer"
                              title="Void voucher and reverse ledger entries"
                            >
                              Void
                            </button>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: HUNDI / SIDE-PAYMENT LEDGER (২য় অংশ - বাংলা টাকা হুন্ডিতে ইন্ডিয়ান রুপি) */}
      {(activeSubSection === 'all' || activeSubSection === 'hundi_settle') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-lg bg-amber-600 text-white text-xs font-black flex items-center justify-center">
                  ২
                </span>
                <h3 className="text-base font-black text-slate-900">
                  Hundi / Unofficial Side-Payment Ledger (হুন্ডি ও ক্যাশ খতিয়ান)
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                অতিরিক্ত বাণিজ্যিক ডিফারেন্সিয়াল রেট বাংলা টাকা হুন্ডিতে ইন্ডিয়ান রুপি (IC RS) হিসেবে পরিশোধ।
              </p>
            </div>

            {!isHundiSettled && totalDifferentialGapBdt > 0 && !isClosed && (
              <button
                type="button"
                onClick={() => {
                  resetHundiForm();
                  setShowHundiPaymentModal(true);
                }}
                className="px-3.5 py-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold rounded-xl text-xs transition-all flex items-center gap-1.5 self-start cursor-pointer shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                ক্যাশ / হুন্ডি পেমেন্ট এন্ট্রি
              </button>
            )}
          </div>

          {(selectedLc.hundiPayments || []).length === 0 ? (
            <div className="p-8 text-center bg-amber-50/40 border border-dashed border-amber-200 rounded-2xl">
              <Zap className="w-8 h-8 text-amber-300 mx-auto mb-2" />
              <p className="text-xs font-bold text-amber-950">কোন হুন্ডি বা ক্যাশ পেমেন্ট এখনো এন্ট্রি করা হয়নি</p>
              <p className="text-[11px] text-amber-700 mt-0.5">
                বাংলা টাকা দিয়ে হুন্ডি এজেন্টের মাধ্যমে এক্সপোর্টারকে রুপি পেমেন্ট রেকর্ড করুন।
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto border border-slate-200 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-amber-50/70 text-amber-950 font-bold border-b border-amber-200">
                  <tr>
                    <th className="py-3 px-3.5">তারিখ (Date)</th>
                    <th className="py-3 px-3">ভাউচার নং</th>
                    <th className="py-3 px-3">পেইড ফ্রম (Paid From)</th>
                    <th className="py-3 px-3">হুন্ডি এজেন্ট / মাধ্যম</th>
                    <th className="py-3 px-3">টোকেন / রেফারেন্স</th>
                    <th className="py-3 px-3 text-right">বাংলা টাকা (BDT)</th>
                    <th className="py-3 px-3 text-right">হুন্ডি রেট (BDT/INR)</th>
                    <th className="py-3 px-3 text-right">ইন্ডিয়ান রুপি (IC RS)</th>
                    <th className="py-3 px-3 text-center">মাধ্যম</th>
                    <th className="py-3 px-3 text-center">স্ট্যাটাস</th>
                    <th className="py-3 px-3 text-center">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {(selectedLc.hundiPayments || []).map((hp, idx) => {
                    const isVoided = hp.status === 'Voided';

                    return (
                      <tr 
                        key={hp.id || idx} 
                        className={`transition-colors ${isVoided ? 'bg-slate-100/70 text-slate-400' : 'hover:bg-amber-50/30'}`}
                      >
                        <td className={`py-3 px-3.5 font-bold ${isVoided ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                          {hp.paymentDate}
                        </td>

                        {/* Voucher No */}
                        <td className="py-3 px-3">
                          {hp.voucherNo ? (
                            <button
                              type="button"
                              onClick={() => {
                                const found = transactions.find(t => t.voucherNo === hp.voucherNo || t.id === hp.transactionId);
                                if (found) setSelectedTxnForView(found);
                              }}
                              className={`font-mono font-bold text-xs inline-flex items-center gap-1 transition-colors cursor-pointer ${
                                isVoided ? 'line-through text-slate-400' : 'text-blue-600 hover:text-blue-800 underline'
                              }`}
                              title="Click to view voucher"
                            >
                              <FileText className="w-3 h-3 text-blue-500 shrink-0" />
                              <span>{hp.voucherNo}</span>
                            </button>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>

                        {/* Paid From Account */}
                        <td className="py-3 px-3 font-sans text-[11px]">
                          <span className={`font-semibold block ${isVoided ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                            {hp.paidFromAccountName || 'Cash in Hand'}
                          </span>
                        </td>

                        <td className={`py-3 px-3 font-sans font-bold ${isVoided ? 'line-through text-slate-400' : 'text-amber-950'}`}>
                          {hp.hundiBroker}
                          {hp.notes && <span className="block text-[10px] text-slate-400 font-normal font-sans">{hp.notes}</span>}
                        </td>

                        <td className={`py-3 px-3 font-bold ${isVoided ? 'line-through text-slate-400' : 'text-indigo-700'}`}>
                          {hp.receiptToken || 'N/A'}
                        </td>

                        <td className={`py-3 px-3 text-right font-black ${isVoided ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                          ৳{hp.amountBdt.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                        </td>

                        <td className="py-3 px-3 text-right font-bold text-amber-800">
                          {hp.hundiRateBdtToInr.toFixed(2)}
                        </td>

                        <td className={`py-3 px-3 text-right font-black ${isVoided ? 'line-through text-slate-400' : 'text-indigo-900 bg-indigo-50/30'}`}>
                          ₹{hp.amountInr.toLocaleString('en-US', { maximumFractionDigits: 0 })} IC RS
                        </td>

                        <td className="py-3 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 font-sans">
                            {hp.paymentMode}
                          </span>
                        </td>

                        {/* Status */}
                        <td className="py-3 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-sans ${
                            isVoided 
                              ? 'bg-slate-200 text-slate-600 line-through' 
                              : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {hp.status || 'Paid'}
                          </span>
                        </td>

                        {/* Action: Void Button (Requirement E.1, E.2) */}
                        <td className="py-3 px-3 text-center">
                          {isVoided ? (
                            <span className="text-[10px] text-slate-400 font-sans italic" title={hp.voidReason}>
                              বাতিলকৃত
                            </span>
                          ) : isAdmin ? (
                            <button
                              type="button"
                              onClick={() => {
                                setVoidTarget({ type: 'hundi', item: hp });
                                setVoidReason('');
                                setVoidError(null);
                              }}
                              className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-[11px] font-bold transition-colors cursor-pointer"
                              title="ভাউচার বাতিল (Void) করুন ও একাউন্ট রিভার্স করুন"
                            >
                              Void
                            </button>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL 1: ADD COMMERCIAL RATE BATCH (Preserved)                        */}
      {/* --------------------------------------------------------------------- */}
      {showAddBatchModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain">
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-black">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">নতুন বাণিজ্যিক রেট স্ল্যাব যোগ করুন</h3>
                  <p className="text-[11px] text-slate-500">Commercial Multi-Rate Batch Allocation</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddBatchModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddRateBatch} autoComplete="off" className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">লট / স্ল্যাব নাম</label>
                <input
                  type="text"
                  value={newBatchName}
                  onChange={(e) => setNewBatchName(e.target.value)}
                  required
                  className="w-full border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  placeholder="e.g. ২য় লট (বাড়তি রেট)"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">পরিমাণ ({selectedLc.uom || 'MT'})</label>
                  <input
                    type="number"
                    value={newBatchQuantity || ''}
                    onChange={(e) => setNewBatchQuantity(Number(e.target.value))}
                    required
                    min={1}
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">বাণিজ্যিক রেট ({currSym})</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newBatchActualRate || ''}
                    onChange={(e) => setNewBatchActualRate(Number(e.target.value))}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-indigo-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-indigo-50/30"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">নোট / পরিবর্তন কারণ</label>
                <input
                  type="text"
                  value={newBatchNotes}
                  onChange={(e) => setNewBatchNotes(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddBatchModal(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-colors shadow-2xs cursor-pointer"
                >
                  স্ল্যাব সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL 1.5: EDIT COMMERCIAL RATE BATCH (Requirement 2)                 */}
      {/* --------------------------------------------------------------------- */}
      {showEditBatchModal && editingBatch && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain">
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-black">
                  <Edit3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">ব্যাচ রেট পরিবর্তন (Edit Batch Rates)</h3>
                  <p className="text-[11px] text-slate-500 font-mono">{editingBatch.batchName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowEditBatchModal(false);
                  setEditingBatch(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditBatch} className="space-y-3.5 text-xs">
              {editingBatch.isAuto && (
                <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-[11px] leading-relaxed">
                  এটি অতিরিক্ত রিসিভকৃত পণ্যের স্বয়ংক্রিয় সিস্টেম ব্যাচ। এর পরিমাণ ({editingBatch.quantity} MT) সরাসরি রিসিভিং পরিমাণের সাথে সুসংগত। আপনি এর ব্যাংক রেট ও বাণিজ্যিক রেট পরিবর্তন করতে পারেন।
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">পরিমাণ ({selectedLc.uom || 'MT'})</label>
                  <input
                    type="number"
                    value={editBatchQuantity}
                    onChange={(e) => setEditBatchQuantity(Number(e.target.value))}
                    disabled={editingBatch.isAuto}
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none disabled:bg-slate-100 disabled:text-slate-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">অফিসিয়াল ব্যাংক রেট ({currSym})</label>
                  <input
                    type="number"
                    step="0.01"
                    value={editBatchOfficialRate}
                    onChange={(e) => setEditBatchOfficialRate(Number(e.target.value))}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-blue-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-blue-50/30"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">আসল বাণিজ্যিক রেট ({currSym})</label>
                <input
                  type="number"
                  step="0.01"
                  value={editBatchActualRate}
                  onChange={(e) => setEditBatchActualRate(Number(e.target.value))}
                  required
                  className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-indigo-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-indigo-50/30"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">নোট / পরিবর্তন বিবরণ</label>
                <input
                  type="text"
                  value={editBatchNotes}
                  onChange={(e) => setEditBatchNotes(e.target.value)}
                  placeholder="রেট পরিবর্তনের কারণ..."
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setShowEditBatchModal(false);
                    setEditingBatch(null);
                  }}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-colors shadow-2xs cursor-pointer"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL 2: RECORD PAYMENT SETTLE BY BANK                                */}
      {/* --------------------------------------------------------------------- */}
      {showBankSettleModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain">
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 animate-in fade-in zoom-in-95 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-black">
                  <Landmark className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">Record Official Bank LC Settlement</h3>
                  <p className="text-[11px] text-slate-500">Atomic voucher posting, ledger debit & bank balance reduction</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  resetBankSettleForm();
                  setShowBankSettleModal(false);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Error Banner */}
            {bankSettleError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1 font-medium">{bankSettleError}</div>
              </div>
            )}

            <form onSubmit={handleRecordBankSettlement} autoComplete="off" className="space-y-3.5 text-xs">
              {/* LC Info Block */}
              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-2xl space-y-1 text-[11px]">
                <div className="flex justify-between text-blue-900">
                  <span>LC Number:</span>
                  <span className="font-mono font-bold">{selectedLc.lcNumber}</span>
                </div>
                <div className="flex justify-between text-blue-900">
                  <span>Beneficiary Exporter:</span>
                  <span className="font-bold">{selectedLc.supplierName}</span>
                </div>
                <div className="flex justify-between text-blue-950 font-bold border-t border-blue-200 pt-1">
                  <span>Official LC Total Value:</span>
                  <span className="font-mono">{currSym}{officialBankLcTotalForeign.toLocaleString()} {selectedLc.currency || 'USD'}</span>
                </div>
                <div className="flex justify-between text-emerald-800 font-semibold">
                  <span>Already Settled by Bank:</span>
                  <span className="font-mono">{currSym}{totalBankSettledForeign.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-rose-700 font-bold border-t border-blue-200/60 pt-0.5">
                  <span>Maximum Remaining Balance (Cap Limit):</span>
                  <span className="font-mono">{currSym}{remainingBankDueForeign.toLocaleString()}</span>
                </div>
              </div>

              {!isMarginPosted && (
                <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <strong className="block font-bold">Cannot settle: LC margin has not been posted or marked paid</strong>
                    <span className="text-[11px] text-amber-700">Bank settlement cannot be performed until margin payment is posted.</span>
                  </div>
                </div>
              )}

              {/* Date & Foreign Amount */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Settlement Date <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={bankSettleDate}
                    onChange={(e) => setBankSettleDate(e.target.value)}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Settlement Amount ({selectedLc.currency || 'USD'}) <span className="text-rose-500">*</span>
                    <span className="text-[10px] text-slate-400 font-normal ml-1">
                      (Max {currSym}{remainingBankDueForeign.toLocaleString()})
                    </span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min={0.01}
                    max={remainingBankDueForeign > 0 ? remainingBankDueForeign : undefined}
                    value={bankSettleAmountForeign}
                    onChange={(e) => setBankSettleAmountForeign(e.target.value)}
                    required
                    placeholder={`Max ${remainingBankDueForeign}`}
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-blue-950 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-blue-50/30"
                  />
                </div>
              </div>

              {/* Exchange Rate & Margin Adjustment */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Bank Exchange Rate (BDT) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min={1}
                    value={bankSettleExchangeRate || ''}
                    onChange={(e) => setBankSettleExchangeRate(Number(e.target.value))}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Margin Adjustment (BDT)
                    <span className="text-[10px] text-slate-400 font-normal ml-1">
                      {isMarginPosted ? `(Max ৳${maxMarginAvailable.toLocaleString()})` : '(Margin not posted)'}
                    </span>
                  </label>
                  {!isMarginPosted && (
                    <p className="text-[10px] text-amber-700 bg-amber-50 border border-amber-200 p-1.5 rounded-lg mb-1 font-medium">
                      ⚠️ Margin voucher has not been posted to accounts for this LC. Post margin first to adjust.
                    </p>
                  )}
                  <input
                    type="number"
                    min={0}
                    disabled={!isMarginPosted}
                    max={Math.min(maxMarginAvailable, bankBdtGross)}
                    value={isMarginPosted ? bankSettleMarginAdjusted : ''}
                    onChange={(e) => setBankSettleMarginAdjusted(e.target.value)}
                    placeholder={isMarginPosted ? "৳0" : "Margin not posted"}
                    className={`w-full border rounded-xl p-2.5 font-mono font-bold text-emerald-800 focus:ring-2 focus:ring-blue-500 focus:outline-none ${
                      !isMarginPosted 
                        ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed' 
                        : 'bg-white border-slate-300'
                    }`}
                  />
                </div>
              </div>

              {/* Requirement B.1: Searchable Paid From Bank Account Dropdown */}
              <div className="relative" ref={bankDropdownRef}>
                <label className="block font-bold text-slate-700 mb-1">
                  Paid From Bank Account <span className="text-rose-500">*</span>
                  {!isAdmin && userBranch && userBranch !== 'All Branches' && (
                    <span className="text-[10px] text-slate-400 font-normal ml-1.5">
                      (Branch: {userBranch})
                    </span>
                  )}
                </label>

                <div
                  onClick={() => setIsBankDropdownOpen(prev => !prev)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 bg-white cursor-pointer flex items-center justify-between text-xs hover:border-blue-500 transition-colors shadow-2xs"
                >
                  {selectedBankAccount ? (
                    <div className="flex items-center justify-between w-full pr-2">
                      <div className="truncate mr-2">
                        <span className="font-bold text-slate-900">{selectedBankAccount.bankName}</span>
                        <span className="text-slate-500 font-mono ml-1.5">({selectedBankAccount.accountNumber})</span>
                        <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded font-semibold bg-slate-100 text-slate-700">
                          {selectedBankAccount.branch || 'Principal Branch'}
                        </span>
                      </div>
                      <span className={`font-mono font-bold shrink-0 ${
                        (selectedBankAccount.ledgerBalance || 0) < 0 ? 'text-rose-600' : 'text-emerald-700'
                      }`}>
                        ৳ {(selectedBankAccount.ledgerBalance || 0).toLocaleString()}
                      </span>
                    </div>
                  ) : (
                    <span className="text-slate-400">Search and select real Bank Account...</span>
                  )}
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                </div>

                {isBankDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-2xl z-50 p-2 max-h-60 overflow-hidden flex flex-col">
                    <div className="relative mb-2">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                      <input
                        type="text"
                        value={bankSearchTerm}
                        onChange={(e) => setBankSearchTerm(e.target.value)}
                        placeholder="Search by bank name, account no, branch..."
                        className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-blue-500"
                        autoFocus
                      />
                    </div>

                    <div className="overflow-y-auto space-y-1">
                      {filteredBankAccounts.length === 0 ? (
                        <div className="text-center py-4 text-slate-400 text-xs">
                          No accessible bank accounts found
                        </div>
                      ) : (
                        filteredBankAccounts.map((acc, accIdx) => (
                          <div
                            key={`bs-acc-${acc.id}-${accIdx}`}
                            onClick={() => {
                              setSelectedBankAccountId(acc.id);
                              setIsBankDropdownOpen(false);
                            }}
                            className={`p-2 rounded-lg cursor-pointer flex items-center justify-between text-xs transition-colors ${
                              selectedBankAccountId === acc.id ? 'bg-blue-50 text-blue-900 border border-blue-200' : 'hover:bg-slate-50 text-slate-800'
                            }`}
                          >
                            <div>
                              <div className="font-bold flex items-center gap-1.5">
                                <span>{acc.bankName}</span>
                                <span className="text-[10px] font-normal text-slate-500 font-mono">({acc.accountNumber})</span>
                              </div>
                              <div className="text-[10px] text-slate-400">
                                {acc.branch || 'Head Office'} • {acc.accountType}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className={`font-mono font-bold ${(acc.ledgerBalance || 0) < 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                                ৳ {(acc.ledgerBalance || 0).toLocaleString()}
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Swift Ref & Notes (Requirements A.5, B.4) */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    SWIFT Reference (MT752 Ref)
                  </label>
                  <input
                    type="text"
                    value={bankSettleSwiftRef}
                    onChange={(e) => setBankSettleSwiftRef(e.target.value)}
                    placeholder="e.g. SWIFT-MT752-98124"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Notes / Remarks
                  </label>
                  <input
                    type="text"
                    value={bankSettleNotes}
                    onChange={(e) => setBankSettleNotes(e.target.value)}
                    placeholder="e.g. Foreign remittance retired"
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                  />
                </div>
              </div>

              {/* Summary Calculation (Requirement B.2) */}
              <div className="p-3 bg-slate-900 text-white rounded-2xl font-mono text-[11px] space-y-1">
                <div className="flex justify-between text-blue-300">
                  <span>Gross BDT Remittance:</span>
                  <span className="font-bold">৳{bankBdtGross.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                </div>
                <div className="flex justify-between text-emerald-400">
                  <span>- Margin Adjusted:</span>
                  <span>৳{numBankMargin.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-white font-bold border-t border-slate-800 pt-1">
                  <span>Net Debit from Account:</span>
                  <span className="text-amber-400">৳{bankNetDebit.toLocaleString()}</span>
                </div>
              </div>

              {/* Overdraft Restricted / Admin Banner (Requirement B.5) */}
              {isBankOverdraft && !isAdmin && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                  <div>
                    <strong>Bank Overdraft Restricted: </strong>
                    Selected account balance (৳{(selectedBankAccount?.ledgerBalance || 0).toLocaleString()}) is lower than net debit (৳{bankNetDebit.toLocaleString()}). Only an Admin can authorize overdraft payments.
                  </div>
                </div>
              )}

              {isBankOverdraft && isAdmin && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 space-y-2">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-xs">
                      <strong className="block font-bold">Bank Overdraft Warning</strong>
                      Account balance is ৳{(selectedBankAccount?.ledgerBalance || 0).toLocaleString()}, net debit is ৳{bankNetDebit.toLocaleString()}. Projected balance: ৳{((selectedBankAccount?.ledgerBalance || 0) - bankNetDebit).toLocaleString()}.
                    </div>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-xs text-amber-950 pt-1.5 border-t border-amber-200/60">
                    <input
                      type="checkbox"
                      checked={bankOverdraftApproved}
                      onChange={(e) => setBankOverdraftApproved(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 border-amber-300"
                    />
                    <span>Admin Confirmation: I authorize this bank overdraft payment</span>
                  </label>
                </div>
              )}

              {/* Submit / Cancel Buttons (Requirement A.4) */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  disabled={isSavingBankSettle}
                  onClick={() => {
                    resetBankSettleForm();
                    setShowBankSettleModal(false);
                  }}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={
                    isSavingBankSettle ||
                    !isMarginPosted ||
                    !selectedBankAccountId ||
                    numBankForeign <= 0 ||
                    numBankForeign > remainingBankDueForeign + 0.001 ||
                    (isBankOverdraft && (!isAdmin || !bankOverdraftApproved))
                  }
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all shadow-2xs flex items-center gap-2 cursor-pointer"
                >
                  {isSavingBankSettle ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Posting Voucher & Saving...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Save & Post Bank Voucher</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL 3: RECORD HUNDI / SIDE-PAYMENT                                  */}
      {/* --------------------------------------------------------------------- */}
      {showHundiPaymentModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain">
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 animate-in fade-in zoom-in-95 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-black">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">বাংলা টাকা হুন্ডিতে ইন্ডিয়ান রুপি পেমেন্ট এন্ট্রি</h3>
                  <p className="text-[11px] text-slate-500">Atomic voucher posting, cash/bank deduction & audit log</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  resetHundiForm();
                  setShowHundiPaymentModal(false);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Error Banner */}
            {hundiError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1 font-medium">{hundiError}</div>
              </div>
            )}

            <form onSubmit={handleRecordHundiPayment} autoComplete="off" className="space-y-3.5 text-xs">
              {/* Requirement C.1: LC Information Block at the top */}
              <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-2xl space-y-1 text-[11px]">
                <div className="flex justify-between text-amber-950 font-bold">
                  <span>এলসি নম্বর (LC No):</span>
                  <span className="font-mono">{selectedLc.lcNumber}</span>
                </div>
                <div className="flex justify-between text-amber-900">
                  <span>বেনিফিশিয়ারি এক্সপোর্টার:</span>
                  <span className="font-semibold">{selectedLc.supplierName}</span>
                </div>
                <div className="flex justify-between text-amber-950 font-bold border-t border-amber-200 pt-1">
                  <span>মোট হুন্ডি গ্যাপ (Total Gap):</span>
                  <span className="font-mono">৳{totalDifferentialGapBdt.toLocaleString()} (₹{totalDifferentialGapInr.toLocaleString()} IC RS)</span>
                </div>
                <div className="flex justify-between text-amber-900">
                  <span>ইতিমধ্যে পরিশোধিত (Already Paid):</span>
                  <span className="font-mono">৳{totalHundiPaidBdt.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-rose-700 font-bold border-t border-amber-200/80 pt-0.5">
                  <span>সর্বোচ্চ অবশিষ্ট বকেয়া (Cap Limit):</span>
                  <span className="font-mono">৳{remainingHundiDueBdt.toLocaleString()}</span>
                </div>
              </div>

              {/* Date & Rate */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    পেমেন্ট তারিখ <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={hundiDate}
                    onChange={(e) => setHundiDate(e.target.value)}
                    required
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    হুন্ডি রেট (১ রুপির BDT দর) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min={0.1}
                    value={hundiRateBdtToInr || ''}
                    onChange={(e) => setHundiRateBdtToInr(Number(e.target.value))}
                    required
                    placeholder="e.g. 1.45"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-indigo-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-indigo-50/30"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">যেমন: ৳১.৪৫ টাকা = ₹১ ইন্ডিয়ান রুপি</span>
                </div>
              </div>

              {/* Amount (Capped at remaining gap, Requirement A.2) */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  পরিশোধকৃত বাংলা টাকা (BDT Amount) <span className="text-rose-500">*</span>
                  <span className="text-[10px] text-slate-400 font-normal ml-1">
                    (Max ৳{remainingHundiDueBdt.toLocaleString()})
                  </span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono font-black text-slate-400">৳</span>
                  <input
                    type="number"
                    min={1}
                    max={remainingHundiDueBdt > 0 ? remainingHundiDueBdt : undefined}
                    value={hundiAmountBdt}
                    onChange={(e) => setHundiAmountBdt(e.target.value)}
                    required
                    placeholder={`Max ${remainingHundiDueBdt}`}
                    className="w-full pl-8 pr-3 py-2.5 border border-slate-300 rounded-xl font-mono font-black text-base text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                  />
                </div>
              </div>

              {/* Live Converted IC RS Badge */}
              <div className="p-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-2xl flex items-center justify-between font-mono">
                <div>
                  <span className="text-[10px] text-amber-200 block font-sans">এক্সপোর্টারের কাছে জমা রুপি (IC RS):</span>
                  <span className="text-xl font-black">
                    ₹{hundiRateBdtToInr > 0 ? Math.round(numHundiBdt / hundiRateBdtToInr).toLocaleString() : 0} IC RS
                  </span>
                </div>
                <div className="text-right text-[10px] text-amber-100">
                  <span>ডলার সমমান:</span>
                  <span className="block font-bold">${exchangeRate > 0 ? (numHundiBdt / exchangeRate).toFixed(2) : 0} USD</span>
                </div>
              </div>

              {/* Payment Mode */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  পেমেন্ট মেথড <span className="text-rose-500">*</span>
                </label>
                <select
                  value={hundiPaymentMode}
                  onChange={(e) => setHundiPaymentMode(e.target.value as any)}
                  required
                  className="w-full border border-slate-300 rounded-xl p-2.5 font-medium text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                >
                  <option value="">Select Payment Method...</option>
                  <option value="Cash (BDT)">ক্যাশ নগদ (Cash BDT)</option>
                  <option value="Bank Transfer (BDT)">ব্যাংক ট্রান্সফার (Bank Transfer BDT)</option>
                  <option value="Angadia / Hawala">আংগাড়িয়া / হাওয়ালা টোকেন</option>
                </select>
              </div>

              {/* Requirement C.2: Paid From Account Searchable Dropdown */}
              <div className="relative" ref={hundiDropdownRef}>
                <label className="block font-bold text-slate-700 mb-1">
                  পেইড ফ্রম একাউন্ট (Paid From Account) <span className="text-rose-500">*</span>
                </label>

                <div
                  onClick={() => setIsHundiAccountDropdownOpen(prev => !prev)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 bg-white cursor-pointer flex items-center justify-between text-xs hover:border-amber-500 transition-colors shadow-2xs"
                >
                  {selectedHundiAccount ? (
                    <div className="flex items-center justify-between w-full pr-2">
                      <div className="truncate mr-2">
                        <span className="font-bold text-slate-900">{selectedHundiAccount.bankName}</span>
                        <span className="text-slate-500 font-mono ml-1.5">({selectedHundiAccount.accountNumber})</span>
                        <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded font-semibold bg-slate-100 text-slate-700">
                          {selectedHundiAccount.branch || 'Head Office'}
                        </span>
                      </div>
                      <span className={`font-mono font-bold shrink-0 ${
                        (selectedHundiAccount.ledgerBalance || 0) < 0 ? 'text-rose-600' : 'text-emerald-700'
                      }`}>
                        ৳ {(selectedHundiAccount.ledgerBalance || 0).toLocaleString()}
                      </span>
                    </div>
                  ) : (
                    <span className="text-slate-400">Search and select Cash or Bank Account...</span>
                  )}
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                </div>

                {isHundiAccountDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-2xl z-50 p-2 max-h-60 overflow-hidden flex flex-col">
                    <div className="relative mb-2">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                      <input
                        type="text"
                        value={hundiAccountSearchTerm}
                        onChange={(e) => setHundiAccountSearchTerm(e.target.value)}
                        placeholder="Search cash or bank account..."
                        className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-amber-500"
                        autoFocus
                      />
                    </div>

                    <div className="overflow-y-auto space-y-1">
                      {filteredHundiAccounts.length === 0 ? (
                        <div className="text-center py-4 text-slate-400 text-xs">
                          No accessible accounts found
                        </div>
                      ) : (
                        filteredHundiAccounts.map((acc, accIdx) => {
                          const isAccCash = acc.accountCategory === 'Cash' || acc.accountType === 'Petty Cash' || acc.accountType === 'POS Cash' || acc.bankName.toLowerCase().includes('cash');

                          return (
                            <div
                              key={`hnd-acc-${acc.id}-${accIdx}`}
                              onClick={() => {
                                setSelectedHundiAccountId(acc.id);
                                setIsHundiAccountDropdownOpen(false);
                              }}
                              className={`p-2 rounded-lg cursor-pointer flex items-center justify-between text-xs transition-colors ${
                                selectedHundiAccountId === acc.id ? 'bg-amber-50 text-amber-900 border border-amber-200' : 'hover:bg-slate-50 text-slate-800'
                              }`}
                            >
                              <div>
                                <div className="font-bold flex items-center gap-1.5">
                                  <span>{acc.bankName}</span>
                                  <span className="text-[10px] font-normal text-slate-500 font-mono">({acc.accountNumber})</span>
                                  {isAccCash && (
                                    <span className="text-[9px] bg-amber-100 text-amber-800 px-1 py-0.2 rounded font-bold">CASH</span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-400">
                                  {acc.branch || 'Head Office'} • {acc.accountType}
                                </div>
                              </div>
                              <div className="text-right">
                                <div className={`font-mono font-bold ${(acc.ledgerBalance || 0) < 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                                  ৳ {(acc.ledgerBalance || 0).toLocaleString()}
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Cash Deficit Warning */}
              {isHundiCashDeficit && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                  <div>
                    <strong>Insufficient Cash Balance: </strong>
                    The selected cash account has ৳{(selectedHundiAccount?.ledgerBalance || 0).toLocaleString()}, but payment is ৳{numHundiBdt.toLocaleString()}. Cash balance cannot become negative.
                  </div>
                </div>
              )}

              {/* Bank Overdraft for Hundi */}
              {isHundiBankOverdraft && !isAdmin && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                  <div>
                    <strong>Bank Overdraft Restricted: </strong>
                    Selected account balance (৳{(selectedHundiAccount?.ledgerBalance || 0).toLocaleString()}) is lower than the required payment. Only an Admin can authorize overdraft payments.
                  </div>
                </div>
              )}

              {isHundiBankOverdraft && isAdmin && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 space-y-2">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-xs">
                      <strong className="block font-bold">Bank Overdraft Warning</strong>
                      Account balance is ৳{(selectedHundiAccount?.ledgerBalance || 0).toLocaleString()}, payment is ৳{numHundiBdt.toLocaleString()}. Projected balance: ৳{((selectedHundiAccount?.ledgerBalance || 0) - numHundiBdt).toLocaleString()}.
                    </div>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-xs text-amber-950 pt-1.5 border-t border-amber-200/60">
                    <input
                      type="checkbox"
                      checked={hundiOverdraftApproved}
                      onChange={(e) => setHundiOverdraftApproved(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 border-amber-300"
                    />
                    <span>Admin Confirmation: I authorize this bank overdraft payment</span>
                  </label>
                </div>
              )}

              {/* Agent, Recipient & Token (Requirement A.5) */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">হুন্ডি এজেন্ট / মাধ্যম</label>
                  <input
                    type="text"
                    value={hundiBroker}
                    onChange={(e) => setHundiBroker(e.target.value)}
                    placeholder="e.g. রব্বানী ভাই / বুড়িমারী খাতা"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">রশিদ / টোকেন নং</label>
                  <input
                    type="text"
                    value={hundiReceiptToken}
                    onChange={(e) => setHundiReceiptToken(e.target.value)}
                    placeholder="e.g. HND-TK-2026-09"
                    className="w-full border border-slate-300 rounded-xl p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">নোট / বিবরণ</label>
                <input
                  type="text"
                  value={hundiNotes}
                  onChange={(e) => setHundiNotes(e.target.value)}
                  placeholder="নোট লিখুন..."
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                />
              </div>

              {/* Submit Buttons (Requirement A.4) */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  disabled={isSavingHundi}
                  onClick={() => {
                    resetHundiForm();
                    setShowHundiPaymentModal(false);
                  }}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors cursor-pointer disabled:opacity-50"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={
                    isSavingHundi ||
                    !selectedHundiAccountId ||
                    numHundiBdt <= 0 ||
                    numHundiBdt > remainingHundiDueBdt + 1 ||
                    isHundiCashDeficit ||
                    (isHundiBankOverdraft && (!isAdmin || !hundiOverdraftApproved))
                  }
                  className="px-5 py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all shadow-2xs flex items-center gap-2 cursor-pointer"
                >
                  {isSavingHundi ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Posting Voucher & Saving...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Save & Post Hundi Voucher</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL 4: VOID REVERSAL CONFIRMATION (Requirement E.1, E.2)           */}
      {/* --------------------------------------------------------------------- */}
      {voidTarget && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain">
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 space-y-4 my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center font-black">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">
                    {voidTarget.type === 'bank' ? 'Void Bank Settlement Voucher' : 'হুন্ডি পেমেন্ট বাতিল (Void)'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Reverse voucher, restore balances & mark record as Voided
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setVoidTarget(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {voidError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1 font-medium">{voidError}</div>
              </div>
            )}

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Item Type:</span>
                <span className="font-bold text-slate-800 uppercase">{voidTarget.type === 'bank' ? 'Bank Settlement' : 'Hundi Payment'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Voucher No:</span>
                <span className="font-mono font-bold text-blue-700">{voidTarget.item.voucherNo || (voidTarget.item as any).voucherNumber || 'N/A'}</span>
              </div>
              <div className="flex justify-between font-bold border-t border-slate-200 pt-1">
                <span className="text-slate-600">Amount:</span>
                <span className="font-mono text-rose-700">
                  ৳{(voidTarget.item as any).netPaidBdt ? (voidTarget.item as any).netPaidBdt.toLocaleString() : (voidTarget.item as any).amountBdt ? (voidTarget.item as any).amountBdt.toLocaleString() : (voidTarget.item as any).amountLocalBdt.toLocaleString()}
                </span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1 text-xs">
                Void Reason <span className="text-rose-500">*</span>
              </label>
              <textarea
                value={voidReason}
                onChange={(e) => setVoidReason(e.target.value)}
                required
                rows={3}
                placeholder="Reason for voiding (e.g. incorrect account selection, revised amount)..."
                className="w-full border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                disabled={isVoiding}
                onClick={() => setVoidTarget(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors cursor-pointer text-xs disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isVoiding || !voidReason.trim()}
                onClick={handleExecuteVoid}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer text-xs"
              >
                {isVoiding ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Reversing Voucher...</span>
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-4 h-4" />
                    <span>Confirm Void & Reverse</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL 5: REOPEN CLOSED LC (Requirement D.5)                           */}
      {/* --------------------------------------------------------------------- */}
      {showReopenModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain">
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 space-y-4 my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-black">
                  <Unlock className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">Reopen Closed LC</h3>
                  <p className="text-[11px] text-slate-500">
                    Admin authorization to reopen closed LC for corrections
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowReopenModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {reopenError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1 font-medium">{reopenError}</div>
              </div>
            )}

            <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-2xl text-xs text-amber-950">
              <p className="font-bold">LC Number: {selectedLc.lcNumber}</p>
              <p className="text-[11px] text-amber-900 mt-1">
                Reopening restores this LC to Active status for revisions. This action is logged in audit trail.
              </p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1 text-xs">
                Reopen Reason <span className="text-rose-500">*</span>
              </label>
              <textarea
                value={reopenReason}
                onChange={(e) => setReopenReason(e.target.value)}
                required
                rows={3}
                placeholder="Enter reason for reopening (e.g. additional duty reconciliation)..."
                className="w-full border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                disabled={isReopening}
                onClick={() => setShowReopenModal(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors cursor-pointer text-xs disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isReopening || !reopenReason.trim()}
                onClick={handleExecuteReopen}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer text-xs"
              >
                {isReopening ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Reopening LC...</span>
                  </>
                ) : (
                  <>
                    <Unlock className="w-4 h-4" />
                    <span>Authorize & Reopen</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL 6: PRINT STATEMENT / VOUCHER (Preserved)                        */}
      {/* --------------------------------------------------------------------- */}
      {showPrintStatementModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs overflow-y-auto flex items-center justify-center p-4 overscroll-contain">
          <div 
            onWheel={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full p-6 animate-in fade-in zoom-in-95 space-y-4 max-h-[92vh] overflow-y-auto overscroll-contain my-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-black">
                  <Printer className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">LC Exporter Bill & Settlement Statement (A4)</h3>
                  <p className="text-[11px] text-slate-500">Dual Settlement Official & Hundi Clearance Sheet</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print Statement
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintStatementModal(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Sheet View */}
            <div className="p-6 bg-white border border-slate-200 rounded-2xl space-y-5 text-xs text-slate-900 font-sans print:border-none print:p-0">
              {/* Header */}
              <div className="text-center border-b pb-4">
                <h1 className="text-xl font-black text-slate-900 tracking-tight">M/S JUBAYER OVERSEAS</h1>
                <p className="text-xs text-slate-500">Government Approved Stone Importer & Infrastructure Supplier</p>
                <p className="text-[11px] text-slate-400">Sonahat & Burimari Land Port Operation • Head Office: Dhaka</p>
                <div className="mt-2 inline-block px-3 py-1 bg-slate-100 rounded-lg font-bold text-xs uppercase tracking-wider font-mono">
                  Dual LC Exporter Bills Settlement Statement
                </div>
              </div>

              {/* LC Basic Overview */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 text-[11px]">
                <div>
                  <span className="text-slate-500 block">LC Number:</span>
                  <span className="font-mono font-bold">{selectedLc.lcNumber}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Beneficiary Exporter:</span>
                  <span className="font-bold">{selectedLc.supplierName}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Total Quantity:</span>
                  <span className="font-mono font-bold">{totalLcQuantity.toLocaleString()} {selectedLc.uom || 'MT'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Status:</span>
                  <span className="font-bold text-indigo-700">{selectedLc.status}</span>
                </div>
              </div>

              {/* Bank Settlements Table */}
              <div className="space-y-1.5">
                <h4 className="font-black text-slate-800 text-xs flex items-center gap-1.5">
                  <Landmark className="w-3.5 h-3.5 text-blue-600" />
                  1. Official Bank LC Settlement:
                </h4>
                <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden text-[11px]">
                  <thead className="bg-slate-100 font-bold border-b border-slate-200">
                    <tr>
                      <th className="p-2">Date</th>
                      <th className="p-2">Bank & Debit Account</th>
                      <th className="p-2">Voucher / SWIFT Ref</th>
                      <th className="p-2 text-right">Foreign Currency</th>
                      <th className="p-2 text-right">Rate</th>
                      <th className="p-2 text-right">Total BDT</th>
                      <th className="p-2 text-right">Margin Adjusted</th>
                      <th className="p-2 text-right">Net Paid</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {(selectedLc.bankSettlements || []).map((b, i) => (
                      <tr key={i} className={b.status === 'Voided' ? 'line-through text-slate-400 bg-slate-50' : ''}>
                        <td className="p-2">{b.settlementDate}</td>
                        <td className="p-2 font-sans">{b.bankAccountName || b.bankName}</td>
                        <td className="p-2">{b.voucherNo || b.voucherNumber || b.swiftRef || '-'}</td>
                        <td className="p-2 text-right">{currSym}{b.amountForeign.toLocaleString()}</td>
                        <td className="p-2 text-right">{b.exchangeRate.toFixed(2)}</td>
                        <td className="p-2 text-right">৳{b.amountLocalBdt.toLocaleString()}</td>
                        <td className="p-2 text-right">৳{(b.marginAdjustedBdt || 0).toLocaleString()}</td>
                        <td className="p-2 text-right font-bold">৳{(b.netPaidBdt || b.amountLocalBdt).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Hundi Settlements Table */}
              <div className="space-y-1.5">
                <h4 className="font-black text-slate-800 text-xs flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-600" />
                  ২. হুন্ডি / সাইড-পেমেন্ট (Commercial Differential Hundi Settlement):
                </h4>
                <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden text-[11px]">
                  <thead className="bg-amber-50 font-bold border-b border-amber-200 text-amber-950">
                    <tr>
                      <th className="p-2">তারিখ</th>
                      <th className="p-2">একাউন্ট / মাধ্যম</th>
                      <th className="p-2">টোকেন / ভাউচার</th>
                      <th className="p-2 text-right">বাংলা টাকা (BDT)</th>
                      <th className="p-2 text-right">হুন্ডি রেট</th>
                      <th className="p-2 text-right">ইন্ডিয়ান রুপি (IC RS)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {(selectedLc.hundiPayments || []).map((h, i) => (
                      <tr key={i} className={h.status === 'Voided' ? 'line-through text-slate-400 bg-slate-50' : ''}>
                        <td className="p-2">{h.paymentDate}</td>
                        <td className="p-2 font-sans">{h.paidFromAccountName || h.hundiBroker}</td>
                        <td className="p-2">{h.voucherNo || h.receiptToken || '-'}</td>
                        <td className="p-2 text-right font-bold">৳{h.amountBdt.toLocaleString()}</td>
                        <td className="p-2 text-right">{h.hundiRateBdtToInr.toFixed(2)}</td>
                        <td className="p-2 text-right">₹{h.amountInr.toLocaleString()} IC RS</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer Audit info */}
              <div className="pt-8 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                <div>
                  <p>M/S JUBAYER OVERSEAS • TradeCore Enterprise ERP</p>
                  <p className="text-[10px]">Printed by: {currentUser?.name || 'Administrator'}, {new Date().toLocaleString()}</p>
                </div>
                <div className="text-right">
                  <p className="border-t border-slate-400 pt-1 w-40 text-center font-bold text-slate-800">
                    Authorized Signatory
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* VOUCHER PRINT MODAL (Requirement B.6, C.3)                            */}
      {/* --------------------------------------------------------------------- */}
      <VoucherPrintModal
        isOpen={!!selectedTxnForView}
        onClose={() => setSelectedTxnForView(null)}
        transaction={selectedTxnForView}
      />
    </div>
  );
};
