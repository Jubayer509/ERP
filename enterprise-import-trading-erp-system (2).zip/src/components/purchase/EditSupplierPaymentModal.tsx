import React, { useState } from 'react';
import { 
  CreditCard, 
  X, 
  Save, 
  Lock,
  AlertTriangle,
  RotateCcw,
  Loader2
} from 'lucide-react';
import { SupplierPaymentRecord, Supplier } from '../../types/erp';
import { ModalWrapper } from '../common/ModalWrapper';
import { useAuth } from '../../contexts/AuthContext';
import { voidAccountTransaction, editAccountTransaction, getAccountTransactions } from '../../services/accountService';

interface EditSupplierPaymentModalProps {
  isOpen: boolean;
  payment: SupplierPaymentRecord | null;
  suppliers: Supplier[];
  onClose: () => void;
  onSave: (updated: SupplierPaymentRecord) => void;
  onVoidPayment?: (voidedPayment: SupplierPaymentRecord) => void;
}

export const EditSupplierPaymentModal: React.FC<EditSupplierPaymentModalProps> = ({
  isOpen,
  payment,
  suppliers,
  onClose,
  onSave,
  onVoidPayment
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  if (!isOpen || !payment) return null;

  // Check if this payment is linked to a posted accounting voucher
  const linkedTxn = payment.voucherId
    ? getAccountTransactions().find(t => t.id === payment.voucherId)
    : getAccountTransactions().find(t => t.voucherNo === payment.voucherNumber && t.status !== 'voided');
  const hasPostedVoucher = Boolean(payment.voucherId || linkedTxn);
  const isAlreadyVoided = payment.status === 'Voided' || payment.isVoided || linkedTxn?.status === 'voided';

  const [paymentDate, setPaymentDate] = useState(payment.paymentDate);
  const [chequeNumber, setChequeNumber] = useState(payment.chequeNumber || '');
  const [chequeDate, setChequeDate] = useState(payment.chequeDate || '');
  const [notes, setNotes] = useState(payment.notes || '');
  const [voidReason, setVoidReason] = useState('');
  const [showVoidConfirm, setShowVoidConfirm] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isAlreadyVoided || isProcessing) return;
    setErrorMsg(null);
    setIsProcessing(true);

    try {
      const targetTxnId = payment.voucherId || linkedTxn?.id;
      if (targetTxnId) {
        await editAccountTransaction(
          targetTxnId,
          {
            date: paymentDate,
            referenceNo: payment.invoiceNumber || payment.voucherNumber,
            note: notes.trim()
          },
          {
            uid: currentUser?.id || 'usr-admin',
            name: currentUser?.name || 'Admin',
            email: currentUser?.email
          },
          'Updated supplier payment metadata'
        );
      }

      const updated: SupplierPaymentRecord = {
        ...payment,
        paymentDate,
        chequeNumber: payment.paymentMethod === 'Cheque' ? chequeNumber : payment.chequeNumber,
        chequeDate: payment.paymentMethod === 'Cheque' ? chequeDate : payment.chequeDate,
        notes: notes.trim()
      };
      onSave(updated);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to update payment metadata.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleVoidAndReverse = async () => {
    if (!isAdmin) {
      setErrorMsg('Only an Administrator can void a posted payment voucher.');
      return;
    }
    if (!voidReason.trim()) {
      setErrorMsg('Please enter a mandatory reason for voiding this payment voucher.');
      return;
    }
    setErrorMsg(null);
    setIsProcessing(true);

    try {
      const targetTxnId = payment.voucherId || linkedTxn?.id;
      if (targetTxnId) {
        await voidAccountTransaction(
          targetTxnId,
          voidReason.trim(),
          {
            uid: currentUser?.id || 'usr-admin',
            name: currentUser?.name || 'Admin',
            email: currentUser?.email
          }
        );
      }

      const voidedRecord: SupplierPaymentRecord = {
        ...payment,
        status: 'Voided',
        isVoided: true,
        voidReason: voidReason.trim(),
        voidedAt: new Date().toISOString(),
        voidedBy: currentUser?.name || 'Admin',
        notes: `${payment.notes || ''} | [VOIDED: ${voidReason.trim()}]`
      };

      if (onVoidPayment) {
        onVoidPayment(voidedRecord);
      } else {
        onSave(voidedRecord);
      }
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to void payment voucher.');
    } finally {
      setIsProcessing(false);
    }
  };

  const isDirty =
    paymentDate !== payment.paymentDate ||
    chequeNumber !== (payment.chequeNumber || '') ||
    chequeDate !== (payment.chequeDate || '') ||
    notes !== (payment.notes || '');

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      isDirty={isDirty}
      isSaving={isProcessing}
      backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-emerald-950 text-white flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center border border-emerald-400/20">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">Edit Supplier Payment</h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-emerald-500/30 text-emerald-200">
                  {payment.paymentNumber}
                </span>
              </div>
              <p className="text-xs text-slate-400">Supplier: {payment.supplierName}</p>
            </div>
          </div>
          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs">
          {/* Accounting Lock Banner */}
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-amber-900">
            <Lock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="font-bold text-xs">
                Accounting Lock: Financial Amounts & Disbursing Account Locked
              </div>
              <p className="text-[11px] text-amber-800">
                To change the payment amount, payment method, or paid-from account, an Administrator must <strong>Void &amp; Reverse</strong> this voucher ({payment.voucherNumber || 'Posted'}) and record a new payment entry.
              </p>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div>
              <label className="block font-semibold text-slate-500 mb-0.5">
                Posted Amount (Locked)
              </label>
              <div className="font-mono font-bold text-sm text-emerald-700">
                BDT {payment.amount.toLocaleString()}
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-500 mb-0.5">
                Voucher &amp; Method (Locked)
              </label>
              <div className="font-mono font-bold text-slate-800">
                {payment.voucherNumber || payment.paymentNumber} ({payment.paymentMethod})
              </div>
              {payment.bankName && (
                <div className="text-[10px] text-slate-500 truncate">{payment.bankName}</div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Payment Date</label>
              <input
                type="date"
                required
                disabled={isAlreadyVoided}
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2 font-mono text-slate-800 disabled:bg-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Linked Invoice</label>
              <input
                type="text"
                disabled
                value={payment.invoiceNumber || 'On-Account'}
                className="w-full border border-slate-200 rounded-xl p-2 font-mono bg-slate-100 text-slate-600 cursor-not-allowed"
              />
            </div>
          </div>

          {payment.paymentMethod === 'Cheque' && (
            <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Cheque Number</label>
                <input
                  type="text"
                  disabled={isAlreadyVoided}
                  value={chequeNumber}
                  onChange={(e) => setChequeNumber(e.target.value)}
                  placeholder="e.g. CQ-992144"
                  className="w-full border border-slate-300 rounded-xl p-2 font-mono bg-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Cheque Clearing Date</label>
                <input
                  type="date"
                  disabled={isAlreadyVoided}
                  value={chequeDate}
                  onChange={(e) => setChequeDate(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl p-2 font-mono bg-white"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Payment Notes / Description</label>
            <input
              type="text"
              disabled={isAlreadyVoided}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Cleared via RTGS for boulder delivery"
              className="w-full border border-slate-300 rounded-xl p-2 disabled:bg-slate-100"
            />
          </div>

          {/* Admin Void & Re-entry Section */}
          {!isAlreadyVoided && isAdmin && (
            <div className="pt-2 border-t border-slate-200">
              {!showVoidConfirm ? (
                <button
                  type="button"
                  onClick={() => setShowVoidConfirm(true)}
                  className="w-full py-2 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Admin: Void Voucher &amp; Reverse Balances (For Re-entry)</span>
                </button>
              ) : (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-2.5">
                  <div className="font-bold text-rose-900 text-xs">
                    Void Payment Voucher ({payment.voucherNumber || payment.paymentNumber})
                  </div>
                  <p className="text-[11px] text-rose-700">
                    This posts a reversing ledger entry (Dr Cash/Bank, Cr Supplier Payable), restores the supplier payable and invoice due balance, and marks this payment as Voided.
                  </p>
                  <input
                    type="text"
                    value={voidReason}
                    onChange={(e) => setVoidReason(e.target.value)}
                    placeholder="Mandatory void reason (e.g. Wrong account or amount entered)..."
                    className="w-full border border-rose-300 rounded-lg p-2 bg-white text-slate-900 text-xs outline-none"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setShowVoidConfirm(false);
                        setVoidReason('');
                      }}
                      className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-700 font-semibold text-xs cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={isProcessing || !voidReason.trim()}
                      onClick={handleVoidAndReverse}
                      className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-300 text-white rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      {isProcessing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
                      <span>Confirm Void &amp; Reverse</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              data-modal-close="true"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 font-semibold"
            >
              Cancel
            </button>
            {!isAlreadyVoided && (
              <button
                type="submit"
                disabled={isProcessing}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                <span>Save Metadata</span>
              </button>
            )}
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};
