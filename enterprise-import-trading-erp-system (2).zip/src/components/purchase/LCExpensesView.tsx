import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Calculator, 
  Receipt, 
  DollarSign, 
  Plus, 
  CheckCircle2, 
  Ship, 
  AlertCircle,
  FileCheck,
  Building2,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  Percent,
  Search,
  ChevronDown,
  X,
  CreditCard,
  FileText,
  ShieldAlert,
  Loader2,
  Lock,
  AlertTriangle
} from 'lucide-react';
import { LetterOfCredit, BankAccount, Supplier, AccountCOA } from '../../types/erp';
import { AccountTransaction, PaymentMethod, AccountHead } from '../../types/accounts';
import { useAuth } from '../../contexts/AuthContext';
import { getBankAccounts, subscribeBankAccounts, isCashAccount as checkIsCashAccount } from '../../utils/bankAccountStorage';
import { getSuppliers, subscribeSuppliers } from '../../utils/supplierStorage';
import { getCOA, subscribeCOA } from '../../utils/coaStorage';
import { 
  postVoucher, 
  getAccountHeads, 
  addAccountHead, 
  getAccountTransactions, 
  subscribeAccountTransactions 
} from '../../services/accountService';
import { VoucherPrintModal } from '../accounts/VoucherPrintModal';
import { 
  LCModal, 
  LCFormField, 
  LCInput, 
  LCSelect, 
  LCButton, 
  LCSection 
} from '../lc/ui';
import { computeLcBill } from '../../utils/lcBillingHelper';
import { calculateLcTariff, updateDutyHeadCapitalize } from '../../utils/lcTariff';

interface LCExpensesViewProps {
  lcs: LetterOfCredit[];
  selectedLc: LetterOfCredit;
  onSelectLc: (lc: LetterOfCredit) => void;
  onUpdateLcExpenses: (
    lcId: string, 
    newExpense: {
      id?: string;
      expenseType: string;
      amountLocal: number;
      paidTo: string;
      status: 'Paid' | 'Billed' | 'Invoiced' | 'Estimated' | 'Voided';
      voucherNo?: string;
      lcId?: string;
      paymentDate?: string;
      paidFromAccountId?: string;
      paidFromAccountName?: string;
      paymentMethod?: string;
      referenceNo?: string;
      transactionId?: string;
      postedBy?: {
        uid: string;
        name: string;
        email?: string;
      } | string;
      postedAt?: string;
    }
  ) => void;
  onNavigateToBills: () => void;
  onPostMargin?: (lc: LetterOfCredit) => void;
}

export const LCExpensesView: React.FC<LCExpensesViewProps> = ({
  lcs,
  selectedLc,
  onSelectLc,
  onUpdateLcExpenses,
  onNavigateToBills,
  onPostMargin
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';
  const userBranch = currentUser?.branch;

  // Real-time subscriptions to Bank Accounts, Account Transactions, and Chart of Accounts
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  const [accountTransactions, setAccountTransactions] = useState<AccountTransaction[]>(() => getAccountTransactions());
  const [coaList, setCoaList] = useState<AccountCOA[]>(() => getCOA());

  useEffect(() => {
    const unsubBanks = subscribeBankAccounts(setBankAccounts);
    const unsubTxns = subscribeAccountTransactions(setAccountTransactions);
    const unsubCoa = subscribeCOA(setCoaList);
    return () => {
      unsubBanks();
      unsubTxns();
      unsubCoa();
    };
  }, []);

  // Expense accounts strictly from Chart of Accounts ("All Expenses" list)
  const coaExpenseHeads = useMemo(() => {
    return coaList.filter(head => head.category === 'Expense');
  }, [coaList]);

  // Filter accounts: managers see only their own branch accounts; admin sees all
  const accessibleBankAccounts = useMemo(() => {
    let list = bankAccounts;
    if (!isAdmin && userBranch && userBranch !== 'All Branches') {
      list = bankAccounts.filter(
        b => !b.branch || b.branch === 'All Branches' || b.branch.toLowerCase().trim() === userBranch.toLowerCase().trim()
      );
    }
    const seen = new Set<string>();
    return list.filter(b => {
      if (!b?.id || seen.has(b.id)) return false;
      seen.add(b.id);
      return true;
    });
  }, [bankAccounts, isAdmin, userBranch]);

  // Modal State
  const [showAddExpenseModal, setShowAddExpenseModal] = useState(false);
  const [payNowTargetId, setPayNowTargetId] = useState<string | null>(null);

  // Form Fields (Empty by default per Requirement 4)
  const [formLcId, setFormLcId] = useState<string>('');
  const [expenseHead, setExpenseHead] = useState<string>('');
  const [expenseAmount, setExpenseAmount] = useState<string>('');
  const [expensePaidTo, setExpensePaidTo] = useState<string>('');
  const [expenseStatus, setExpenseStatus] = useState<'Estimated' | 'Billed' | 'Paid'>('' as any);

  // Suppliers subscription for Payable To dropdown (Requirement 5)
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => getSuppliers());
  useEffect(() => {
    const unsub = subscribeSuppliers(setSuppliers);
    return () => unsub();
  }, []);

  // Vendor selection & inline add vendor state
  const [selectedVendorId, setSelectedVendorId] = useState<string>('');
  const [showAddVendorInline, setShowAddVendorInline] = useState<boolean>(false);
  const [newVendorName, setNewVendorName] = useState<string>('');
  const [newVendorCountry, setNewVendorCountry] = useState<string>('');
  const [newVendorPhone, setNewVendorPhone] = useState<string>('');

  // Paid From fields (when status === 'Paid')
  const [paymentDate, setPaymentDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [paidFromAccountId, setPaidFromAccountId] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('' as any);
  const [referenceNo, setReferenceNo] = useState<string>('');
  const [narration, setNarration] = useState<string>('');
  const [adminApprovedOverdraft, setAdminApprovedOverdraft] = useState<boolean>(false);

  // Searchable dropdown state
  const [accountSearchTerm, setAccountSearchTerm] = useState<string>('');
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState<boolean>(false);
  const accountDropdownRef = useRef<HTMLDivElement>(null);

  // UI state
  const [formError, setFormError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const isSubmittingExpenseRef = useRef<boolean>(false);

  // Voucher print view modal
  const [selectedTxnForView, setSelectedTxnForView] = useState<AccountTransaction | null>(null);

  // Close account dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (accountDropdownRef.current && !accountDropdownRef.current.contains(event.target as Node)) {
        setIsAccountDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Selected Bank / Cash Account
  const selectedBankAccount = useMemo(() => {
    return bankAccounts.find(b => b.id === paidFromAccountId);
  }, [bankAccounts, paidFromAccountId]);

  // Cash account detection
  const isCashAccount = useMemo(() => {
    return checkIsCashAccount(selectedBankAccount);
  }, [selectedBankAccount]);

  // Automatically lock paymentMethod to Cash for cash accounts
  useEffect(() => {
    if (isCashAccount) {
      setPaymentMethod('Cash');
    } else if (paymentMethod === 'Cash' && selectedBankAccount && !isCashAccount) {
      setPaymentMethod('Bank Transfer');
    }
  }, [isCashAccount, selectedBankAccount]);

  // Search filtered accounts
  const filteredAccounts = useMemo(() => {
    if (!accountSearchTerm.trim()) return accessibleBankAccounts;
    const term = accountSearchTerm.toLowerCase();
    return accessibleBankAccounts.filter(
      b =>
        b.bankName.toLowerCase().includes(term) ||
        (b.accountNumber && b.accountNumber.toLowerCase().includes(term)) ||
        (b.branch && b.branch.toLowerCase().includes(term)) ||
        (b.accountType && b.accountType.toLowerCase().includes(term))
    );
  }, [accessibleBankAccounts, accountSearchTerm]);

  const submissionDraftIdRef = useRef<string>(`exp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`);

  // Form Reset Helper
  const resetForm = (clearLock: boolean = false) => {
    if (clearLock) {
      isSubmittingExpenseRef.current = false;
      setIsSaving(false);
    }
    submissionDraftIdRef.current = `exp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setPayNowTargetId(null);
    setFormLcId('');
    setExpenseHead('');
    setExpenseAmount('');
    setExpensePaidTo('');
    setSelectedVendorId('');
    setShowAddVendorInline(false);
    setNewVendorName('');
    setNewVendorPhone('');
    setExpenseStatus('' as any);
    setPaymentDate(new Date().toISOString().split('T')[0]);
    setPaidFromAccountId('');
    setAccountSearchTerm('');
    setIsAccountDropdownOpen(false);
    setPaymentMethod('' as any);
    setReferenceNo('');
    setNarration('');
    setAdminApprovedOverdraft(false);
    setFormError(null);
  };

  const isExpenseFormDirty = payNowTargetId
    ? Boolean(paidFromAccountId || referenceNo.trim() || narration.trim())
    : Boolean(
        expenseHead ||
        (expenseAmount !== '' && Number(expenseAmount) > 0) ||
        paidFromAccountId ||
        referenceNo.trim() ||
        narration.trim()
      );

  const handleCloseExpenseModal = () => {
    if (isSaving) return;
    resetForm();
    setShowAddExpenseModal(false);
  };

  // Helper to determine effective status (accounts for voided vouchers in Accounts)
  const getExpenseEffectiveStatus = (exp: any): 'Paid' | 'Billed' | 'Estimated' | 'Voided' => {
    if (exp.status === 'Voided') return 'Voided';
    if (exp.voucherNo) {
      const txn = accountTransactions.find(
        t => t.voucherNo === exp.voucherNo || (exp.transactionId && t.id === exp.transactionId)
      );
      if (txn && txn.status === 'voided') {
        return 'Voided';
      }
    }
    if (exp.status === 'Invoiced') return 'Billed';
    return exp.status;
  };

  // Helper to determine if an expense head is capitalizable to inventory landed cost (IAS 2)
  const isHeadCapitalizable = (head: string): boolean => {
    const lower = (head || '').toLowerCase();
    if (
      lower.includes('bank commission') ||
      lower.includes('bank charge') ||
      lower.includes('swift') ||
      lower.includes('fine') ||
      lower.includes('penalty')
    ) {
      return false;
    }
    return true;
  };

  // Landed Cost Calculations: activeExpenses used for totalClearanceLogistics and totalLandedCostBDT must EXCLUDE status Estimated and Voided
  const activeExpenses = useMemo(() => {
    return selectedLc.expenses.filter(e => {
      const st = getExpenseEffectiveStatus(e);
      return st !== 'Voided' && st !== 'Estimated';
    });
  }, [selectedLc.expenses, accountTransactions]);

  const estimatedExpenses = useMemo(() => {
    return selectedLc.expenses.filter(e => getExpenseEffectiveStatus(e) === 'Estimated');
  }, [selectedLc.expenses, accountTransactions]);

  const estimatedTotal = useMemo(() => {
    return estimatedExpenses.reduce((sum, e) => sum + (Number(e.amountLocal) || 0), 0);
  }, [estimatedExpenses]);

  // Requirement 1: Use computeLcBill for base bill and billable quantity
  const lcBill = useMemo(() => computeLcBill(selectedLc), [selectedLc]);
  const baseFobBdt = lcBill.officialBillBdt;

  // Real saved expenses only. All hardcoded fallback values deleted (default to 0 if not recorded).
  const portDemurrageBDT = activeExpenses.find(e => e.expenseType.toLowerCase().includes('port demurrage') || e.expenseType.toLowerCase().includes('demurrage'))?.amountLocal || 0;
  const cfCommissionBDT = activeExpenses.find(e => e.expenseType.toLowerCase().includes('c&f') || e.expenseType.toLowerCase().includes('clearing'))?.amountLocal || 0;
  const localCarriageBDT = activeExpenses.find(e => e.expenseType.toLowerCase().includes('local freight') || e.expenseType.toLowerCase().includes('freight') || e.expenseType.toLowerCase().includes('carriage'))?.amountLocal || 0;
  const marineInsuranceBDT = activeExpenses.find(e => e.expenseType.toLowerCase().includes('marine insurance') || e.expenseType.toLowerCase().includes('insurance'))?.amountLocal || 0;
  const bankCommissionBDT = activeExpenses.find(e => e.expenseType.toLowerCase().includes('bank commission') || e.expenseType.toLowerCase().includes('bank charge'))?.amountLocal || 0;

  // Real actual clearance & logistics expenses (excluding non-capitalized heads like bank commission)
  const realActualExpenses = activeExpenses
    .filter(e => isHeadCapitalizable(e.expenseType))
    .reduce((sum, e) => sum + (Number(e.amountLocal) || 0), 0);

  // HS code linked to the LC's item (the stone item uses 2517.10.00 as shown in the existing tariff panel, never 7208.38.00)
  const selectedHsCode = selectedLc.items[0]?.hsCode?.trim() || '2517.10.00';

  // Listen for tariff configuration updates
  const [tariffVersion, setTariffVersion] = useState(0);
  useEffect(() => {
    const handleTariffChange = () => setTariffVersion(v => v + 1);
    window.addEventListener('tradecore_tariff_changed', handleTariffChange);
    return () => window.removeEventListener('tradecore_tariff_changed', handleTariffChange);
  }, []);

  const tariffResult = useMemo(() => {
    return calculateLcTariff(baseFobBdt, selectedHsCode);
  }, [baseFobBdt, selectedHsCode, tariffVersion]);

  // Check if actual Bill of Entry is posted
  const hasActualBoe = Boolean(
    (selectedLc.boeNumber && selectedLc.boeNumber !== 'BOE-PENDING' && selectedLc.boeNumber.trim() !== '') ||
    activeExpenses.some(e => e.expenseType.toLowerCase().includes('customs duty') && (e.status === 'Paid' || e.voucherNo))
  );

  // Dr Raw Material Inventory = CFR BDT + capitalizable duties + capitalizable actual expenses.
  // Bank margin and bank commission must NOT appear in the inventory entry or in landed cost.
  const inventoryDrBdt = baseFobBdt + tariffResult.capitalizableDutiesBdt + realActualExpenses;
  const totalLandedCostBDT = inventoryDrBdt;

  const totalClearanceLogistics = tariffResult.totalDutiesBdt + realActualExpenses;
  const totalQty = lcBill.billableQty > 0 ? lcBill.billableQty : (selectedLc.items.reduce((acc, itm) => acc + itm.quantity, 0) || (selectedLc.quantity || 1));
  const unitLandedCostBDT = totalQty > 0 ? Math.round(totalLandedCostBDT / totalQty) : 0;
  const cfrCostPerMt = totalQty > 0 ? (baseFobBdt / totalQty) : 0;
  const isLandedCostSpike = cfrCostPerMt > 0 && unitLandedCostBDT > (cfrCostPerMt * 2);

  const commodityDescription = selectedLc.items.map(i => i.itemName).join(', ') || selectedLc.originQuarryItem || 'Boulder Stone';

  // Rebuilt GL Journal lines from real values (no plug, no balancing figure)
  const glLines = useMemo(() => {
    const lines = [
      {
        type: 'DR' as const,
        accountCode: '13100',
        accountName: 'Raw Material Inventory (Landed Stock)',
        particulars: `LC ${selectedLc.lcNumber} Landed Inventory (CFR ৳${baseFobBdt.toLocaleString()} + Cap. Duties ৳${tariffResult.capitalizableDutiesBdt.toLocaleString()}${realActualExpenses > 0 ? ` + Actual Logistics ৳${realActualExpenses.toLocaleString()}` : ''})`,
        amount: inventoryDrBdt
      },
      {
        type: 'DR' as const,
        accountCode: '11410',
        accountName: 'VAT Current Account (Input Tax Receivable)',
        particulars: `Import VAT (Mushak 9.1) @ 15% - Non-capitalized Tax Asset`,
        amount: tariffResult.vatAmount
      },
      {
        type: 'DR' as const,
        accountCode: '11420',
        accountName: 'Advance Income Tax Asset (AIT Sec 82C)',
        particulars: `Advance Income Tax @ 5% - Tax Receivable Asset`,
        amount: tariffResult.aitAmount
      },
      {
        type: 'DR' as const,
        accountCode: '11430',
        accountName: 'Advance Tax Asset (AT Mushak 9.1)',
        particulars: `Advance Tax @ 5% - Tax Receivable Asset`,
        amount: tariffResult.atAmount
      },
      {
        type: 'CR' as const,
        accountCode: '21100',
        accountName: 'Foreign Supplier Payable (CFR)',
        particulars: `CFR Document Value payable to ${selectedLc.supplierName}`,
        amount: baseFobBdt
      },
      {
        type: 'CR' as const,
        accountCode: '21400',
        accountName: 'Customs & Port Clearing Accrual',
        particulars: `${hasActualBoe ? 'Assessed' : 'Provisional'} Customs Duties (CD+RD+SD+VAT+AIT+AT)${realActualExpenses > 0 ? ` + Logistics Accrual` : ''}`,
        amount: tariffResult.totalDutiesBdt + realActualExpenses
      }
    ];

    const totalDebits = lines.filter(l => l.type === 'DR').reduce((sum, l) => sum + l.amount, 0);
    const totalCredits = lines.filter(l => l.type === 'CR').reduce((sum, l) => sum + l.amount, 0);
    const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01 && totalDebits > 0;

    return {
      lines,
      totalDebits,
      totalCredits,
      isBalanced
    };
  }, [baseFobBdt, tariffResult, realActualExpenses, inventoryDrBdt, selectedLc, hasActualBoe]);

  // Balance validations
  const numericAmount = Number(expenseAmount) || 0;
  const currentAccountBalance = selectedBankAccount ? (selectedBankAccount.ledgerBalance || 0) : 0;
  const isCashDeficit = expenseStatus === 'Paid' && isCashAccount && currentAccountBalance < numericAmount;
  const isBankOverdraft = expenseStatus === 'Paid' && !isCashAccount && selectedBankAccount && currentAccountBalance < numericAmount;

  // Account Head matching helper (Requirement 3)
  const getOrCreateMatchingAccountHead = async (category: string): Promise<AccountHead> => {
    const coaMatch = coaList.find(
      c => c.category === 'Expense' && (c.name.toLowerCase() === category.toLowerCase() || c.code.toLowerCase() === category.toLowerCase())
    );
    if (coaMatch) {
      return {
        id: `coa-${coaMatch.code}`,
        code: coaMatch.code,
        name: coaMatch.name,
        nameEn: coaMatch.name,
        nameBn: coaMatch.name,
        type: 'Expense',
        active: true,
        createdAt: new Date().toISOString()
      };
    }

    const heads = getAccountHeads();
    const lower = category.toLowerCase();

    // 1. Port & Customs Clearing
    if (lower.includes('port') || lower.includes('demurrage') || lower.includes('custom') || lower.includes('c&f') || lower.includes('cpa') || lower.includes('clearing')) {
      const found = heads.find(h => h.code === 'EXP-505' || h.name.toLowerCase().includes('port') || h.name.toLowerCase().includes('custom') || h.name.toLowerCase().includes('clearing'));
      if (found) return found;
    }

    // 2. Freight & Transport
    if (lower.includes('freight') || lower.includes('transport') || lower.includes('carriage') || lower.includes('trailer') || lower.includes('haulage')) {
      const found = heads.find(h => h.code === 'EXP-503' || h.name.toLowerCase().includes('freight') || h.name.toLowerCase().includes('transport'));
      if (found) return found;
    }

    // 3. Bank Commission / Swift
    if (lower.includes('bank') || lower.includes('commission') || lower.includes('swift') || lower.includes('acceptance')) {
      const found = heads.find(h => h.code === 'EXP-511' || h.name.toLowerCase().includes('commission') || h.name.toLowerCase().includes('bank charge'));
      if (found) return found;
    }

    // 4. Warehouse & Labour
    if (lower.includes('labour') || lower.includes('crush') || lower.includes('unloading') || lower.includes('warehouse')) {
      const found = heads.find(h => h.code === 'EXP-507' || h.name.toLowerCase().includes('labour') || h.name.toLowerCase().includes('unloading'));
      if (found) return found;
    }

    // 5. Look for any existing head named "LC Landed Cost - Capitalized"
    const lcCap = heads.find(h => h.name.toLowerCase().includes('lc landed cost') || h.nameEn?.toLowerCase().includes('lc landed cost') || h.code === 'EXP-LC-CAP');
    if (lcCap) return lcCap;

    // 6. Direct match
    const directMatch = heads.find(h => h.name.toLowerCase() === lower || h.nameEn?.toLowerCase() === lower);
    if (directMatch) return directMatch;

    // 7. If no match exists, create "LC Landed Cost - Capitalized"
    try {
      const created = await addAccountHead({
        code: 'EXP-LC-CAP',
        name: 'LC Landed Cost - Capitalized',
        nameEn: 'LC Landed Cost - Capitalized',
        nameBn: 'LC Landed Cost - Capitalized',
        type: 'Expense',
        description: 'Capitalized logistics, port, customs, and clearance costs for Letter of Credit imports',
        active: true,
        isSystem: true
      });
      return created;
    } catch (err) {
      console.warn('Fallback to first expense head:', err);
      const fallback = heads.find(h => h.type === 'Expense') || {
        id: 'head-exp-lc-cap',
        code: 'EXP-LC-CAP',
        name: 'LC Landed Cost - Capitalized',
        nameEn: 'LC Landed Cost - Capitalized',
        nameBn: 'LC Landed Cost - Capitalized',
        type: 'Expense',
        active: true,
        createdAt: new Date().toISOString()
      };
      return fallback;
    }
  };

  // Convert / Pay Now Handler
  const handlePayNow = (exp: any) => {
    resetForm();
    setPayNowTargetId(exp.id);
    setFormLcId(selectedLc.id);
    setExpenseHead(exp.expenseType);
    setExpenseAmount(String(exp.amountLocal));
    setExpensePaidTo(exp.paidTo);
    const supp = suppliers.find(s => s.name === exp.paidTo);
    if (supp) setSelectedVendorId(supp.id);
    setExpenseStatus('Paid');
    setPaymentDate(new Date().toISOString().split('T')[0]);
    setShowAddExpenseModal(true);
  };

  // Convert to Billed Handler
  const handleConvertToBilled = (exp: any) => {
    resetForm();
    setPayNowTargetId(exp.id);
    setFormLcId(selectedLc.id);
    setExpenseHead(exp.expenseType);
    setExpenseAmount(String(exp.amountLocal));
    setExpensePaidTo(exp.paidTo);
    const supp = suppliers.find(s => s.name === exp.paidTo);
    if (supp) setSelectedVendorId(supp.id);
    setExpenseStatus('Billed');
    setPaymentDate(new Date().toISOString().split('T')[0]);
    setShowAddExpenseModal(true);
  };

  // View Voucher Handler (Requirement 5)
  const handleViewVoucher = (voucherNo?: string, transactionId?: string, exp?: any) => {
    if (!voucherNo) return;
    const found = accountTransactions.find(t => t.voucherNo === voucherNo || (transactionId && t.id === transactionId));
    if (found) {
      setSelectedTxnForView(found);
    } else if (exp) {
      // Fallback synthetic transaction
      const fallbackTxn: AccountTransaction = {
        id: transactionId || `txn-${voucherNo}`,
        voucherNo,
        date: exp.paymentDate || '2026-01-01',
        transactionType: 'PAYMENT',
        subType: 'Expense / General Payment',
        amount: exp.amountLocal,
        bankAccountId: exp.paidFromAccountId || 'acc-cash',
        bankAccountName: exp.paidFromAccountName || 'Paid Cash/Bank Account',
        paymentMethod: (exp.paymentMethod as any) || 'Cash',
        referenceNo: exp.referenceNo,
        note: `LC ${selectedLc.lcNumber} - ${exp.expenseType} - ${exp.paidTo}`,
        branch: selectedLc.branch || 'Head Office',
        status: exp.status === 'Voided' ? 'voided' : 'active',
        createdBy: typeof exp.postedBy === 'object' && exp.postedBy ? exp.postedBy : { uid: 'user', name: exp.postedBy || 'Authorized Officer' },
        createdAt: exp.postedAt || new Date().toISOString()
      };
      setSelectedTxnForView(fallbackTxn);
    }
  };

  // Form Submission
  const handleExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingExpenseRef.current) return;
    setFormError(null);

    const amt = Number(expenseAmount);
    if (!amt || amt <= 0) {
      setFormError('Expense amount must be greater than zero.');
      return;
    }

    if (!expenseHead.trim()) {
      setFormError('Please select or enter an expense head category.');
      return;
    }

    const selectedVendor = suppliers.find(s => s.id === selectedVendorId || (expensePaidTo && s.name === expensePaidTo));
    const vendorName = selectedVendor?.name || expensePaidTo.trim() || expenseHead;

    const chosenLc = lcs.find(l => l.id === formLcId) || selectedLc;
    const lcNum = chosenLc.lcNumber;
    const isCap = isHeadCapitalizable(expenseHead);

    if (expenseStatus === 'Estimated') {
      // Estimated: provisional record only. No GL posting, no inventory change, no payable.
      setIsSaving(true);
      onUpdateLcExpenses(chosenLc.id, {
        id: payNowTargetId || undefined,
        expenseType: expenseHead,
        amountLocal: amt,
        paidTo: vendorName,
        status: 'Estimated',
        lcId: chosenLc.id
      });

      if (chosenLc.id !== selectedLc.id) {
        onSelectLc(chosenLc);
      }

      resetForm();
      setShowAddExpenseModal(false);
      return;
    }

    if (expenseStatus === 'Billed') {
      isSubmittingExpenseRef.current = true;
      setIsSaving(true);
      try {
        const matchedHead = await getOrCreateMatchingAccountHead(expenseHead);
        const defaultNarration = `LC ${lcNum} - ${expenseHead}`;
        const finalNarration = narration.trim()
          ? (narration.includes(lcNum) ? narration.trim() : `LC ${lcNum} - ${narration.trim()}`)
          : defaultNarration;
        const finalRef = referenceNo.trim()
          ? (referenceNo.includes(lcNum) ? referenceNo.trim() : `${referenceNo.trim()} (LC ${lcNum})`)
          : `LC ${lcNum}`;
        const targetExpenseId = payNowTargetId || submissionDraftIdRef.current;
        const postedAtIso = new Date().toISOString();
        const effDate = paymentDate || postedAtIso.split('T')[0];

        const postedTxn = await postVoucher({
          transactionType: 'JOURNAL',
          subType: 'Vendor Bill / LC Logistics Expense',
          date: effDate,
          amount: amt,
          partyType: selectedVendor ? 'Supplier' : 'None',
          partyId: selectedVendor?.id,
          partyName: selectedVendor?.name || vendorName,
          partyCode: selectedVendor?.code,
          accountHeadCode: isCap ? '13100' : (matchedHead.code || 'EXP-LC-GEN'),
          accountHeadName: isCap ? 'Raw Material Inventory (Landed Stock)' : matchedHead.name,
          accountHeadId: isCap ? '13100' : matchedHead.id,
          debitLines: [
            {
              accountCode: isCap ? '13100' : (matchedHead.code || 'EXP-LC-GEN'),
              particulars: finalNarration,
              amount: amt
            }
          ],
          creditLines: [
            {
              accountCode: selectedVendor?.code || '21400',
              particulars: finalNarration,
              amount: amt
            }
          ],
          referenceNo: finalRef,
          note: finalNarration,
          costCenter: 'LC Import Logistics',
          branch: chosenLc.branch || 'Head Office',
          user: {
            uid: currentUser?.uid || 'user-admin',
            name: currentUser?.name || 'Authorized User',
            email: currentUser?.email || 'admin@tradecore.local'
          },
          idempotencyKey: `lc_exp_bill_${targetExpenseId}`,
          lcId: chosenLc.id,
          lcNumber: chosenLc.lcNumber,
          lcExpenseId: targetExpenseId,
          lcExpenseHead: expenseHead,
          lcExpenseRecord: {
            id: targetExpenseId,
            lcId: chosenLc.id,
            lcNumber: chosenLc.lcNumber,
            expenseType: expenseHead,
            amountLocal: amt,
            paidTo: selectedVendor?.name || vendorName,
            status: 'Billed',
            paymentDate: effDate,
            referenceNo: finalRef,
            accountHeadId: matchedHead.id,
            accountHeadCode: matchedHead.code,
            capitalizedToInventory: isCap,
            postedBy: {
              uid: currentUser?.uid || 'user-admin',
              name: currentUser?.name || 'Authorized User',
              email: currentUser?.email || 'admin@tradecore.local'
            },
            postedAt: postedAtIso
          }
        });

        onUpdateLcExpenses(chosenLc.id, {
          id: targetExpenseId,
          expenseType: expenseHead,
          amountLocal: amt,
          paidTo: selectedVendor?.name || vendorName,
          status: 'Billed',
          voucherNo: postedTxn.voucherNo,
          transactionId: postedTxn.id,
          lcId: chosenLc.id,
          paymentDate: effDate,
          referenceNo: finalRef,
          postedBy: {
            uid: currentUser?.uid || 'user-admin',
            name: currentUser?.name || 'Authorized User',
            email: currentUser?.email || 'admin@tradecore.local'
          },
          postedAt: postedAtIso
        });

        if (chosenLc.id !== selectedLc.id) {
          onSelectLc(chosenLc);
        }

        resetForm();
        setShowAddExpenseModal(false);
      } catch (err: any) {
        console.error('Failed to post vendor bill voucher for LC expense:', err);
        setFormError(err?.message || 'Bill voucher posting failed. The LC expense was not saved.');
        return;
      } finally {
        isSubmittingExpenseRef.current = false;
        setIsSaving(false);
      }
      return;
    }

    if (expenseStatus === 'Paid') {
      if (!paidFromAccountId || !selectedBankAccount) {
        setFormError('Please select a valid Cash or Bank account to pay from.');
        return;
      }

      if (isCashAccount && currentAccountBalance < amt) {
        setFormError(`Cash account balance (৳${currentAccountBalance.toLocaleString()}) is lower than the amount (৳${amt.toLocaleString()}). Cash balance cannot be negative.`);
        return;
      }

      if (!isCashAccount && currentAccountBalance < amt) {
        if (!isAdmin) {
          setFormError(`Bank account has insufficient balance (৳${currentAccountBalance.toLocaleString()}). Only an Admin can approve an overdraft.`);
          return;
        }
        if (!adminApprovedOverdraft) {
          setFormError('This bank account has insufficient balance. Please confirm Admin Overdraft Approval to continue.');
          return;
        }
      }

      isSubmittingExpenseRef.current = true;
      setIsSaving(true);
      try {
        const matchedHead = await getOrCreateMatchingAccountHead(expenseHead);
        const defaultNarration = `LC ${lcNum} - ${expenseHead}`;
        const finalNarration = narration.trim()
          ? (narration.includes(lcNum) ? narration.trim() : `LC ${lcNum} - ${narration.trim()}`)
          : defaultNarration;
        const finalRef = referenceNo.trim()
          ? (referenceNo.includes(lcNum) ? referenceNo.trim() : `${referenceNo.trim()} (LC ${lcNum})`)
          : `LC ${lcNum}`;

        // Check if settling an already billed vendor record
        const existingExp = payNowTargetId ? selectedLc.expenses.find(e => e.id === payNowTargetId) : null;
        const isSettlingExistingBill = existingExp && existingExp.status === 'Billed' && selectedVendor;
        const targetExpenseId = payNowTargetId || submissionDraftIdRef.current;
        const postedAtIso = new Date().toISOString();
        const effDate = paymentDate || postedAtIso.split('T')[0];
        const formattedPaidFrom = `${selectedBankAccount.bankName} (${selectedBankAccount.accountNumber})`;

        const postedTxn = await postVoucher({
          transactionType: 'PAYMENT',
          subType: isSettlingExistingBill ? 'Payment to Supplier' : 'LC Logistics Payment',
          date: effDate,
          amount: amt,
          bankAccountId: paidFromAccountId,
          paymentMethod: isCashAccount ? 'Cash' : (paymentMethod || 'Bank Transfer'),
          referenceNo: finalRef,
          note: finalNarration,
          costCenter: 'LC Import Logistics',
          branch: selectedBankAccount.branch || chosenLc.branch || 'Head Office',
          partyType: selectedVendor ? 'Supplier' : 'None',
          partyId: selectedVendor ? selectedVendor.id : undefined,
          partyName: selectedVendor ? selectedVendor.name : undefined,
          accountHeadId: matchedHead.id,
          accountHeadName: matchedHead.name,
          accountHeadCode: isCap ? '13100' : (matchedHead.code || 'EXP-LC-CAP'),
          debitLines: [
            {
              accountCode: isSettlingExistingBill ? (selectedVendor?.code || '21100') : (isCap ? '13100' : (matchedHead.code || 'EXP-LC-CAP')),
              particulars: finalNarration,
              amount: amt
            }
          ],
          user: {
            uid: currentUser?.uid || 'user-admin',
            name: currentUser?.name || 'Authorized User',
            email: currentUser?.email || 'admin@tradecore.local'
          },
          adminApprovedOverdraft: isBankOverdraft && isAdmin && adminApprovedOverdraft,
          idempotencyKey: `lc_exp_paid_${targetExpenseId}`,
          lcId: chosenLc.id,
          lcNumber: chosenLc.lcNumber,
          lcExpenseId: targetExpenseId,
          lcExpenseHead: expenseHead,
          lcExpenseRecord: {
            id: targetExpenseId,
            lcId: chosenLc.id,
            lcNumber: chosenLc.lcNumber,
            expenseType: expenseHead,
            amountLocal: amt,
            paidTo: vendorName,
            status: 'Paid',
            paymentDate: effDate,
            paidFromAccountId: selectedBankAccount.id,
            paidFromAccountName: formattedPaidFrom,
            paymentMethod: isCashAccount ? 'Cash' : paymentMethod,
            referenceNo: finalRef,
            accountHeadId: matchedHead.id,
            accountHeadCode: matchedHead.code,
            capitalizedToInventory: isCap,
            postedBy: {
              uid: currentUser?.uid || 'user-admin',
              name: currentUser?.name || 'Authorized User',
              email: currentUser?.email || 'admin@tradecore.local'
            },
            postedAt: postedAtIso
          }
        });

        onUpdateLcExpenses(chosenLc.id, {
          id: targetExpenseId,
          expenseType: expenseHead,
          amountLocal: amt,
          paidTo: vendorName,
          status: 'Paid',
          voucherNo: postedTxn.voucherNo,
          transactionId: postedTxn.id,
          lcId: chosenLc.id,
          paymentDate: effDate,
          paidFromAccountId: selectedBankAccount.id,
          paidFromAccountName: formattedPaidFrom,
          paymentMethod: isCashAccount ? 'Cash' : paymentMethod,
          referenceNo: finalRef,
          postedBy: {
            uid: currentUser?.uid || 'user-admin',
            name: currentUser?.name || 'Authorized User',
            email: currentUser?.email || 'admin@tradecore.local'
          },
          postedAt: postedAtIso
        });

        if (chosenLc.id !== selectedLc.id) {
          onSelectLc(chosenLc);
        }

        resetForm();
        setShowAddExpenseModal(false);
      } catch (err: any) {
        console.error('Failed to post payment voucher for LC expense:', err);
        setFormError(err?.message || 'Payment voucher posting failed. The LC expense was not saved.');
        return;
      } finally {
        isSubmittingExpenseRef.current = false;
        setIsSaving(false);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: LC Selector & Core Landed Cost KPIs */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Calculator className="w-5 h-5 text-blue-600" />
              LC Expenses & Landed Cost Breakdown
            </h2>
          </div>

          {/* Quick LC Selector Dropdown & Actions */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5">
              {/* Requirement 1: Relabeled "Viewing LC" */}
              <span className="text-xs font-bold text-slate-500 font-mono">Viewing LC:</span>
              <select
                value={selectedLc.id}
                onChange={(e) => {
                  const found = lcs.find(l => l.id === e.target.value);
                  if (found) onSelectLc(found);
                }}
                className="bg-transparent text-xs font-bold font-mono text-blue-700 focus:outline-none cursor-pointer"
              >
                {lcs.map((l, idx) => (
                  <option key={`top-lc-${l.id}-${idx}`} value={l.id}>
                    {l.lcNumber} - ${l.cfrAmount.toLocaleString()} ({l.status})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={() => {
                resetForm();
                setShowAddExpenseModal(true);
              }}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add LC Expense Head
            </button>

            <button
              type="button"
              onClick={onNavigateToBills}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5 text-slate-500" />
              View Exporter Bills
            </button>
          </div>
        </div>

        {/* Selected LC Profile Pill */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 bg-slate-50 border border-slate-200/80 rounded-xl p-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold font-mono text-sm shrink-0">
              <Ship className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-slate-900 text-sm">{selectedLc.lcNumber}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                  {selectedLc.lcType}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {selectedLc.status}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                <strong>Supplier:</strong> {selectedLc.supplierName} • <strong>Commodity:</strong> {commodityDescription} ({totalQty} MT)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Bank Margin</span>
              <span className="font-bold text-slate-700">
                {(selectedLc.marginPercent !== undefined ? selectedLc.marginPercent : selectedLc.marginDepositPercent) || 0}% (BDT {(((selectedLc.marginAmountBDT !== undefined ? selectedLc.marginAmountBDT : selectedLc.marginAmountLocal) || 0) / 100000).toFixed(1)}L)
              </span>
              {selectedLc.marginVoucherNo ? (
                <span className="text-[10px] text-blue-600 font-bold block">{selectedLc.marginVoucherNo}</span>
              ) : onPostMargin ? (
                <button
                  type="button"
                  onClick={() => onPostMargin(selectedLc)}
                  className="mt-0.5 px-2 py-0.5 bg-amber-600 hover:bg-amber-700 text-white rounded text-[9px] font-bold block transition-colors cursor-pointer"
                >
                  Post Margin Now
                </button>
              ) : null}
            </div>
            <div className="border-l border-slate-200 pl-4">
              <span className="text-slate-400 block text-[10px] uppercase">Bill of Entry (BOE)</span>
              <span className="font-bold text-blue-700">{selectedLc.boeNumber || 'BOE-PENDING'}</span>
            </div>
            <div className="border-l border-slate-200 pl-4">
              <span className="text-slate-400 block text-[10px] uppercase">Exchange Rate</span>
              <span className="font-bold text-slate-900 font-mono">1 USD = {lcBill.exchangeRate} BDT</span>
            </div>
          </div>
        </div>

        {/* 4 Core Financial KPI Blocks */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
              1. Base CFR Invoice Value
            </span>
            <div className="mt-1 flex items-baseline gap-1.5 font-mono">
              <span className="text-lg font-black text-slate-900">
                ${lcBill.officialBillForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className="text-xs text-slate-500">USD</span>
            </div>
            <span className="text-[11px] font-mono text-slate-500 mt-0.5 block">
              BDT {(baseFobBdt / 1000000).toFixed(2)}M (@ {lcBill.exchangeRate})
            </span>
          </div>

          <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-3.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 block">
              {hasActualBoe ? '2. Customs Duties' : '2. Estimated Customs Duties (BOE pending)'}
            </span>
            <div className="mt-1 flex items-baseline gap-1.5 font-mono">
              <span className="text-lg font-black text-amber-900">
                BDT {totalClearanceLogistics.toLocaleString()}
              </span>
            </div>
            <span className="text-[11px] font-mono text-amber-700 mt-0.5 block">
              Duties (৳{tariffResult.totalDutiesBdt.toLocaleString()}) + Logistics (৳{realActualExpenses.toLocaleString()})
            </span>
          </div>

          <div className="bg-blue-50/60 border border-blue-200 rounded-xl p-3.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-800 block">
                {hasActualBoe ? '3. Landed Cost' : '3. Estimated Landed Cost'}
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                Actual
              </span>
            </div>
            <div className="mt-1 flex items-baseline gap-1.5 font-mono">
              <span className="text-lg font-black text-blue-900">
                BDT {totalLandedCostBDT.toLocaleString()}
              </span>
              <span className="text-xs text-blue-700 font-bold">(Actual)</span>
            </div>
            {estimatedTotal > 0 && (
              <div className="mt-1 flex items-center justify-between text-[11px] font-mono text-amber-900 bg-amber-100/70 px-2 py-0.5 rounded border border-amber-200">
                <span>Actual + Estimated:</span>
                <span className="font-bold">BDT {(totalLandedCostBDT + estimatedTotal).toLocaleString()}</span>
              </div>
            )}
            <span className="text-[10px] font-mono text-blue-700 mt-0.5 block">
              CFR + Cap. Duties + Actual Logistics
            </span>
          </div>

          <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-3.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 block">
              {hasActualBoe ? '4. Landed Unit Cost / MT' : '4. Estimated Landed Unit Cost / MT'}
            </span>
            <div className="mt-1 flex items-baseline gap-1.5 font-mono">
              <span className="text-lg font-black text-emerald-900">
                BDT {unitLandedCostBDT.toLocaleString()}
              </span>
              <span className="text-xs text-emerald-700 font-bold">/ MT (Actual)</span>
            </div>
            {estimatedTotal > 0 && totalQty > 0 && (
              <div className="mt-1 flex items-center justify-between text-[11px] font-mono text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                <span>Actual + Est / MT:</span>
                <span className="font-bold">BDT {Math.round((totalLandedCostBDT + estimatedTotal) / totalQty).toLocaleString()}/MT</span>
              </div>
            )}
            <span className="text-[10px] font-mono text-emerald-700 mt-0.5 block">
              Qty: {totalQty} MT (CFR: ৳{Math.round(cfrCostPerMt).toLocaleString()}/MT)
            </span>
          </div>
        </div>

        {/* Warning if Landed Cost per MT > 2x CFR Cost per MT */}
        {isLandedCostSpike && (
          <div className="mt-3 p-3 bg-amber-50 border border-amber-300 rounded-xl flex items-center justify-between text-amber-900 text-xs">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span className="font-bold">
                Warning: Landed unit cost (BDT {unitLandedCostBDT.toLocaleString()}/MT) is {((unitLandedCostBDT / cfrCostPerMt) * 100).toFixed(0)}% of CFR cost (BDT {Math.round(cfrCostPerMt).toLocaleString()}/MT), exceeding the 2x threshold.
              </span>
            </div>
            <span className="px-2 py-0.5 rounded bg-amber-200 text-amber-900 font-mono text-[10px] font-bold">
              Threshold: 200%
            </span>
          </div>
        )}
      </div>

      {/* Main Grid: Comprehensive Expense Ledger & NBR Customs Duty Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Full Expense Ledger */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Apportioned Expense Ledger</h3>
              </div>
              <span className="text-xs font-mono font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-lg">
                {selectedLc.expenses.length} Vouchers
              </span>
            </div>

            <div className="overflow-x-auto mt-3">
              <table className="w-full text-left text-xs border border-slate-200 rounded-xl overflow-hidden">
                <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Expense Head</th>
                    <th className="py-2.5 px-3">Paid To / Vendor</th>
                    {/* Requirement 5: Added Paid From and Voucher No columns */}
                    <th className="py-2.5 px-3">Paid From</th>
                    <th className="py-2.5 px-3">Voucher #</th>
                    <th className="py-2.5 px-3 text-right">Amount (BDT)</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700">
                  {selectedLc.expenses.length === 0 ? (
                    <tr key="empty-expense-row">
                      <td colSpan={7} className="py-6 text-center text-slate-400">
                        No expense heads recorded for this LC yet. Click "Add LC Expense Head" to capitalize customs and clearance bills.
                      </td>
                    </tr>
                  ) : (
                    selectedLc.expenses.map((exp, idx) => {
                      const effStatus = getExpenseEffectiveStatus(exp);
                      const isVoided = effStatus === 'Voided';
                      const rowKey = exp.id ? `exp-row-${exp.id}-${idx}` : `exp-row-${selectedLc.id}-${idx}-${exp.expenseType}`;

                      return (
                        <tr 
                          key={rowKey} 
                          className={`transition-colors ${isVoided ? 'bg-slate-50/70 text-slate-400 opacity-70' : 'hover:bg-slate-50/60'}`}
                        >
                          <td className="py-2.5 px-3 font-semibold text-slate-900 flex items-center gap-1.5">
                            <Layers className={`w-3.5 h-3.5 shrink-0 ${isVoided ? 'text-slate-400' : 'text-blue-500'}`} />
                            <span className={isVoided ? 'line-through' : ''}>{exp.expenseType}</span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-600">{exp.paidTo}</td>
                          
                          {/* Paid From column */}
                          <td className="py-2.5 px-3 text-slate-600 max-w-[150px] truncate" title={exp.paidFromAccountName || '-'}>
                            {exp.paidFromAccountName || (exp.status === 'Paid' ? 'Paid (Cash/Bank)' : '-')}
                          </td>

                          {/* Voucher No column - clickable to view voucher (Requirement 5) */}
                          <td className="py-2.5 px-3 font-mono text-[11px]">
                            {exp.voucherNo ? (
                              <button
                                type="button"
                                onClick={() => handleViewVoucher(exp.voucherNo, exp.transactionId, exp)}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded font-mono text-[11px] font-bold bg-blue-50 text-blue-700 hover:bg-blue-100 hover:underline transition-colors border border-blue-200 cursor-pointer"
                                title="Click to view voucher details"
                              >
                                <FileText className="w-3 h-3 text-blue-500" />
                                <span>{exp.voucherNo}</span>
                              </button>
                            ) : (
                              <span className="text-slate-400">-</span>
                            )}
                          </td>

                          {/* Amount column */}
                          <td className={`py-2.5 px-3 text-right font-mono font-bold ${isVoided ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                            ৳{exp.amountLocal.toLocaleString()}
                          </td>

                          {/* Status column */}
                          <td className="py-2.5 px-3 text-center">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              isVoided ? 'bg-slate-200 text-slate-700 font-mono' :
                              effStatus === 'Paid' ? 'bg-emerald-100 text-emerald-800' :
                              effStatus === 'Billed' ? 'bg-blue-100 text-blue-800' :
                              'bg-amber-100 text-amber-800'
                            }`}>
                              {effStatus}
                            </span>
                          </td>

                          {/* Action column: Convert or Pay actions */}
                          <td className="py-2.5 px-3 text-center">
                            {!isVoided && effStatus === 'Estimated' && (
                              <div className="flex items-center justify-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleConvertToBilled(exp)}
                                  className="px-2 py-0.5 bg-blue-600 hover:bg-blue-700 text-white rounded text-[10px] font-bold shadow-2xs transition-colors inline-flex items-center gap-1 cursor-pointer"
                                  title="Convert Estimated record to Billed (Posts Dr Inventory / Cr Vendor Payable)"
                                >
                                  <Receipt className="w-3 h-3" />
                                  <span>Bill</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handlePayNow(exp)}
                                  className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold shadow-2xs transition-colors inline-flex items-center gap-1 cursor-pointer"
                                  title="Convert Estimated record to Paid (Posts payment voucher & deducts Cash/Bank)"
                                >
                                  <CreditCard className="w-3 h-3" />
                                  <span>Pay</span>
                                </button>
                              </div>
                            )}
                            {!isVoided && effStatus === 'Billed' && (
                              <button
                                type="button"
                                onClick={() => handlePayNow(exp)}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold shadow-2xs transition-colors inline-flex items-center gap-1 cursor-pointer"
                                title="Pay this billed vendor invoice now via Cash/Bank payment voucher"
                              >
                                <CreditCard className="w-3 h-3" />
                                <span>Pay Now</span>
                              </button>
                            )}
                            {(isVoided || effStatus === 'Paid') && (
                              <span className="text-slate-300 font-mono text-[11px]">-</span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-50 font-bold border-t-2 border-slate-300">
                    <td colSpan={4} className="py-2.5 px-3 text-slate-900">
                      Total Actual Logistics Expenses (Billed & Paid)
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-900 font-bold">
                      ৳{activeExpenses.reduce((sum, e) => sum + e.amountLocal, 0).toLocaleString()}
                    </td>
                    <td colSpan={2}></td>
                  </tr>
                  <tr className="bg-amber-50/60 font-semibold border-t border-amber-200 text-amber-900 text-[11px]">
                    <td colSpan={4} className="py-2 px-3 text-amber-800">
                      Estimated, not in cost
                    </td>
                    <td className="py-2 px-3 text-right font-mono text-amber-800 font-bold">
                      ৳{estimatedTotal.toLocaleString()}
                    </td>
                    <td colSpan={2} className="py-2 px-3 text-center text-[10px] text-amber-700 font-sans">
                      Provisional (Pending bill/payment)
                    </td>
                  </tr>
                  {estimatedTotal > 0 && (
                    <tr className="bg-slate-100 font-bold border-t border-slate-300 text-slate-800 text-xs">
                      <td colSpan={4} className="py-2 px-3">
                        Total (Actual + Estimated)
                      </td>
                      <td className="py-2 px-3 text-right font-mono text-slate-900 font-bold">
                        ৳{(activeExpenses.reduce((sum, e) => sum + e.amountLocal, 0) + estimatedTotal).toLocaleString()}
                      </td>
                      <td colSpan={2}></td>
                    </tr>
                  )}
                </tfoot>
              </table>
            </div>

            {/* Accounting GL Journal Preview (IAS 2 Valuation - Preview Only, Not Posted) */}
            <div className="mt-4 p-3.5 bg-slate-900 text-slate-200 rounded-xl font-mono text-xs space-y-2">
              <div className="flex items-center justify-between text-slate-400 text-[11px] border-b border-slate-800 pb-1.5">
                <div className="flex items-center gap-2">
                  <span>{hasActualBoe ? 'GL Journal (BOE Assessed)' : 'GL Journal Preview'}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    hasActualBoe ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}>
                    {hasActualBoe ? 'Actual (BOE Assessed)' : 'Preview only, not posted'}
                  </span>
                </div>
                {glLines.isBalanced ? (
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Balanced
                  </span>
                ) : (
                  <span className="text-rose-400 font-bold">
                    Out of Balance (Diff: BDT {Math.abs(glLines.totalDebits - glLines.totalCredits).toLocaleString()})
                  </span>
                )}
              </div>

              {/* Debit Lines */}
              <div className="space-y-1">
                {glLines.lines.filter(l => l.type === 'DR').map((line, idx) => (
                  <div key={`gl-dr-${line.accountCode}-${idx}`} className="flex justify-between text-slate-100">
                    <span className="truncate pr-2">
                      <strong className="text-emerald-400 font-bold">Dr. {line.accountCode}</strong> {line.accountName}
                    </span>
                    <span className="font-bold text-emerald-300 shrink-0">BDT {line.amount.toLocaleString()}</span>
                  </div>
                ))}
              </div>

              {/* Credit Lines */}
              <div className="space-y-1 pt-1.5 border-t border-slate-800/80">
                {glLines.lines.filter(l => l.type === 'CR').map((line, idx) => (
                  <div key={`gl-cr-${line.accountCode}-${idx}`} className="flex justify-between text-slate-300 pl-4">
                    <span className="truncate pr-2">
                      <strong className="text-blue-400 font-bold">Cr. {line.accountCode}</strong> {line.accountName}
                    </span>
                    <span className="font-bold text-slate-200 shrink-0">BDT {line.amount.toLocaleString()}</span>
                  </div>
                ))}
              </div>

              <div className="pt-1.5 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                <span>Total Debit: <strong className="text-emerald-400 font-mono">BDT {glLines.totalDebits.toLocaleString()}</strong></span>
                <span>Total Credit: <strong className="text-blue-400 font-mono">BDT {glLines.totalCredits.toLocaleString()}</strong></span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): NBR Customs Tariff Assessment Engine */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900">NBR Customs Tariff Structure</h3>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    hasActualBoe ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-amber-100 text-amber-800 border border-amber-200'
                  }`}>
                    {hasActualBoe ? 'Actual (BOE Assessed)' : 'Estimate Preview (BOE pending)'}
                  </span>
                </div>
              </div>
              <span className="text-xs font-mono font-bold bg-amber-50 text-amber-800 px-2 py-0.5 rounded border border-amber-200">
                HS: {selectedHsCode}
              </span>
            </div>

            <div className="mt-3 space-y-2 text-xs">
              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200/70">
                <div>
                  <span className="text-slate-600 block">Assessable Value (AV = CFR + {tariffResult.landingPercent}% Landing)</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    CFR: ৳{baseFobBdt.toLocaleString()} + Landing: ৳{tariffResult.landingAmountBdt.toLocaleString()}
                  </span>
                </div>
                <span className="font-mono font-bold text-slate-900 text-sm">৳{tariffResult.assessableValueBdt.toLocaleString()}</span>
              </div>

              {/* Duty Heads with Real Calculations and Capitalize Flags */}
              <div className="space-y-1.5 pt-1">
                {tariffResult.lines.map((duty) => (
                  <div key={`duty-row-${duty.code}`} className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200">
                    <div className="flex-1 pr-2">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-slate-800">{duty.name} @ {duty.ratePercent}%</span>
                        {duty.capitalizeToInventory ? (
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 border border-emerald-200" title="Capitalized to Raw Material Inventory">
                            Capitalized
                          </span>
                        ) : (
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 border border-slate-200" title="Tax Credit / Asset (Not in Inventory Cost)">
                            Tax Asset
                          </span>
                        )}
                        {isAdmin && (
                          <button
                            type="button"
                            onClick={() => updateDutyHeadCapitalize(selectedHsCode, duty.code, !duty.capitalizeToInventory)}
                            className="text-[9px] text-blue-600 hover:underline ml-1 cursor-pointer font-sans"
                            title="Toggle Capitalization Flag (Admin Only)"
                          >
                            [Edit]
                          </button>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono block">
                        Base: ৳{duty.baseAmountBdt.toLocaleString()}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-slate-900 shrink-0">
                      ৳{duty.dutyAmountBdt.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between p-3 bg-amber-50/80 border border-amber-200 rounded-xl mt-3 font-bold">
                <span className="text-amber-900">Total Statutory Assessment:</span>
                <span className="font-mono text-sm text-amber-900">
                  ৳{tariffResult.totalDutiesBdt.toLocaleString()}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 text-[11px] font-mono">
                <div className="bg-emerald-50/80 p-2 rounded-lg border border-emerald-200">
                  <span className="text-emerald-800 text-[10px] block font-sans font-bold">Capitalized Duties (CD+RD+SD):</span>
                  <span className="font-bold text-emerald-950">৳{tariffResult.capitalizableDutiesBdt.toLocaleString()}</span>
                </div>
                <div className="bg-blue-50/80 p-2 rounded-lg border border-blue-200">
                  <span className="text-blue-800 text-[10px] block font-sans font-bold">Recoverable Taxes (VAT+AIT+AT):</span>
                  <span className="font-bold text-blue-950">৳{tariffResult.recoverableTaxesBdt.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add LC Expense Head / Pay Now Modal */}
      {showAddExpenseModal && (
        <LCModal
          isOpen={showAddExpenseModal}
          onClose={handleCloseExpenseModal}
          title={payNowTargetId ? 'Pay LC Expense Head' : 'Add LC Expense Head'}
          size="md"
          isDirty={isExpenseFormDirty}
          isSaving={isSaving}
          primaryAction={
            <LCButton
              type="submit"
              form="lc-expense-modal-form"
              variant="primary"
              size="md"
              isLoading={isSaving}
              loadingText={
                expenseStatus === 'Paid'
                  ? 'Posting Payment...'
                  : expenseStatus === 'Billed'
                  ? 'Posting Bill...'
                  : 'Saving Estimate...'
              }
              disabled={
                isSaving ||
                !expenseAmount ||
                numericAmount <= 0 ||
                !expenseHead ||
                (expenseStatus === 'Paid' && (
                  !paidFromAccountId ||
                  isCashDeficit ||
                  (isBankOverdraft && (!isAdmin || !adminApprovedOverdraft))
                ))
              }
              icon={<CheckCircle2 className="w-4 h-4" />}
            >
              {expenseStatus === 'Paid'
                ? 'Post Payment'
                : expenseStatus === 'Billed'
                ? 'Post Bill'
                : 'Save Estimate'}
            </LCButton>
          }
        >
          {/* Error Banner */}
          {formError && (
            <div className="p-3 bg-[#FEF2F2] dark:bg-rose-950/40 border border-[#DC2626]/20 rounded-[8px] text-[#DC2626] dark:text-rose-300 text-[12px] flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-[#DC2626] shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{formError}</div>
            </div>
          )}

          <form 
            id="lc-expense-modal-form"
            autoComplete="off"
            onSubmit={handleExpenseSubmit} 
            onKeyDown={(e) => { if (e.key === 'Enter' && (isSaving || isSubmittingExpenseRef.current)) e.preventDefault(); }}
            className="space-y-4 text-[14px]"
          >
            {/* LC Number dropdown */}
            <LCFormField label="LC Number" required locked={!!payNowTargetId}>
              <LCSelect
                value={formLcId}
                onChange={(e) => setFormLcId(e.target.value)}
                disabled={!!payNowTargetId}
                locked={!!payNowTargetId}
                required
              >
                <option value="">Select LC Number...</option>
                {lcs.map((l, idx) => (
                  <option key={`modal-lc-${l.id}-${idx}`} value={l.id}>
                    {l.lcNumber} - {l.supplierName || 'Unknown Supplier'} - ${l.cfrAmount.toLocaleString()} ({l.status})
                  </option>
                ))}
              </LCSelect>
            </LCFormField>

            {/* Expense Head / Category */}
            <LCFormField label="Expense Head / Category" required locked={!!payNowTargetId}>
              <LCSelect
                value={expenseHead}
                onChange={(e) => setExpenseHead(e.target.value)}
                disabled={!!payNowTargetId}
                locked={!!payNowTargetId}
                required
              >
                <option value="">Select Expense Head...</option>
                {payNowTargetId && expenseHead && !coaExpenseHeads.some(h => h.name === expenseHead) && (
                  <option value={expenseHead}>{expenseHead}</option>
                )}
                {coaExpenseHeads.map((head) => (
                  <option key={head.code} value={head.name}>
                    {head.name} ({head.code})
                  </option>
                ))}
              </LCSelect>
            </LCFormField>

            {/* Expense Amount (BDT) */}
            <LCFormField label="Expense Amount (BDT)" required locked={!!payNowTargetId}>
              <LCInput
                type="number"
                value={expenseAmount}
                onChange={(e) => setExpenseAmount(e.target.value)}
                disabled={!!payNowTargetId}
                locked={!!payNowTargetId}
                required
                min={1}
                isNumber
                suffixText="BDT"
                placeholder="e.g. 50000"
              />
            </LCFormField>

            {/* Payment Status Dropdown: Estimated, Billed, Paid */}
            <LCFormField
              label="Payment Status"
              required
              locked={!!payNowTargetId}
              helperText={
                expenseStatus === 'Estimated'
                  ? 'Provisional estimate: Not posted to GL, no inventory impact, not added to landed cost. Can be converted to Billed or Paid later.'
                  : expenseStatus === 'Billed'
                  ? `Vendor Bill: Posts Dr Inventory (13100) / Cr Accounts Payable (${expensePaidTo || 'Vendor'}). Capitalized to landed cost upon posting.`
                  : undefined
              }
            >
              <LCSelect
                value={expenseStatus}
                onChange={(e) => setExpenseStatus(e.target.value as any)}
                required
              >
                <option value="">Select Payment Status...</option>
                <option value="Estimated">Estimated (Provisional record only, no GL / inventory effect)</option>
                <option value="Billed">Billed (Dr Inventory / Cr Accounts Payable for vendor)</option>
                <option value="Paid">Paid (Require Paid From cash/bank & post payment voucher)</option>
              </LCSelect>
            </LCFormField>

            {/* Payment Details Section (When Payment Status = Paid) */}
            {expenseStatus === 'Paid' && (
              <LCSection
                title="Real-time Payment Voucher Details (Cash / Bank Posting)"
                divider
                columns={1}
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <LCFormField label="Payment Date" required>
                    <LCInput
                      type="date"
                      value={paymentDate}
                      onChange={(e) => setPaymentDate(e.target.value)}
                      required
                    />
                  </LCFormField>

                  <LCFormField
                    label="Payment Method"
                    required
                    subLabel={isCashAccount ? <span className="text-[11px] text-slate-400">(Locked for Cash)</span> : null}
                  >
                    <LCSelect
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                      disabled={isCashAccount}
                      locked={isCashAccount}
                      required
                    >
                      <option value="">Select Payment Method...</option>
                      <option value="Cash">Cash</option>
                      <option value="Bank Transfer">Bank Transfer</option>
                      <option value="Cheque">Cheque</option>
                    </LCSelect>
                  </LCFormField>
                </div>

                {/* Paid From Account Searchable Dropdown */}
                <LCFormField
                  label="Paid From Account"
                  required
                  subLabel={
                    !isAdmin && userBranch && userBranch !== 'All Branches' ? (
                      <span className="text-[11px] text-slate-400">(Branch: {userBranch})</span>
                    ) : null
                  }
                >
                  <div className="relative" ref={accountDropdownRef}>
                    <div
                      onClick={() => setIsAccountDropdownOpen(prev => !prev)}
                      className="w-full h-10 px-3 border border-[#E5E7EB] dark:border-slate-700 rounded-[8px] bg-white dark:bg-slate-800 cursor-pointer flex items-center justify-between text-[13px] hover:border-[#2563EB] transition-colors"
                    >
                      {selectedBankAccount ? (
                        <div className="flex items-center justify-between w-full pr-2">
                          <div className="truncate mr-2">
                            <span className="font-medium text-slate-900 dark:text-slate-100">{selectedBankAccount.bankName}</span>
                            <span className="text-slate-400 font-mono ml-1.5">({selectedBankAccount.accountNumber})</span>
                            <span className="ml-2 text-[11px] px-1.5 py-0.5 rounded-[4px] font-medium bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                              {selectedBankAccount.branch || 'Head Office'}
                            </span>
                          </div>
                          <span className={`font-mono tabular-nums font-semibold shrink-0 ${(selectedBankAccount.ledgerBalance || 0) < 0 ? 'text-[#DC2626]' : 'text-[#059669]'}`}>
                            ৳ {(selectedBankAccount.ledgerBalance || 0).toLocaleString()}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400">Search and select Cash or Bank Account...</span>
                      )}
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    </div>

                    {isAccountDropdownOpen && (
                      <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-[8px] shadow-lg z-50 p-2 max-h-60 overflow-hidden flex flex-col">
                        <div className="relative mb-2 shrink-0">
                          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                          <input
                            type="text"
                            value={accountSearchTerm}
                            onChange={(e) => setAccountSearchTerm(e.target.value)}
                            placeholder="Search by bank name, account number, or branch..."
                            className="w-full pl-8 pr-3 py-1.5 border border-[#E5E7EB] dark:border-slate-700 rounded-[6px] text-[13px] bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-[#2563EB]"
                            autoFocus
                          />
                        </div>

                        <div className="overflow-y-auto space-y-1 max-h-48 pr-1">
                          {filteredAccounts.length === 0 ? (
                            <div className="text-center py-3 text-slate-400 text-[13px]">
                              No accessible cash/bank accounts found
                            </div>
                          ) : (
                            filteredAccounts.map((acc, accIdx) => {
                              const isAccCash = checkIsCashAccount(acc);
                              return (
                                <div
                                  key={`paid-acc-${acc.id}-${accIdx}`}
                                  onClick={() => {
                                    setPaidFromAccountId(acc.id);
                                    if (isAccCash) {
                                      setPaymentMethod('Cash');
                                    }
                                    setIsAccountDropdownOpen(false);
                                  }}
                                  className={`p-2 rounded-[6px] cursor-pointer flex items-center justify-between text-[13px] transition-colors ${
                                    paidFromAccountId === acc.id
                                      ? 'bg-[#EFF6FF] dark:bg-blue-900/30 text-[#1E40AF] dark:text-blue-300 font-medium'
                                      : 'hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-700 dark:text-slate-200'
                                  }`}
                                >
                                  <div>
                                    <div className="font-medium flex items-center gap-1.5">
                                      <span>{acc.bankName}</span>
                                      <span className="text-[11px] font-normal text-slate-400 font-mono">({acc.accountNumber})</span>
                                      {isAccCash && (
                                        <span className="text-[10px] bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300 px-1 py-0.2 rounded font-medium">CASH</span>
                                      )}
                                    </div>
                                    <div className="text-[11px] text-slate-400">
                                      {acc.branch || 'Head Office'} • {acc.accountType}
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <div className={`font-mono tabular-nums font-semibold ${(acc.ledgerBalance || 0) < 0 ? 'text-[#DC2626]' : 'text-[#059669]'}`}>
                                      ৳ {(acc.ledgerBalance || 0).toLocaleString()}
                                    </div>
                                  </div>
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </LCFormField>

                {/* Reference & Narration */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <LCFormField label="Reference / Cheque No" helperText="(Optional)">
                    <LCInput
                      type="text"
                      value={referenceNo}
                      onChange={(e) => setReferenceNo(e.target.value)}
                      placeholder="e.g. CQ-2026-99 or BEFTN-01"
                    />
                  </LCFormField>

                  <LCFormField label="Narration" helperText="(Optional)">
                    <LCInput
                      type="text"
                      value={narration}
                      onChange={(e) => setNarration(e.target.value)}
                      placeholder={`LC ${lcs.find(l => l.id === formLcId)?.lcNumber || selectedLc.lcNumber} - ${expenseHead || 'Demurrage'} - ${expensePaidTo || 'Vendor'}`}
                    />
                  </LCFormField>
                </div>

                {/* Cash Deficit Warning */}
                {isCashDeficit && (
                  <div className="p-3 bg-[#FEF2F2] dark:bg-rose-950/30 border border-[#DC2626]/20 rounded-[8px] text-[#DC2626] dark:text-rose-300 text-[12px] flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 shrink-0" />
                    <div>
                      <strong>Insufficient Cash Balance: </strong>
                      The selected cash account has ৳{currentAccountBalance.toLocaleString()}, but the payment is ৳{numericAmount.toLocaleString()}. Cash balance cannot become negative.
                    </div>
                  </div>
                )}

                {/* Bank Overdraft: Non-Admin Blocked */}
                {isBankOverdraft && !isAdmin && (
                  <div className="p-3 bg-[#FEF2F2] dark:bg-rose-950/30 border border-[#DC2626]/20 rounded-[8px] text-[#DC2626] dark:text-rose-300 text-[12px] flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 shrink-0" />
                    <div>
                      <strong>Bank Overdraft Restricted: </strong>
                      The bank account balance (৳{currentAccountBalance.toLocaleString()}) is lower than the required amount. Only an Admin can authorize an overdraft payment.
                    </div>
                  </div>
                )}

                {/* Bank Overdraft: Admin Approval Banner */}
                {isBankOverdraft && isAdmin && (
                  <div className="p-3 bg-[#FFFBEB] dark:bg-amber-950/30 border border-[#D97706]/20 rounded-[8px] text-[#92400E] dark:text-amber-300 space-y-2 text-[12px]">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-[#D97706] shrink-0 mt-0.5" />
                      <div>
                        <strong className="block font-semibold">Bank Account Overdraft Warning</strong>
                        Account balance is ৳{currentAccountBalance.toLocaleString()}, but payment is ৳{numericAmount.toLocaleString()}. The projected balance will be ৳{(currentAccountBalance - numericAmount).toLocaleString()}.
                      </div>
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer font-medium pt-1.5 border-t border-[#D97706]/20">
                      <input
                        type="checkbox"
                        checked={adminApprovedOverdraft}
                        onChange={(e) => setAdminApprovedOverdraft(e.target.checked)}
                        className="w-4 h-4 rounded-[4px] text-[#2563EB] focus:ring-[#2563EB] border-slate-300"
                      />
                      <span>Admin Confirmation: I authorize this bank overdraft payment</span>
                    </label>
                  </div>
                )}
              </LCSection>
            )}
          </form>
        </LCModal>
      )}


      {/* Voucher Print View Modal (Requirement 5) */}
      <VoucherPrintModal
        isOpen={!!selectedTxnForView}
        onClose={() => setSelectedTxnForView(null)}
        transaction={selectedTxnForView}
      />
    </div>
  );
};
