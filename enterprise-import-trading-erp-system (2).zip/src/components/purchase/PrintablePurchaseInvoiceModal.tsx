import React, { useState } from 'react';
import { 
  Printer, 
  Share2, 
  X, 
  Building2, 
  CreditCard,
  Receipt,
  Warehouse,
  Ship,
  FileText
} from 'lucide-react';
import { DirectPurchaseInvoice, Supplier } from '../../types/erp';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface PrintablePurchaseInvoiceModalProps {
  invoice: DirectPurchaseInvoice;
  supplier?: Supplier;
  onClose: () => void;
  onPaymentCollect?: (invoice: DirectPurchaseInvoice) => void;
}

// Convert numbers to words (BDT)
function numberToBDTWords(num: number): string {
  if (!num || num === 0) return 'Zero Taka Only';
  const units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertBelowThousand(n: number): string {
    let str = '';
    if (n >= 100) {
      str += units[Math.floor(n / 100)] + ' Hundred ';
      n %= 100;
    }
    if (n >= 20) {
      str += tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + units[n % 10] : '');
    } else if (n > 0) {
      str += units[n];
    }
    return str.trim();
  }

  let crore = Math.floor(num / 10000000);
  let remainder = num % 10000000;
  let lakh = Math.floor(remainder / 100000);
  remainder %= 100000;
  let thousand = Math.floor(remainder / 1000);
  let rest = remainder % 1000;

  let words = '';
  if (crore > 0) words += convertBelowThousand(crore) + ' Crore ';
  if (lakh > 0) words += convertBelowThousand(lakh) + ' Lakh ';
  if (thousand > 0) words += convertBelowThousand(thousand) + ' Thousand ';
  if (rest > 0) words += convertBelowThousand(rest);

  return (words.trim() + ' Taka Only');
}

export const PrintablePurchaseInvoiceModal: React.FC<PrintablePurchaseInvoiceModalProps> = ({
  invoice,
  supplier,
  onClose,
  onPaymentCollect
}) => {
  const [copied, setCopied] = useState(false);
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  React.useEffect(() => {
    return subscribeCompanyProfile(setCompanyProfile);
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const handleCopySummary = () => {
    const text = `*COMMERCIAL PURCHASE INVOICE: ${invoice.invoiceNumber}*\nSupplier: ${supplier?.name || invoice.supplierName}\nChallan: ${invoice.challanNumber}\nDate: ${invoice.invoiceDate}\nTotal Amount: ${invoice.currency} ${invoice.grandTotal.toLocaleString()}\nPaid: ${invoice.currency} ${invoice.paidAmount.toLocaleString()}\nDue Balance: ${invoice.currency} ${invoice.dueAmount.toLocaleString()}\nPayment Status: ${invoice.paymentStatus}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const isFullyPaid = invoice.dueAmount === 0 || invoice.paymentStatus === 'Paid';
  const isPartial = invoice.paymentStatus === 'Partial' || (invoice.dueAmount > 0 && invoice.paidAmount > 0);

  // Subtotal calculation
  const subtotal = invoice.subTotal || invoice.items.reduce((sum, itm) => sum + (itm.totalPrice || itm.quantity * itm.unitPrice), 0);

  return (
    <ModalWrapper
      isOpen={true}
      onClose={onClose}
      isDirty={false}
      backdropClassName="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex flex-col items-center justify-start p-2 sm:p-4 overflow-y-auto animate-in fade-in"
    >
      {/* Top Action Bar (No-Print) */}
      <div className="w-full max-w-4xl bg-white border border-slate-200 rounded-t-2xl p-3.5 flex items-center justify-between shadow-xl no-print mb-2 sticky top-2 z-20">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-900 text-white flex items-center justify-center font-bold text-xs">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-2">
                Purchase Invoice #{invoice.invoiceNumber}
              </h3>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                isFullyPaid ? 'bg-emerald-50 text-emerald-700 border-emerald-300' :
                isPartial ? 'bg-amber-50 text-amber-700 border-amber-300' :
                'bg-rose-50 text-rose-700 border-rose-300'
              }`}>
                {isFullyPaid ? '✓ Paid' : isPartial ? '⏳ Partial' : '⚠️ Unpaid / Due'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {invoice.dueAmount > 0 && onPaymentCollect && (
            <button
              type="button"
              onClick={() => onPaymentCollect(invoice)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              title="Pay outstanding due to supplier"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Pay Due</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleCopySummary}
            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-200 cursor-pointer"
            title="Copy invoice summary"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{copied ? 'Copied!' : 'Share / Copy'}</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-extrabold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            title="Print or Save as PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Invoice</span>
          </button>

          <button
            type="button"
            data-modal-close="true"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors ml-1 cursor-pointer shrink-0"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Invoice Sheet Canvas (Clean Minimal Print Ready - matching Sales Invoice Design) */}
      <div 
        id="printable-invoice"
        className="w-full max-w-4xl bg-white border border-slate-200 rounded-2xl shadow-xl p-6 sm:p-10 mb-12 select-text text-slate-900 space-y-6"
      >
        {/* Header: Company Info + Invoice Details */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 border-b-2 border-slate-900">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-indigo-900 text-white flex items-center justify-center font-black text-lg">
                {(companyProfile.companyName || 'J').replace(/^M\/S\s+/i, '').charAt(0).toUpperCase() || 'J'}
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
                  {companyProfile.companyName}
                </h2>
                <p className="text-[11px] text-slate-500 font-mono">
                  {companyProfile.address}
                </p>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 space-y-0.5">
              <div>Mobile: {companyProfile.mobile}</div>
            </div>
          </div>

          <div className="sm:text-right">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 uppercase tracking-tight">
              PURCHASE INVOICE
            </h1>
            <div className="mt-1 font-mono space-y-0.5 text-xs">
              <div className="font-bold text-sm text-indigo-700">{invoice.invoiceNumber}</div>
              <div className="text-slate-500">Challan: <strong className="text-slate-800">{invoice.challanNumber}</strong></div>
              <div className="text-slate-500">Date: {invoice.invoiceDate}</div>
              <div className="text-slate-500">Due: <strong className="text-rose-600">{invoice.dueDate}</strong></div>
              <div className="pt-1">
                <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${
                  isFullyPaid ? 'bg-emerald-50 text-emerald-700 border-emerald-300' :
                  isPartial ? 'bg-amber-50 text-amber-700 border-amber-300' :
                  'bg-rose-50 text-rose-700 border-rose-300'
                }`}>
                  {(invoice.paymentStatus || (invoice.dueAmount === 0 ? 'PAID' : 'DUE')).toUpperCase()}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bill From (Supplier / Vendor) & Order Terms Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pb-6 border-b border-slate-200 text-xs">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-1">
            <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block">
              VENDOR / SUPPLIER DETAILS
            </span>
            <div className="font-bold text-sm text-slate-900">
              {supplier?.name || invoice.supplierName}
            </div>
            {supplier?.category && (
              <div className="text-indigo-700 font-medium text-[11px]">{supplier.category}</div>
            )}
            <div className="text-slate-500">
              {supplier?.city || 'Burimari / Chittagong'}, {supplier?.country || 'Bangladesh'}
            </div>
            <div className="text-slate-500 font-mono text-[11px]">
              Phone: {supplier?.phone || '+880 1711-XXXXXX'} | Code: {supplier?.code || invoice.supplierId}
            </div>
            {invoice.supplierBillNumber && (
              <div className="text-slate-600 font-mono text-[11px] pt-0.5">
                Supplier Bill Ref: <strong>{invoice.supplierBillNumber}</strong>
              </div>
            )}
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-1 sm:text-right">
            <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block">
              PURCHASE & SETTLEMENT TERMS
            </span>
            <div className="text-slate-700">
              Challan Ref: <span className="font-mono font-bold text-slate-900">{invoice.challanNumber || 'CH-DIRECT'}</span>
            </div>
            <div className="text-slate-700">
              Stock Depot / Yard: <span className="font-semibold text-teal-800">{invoice.warehouseName || 'Central Warehouse'}</span>
            </div>
            <div className="text-slate-700">
              Payment Terms: <span className="font-semibold">{invoice.paymentMethod || '30 Days Credit'}</span>
            </div>
            <div className="text-slate-700">
              Linked LC / Source: <span className="font-mono font-semibold text-blue-700">{invoice.lcNumber || 'Spot Local Purchase'}</span>
            </div>
            {invoice.branch && (
              <div className="text-slate-600 text-[11px]">
                Branch: <strong>{invoice.branch}</strong>
              </div>
            )}
          </div>
        </div>

        {/* Note: Truck measurement sector is intentionally omitted per user specification */}

        {/* Product Items Table (Identical styling to Sales Invoice) */}
        <div className="overflow-hidden border border-slate-200 rounded-xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 font-mono text-[11px] uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-4 font-bold">#</th>
                <th className="py-2.5 px-4 font-bold">DESCRIPTION / ITEM</th>
                <th className="py-2.5 px-4 font-bold text-center">RECEIVING DEPOT / UOM</th>
                <th className="py-2.5 px-4 font-bold text-right">QTY</th>
                <th className="py-2.5 px-4 font-bold text-right">RATE ({invoice.currency || 'BDT'})</th>
                <th className="py-2.5 px-4 font-bold text-right">AMOUNT ({invoice.currency || 'BDT'})</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoice.items.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-mono text-slate-400">{idx + 1}</td>
                  <td className="py-3 px-4 font-semibold text-slate-900">
                    {item.itemName}
                  </td>
                  <td className="py-3 px-4 text-center font-mono text-slate-600">
                    <span className="text-slate-700 font-medium">{item.uom || 'MT'}</span>
                    <span className="text-slate-400 text-[10px] block font-sans truncate max-w-[140px] mx-auto">
                      {invoice.warehouseName}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {item.quantity.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-700">
                    {invoice.currency === 'USD' ? '$' : '৳'}{item.unitPrice.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {invoice.currency === 'USD' ? '$' : '৳'}{(item.totalPrice || (item.quantity * item.unitPrice)).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Financial Summary & In Words */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-2">
          <div className="md:col-span-7 space-y-3 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block mb-1">
                AMOUNT IN WORDS
              </span>
              <p className="font-semibold text-slate-800 italic">
                {numberToBDTWords(invoice.grandTotal)}
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1 text-slate-600">
              <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase block mb-1">
                SETTLEMENT & AUDIT DETAILS
              </span>
              <div>Disbursement Method: <strong>{invoice.paymentMethod}</strong></div>
              {invoice.lcNumber && (
                <div className="font-mono text-[11px] text-blue-700">
                  LC Reference: <strong>{invoice.lcNumber}</strong> (Import Document Accrual)
                </div>
              )}
              {invoice.notes && (
                <div className="text-[11px] text-slate-600 italic">
                  Notes: {invoice.notes}
                </div>
              )}
              <div className="text-[10px] text-slate-400">
                Goods verified and posted to store ledger. All invoices are subject to weighbridge and accounts clearance.
              </div>
            </div>
          </div>

          <div className="md:col-span-5 bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-2 text-xs">
            <div className="flex justify-between items-center text-slate-600 font-mono">
              <span>Subtotal:</span>
              <span className="font-bold text-slate-900">
                {invoice.currency === 'USD' ? '$' : '৳'}{subtotal.toLocaleString()}
              </span>
            </div>

            {invoice.taxVatAmount > 0 && (
              <div className="flex justify-between items-center text-slate-600 font-mono">
                <span>Tax / VAT ({invoice.taxVatRate}%):</span>
                <span className="font-semibold text-slate-800">
                  {invoice.currency === 'USD' ? '$' : '৳'}{invoice.taxVatAmount.toLocaleString()}
                </span>
              </div>
            )}

            {invoice.discountAmount && invoice.discountAmount > 0 ? (
              <div className="flex justify-between items-center text-emerald-700 font-mono">
                <span>Discount / Rebate:</span>
                <span className="font-semibold">
                  - {invoice.currency === 'USD' ? '$' : '৳'}{invoice.discountAmount.toLocaleString()}
                </span>
              </div>
            ) : null}

            <div className="flex justify-between items-baseline pt-3 pb-2 border-t-2 border-b border-slate-200">
              <span className="font-black text-slate-900 uppercase font-mono">TOTAL:</span>
              <span className="text-xl font-black text-slate-900 font-mono">
                {invoice.currency === 'USD' ? '$' : '৳'}{invoice.grandTotal.toLocaleString()}
              </span>
            </div>

            <div className="flex justify-between items-center text-[11px] font-mono text-emerald-700">
              <span>Paid to Date:</span>
              <span className="font-bold">
                {invoice.currency === 'USD' ? '$' : '৳'}{invoice.paidAmount.toLocaleString()}
              </span>
            </div>

            <div className="flex justify-between items-center text-xs font-mono text-rose-600 font-bold">
              <span>Net Due Balance:</span>
              <span className="text-sm font-black">
                {invoice.currency === 'USD' ? '$' : '৳'}{invoice.dueAmount.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Signatures */}
        <div className="grid grid-cols-3 gap-6 pt-12 text-center text-xs text-slate-500 border-t border-slate-200">
          <div>
            <div className="border-t border-dashed border-slate-400 pt-2 font-medium">
              Prepared By (Store In-Charge)
            </div>
          </div>
          <div>
            <div className="border-t border-dashed border-slate-400 pt-2 font-medium">
              Quality & Weighbridge Verification
            </div>
          </div>
          <div>
            <div className="border-t border-dashed border-slate-400 pt-2 font-medium">
              Authorized Commercial Signatory
            </div>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};
