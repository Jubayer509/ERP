import React, { useState, useMemo } from 'react';
import { 
  FileSpreadsheet, 
  Search, 
  Filter, 
  Plus, 
  Trash2, 
  Download, 
  Printer, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Calculator, 
  Layers, 
  Landmark, 
  DollarSign, 
  RefreshCw, 
  CheckCircle2, 
  Clock, 
  Edit3, 
  Sparkles,
  ChevronDown,
  Calendar,
  X,
  TrendingDown,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { LetterOfCredit, SoilClaimRecord, KhataPaymentRecord } from '../../types/erp';
import { PrintHeader, PrintSignatures } from '../common/PrintHeader';

interface LCBalanceSheetViewProps {
  lcs: LetterOfCredit[];
  initialSoilClaims?: SoilClaimRecord[];
  initialKhataPayments?: KhataPaymentRecord[];
  onSelectLc?: (lc: LetterOfCredit) => void;
}

export const LCBalanceSheetView: React.FC<LCBalanceSheetViewProps> = ({
  lcs,
  initialSoilClaims = [],
  initialKhataPayments = [],
  onSelectLc
}) => {
  // Search & Filter States
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOwner, setSelectedOwner] = useState<string>('ALL');
  const [selectedImporter, setSelectedImporter] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [globalBdtRate, setGlobalBdtRate] = useState<number>(124);

  // Khata ledger states (Soil claims & Khata payments)
  const [soilClaims, setSoilClaims] = useState<SoilClaimRecord[]>(initialSoilClaims);
  const [khataPayments, setKhataPayments] = useState<KhataPaymentRecord[]>(initialKhataPayments);

  // Modals
  const [isSoilModalOpen, setIsSoilModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isBataCalcOpen, setIsBataCalcOpen] = useState(false);

  // New Soil Claim Form State
  const [newSoilLc, setNewSoilLc] = useState('');
  const [newSoilMt, setNewSoilMt] = useState<number>(0);
  const [newSoilRateBdt, setNewSoilRateBdt] = useState<number>(0);
  const [newSoilDate, setNewSoilDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newSoilNote, setNewSoilNote] = useState('');

  // New Khata Payment Form State
  const [newPayLc, setNewPayLc] = useState('');
  const [newPayPayer, setNewPayPayer] = useState('');
  const [newPayType, setNewPayType] = useState<'BDT' | 'IC_RS' | 'USD'>('' as any);
  const [newPayAmountBdt, setNewPayAmountBdt] = useState<number>(0);
  const [newPayAmountRs, setNewPayAmountRs] = useState<number>(0);
  const [newPayBataRate, setNewPayBataRate] = useState<number>('' as any);
  const [newPayDate, setNewPayDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newPayNote, setNewPayNote] = useState('');

  // Interactive Live BATA Calculator State
  const [calcIcRs, setCalcIcRs] = useState<number>('' as any);
  const [calcBataRate, setCalcBataRate] = useState<number>('' as any);
  const [calcPercent, setCalcPercent] = useState<number>('' as any);

  // Filtered LCs
  const filteredLcs = useMemo(() => {
    return lcs.filter(lc => {
      if (lc.status === 'Cancelled' || lc.isCancelled) return false;
      const matchSearch = 
        lc.lcNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lc.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (lc.importerName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (lc.companyOwner || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (lc.originQuarryItem || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (lc.boulderCategory || '').toLowerCase().includes(searchTerm.toLowerCase());

      const matchOwner = selectedOwner === 'ALL' || lc.companyOwner === selectedOwner;
      const matchImporter = selectedImporter === 'ALL' || lc.importerName === selectedImporter;
      const matchCategory = selectedCategory === 'ALL' || lc.boulderCategory === selectedCategory;

      return matchSearch && matchOwner && matchImporter && matchCategory;
    });
  }, [lcs, searchTerm, selectedOwner, selectedImporter, selectedCategory]);

  // Aggregate Calculations
  const aggregates = useMemo(() => {
    let totalReceivedMt = 0;
    let totalBillUsd = 0;
    let totalBankLcAmount = 0;
    let totalBalanceUsd = 0;
    let totalBalanceBdt = 0;

    filteredLcs.forEach(lc => {
      const recvMt = lc.receivedQtyMt ?? lc.items[0]?.quantity ?? 0;
      const rateUsd = lc.contractRateUsd ?? lc.items[0]?.unitPriceForeign ?? 0;
      const billUsd = lc.totalBillUsd ?? (recvMt * rateUsd);
      const lcAmount = lc.cfrAmount;
      const balUsd = lc.usdBalance ?? (billUsd - lcAmount);
      const rateBdt = lc.rateBdt || globalBdtRate;
      const balBdt = lc.bdtBalanceAmount ?? (balUsd * rateBdt);

      totalReceivedMt += recvMt;
      totalBillUsd += billUsd;
      totalBankLcAmount += lcAmount;
      totalBalanceUsd += balUsd;
      totalBalanceBdt += balBdt;
    });

    const totalSoilClaimBdt = soilClaims.reduce((sum, sc) => sum + sc.totalAmountBdt, 0);
    const totalKhataBdt = khataPayments
      .filter(p => p.paymentType === 'BDT')
      .reduce((sum, p) => sum + (p.amountBdt || 0), 0);
    const totalKhataRs = khataPayments
      .filter(p => p.paymentType === 'IC_RS')
      .reduce((sum, p) => sum + (p.amountRs || 0), 0);

    return {
      totalReceivedMt,
      totalBillUsd,
      totalBankLcAmount,
      totalBalanceUsd,
      totalBalanceBdt,
      totalSoilClaimBdt,
      totalKhataBdt,
      totalKhataRs,
      netSettlementBdt: totalBalanceBdt - totalSoilClaimBdt - totalKhataBdt
    };
  }, [filteredLcs, globalBdtRate, soilClaims, khataPayments]);

  // Unique lists for filter dropdowns
  const owners = useMemo(() => {
    const set = new Set<string>();
    lcs.forEach(l => { if (l.companyOwner) set.add(l.companyOwner); });
    return Array.from(set);
  }, [lcs]);

  const importers = useMemo(() => {
    const set = new Set<string>();
    lcs.forEach(l => { if (l.importerName) set.add(l.importerName); });
    return Array.from(set);
  }, [lcs]);

  const categories = useMemo(() => {
    const set = new Set<string>();
    lcs.forEach(l => { if (l.boulderCategory) set.add(l.boulderCategory); });
    return Array.from(set);
  }, [lcs]);

  // Handlers for adding records
  const handleAddSoilClaim = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSoilLc || newSoilMt <= 0 || newSoilRateBdt <= 0) return;

    const total = Math.round(newSoilMt * newSoilRateBdt);
    const newRecord: SoilClaimRecord = {
      id: `sc-${Date.now()}`,
      lcNumber: newSoilLc,
      claimMt: newSoilMt,
      ratePerMtBdt: newSoilRateBdt,
      totalAmountBdt: total,
      date: newSoilDate,
      note: newSoilNote || `Soil Claim for LC ${newSoilLc}`
    };

    setSoilClaims([newRecord, ...soilClaims]);
    setIsSoilModalOpen(false);
    setNewSoilLc('');
    setNewSoilMt(0);
    setNewSoilRateBdt(0);
    setNewSoilDate(new Date().toISOString().split('T')[0]);
    setNewSoilNote('');
  };

  const handleDeleteSoilClaim = (id: string) => {
    setSoilClaims(soilClaims.filter(c => c.id !== id));
  };

  const handleAddKhataPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPayPayer) return;

    let bdt = newPayAmountBdt;
    if (newPayType === 'IC_RS' && Number(newPayBataRate) > 0) {
      bdt = Math.round(newPayAmountRs * Number(newPayBataRate));
    }

    const newRecord: KhataPaymentRecord = {
      id: `kp-${Date.now()}`,
      lcNumber: newPayLc || undefined,
      date: newPayDate,
      paidBy: newPayPayer,
      paymentType: newPayType || 'BDT',
      amountBdt: bdt,
      amountRs: newPayType === 'IC_RS' ? newPayAmountRs : undefined,
      bataRate: newPayType === 'IC_RS' ? Number(newPayBataRate) : undefined,
      status: 'Paid',
      note: newPayNote
    };

    setKhataPayments([newRecord, ...khataPayments]);
    setIsPaymentModalOpen(false);
    setNewPayLc('');
    setNewPayPayer('');
    setNewPayType('' as any);
    setNewPayAmountBdt(0);
    setNewPayAmountRs(0);
    setNewPayBataRate('' as any);
    setNewPayDate(new Date().toISOString().split('T')[0]);
    setNewPayNote('');
  };

  const handleDeleteKhataPayment = (id: string) => {
    setKhataPayments(khataPayments.filter(p => p.id !== id));
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    const headers = [
      'LC No', 'Owner', 'EXP Company', 'Border', 'Importer', 'Item',
      'Received MT', 'Rate USD', 'Total USD', 'LC Bank Amount', 'Balance USD',
      'Rate BDT', 'Amount BDT', 'Remark'
    ];

    const rows = filteredLcs.map(lc => {
      const recvMt = lc.receivedQtyMt ?? lc.items[0]?.quantity ?? 0;
      const rateUsd = lc.contractRateUsd ?? lc.items[0]?.unitPriceForeign ?? 0;
      const billUsd = lc.totalBillUsd ?? (recvMt * rateUsd);
      const lcAmount = lc.cfrAmount;
      const balUsd = lc.usdBalance ?? (billUsd - lcAmount);
      const rateBdt = lc.rateBdt || globalBdtRate;
      const balBdt = lc.bdtBalanceAmount ?? (balUsd * rateBdt);

      return [
        lc.lcNumber,
        lc.companyOwner || '',
        `"${lc.supplierName}"`,
        lc.borderLandPort || 'Burimari',
        lc.importerName || '',
        `"${lc.originQuarryItem || lc.boulderCategory || ''}"`,
        recvMt,
        rateUsd,
        billUsd.toFixed(2),
        lcAmount.toFixed(2),
        balUsd.toFixed(2),
        rateBdt,
        balBdt.toFixed(0),
        lc.remarkStatus || lc.status
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `LC_Balance_Sheet_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Official Print Header */}
      <PrintHeader
        title="L/C Balance Sheet & Cross-Border Procurement Ledger"
        subtitle="Consolidated Foreign Currency (USD), Land Port Receiving, Delivery Differentials & Net Outstanding"
        metadata={[
          { label: 'Total LCs', value: `${filteredLcs.length}` },
          { label: 'Total Received', value: `${aggregates.totalReceivedMt.toLocaleString()} MT` },
          { label: 'Total Bill (USD)', value: `$${aggregates.totalBillUsd.toLocaleString()}` },
          { label: 'Net Settlement (BDT)', value: `৳${Math.round(aggregates.netSettlementBdt).toLocaleString()}` }
        ]}
      />

      {/* Top Banner / Heading (Hidden when printing) */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-slate-800 no-print print:hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-1">
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
              LC Balance Sheet
            </h1>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setIsSoilModalOpen(true)}
              className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Soil Claim</span>
            </button>

            <button
              type="button"
              onClick={() => setIsPaymentModalOpen(true)}
              className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ খাতা পেমেন্ট (Cash/Bank)</span>
            </button>

            <button
              type="button"
              onClick={() => setIsBataCalcOpen(true)}
              className="px-3.5 py-2 bg-blue-600/80 hover:bg-blue-600 text-white rounded-xl text-xs font-bold transition-all border border-blue-400/40 flex items-center gap-1.5"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>বাটা ক্যালকুলেটর (BATA)</span>
            </button>

            <button
              type="button"
              onClick={handleExportCsv}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium border border-slate-700 transition-colors flex items-center gap-1.5"
              title="Download Excel CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium border border-slate-700 transition-colors flex items-center gap-1.5"
              title="Print Ledger"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
          </div>
        </div>

        {/* 5 KPI Metric Pill Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-6 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-800/60 backdrop-blur-xs rounded-2xl p-3 border border-slate-700/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Received Stone / Cargo
            </span>
            <span className="text-xl font-black text-white font-mono mt-1 block">
              {aggregates.totalReceivedMt.toLocaleString('en-US', { maximumFractionDigits: 2 })} <span className="text-xs font-sans text-slate-400">MT</span>
            </span>
            <span className="text-[10px] text-blue-400 mt-0.5 block">{filteredLcs.length} LCs Recorded</span>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs rounded-2xl p-3 border border-slate-700/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Total Bill USD
            </span>
            <span className="text-xl font-black text-amber-300 font-mono mt-1 block">
              ${aggregates.totalBillUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Delivered Cargo Value</span>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs rounded-2xl p-3 border border-slate-700/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Net Balance USD
            </span>
            <span className={`text-xl font-black font-mono mt-1 block ${aggregates.totalBalanceUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {aggregates.totalBalanceUsd >= 0 ? '+' : ''}${aggregates.totalBalanceUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Delivery vs Bank LC</span>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs rounded-2xl p-3 border border-slate-700/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Total Soil Claims
            </span>
            <span className="text-xl font-black text-rose-300 font-mono mt-1 block">
              ৳{aggregates.totalSoilClaimBdt.toLocaleString('en-US')}
            </span>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs rounded-2xl p-3 border border-slate-700/60 col-span-2 sm:col-span-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Net BDT Outstanding
            </span>
            <span className={`text-xl font-black font-mono mt-1 block ${aggregates.netSettlementBdt >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
              {aggregates.netSettlementBdt >= 0 ? '+' : ''}৳{Math.round(aggregates.netSettlementBdt).toLocaleString('en-US')}
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar (Hidden when printing) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3 no-print print:hidden">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by LC No (e.g. 2881, 1547, 1248), Exporter, Owner, Quarry..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
            />
          </div>

          {/* Quick Category Select Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
            <button
              type="button"
              onClick={() => setSelectedCategory('ALL')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === 'ALL'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All Items
            </button>
            <button
              type="button"
              onClick={() => setSelectedCategory('Boulder Stone')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === 'Boulder Stone'
                  ? 'bg-blue-600 text-white'
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
              }`}
            >
              🪨 Boulder
            </button>
            <button
              type="button"
              onClick={() => setSelectedCategory('River Stone Boulder')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === 'River Stone Boulder'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
              }`}
            >
              🌊 River Stone
            </button>
            <button
              type="button"
              onClick={() => setSelectedCategory('20MM Crush Stone')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === '20MM Crush Stone'
                  ? 'bg-slate-700 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              🔨 20MM Crush
            </button>
            <button
              type="button"
              onClick={() => setSelectedCategory('Fertilizer (GA-3)')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === 'Fertilizer (GA-3)'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
              }`}
            >
              🌱 China Fertilizer
            </button>
          </div>
        </div>

        {/* Row 2: Owner, Importer & Global BDT Rate */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
          <div className="flex flex-wrap items-center gap-3">
            {/* Owner Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Owner:</span>
              <select
                value={selectedOwner}
                onChange={e => setSelectedOwner(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800 font-semibold focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              >
                <option value="ALL">All Owners</option>
                {owners.map(o => (
                  <option key={o} value={o}>{o}</option>
                ))}
              </select>
            </div>

            {/* Importer Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Importer:</span>
              <select
                value={selectedImporter}
                onChange={e => setSelectedImporter(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800 font-semibold focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              >
                <option value="ALL">All Importers</option>
                {importers.map(imp => (
                  <option key={imp} value={imp}>{imp}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Global BDT Conversion Rate (Editable) */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1">
            <span className="text-slate-500 font-medium">Conversion Rate:</span>
            <div className="flex items-center gap-1 font-mono font-bold text-slate-900">
              <span>$1 USD = ৳</span>
              <input
                type="number"
                value={globalBdtRate}
                onChange={e => setGlobalBdtRate(parseFloat(e.target.value) || 0)}
                className="w-14 bg-white border border-slate-300 rounded px-1.5 py-0.5 text-center text-xs focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              />
              <span className="text-[10px] text-slate-400 font-normal">BDT</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main L/C Balance Sheet Table (Exact physical replica of PDF 2) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-600" />
            <h2 className="text-sm font-bold text-slate-800">
              L/C Balance Sheet Table ({filteredLcs.length} Records)
            </h2>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            Showing records for Burimari & CTG Port
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-600 font-bold text-[11px] uppercase tracking-wider">
                <th className="py-2.5 px-3">L/C No</th>
                <th className="py-2.5 px-3">Owner</th>
                <th className="py-2.5 px-3">EXP Company</th>
                <th className="py-2.5 px-2.5 text-center">Border</th>
                <th className="py-2.5 px-3">Importer</th>
                <th className="py-2.5 px-3">Boulder / Item</th>
                <th className="py-2.5 px-2.5 text-right">Received M/T</th>
                <th className="py-2.5 px-2.5 text-right">Rate USD$</th>
                <th className="py-2.5 px-3 text-right">Total USD</th>
                <th className="py-2.5 px-3 text-right">L/C Rate (Amt)</th>
                <th className="py-2.5 px-3 text-right">Balance USD</th>
                <th className="py-2.5 px-2.5 text-center">Rate BDT</th>
                <th className="py-2.5 px-3 text-right">Amount (BDT)</th>
                <th className="py-2.5 px-2.5 text-center">Remark</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filteredLcs.map((lc) => {
                const recvMt = lc.receivedQtyMt ?? lc.items[0]?.quantity ?? 0;
                const rateUsd = lc.contractRateUsd ?? lc.items[0]?.unitPriceForeign ?? 0;
                const billUsd = lc.totalBillUsd ?? (recvMt * rateUsd);
                const lcAmount = lc.cfrAmount;
                const balUsd = lc.usdBalance ?? (billUsd - lcAmount);
                const rateBdt = lc.rateBdt || globalBdtRate;
                const balBdt = lc.bdtBalanceAmount ?? (balUsd * rateBdt);

                const isReceivable = balUsd > 0;
                const isPayable = balUsd < 0;

                return (
                  <tr 
                    key={lc.id} 
                    className="hover:bg-blue-50/40 transition-colors group cursor-pointer"
                    onClick={() => onSelectLc && onSelectLc(lc)}
                  >
                    {/* LC Number */}
                    <td className="py-2.5 px-3 font-mono font-bold text-blue-700 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span>{lc.lcNumber}</span>
                      </div>
                    </td>

                    {/* Company Owner */}
                    <td className="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                      {lc.companyOwner || 'Edu'}
                    </td>

                    {/* Exporter Company */}
                    <td className="py-2.5 px-3 font-medium text-slate-900 whitespace-nowrap max-w-[160px] truncate" title={lc.supplierName}>
                      {lc.supplierName}
                    </td>

                    {/* Border Land Port */}
                    <td className="py-2.5 px-2.5 text-center whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                        {lc.borderLandPort || 'Burimari'}
                      </span>
                    </td>

                    {/* Importer */}
                    <td className="py-2.5 px-3 text-slate-700 whitespace-nowrap">
                      {lc.importerName || 'Amir Hamza'}
                    </td>

                    {/* Boulder / Item */}
                    <td className="py-2.5 px-3 text-slate-800 whitespace-nowrap">
                      <span className="font-semibold block">{lc.originQuarryItem || lc.items[0]?.itemName}</span>
                      <span className="text-[10px] text-slate-400 block">{lc.boulderCategory}</span>
                    </td>

                    {/* Received MT */}
                    <td className="py-2.5 px-2.5 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                      {recvMt > 0 ? recvMt.toLocaleString('en-US', { maximumFractionDigits: 2 }) : <span className="text-slate-400 italic">0 MT</span>}
                    </td>

                    {/* Rate USD */}
                    <td className="py-2.5 px-2.5 text-right font-mono text-slate-700 whitespace-nowrap">
                      ${rateUsd.toFixed(2)}
                    </td>

                    {/* Total USD */}
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                      ${billUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>

                    {/* L/C Rate Amount */}
                    <td className="py-2.5 px-3 text-right font-mono text-slate-600 whitespace-nowrap">
                      ${lcAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>

                    {/* Balance USD */}
                    <td className="py-2.5 px-3 text-right font-mono font-black whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[11px] ${
                        isReceivable ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                        isPayable ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                        'bg-slate-50 text-slate-600'
                      }`}>
                        {isReceivable ? '+' : ''}${balUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </td>

                    {/* Rate BDT */}
                    <td className="py-2.5 px-2.5 text-center font-mono text-slate-600 whitespace-nowrap">
                      {rateBdt}
                    </td>

                    {/* Amount BDT */}
                    <td className="py-2.5 px-3 text-right font-mono font-bold whitespace-nowrap">
                      <span className={balBdt >= 0 ? 'text-emerald-700' : 'text-rose-700'}>
                        {balBdt >= 0 ? '+' : ''}৳{Math.round(balBdt).toLocaleString('en-US')}
                      </span>
                    </td>

                    {/* Remark / Status */}
                    <td className="py-2.5 px-2.5 text-center whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        lc.remarkStatus === 'LC Closed' || lc.status === 'Costed & Closed' ? 'bg-slate-100 text-slate-700' :
                        lc.remarkStatus === 'On Loading' ? 'bg-blue-100 text-blue-800 animate-pulse' :
                        lc.remarkStatus === 'In Transit' ? 'bg-indigo-100 text-indigo-800' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {lc.remarkStatus || lc.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>

            {/* Total Footer Row */}
            <tfoot>
              <tr className="bg-slate-100 font-mono font-black text-slate-900 border-t-2 border-slate-300">
                <td colSpan={6} className="py-3 px-3 text-right font-sans font-bold uppercase tracking-wider text-xs">
                  Grand Total Balance Sheet:
                </td>
                <td className="py-3 px-2.5 text-right font-black">
                  {aggregates.totalReceivedMt.toLocaleString('en-US', { maximumFractionDigits: 2 })} MT
                </td>
                <td></td>
                <td className="py-3 px-3 text-right font-black text-amber-900">
                  ${aggregates.totalBillUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="py-3 px-3 text-right font-black text-slate-700">
                  ${aggregates.totalBankLcAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="py-3 px-3 text-right font-black text-blue-900">
                  {aggregates.totalBalanceUsd >= 0 ? '+' : ''}${aggregates.totalBalanceUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="text-center font-normal text-xs text-slate-500">Avg {globalBdtRate}</td>
                <td className="py-3 px-3 text-right font-black text-slate-950">
                  {aggregates.totalBalanceBdt >= 0 ? '+' : ''}৳{Math.round(aggregates.totalBalanceBdt).toLocaleString('en-US')}
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Bottom 2-Column Section: 1) Soil Claim Ledger & 2) IC Rs / Khata Payment Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Module 1: Soil Claim Ledger */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col justify-between">
          <div>
            <div className="px-5 py-3.5 bg-amber-50/70 border-b border-amber-200/60 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-700" />
                <h3 className="text-sm font-bold text-amber-950">
                  Soil Claim Ledger
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsSoilModalOpen(true)}
                className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>New Claim</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold text-[11px]">
                    <th className="py-2 px-3">L/C No</th>
                    <th className="py-2 px-3 text-right">Soil Claim (MT)</th>
                    <th className="py-2 px-3 text-right">Rate (BDT/MT)</th>
                    <th className="py-2 px-3 text-right">Total (BDT)</th>
                    <th className="py-2 px-3">Date & Notes</th>
                    <th className="py-2 px-2 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {soilClaims.map(sc => (
                    <tr key={sc.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-mono font-bold text-blue-700">{sc.lcNumber}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-amber-800">{sc.claimMt} MT</td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-700">৳{sc.ratePerMtBdt.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-black text-rose-700">৳{sc.totalAmountBdt.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-slate-600 text-[11px]">
                        <span className="font-semibold block">{sc.date}</span>
                        <span className="text-[10px] text-slate-400">{sc.note}</span>
                      </td>
                      <td className="py-2.5 px-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteSoilClaim(sc.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                          title="Delete Claim"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {soilClaims.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-4 text-center text-slate-400">No soil claim entries</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between font-mono font-bold text-xs">
            <span className="text-slate-600 font-sans font-semibold">Total Soil Claim Deductions:</span>
            <span className="text-rose-700 text-sm font-black">
              ৳{aggregates.totalSoilClaimBdt.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Module 2: Indian Rupee (IC Rs) & Khata Part-Payment Ledger */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col justify-between">
          <div>
            <div className="px-5 py-3.5 bg-indigo-50/70 border-b border-indigo-200/60 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Landmark className="w-4 h-4 text-indigo-700" />
                <h3 className="text-sm font-bold text-indigo-950">
                  খাতা পেমেন্ট ও ইন্ডিয়ান রুপি (IC Rs / BATA Settlement)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsPaymentModalOpen(true)}
                className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>+ পেমেন্ট এন্ট্রি</span>
              </button>
            </div>

            <div className="p-4 text-xs text-slate-600 bg-indigo-50/20 border-b border-slate-100 flex items-center justify-between">
              <p>
                রাব্বি ভাইয়ের পার্ট পেমেন্ট এবং জুবায়েদ ভাই (IBBL A/C 3609) এর মাধ্যমে ইন্ডিয়ান রুপি বাটা (BATA) সেটেলমেন্ট।
              </p>
              <button
                type="button"
                onClick={() => setIsBataCalcOpen(true)}
                className="text-[11px] font-bold text-indigo-600 underline whitespace-nowrap ml-2"
              >
                বাটা হিসাব দেখুন
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold text-[11px]">
                    <th className="py-2 px-3">তারিখ</th>
                    <th className="py-2 px-3">বিবরণ / Paid By</th>
                    <th className="py-2 px-2.5 text-center">মুদ্রা</th>
                    <th className="py-2 px-3 text-right">পরিমাণ (Amount)</th>
                    <th className="py-2 px-3 text-right">BDT সমমূল্য</th>
                    <th className="py-2 px-2 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {khataPayments.map(kp => (
                    <tr key={kp.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-mono text-slate-600 whitespace-nowrap">{kp.date}</td>
                      <td className="py-2.5 px-3">
                        <span className="font-semibold text-slate-900 block">{kp.paidBy}</span>
                        <span className="text-[10px] text-slate-400 block">{kp.note}</span>
                      </td>
                      <td className="py-2.5 px-2.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          kp.paymentType === 'IC_RS' ? 'bg-orange-100 text-orange-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {kp.paymentType === 'IC_RS' ? 'IC Rs' : 'BDT'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-800">
                        {kp.paymentType === 'IC_RS' ? `${(kp.amountRs || 0).toLocaleString()} Rs` : `৳${(kp.amountBdt || 0).toLocaleString()}`}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-black text-emerald-700">
                        ৳{(kp.amountBdt || 0).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteKhataPayment(kp.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                          title="Delete Payment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {khataPayments.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-4 text-center text-slate-400">কোন পেমেন্ট রেকর্ড নেই</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between font-mono font-bold text-xs">
            <span className="text-slate-600 font-sans font-semibold">Total Khata Payments Settled:</span>
            <span className="text-emerald-700 text-sm font-black">
              ৳{aggregates.totalKhataBdt.toLocaleString()}
            </span>
          </div>
        </div>

      </div>

      {/* Modal 1: Add Soil Claim */}
      {isSoilModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-slate-900 text-base">Add Soil Claim</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsSoilModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSoilClaim} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Select L/C Number:</label>
                <select
                  value={newSoilLc}
                  onChange={e => setNewSoilLc(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-semibold focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                >
                  <option value="">-- Select LC --</option>
                  {lcs.map(l => (
                    <option key={l.id} value={l.lcNumber}>
                      {l.lcNumber} - {l.supplierName} ({l.boulderCategory || 'Stone'})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Claim Weight (MT):</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 14.5"
                    value={newSoilMt || ''}
                    onChange={e => setNewSoilMt(parseFloat(e.target.value) || 0)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Rate per MT (BDT):</label>
                  <input
                    type="number"
                    placeholder="e.g. 2450"
                    value={newSoilRateBdt || ''}
                    onChange={e => setNewSoilRateBdt(parseFloat(e.target.value) || 0)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Real-time Calculation Box */}
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-center justify-between">
                <span className="font-semibold text-amber-900">Total Deduction (BDT):</span>
                <span className="text-base font-black font-mono text-rose-700">
                  ৳{Math.round(newSoilMt * newSoilRateBdt).toLocaleString()}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Date:</label>
                  <input
                    type="date"
                    value={newSoilDate}
                    onChange={e => setNewSoilDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Note / Challan Ref:</label>
                  <input
                    type="text"
                    placeholder="Weighbridge wash deduction"
                    value={newSoilNote}
                    onChange={e => setNewSoilNote(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsSoilModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold transition-colors shadow-md"
                >
                  Save Soil Claim
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Add Khata Payment */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Landmark className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-base">খাতা পেমেন্ট / বাটা এন্ট্রি</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsPaymentModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddKhataPayment} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Paid By / বিবরণ:</label>
                <input
                  type="text"
                  placeholder="e.g. Payment By Rabbi / Paid By Jubayer (A/C 3609) IBBL"
                  value={newPayPayer}
                  onChange={e => setNewPayPayer(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Payment Currency:</label>
                  <select
                    value={newPayType}
                    onChange={e => setNewPayType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-bold focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="BDT">BDT (টাকা)</option>
                    <option value="IC_RS">IC Rs (ইন্ডিয়ান রুপি)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Relevant LC (Optional):</label>
                  <input
                    type="text"
                    placeholder="e.g. 2881 or 547"
                    value={newPayLc}
                    onChange={e => setNewPayLc(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {newPayType === 'BDT' ? (
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Amount (BDT ৳):</label>
                  <input
                    type="number"
                    placeholder="e.g. 39300"
                    value={newPayAmountBdt || ''}
                    onChange={e => setNewPayAmountBdt(parseFloat(e.target.value) || 0)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono font-bold text-emerald-800 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              ) : (
                <div className="space-y-3 bg-orange-50/70 p-3 rounded-2xl border border-orange-200">
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block font-bold text-orange-950 mb-1">IC Rs Amount:</label>
                      <input
                        type="number"
                        placeholder="e.g. 80654.69"
                        value={newPayAmountRs || ''}
                        onChange={e => setNewPayAmountRs(parseFloat(e.target.value) || 0)}
                        required
                        className="w-full bg-white border border-orange-200 rounded-xl px-3 py-2 font-mono font-bold text-orange-900 focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-orange-950 mb-1">BATA Rate / Multiplier:</label>
                      <input
                        type="number"
                        step="0.001"
                        placeholder="1.27"
                        value={newPayBataRate || ''}
                        onChange={e => setNewPayBataRate(parseFloat(e.target.value) || 1)}
                        className="w-full bg-white border border-orange-200 rounded-xl px-3 py-2 font-mono font-bold text-orange-900 focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-orange-200">
                    <span className="font-semibold text-orange-900">Converted to BDT:</span>
                    <span className="font-black font-mono text-emerald-700 text-sm">
                      ৳{Math.round(newPayAmountRs * newPayBataRate).toLocaleString()}
                    </span>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Date:</label>
                  <input
                    type="date"
                    value={newPayDate}
                    onChange={e => setNewPayDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Notes / Bank Ref:</label>
                  <input
                    type="text"
                    placeholder="IBBL A/C 3609"
                    value={newPayNote}
                    onChange={e => setNewPayNote(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-colors shadow-md"
                >
                  Save Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Live BATA Calculator (ইন্ডিয়ান রুপি ও বাটা হিসাব) */}
      {isBataCalcOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Calculator className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-base">ইন্ডিয়ান রুপি ও বাটা ক্যালকুলেটর (IC Rs to BDT)</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsBataCalcOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl text-xs text-blue-900">
              <span className="font-bold block">আপনার খাতার হিসাবের সূত্র (From PDF 2 Khata):</span>
              <p className="mt-1 font-mono text-[11px]">
                Payable IC Rs 80,654.69 @ 75.30% BATA (বা 1.27 মাল্টিপ্লায়ার) = 103,000.00 BDT
              </p>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Payable IC Rs (ইন্ডিয়ান রুপি):</label>
                <input
                  type="number"
                  value={calcIcRs}
                  onChange={e => setCalcIcRs(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono font-black text-slate-900 text-base focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">BATA Multiplier (বাটা দর):</label>
                  <input
                    type="number"
                    step="0.001"
                    value={calcBataRate}
                    onChange={e => setCalcBataRate(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">যেমন: 1.27 (100 Rs = 127 BDT)</span>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Border BATA % (বিকল্প):</label>
                  <input
                    type="number"
                    step="0.01"
                    value={calcPercent}
                    onChange={e => {
                      const p = parseFloat(e.target.value) || 0;
                      setCalcPercent(p);
                      if (p > 0) setCalcBataRate(parseFloat((100 / p).toFixed(3)));
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">যেমন: 75.30% বাটা</span>
                </div>
              </div>

              {/* Conversion Result Display Card */}
              <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-2xl p-4 shadow-md flex items-center justify-between">
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-emerald-100 font-bold block">
                    Settlement Equivalent (টাকায় পরিশোধযোগ্য)
                  </span>
                  <span className="text-2xl font-black font-mono text-white mt-1 block">
                    ৳{Math.round(calcIcRs * calcBataRate).toLocaleString('en-US')} BDT
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-emerald-100 block">Bank Account:</span>
                  <span className="font-bold text-xs text-white">IBBL A/C 3609</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setNewPayType('IC_RS');
                    setNewPayAmountRs(calcIcRs);
                    setNewPayBataRate(calcBataRate);
                    setNewPayPayer('Paid By Jubayer (A/C 3609) IBBL');
                    setNewPayNote(`Payable IC Rs ${calcIcRs} @ ${calcPercent}% BATA`);
                    setIsBataCalcOpen(false);
                    setIsPaymentModalOpen(true);
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-colors shadow-md flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>খাতায় এন্ট্রি যোগ করুন</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Official Signatures Block (Print Only) */}
      <PrintSignatures
        preparedByRole="Commercial & LC Officer"
        auditedByRole="Import Accounts Auditor"
        approvedByRole="Managing Director"
      />
    </div>
  );
};
