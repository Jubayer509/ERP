import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  Search, 
  Plus, 
  Calendar, 
  Building2, 
  Receipt, 
  Printer, 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  FileText, 
  ChevronRight,
  Filter,
  ArrowUpRight,
  Eye,
  X,
  Edit,
  Trash2,
  RotateCcw,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { SupplierPaymentRecord, Supplier, DirectPurchaseInvoice, BankAccount } from '../../types/erp';
import { EditSupplierPaymentModal } from './EditSupplierPaymentModal';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { RecycleBinModal } from '../common/RecycleBinModal';
import { ModalWrapper } from '../common/ModalWrapper';
import { saveDeletedRecord, getDeletedRecords, subscribeRecycleBin } from '../../utils/recycleBinStorage';
import { getBankAccounts, subscribeBankAccounts, isCashAccount } from '../../utils/bankAccountStorage';
import { postVoucher, voidAccountTransaction, getAccountTransactions } from '../../services/accountService';
import { useAuth } from '../../contexts/AuthContext';

interface SupplierPaymentListProps {
  payments: SupplierPaymentRecord[];
  suppliers: Supplier[];
  invoices: DirectPurchaseInvoice[];
  onRecordNewPayment: (payment: SupplierPaymentRecord) => void;
  onUpdatePayment?: (payment: SupplierPaymentRecord) => void;
  onDeletePayment?: (id: string) => void;
  onViewInvoice?: (invoiceNumber: string) => void;
  onViewSupplierLedger?: (supplierId: string) => void;
  isCreateModalOpenExternal?: boolean;
  onCloseCreateModal?: () => void;
  preselectedInvoice?: DirectPurchaseInvoice | null;
}

export const SupplierPaymentList: React.FC<SupplierPaymentListProps> = ({
  payments,
  suppliers,
  invoices,
  onRecordNewPayment,
  onUpdatePayment,
  onDeletePayment,
  onViewInvoice,
  onViewSupplierLedger,
  isCreateModalOpenExternal = false,
  onCloseCreateModal,
  preselectedInvoice = null
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [methodFilter, setMethodFilter] = useState<string>('ALL');
  const [supplierFilter, setSupplierFilter] = useState<string>('ALL');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | 'THIS_MONTH'>('ALL');
  
  // Modals
  const [showCreateModalInternal, setShowCreateModalInternal] = useState(false);
  const showCreateModal = showCreateModalInternal || isCreateModalOpenExternal;
  const [selectedVoucherForPrint, setSelectedVoucherForPrint] = useState<SupplierPaymentRecord | null>(null);

  // Edit, Delete & Recycle Bin state
  const [editingPayment, setEditingPayment] = useState<SupplierPaymentRecord | null>(null);
  const [deletingPayment, setDeletingPayment] = useState<SupplierPaymentRecord | null>(null);
  const [isRecycleBinOpen, setIsRecycleBinOpen] = useState(false);
  const [trashCount, setTrashCount] = useState<number>(() => {
    return getDeletedRecords().filter(r => r.recordType === 'supplier_payment').length;
  });

  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  // Real Bank & Cash Accounts
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());
  useEffect(() => {
    const unsub = subscribeBankAccounts(setBankAccounts);
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsub = subscribeRecycleBin(() => {
      setTrashCount(getDeletedRecords().filter(r => r.recordType === 'supplier_payment').length);
    });
    return unsub;
  }, []);

  const handleConfirmDelete = async (reason: string) => {
    if (!deletingPayment) return;
    if (!isAdmin) {
      return;
    }
    const targetTxnId =
      deletingPayment.voucherId ||
      getAccountTransactions().find(t => t.voucherNo === deletingPayment.voucherNumber && t.status !== 'voided')?.id;

    if (targetTxnId) {
      try {
        await voidAccountTransaction(
          targetTxnId,
          reason || 'Supplier payment voided & moved to Recycle Bin',
          {
            uid: currentUser?.id || 'usr-admin',
            name: currentUser?.name || 'Admin',
            email: currentUser?.email
          }
        );
      } catch (err) {
        console.warn('Voucher void notice during payment cancel:', err);
      }
    }

    saveDeletedRecord({
      recordType: 'supplier_payment',
      originalId: deletingPayment.id,
      referenceNumber: deletingPayment.voucherNumber || deletingPayment.paymentNumber,
      title: `Supplier Payment Voucher (${deletingPayment.supplierName})`,
      partyName: deletingPayment.supplierName,
      amount: deletingPayment.amount,
      date: deletingPayment.paymentDate,
      deletedBy: currentUser?.name || 'Admin',
      reason,
      data: { ...deletingPayment, status: 'Voided', isVoided: true, voidReason: reason }
    });
    if (onDeletePayment) {
      onDeletePayment(deletingPayment.id);
    }
    setDeletingPayment(null);
  };

  // Form State
  const [supplierId, setSupplierId] = useState(preselectedInvoice?.supplierId || '');
  const [invoiceId, setInvoiceId] = useState(preselectedInvoice?.id || '');
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [amount, setAmount] = useState<number>(preselectedInvoice?.dueAmount || 0);
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank Transfer' | 'Cheque' | 'LC Settlement'>('' as any);
  const [paidFromAccountId, setPaidFromAccountId] = useState<string>('');
  const [chequeNumber, setChequeNumber] = useState('');
  const [chequeDate, setChequeDate] = useState('');
  const [voucherNumber, setVoucherNumber] = useState(`DV-${Math.floor(1000 + Math.random() * 9000)}`);
  const [notes, setNotes] = useState('');
  const [adminApprovedOverdraft, setAdminApprovedOverdraft] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isSubmittingRef = React.useRef(false);
  const [pendingPaymentId, setPendingPaymentId] = useState(() => `sp-${Date.now()}`);

  // Filtered accounts based on paymentMethod using isCashAccount
  const filteredPaidFromAccounts = React.useMemo(() => {
    if (paymentMethod === 'Cash') {
      return bankAccounts.filter(acc => isCashAccount(acc));
    }
    if (paymentMethod === 'Bank Transfer' || paymentMethod === 'Cheque') {
      return bankAccounts.filter(acc => !isCashAccount(acc));
    }
    return bankAccounts;
  }, [bankAccounts, paymentMethod]);

  // Clear paidFromAccountId if it is no longer in available filtered accounts
  useEffect(() => {
    if (paidFromAccountId && !filteredPaidFromAccounts.some(a => a.id === paidFromAccountId)) {
      setPaidFromAccountId('');
    }
    setAdminApprovedOverdraft(false);
    setSubmitError(null);
  }, [filteredPaidFromAccounts, paymentMethod]);

  const selectedPaidFromAccount = React.useMemo(
    () => bankAccounts.find(a => a.id === paidFromAccountId),
    [bankAccounts, paidFromAccountId]
  );

  // When preselectedInvoice changes, update form
  React.useEffect(() => {
    if (preselectedInvoice) {
      setSupplierId(preselectedInvoice.supplierId);
      setInvoiceId(preselectedInvoice.id);
      setAmount(preselectedInvoice.dueAmount);
      setNotes('');
      setPendingPaymentId(`sp-${Date.now()}`);
      setSubmitError(null);
    }
  }, [preselectedInvoice]);

  const handleCloseModal = () => {
    if (isSubmittingRef.current) return;
    setSupplierId('');
    setInvoiceId('');
    setAmount(0);
    setPaymentMethod('' as any);
    setPaidFromAccountId('');
    setChequeNumber('');
    setChequeDate('');
    setNotes('');
    setAdminApprovedOverdraft(false);
    setSubmitError(null);
    setPendingPaymentId(`sp-${Date.now()}`);
    setShowCreateModalInternal(false);
    if (onCloseCreateModal) onCloseCreateModal();
  };

  const isPaymentDirty = Boolean(supplierId || amount > 0 || invoiceId !== '' || notes.trim() !== '');

  // Find supplier unpaid invoices
  const supplierUnpaidInvoices = invoices.filter(
    inv => inv.supplierId === supplierId && inv.dueAmount > 0 && !inv.isVoided && inv.status !== 'Voided'
  );

  // Handle Supplier Selection
  const handleSupplierChange = (newSuppId: string) => {
    setSupplierId(newSuppId);
    setInvoiceId('');
    setAmount(0);
  };

  // Handle Invoice Selection
  const handleInvoiceChange = (newInvId: string) => {
    setInvoiceId(newInvId);
    if (newInvId === '') {
      setAmount(0);
    } else {
      const inv = invoices.find(i => i.id === newInvId);
      if (inv) {
        setAmount(inv.dueAmount);
        setNotes(`Payment for purchase invoice ${inv.invoiceNumber}`);
      }
    }
  };

  // Submit Payment (Flow B: calls postVoucher atomically with idempotency and overdraft rules)
  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingRef.current) return;
    setSubmitError(null);

    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) {
      setSubmitError('Payment amount must be greater than 0.');
      return;
    }

    const requiresPaidFrom =
      paymentMethod === 'Cash' || paymentMethod === 'Bank Transfer' || paymentMethod === 'Cheque';

    if (requiresPaidFrom && !paidFromAccountId) {
      setSubmitError('Please select a "Paid From" Cash or Bank account.');
      return;
    }

    const accountObj = bankAccounts.find(a => a.id === paidFromAccountId);
    if (requiresPaidFrom && !accountObj) {
      setSubmitError('Selected "Paid From" account was not found.');
      return;
    }

    if (accountObj) {
      const currentBal = Number(accountObj.ledgerBalance) || 0;
      const projectedBal = currentBal - numericAmount;
      const isCash = isCashAccount(accountObj);

      if (isCash && projectedBal < 0) {
        setSubmitError(
          `Insufficient Cash balance in ${accountObj.bankName}. Current balance: BDT ${currentBal.toLocaleString()}, required: BDT ${numericAmount.toLocaleString()}. Cash accounts cannot go negative.`
        );
        return;
      }

      if (!isCash && projectedBal < 0 && !(isAdmin && adminApprovedOverdraft)) {
        setSubmitError(
          isAdmin
            ? `Bank balance in ${accountObj.bankName} (BDT ${currentBal.toLocaleString()}) is less than payment amount. Please check "Admin Overdraft Approval" below to proceed.`
            : `Insufficient Bank balance in ${accountObj.bankName} (BDT ${currentBal.toLocaleString()}). Bank overdraft requires Administrator approval.`
        );
        return;
      }
    }

    const supp = suppliers.find(s => s.id === supplierId);
    if (!supp) {
      setSubmitError('Please select a valid supplier.');
      return;
    }

    const inv = invoices.find(i => i.id === invoiceId);
    if (inv && numericAmount > inv.dueAmount) {
      setSubmitError(`Payment amount (BDT ${numericAmount.toLocaleString()}) exceeds invoice due amount (BDT ${inv.dueAmount.toLocaleString()}).`);
      return;
    }

    isSubmittingRef.current = true;
    setIsSubmitting(true);

    try {
      const mappedMethod =
        paymentMethod === 'Cash'
          ? 'Cash'
          : paymentMethod === 'Cheque'
            ? 'Cheque'
            : 'Bank Transfer';

      const refStr = inv
        ? inv.invoiceNumber
        : chequeNumber.trim() || voucherNumber.trim() || undefined;

      const postedTxn = await postVoucher({
        transactionType: 'PAYMENT',
        subType: 'Pay to Supplier',
        date: paymentDate,
        amount: numericAmount,
        partyType: 'Supplier',
        partyId: supp.id,
        partyName: supp.name,
        partyCode: supp.code,
        partyPhone: supp.phone,
        bankAccountId: accountObj ? accountObj.id : undefined,
        paymentMethod: mappedMethod,
        referenceNo: refStr,
        note: `${notes.trim()}${inv ? ` (Invoice: ${inv.invoiceNumber})` : ''}`,
        branch: currentUser?.branch || 'Corporate Headquarters',
        user: {
          uid: currentUser?.id || 'usr-admin',
          name: currentUser?.name || 'Accounts Dept',
          email: currentUser?.email
        },
        adminApprovedOverdraft: isAdmin && adminApprovedOverdraft,
        idempotencyKey: `sp-pay-${pendingPaymentId}`
      });

      const newPayment: SupplierPaymentRecord = {
        id: pendingPaymentId,
        paymentNumber: `SP-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        paymentDate: paymentDate,
        supplierId: supp.id,
        supplierName: supp.name,
        invoiceId: inv ? inv.id : undefined,
        invoiceNumber: inv ? inv.invoiceNumber : undefined,
        amount: numericAmount,
        paymentMethod: paymentMethod,
        bankAccountId: accountObj?.id,
        bankName: accountObj ? `${accountObj.bankName} (${accountObj.accountNumber})` : undefined,
        chequeNumber: paymentMethod === 'Cheque' ? chequeNumber : undefined,
        chequeDate: paymentMethod === 'Cheque' ? chequeDate : undefined,
        voucherId: postedTxn.id,
        voucherNumber: postedTxn.voucherNo,
        notes: notes.trim(),
        status: 'Cleared',
        branch: currentUser?.branch || 'Corporate Headquarters',
        recordedBy: currentUser?.name || 'Accounts Dept'
      };

      onRecordNewPayment(newPayment);
      isSubmittingRef.current = false;
      setIsSubmitting(false);
      handleCloseModal();
    } catch (err: any) {
      isSubmittingRef.current = false;
      setIsSubmitting(false);
      setSubmitError(err?.message || 'Failed to post supplier payment voucher.');
    }
  };

  // Date filtering logic
  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.substring(0, 7);

  // Filtered Payments
  const filteredPayments = payments.filter(p => {
    const matchesSearch = 
      p.paymentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.invoiceNumber && p.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.voucherNumber && p.voucherNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.chequeNumber && p.chequeNumber.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesMethod = methodFilter === 'ALL' || p.paymentMethod === methodFilter;
    const matchesSupplier = supplierFilter === 'ALL' || p.supplierId === supplierFilter || p.supplierName === supplierFilter;

    let matchesDate = true;
    if (dateFilter === 'TODAY') {
      matchesDate = p.paymentDate === todayStr;
    } else if (dateFilter === 'THIS_MONTH') {
      matchesDate = p.paymentDate.startsWith(currentMonthStr);
    }

    return matchesSearch && matchesMethod && matchesSupplier && matchesDate;
  });

  const totalPaidAmount = filteredPayments.reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="space-y-4">
      {/* Top KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Total Supplier Payments</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-black text-slate-900 font-mono">
            BDT {totalPaidAmount.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {filteredPayments.length} Payment Records
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Bank & TT Transfers</span>
            <Building2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-black text-blue-700 font-mono">
            BDT {payments.filter(p => p.paymentMethod === 'Bank Transfer').reduce((s, p) => s + p.amount, 0).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {payments.filter(p => p.paymentMethod === 'Bank Transfer').length} Bank Transactions
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Cheque Payments</span>
            <Receipt className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-xl font-black text-indigo-700 font-mono">
            BDT {payments.filter(p => p.paymentMethod === 'Cheque').reduce((s, p) => s + p.amount, 0).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {payments.filter(p => p.paymentMethod === 'Cheque').length} Cheques Issued
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Cash Settlements</span>
            <CreditCard className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-black text-amber-700 font-mono">
            BDT {payments.filter(p => p.paymentMethod === 'Cash').reduce((s, p) => s + p.amount, 0).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Spot & Clearing Cash Payments
          </div>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        {/* Controls & Quick Filter Strip */}
        <div className="p-4 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2 flex-1">
            {/* Search */}
            <div className="relative min-w-[240px] max-w-sm flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search voucher no, supplier, invoice or cheque..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
              />
            </div>

            {/* Date Quick Tabs */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              <button
                type="button"
                onClick={() => setDateFilter('ALL')}
                className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                  dateFilter === 'ALL' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Dates ({payments.length})
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('TODAY')}
                className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                  dateFilter === 'TODAY' ? 'bg-white text-emerald-800 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Today's Payments
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('THIS_MONTH')}
                className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                  dateFilter === 'THIS_MONTH' ? 'bg-white text-emerald-800 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                This Month
              </button>
            </div>

            {/* Supplier Filter */}
            <select
              value={supplierFilter}
              onChange={(e) => setSupplierFilter(e.target.value)}
              className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none font-medium text-slate-700 max-w-[170px]"
            >
              <option value="ALL">All Suppliers</option>
              {suppliers.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>

            {/* Payment Method Filter */}
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value)}
              className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none font-medium text-slate-700"
            >
              <option value="ALL">All Methods</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cheque">Cheque</option>
              <option value="Cash">Cash</option>
              <option value="LC Settlement">LC Settlement</option>
            </select>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => window.print()}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              title="Print All Payments Transaction Report"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>Print All</span>
            </button>

            <button
              type="button"
              onClick={() => setIsRecycleBinOpen(true)}
              className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
              title="Recycle Bin"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
              <span>Trash ({trashCount})</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setSupplierId('');
                setInvoiceId('');
                setAmount(0);
                setPaymentMethod('' as any);
                setPaidFromAccountId('');
                setChequeNumber('');
                setChequeDate('');
                setNotes('');
                setShowCreateModalInternal(true);
              }}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              New Supplier Payment
            </button>
          </div>
        </div>

        {/* Payments Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Payment No / Voucher</th>
                <th className="py-2.5 px-3">Payment Date</th>
                <th className="py-2.5 px-3">Supplier Name</th>
                <th className="py-2.5 px-3">Linked Invoice</th>
                <th className="py-2.5 px-3">Payment Method</th>
                <th className="py-2.5 px-3">Bank / Cheque Details</th>
                <th className="py-2.5 px-3 text-right">Amount Paid</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-3 text-right">Action / Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    No supplier payment records found. Click the button above to record a new payment.
                  </td>
                </tr>
              ) : (
                filteredPayments.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="font-mono font-bold text-emerald-800">{p.paymentNumber}</div>
                      {p.voucherNumber && (
                        <div className="text-[10px] text-slate-400 font-mono">Ref: {p.voucherNumber}</div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-slate-700 font-medium">
                      {p.paymentDate}
                    </td>
                    <td className="py-2.5 px-3">
                      <button
                        type="button"
                        onClick={() => onViewSupplierLedger && onViewSupplierLedger(p.supplierId)}
                        className="font-bold text-slate-900 hover:text-blue-600 hover:underline text-left cursor-pointer"
                      >
                        {p.supplierName}
                      </button>
                    </td>
                    <td className="py-2.5 px-3">
                      {p.invoiceNumber ? (
                        <button
                          type="button"
                          onClick={() => onViewInvoice && onViewInvoice(p.invoiceNumber!)}
                          className="font-mono text-blue-700 hover:underline font-semibold text-[11px]"
                        >
                          {p.invoiceNumber}
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">On-Account</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                        p.paymentMethod === 'Bank Transfer' ? 'bg-blue-50 text-blue-800 border-blue-200' :
                        p.paymentMethod === 'Cheque' ? 'bg-indigo-50 text-indigo-800 border-indigo-200' :
                        p.paymentMethod === 'Cash' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                        'bg-purple-50 text-purple-800 border-purple-200'
                      }`}>
                        {p.paymentMethod}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="text-[11px] text-slate-800 font-medium truncate max-w-[180px]">
                        {p.bankName || p.notes || '-'}
                      </div>
                      {p.chequeNumber && (
                        <div className="text-[10px] text-indigo-600 font-mono">
                          CQ: {p.chequeNumber} ({p.chequeDate})
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span className="font-mono font-bold text-sm text-emerald-700">
                        BDT {p.amount.toLocaleString()}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Cleared
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5 flex-wrap">
                        {onViewSupplierLedger && (
                          <button
                            type="button"
                            onClick={() => onViewSupplierLedger(p.supplierId)}
                            className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 transition-colors cursor-pointer"
                            title="View Supplier Ledger"
                          >
                            <FileText className="w-3 h-3 text-indigo-600" />
                            <span>Ledger</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => setEditingPayment(p)}
                          className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 transition-colors cursor-pointer"
                          title="Edit Payment Voucher"
                        >
                          <Edit className="w-3 h-3 text-blue-600" />
                          <span>Edit</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setSelectedVoucherForPrint(p)}
                          className="px-2 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 transition-colors cursor-pointer"
                          title="Print Payment Voucher"
                        >
                          <Printer className="w-3 h-3 text-slate-600" />
                          <span>Receipt</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeletingPayment(p)}
                          className="p-1 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer border border-transparent hover:border-rose-200"
                          title="Delete to Recycle Bin"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: New Supplier Payment */}
      {showCreateModal && (
        <ModalWrapper
          isOpen={showCreateModal}
          onClose={handleCloseModal}
          isDirty={isPaymentDirty}
          backdropClassName="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full p-5 space-y-4 border border-slate-200 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-xs">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">New Supplier Payment</h3>
                </div>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={handleCloseModal}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPayment} autoComplete="off" className="space-y-4 text-xs">
              {/* Supplier Selection */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Select Supplier *
                </label>
                <select
                  value={supplierId}
                  onChange={(e) => handleSupplierChange(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
                  required
                >
                  <option value="">-- Select Supplier --</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.country})
                    </option>
                  ))}
                </select>
              </div>

              {/* Linked Invoice Selection */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Linked Purchase Invoice
                </label>
                <select
                  value={invoiceId}
                  onChange={(e) => handleInvoiceChange(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-slate-800"
                >
                  <option value="">-- On-Account / Direct Supplier Ledger Posting --</option>
                  {supplierUnpaidInvoices.map(inv => (
                    <option key={inv.id} value={inv.id}>
                      {inv.invoiceNumber} | Date: {inv.invoiceDate} | Total: BDT {inv.grandTotal.toLocaleString()} | Due: BDT {inv.dueAmount.toLocaleString()}
                    </option>
                  ))}
                </select>
                {supplierUnpaidInvoices.length > 0 ? (
                  <p className="text-[10px] text-emerald-700 font-medium mt-1">
                    This supplier has {supplierUnpaidInvoices.length} unpaid invoice(s).
                  </p>
                ) : (
                  <p className="text-[10px] text-slate-400 mt-1">
                    No unpaid invoices found. Payment will be posted as on-account or advance.
                  </p>
                )}
              </div>

              {/* Payment Date & Amount */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Payment Date *
                  </label>
                  <input
                    type="date"
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none font-semibold text-slate-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Amount in BDT *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    value={amount || ''}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              {/* Payment Method */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                  Payment Method *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Bank Transfer', 'Cheque', 'Cash'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`p-2 rounded-xl text-xs font-bold border transition-all text-center ${
                        paymentMethod === method
                          ? 'bg-[#def645] text-slate-950 border-slate-900 shadow-xs'
                          : 'bg-slate-50 hover:bg-white text-slate-700 border-slate-200'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              {/* Paid From Account (Cash or Bank filtered by isCashAccount with Balance) */}
              {(paymentMethod === 'Cash' || paymentMethod === 'Bank Transfer' || paymentMethod === 'Cheque') && (
                <div className="space-y-3 p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[11px] font-bold text-slate-700">
                        Paid From ({paymentMethod === 'Cash' ? 'Cash Account' : 'Bank Account'}) <span className="text-rose-500">*</span>
                      </label>
                      {selectedPaidFromAccount && (
                        <span className={`text-[11px] font-mono font-bold ${
                          (selectedPaidFromAccount.ledgerBalance || 0) < amount ? 'text-rose-600' : 'text-emerald-700'
                        }`}>
                          Balance: BDT {(selectedPaidFromAccount.ledgerBalance || 0).toLocaleString()}
                        </span>
                      )}
                    </div>
                    <select
                      value={paidFromAccountId}
                      onChange={(e) => setPaidFromAccountId(e.target.value)}
                      required
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold outline-none text-slate-800 focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">-- Select {paymentMethod === 'Cash' ? 'Cash' : 'Bank'} Account --</option>
                      {filteredPaidFromAccounts.map(acc => (
                        <option key={acc.id} value={acc.id}>
                          {acc.bankName} ({acc.accountNumber}) — Bal: BDT {(acc.ledgerBalance || 0).toLocaleString()}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Overdraft warning / Admin approval for Bank accounts */}
                  {selectedPaidFromAccount && (selectedPaidFromAccount.ledgerBalance || 0) - amount < 0 && (
                    isCashAccount(selectedPaidFromAccount) ? (
                      <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-[11px] text-rose-800 font-semibold flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span>
                          Cash account balance cannot become negative (Shortfall: BDT {Math.abs((selectedPaidFromAccount.ledgerBalance || 0) - amount).toLocaleString()}).
                        </span>
                      </div>
                    ) : (
                      <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 space-y-1.5">
                        <div className="font-bold flex items-center gap-1.5">
                          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                          <span>
                            Bank Overdraft Warning: Post-payment balance will be -BDT {Math.abs((selectedPaidFromAccount.ledgerBalance || 0) - amount).toLocaleString()}
                          </span>
                        </div>
                        {isAdmin ? (
                          <label className="flex items-center gap-2 cursor-pointer font-semibold text-amber-950">
                            <input
                              type="checkbox"
                              checked={adminApprovedOverdraft}
                              onChange={(e) => setAdminApprovedOverdraft(e.target.checked)}
                              className="rounded border-amber-400 text-emerald-600 focus:ring-emerald-500"
                            />
                            <span>Admin Overdraft Approval: Authorize negative bank balance</span>
                          </label>
                        ) : (
                          <p className="text-rose-700 font-semibold">
                            Only an Administrator can approve a bank overdraft.
                          </p>
                        )}
                      </div>
                    )
                  )}

                  {paymentMethod === 'Cheque' && (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-1">
                          Cheque No.
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. CQ-991204"
                          value={chequeNumber}
                          onChange={(e) => setChequeNumber(e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-mono outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-1">
                          Cheque Date
                        </label>
                        <input
                          type="date"
                          value={chequeDate}
                          onChange={(e) => setChequeDate(e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold outline-none"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Debit Voucher Ref & Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Debit Voucher Ref (Auto-assigned on Post)
                  </label>
                  <input
                    type="text"
                    value={voucherNumber}
                    onChange={(e) => setVoucherNumber(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-semibold outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Notes / Memo
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Payment description..."
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                  />
                </div>
              </div>

              {submitError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{submitError}</span>
                </div>
              )}

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  disabled={isSubmitting}
                  data-modal-close="true"
                  onClick={handleCloseModal}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-300 text-white font-bold rounded-xl text-xs transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Posting Voucher...</span>
                    </>
                  ) : (
                    <span>✓ Post Payment</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </ModalWrapper>
      )}

      {/* Modal: Print Payment Voucher Receipt */}
      {selectedVoucherForPrint && (
        <ModalWrapper
          isOpen={!!selectedVoucherForPrint}
          onClose={() => setSelectedVoucherForPrint(null)}
          isDirty={false}
          backdropClassName="fixed inset-0 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in"
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-slate-200">
            {/* Slip Header */}
            <div className="text-center pb-3 border-b border-slate-200">
              <div className="text-base font-black text-slate-900 tracking-tight">STARLINE TRADING & EXIM</div>
              <div className="text-[11px] text-slate-500">Corporate Importer of Bhutan & Indian Stone Boulders</div>
              <div className="text-xs font-bold uppercase mt-2 bg-slate-100 text-slate-800 inline-block px-3 py-0.5 rounded-full">
                SUPPLIER DEBIT PAYMENT VOUCHER
              </div>
            </div>

            <div className="space-y-2.5 text-xs text-slate-700">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Voucher / Payment No:</span>
                <span className="font-mono font-bold text-slate-900">{selectedVoucherForPrint.paymentNumber}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Debit Voucher Ref:</span>
                <span className="font-mono font-semibold text-slate-800">{selectedVoucherForPrint.voucherNumber || '-'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Payment Date:</span>
                <span className="font-semibold text-slate-900">{selectedVoucherForPrint.paymentDate}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Paid To (Supplier):</span>
                <span className="font-bold text-slate-900">{selectedVoucherForPrint.supplierName}</span>
              </div>
              {selectedVoucherForPrint.invoiceNumber && (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Against Invoice:</span>
                  <span className="font-mono font-bold text-blue-700">{selectedVoucherForPrint.invoiceNumber}</span>
                </div>
              )}
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Payment Method:</span>
                <span className="font-semibold text-slate-900">{selectedVoucherForPrint.paymentMethod}</span>
              </div>
              {selectedVoucherForPrint.bankName && (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Bank / Channel:</span>
                  <span className="font-medium text-slate-800">{selectedVoucherForPrint.bankName}</span>
                </div>
              )}
              {selectedVoucherForPrint.chequeNumber && (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Cheque No & Date:</span>
                  <span className="font-mono font-bold text-indigo-700">{selectedVoucherForPrint.chequeNumber} ({selectedVoucherForPrint.chequeDate})</span>
                </div>
              )}
              <div className="flex justify-between py-2 border-t-2 border-slate-800 font-bold text-sm text-slate-900">
                <span>Total Amount Paid:</span>
                <span className="font-mono text-emerald-700">BDT {selectedVoucherForPrint.amount.toLocaleString()}</span>
              </div>
              {selectedVoucherForPrint.notes && (
                <div className="pt-1 text-[11px] text-slate-500 italic">
                  Remarks: {selectedVoucherForPrint.notes}
                </div>
              )}
            </div>

            {/* Signature Area */}
            <div className="grid grid-cols-2 gap-4 pt-6 text-[10px] text-center text-slate-500 border-t border-slate-100">
              <div className="border-t border-slate-300 pt-1">Prepared By (Accounts)</div>
              <div className="border-t border-slate-300 pt-1">Authorized Signatory / MD</div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setSelectedVoucherForPrint(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                Print Voucher
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* Edit Supplier Payment Modal */}
      {editingPayment && (
        <EditSupplierPaymentModal
          isOpen={!!editingPayment}
          payment={editingPayment}
          suppliers={suppliers}
          onClose={() => setEditingPayment(null)}
          onSave={(updated) => {
            if (onUpdatePayment) {
              onUpdatePayment(updated);
            }
            setEditingPayment(null);
          }}
        />
      )}

      {/* Delete Confirmation Modal with Soft Delete Notice */}
      {deletingPayment && (
        <DeleteConfirmModal
          isOpen={!!deletingPayment}
          title="Supplier Payment"
          referenceNumber={deletingPayment.voucherNumber || deletingPayment.paymentNumber}
          partyName={deletingPayment.supplierName}
          amount={deletingPayment.amount}
          onClose={() => setDeletingPayment(null)}
          onConfirm={handleConfirmDelete}
        />
      )}

      {/* Module Recycle Bin & Restore Hub */}
      <RecycleBinModal
        isOpen={isRecycleBinOpen}
        initialType="supplier_payment"
        onClose={() => setIsRecycleBinOpen(false)}
      />
    </div>
  );
};
