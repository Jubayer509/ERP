import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Search, 
  Calendar, 
  Receipt, 
  CreditCard, 
  FileText, 
  Plus, 
  Printer, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ChevronRight,
  Eye,
  MapPin,
  Phone,
  Landmark,
  Layers,
  ArrowDownLeft,
  ArrowUpRight,
  Edit3
} from 'lucide-react';
import { Supplier, DirectPurchaseInvoice, SupplierPaymentRecord, FiscalYear } from '../../types/erp';
import { useAuth } from '../../contexts/AuthContext';
import { 
  getFiscalYears, 
  getActiveFiscalYear, 
  formatFiscalYearDisplay, 
  subscribeFiscalYears 
} from '../../utils/fiscalYearStorage';
import { getAccountTransactions } from '../../services/accountService';
import { getCompanyProfile, subscribeCompanyProfile } from '../../utils/systemSettingsStorage';
import { ModalWrapper } from '../common/ModalWrapper';

interface SupplierKhataReportProps {
  suppliers: Supplier[];
  invoices: DirectPurchaseInvoice[];
  payments: SupplierPaymentRecord[];
  selectedSupplierId?: string;
  initialTab?: 'invoices' | 'payments' | 'ledger' | 'payables';
  onSelectSupplier?: (supplierId: string) => void;
  onOpenPaymentModal: (supplierId: string, preselectedInvoice?: DirectPurchaseInvoice) => void;
  onOpenNewInvoiceModal: (supplierId: string) => void;
  onOpenAddSupplierModal?: () => void;
  onEditSupplier?: (supplier: Supplier) => void;
}

export const SupplierKhataReport: React.FC<SupplierKhataReportProps> = ({
  suppliers,
  invoices,
  payments,
  selectedSupplierId,
  initialTab,
  onSelectSupplier,
  onOpenPaymentModal,
  onOpenNewInvoiceModal,
  onOpenAddSupplierModal,
  onEditSupplier
}) => {
  const { currentUser } = useAuth();
  const [activeSupplierId, setActiveSupplierId] = useState<string>(
    selectedSupplierId || suppliers[0]?.id || ''
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'invoices' | 'payments' | 'ledger' | 'payables'>(
    initialTab || 'ledger'
  );
  const [dateFilter, setDateFilter] = useState<'ALL' | 'THIS_MONTH' | 'LAST_30' | 'LAST_90'>('ALL');
  const [ledgerViewMode, setLedgerViewMode] = useState<'detail' | 'compact'>('detail');
  const [siteFilter, setSiteFilter] = useState<string>('ALL');
  const [userFilter, setUserFilter] = useState<string>('ALL');
  const [viewInvoiceSlip, setViewInvoiceSlip] = useState<DirectPurchaseInvoice | null>(null);
  const [printLedgerModal, setPrintLedgerModal] = useState(false);

  // Fiscal Year System Integration
  const [fiscalYears, setFiscalYears] = useState<FiscalYear[]>(() => getFiscalYears());
  const [selectedFYId, setSelectedFYId] = useState<string>(() => getActiveFiscalYear().id);
  const [companyProfile, setCompanyProfile] = useState(() => getCompanyProfile());

  React.useEffect(() => {
    const unsub = subscribeFiscalYears((updated) => {
      setFiscalYears(updated);
    });
    const unsubComp = subscribeCompanyProfile(setCompanyProfile);
    return () => {
      unsub();
      unsubComp();
    };
  }, []);

  const selectedFY = useMemo(() => {
    return fiscalYears.find(f => f.id === selectedFYId) || getActiveFiscalYear();
  }, [fiscalYears, selectedFYId]);

  // Sync if selectedSupplierId or initialTab changes from outside
  React.useEffect(() => {
    if (selectedSupplierId) {
      setActiveSupplierId(selectedSupplierId);
    }
  }, [selectedSupplierId]);

  React.useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const handleSelectSupplier = (id: string) => {
    setActiveSupplierId(id);
    if (onSelectSupplier) onSelectSupplier(id);
  };

  const currentSupplier = useMemo(() => {
    return suppliers.find(s => s.id === activeSupplierId) || suppliers[0];
  }, [suppliers, activeSupplierId]);

  // Today & Month strings
  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.substring(0, 7);

  // Filter invoices for current supplier
  const supplierInvoices = useMemo(() => {
    if (!currentSupplier) return [];
    return invoices.filter(inv => {
      if (inv.supplierId !== currentSupplier.id && inv.supplierName !== currentSupplier.name) return false;
      if (dateFilter === 'THIS_MONTH') return inv.invoiceDate.startsWith(currentMonthStr);
      if (dateFilter === 'LAST_30') {
        const d = new Date();
        d.setDate(d.getDate() - 30);
        return inv.invoiceDate >= d.toISOString().split('T')[0];
      }
      if (dateFilter === 'LAST_90') {
        const d = new Date();
        d.setDate(d.getDate() - 90);
        return inv.invoiceDate >= d.toISOString().split('T')[0];
      }
      return true;
    }).sort((a, b) => new Date(b.invoiceDate).getTime() - new Date(a.invoiceDate).getTime());
  }, [invoices, currentSupplier, dateFilter, currentMonthStr]);

  // Filter payments for current supplier
  const supplierPayments = useMemo(() => {
    if (!currentSupplier) return [];
    return payments.filter(p => {
      if (p.supplierId !== currentSupplier.id && p.supplierName !== currentSupplier.name) return false;
      if (dateFilter === 'THIS_MONTH') return p.paymentDate.startsWith(currentMonthStr);
      if (dateFilter === 'LAST_30') {
        const d = new Date();
        d.setDate(d.getDate() - 30);
        return p.paymentDate >= d.toISOString().split('T')[0];
      }
      if (dateFilter === 'LAST_90') {
        const d = new Date();
        d.setDate(d.getDate() - 90);
        return p.paymentDate >= d.toISOString().split('T')[0];
      }
      return true;
    }).sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
  }, [payments, currentSupplier, dateFilter, currentMonthStr]);

  // Unified Chronological Ledger with Rich Itemized Breakdown (Parity with Jubayer Overseas Reference)
  const ledgerEntries = useMemo(() => {
    if (!currentSupplier) return [];

    const entries: {
      id: string;
      date: string;
      type: 'Invoice' | 'Payment';
      refNo: string;
      memoNo?: string;
      purchaser?: string;
      site?: string;
      description: string;
      debit: number; // Purchase creates payable obligation
      credit: number; // Payment made reduces payable
      items?: {
        itemName: string;
        quantity: number;
        uom: string;
        unitPrice: number;
        total: number;
      }[];
      shippingCost?: number;
      discountAmount?: number;
      taxVatAmount?: number;
      paymentMethod?: string;
      bankName?: string;
      chequeNumber?: string;
      chequeDate?: string;
      truckNo?: string;
      rawItem?: any;
    }[] = [];

    // Invoices add to payable
    supplierInvoices.forEach(inv => {
      const site = inv.warehouseName?.includes('Burimari') 
        ? 'Burimari' 
        : inv.warehouseName?.includes('Sonahat') 
          ? 'Sonahat' 
          : (inv.branch || 'Burimari');

      const itemsList = (inv.items && inv.items.length > 0)
        ? inv.items.map(i => ({
            itemName: i.itemName,
            quantity: i.quantity,
            uom: i.uom || 'CFT',
            unitPrice: i.unitPrice,
            total: i.totalPrice || Math.round(i.quantity * i.unitPrice)
          }))
        : [
            {
              itemName: 'Boulder / Crushed Stone',
              quantity: 100,
              uom: 'CFT',
              unitPrice: Math.round(inv.grandTotal / 100),
              total: inv.grandTotal
            }
          ];

      entries.push({
        id: `inv-${inv.id}`,
        date: inv.invoiceDate,
        type: 'Invoice',
        refNo: inv.invoiceNumber,
        memoNo: inv.challanNumber ? `memo ${inv.challanNumber.replace('CH-', '')}` : (inv.supplierBillNumber ? `bill ${inv.supplierBillNumber}` : 'memo 49'),
        purchaser: inv.createdBy || 'jubayer',
        site: site,
        description: `Purchase Invoice: ${itemsList.map(i => i.itemName).join(', ')}`,
        items: itemsList,
        shippingCost: 0,
        discountAmount: inv.discountAmount || 0,
        taxVatAmount: inv.taxVatAmount || 0,
        truckNo: inv.truckNo,
        debit: inv.grandTotal,
        credit: 0,
        rawItem: inv
      });
    });

    // Payments reduce payable
    supplierPayments.forEach(pay => {
      entries.push({
        id: `pay-${pay.id}`,
        date: pay.paymentDate,
        type: 'Payment',
        refNo: pay.voucherNumber || pay.paymentNumber,
        purchaser: pay.recordedBy || 'jubayer',
        site: pay.paymentMethod === 'Cash' ? 'Burimari Cash' : (pay.bankName || 'Eastern Bank PLC'),
        description: `Supplier Payment: ${pay.paymentMethod}${pay.bankName ? ` (${pay.bankName})` : ''}`,
        paymentMethod: pay.paymentMethod,
        bankName: pay.bankName,
        chequeNumber: pay.chequeNumber,
        chequeDate: pay.chequeDate,
        debit: 0,
        credit: pay.amount,
        rawItem: pay
      });
    });

    // Dynamic Account Transactions (Payments & Deposits) for this Supplier
    const allAccountTxns = getAccountTransactions();
    allAccountTxns
      .filter(t => (t.partyId === currentSupplier.id || t.partyName === currentSupplier.name) && t.status === 'active')
      .forEach(t => {
        const isPayment = t.transactionType === 'PAYMENT';
        entries.push({
          id: `acc-tx-${t.id}`,
          date: t.date,
          type: 'Payment',
          refNo: t.voucherNo,
          purchaser: t.createdBy?.name || 'Accounts Desk',
          site: t.branch || 'Burimari',
          description: `${t.subType}: ${t.note || t.paymentMethod} (Voucher: ${t.voucherNo})`,
          paymentMethod: t.paymentMethod,
          bankName: t.bankAccountName,
          chequeNumber: t.referenceNo,
          debit: isPayment ? 0 : t.amount, // If deposit from supplier (refund), debit
          credit: isPayment ? t.amount : 0, // If payment to supplier, credit (reduces payable)
          rawItem: t
        });
      });

    // Sort chronologically ascending
    entries.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Filter by site and user if set
    const filteredEntries = entries.filter(entry => {
      if (siteFilter !== 'ALL') {
        const s = (entry.site || '').toLowerCase();
        if (!s.includes(siteFilter.toLowerCase())) return false;
      }
      if (userFilter !== 'ALL') {
        const u = (entry.purchaser || '').toLowerCase();
        if (!u.includes(userFilter.toLowerCase())) return false;
      }
      return true;
    });

    // Calculate running balance
    let runningBalance = currentSupplier.openingBalance || 0;
    return filteredEntries.map(entry => {
      runningBalance = runningBalance + entry.debit - entry.credit;
      return {
        ...entry,
        runningBalance
      };
    });
  }, [supplierInvoices, supplierPayments, currentSupplier, siteFilter, userFilter]);

  // Aging buckets calculation across all purchase invoices (Accounts Payable Parity)
  const agingStats = useMemo(() => {
    const today = new Date().getTime();
    let current_0_30 = 0;
    let days_31_60 = 0;
    let days_61_90 = 0;
    let days_90_plus = 0;

    invoices.filter(i => (i.dueAmount || 0) > 0).forEach(inv => {
      const invTime = new Date(inv.invoiceDate).getTime();
      const diffDays = Math.max(0, Math.floor((today - invTime) / (1000 * 60 * 60 * 24)));

      if (diffDays <= 30) {
        current_0_30 += inv.dueAmount;
      } else if (diffDays <= 60) {
        days_31_60 += inv.dueAmount;
      } else if (diffDays <= 90) {
        days_61_90 += inv.dueAmount;
      } else {
        days_90_plus += inv.dueAmount;
      }
    });

    return {
      current_0_30,
      days_31_60,
      days_61_90,
      days_90_plus,
      totalDue: current_0_30 + days_31_60 + days_61_90 + days_90_plus
    };
  }, [invoices]);

  // All unpaid invoices across all suppliers for Payables list
  const allUnpaidInvoices = useMemo(() => {
    return invoices
      .filter(i => (i.dueAmount || 0) > 0)
      .sort((a, b) => new Date(a.invoiceDate).getTime() - new Date(b.invoiceDate).getTime());
  }, [invoices]);

  const availableSupplierSites = useMemo(() => {
    const s = new Set<string>();
    invoices.forEach(i => {
      if (i.warehouseName?.includes('Burimari')) s.add('Burimari');
      else if (i.warehouseName?.includes('Sonahat')) s.add('Sonahat');
      else if (i.branch) s.add(i.branch);
    });
    s.add('Burimari');
    s.add('Sonahat');
    return Array.from(s);
  }, [invoices]);

  const availableSupplierUsers = useMemo(() => {
    const u = new Set<string>();
    invoices.forEach(i => {
      if (i.createdBy) u.add(i.createdBy);
    });
    payments.forEach(p => {
      if (p.recordedBy) u.add(p.recordedBy);
    });
    u.add('jubayer');
    u.add('admin');
    return Array.from(u);
  }, [invoices, payments]);

  const currentDateTimeFormatted = useMemo(() => {
    const d = new Date();
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  }, []);

  // Format date helper DD/MM/YYYY
  const formatDateSlash = (dStr: string) => {
    if (!dStr) return '';
    const parts = dStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dStr;
  };

  // Convert number to words in Taka
  function numberToWords(num: number): string {
    if (num <= 0) return 'Zero Taka Only';
    const units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 
      'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

    function convertBelowThousand(n: number): string {
      let str = '';
      if (n >= 100) {
        str += units[Math.floor(n / 100)] + ' Hundred ';
        n %= 100;
      }
      if (n >= 20) {
        str += tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + units[n % 10] : '');
      } else if (n > 0) {
        str += units[n];
      }
      return str.trim();
    }

    let rounded = Math.round(num);
    let crore = Math.floor(rounded / 10000000);
    let remainder = rounded % 10000000;
    let lakh = Math.floor(remainder / 100000);
    remainder %= 100000;
    let thousand = Math.floor(remainder / 1000);
    let rest = remainder % 1000;

    let words = '';
    if (crore > 0) words += convertBelowThousand(crore) + ' Crore ';
    if (lakh > 0) words += convertBelowThousand(lakh) + ' Lakh ';
    if (thousand > 0) words += convertBelowThousand(thousand) + ' Thousand ';
    if (rest > 0) words += convertBelowThousand(rest);

    return (words.trim() + ' Taka Only');
  }

  // Aggregate metrics for selected supplier
  const totalInvoicedAmt = supplierInvoices.reduce((sum, i) => sum + i.grandTotal, 0);
  const totalPaidAmt = supplierPayments.reduce((sum, p) => sum + p.amount, 0);
  const totalDueAmt = supplierInvoices.reduce((sum, i) => sum + i.dueAmount, 0);
  const pendingInvoicesCount = supplierInvoices.filter(i => i.dueAmount > 0).length;

  // Filtered suppliers list for left selector
  const filteredSuppliersList = suppliers.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.country.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                <FileText className="w-5 h-5" />
              </span>
              <div>
                <h2 className="text-base md:text-lg font-bold text-slate-900">
                  Supplier Ledger, Invoices & Payables Statement
                </h2>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {onOpenAddSupplierModal && (
              <button
                type="button"
                onClick={onOpenAddSupplierModal}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-emerald-400" />
                <span>+ Add Supplier</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => onOpenNewInvoiceModal(currentSupplier?.id || '')}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ New Invoice</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenPaymentModal(currentSupplier?.id || '')}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>+ Pay Supplier</span>
            </button>
            <button
              type="button"
              onClick={() => setPrintLedgerModal(true)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Ledger</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Supplier Picker & Right Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Column: Supplier Directory Selector */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-3 shadow-xs space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-700">Select Supplier</span>
            <div className="flex items-center gap-1.5">
              {onOpenAddSupplierModal && (
                <button
                  type="button"
                  onClick={onOpenAddSupplierModal}
                  className="px-2 py-0.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer shadow-2xs"
                  title="Add New Supplier"
                >
                  <Plus className="w-2.5 h-2.5 text-emerald-400" />
                  <span>+ Add</span>
                </button>
              )}
              <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full font-bold">
                {suppliers.length}
              </span>
            </div>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search supplier, code, country..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="space-y-1.5 max-h-[580px] overflow-y-auto pr-1">
            {filteredSuppliersList.map((supp) => {
              const isSelected = supp.id === activeSupplierId;
              const suppInvoices = invoices.filter(i => i.supplierId === supp.id || i.supplierName === supp.name);
              const suppDue = suppInvoices.reduce((s, i) => s + i.dueAmount, 0);

              return (
                <button
                  key={supp.id}
                  type="button"
                  onClick={() => handleSelectSupplier(supp.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer flex flex-col gap-1.5 ${
                    isSelected
                      ? 'bg-indigo-50/70 border-indigo-300 shadow-2xs'
                      : 'bg-white hover:bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1">
                    <span className="font-bold text-xs text-slate-900 leading-tight">
                      {supp.name}
                    </span>
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 shrink-0">
                      {supp.country === 'Bangladesh' ? '🇧🇩 BD' : supp.country === 'Bhutan' ? '🇧🇹 BT' : supp.country === 'India' ? '🇮🇳 IN' : '🌐'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <span>{supp.code} • {supp.category}</span>
                    <span className={`font-mono font-bold ${suppDue > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                      {suppDue > 0 ? `Due: BDT ${suppDue.toLocaleString()}` : 'All Paid'}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Supplier Khata Details & Invoices */}
        <div className="lg:col-span-8 space-y-4">
          {/* Current Supplier Summary Header */}
          {currentSupplier && (
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-black text-slate-900">{currentSupplier.name}</h3>
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-md">
                      {currentSupplier.category}
                    </span>
                    {onEditSupplier && (
                      <button
                        type="button"
                        onClick={() => onEditSupplier(currentSupplier)}
                        className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 border border-slate-200 rounded-md transition-colors cursor-pointer"
                        title="Edit Supplier Profile"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>Edit Profile</span>
                      </button>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-1 flex-wrap">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {currentSupplier.city}, {currentSupplier.country}
                    </span>
                    <span className="flex items-center gap-1">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      {currentSupplier.phone || 'N/A'}
                    </span>
                    <span className="font-mono text-[11px]">
                      Terms: {currentSupplier.paymentTerms}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[11px] text-slate-400 block font-semibold">Total Outstanding Due</span>
                  <span className={`text-lg font-black font-mono ${totalDueAmt > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                    BDT {totalDueAmt.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* 4 Metric Stats Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-3">
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Total Invoiced</span>
                  <div className="text-sm sm:text-base font-black font-mono text-slate-900 mt-0.5">
                    BDT {totalInvoicedAmt.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-slate-400">{supplierInvoices.length} Invoices</span>
                </div>

                <div className="p-2.5 bg-emerald-50/60 rounded-xl border border-emerald-200">
                  <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">Total Paid</span>
                  <div className="text-sm sm:text-base font-black font-mono text-emerald-700 mt-0.5">
                    BDT {totalPaidAmt.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-emerald-600">{supplierPayments.length} Payment Receipts</span>
                </div>

                <div className="p-2.5 bg-rose-50/60 rounded-xl border border-rose-200">
                  <span className="text-[10px] font-bold text-rose-800 uppercase tracking-wider block">Pending Due</span>
                  <div className="text-sm sm:text-base font-black font-mono text-rose-700 mt-0.5">
                    BDT {totalDueAmt.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-rose-600">{pendingInvoicesCount} Pending Invoices</span>
                </div>

                <div className="p-2.5 bg-blue-50/60 rounded-xl border border-blue-200">
                  <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider block">Payment Ratio</span>
                  <div className="text-sm sm:text-base font-black font-mono text-blue-800 mt-0.5">
                    {totalInvoicedAmt > 0 ? Math.round((totalPaidAmt / totalInvoicedAmt) * 100) : 100}%
                  </div>
                  <span className="text-[10px] text-blue-600">Settled vs Invoiced</span>
                </div>
              </div>
            </div>
          )}

          {/* Sub-Tabs & Date Filter Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-2.5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            {/* View Mode Tabs */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveTab('invoices')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'invoices'
                    ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Purchase Invoices ({supplierInvoices.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('payments')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'payments'
                    ? 'bg-white text-emerald-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>Payments Register ({supplierPayments.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('ledger')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'ledger'
                    ? 'bg-white text-slate-900 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Account Ledger / Statement</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('payables')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'payables'
                    ? 'bg-white text-rose-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <DollarSign className="w-3.5 h-3.5" />
                <span>Payables & Aging</span>
              </button>
            </div>

            {/* Date Range Quick Filter */}
            <div className="flex items-center gap-1 text-[11px] font-medium">
              <span className="text-slate-400 mr-1">Date:</span>
              <button
                type="button"
                onClick={() => setDateFilter('ALL')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  dateFilter === 'ALL' ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-200' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('THIS_MONTH')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  dateFilter === 'THIS_MONTH' ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-200' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                This Month
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('LAST_30')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  dateFilter === 'LAST_30' ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-200' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                30 Days
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('LAST_90')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  dateFilter === 'LAST_90' ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-200' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                90 Days
              </button>
            </div>
          </div>

          {/* TAB 1: Invoices View */}
          {activeTab === 'invoices' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  All Purchase Invoices for {currentSupplier?.name} ({supplierInvoices.length} Invoices)
                </span>
                <button
                  type="button"
                  onClick={() => onOpenNewInvoiceModal(currentSupplier?.id || '')}
                  className="text-xs font-bold text-indigo-700 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Add New Invoice</span>
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Invoice # & Challan</th>
                      <th className="py-2.5 px-3">Date & Due</th>
                      <th className="py-2.5 px-3">Items & Qty</th>
                      <th className="py-2.5 px-3 text-right">Total (BDT)</th>
                      <th className="py-2.5 px-3 text-right">Paid (BDT)</th>
                      <th className="py-2.5 px-3 text-right">Due Balance</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                      <th className="py-2.5 px-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {supplierInvoices.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-slate-400">
                          <Receipt className="w-7 h-7 mx-auto text-slate-300 mb-1" />
                          <p className="font-semibold text-slate-600">No purchase invoices found for this supplier</p>
                          <p className="text-[11px] text-slate-400">Click the button above to create a new invoice.</p>
                        </td>
                      </tr>
                    ) : (
                      supplierInvoices.map((inv) => (
                        <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-2.5 px-3">
                            <span className="font-mono font-bold text-indigo-700 block">{inv.invoiceNumber}</span>
                            <span className="text-[10px] text-slate-400 font-mono">Challan: {inv.challanNumber}</span>
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="font-medium text-slate-800 block">{inv.invoiceDate}</span>
                            <span className="text-[10px] text-slate-400">Due: {inv.dueDate}</span>
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="font-semibold text-slate-900 block truncate max-w-[170px]">
                              {inv.items?.[0]?.itemName}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {inv.items?.[0]?.quantity} {inv.items?.[0]?.uom || 'MT'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                            {inv.grandTotal.toLocaleString()}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-emerald-600 font-semibold">
                            {inv.paidAmount.toLocaleString()}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold">
                            {inv.dueAmount > 0 ? (
                              <span className="text-rose-600">{inv.dueAmount.toLocaleString()}</span>
                            ) : (
                              <span className="text-emerald-600">0</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              inv.paymentStatus === 'Paid'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                                : inv.paymentStatus === 'Partial'
                                  ? 'bg-amber-50 text-amber-700 border-amber-300'
                                  : 'bg-rose-50 text-rose-700 border-rose-300'
                            }`}>
                              {inv.paymentStatus === 'Paid' ? 'Paid' : inv.paymentStatus === 'Partial' ? 'Partial' : 'Unpaid'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {inv.dueAmount > 0 && (
                                <button
                                  type="button"
                                  onClick={() => onOpenPaymentModal(currentSupplier?.id || '', inv)}
                                  className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-md text-[11px] font-bold border border-emerald-200 transition-colors flex items-center gap-1 cursor-pointer"
                                  title="Pay outstanding bill"
                                >
                                  <CreditCard className="w-3 h-3 text-emerald-600" />
                                  <span>Pay</span>
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => setViewInvoiceSlip(inv)}
                                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-[11px] font-bold transition-colors cursor-pointer"
                                title="View Slip"
                              >
                                <Eye className="w-3 h-3 text-slate-600" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: Payments Register View */}
          {activeTab === 'payments' && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  Payments Made to {currentSupplier?.name} ({supplierPayments.length} Payments)
                </span>
                <button
                  type="button"
                  onClick={() => onOpenPaymentModal(currentSupplier?.id || '')}
                  className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Record New Payment</span>
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Voucher # & Ref</th>
                      <th className="py-2.5 px-3">Payment Date</th>
                      <th className="py-2.5 px-3">Payment Method</th>
                      <th className="py-2.5 px-3">Linked Invoice</th>
                      <th className="py-2.5 px-3 text-right">Amount Paid (BDT)</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {supplierPayments.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-slate-400">
                          <CreditCard className="w-7 h-7 mx-auto text-slate-300 mb-1" />
                          <p className="font-semibold text-slate-600">No payment records found</p>
                        </td>
                      </tr>
                    ) : (
                      supplierPayments.map((pay) => (
                        <tr key={pay.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-800">
                            {pay.voucherNumber || pay.paymentNumber}
                          </td>
                          <td className="py-2.5 px-3 text-slate-700">{pay.paymentDate}</td>
                          <td className="py-2.5 px-3">
                            <span className="font-medium text-slate-900 block">{pay.paymentMethod}</span>
                            {pay.bankName && (
                              <span className="text-[10px] text-slate-400 block">{pay.bankName}</span>
                            )}
                            {pay.chequeNumber && (
                              <span className="text-[10px] text-indigo-600 font-mono block">Chq: {pay.chequeNumber}</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-indigo-700">
                            {pay.invoiceNumber || 'On Account / General Khata'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                            BDT {pay.amount.toLocaleString()}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                              {pay.status || 'Cleared'}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: Account Ledger / Statement View (Jubayer Overseas Reference Parity) */}
          {activeTab === 'ledger' && (
            <div className="space-y-4">
              {/* Header Controls & Filter Bar */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-indigo-600" />
                    <span>Supplier Detail Transaction Statement</span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-mono px-2 py-0.5 rounded-full font-bold">
                      Standard Format
                    </span>
                  </h3>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* View Mode Toggle */}
                  <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
                    <button
                      type="button"
                      onClick={() => setLedgerViewMode('detail')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                        ledgerViewMode === 'detail'
                          ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Layers className="w-3.5 h-3.5" />
                      <span>Detail View</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setLedgerViewMode('compact')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                        ledgerViewMode === 'compact'
                          ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Landmark className="w-3.5 h-3.5" />
                      <span>Compact Table</span>
                    </button>
                  </div>

                  {/* Fiscal Year (FY) Filter */}
                  <select
                    value={selectedFYId}
                    onChange={(e) => setSelectedFYId(e.target.value)}
                    className="p-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:bg-white outline-none"
                    title="Filter by Fiscal Year (FY)"
                  >
                    {fiscalYears.map(fy => (
                      <option key={fy.id} value={fy.id}>
                        {fy.name} ({fy.status})
                      </option>
                    ))}
                  </select>

                  {/* Site Filter */}
                  <select
                    value={siteFilter}
                    onChange={(e) => setSiteFilter(e.target.value)}
                    className="p-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:bg-white outline-none"
                    title="Filter by Loading/Receiving Site"
                  >
                    <option value="ALL">All Sites</option>
                    {availableSupplierSites.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>

                  {/* Purchaser / User Filter */}
                  <select
                    value={userFilter}
                    onChange={(e) => setUserFilter(e.target.value)}
                    className="p-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:bg-white outline-none"
                    title="Filter by User / Officer"
                  >
                    <option value="ALL">All Users</option>
                    {availableSupplierUsers.map(u => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>

                  <button
                    type="button"
                    onClick={() => setPrintLedgerModal(true)}
                    className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Statement</span>
                  </button>
                </div>
              </div>

              {/* Master Detail Transaction Sheet */}
              {ledgerViewMode === 'detail' ? (
                <div className="bg-white border border-slate-300 rounded-2xl shadow-xs p-6 sm:p-8 text-slate-900">
                  {/* Document Header (Dynamic Corporate Enterprise Layout) */}
                  <div className="flex flex-col sm:flex-row justify-between items-start pb-4 border-b-2 border-slate-900 gap-4">
                    <div>
                      <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                        Supplier Detail Transaction
                      </h2>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Detailed Ledger, Procurement Items & Payment Movement Statement
                      </p>
                    </div>

                    <div className="text-left sm:text-right">
                      <h3 className="text-lg sm:text-xl font-black tracking-tight text-slate-900 uppercase">
                        APEX GLOBAL TRADING & DISTRIBUTION
                      </h3>
                      <p className="text-xs text-slate-600 font-medium">
                        apex-global.com • Procurement & Port Operations
                      </p>
                      <p className="text-xs text-slate-700 font-semibold">
                        Authorized: {currentUser?.displayName || 'Procurement & Finance Officer'}
                      </p>
                    </div>
                  </div>

                  {/* Metadata Key-Value Block */}
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-y-1 gap-x-6 py-4 text-xs font-sans border-b border-slate-200">
                    <div className="sm:col-span-8 grid grid-cols-3 gap-y-1">
                      <div className="text-slate-700 font-medium">Print Out Date:</div>
                      <div className="col-span-2 font-mono font-semibold text-slate-900">
                        {currentDateTimeFormatted}
                      </div>

                      <div className="text-slate-700 font-medium">Fiscal Year:</div>
                      <div className="col-span-2 font-medium text-slate-900 flex items-center gap-2">
                        <span className="font-semibold text-slate-900 font-mono">{formatFiscalYearDisplay(selectedFY)}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold font-mono ${
                          selectedFY?.status === 'Active' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : selectedFY?.status === 'Closed'
                              ? 'bg-slate-100 text-slate-600'
                              : 'bg-blue-100 text-blue-800'
                        }`}>
                          {selectedFY?.status}
                        </span>
                      </div>

                      <div className="text-slate-700 font-medium">Period:</div>
                      <div className="col-span-2 font-mono font-semibold text-slate-900">
                        {dateFilter === 'ALL' 
                          ? `${selectedFY.startDate.split('-').reverse().join('/')} - ${selectedFY.endDate.split('-').reverse().join('/')}`
                          : dateFilter === 'THIS_MONTH'
                            ? 'Current Month'
                            : dateFilter === 'LAST_30'
                              ? 'Last 30 Days'
                              : 'Last 90 Days'}
                      </div>

                      <div className="text-slate-700 font-medium">Supplier:</div>
                      <div className="col-span-2 font-bold text-slate-900">
                        {currentSupplier?.name} ({currentSupplier?.category || 'Boulder Quarry'})
                      </div>

                      <div className="text-slate-700 font-medium">Show Balance:</div>
                      <div className="col-span-2 font-medium text-slate-900">
                        Yes
                      </div>

                      <div className="text-slate-700 font-medium">Currency:</div>
                      <div className="col-span-2 font-medium text-slate-900">
                        Balances in Home Currency (BDT)
                      </div>

                      <div className="text-slate-700 font-medium">Suppress Zeros:</div>
                      <div className="col-span-2 font-medium text-slate-900">
                        No
                      </div>
                    </div>

                    <div className="sm:col-span-4 flex flex-col justify-between sm:items-end pt-2 sm:pt-0">
                      <div className="font-mono text-xs text-slate-500 font-semibold">
                        Page 1 of 1
                      </div>

                      <div className="text-left sm:text-right mt-2 sm:mt-0 p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 text-[11px]">
                        <span className="text-slate-500 block">Supplier Code:</span>
                        <span className="font-mono font-bold text-indigo-900 text-xs">{currentSupplier?.code}</span>
                        <span className="text-slate-500 block mt-1">Origin Country:</span>
                        <span className="font-semibold text-slate-700">{currentSupplier?.country}</span>
                      </div>
                    </div>
                  </div>

                  {/* Core Table */}
                  <div className="mt-4 overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b-2 border-slate-900 text-slate-900 font-bold text-xs uppercase tracking-wider">
                          <th className="py-2.5 px-2 w-24">Date</th>
                          <th className="py-2.5 px-3">Ref (Type - Trans No.)</th>
                          <th className="py-2.5 px-3">User / LOC or Bank</th>
                          <th className="py-2.5 px-3 text-right w-28">Charges</th>
                          <th className="py-2.5 px-3 text-right w-28">Credits</th>
                          <th className="py-2.5 px-3 text-right w-32">Balance</th>
                        </tr>
                      </thead>

                      <tbody className="divide-y divide-slate-300 text-slate-900 font-normal">
                        {/* Opening Balance Line */}
                        <tr className="bg-slate-50/70 font-semibold border-b border-slate-200">
                          <td className="py-2.5 px-2 font-mono text-slate-700">
                            01/07/2026
                          </td>
                          <td className="py-2.5 px-3 text-slate-800 italic">
                            Opening Balance Brought Forward
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px]">
                            jubayer / Burimari
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-slate-400">-</td>
                          <td className="py-2.5 px-3 text-right font-mono text-slate-400">-</td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                            {(currentSupplier?.openingBalance || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                        </tr>

                        {/* Ledger Transactions */}
                        {ledgerEntries.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="py-8 text-center text-slate-400 italic">
                              No transactions found.
                            </td>
                          </tr>
                        ) : (
                          ledgerEntries.map((row) => {
                            const isDebit = row.debit > 0;
                            const isCredit = row.credit > 0;

                            return (
                              <React.Fragment key={row.id}>
                                <tr className="align-top hover:bg-slate-50/50 transition-colors">
                                  <td className="py-2 px-2 font-mono text-slate-800 whitespace-nowrap pt-3">
                                    {row.date}
                                  </td>

                                  <td className="py-2 px-3 font-bold text-slate-900 pt-3">
                                    <span className="font-mono text-xs">{row.refNo}</span>
                                  </td>

                                  <td className="py-2 px-3 font-mono text-slate-700 text-xs whitespace-nowrap pt-3">
                                    <span className="font-semibold text-slate-900">
                                      {row.purchaser || 'jubayer'}
                                    </span>
                                    <span className="text-slate-400 mx-1">/</span>
                                    <span className="font-semibold text-blue-900">
                                      {row.type === 'Payment' 
                                        ? (row.bankName || row.paymentMethod || 'Bank') 
                                        : (row.site || 'Burimari')}
                                    </span>
                                  </td>

                                  {/* Charges (Purchase) */}
                                  <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 pt-3 whitespace-nowrap">
                                    {isDebit 
                                      ? row.debit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) 
                                      : ''}
                                  </td>

                                  {/* Credits (Payments) */}
                                  <td className="py-2 px-3 text-right font-mono font-bold text-emerald-800 pt-3 whitespace-nowrap">
                                    {isCredit 
                                      ? row.credit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) 
                                      : ''}
                                  </td>

                                  {/* Balance */}
                                  <td className="py-2 px-3 text-right font-mono font-black text-rose-900 pt-3 whitespace-nowrap">
                                    {row.runningBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                  </td>
                                </tr>

                                {/* Under-Row Breakdown */}
                                <tr className="border-b border-slate-200">
                                  <td></td>
                                  <td colSpan={5} className="pb-3 pt-0.5 px-3">
                                    {row.type === 'Invoice' && (
                                      <div className="text-xs space-y-1.5 pl-2 border-l-2 border-slate-300">
                                        {/* Memo tag */}
                                        {row.memoNo && (
                                          <div className="italic text-slate-700 font-medium text-[11px]">
                                            {row.memoNo}
                                            {row.truckNo && <span className="ml-2 font-mono not-italic text-slate-500 font-bold">• {row.truckNo}</span>}
                                          </div>
                                        )}

                                        {/* Items Table */}
                                        <div className="max-w-xl">
                                          <table className="w-full text-xs text-left">
                                            <thead>
                                              <tr className="text-slate-500 font-semibold border-b border-slate-200 text-[11px]">
                                                <th className="py-1 w-7/12">Item / QTY</th>
                                                <th className="py-1 text-right w-2/12">Price</th>
                                                <th className="py-1 text-right w-3/12">Total</th>
                                              </tr>
                                            </thead>
                                            <tbody className="divide-y divide-slate-100 font-mono">
                                              {(row.items && row.items.length > 0) ? (
                                                row.items.map((itm, idx) => (
                                                  <tr key={idx} className="text-slate-800">
                                                    <td className="py-1 font-sans">
                                                      <span className="font-semibold text-slate-900">{itm.itemName}</span>
                                                      <span className="text-slate-500 ml-1">
                                                        x {itm.quantity.toFixed(2)} {itm.uom}
                                                      </span>
                                                    </td>
                                                    <td className="py-1 text-right">
                                                      {itm.unitPrice.toFixed(2)}
                                                    </td>
                                                    <td className="py-1 text-right font-bold text-slate-900">
                                                      {itm.total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                                    </td>
                                                  </tr>
                                                ))
                                              ) : (
                                                <tr className="text-slate-800">
                                                  <td className="py-1 font-sans">
                                                    <span className="font-semibold text-slate-900">{row.description}</span>
                                                  </td>
                                                  <td className="py-1 text-right">-</td>
                                                  <td className="py-1 text-right font-bold text-slate-900">
                                                    {row.debit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                                  </td>
                                                </tr>
                                              )}
                                            </tbody>
                                          </table>

                                          {/* Subtotals strip: Shipping, Discount, Total Amount */}
                                          <div className="mt-1 pt-1 border-t border-slate-200 text-[11px] flex justify-end gap-6 text-slate-600 font-mono">
                                            <div>Shipping: <span className="font-bold text-slate-900">{(row.shippingCost || 0).toFixed(2)}</span></div>
                                            <div>Discount: <span className="font-bold text-slate-900">{(row.discountAmount || 0).toFixed(2)}</span></div>
                                            <div>Total Amount: <span className="font-bold text-slate-900">{row.debit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
                                          </div>
                                        </div>
                                      </div>
                                    )}

                                    {row.type === 'Payment' && (
                                      <div className="text-xs space-y-1 pl-2 border-l-2 border-emerald-400">
                                        <div className="text-slate-700 font-medium">
                                          <span className="text-emerald-700 font-bold">Disbursement Voucher:</span>{' '}
                                          {row.description}
                                        </div>
                                        <div className="text-[11px] text-slate-500 font-mono flex items-center gap-3 flex-wrap">
                                          {row.paymentMethod && <span>Method: <strong className="text-slate-800">{row.paymentMethod}</strong></span>}
                                          {row.bankName && <span>Bank: <strong className="text-slate-800">{row.bankName}</strong></span>}
                                          {row.chequeNumber && <span>Cheque #: <strong className="text-indigo-800">{row.chequeNumber}</strong></span>}
                                          {row.chequeDate && <span>Date: <strong className="text-slate-800">{row.chequeDate}</strong></span>}
                                        </div>
                                      </div>
                                    )}
                                  </td>
                                </tr>
                              </React.Fragment>
                            );
                          })
                        )}

                        {/* Total Summary Row */}
                        <tr className="border-t-2 border-slate-900 bg-slate-50 font-bold text-xs">
                          <td colSpan={3} className="py-3 px-3 text-right uppercase tracking-wider text-slate-800">
                            Total Activity in Selected Period:
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-slate-950 text-sm whitespace-nowrap">
                            BDT {totalInvoicedAmt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-emerald-800 text-sm whitespace-nowrap">
                            BDT {totalPaidAmt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-rose-900 text-sm whitespace-nowrap">
                            BDT {totalDueAmt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Footer Notes & Total in Words */}
                  <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="font-bold text-slate-700 block mb-0.5">NET PAYABLE BALANCE IN WORDS:</span>
                      <p className="font-semibold text-slate-900 italic font-serif">
                        {numberToWords(totalDueAmt)}
                      </p>
                      <p className="text-[11px] text-slate-500 mt-2">
                        Note: This statement is computer-generated by Apex Global Procurement & Commercial ERP. Any questions or discrepancies should be directed to the procurement & audit department within 7 business days.
                      </p>
                    </div>

                    <div className="flex flex-col justify-end sm:items-end text-slate-600 text-[11px] font-mono">
                      <div>Authorized Signatory • Apex Global Distribution</div>
                      <div className="w-48 border-b border-slate-400 mt-8 mb-1"></div>
                      <div className="text-slate-400">Head of Procurement & Accounts ({currentUser?.displayName || 'Finance Lead'})</div>
                    </div>
                  </div>
                </div>
              ) : (
                /* Compact Classic Table View */
                <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 px-3">Date</th>
                          <th className="py-2.5 px-3">Reference / Slip</th>
                          <th className="py-2.5 px-3">Site / User</th>
                          <th className="py-2.5 px-3">Description</th>
                          <th className="py-2.5 px-3 text-right">Debit / Purchase</th>
                          <th className="py-2.5 px-3 text-right">Credit / Payment</th>
                          <th className="py-2.5 px-3 text-right">Payable Balance</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {ledgerEntries.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="py-8 text-center text-slate-400">
                              <FileText className="w-7 h-7 mx-auto text-slate-300 mb-1" />
                              <p className="font-semibold text-slate-600">No ledger transactions found</p>
                            </td>
                          </tr>
                        ) : (
                          ledgerEntries.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/70 transition-colors">
                              <td className="py-2.5 px-3 text-slate-700 font-medium">{row.date}</td>
                              <td className="py-2.5 px-3 font-mono font-bold text-indigo-700">{row.refNo}</td>
                              <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                                {row.purchaser || 'jubayer'} / {row.site || 'Burimari'}
                              </td>
                              <td className="py-2.5 px-3 text-slate-800">{row.description}</td>
                              <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                                {row.debit > 0 ? `BDT ${row.debit.toLocaleString()}` : '-'}
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-600">
                                {row.credit > 0 ? `BDT ${row.credit.toLocaleString()}` : '-'}
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                                BDT {row.runningBalance.toLocaleString()}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                      {ledgerEntries.length > 0 && (
                        <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                          <tr>
                            <td colSpan={4} className="py-2.5 px-3 text-right text-slate-700">Total:</td>
                            <td className="py-2.5 px-3 text-right font-mono text-slate-900">
                              BDT {totalInvoicedAmt.toLocaleString()}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-emerald-700">
                              BDT {totalPaidAmt.toLocaleString()}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-rose-700">
                              BDT {totalDueAmt.toLocaleString()}
                            </td>
                          </tr>
                        </tfoot>
                      )}
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: Supplier Payables & Aging Analysis (Consolidated into Supplier Ledger) */}
          {activeTab === 'payables' && (
            <div className="space-y-4">
              {/* Aging Buckets Header */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-rose-600" />
                      <span>Accounts Payable (AP) & Aging Analysis</span>
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => onOpenPaymentModal(activeSupplierId)}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>+ Make Supplier Payment</span>
                  </button>
                </div>

                {/* Aging 4 Buckets */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold uppercase text-slate-400">Current (0-30 Days)</span>
                    <div className="text-base font-bold font-mono text-slate-900 mt-1">
                      BDT {agingStats.current_0_30.toLocaleString()}
                    </div>
                    <span className="text-[10px] text-slate-500">Current Bills</span>
                  </div>
                  <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-200">
                    <span className="text-[10px] font-bold uppercase text-blue-700">31-60 Days</span>
                    <div className="text-base font-bold font-mono text-blue-900 mt-1">
                      BDT {agingStats.days_31_60.toLocaleString()}
                    </div>
                    <span className="text-[10px] text-blue-600">Standard Term</span>
                  </div>
                  <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-200">
                    <span className="text-[10px] font-bold uppercase text-amber-700">61-90 Days</span>
                    <div className="text-base font-bold font-mono text-amber-900 mt-1">
                      BDT {agingStats.days_61_90.toLocaleString()}
                    </div>
                    <span className="text-[10px] text-amber-600">Near Due</span>
                  </div>
                  <div className="p-3 bg-rose-50/50 rounded-xl border border-rose-200">
                    <span className="text-[10px] font-bold uppercase text-rose-700">90+ Days Overdue</span>
                    <div className="text-base font-bold font-mono text-rose-900 mt-1">
                      BDT {agingStats.days_90_plus.toLocaleString()}
                    </div>
                    <span className="text-[10px] text-rose-600 font-semibold">
                      {agingStats.days_90_plus > 0 ? 'Urgent Payment Required' : 'No Overdue Balance'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Supplier-by-Supplier Payable Due Table */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                <div className="p-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      Supplier Due Breakdown & Action Ledger
                    </h4>
                  </div>
                  <span className="text-xs font-mono font-bold bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-lg">
                    {suppliers.length} Suppliers Listed
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Supplier / Company</th>
                        <th className="py-2.5 px-3">Category & Origin</th>
                        <th className="py-2.5 px-3">Payment Terms</th>
                        <th className="py-2.5 px-3 text-center">Unpaid Invoices</th>
                        <th className="py-2.5 px-3 text-right">Outstanding Due</th>
                        <th className="py-2.5 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {suppliers.map((s) => {
                        const suppInvoices = invoices.filter(i => i.supplierId === s.id || i.supplierName === s.name);
                        const unpaidInvoices = suppInvoices.filter(i => i.dueAmount > 0);
                        const invoiceDueTotal = unpaidInvoices.reduce((sum, i) => sum + i.dueAmount, 0);
                        const displayDue = Math.max(s.currentPayable, invoiceDueTotal);

                        return (
                          <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                            <td className="py-2.5 px-3">
                              <span className="font-bold text-slate-900 block text-xs">{s.name}</span>
                              <span className="text-[10px] text-slate-400 font-mono">Code: {s.code}</span>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 inline-block mb-0.5">
                                {s.category}
                              </span>
                              <span className="text-[11px] text-slate-500 block">Origin: {s.country}</span>
                            </td>
                            <td className="py-2.5 px-3 text-slate-600 font-medium">
                              {s.paymentTerms}
                            </td>
                            <td className="py-2.5 px-3 text-center font-mono">
                              {unpaidInvoices.length > 0 ? (
                                <span className="px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200 font-bold text-[10px]">
                                  {unpaidInvoices.length} Invoices Due
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-[10px]">
                                  ✓ Clear
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                              <span className={displayDue > 0 ? 'text-rose-600 text-sm' : 'text-emerald-600'}>
                                BDT {displayDue.toLocaleString()}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                {displayDue > 0 && (
                                  <button
                                    type="button"
                                    onClick={() => onOpenPaymentModal(s.id, unpaidInvoices[0])}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
                                  >
                                    <CreditCard className="w-3 h-3" />
                                    <span>Pay</span>
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => {
                                    handleSelectSupplier(s.id);
                                    setActiveTab('ledger');
                                  }}
                                  className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg font-semibold text-[11px] transition-colors flex items-center gap-1 cursor-pointer"
                                >
                                  <FileText className="w-3 h-3 text-indigo-600" />
                                  <span>View Ledger</span>
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* All Unpaid Invoices Across the System */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                <div className="p-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Receipt className="w-4 h-4 text-rose-600" />
                    <span>All Unpaid / Due Purchase Invoices ({allUnpaidInvoices.length})</span>
                  </span>
                  <span className="text-xs font-mono font-bold text-rose-700">
                    Total Due: BDT {agingStats.totalDue.toLocaleString()}
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Invoice # & Challan</th>
                        <th className="py-2.5 px-3">Supplier Name</th>
                        <th className="py-2.5 px-3">Invoice Date</th>
                        <th className="py-2.5 px-3">Due Date</th>
                        <th className="py-2.5 px-3 text-right">Invoice Total</th>
                        <th className="py-2.5 px-3 text-right">Remaining Due</th>
                        <th className="py-2.5 px-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {allUnpaidInvoices.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-6 text-center text-slate-400">
                            <CheckCircle2 className="w-6 h-6 mx-auto text-emerald-500 mb-1" />
                            <p className="font-semibold text-slate-700">No unpaid purchase invoices found.</p>
                          </td>
                        </tr>
                      ) : (
                        allUnpaidInvoices.map((inv) => (
                          <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors">
                            <td className="py-2.5 px-3">
                              <span className="font-mono font-bold text-indigo-700 block">{inv.invoiceNumber}</span>
                              <span className="text-[10px] text-slate-400 font-mono">Challan: {inv.challanNumber}</span>
                            </td>
                            <td className="py-2.5 px-3 font-semibold text-slate-900">{inv.supplierName}</td>
                            <td className="py-2.5 px-3 text-slate-700">{inv.invoiceDate}</td>
                            <td className="py-2.5 px-3 font-mono font-bold text-rose-700">{inv.dueDate}</td>
                            <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-900">
                              BDT {inv.grandTotal.toLocaleString()}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                              BDT {inv.dueAmount.toLocaleString()}
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              <button
                                type="button"
                                onClick={() => onOpenPaymentModal(inv.supplierId, inv)}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition-colors inline-flex items-center gap-1 shadow-2xs cursor-pointer"
                              >
                                <CreditCard className="w-3 h-3" />
                                <span>Pay Due</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Invoice Slip Modal */}
      {viewInvoiceSlip && (
        <ModalWrapper
          isOpen={!!viewInvoiceSlip}
          onClose={() => setViewInvoiceSlip(null)}
          isDirty={false}
          backdropClassName="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 shrink-0">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm">Purchase Invoice Challan Slip</h3>
              </div>
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setViewInvoiceSlip(null)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer p-1 shrink-0"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 my-4 text-xs font-mono">
              <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Invoice Number:</span>
                  <span className="font-bold text-indigo-700">{viewInvoiceSlip.invoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Challan Number:</span>
                  <span className="font-bold">{viewInvoiceSlip.challanNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Date:</span>
                  <span>{viewInvoiceSlip.invoiceDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Supplier:</span>
                  <span className="font-bold text-slate-900">{viewInvoiceSlip.supplierName}</span>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="p-2">Item</th>
                      <th className="p-2 text-right">Qty</th>
                      <th className="p-2 text-right">Rate</th>
                      <th className="p-2 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {viewInvoiceSlip.items?.map((itm, idx) => (
                      <tr key={idx} className="border-b border-slate-100">
                        <td className="p-2">{itm.itemName}</td>
                        <td className="p-2 text-right">{itm.quantity} {itm.uom}</td>
                        <td className="p-2 text-right">{viewInvoiceSlip.currency} {itm.unitPrice.toLocaleString()}</td>
                        <td className="p-2 text-right font-bold">{viewInvoiceSlip.currency} {itm.totalPrice.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="p-3 bg-indigo-50/50 rounded-xl space-y-1">
                <div className="flex justify-between font-bold text-sm">
                  <span>Grand Total:</span>
                  <span>{viewInvoiceSlip.currency} {viewInvoiceSlip.grandTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-emerald-700">
                  <span>Paid:</span>
                  <span>{viewInvoiceSlip.currency} {viewInvoiceSlip.paidAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-rose-700 font-bold">
                  <span>Due Balance:</span>
                  <span>{viewInvoiceSlip.currency} {viewInvoiceSlip.dueAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setViewInvoiceSlip(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Slip</span>
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* Print Ledger Modal (Exact Parity with Jubayer Overseas Reference) */}
      {printLedgerModal && (
        <ModalWrapper
          isOpen={printLedgerModal}
          onClose={() => setPrintLedgerModal(false)}
          isDirty={false}
          backdropClassName="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6"
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full p-6 sm:p-8 animate-in fade-in zoom-in-95 max-h-[92vh] overflow-y-auto border border-slate-300">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 no-print shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Supplier Detail Transaction Print Preview
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Document</span>
                </button>
                <button
                  type="button"
                  data-modal-close="true"
                  onClick={() => setPrintLedgerModal(false)}
                  className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1 cursor-pointer shrink-0"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Document Body for Print */}
            <div className="my-4 text-xs space-y-4">
              {/* Header */}
              <div className="flex justify-between items-start pb-4 border-b-2 border-slate-900">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    Supplier Detail Transaction
                  </h2>
                </div>

                <div className="text-right">
                  <h3 className="text-lg sm:text-xl font-black tracking-tight text-slate-900 uppercase">
                    {companyProfile.companyName}
                  </h3>
                  <p className="text-xs text-slate-600 font-medium">
                    {companyProfile.address} • Mobile: {companyProfile.mobile}
                  </p>
                  <p className="text-xs text-slate-700 font-semibold">
                    Authorized: {currentUser?.displayName || 'Procurement & Finance Officer'}
                  </p>
                </div>
              </div>

              {/* 2-Column Metadata Strip */}
              <div className="grid grid-cols-12 gap-y-1 gap-x-6 py-2 text-xs font-sans border-b border-slate-200">
                <div className="col-span-8 grid grid-cols-3 gap-y-1">
                  <div className="text-slate-700 font-medium">Print Out Date:</div>
                  <div className="col-span-2 font-mono font-semibold text-slate-900">
                    {currentDateTimeFormatted}
                  </div>

                  <div className="text-slate-700 font-medium">Fiscal Year:</div>
                  <div className="col-span-2 font-medium text-slate-900 flex items-center gap-2">
                    <span className="font-semibold text-slate-900 font-mono">{formatFiscalYearDisplay(selectedFY)}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold font-mono ${
                      selectedFY?.status === 'Active' 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : selectedFY?.status === 'Closed'
                          ? 'bg-slate-100 text-slate-600'
                          : 'bg-blue-100 text-blue-800'
                    }`}>
                      {selectedFY?.status}
                    </span>
                  </div>

                  <div className="text-slate-700 font-medium">Period:</div>
                  <div className="col-span-2 font-mono font-semibold text-slate-900">
                    {dateFilter === 'ALL' 
                      ? `${selectedFY.startDate.split('-').reverse().join('/')} - ${selectedFY.endDate.split('-').reverse().join('/')}`
                      : dateFilter === 'THIS_MONTH'
                        ? 'Current Month'
                        : dateFilter === 'LAST_30'
                          ? 'Last 30 Days'
                          : 'Last 90 Days'}
                  </div>

                  <div className="text-slate-700 font-medium">Supplier:</div>
                  <div className="col-span-2 font-bold text-slate-900">
                    {currentSupplier?.name} ({currentSupplier?.category || 'Boulder Quarry'})
                  </div>

                  <div className="text-slate-700 font-medium">Show Balance:</div>
                  <div className="col-span-2 font-medium text-slate-900">
                    Yes
                  </div>

                  <div className="text-slate-700 font-medium">Currency:</div>
                  <div className="col-span-2 font-medium text-slate-900">
                    Balances in Home Currency (BDT)
                  </div>

                  <div className="text-slate-700 font-medium">Suppress Zeros:</div>
                  <div className="col-span-2 font-medium text-slate-900">
                    No
                  </div>
                </div>

                <div className="col-span-4 flex flex-col justify-between items-end">
                  <div className="font-mono text-xs text-slate-500 font-semibold">
                    Page 1 of 1
                  </div>
                  <div className="text-right p-2 bg-slate-50 rounded-lg border border-slate-200 text-[11px]">
                    <span className="text-slate-500 block">Supplier Code:</span>
                    <span className="font-mono font-bold text-slate-900">{currentSupplier?.code}</span>
                    <span className="text-slate-500 block mt-0.5">Origin Country:</span>
                    <span className="font-semibold text-slate-700">{currentSupplier?.country}</span>
                  </div>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b-2 border-slate-900 text-slate-900 font-bold text-xs uppercase tracking-wider">
                      <th className="py-2 px-2 w-24">Date</th>
                      <th className="py-2 px-3">Ref (Type - Trans No.)</th>
                      <th className="py-2 px-3">User / LOC or Bank</th>
                      <th className="py-2 px-3 text-right w-28">Charges</th>
                      <th className="py-2 px-3 text-right w-28">Credits</th>
                      <th className="py-2 px-3 text-right w-32">Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-300 text-slate-900 font-normal">
                    {/* Opening Balance Line */}
                    <tr className="bg-slate-50 font-semibold border-b border-slate-200">
                      <td className="py-2 px-2 font-mono text-slate-700">01/07/2026</td>
                      <td className="py-2 px-3 text-slate-800 italic">Opening Balance Brought Forward</td>
                      <td className="py-2 px-3 font-mono text-slate-500">jubayer / Burimari</td>
                      <td className="py-2 px-3 text-right font-mono text-slate-400">-</td>
                      <td className="py-2 px-3 text-right font-mono text-slate-400">-</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                        {(currentSupplier?.openingBalance || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                    </tr>

                    {ledgerEntries.map((row) => (
                      <React.Fragment key={row.id}>
                        <tr className="align-top hover:bg-slate-50/50">
                          <td className="py-2 px-2 font-mono text-slate-800 whitespace-nowrap pt-3">{row.date}</td>
                          <td className="py-2 px-3 font-bold text-slate-900 pt-3">
                            <span className="font-mono text-xs">{row.refNo}</span>
                          </td>
                          <td className="py-2 px-3 font-mono text-slate-700 text-xs whitespace-nowrap pt-3">
                            <span className="font-semibold text-slate-900">{row.purchaser || 'jubayer'}</span>
                            <span className="text-slate-400 mx-1">/</span>
                            <span className="font-semibold text-blue-900">
                              {row.type === 'Payment' ? (row.bankName || row.paymentMethod || 'Bank') : (row.site || 'Burimari')}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 pt-3 whitespace-nowrap">
                            {row.debit > 0 ? row.debit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : ''}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-emerald-800 pt-3 whitespace-nowrap">
                            {row.credit > 0 ? row.credit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : ''}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-black text-rose-900 pt-3 whitespace-nowrap">
                            {row.runningBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                        </tr>

                        <tr className="border-b border-slate-200">
                          <td></td>
                          <td colSpan={5} className="pb-3 pt-0.5 px-3">
                            {row.type === 'Invoice' && (
                              <div className="text-xs space-y-1 pl-2 border-l-2 border-slate-300">
                                {row.memoNo && (
                                  <div className="italic text-slate-700 font-medium text-[11px]">
                                    {row.memoNo}
                                    {row.truckNo && <span className="ml-2 font-mono not-italic text-slate-500 font-bold">• {row.truckNo}</span>}
                                  </div>
                                )}
                                <div className="max-w-xl">
                                  <table className="w-full text-xs text-left">
                                    <thead>
                                      <tr className="text-slate-500 font-semibold border-b border-slate-200 text-[11px]">
                                        <th className="py-0.5 w-7/12">Item / QTY</th>
                                        <th className="py-0.5 text-right w-2/12">Price</th>
                                        <th className="py-0.5 text-right w-3/12">Total</th>
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 font-mono">
                                      {row.items?.map((itm, idx) => (
                                        <tr key={idx} className="text-slate-800">
                                          <td className="py-0.5 font-sans">
                                            <span className="font-semibold text-slate-900">{itm.itemName}</span>
                                            <span className="text-slate-500 ml-1">x {itm.quantity.toFixed(2)} {itm.uom}</span>
                                          </td>
                                          <td className="py-0.5 text-right">{itm.unitPrice.toFixed(2)}</td>
                                          <td className="py-0.5 text-right font-bold text-slate-900">
                                            {itm.total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                  <div className="mt-1 pt-1 border-t border-slate-200 text-[11px] flex justify-end gap-6 text-slate-600 font-mono">
                                    <div>Shipping: <span className="font-bold text-slate-900">{(row.shippingCost || 0).toFixed(2)}</span></div>
                                    <div>Discount: <span className="font-bold text-slate-900">{(row.discountAmount || 0).toFixed(2)}</span></div>
                                    <div>Total Amount: <span className="font-bold text-slate-900">{row.debit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
                                  </div>
                                </div>
                              </div>
                            )}

                            {row.type === 'Payment' && (
                              <div className="text-xs space-y-1 pl-2 border-l-2 border-emerald-400">
                                <div className="text-slate-700 font-medium">
                                  <span className="text-emerald-700 font-bold">Disbursement Voucher:</span> {row.description}
                                </div>
                                <div className="text-[11px] text-slate-500 font-mono flex items-center gap-3 flex-wrap">
                                  {row.paymentMethod && <span>Method: <strong className="text-slate-800">{row.paymentMethod}</strong></span>}
                                  {row.bankName && <span>Bank: <strong className="text-slate-800">{row.bankName}</strong></span>}
                                  {row.chequeNumber && <span>Cheque #: <strong className="text-indigo-800">{row.chequeNumber}</strong></span>}
                                  {row.chequeDate && <span>Date: <strong className="text-slate-800">{row.chequeDate}</strong></span>}
                                </div>
                              </div>
                            )}
                          </td>
                        </tr>
                      </React.Fragment>
                    ))}

                    <tr className="border-t-2 border-slate-900 bg-slate-50 font-bold text-xs">
                      <td colSpan={3} className="py-2.5 px-3 text-right uppercase tracking-wider text-slate-800">
                        Total Activity in Selected Period:
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-950 text-sm whitespace-nowrap">
                        BDT {totalInvoicedAmt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-emerald-800 text-sm whitespace-nowrap">
                        BDT {totalPaidAmt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-rose-900 text-sm whitespace-nowrap">
                        BDT {totalDueAmt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Footer Notes & Total in Words */}
              <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="font-bold text-slate-700 block mb-0.5">NET PAYABLE BALANCE IN WORDS:</span>
                  <p className="font-semibold text-slate-900 italic font-serif">
                    {numberToWords(totalDueAmt)}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-2">
                    Note: This statement is computer-generated by {companyProfile.companyName}. Any questions or discrepancies should be directed to the procurement & audit department within 7 business days.
                  </p>
                </div>

                <div className="flex flex-col justify-end items-end text-slate-600 text-[11px] font-mono">
                  <div>Authorized Signatory • {companyProfile.companyName}</div>
                  <div className="w-48 border-b border-slate-400 mt-8 mb-1"></div>
                  <div className="text-slate-400">Head of Procurement & Accounts ({currentUser?.displayName || 'Finance Lead'})</div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 no-print">
              <button
                type="button"
                data-modal-close="true"
                onClick={() => setPrintLedgerModal(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Document</span>
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};
