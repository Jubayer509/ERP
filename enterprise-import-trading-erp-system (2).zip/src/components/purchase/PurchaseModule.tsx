import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  ShoppingCart, 
  FileCheck, 
  Truck, 
  Building2, 
  Plus, 
  Search, 
  Calendar, 
  CheckCircle2, 
  DollarSign, 
  ClipboardList, 
  RotateCcw,
  ShieldCheck,
  Ship,
  FileText,
  Calculator,
  Receipt,
  Layers,
  ChevronDown,
  Clock,
  ArrowRight,
  Filter,
  AlertCircle,
  Bell,
  FileSpreadsheet,
  CreditCard,
  Landmark,
  LayoutDashboard,
  TrendingUp,
  ChevronRight,
  Zap,
  Coins,
  MapPin,
  ArrowDownToLine,
  Users,
  Lock,
  AlertTriangle,
  XCircle,
  X,
  ShieldAlert,
  Loader2
} from 'lucide-react';
import { MOCK_SUPPLIERS, MOCK_GRNS, MOCK_ITEMS, MOCK_LCS, MOCK_SOIL_CLAIMS, MOCK_KHATA_PAYMENTS, MOCK_DIRECT_PURCHASE_INVOICES, MOCK_SUPPLIER_PAYMENTS } from '../../data/mockErpData';
import { PurchaseOrder, GRN, Supplier, LetterOfCredit, LCStatus, LCType, SoilClaimRecord, KhataPaymentRecord, DirectPurchaseInvoice, SupplierPaymentRecord, BankAccount } from '../../types/erp';
import { AccountTransaction, AccountHead } from '../../types/accounts';
import { useAuth } from '../../contexts/AuthContext';
import { getBankAccounts, subscribeBankAccounts, isCashAccount } from '../../utils/bankAccountStorage';
import { ModalWrapper } from '../common/ModalWrapper';
import { 
  postVoucher, 
  voidAccountTransaction, 
  getAccountTransactions, 
  subscribeAccountTransactions,
  getOrCreateAccountHead, 
  getAccountHeads,
  postLcMargin,
  reverseAndCorrectLcMargin,
  computeExpectedLcMarginBDT,
  createLetterOfCreditAtomic,
  validateAndClaimEditedLcNumber,
  voidDuplicateLc,
  reverseVoucher,
  persistLcExpenseDurable,
  reconcileAndHealLcExpenses,
  subscribeFirestoreLcs
} from '../../services/accountService';
import { VoucherPrintModal } from '../accounts/VoucherPrintModal';
import { DocumentaryCreditTracker } from '../lc/DocumentaryCreditTracker';
import { LCExpensesView } from './LCExpensesView';
import { LCExporterBillsView } from './LCExporterBillsView';
import { computeLCProgressAndStatus } from '../../utils/lcStatusHelper';
import { LCProductReceivingSector } from '../lc/LCProductReceivingSector';
import { LCRegisterView } from './LCRegisterView';
import { LCBalanceSheetView } from './LCBalanceSheetView';
import { DirectPurchaseInvoiceView } from './DirectPurchaseInvoiceView';
import { SupplierPaymentList } from './SupplierPaymentList';
import { SupplierKhataReport } from './SupplierKhataReport';
import { PurchaseOverviewDashboard } from './PurchaseOverviewDashboard';
import { PrintablePurchaseInvoiceModal } from './PrintablePurchaseInvoiceModal';
import { AddSupplierModal } from './AddSupplierModal';
import { CompanyOwnerLcReport } from './CompanyOwnerLcReport';
import { LCExpiryAlertBanner } from '../lc/LCExpiryAlertBanner';
import { LCExpiryAlertModal } from '../lc/LCExpiryAlertModal';
import { generateLCExpiryAlerts, LCExpiryAlert } from '../../utils/lcAlertUtils';
import { subscribeRecycleBin } from '../../utils/recycleBinStorage';
import { getSuppliers, saveSuppliers, subscribeSuppliers, getUniqueCompanyOwners, updateSupplier, addSupplier, updateSupplierPayableBalance } from '../../utils/supplierStorage';
import { addStockToItem, deductStockFromItem } from '../../utils/itemStorage';
import { SupplierProfilesView } from './SupplierProfilesView';
import { LCStatusSummaryDashboard } from '../lc/LCStatusSummaryDashboard';

export type PurchaseSubTab = 
  | 'overview'
  | 'lc_status_summary'
  | 'lc_balance_sheet'
  | 'lc_register'
  | 'lc_owner_report'
  | 'lc_tracking' 
  | 'lc_expenses' 
  | 'lc_exporter_bills' 
  | 'lc_product_receiving'
  | 'purchase_invoice'
  | 'supplier_payments'
  | 'supplier_profiles'
  | 'po' 
  | 'grn' 
  | 'suppliers' 
  | 'payables';

export interface PurchaseModuleProps {
  initialTab?: PurchaseSubTab;
  currentBranch?: string;
  activeSubTab?: PurchaseSubTab;
  onSubTabChange?: (tab: PurchaseSubTab) => void;
}

export const PurchaseModule: React.FC<PurchaseModuleProps> = ({ 
  initialTab = 'purchase_invoice',
  currentBranch = 'All Branches',
  activeSubTab,
  onSubTabChange
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  // Bank & Cash Accounts (Real accounts from accountService / bankAccountStorage)
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => getBankAccounts());

  useEffect(() => {
    const unsub = subscribeBankAccounts((accs) => {
      setBankAccounts(accs);
    });
    return () => unsub();
  }, []);

  const accessibleAccounts = useMemo(() => {
    if (currentUser?.role === 'admin') {
      return bankAccounts;
    }
    const userBranch = currentUser?.branch || currentBranch;
    if (!userBranch || userBranch === 'All Branches') {
      return bankAccounts;
    }
    const branchKey = userBranch.toLowerCase().replace(' office', '');
    return bankAccounts.filter(acc => 
      !acc.branch || acc.branch.toLowerCase().includes(branchKey) || acc.branch === 'Head Office'
    );
  }, [bankAccounts, currentUser, currentBranch]);

  const expenseHeads = useMemo(() => {
    return getAccountHeads().filter(h => h.type === 'Expense' && h.active !== false);
  }, []);

  const [internalTab, setInternalTab] = useState<PurchaseSubTab>(initialTab === 'po' ? 'purchase_invoice' : initialTab);
  const activeTab = activeSubTab || internalTab;

  const setActiveTab = (tab: PurchaseSubTab) => {
    setInternalTab(tab);
    if (onSubTabChange) {
      onSubTabChange(tab);
    }
  };

  // Direct Purchase Invoices State (Replaces / Upgrades Purchase Order)
  const [purchaseInvoices, setPurchaseInvoices] = useState<DirectPurchaseInvoice[]>(() => {
    try {
      const saved = localStorage.getItem('tradecore_purchase_invoices_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load purchase invoices', e);
    }
    return MOCK_DIRECT_PURCHASE_INVOICES;
  });

  // Supplier Payments State (Complete Supplier Payment System)
  const [supplierPayments, setSupplierPayments] = useState<SupplierPaymentRecord[]>(() => {
    try {
      const saved = localStorage.getItem('tradecore_supplier_payments_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load supplier payments', e);
    }
    return MOCK_SUPPLIER_PAYMENTS;
  });

  // Navigation & Modal Preselection States
  const [preselectedInvoiceForPayment, setPreselectedInvoiceForPayment] = useState<DirectPurchaseInvoice | null>(null);
  const [selectedSupplierForKhata, setSelectedSupplierForKhata] = useState<string>(MOCK_SUPPLIERS[0]?.id || '');
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedPrintInvoice, setSelectedPrintInvoice] = useState<DirectPurchaseInvoice | null>(null);

  // Filtered by branch (guarantee newly created invoice is never hidden)
  const displayedPurchaseInvoices = purchaseInvoices.filter(i => {
    if (!currentBranch || currentBranch === 'All Branches') return true;
    const branchKey = currentBranch.toLowerCase().replace(' office', '');
    return !i.branch || 
           i.branch.toLowerCase().includes(branchKey) ||
           (i.warehouseName && i.warehouseName.toLowerCase().includes(branchKey));
  });

  const [showCreateInvoiceModal, setShowCreateInvoiceModal] = useState(false);

  // Today's Date & Month Prefix for Immediate Stats
  const todayDateStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const currentMonthPrefix = useMemo(() => todayDateStr.slice(0, 7), [todayDateStr]);

  // Quick statistics for immediate visibility across Purchase module
  const quickPurchaseStats = useMemo(() => {
    // 1. Total Unpaid Purchases
    const unpaidInvoices = purchaseInvoices.filter(i => (i.dueAmount || 0) > 0);
    const totalUnpaidAmount = unpaidInvoices.reduce((sum, i) => sum + (i.dueAmount || 0), 0);

    // 2. Today's Purchase Invoices
    const todayInvoices = purchaseInvoices.filter(i => i.invoiceDate === todayDateStr);
    const todayTotalAmount = todayInvoices.reduce((sum, i) => sum + (i.grandTotal || 0), 0);

    // 3. This Month's Purchase Total
    const monthInvoices = purchaseInvoices.filter(i => (i.invoiceDate || '').startsWith(currentMonthPrefix));
    const monthTotalAmount = monthInvoices.reduce((sum, i) => sum + (i.grandTotal || 0), 0);

    return {
      unpaidCount: unpaidInvoices.length,
      totalUnpaidAmount,
      todayCount: todayInvoices.length,
      todayTotalAmount,
      monthCount: monthInvoices.length,
      monthTotalAmount
    };
  }, [purchaseInvoices, todayDateStr, currentMonthPrefix]);

  // Handlers for Direct Purchase Invoices
  const handleCreatePurchaseInvoice = (newInv: DirectPurchaseInvoice) => {
    const updated = [newInv, ...purchaseInvoices];
    setPurchaseInvoices(updated);
    try {
      localStorage.setItem('tradecore_purchase_invoices_v1', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }

    // Auto-update inventory stock for each purchased item
    if (Array.isArray(newInv.items)) {
      newInv.items.forEach(item => {
        if (item.quantity > 0) {
          addStockToItem(item.itemId, item.quantity, item.unitPrice, newInv.warehouseName);
        }
      });
    }

    // Note: Supplier payable and bank/cash balances are updated atomically by postVoucher
    // (avoiding double counting). If an initial payment was posted with the invoice, also record it in supplierPayments.
    if (newInv.paidAmount > 0 && newInv.paymentVoucherNumber) {
      const initialPaymentRecord: SupplierPaymentRecord = {
        id: `sp-init-${newInv.id}`,
        paymentNumber: `SP-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        paymentDate: newInv.invoiceDate,
        supplierId: newInv.supplierId,
        supplierName: newInv.supplierName,
        invoiceId: newInv.id,
        invoiceNumber: newInv.invoiceNumber,
        amount: newInv.paidAmount,
        paymentMethod: newInv.paymentMethod === 'Cash' ? 'Cash' : 'Bank Transfer',
        bankAccountId: newInv.paidFromAccountId,
        bankName: newInv.paidFromAccountName,
        voucherId: newInv.paymentVoucherId,
        voucherNumber: newInv.paymentVoucherNumber,
        notes: `Initial payment on Direct Purchase Invoice ${newInv.invoiceNumber}`,
        status: 'Cleared',
        branch: newInv.branch || 'Dhaka Head Office',
        recordedBy: currentUser?.name || 'Accounts Dept'
      };
      setSupplierPayments(prev => {
        if (prev.some(p => p.id === initialPaymentRecord.id || p.voucherId === initialPaymentRecord.voucherId)) {
          return prev;
        }
        const next = [initialPaymentRecord, ...prev];
        try {
          localStorage.setItem('tradecore_supplier_payments_v1', JSON.stringify(next));
        } catch (err) {}
        return next;
      });
    }

    triggerToast(`✓ Direct Purchase Invoice ${newInv.invoiceNumber} created & stock inward auto-posted!`);
  };

  const handleUpdatePurchaseInvoice = (updatedInv: DirectPurchaseInvoice) => {
    const prevInv = purchaseInvoices.find(i => i.id === updatedInv.id);
    const updated = purchaseInvoices.map(i => i.id === updatedInv.id ? updatedInv : i);
    setPurchaseInvoices(updated);
    try {
      localStorage.setItem('tradecore_purchase_invoices_v1', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }

    // If invoice was voided via EditPurchaseInvoiceModal, revert stock and mark linked initial payment voided
    if (updatedInv.isVoided && prevInv && !prevInv.isVoided) {
      if (Array.isArray(prevInv.items)) {
        prevInv.items.forEach(item => {
          if (item.quantity > 0) {
            deductStockFromItem(item.itemId, item.quantity, prevInv.warehouseName);
          }
        });
      }
      // If legacy invoice had no purchaseVoucherId, reverse its dueAmount manually
      if (!prevInv.purchaseVoucherId && !prevInv.purchaseVoucherNumber && prevInv.dueAmount > 0) {
        updateSupplierPayableBalance(prevInv.supplierId, -prevInv.dueAmount);
      }
      triggerToast(`✓ Purchase Invoice ${updatedInv.invoiceNumber} voided & reversed!`);
      return;
    }

    triggerToast(`✓ Purchase Invoice ${updatedInv.invoiceNumber} updated!`);
  };

  const handleDeletePurchaseInvoice = (id: string) => {
    const target = purchaseInvoices.find(i => i.id === id);
    const updated = purchaseInvoices.filter(i => i.id !== id);
    setPurchaseInvoices(updated);
    try {
      localStorage.setItem('tradecore_purchase_invoices_v1', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }

    // Revert inventory stock (if not already voided)
    if (target && !target.isVoided && Array.isArray(target.items)) {
      target.items.forEach(item => {
        if (item.quantity > 0) {
          deductStockFromItem(item.itemId, item.quantity, target.warehouseName);
        }
      });
    }

    // Only adjust supplier payable manually for legacy pre-voucher invoices (posted vouchers are reversed by voidAccountTransaction)
    if (target && !target.isVoided && !target.purchaseVoucherId && !target.purchaseVoucherNumber && target.dueAmount > 0) {
      updateSupplierPayableBalance(target.supplierId, -target.dueAmount);
    }
    triggerToast(`✓ Purchase Invoice moved to Recycle Bin & stock reverted.`);
  };

  // Handler for Updating Supplier Payment
  const handleUpdateSupplierPayment = (updatedPay: SupplierPaymentRecord) => {
    const prevPay = supplierPayments.find(p => p.id === updatedPay.id);
    const updated = supplierPayments.map(p => p.id === updatedPay.id ? updatedPay : p);
    setSupplierPayments(updated);
    try {
      localStorage.setItem('tradecore_supplier_payments_v1', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }

    // If payment was voided via EditSupplierPaymentModal, restore linked invoice dueAmount
    if (prevPay && !prevPay.isVoided && (updatedPay.isVoided || updatedPay.status === 'Voided')) {
      if (updatedPay.invoiceId || updatedPay.invoiceNumber) {
        setPurchaseInvoices(prev => {
          const next = prev.map(inv => {
            if (inv.id === updatedPay.invoiceId || inv.invoiceNumber === updatedPay.invoiceNumber) {
              const newPaid = Math.max(0, inv.paidAmount - prevPay.amount);
              const newDue = Math.max(0, inv.grandTotal - newPaid);
              return {
                ...inv,
                paidAmount: newPaid,
                dueAmount: newDue,
                paymentStatus: (newDue <= 0 ? 'Paid' : newPaid > 0 ? 'Partial' : 'Unpaid') as DirectPurchaseInvoice['paymentStatus'],
                status: (newDue <= 0 ? 'Posted & In Stock' : 'Payment Pending') as DirectPurchaseInvoice['status']
              };
            }
            return inv;
          });
          try {
            localStorage.setItem('tradecore_purchase_invoices_v1', JSON.stringify(next));
          } catch (err) {}
          return next;
        });
      }
      // Only manually restore supplier payable if legacy payment had no voucherId
      if (!prevPay.voucherId) {
        updateSupplierPayableBalance(prevPay.supplierId, prevPay.amount);
      }
      triggerToast(`✓ Supplier Payment ${updatedPay.voucherNumber || updatedPay.paymentNumber} voided & reversed!`);
      return;
    }

    triggerToast(`✓ Supplier Payment ${updatedPay.voucherNumber || updatedPay.paymentNumber} updated successfully!`);
  };

  // Handler for Deleting Supplier Payment
  const handleDeleteSupplierPayment = (id: string) => {
    const target = supplierPayments.find(p => p.id === id);
    const updated = supplierPayments.filter(p => p.id !== id);
    setSupplierPayments(updated);
    try {
      localStorage.setItem('tradecore_supplier_payments_v1', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }

    // Revert payment on linked invoice (and supplier payable only if legacy record without voucherId)
    if (target && !target.isVoided && target.status !== 'Voided') {
      if (!target.voucherId) {
        updateSupplierPayableBalance(target.supplierId, target.amount);
      }

      if (target.invoiceId || target.invoiceNumber) {
        setPurchaseInvoices(prev => {
          const next = prev.map(inv => {
            if (inv.id === target.invoiceId || inv.invoiceNumber === target.invoiceNumber) {
              const newPaid = Math.max(0, inv.paidAmount - target.amount);
              const newDue = Math.max(0, inv.grandTotal - newPaid);
              return {
                ...inv,
                paidAmount: newPaid,
                dueAmount: newDue,
                paymentStatus: (newDue <= 0 ? 'Paid' : newPaid > 0 ? 'Partial' : 'Unpaid') as DirectPurchaseInvoice['paymentStatus'],
                status: (newDue <= 0 ? 'Posted & In Stock' : 'Payment Pending') as DirectPurchaseInvoice['status']
              };
            }
            return inv;
          });
          try {
            localStorage.setItem('tradecore_purchase_invoices_v1', JSON.stringify(next));
          } catch (err) {}
          return next;
        });
      }
    }
    triggerToast(`✓ Supplier Payment moved to Recycle Bin. Due balance restored.`);
  };

  // Listen to Recycle Bin restore events
  useEffect(() => {
    const handleRestoreEvent = (e: any) => {
      const detail = e.detail;
      if (detail && detail.action === 'restore' && detail.record) {
        const rec = detail.record;
        if (rec.recordType === 'purchase_invoice' && rec.data) {
          const inv: DirectPurchaseInvoice = rec.data;
          setPurchaseInvoices(prev => {
            if (prev.some(i => i.id === inv.id)) return prev;
            const next = [inv, ...prev];
            try {
              localStorage.setItem('tradecore_purchase_invoices_v1', JSON.stringify(next));
            } catch (err) {}
            return next;
          });
          triggerToast(`✓ Purchase Invoice ${inv.invoiceNumber} restored successfully!`);
        } else if (rec.recordType === 'supplier_payment' && rec.data) {
          const pay: SupplierPaymentRecord = rec.data;
          setSupplierPayments(prev => {
            if (prev.some(p => p.id === pay.id)) return prev;
            const next = [pay, ...prev];
            try {
              localStorage.setItem('tradecore_supplier_payments_v1', JSON.stringify(next));
            } catch (err) {}
            return next;
          });
          triggerToast(`✓ Supplier Payment ${pay.voucherNumber || pay.paymentNumber} restored!`);
        }
      }
    };

    window.addEventListener('tradecore_recycle_bin_changed', handleRestoreEvent);
    return () => window.removeEventListener('tradecore_recycle_bin_changed', handleRestoreEvent);
  }, []);

  // Handler for Recording New Supplier Payment
  const handleRecordSupplierPayment = (payment: SupplierPaymentRecord) => {
    const updatedPayments = [payment, ...supplierPayments];
    setSupplierPayments(updatedPayments);
    try {
      localStorage.setItem('tradecore_supplier_payments_v1', JSON.stringify(updatedPayments));
    } catch (e) {
      console.error(e);
    }

    // Update linked purchase invoice (if specified)
    if (payment.invoiceId || payment.invoiceNumber) {
      setPurchaseInvoices(prev => {
        const next = prev.map(inv => {
          if (inv.id === payment.invoiceId || inv.invoiceNumber === payment.invoiceNumber) {
            const newPaid = inv.paidAmount + payment.amount;
            const newDue = Math.max(0, inv.grandTotal - newPaid);
            const newPaymentStatus: DirectPurchaseInvoice['paymentStatus'] = 
              newDue <= 0 ? 'Paid' : (newPaid > 0 ? 'Partial' : 'Unpaid');
            return {
              ...inv,
              paidAmount: newPaid,
              dueAmount: newDue,
              paymentStatus: newPaymentStatus,
              paymentVoucherId: payment.voucherId || inv.paymentVoucherId,
              paymentVoucherNumber: payment.voucherNumber || inv.paymentVoucherNumber,
              status: (newDue <= 0 ? 'Posted & In Stock' : 'Payment Pending') as DirectPurchaseInvoice['status'],
              notes: `${inv.notes || ''} | [Payment of ৳${payment.amount.toLocaleString()} paid via ${payment.voucherNumber || payment.paymentNumber}]`
            };
          }
          return inv;
        });
        try {
          localStorage.setItem('tradecore_purchase_invoices_v1', JSON.stringify(next));
        } catch (e) {
          console.error(e);
        }
        return next;
      });
    }

    // Note: Supplier currentPayable and Bank/Cash balance are already updated atomically by postVoucher
    // (avoiding double counting).

    triggerToast(`✓ Supplier Payment ${payment.voucherNumber || payment.paymentNumber} of ৳${payment.amount.toLocaleString()} recorded!`);
  };

  // Core Data States
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([
    {
      id: 'po-101',
      poNumber: 'PO-2026-0112',
      supplierId: 'supp-201',
      supplierName: 'Baosteel International Trading Corp',
      lcNumber: 'LC-2026-CH-0042',
      poDate: '2026-08-05',
      expectedDelivery: '2026-09-15',
      currency: 'USD',
      items: [
        { itemId: 'item-301', itemName: 'Hot Rolled Prime Steel Coils', quantity: 300, unitPrice: 650, totalPrice: 195000 }
      ],
      totalAmount: 195000,
      status: 'GRN Received'
    },
    {
      id: 'po-102',
      poNumber: 'PO-2026-0118',
      supplierId: 'supp-202',
      supplierName: 'Sabic Petrochemicals Middle East',
      lcNumber: 'LC-2026-CH-0089',
      poDate: '2026-08-25',
      expectedDelivery: '2026-10-10',
      currency: 'USD',
      items: [
        { itemId: 'item-302', itemName: 'HDPE Virgin Resin Pellets', quantity: 200, unitPrice: 1225, totalPrice: 245000 }
      ],
      totalAmount: 245000,
      status: 'Approved'
    },
    {
      id: 'po-103',
      poNumber: 'PO-2026-0125',
      supplierId: 'supp-203',
      supplierName: 'Karnaphuli C&F and Logistics Services',
      poDate: '2026-09-10',
      expectedDelivery: '2026-09-20',
      currency: 'BDT',
      items: [
        { itemId: 'srv-01', itemName: 'Customs Clearance & Handling Services', quantity: 1, unitPrice: 85000, totalPrice: 85000 }
      ],
      totalAmount: 85000,
      status: 'Approved'
    }
  ]);

  const [grns, setGrns] = useState<GRN[]>(MOCK_GRNS);
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => getSuppliers());
  const [lcs, setLcs] = useState<LetterOfCredit[]>(() => {
    let baseList: LetterOfCredit[] = [];
    try {
      const saved = localStorage.getItem('tradecore_lcs_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const knownIds = new Set(parsed.map((l: any) => l.id));
          for (const mockLc of MOCK_LCS) {
            if (!knownIds.has(mockLc.id) && (mockLc.lcNumber === 'LC-2026-SB-155' || mockLc.lcNumber === 'LC-2026-SB-602')) {
              parsed.push(mockLc);
            }
          }
          baseList = parsed.map((l: LetterOfCredit) => ({
            ...l,
            expenses: Array.isArray(l.expenses) ? l.expenses : [],
            marginPercent: l.marginPercent !== undefined ? l.marginPercent : (l.marginDepositPercent ?? 0),
            marginAmountBDT: l.marginAmountBDT !== undefined ? l.marginAmountBDT : (l.marginAmountLocal ?? 0),
            marginVoucherId: l.marginVoucherId || l.marginTransactionId,
            marginVoucherNo: l.marginVoucherNo
          }));
        }
      }
    } catch (e) {
      console.error('Failed to load LCs', e);
    }
    if (baseList.length === 0) {
      baseList = MOCK_LCS.map(l => ({
        ...l,
        expenses: Array.isArray(l.expenses) ? l.expenses : [],
        marginPercent: l.marginPercent !== undefined ? l.marginPercent : (l.marginDepositPercent ?? 0),
        marginAmountBDT: l.marginAmountBDT !== undefined ? l.marginAmountBDT : (l.marginAmountLocal ?? 0),
        marginVoucherId: l.marginVoucherId || l.marginTransactionId,
        marginVoucherNo: l.marginVoucherNo
      }));
    }
    return reconcileAndHealLcExpenses(baseList, getAccountTransactions()).lcs;
  });
  const [soilClaims, setSoilClaims] = useState<SoilClaimRecord[]>(MOCK_SOIL_CLAIMS);
  const [khataPayments, setKhataPayments] = useState<KhataPaymentRecord[]>(MOCK_KHATA_PAYMENTS);

  // Initialize selectedLc from persisted selection or LC with most recent expense activity (never static MOCK_LCS[0])
  const [selectedLc, setSelectedLc] = useState<LetterOfCredit>(() => {
    try {
      const savedSelectedId = localStorage.getItem('tradecore_selected_lc_id_v1');
      if (savedSelectedId) {
        const matched = lcs.find(l => l.id === savedSelectedId);
        if (matched) return matched;
      }
    } catch {}
    // Default to the LC with the most recent expense/voucher activity, or lcs[0]
    let bestLc = lcs[0] || MOCK_LCS[0];
    let bestTime = -1;
    for (const candidate of lcs) {
      const exps = candidate.expenses || [];
      if (exps.length > 0) {
        for (const exp of exps) {
          const ts = new Date((exp as any).postedAt || exp.paymentDate || 0).getTime() || exps.length;
          if (ts > bestTime) {
            bestTime = ts;
            bestLc = candidate;
          }
        }
      }
    }
    return bestLc;
  });

  const lcsRef = useRef<LetterOfCredit[]>(lcs);
  useEffect(() => {
    lcsRef.current = lcs;
  }, [lcs]);

  // Remember selected LC ID across page refreshes
  useEffect(() => {
    if (selectedLc?.id) {
      try {
        localStorage.setItem('tradecore_selected_lc_id_v1', selectedLc.id);
      } catch {}
    }
  }, [selectedLc?.id]);

  // Always keep selectedLc synchronized with the latest matching LC record in `lcs`
  useEffect(() => {
    if (!selectedLc) return;
    const latest = lcs.find(l => l.id === selectedLc.id);
    if (latest && latest !== selectedLc) {
      setSelectedLc(latest);
    }
  }, [lcs, selectedLc]);

  // Subscribe to AccountTransactions and Firestore letters_of_credit to self-heal missing LC expenses automatically
  useEffect(() => {
    const unsubTxns = subscribeAccountTransactions((txns) => {
      setLcs(prev => {
        const result = reconcileAndHealLcExpenses(prev, txns);
        return result.changed ? result.lcs : prev;
      });
    });
    const unsubFirestoreLcs = subscribeFirestoreLcs(
      () => lcsRef.current,
      (mergedLcs) => {
        setLcs(mergedLcs);
      }
    );
    const handleLcsEvent = (e: Event) => {
      const custom = e as CustomEvent;
      if (custom.detail?.lcs && Array.isArray(custom.detail.lcs)) {
        setLcs(custom.detail.lcs);
      }
    };
    window.addEventListener('tradecore_lcs_changed', handleLcsEvent);
    return () => {
      unsubTxns();
      unsubFirestoreLcs();
      window.removeEventListener('tradecore_lcs_changed', handleLcsEvent);
    };
  }, []);

  // Sync suppliers from localStorage/event listener
  useEffect(() => {
    const unsubscribe = subscribeSuppliers((updatedSuppliers) => {
      setSuppliers(updatedSuppliers);
    });
    return () => unsubscribe();
  }, []);

  // Modals & Alerts
  const [showPOModal, setShowPOModal] = useState(false);
  const [showNewLcModal, setShowNewLcModal] = useState(false);
  const [showAddSupplierModal, setShowAddSupplierModal] = useState(false);
  const [supplierToEdit, setSupplierToEdit] = useState<Supplier | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New PO form states
  const [selectedSupplier, setSelectedSupplier] = useState('');
  const [selectedItem, setSelectedItem] = useState('');
  const [poQty, setPoQty] = useState(0);
  const [poRate, setPoRate] = useState(0);
  const [poLcRef, setPoLcRef] = useState('');

  // New LC Form state
  const [newLcNumber, setNewLcNumber] = useState('');
  const [initialNewLcNumber, setInitialNewLcNumber] = useState('');
  const [newLcSupplier, setNewLcSupplier] = useState('');
  const [newLcCompanyOwner, setNewLcCompanyOwner] = useState('');
  const [newLcBank, setNewLcBank] = useState('');
  const [newLcOpeningDate, setNewLcOpeningDate] = useState(new Date().toISOString().split('T')[0]);
  const [newLcMaturityDate, setNewLcMaturityDate] = useState('');
  const [newLcStatus, setNewLcStatus] = useState<LCStatus>('' as any);
  const [newLcType, setNewLcType] = useState<LCType>('' as any);
  const [newLcCfr, setNewLcCfr] = useState(0);
  const [newLcMargin, setNewLcMargin] = useState<number | string>('');
  const [newLcCommodity, setNewLcCommodity] = useState('');
  const [newLcBorderLandPort, setNewLcBorderLandPort] = useState('');

  // Requirement 1 & 2: Margin Account & Opening Charges states
  const [newLcMarginPaidFromAccountId, setNewLcMarginPaidFromAccountId] = useState<string>('');
  const [newLcMarginPaymentDate, setNewLcMarginPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [newLcOpeningCharges, setNewLcOpeningCharges] = useState<string>('');
  const [newLcOpeningChargeHeadName, setNewLcOpeningChargeHeadName] = useState<string>('');
  const [isSavingNewLc, setIsSavingNewLc] = useState<boolean>(false);
  const isCreatingLcRef = useRef<boolean>(false);
  const [newLcError, setNewLcError] = useState<string | null>(null);
  const [newLcOverdraftApproved, setNewLcOverdraftApproved] = useState<boolean>(false);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState<boolean>(false);
  const [accountSearchTerm, setAccountSearchTerm] = useState<string>('');
  const accountDropdownRef = useRef<HTMLDivElement>(null);

  // Requirement 4: Post Margin modal for existing LCs
  const [marginModalLc, setMarginModalLc] = useState<LetterOfCredit | null>(null);
  const [postMarginAccountId, setPostMarginAccountId] = useState<string>('');
  const [postMarginDate, setPostMarginDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [postMarginMode, setPostMarginMode] = useState<'post_voucher' | 'mark_external'>('post_voucher');
  const [postMarginExternalReason, setPostMarginExternalReason] = useState<string>('');
  const [isSavingPostMargin, setIsSavingPostMargin] = useState<boolean>(false);
  const isPostingMarginRef = useRef<boolean>(false);
  const [postMarginError, setPostMarginError] = useState<string | null>(null);
  const [isPostMarginDropdownOpen, setIsPostMarginDropdownOpen] = useState<boolean>(false);
  const [postMarginAccountSearch, setPostMarginAccountSearch] = useState<string>('');
  const postMarginDropdownRef = useRef<HTMLDivElement>(null);

  // Requirement 3: Admin Cancel LC modal state
  const [cancelModalLc, setCancelModalLc] = useState<LetterOfCredit | null>(null);
  const [cancelLcReason, setCancelLcReason] = useState<string>('');
  const [isCancellingLc, setIsCancellingLc] = useState<boolean>(false);
  const [cancelLcError, setCancelLcError] = useState<string | null>(null);

  // Voucher Print Modal state
  const [selectedTxnForView, setSelectedTxnForView] = useState<AccountTransaction | null>(null);

  const handleOpenVoucher = (voucherNo?: string, transactionId?: string) => {
    if (!voucherNo && !transactionId) return;
    const allTxns = getAccountTransactions();
    let found = allTxns.find(t => (transactionId && t.id === transactionId) || (voucherNo && t.voucherNo === voucherNo));
    if (found) {
      setSelectedTxnForView(found);
    } else if (voucherNo) {
      const relLc = lcs.find(l => l.marginVoucherNo === voucherNo);
      setSelectedTxnForView({
        id: transactionId || `txn-${voucherNo}`,
        voucherNo: voucherNo,
        date: relLc?.marginPaymentDate || relLc?.openingDate || new Date().toISOString().split('T')[0],
        transactionType: 'PAYMENT',
        subType: 'LC Margin Deposit',
        amount: relLc?.marginAmountLocal || 0,
        bankAccountId: relLc?.marginPaidFromAccountId || 'acc-1',
        bankAccountName: relLc?.marginPaidFromAccountName || 'Bank Account',
        paymentMethod: 'Bank Transfer',
        particulars: `LC Margin Deposit - LC ${relLc?.lcNumber || ''}`,
        status: 'active',
        createdAt: new Date().toISOString()
      } as any);
    }
  };

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (accountDropdownRef.current && !accountDropdownRef.current.contains(e.target as Node)) {
        setIsAccountDropdownOpen(false);
      }
      if (postMarginDropdownRef.current && !postMarginDropdownRef.current.contains(e.target as Node)) {
        setIsPostMarginDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Quantity, Currency, Dual-Pricing states (Bank LC Rate vs Actual Rate & Hundi Gap)
  const [newLcQuantity, setNewLcQuantity] = useState<number>(0);
  const [newLcQtyInput, setNewLcQtyInput] = useState<string>('');
  const [newLcUom, setNewLcUom] = useState<string>('');
  const [newLcCurrency, setNewLcCurrency] = useState<'USD' | 'INR'>('' as any);
  const [newLcExchangeRate, setNewLcExchangeRate] = useState<number>(0);
  const [newLcExchangeRateInput, setNewLcExchangeRateInput] = useState<string>('');
  const [newLcInrRate, setNewLcInrRate] = useState<number>(0);
  const [newLcInrRateInput, setNewLcInrRateInput] = useState<string>('');
  const [newLcOfficialRate, setNewLcOfficialRate] = useState<number>(0);
  const [newLcOfficialRateInput, setNewLcOfficialRateInput] = useState<string>('');
  const [newLcActualRate, setNewLcActualRate] = useState<number>(0);
  const [newLcActualRateInput, setNewLcActualRateInput] = useState<string>('');
  const [showLcOpeningChargesBox, setShowLcOpeningChargesBox] = useState<boolean>(false);
  const [showLcNotesBox, setShowLcNotesBox] = useState<boolean>(false);
  const [newLcNotes, setNewLcNotes] = useState<string>('');

  const sanitizeDecimalInput = (raw: string): string => {
    const cleaned = raw.replace(/[^0-9.]/g, '');
    const parts = cleaned.split('.');
    if (parts.length > 2) {
      return parts[0] + '.' + parts.slice(1).join('');
    }
    return cleaned;
  };

  const resetNewLcForm = () => {
    setNewLcNumber('');
    setInitialNewLcNumber('');
    setNewLcSupplier('');
    setNewLcCompanyOwner('');
    setNewLcBank('');
    const today = new Date().toISOString().split('T')[0];
    setNewLcOpeningDate(today);
    setNewLcMaturityDate('');
    setNewLcStatus('' as any);
    setNewLcType('' as any);
    setNewLcCfr(0);
    setNewLcMargin('');
    setNewLcCommodity('');
    setNewLcBorderLandPort('');
    setNewLcQuantity(0);
    setNewLcQtyInput('');
    setNewLcUom('');
    setNewLcCurrency('' as any);
    setNewLcExchangeRate(0);
    setNewLcExchangeRateInput('');
    setNewLcInrRate(0);
    setNewLcInrRateInput('');
    setNewLcOfficialRate(0);
    setNewLcOfficialRateInput('');
    setNewLcActualRate(0);
    setNewLcActualRateInput('');
    setNewLcMarginPaidFromAccountId('');
    setNewLcMarginPaymentDate(today);
    setNewLcOpeningCharges('');
    setNewLcOpeningChargeHeadName('');
    setShowLcOpeningChargesBox(false);
    setShowLcNotesBox(false);
    setNewLcNotes('');
    setNewLcOverdraftApproved(false);
    setNewLcError(null);
    setIsAccountDropdownOpen(false);
    setAccountSearchTerm('');
    isCreatingLcRef.current = false;
    setIsSavingNewLc(false);
  };

  const openNewLcModal = () => {
    resetNewLcForm();
    setShowNewLcModal(true);
  };

  const handleCloseNewLcModal = () => {
    resetNewLcForm();
    setShowNewLcModal(false);
  };

  const isNewLcDirty =
    newLcNumber !== initialNewLcNumber ||
    newLcSupplier !== '' ||
    newLcCompanyOwner !== '' ||
    newLcBank !== '' ||
    newLcMaturityDate !== '' ||
    Boolean(newLcType) ||
    String(newLcMargin) !== '' ||
    newLcCommodity !== '' ||
    newLcBorderLandPort !== '' ||
    newLcQuantity !== 0 ||
    newLcUom !== '' ||
    Boolean(newLcCurrency) ||
    newLcExchangeRate !== 0 ||
    newLcOfficialRate !== 0 ||
    newLcActualRate !== 0 ||
    newLcOpeningCharges !== '' ||
    newLcOpeningChargeHeadName !== '' ||
    newLcOverdraftApproved;

  const handleCloseMarginModal = () => {
    setMarginModalLc(null);
    setPostMarginAccountId('');
    setPostMarginError(null);
    setPostMarginMode('post_voucher');
    setPostMarginExternalReason('');
    setIsPostMarginDropdownOpen(false);
    setPostMarginAccountSearch('');
    isPostingMarginRef.current = false;
    setIsSavingPostMargin(false);
  };

  const handleCloseCancelLcModal = () => {
    setCancelModalLc(null);
    setCancelLcReason('');
    setCancelLcError(null);
    setIsCancellingLc(false);
  };

  // Auto-sync company owner when LC supplier changes
  const handleLcSupplierSelect = (supplierName: string) => {
    setNewLcSupplier(supplierName);
    const matched = suppliers.find(s => s.name === supplierName);
    if (matched?.companyOwner) {
      setNewLcCompanyOwner(matched.companyOwner);
    }
  };

  // Expiry Alert Engine State
  const [showExpiryModal, setShowExpiryModal] = useState(false);
  const [acknowledgedAlertIds, setAcknowledgedAlertIds] = useState<string[]>([]);
  const [isUrgentExpiryFiltered, setIsUrgentExpiryFiltered] = useState(false);

  // Prevent background scroll and cursor freeze when New LC modal or Alert modal is open
  useEffect(() => {
    if (showNewLcModal || showExpiryModal) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow || 'unset';
      };
    }
  }, [showNewLcModal, showExpiryModal]);

  // Live LC Expiry Alerts
  const lcExpiryAlerts = useMemo(() => {
    return generateLCExpiryAlerts(lcs, acknowledgedAlertIds);
  }, [lcs, acknowledgedAlertIds]);

  const criticalAlertsCount = lcExpiryAlerts.filter(a => a.severity === 'critical' || a.severity === 'expired').length;

  const handleAcknowledgeAlert = (alertId: string) => {
    setAcknowledgedAlertIds(prev => [...prev, alertId]);
    triggerToast('✓ Alert acknowledged.');
  };

  const handleApplyAmendment = (lcId: string, newShipmentDate: string, newExpiryDate: string) => {
    setLcs(prevLcs => prevLcs.map(item => {
      if (item.id === lcId) {
        return {
          ...item,
          shipmentExpiryDate: newShipmentDate,
          lcExpiryDate: newExpiryDate,
          status: item.status === 'Discrepant' ? 'Confirmed' : item.status
        };
      }
      return item;
    }));
    triggerToast(`✓ Bank Amendment applied: Shipment extended to ${newShipmentDate}, LC Expiry extended to ${newExpiryDate}`);
  };

  // Sync initialTab when props change
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Purchase Order Creation
  const handleCreatePO = (e: React.FormEvent) => {
    e.preventDefault();
    const supp = suppliers.find(s => s.id === selectedSupplier);
    const itm = MOCK_ITEMS.find(i => i.id === selectedItem);
    if (!supp || !itm) return;

    const total = poQty * poRate;
    const newPO: PurchaseOrder = {
      id: `po-${Date.now()}`,
      poNumber: `PO-2026-0${126 + purchaseOrders.length}`,
      supplierId: supp.id,
      supplierName: supp.name,
      lcNumber: poLcRef || undefined,
      poDate: new Date().toISOString().split('T')[0],
      expectedDelivery: '2026-10-25',
      currency: supp.country === 'Bangladesh' ? 'BDT' : 'USD',
      items: [
        {
          itemId: itm.id,
          itemName: itm.name,
          quantity: poQty,
          unitPrice: poRate,
          totalPrice: total
        }
      ],
      totalAmount: total,
      status: 'Approved'
    };

    setPurchaseOrders([newPO, ...purchaseOrders]);
    setShowPOModal(false);
    triggerToast(`✓ Purchase Order ${newPO.poNumber} created for ${supp.name}`);
  };

  // Open New LC (Requirement 1 & 2: Deduct Margin & Opening Charges via Real Voucher)
  const handleCreateLC = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isCreatingLcRef.current) return;
    setNewLcError(null);

    const normalizedLcNumber = (newLcNumber || '').trim().toUpperCase();
    if (!normalizedLcNumber) {
      setNewLcError('LC number is required.');
      return;
    }

    // Synchronous unique LC check
    const existingConflict = lcs.find(l => 
      !l.isVoided && l.status !== 'Voided' && 
      (l.normalizedLcNumber || l.lcNumber.trim().toUpperCase()) === normalizedLcNumber
    );
    if (existingConflict) {
      setNewLcError(`LC number "${newLcNumber.trim()}" already exists. LC numbers must be unique.`);
      return;
    }

    const calculatedOfficialTotal = newLcQuantity * newLcOfficialRate;
    const calculatedOfficialTotalBdt = calculatedOfficialTotal * newLcExchangeRate;
    const marginPercentNum = typeof newLcMargin === 'number'
      ? newLcMargin
      : (newLcMargin === '' ? NaN : parseFloat(String(newLcMargin)));

    if (isNaN(marginPercentNum) || marginPercentNum < 0 || marginPercentNum > 100) {
      setNewLcError('Margin percentage must be a valid number between 0% and 100%.');
      return;
    }

    const calculatedMarginAmountBdt = Math.round((calculatedOfficialTotalBdt * marginPercentNum) / 100);
    const openingChargesNum = parseFloat(String(newLcOpeningCharges)) || 0;
    const totalOpeningDeductionBdt = (marginPercentNum > 0 ? calculatedMarginAmountBdt : 0) + openingChargesNum;

    if (marginPercentNum > 0 && !newLcMarginPaidFromAccountId) {
      setNewLcError('Please select a Bank or Cash account for Margin payment.');
      return;
    }

    if (marginPercentNum === 0 && openingChargesNum > 0 && !newLcMarginPaidFromAccountId) {
      setNewLcError('Please select a Bank or Cash account for Opening Charges payment.');
      return;
    }

    const selectedMarginAccount = newLcMarginPaidFromAccountId
      ? bankAccounts.find(a => a.id === newLcMarginPaidFromAccountId)
      : undefined;

    if (totalOpeningDeductionBdt > 0 && !selectedMarginAccount) {
      setNewLcError('Selected account could not be found in the database.');
      return;
    }

    const isMarginAccountCash = isCashAccount(selectedMarginAccount);

    const isMarginAccountOverdraft = selectedMarginAccount && !isMarginAccountCash && (selectedMarginAccount.ledgerBalance || 0) < totalOpeningDeductionBdt;

    if (selectedMarginAccount && isMarginAccountCash && (selectedMarginAccount.ledgerBalance || 0) < totalOpeningDeductionBdt) {
      setNewLcError(
        `Insufficient cash balance in ${selectedMarginAccount.bankName}. Required: ৳${totalOpeningDeductionBdt.toLocaleString()}, Current: ৳${(selectedMarginAccount.ledgerBalance || 0).toLocaleString()}. Negative cash balance is prohibited.`
      );
      return;
    }

    if (isMarginAccountOverdraft && !isAdmin) {
      setNewLcError(
        `Insufficient bank balance (Current: ৳${(selectedMarginAccount?.ledgerBalance || 0).toLocaleString()}, Required: ৳${totalOpeningDeductionBdt.toLocaleString()}). Only an Administrator can authorize overdraft.`
      );
      return;
    }

    if (isMarginAccountOverdraft && isAdmin && !newLcOverdraftApproved) {
      setNewLcError(
        'Insufficient bank balance. Please check the authorization box below to approve overdraft.'
      );
      return;
    }

    // Set synchronous lock BEFORE any await
    isCreatingLcRef.current = true;
    setIsSavingNewLc(true);

    try {
      const calculatedActualTotal = newLcQuantity * newLcActualRate;
      const diffRate = Math.max(0, newLcActualRate - newLcOfficialRate);
      const calculatedDiffAmount = newLcQuantity * diffRate;
      const calculatedDiffBdt = calculatedDiffAmount * newLcExchangeRate;
      const isIndia = newLcSupplier.includes('India');
      const matchedSupp = suppliers.find(s => s.name === newLcSupplier || s.id === newLcSupplier);
      const finalOwner = newLcCompanyOwner.trim() || matchedSupp?.companyOwner || undefined;

      // 1. Build Base LC Record
      const newRecordData: LetterOfCredit = {
        id: `lc-${Date.now()}`,
        lcNumber: newLcNumber.trim(),
        normalizedLcNumber,
        bankReference: `EBL/CGP/IMP/2026/0${lcs.length + 95}`,
        issuingBank: newLcBank,
        branch: selectedMarginAccount?.branch || 'Corporate Principal Branch',
        supplierId: matchedSupp ? matchedSupp.id : 'supp-201',
        supplierName: matchedSupp ? matchedSupp.name : newLcSupplier,
        companyOwner: finalOwner,
        beneficiaryCountry: isIndia ? 'India' : (matchedSupp?.country || 'Bhutan'),
        borderLandPort: newLcBorderLandPort,
        boulderCategory: 'Boulder Stone',
        originQuarryItem: newLcCommodity,
        lcType: newLcType,
        currency: newLcCurrency,
        exchangeRate: newLcExchangeRate,
        quantity: newLcQuantity,
        uom: newLcUom,
        officialLcRate: newLcOfficialRate,
        actualRate: newLcActualRate,
        contractRateUsd: newLcActualRate,
        lcBankRateUsd: newLcOfficialRate,
        rateDifference: diffRate,
        officialLcTotal: calculatedOfficialTotal,
        actualTotalAmount: calculatedActualTotal,
        differentialAmount: calculatedDiffAmount,
        differentialAmountBdt: calculatedDiffBdt,
        differentialSettledAmount: 0,
        differentialSettlementStatus: calculatedDiffAmount > 0 ? 'Unsettled' : 'Fully Settled',
        differentialPayments: [],
        rateBatches: [
          {
            id: `rb-${Date.now()}-1`,
            batchName: '1st Batch (Original Agreement)',
            quantity: newLcQuantity,
            uom: newLcUom,
            officialRate: newLcOfficialRate,
            actualRate: newLcActualRate,
            rateDifference: diffRate,
            totalCommercialAmount: calculatedActualTotal,
            totalOfficialAmount: calculatedOfficialTotal,
            differentialAmount: calculatedDiffAmount,
            notes: 'Initial contractual rate',
            date: newLcOpeningDate
          }
        ],
        bankSettlements: [],
        hundiPayments: [],
        receivedQtyMt: 0,
        receivedQuantity: 0,
        remainingQuantity: newLcQuantity,
        receivings: [],
        totalBillUsd: 0,
        rateBdt: 0,
        usdBalance: 0,
        bdtBalanceAmount: 0,
        fobAmount: calculatedOfficialTotal * 0.95,
        cfrAmount: calculatedOfficialTotal,
        marginPercent: marginPercentNum,
        marginAmountBDT: calculatedMarginAmountBdt,
        marginDepositPercent: marginPercentNum,
        marginAmountLocal: calculatedMarginAmountBdt,
        openingDate: newLcOpeningDate || new Date().toISOString().split('T')[0],
        shipmentExpiryDate: newLcMaturityDate ? new Date(new Date(newLcMaturityDate).getTime() - 10 * 86400000).toISOString().split('T')[0] : '2026-11-20',
        lcExpiryDate: newLcMaturityDate || '2026-12-15',
        maturityDate: newLcMaturityDate || '2026-12-15',
        piNumber: `PI-${Math.floor(Math.random() * 90000 + 10000)}`,
        boeNumber: '',
        blNumber: '',
        portOfLoading: isIndia ? 'Fulbari / Kolkata, India' : 'Phuentsholing / Samtse, Bhutan',
        portOfDischarge: `${newLcBorderLandPort} Land Port, Bangladesh`,
        status: newLcStatus,
        items: [
          {
            itemId: 'item-301',
            itemName: newLcCommodity,
            hsCode: '2517.10.00',
            quantity: newLcQuantity,
            uom: newLcUom,
            unitPriceForeign: newLcOfficialRate,
            totalForeign: calculatedOfficialTotal,
            assessmentValueUnit: newLcOfficialRate * newLcExchangeRate
          }
        ],
        expenses: []
      };

      // 2. Atomic LC creation, margin voucher, balance deduction, registry entry in ONE transaction
      const atomicResult = await createLetterOfCreditAtomic({
        lcData: newRecordData,
        bankAccountId: selectedMarginAccount?.id,
        marginPaymentDate: newLcMarginPaymentDate || newLcOpeningDate,
        openingChargesNum,
        openingChargeHeadName: newLcOpeningChargeHeadName || 'Bank Charges & LC Commission',
        user: {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || 'Authorized Officer',
          email: currentUser?.email || 'admin@tradecore.local'
        },
        adminApprovedOverdraft: Boolean(isMarginAccountOverdraft && isAdmin && newLcOverdraftApproved),
        allLcs: lcs
      });

      const nextLcs = [atomicResult.createdLc, ...lcs];
      setLcs(nextLcs);
      try {
        localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs));
      } catch (e) {}
      setSelectedLc(atomicResult.createdLc);
      setShowNewLcModal(false);
      setBankAccounts(getBankAccounts());

      const postedMarginVoucherNo = atomicResult.createdLc.marginVoucherNo;
      triggerToast(
        postedMarginVoucherNo && selectedMarginAccount
          ? `✓ Import LC ${atomicResult.createdLc.lcNumber} opened! Margin voucher ${postedMarginVoucherNo} posted to ${selectedMarginAccount.bankName}.`
          : `✓ Import LC ${atomicResult.createdLc.lcNumber} opened successfully!`
      );
    } catch (err: any) {
      setNewLcError(err?.message || 'Failed to open LC or post margin voucher.');
    } finally {
      isCreatingLcRef.current = false;
      setIsSavingNewLc(false);
    }
  };

  // Add LC from Tracker component (Requirement 5: Remove hardcoded 15% & 118.50, empty expenses, clean 0s)
  const handleAddLcFromTracker = (data: {
    lcNumber: string;
    issuingBank: string;
    maturityDate: string;
    status: LCStatus;
    supplierName: string;
    lcType: LCType;
    cfrAmount: number;
    commodity: string;
    borderLandPort?: string;
    quantity?: number;
    uom?: string;
    currency?: 'USD' | 'INR' | string;
    exchangeRate?: number;
    officialLcRate?: number;
    actualRate?: number;
    rateDifference?: number;
    differentialAmount?: number;
    differentialAmountBdt?: number;
    marginDepositPercent?: number;
  }) => {
    const qty = data.quantity || 1000;
    const exRate = data.exchangeRate || 122.50;
    const offRate = data.officialLcRate || 14.00;
    const actRate = data.actualRate || 18.00;
    const cfr = data.cfrAmount || (qty * offRate);
    const marginPct = data.marginDepositPercent || 15;
    const marginAmount = Math.round((cfr * exRate * marginPct) / 100);
    const diffRate = Math.max(0, actRate - offRate);
    const diffAmt = data.differentialAmount ?? (qty * diffRate);
    const diffBdt = data.differentialAmountBdt ?? (diffAmt * exRate);

    const newRecord: LetterOfCredit = {
      id: `lc-${Date.now()}`,
      lcNumber: data.lcNumber,
      bankReference: `REF/IMP/2026/0${lcs.length + 90}`,
      issuingBank: data.issuingBank,
      branch: 'Corporate Principal Branch',
      supplierId: 'supp-201',
      supplierName: data.supplierName,
      beneficiaryCountry: 'Overseas',
      borderLandPort: data.borderLandPort || 'Burimari',
      boulderCategory: 'Boulder Stone',
      originQuarryItem: data.commodity,
      lcType: data.lcType,
      currency: (data.currency as any) || 'USD',
      exchangeRate: exRate,
      quantity: qty,
      uom: data.uom || 'MT',
      officialLcRate: offRate,
      actualRate: actRate,
      contractRateUsd: actRate,
      lcBankRateUsd: offRate,
      rateDifference: diffRate,
      officialLcTotal: cfr,
      actualTotalAmount: qty * actRate,
      differentialAmount: diffAmt,
      differentialAmountBdt: diffBdt,
      differentialSettledAmount: 0,
      differentialSettlementStatus: diffAmt > 0 ? 'Unsettled' : 'Fully Settled',
      differentialPayments: [],
      rateBatches: [
        {
          id: `rb-${Date.now()}-1`,
          batchName: 'Lot 1 (Initial Contract)',
          quantity: qty,
          uom: data.uom || 'MT',
          officialRate: offRate,
          actualRate: actRate,
          rateDifference: diffRate,
          totalCommercialAmount: qty * actRate,
          totalOfficialAmount: cfr,
          differentialAmount: diffAmt,
          notes: 'Initial agreed contract rate',
          date: new Date().toISOString().split('T')[0]
        }
      ],
      bankSettlements: [],
      hundiPayments: [],
      receivedQtyMt: 0,
      receivedQuantity: 0,
      remainingQuantity: qty,
      receivings: [],
      totalBillUsd: 0,
      rateBdt: 0,
      usdBalance: 0,
      bdtBalanceAmount: 0,
      fobAmount: cfr * 0.95,
      cfrAmount: cfr,
      marginDepositPercent: marginPct,
      marginAmountLocal: marginAmount,
      marginStatus: 'unposted',
      openingDate: new Date().toISOString().split('T')[0],
      shipmentExpiryDate: '2026-11-20',
      lcExpiryDate: data.maturityDate,
      maturityDate: data.maturityDate,
      piNumber: `PI-${Math.floor(Math.random() * 90000 + 10000)}`,
      boeNumber: '',
      blNumber: '',
      portOfLoading: 'Port of Origin',
      portOfDischarge: `${data.borderLandPort || 'Burimari'} Land Port, Bangladesh`,
      status: data.status,
      items: [
        {
          itemId: 'item-301',
          itemName: data.commodity,
          hsCode: '2517.10.00',
          quantity: qty,
          uom: data.uom || 'MT',
          unitPriceForeign: offRate,
          totalForeign: cfr,
          assessmentValueUnit: offRate * exRate
        }
      ],
      expenses: []
    };

    const nextLcs = [newRecord, ...lcs];
    setLcs(nextLcs);
    try {
      localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs));
    } catch (e) {}
    setSelectedLc(newRecord);
    triggerToast(`✓ Documentary Credit ${data.lcNumber} recorded! (Margin not posted)`);
  };

  // Requirement 4: Post Margin for existing LCs handler
  const handlePostExistingMargin = async () => {
    if (!marginModalLc) return;
    if (isPostingMarginRef.current) return;
    setPostMarginError(null);

    const marginPercent = marginModalLc.marginPercent !== undefined ? marginModalLc.marginPercent : (marginModalLc.marginDepositPercent ?? 15);
    const calculatedMarginBdt = computeExpectedLcMarginBDT({ ...marginModalLc, marginPercent });
    const marginAmt = marginModalLc.marginAmountBDT !== undefined ? marginModalLc.marginAmountBDT : (marginModalLc.marginAmountLocal || calculatedMarginBdt);

    if (postMarginMode === 'mark_external') {
      if (!postMarginExternalReason.trim()) {
        setPostMarginError('Please provide a reason for marking as external / opening balance.');
        return;
      }

      const updatedLc: LetterOfCredit = {
        ...marginModalLc,
        marginPercent,
        marginAmountBDT: marginAmt,
        marginDepositPercent: marginPercent,
        marginAmountLocal: marginAmt,
        marginStatus: 'external',
        marginManualReason: postMarginExternalReason.trim(),
        marginPostedBy: currentUser?.name || 'Admin',
        marginPostedAt: new Date().toISOString()
      };

      const nextLcs = lcs.map(l => l.id === updatedLc.id ? updatedLc : l);
      setLcs(nextLcs);
      try { localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs)); } catch (e) {}
      if (selectedLc.id === updatedLc.id) setSelectedLc(updatedLc);
      setMarginModalLc(null);
      triggerToast(`✓ LC ${updatedLc.lcNumber} margin marked as external / opening balance.`);
      return;
    }

    // Post Voucher Mode (Requirement 4: uses postLcMargin)
    if (!postMarginAccountId) {
      setPostMarginError('Please select a bank or cash account.');
      return;
    }

    const selectedAcc = bankAccounts.find(a => a.id === postMarginAccountId);
    if (!selectedAcc) {
      setPostMarginError('Selected account not found.');
      return;
    }

    isPostingMarginRef.current = true;
    setIsSavingPostMargin(true);

    try {
      const result = await postLcMargin({
        lc: marginModalLc,
        bankAccountId: selectedAcc.id,
        paymentDate: postMarginDate,
        marginPercent,
        marginAmountBDT: marginAmt,
        user: {
          uid: currentUser?.uid || 'user-admin',
          name: currentUser?.name || 'Authorized Officer',
          email: currentUser?.email || 'admin@tradecore.local'
        },
        adminApprovedOverdraft: Boolean(isAdmin && (Number(selectedAcc.ledgerBalance) || 0) < marginAmt),
        allLcs: lcs
      });

      const nextLcs = lcs.map(l => l.id === result.updatedLc.id ? result.updatedLc : l);
      setLcs(nextLcs);
      try { localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs)); } catch (e) {}
      if (selectedLc.id === result.updatedLc.id) setSelectedLc(result.updatedLc);
      setMarginModalLc(null);
      setBankAccounts(getBankAccounts());
      triggerToast(`✓ LC ${result.updatedLc.lcNumber} margin voucher ${result.transaction.voucherNo} posted successfully!`);
    } catch (err: any) {
      setPostMarginError(err?.message || 'Failed to post margin voucher.');
    } finally {
      isPostingMarginRef.current = false;
      setIsSavingPostMargin(false);
    }
  };

  // Requirement 6: Admin Correct by reversal handler
  const handleCorrectMarginByReversal = async (lc: LetterOfCredit, bankAccountId: string, reason: string) => {
    const result = await reverseAndCorrectLcMargin({
      lc,
      bankAccountId,
      reason,
      user: {
        uid: currentUser?.uid || 'user-admin',
        name: currentUser?.name || 'Authorized Officer',
        email: currentUser?.email || 'admin@tradecore.local'
      },
      allLcs: lcs
    });

    const nextLcs = lcs.map(l => l.id === result.updatedLc.id ? result.updatedLc : l);
    setLcs(nextLcs);
    try { localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs)); } catch (e) {}
    if (selectedLc.id === result.updatedLc.id) setSelectedLc(result.updatedLc);
    setBankAccounts(getBankAccounts());
    triggerToast(`✓ Margin for LC ${lc.lcNumber} corrected via reversal voucher ${result.reversalTxn.voucherNo} and corrected voucher ${result.correctedTxn.voucherNo}!`);
    return result;
  };

  // Part 3 Admin Actions: Void Duplicate LC
  const handleVoidDuplicateLc = async (lc: LetterOfCredit, reason: string) => {
    const result = await voidDuplicateLc({
      lc,
      reason,
      user: {
        uid: currentUser?.uid || 'user-admin',
        name: currentUser?.name || 'Admin',
        email: currentUser?.email
      }
    });

    const nextLcs = lcs.map(l => l.id === result.voidedLc.id ? result.voidedLc : l);
    setLcs(nextLcs);
    try { localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs)); } catch (e) {}
    if (selectedLc.id === result.voidedLc.id) setSelectedLc(result.voidedLc);
    setBankAccounts(getBankAccounts());
    triggerToast(`✓ Duplicate LC ${lc.lcNumber} voided and margin reversed (${result.reversalTxn?.voucherNo || 'N/A'}).`);
    return result;
  };

  // Part 3 Admin Actions: Reverse Voucher
  const handleReverseVoucher = async (voucher: AccountTransaction, reason: string) => {
    const result = await reverseVoucher({
      voucher,
      reason,
      user: {
        uid: currentUser?.uid || 'user-admin',
        name: currentUser?.name || 'Admin',
        email: currentUser?.email
      }
    });
    setBankAccounts(getBankAccounts());
    triggerToast(`✓ Voucher ${voucher.voucherNo} reversed by ${result.reversalTxn.voucherNo}. Bank balance restored.`);
    return result;
  };

  // Requirement 3: Admin Cancel LC handler
  const handleConfirmCancelLc = async () => {
    if (!cancelModalLc) return;
    if (!cancelLcReason.trim()) {
      setCancelLcError('Reason is required to cancel LC.');
      return;
    }

    setIsCancellingLc(true);
    setCancelLcError(null);

    try {
      let revVoucherNo: string | undefined = undefined;

      // If opening margin voucher exists, reverse it
      if (cancelModalLc.marginTransactionId) {
        try {
          await voidAccountTransaction(
            cancelModalLc.marginTransactionId,
            `LC ${cancelModalLc.lcNumber} Cancellation: ${cancelLcReason.trim()}`,
            {
              uid: currentUser?.uid || 'admin',
              name: currentUser?.name || 'Admin',
              email: currentUser?.email
            }
          );
          revVoucherNo = `REV-${cancelModalLc.marginVoucherNo}`;
        } catch (vErr) {
          console.warn('Failed to void transaction doc directly, proceeding with LC cancellation:', vErr);
        }
      }

      const updatedLc: LetterOfCredit = {
        ...cancelModalLc,
        status: 'Cancelled',
        isCancelled: true,
        cancelReason: cancelLcReason.trim(),
        cancelledAt: new Date().toISOString(),
        cancelledBy: currentUser?.name || 'Admin',
        cancelVoucherNo: revVoucherNo || (cancelModalLc.marginVoucherNo ? `REV-${cancelModalLc.marginVoucherNo}` : undefined)
      };

      const nextLcs = lcs.map(l => l.id === updatedLc.id ? updatedLc : l);
      setLcs(nextLcs);
      try { localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs)); } catch (e) {}
      if (selectedLc.id === updatedLc.id) setSelectedLc(updatedLc);
      setCancelModalLc(null);
      triggerToast(`✓ LC ${updatedLc.lcNumber} cancelled and margin reversed successfully.`);
    } catch (err: any) {
      setCancelLcError(err?.message || 'Failed to cancel LC.');
    } finally {
      setIsCancellingLc(false);
    }
  };

  const handleUpdateLc = async (lcId: string, updatedFields: Partial<LetterOfCredit>) => {
    if (updatedFields.lcNumber) {
      const targetLc = lcs.find(l => l.id === lcId);
      if (targetLc && updatedFields.lcNumber.trim().toUpperCase() !== (targetLc.normalizedLcNumber || targetLc.lcNumber.trim().toUpperCase())) {
        try {
          const claimedNorm = await validateAndClaimEditedLcNumber(
            updatedFields.lcNumber,
            targetLc.lcNumber,
            lcId,
            lcs
          );
          updatedFields = {
            ...updatedFields,
            lcNumber: updatedFields.lcNumber.trim(),
            normalizedLcNumber: claimedNorm
          };
        } catch (err: any) {
          triggerToast(`Error: ${err?.message || 'LC number already exists'}`);
          return;
        }
      }
    }

    setLcs(prev => {
      const next = prev.map(item => {
        if (item.id === lcId) {
          const updated = { ...item, ...updatedFields };
          if (selectedLc.id === lcId) {
            setSelectedLc(updated);
          }
          return updated;
        }
        return item;
      });
      try { localStorage.setItem('tradecore_lcs_v1', JSON.stringify(next)); } catch (e) {}
      return next;
    });
    triggerToast(`✓ LC details updated successfully!`);
  };

  // Add or Update Expense on LC (Requirement 1, 5)
  const handleUpdateLcExpenses = (
    lcId: string,
    newExp: {
      id?: string;
      expenseType: string;
      amountLocal: number;
      paidTo: string;
      status: 'Paid' | 'Billed' | 'Invoiced' | 'Estimated' | 'Voided';
      voucherNo?: string;
      lcId?: string;
      paymentDate?: string;
      paidFromAccountId?: string;
      paidFromAccountName?: string;
      paymentMethod?: string;
      referenceNo?: string;
      transactionId?: string;
      postedBy?: {
        uid: string;
        name: string;
        email?: string;
      } | string;
      postedAt?: string;
    }
  ) => {
    setLcs(prev => {
      const nextLcs = prev.map(item => {
        if (item.id === lcId) {
          const currentExpenses = item.expenses || [];
          const matchPred = (e: any) =>
            (newExp.id && e.id === newExp.id) ||
            (newExp.transactionId && e.transactionId && e.transactionId === newExp.transactionId) ||
            (newExp.voucherNo && e.voucherNo && e.voucherNo === newExp.voucherNo);

          const resolvedId = newExp.id || (newExp.transactionId ? `exp-${newExp.transactionId}` : `exp-${Date.now()}`);
          const expenseRecord = {
            ...newExp,
            id: resolvedId,
            lcId
          };

          const updatedExpenses = currentExpenses.some(matchPred)
            ? currentExpenses.map(e => (matchPred(e) ? { ...e, ...expenseRecord } : e))
            : [expenseRecord, ...currentExpenses];

          const updated = { ...item, expenses: updatedExpenses };
          return updated;
        }
        return item;
      });

      // Update selected LC (Requirement 1: switch page to chosen LC)
      const targetLc = nextLcs.find(l => l.id === lcId);
      if (targetLc) {
        setSelectedLc(targetLc);
        try {
          localStorage.setItem('tradecore_selected_lc_id_v1', targetLc.id);
        } catch {}
      }
      try {
        localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs));
      } catch (e) {
        console.error(e);
      }

      // Durably persist to Firestore letters_of_credit/{lcId} as well
      persistLcExpenseDurable(lcId, newExp, nextLcs).catch(() => {});

      return nextLcs;
    });

    triggerToast(`✓ Capitalized expense "${newExp.expenseType}" (৳${newExp.amountLocal.toLocaleString()}) to LC inventory valuation!`);
  };

  const handleSettleBill = (lcId: string, note: string) => {
    setLcs(prev => {
      const nextLcs = prev.map(item => {
        if (item.id === lcId) {
          const progress = computeLCProgressAndStatus(item);
          const updated = { ...item, status: progress.computedStatus };
          if (selectedLc.id === lcId) setSelectedLc(updated);
          return updated;
        }
        return item;
      });
      try {
        localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs));
      } catch (e) {}
      return nextLcs;
    });
    triggerToast(`✓ ${note}`);
  };

  const handleUpdateFullLc = (updatedLc: LetterOfCredit) => {
    const progress = computeLCProgressAndStatus(updatedLc);
    const finalLc: LetterOfCredit = {
      ...updatedLc,
      status: progress.computedStatus
    };
    setLcs(prev => {
      const nextLcs = prev.map(item => item.id === finalLc.id ? finalLc : item);
      try {
        localStorage.setItem('tradecore_lcs_v1', JSON.stringify(nextLcs));
      } catch (e) {}
      return nextLcs;
    });
    setSelectedLc(finalLc);
    triggerToast(`✓ LC ${finalLc.lcNumber} updated successfully.`);
  };

  interface SubModuleItem {
    id: PurchaseSubTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    count?: number;
    highlight?: boolean;
  }

  interface SubModuleGroup {
    groupName: string;
    items: SubModuleItem[];
  }

  // Sub-module navigation list with categories
  const SUB_MODULE_GROUPS: SubModuleGroup[] = [
    {
      groupName: 'Executive Dashboard & Overview',
      items: [
        { id: 'overview', label: 'Purchase Dashboard & Statistics', icon: LayoutDashboard, count: undefined, highlight: true },
      ]
    },
    {
      groupName: 'Letter of Credit (LC) & Cross-Border Imports',
      items: [
        { id: 'lc_status_summary', label: 'Status Summary', icon: LayoutDashboard, count: lcs.length, highlight: true },
        { id: 'lc_product_receiving', label: 'LC Product Receiving', icon: ArrowDownToLine, count: undefined, highlight: true },
        { id: 'lc_exporter_bills', label: 'LC / Exporter Bills & Settlement', icon: Receipt, count: undefined },
        { id: 'lc_balance_sheet', label: 'LC Balance Sheet & Khata', icon: FileSpreadsheet, count: lcs.length, highlight: true },
        { id: 'lc_owner_report', label: 'Company Owner Wise LC Report', icon: Users, count: undefined, highlight: true },
        { id: 'lc_register', label: 'LC Register & Instruments', icon: FileText, count: lcs.length },
        { id: 'lc_tracking', label: 'LC Tracking & Workflow', icon: Ship, count: lcs.length },
        { id: 'lc_expenses', label: 'LC Expenses & Landed Cost', icon: Calculator, count: undefined },
      ]
    },
    {
      groupName: 'Domestic & Store Procurement',
      items: [
        { id: 'purchase_invoice', label: 'Direct Purchase Invoices', icon: Receipt, count: purchaseInvoices.length },
        { id: 'supplier_payments', label: 'All Payments Report', icon: CreditCard, count: supplierPayments.length },
        { id: 'supplier_profiles', label: 'Supplier Profile', icon: Building2, count: suppliers.length },
        { id: 'suppliers', label: 'Supplier Ledger', icon: FileText, count: suppliers.length },
        { id: 'grn', label: 'Goods Received (GRN)', icon: Truck, count: grns.length },
      ]
    }
  ];

  const ALL_SUB_ITEMS = SUB_MODULE_GROUPS.flatMap(g => g.items);
  const activeSubItem = ALL_SUB_ITEMS.find(i => i.id === activeTab || (activeTab === 'po' && i.id === 'purchase_invoice')) || ALL_SUB_ITEMS[0];

  const isLcTab = activeTab.startsWith('lc_');

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SLEEK, EXECUTIVE-GRADE MODULE HEADER                                      */}
      {/* Context-aware, minimalist, zero-slop layout for high-end enterprise UX   */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3.5">
          {/* Left: Context Breadcrumb & Editorial Section Title */}
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-500 flex-wrap">
              <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                {isLcTab ? (
                  <>
                    <Ship className="w-3.5 h-3.5 text-blue-600" />
                    <span>LC & Import Hub</span>
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-3.5 h-3.5 text-slate-800" />
                    <span>Purchase & Store</span>
                  </>
                )}
              </span>
              <span className="text-slate-300">/</span>
              <span className="text-slate-600 font-semibold">
                {activeTab === 'overview' && 'Dashboard & Analytics'}
                {activeTab === 'purchase_invoice' && 'Invoices'}
                {activeTab === 'supplier_payments' && 'Payments'}
                {activeTab === 'supplier_profiles' && 'Supplier Profile'}
                {(activeTab === 'suppliers' || activeTab === 'payables') && 'Supplier Ledger'}
                {activeTab === 'grn' && 'Goods Received (GRN)'}
                {activeTab === 'po' && 'Purchase Orders'}
                {activeTab === 'lc_status_summary' && 'Status Summary'}
                {activeTab === 'lc_product_receiving' && 'Border Receiving'}
                {activeTab === 'lc_tracking' && 'LC Tracking'}
                {activeTab === 'lc_balance_sheet' && 'Balance Sheet'}
                {activeTab === 'lc_owner_report' && 'Owner Wise LC Report'}
                {activeTab === 'lc_register' && 'LC Register'}
                {activeTab === 'lc_expenses' && 'Landed Cost'}
                {activeTab === 'lc_exporter_bills' && 'Exporter Bills'}
              </span>

              {/* Quiet Micro-KPI Strip (Single-line zero-pill metadata) */}
              <span className="hidden md:inline-block text-slate-300">·</span>
              <span className="hidden md:flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                {isLcTab ? (
                  <>
                    <span>Active LCs: <strong className="text-slate-800">{lcs.length}</strong></span>
                    <span>·</span>
                    <span>Port: <strong className="text-slate-800">{currentBranch === 'Sonahat Office' ? 'Sonahat Land Port' : 'Burimari Land Port'}</strong></span>
                  </>
                ) : (
                  <>
                    <span>Suppliers: <strong className="text-slate-800">{suppliers.length}</strong></span>
                    <span>·</span>
                    <span>Unpaid Dues: <strong className="text-rose-600">BDT {(quickPurchaseStats.totalUnpaidAmount / 100000).toFixed(2)}L</strong></span>
                    <span>·</span>
                    <span>Today: <strong className="text-slate-800">{quickPurchaseStats.todayCount} Invoices (BDT {(quickPurchaseStats.todayTotalAmount / 1000).toFixed(0)}k)</strong></span>
                  </>
                )}
              </span>
            </div>

            {/* Main Title Line */}
            <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span>
                {activeTab === 'overview' && 'Purchase Executive Dashboard'}
                {activeTab === 'purchase_invoice' && 'Direct Purchase Invoices'}
                {activeTab === 'supplier_payments' && 'Supplier Payments Register'}
                {activeTab === 'supplier_profiles' && 'Supplier Profile & Company Registry'}
                {(activeTab === 'suppliers' || activeTab === 'payables') && 'Supplier Ledger & Accounts'}
                {activeTab === 'grn' && 'Goods Received Notes (GRN)'}
                {activeTab === 'po' && 'Purchase Orders'}
                {activeTab === 'lc_status_summary' && 'LC Lifecycle Status Summary'}
                {activeTab === 'lc_product_receiving' && 'LC Product Receiving'}
                {activeTab === 'lc_tracking' && 'Documentary Credit Tracking'}
                {activeTab === 'lc_balance_sheet' && 'LC Balance Sheet & Khata'}
                {activeTab === 'lc_owner_report' && 'Company Owner Wise LC Report'}
                {activeTab === 'lc_register' && 'LC Register & Portfolios'}
                {activeTab === 'lc_expenses' && 'LC Landed Cost & Customs Duty'}
                {activeTab === 'lc_exporter_bills' && 'LC / Exporter Bills & Settlement'}
              </span>
            </h1>
          </div>

          {/* Right: Context-Aware Executive Action Controls */}
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            {isLcTab ? (
              <>
                {/* LC Alerts Button */}
                <button
                  type="button"
                  onClick={() => setShowExpiryModal(true)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer ${
                    criticalAlertsCount > 0
                      ? 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100'
                      : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-200'
                  }`}
                  title="LC Expiry & Shipment Maturity Alerts"
                >
                  <Bell className={`w-3.5 h-3.5 ${criticalAlertsCount > 0 ? 'text-rose-600 animate-pulse' : 'text-slate-500'}`} />
                  <span>LC Alerts</span>
                  {lcExpiryAlerts.length > 0 && (
                    <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full font-bold ${
                      criticalAlertsCount > 0 ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {lcExpiryAlerts.length}
                    </span>
                  )}
                </button>

                {/* Add Exporter / Supplier in LC Mode */}
                <button
                  type="button"
                  onClick={() => setShowAddSupplierModal(true)}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  title="Add new exporter or supplier"
                >
                  <Building2 className="w-3.5 h-3.5 text-indigo-600" />
                  <span>+ Add Exporter</span>
                </button>

                {/* Direct Mal Receive Button (If not already on receiving tab) */}
                {activeTab !== 'lc_product_receiving' && (
                  <button
                    type="button"
                    onClick={() => setActiveTab('lc_product_receiving')}
                    className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  >
                    <ArrowDownToLine className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Product Receiving & Stock</span>
                  </button>
                )}

                {/* Primary: Open New Import LC */}
                <button
                  type="button"
                  onClick={openNewLcModal}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4 text-emerald-400" />
                  <span>+ Open Import LC</span>
                </button>
              </>
            ) : (
              <>
                {/* Add Supplier Button (Prominent in Purchase Module) */}
                <button
                  type="button"
                  onClick={() => setShowAddSupplierModal(true)}
                  className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer border border-slate-700"
                  title="Add New Supplier or Exporter Company"
                >
                  <Plus className="w-4 h-4 text-emerald-400" />
                  <span>+ Add Supplier</span>
                </button>

                {/* Pay Supplier Button */}
                <button
                  type="button"
                  onClick={() => {
                    setPreselectedInvoiceForPayment(null);
                    setIsPaymentModalOpen(true);
                    setActiveTab('supplier_payments');
                  }}
                  className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                  <span>+ Pay Supplier</span>
                </button>

                {/* Primary: New Purchase Invoice */}
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('purchase_invoice');
                    setShowCreateInvoiceModal(true);
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4 text-[#def645]" />
                  <span>+ New Purchase Invoice</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* LC Module Sub-Navigation Bar */}
        {isLcTab && (
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto">
            {(
              [
                { id: 'lc_status_summary', label: 'Status Summary' },
                { id: 'lc_product_receiving', label: 'LC Product Receiving' },
                { id: 'lc_tracking', label: 'LC Tracking & Workflow' },
                { id: 'lc_balance_sheet', label: 'LC Balance Sheet & Khata' },
                { id: 'lc_owner_report', label: 'Owner Wise LC Report' },
                { id: 'lc_register', label: 'LC Register & Instruments' },
                { id: 'lc_expenses', label: 'LC Expenses & Landed Cost' },
                { id: 'lc_exporter_bills', label: 'Exporter Bills & Settlement' }
              ] as { id: PurchaseSubTab; label: string }[]
            ).map(tabItem => (
              <button
                key={tabItem.id}
                type="button"
                onClick={() => setActiveTab(tabItem.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === tabItem.id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {tabItem.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ==================== SUB-CATEGORY VIEWS ==================== */}

      {/* View 0: Executive Purchase Dashboard & Analytics */}
      {activeTab === 'overview' && (
        <PurchaseOverviewDashboard
          invoices={displayedPurchaseInvoices}
          payments={supplierPayments}
          suppliers={suppliers}
          lcs={lcs}
          onNavigateTab={(tab) => setActiveTab(tab)}
          onOpenNewInvoiceModal={() => {
            setActiveTab('purchase_invoice');
            setShowCreateInvoiceModal(true);
          }}
          onOpenPaymentModal={(suppId, inv) => {
            if (suppId) setSelectedSupplierForKhata(suppId);
            setPreselectedInvoiceForPayment(inv || null);
            setIsPaymentModalOpen(true);
            setActiveTab('supplier_payments');
          }}
          onViewInvoiceSlip={(inv) => {
            setSelectedPrintInvoice(inv);
          }}
          onOpenSupplierKhata={(suppId) => {
            setSelectedSupplierForKhata(suppId);
            setActiveTab('suppliers');
          }}
          currentBranch={currentBranch}
        />
      )}

      {/* View 1: Direct Purchase Invoices */}
      {(activeTab === 'purchase_invoice' || activeTab === 'po') && (
        <DirectPurchaseInvoiceView
          invoices={displayedPurchaseInvoices}
          suppliers={suppliers}
          lcs={lcs}
          recentPayments={supplierPayments}
          onCreateInvoice={handleCreatePurchaseInvoice}
          onUpdateInvoice={handleUpdatePurchaseInvoice}
          onDeleteInvoice={handleDeletePurchaseInvoice}
          onOpenAddSupplierModal={() => setShowAddSupplierModal(true)}
          onSelectLc={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_expenses');
          }}
          onOpenPaymentModal={(suppId, inv) => {
            if (suppId) setSelectedSupplierForKhata(suppId);
            setPreselectedInvoiceForPayment(inv || null);
            setIsPaymentModalOpen(true);
            setActiveTab('supplier_payments');
          }}
          onOpenSupplierKhata={(suppId) => {
            setSelectedSupplierForKhata(suppId);
            setActiveTab('suppliers');
          }}
          onNavigateToPayments={() => setActiveTab('supplier_payments')}
          isCreateModalOpenExternal={showCreateInvoiceModal}
          onCloseCreateModal={() => setShowCreateInvoiceModal(false)}
          currentBranch={currentBranch}
        />
      )}

      {/* View: Supplier Payments */}
      {activeTab === 'supplier_payments' && (
        <SupplierPaymentList
          payments={supplierPayments}
          suppliers={suppliers}
          invoices={purchaseInvoices}
          onRecordNewPayment={handleRecordSupplierPayment}
          onUpdatePayment={handleUpdateSupplierPayment}
          onDeletePayment={handleDeleteSupplierPayment}
          preselectedInvoice={preselectedInvoiceForPayment}
          isCreateModalOpenExternal={isPaymentModalOpen}
          onCloseCreateModal={() => {
            setIsPaymentModalOpen(false);
            setPreselectedInvoiceForPayment(null);
          }}
          onViewSupplierLedger={(suppId) => {
            setSelectedSupplierForKhata(suppId);
            setActiveTab('suppliers');
          }}
          onViewInvoice={(invNum) => {
            const found = purchaseInvoices.find(i => i.invoiceNumber === invNum);
            if (found) {
              setSelectedPrintInvoice(found);
            } else {
              setActiveTab('purchase_invoice');
            }
          }}
        />
      )}

      {/* View 2: Goods Received Notes (GRN) */}
      {activeTab === 'grn' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Goods Received Notes (GRN) & Quality Clearance</h2>
            </div>
            <span className="text-xs font-mono bg-emerald-50 text-emerald-700 border border-emerald-200 px-3 py-1 rounded-xl font-bold">
              Quality Assurance: Active
            </span>
          </div>

          <div className="space-y-3">
            {grns.map((grn) => (
              <div key={grn.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-blue-800 text-sm">{grn.grnNumber}</span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                      QA: {grn.qualityCheckStatus}
                    </span>
                    <span className="text-[10px] bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded-full">
                      Status: {grn.status}
                    </span>
                  </div>
                  <div className="text-slate-500 text-[11px] font-mono">
                    Received: {grn.receivedDate} | Challan: {grn.challanNo}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-600 bg-white p-3 rounded-lg border border-slate-200/80">
                  <div>
                    <span className="text-slate-400 block">Warehouse Location:</span>
                    <span className="font-semibold text-slate-800">{grn.warehouseId.toUpperCase()} Bonded Yard</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Linked PO / Reference:</span>
                    <span className="font-mono font-bold text-slate-800">{grn.poNumber}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Received Quantity:</span>
                    <span className="font-mono font-bold text-slate-900">{grn.items[0]?.receivedQty} MT</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-200">
                  <span className="text-slate-500">Item: <strong>{grn.items[0]?.itemName}</strong></span>
                  <span className="text-emerald-700 font-bold">100% Weighed at Port Weighbridge</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* LC Expiry Alert Notification Ribbon (Active on all LC-related views) */}
      {isLcTab && (
        <LCExpiryAlertBanner
          alerts={lcExpiryAlerts}
          onOpenAlertModal={() => setShowExpiryModal(true)}
          onFilterUrgent={() => {
            setIsUrgentExpiryFiltered(prev => !prev);
            if (activeTab !== 'lc_register') {
              setActiveTab('lc_register');
            }
          }}
          isUrgentFiltered={isUrgentExpiryFiltered}
        />
      )}

      {/* View 0.5: LC Lifecycle Status Summary Dashboard (D3.js) */}
      {activeTab === 'lc_status_summary' && (
        <LCStatusSummaryDashboard
          lcs={lcs}
          currentBranch={currentBranch}
          onSelectLc={(lc) => setSelectedLc(lc)}
          onNavigateToReceiving={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_product_receiving');
          }}
          onNavigateToExpenses={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_expenses');
          }}
          onNavigateToBills={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_exporter_bills');
          }}
          onOpenNewLcModal={openNewLcModal}
        />
      )}

      {/* View 1: LC Balance Sheet & Khata Ledger */}
      {activeTab === 'lc_balance_sheet' && (
        <LCBalanceSheetView
          lcs={lcs}
          initialSoilClaims={soilClaims}
          initialKhataPayments={khataPayments}
          onSelectLc={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_expenses');
            triggerToast(`Opening details & Landed Cost for ${lc.lcNumber}`);
          }}
        />
      )}

      {/* View 2: LC Tracking (Documentary Credit Tracker) */}
      {activeTab === 'lc_tracking' && (
        <DocumentaryCreditTracker
          lcs={lcs}
          onAddLc={handleAddLcFromTracker}
          onUpdateLc={handleUpdateLc}
          onSelectLcForCosting={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_expenses');
            triggerToast(`Opened Landed Cost & Customs Engine for ${lc.lcNumber}`);
          }}
          onSelectLcForReceiving={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_product_receiving');
            triggerToast(`Opening border product receiving & stock entry for ${lc.lcNumber}`);
          }}
          onNavigateToReceiving={() => setActiveTab('lc_product_receiving')}
        />
      )}

      {/* View 3: Company Owner Wise LC Report */}
      {activeTab === 'lc_owner_report' && (
        <CompanyOwnerLcReport
          lcs={lcs}
          suppliers={suppliers}
          onSelectLc={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_balance_sheet');
          }}
          onOpenExpenses={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_expenses');
          }}
          onOpenBills={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_exporter_bills');
          }}
        />
      )}

      {/* View 4: LC Register */}
      {activeTab === 'lc_register' && (
        <LCRegisterView
          lcs={lcs}
          suppliers={suppliers}
          onSelectLc={(lc) => setSelectedLc(lc)}
          onOpenExpenses={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_expenses');
            triggerToast(`Opened Landed Cost Sheet for ${lc.lcNumber}`);
          }}
          onOpenBills={(lc) => {
            setSelectedLc(lc);
            setActiveTab('lc_exporter_bills');
            triggerToast(`Opened Exporter Commercial Bill for ${lc.lcNumber}`);
          }}
          onOpenCreateModal={openNewLcModal}
          onOpenAlertModal={() => setShowExpiryModal(true)}
          onOpenAmendment={(lcId) => {
            const target = lcs.find(l => l.id === lcId);
            if (target) {
              setSelectedLc(target);
              setShowExpiryModal(true);
            }
          }}
          defaultExpiryFilter={isUrgentExpiryFiltered ? 'CRITICAL' : 'ALL'}
          onPostMargin={(lc) => {
            setMarginModalLc(lc);
            setPostMarginAccountId('');
            setPostMarginDate(new Date().toISOString().split('T')[0]);
            setPostMarginError(null);
            setPostMarginMode('post_voucher');
            setPostMarginExternalReason('');
          }}
          onCancelLc={(lc) => {
            setCancelModalLc(lc);
            setCancelLcReason('');
            setCancelLcError(null);
          }}
          onOpenVoucher={handleOpenVoucher}
          onCorrectByReversal={handleCorrectMarginByReversal}
          onVoidDuplicateLc={handleVoidDuplicateLc}
          onReverseVoucher={handleReverseVoucher}
          bankAccounts={accessibleAccounts}
        />
      )}

      {/* View 5: LC Expenses & Landed Cost Engine */}
      {activeTab === 'lc_expenses' && (
        <LCExpensesView
          lcs={lcs}
          selectedLc={selectedLc}
          onSelectLc={(lc) => setSelectedLc(lc)}
          onUpdateLcExpenses={handleUpdateLcExpenses}
          onNavigateToBills={() => setActiveTab('lc_exporter_bills')}
          onPostMargin={(lc) => {
            setMarginModalLc(lc);
            setPostMarginAccountId('');
            setPostMarginDate(new Date().toISOString().split('T')[0]);
            setPostMarginError(null);
            setPostMarginMode('post_voucher');
            setPostMarginExternalReason('');
          }}
        />
      )}

      {/* View 6: LC / Exporter Bills & Settlement */}
      {activeTab === 'lc_exporter_bills' && (
        <LCExporterBillsView
          lcs={lcs}
          selectedLc={selectedLc}
          onSelectLc={(lc) => setSelectedLc(lc)}
          onUpdateLc={handleUpdateFullLc}
          onSettleBill={handleSettleBill}
          onNavigateToExpenses={() => setActiveTab('lc_expenses')}
        />
      )}

      {/* View 6.5: LC Product Receiving & Daily Border Stock Sector */}
      {activeTab === 'lc_product_receiving' && (
        <LCProductReceivingSector
          lcs={lcs}
          selectedLc={selectedLc}
          onSelectLc={(lc) => setSelectedLc(lc)}
          onUpdateLc={handleUpdateFullLc}
          onAddStockReceiving={(rec) => {
            addStockToItem(rec.itemId || rec.itemName, rec.receivedQty, rec.unitCostBdt, rec.warehouseId || rec.warehouseName);
          }}
          currentBranch={currentBranch}
        />
      )}

      {/* View: Supplier Profile */}
      {activeTab === 'supplier_profiles' && (
        <SupplierProfilesView
          suppliers={suppliers}
          onAddSupplier={() => {
            setSupplierToEdit(null);
            setShowAddSupplierModal(true);
          }}
          onEditSupplier={(supp) => {
            setSupplierToEdit(supp);
            setShowAddSupplierModal(true);
          }}
          onViewKhata={(supplierId) => {
            setSelectedSupplierForKhata(supplierId);
            setActiveTab('suppliers');
          }}
          onMakePayment={(supplierId) => {
            setSelectedSupplierForKhata(supplierId);
            setIsPaymentModalOpen(true);
            setActiveTab('supplier_payments');
          }}
          onCreateInvoice={(supplierId) => {
            setSelectedSupplier(supplierId);
            setShowCreateInvoiceModal(true);
          }}
        />
      )}

      {/* View 7: Supplier Ledger & Payables */}
      {(activeTab === 'suppliers' || activeTab === 'payables') && (
        <SupplierKhataReport
          suppliers={suppliers}
          invoices={purchaseInvoices}
          payments={supplierPayments}
          selectedSupplierId={selectedSupplierForKhata}
          initialTab={activeTab === 'payables' ? 'payables' : undefined}
          onSelectSupplier={setSelectedSupplierForKhata}
          onOpenAddSupplierModal={() => {
            setSupplierToEdit(null);
            setShowAddSupplierModal(true);
          }}
          onOpenPaymentModal={(suppId, inv) => {
            if (suppId) setSelectedSupplierForKhata(suppId);
            setPreselectedInvoiceForPayment(inv || null);
            setIsPaymentModalOpen(true);
            setActiveTab('supplier_payments');
          }}
          onOpenNewInvoiceModal={(suppId) => {
            setSelectedSupplier(suppId);
            setActiveTab('purchase_invoice');
            setShowCreateInvoiceModal(true);
          }}
          onEditSupplier={(supp) => {
            setSupplierToEdit(supp);
            setShowAddSupplierModal(true);
          }}
        />
      )}

      {/* ==================== MODALS ==================== */}

      {/* Modal: Open Import LC — Clean Minimal Invoice-Style UI (Desktop + Responsive Mobile) */}
      {showNewLcModal && (() => {
        const softInputClass =
          'bg-[#f3f5f8] border border-transparent rounded-[8px] text-[#1e293b] transition-all duration-150 hover:bg-[#eef1f6] focus:bg-white focus:border-[#135bec] focus:ring-[3px] focus:ring-[#135bec]/10 outline-none';

        const sym = newLcCurrency === 'INR' ? '₹' : '$';
        const qty = newLcQuantity;
        const bankRate = newLcOfficialRate;
        const actualRate = newLcActualRate;
        const exRate = newLcExchangeRate;
        const inrRate = newLcInrRate;
        const marginPct = Math.min(100, Math.max(0, parseFloat(String(newLcMargin)) || 0));
        const charges = showLcOpeningChargesBox ? (parseFloat(String(newLcOpeningCharges)) || 0) : 0;

        const diffPerUnit = Math.max(0, actualRate - bankRate);

        // 1. Bank LC Total
        const bankTotalForeign = qty * bankRate;
        const bankTotalBdt = bankTotalForeign * exRate;

        // 2. Actual Contract Total
        const actualTotalForeign = qty * actualRate;
        const actualTotalBdt = actualTotalForeign * exRate;

        // 3. Unofficial / Diff / Hundi
        const diffTotalForeign = qty * diffPerUnit;
        const diffTotalBdt = diffTotalForeign * exRate;
        const diffInr = inrRate > 0 ? diffTotalBdt / inrRate : 0;

        // Margin & Bank Deductions
        const marginBdt = Math.round((bankTotalBdt * marginPct) / 100);
        const totalDeductionBdt = (marginPct > 0 ? marginBdt : 0) + Math.round(charges);
        const deferredLcDueBdt = Math.max(0, Math.round(bankTotalBdt) - marginBdt);

        const selectedAcc = bankAccounts.find(a => a.id === newLcMarginPaidFromAccountId);
        const accountBalance = selectedAcc ? (selectedAcc.ledgerBalance || 0) : 0;
        const remainingBalance = accountBalance - totalDeductionBdt;
        const isCash = isCashAccount(selectedAcc);
        const isOverdraft = Boolean(selectedAcc && accountBalance < totalDeductionBdt);

        const isSubmitDisabled =
          isSavingNewLc ||
          newLcMargin === '' ||
          parseFloat(String(newLcMargin)) < 0 ||
          parseFloat(String(newLcMargin)) > 100 ||
          (marginPct > 0 && !newLcMarginPaidFromAccountId) ||
          (marginPct === 0 && charges > 0 && !newLcMarginPaidFromAccountId);

        const applyMarginPreset = (pct: number) => {
          setNewLcMargin(String(pct));
        };

        return (
          <ModalWrapper
            isOpen={showNewLcModal}
            onClose={handleCloseNewLcModal}
            isDirty={isNewLcDirty}
            isSaving={isSavingNewLc}
            className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs overflow-y-auto overscroll-contain flex min-h-full items-start md:items-center justify-center p-2 sm:p-4 lg:p-6"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              onWheel={(e) => e.stopPropagation()}
              className="w-full max-w-[1380px] bg-[#f4f6f9] text-[#1e293b] p-3 sm:p-6 lg:p-10 rounded-[24px] md:rounded-[28px] shadow-[0_20px_50px_rgba(15,23,42,0.18)] border border-white/80 my-auto relative"
            >
              <datalist id="lc-commodity-presets">
                <option value="S-Samtse Boulder" />
                <option value="P-Phuentsholing Boulder" />
                <option value="R-Indian River Stone Boulder" />
              </datalist>

              <form
                onSubmit={handleCreateLC}
                autoComplete="off"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (isSavingNewLc || isCreatingLcRef.current)) {
                    e.preventDefault();
                  }
                }}
              >
                {/* =====================================================================
                    WINDOWS / DESKTOP VERSION (8 Columns Left Paper + 4 Columns Right)
                    Hidden on mobile, visible on md+ screens
                ===================================================================== */}
                <div className="hidden md:flex items-center justify-between mb-4 pb-3 border-b border-slate-200/80">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-white shadow-2xs border border-slate-200/80 flex items-center justify-center text-[#135bec]">
                      <FileSpreadsheet className="w-4 h-4" />
                    </div>
                    <h2 className="text-sm font-bold text-slate-800">Establish Import Letter of Credit (LC)</h2>
                  </div>
                  <button
                    type="button"
                    disabled={isSavingNewLc}
                    data-modal-close="true"
                    onClick={handleCloseNewLcModal}
                    title="Close"
                    className="w-8 h-8 rounded-lg bg-white hover:bg-slate-100 text-slate-500 hover:text-slate-800 border border-slate-200/80 shadow-2xs flex items-center justify-center transition cursor-pointer disabled:opacity-50"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="hidden md:grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  {/* LEFT MAIN PAPER CARD (8 COLUMNS) */}
                  <div className="lg:col-span-8 bg-white rounded-2xl shadow-[0_4px_25px_rgba(0,0,0,0.03)] px-6 sm:px-10 pt-10 pb-8 relative mt-4">
                    {/* Top Center Floating Circle Icon */}
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full bg-white shadow-md border border-slate-100 flex items-center justify-center text-[#135bec]">
                      <FileSpreadsheet className="w-5 h-5" />
                    </div>

                    {/* Top Header Row: LC Number Left, Dates Right */}
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-6 mb-8">
                      {/* Left: Boxed LC Number */}
                      <div className="w-full sm:w-auto">
                        <label className="block text-xs font-semibold text-slate-400 mb-1.5">LC Number *</label>
                        <div className={`flex items-center ${softInputClass} px-3.5 py-2.5 w-full sm:w-72`}>
                          <span className="text-slate-400 font-semibold text-sm mr-2 select-none">LC#</span>
                          <input
                            type="text"
                            value={newLcNumber}
                            onChange={(e) => setNewLcNumber(e.target.value)}
                            required
                            className="bg-transparent border-none outline-none w-full font-mono font-bold text-slate-800 text-sm"
                            placeholder="LC-2026-SB-104"
                          />
                        </div>
                      </div>

                      {/* Right: Opening & Expiry Dates */}
                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 w-full sm:w-auto justify-end">
                        <div>
                          <label className="block text-xs font-semibold text-slate-400 mb-1.5 sm:text-right">Opening Date *</label>
                          <input
                            type="date"
                            value={newLcOpeningDate}
                            onChange={(e) => setNewLcOpeningDate(e.target.value)}
                            required
                            className={`${softInputClass} px-3.5 py-2 text-xs font-mono font-semibold text-slate-700 w-40`}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-400 mb-1.5 sm:text-right">Expiry Date *</label>
                          <input
                            type="date"
                            value={newLcMaturityDate}
                            onChange={(e) => setNewLcMaturityDate(e.target.value)}
                            required
                            className={`${softInputClass} px-3.5 py-2 text-xs font-mono font-semibold text-slate-700 w-40`}
                          />
                        </div>
                      </div>
                    </div>

                    <hr className="border-slate-100 mb-7" />

                    {/* Two-Column Section: Issuing Bank (Left) & Beneficiary / Owner (Right) */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                      {/* Left Column: Issuing Bank & Port */}
                      <div className="space-y-4">
                        <h3 className="text-xs font-bold text-slate-700">Issuing Bank &amp; Port</h3>

                        <div>
                          <input
                            type="text"
                            value={newLcBank}
                            onChange={(e) => setNewLcBank(e.target.value)}
                            placeholder="Issuing Bank Name..."
                            className={`${softInputClass} w-full px-3.5 py-2.5 text-sm font-semibold text-slate-800`}
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-medium text-slate-400 mb-1">Border / Land Port Entry</label>
                          <select
                            value={newLcBorderLandPort}
                            onChange={(e) => setNewLcBorderLandPort(e.target.value)}
                            className={`${softInputClass} w-full px-3.5 py-2.5 text-sm font-medium text-slate-700 cursor-pointer`}
                          >
                            <option value="">Select Border / Land Port...</option>
                            <option value="Burimari">Burimari Land Port</option>
                            <option value="Sonahat">Sonahat Land Port</option>
                            <option value="Tamabil">Tamabil Land Port</option>
                            <option value="Bhomra">Bhomra Land Port</option>
                            <option value="Hili">Hili Land Port</option>
                            <option value="Benapole">Benapole Land Port</option>
                            <option value="Chittagong Sea Port">Chittagong Sea Port</option>
                          </select>
                        </div>
                      </div>

                      {/* Right Column: Beneficiary Supplier & Owner Ledger */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-xs font-bold text-slate-700">Beneficiary / Supplier</h3>
                          <button
                            type="button"
                            onClick={() => {
                              setSupplierToEdit(null);
                              setShowAddSupplierModal(true);
                            }}
                            className="text-[11px] font-bold text-[#135bec] hover:underline flex items-center gap-1 cursor-pointer"
                          >
                            <Plus className="w-3 h-3" /> New Company
                          </button>
                        </div>

                        <div>
                          <select
                            value={newLcSupplier}
                            onChange={(e) => handleLcSupplierSelect(e.target.value)}
                            className={`${softInputClass} w-full px-3.5 py-2.5 text-sm font-semibold text-slate-800 cursor-pointer`}
                          >
                            <option value="">Select Supplier / Beneficiary...</option>
                            {suppliers.map(s => (
                              <option key={s.id} value={s.name}>
                                {s.name} ({s.country})
                              </option>
                            ))}
                            {!suppliers.some(s => s.name === 'Pelden Enterprise Limited') && (
                              <option value="Pelden Enterprise Limited">Pelden Enterprise Limited (Bhutan)</option>
                            )}
                            {!suppliers.some(s => s.name === 'Druk Mining & Minerals Co.') && (
                              <option value="Druk Mining & Minerals Co.">Druk Mining &amp; Minerals Co. (Bhutan)</option>
                            )}
                            {!suppliers.some(s => s.name === 'Jaigaon Boulder Exports (India)') && (
                              <option value="Jaigaon Boulder Exports (India)">Jaigaon Boulder Exports (India)</option>
                            )}
                            {!suppliers.some(s => s.name === 'Himalayan Stone Impex') && (
                              <option value="Himalayan Stone Impex">Himalayan Stone Impex (Bhutan)</option>
                            )}
                          </select>
                        </div>

                        {/* Exporter Owner Auto-Filled + Quick Pills */}
                        <div className="bg-[#f8fafc] p-3 rounded-xl border border-slate-100">
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1.5">
                              <Users className="w-3.5 h-3.5 text-[#135bec]" />
                              Exporter Owner (Auto-Ledger)
                            </span>
                          </div>
                          <input
                            type="text"
                            value={newLcCompanyOwner}
                            onChange={(e) => setNewLcCompanyOwner(e.target.value)}
                            className={`${softInputClass} !bg-white border !border-slate-200 w-full px-3 py-1.5 text-xs font-bold text-slate-800 mb-2`}
                            placeholder="Owner / Group Name"
                          />
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[10px] text-slate-400">Frequent:</span>
                            {['Edu', 'Sanad', 'Munna Khan', 'Gawtom', 'Tashi Namgyal'].map(owner => (
                              <button
                                key={owner}
                                type="button"
                                onClick={() => setNewLcCompanyOwner(owner)}
                                className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border transition cursor-pointer ${
                                  newLcCompanyOwner === owner
                                    ? 'bg-blue-50 border-blue-300 text-[#135bec]'
                                    : 'bg-white border-slate-200 text-slate-600 hover:border-blue-400 hover:text-blue-600'
                                }`}
                              >
                                {owner}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Commodity & Dual-Rate Table Section */}
                    <div className="mb-8">
                      {/* Table Header */}
                      <div className="grid grid-cols-12 pb-2.5 mb-3 border-b border-slate-100 text-xs font-bold text-slate-700">
                        <div className="col-span-5">Commodity / Item</div>
                        <div className="col-span-2">Qty &amp; UOM</div>
                        <div className="col-span-2">
                          Bank LC Rate
                          <span className="block text-[10px] font-normal text-blue-600">Official LC</span>
                        </div>
                        <div className="col-span-2">
                          Actual Rate
                          <span className="block text-[10px] font-normal text-emerald-600">Contract Rate</span>
                        </div>
                        <div className="col-span-1 text-right">
                          Diff
                          <span className="block text-[10px] font-normal text-amber-600">/MT</span>
                        </div>
                      </div>

                      {/* Table Row */}
                      <div className="grid grid-cols-12 gap-2.5 items-start py-2 border-b border-slate-100 pb-6">
                        {/* Commodity + LC Type */}
                        <div className="col-span-5 pr-3">
                          <input
                            type="text"
                            list="lc-commodity-presets"
                            value={newLcCommodity}
                            onChange={(e) => setNewLcCommodity(e.target.value)}
                            className={`${softInputClass} w-full px-3.5 py-2.5 text-sm font-semibold text-slate-800 mb-2`}
                            placeholder="Item description..."
                          />
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[11px] font-medium text-slate-400">Instrument:</span>
                            <select
                              value={newLcType}
                              onChange={(e) => setNewLcType(e.target.value as LCType)}
                              className={`${softInputClass} px-2.5 py-1 text-xs font-semibold text-slate-600 cursor-pointer`}
                            >
                              <option value="">Select Instrument...</option>
                              <option value="Usance 90 Days">Usance 90 Days</option>
                              <option value="Sight LC">Irrevocable Sight LC</option>
                              <option value="Usance 180 Days">Usance 180 Days</option>
                              <option value="UPAS">UPAS (Buyer Credit)</option>
                              <option value="Cash LC">Cash LC</option>
                            </select>
                            <div className="flex items-center gap-1 ml-auto">
                              {[
                                { label: 'S', item: 'S-Samtse Boulder', code: 'SB' },
                                { label: 'P', item: 'P-Phuentsholing Boulder', code: 'PB' },
                                { label: 'R', item: 'R-Indian River Stone Boulder', code: 'IR' }
                              ].map(preset => (
                                <button
                                  key={preset.code}
                                  type="button"
                                  title={preset.item}
                                  onClick={() => {
                                    const r = Math.floor(Math.random() * 899 + 100);
                                    setNewLcCommodity(preset.item);
                                    setNewLcNumber(`LC-2026-${preset.code}-${r}`);
                                  }}
                                  className={`w-6 h-6 rounded-md text-[10px] font-mono font-bold transition cursor-pointer ${
                                    newLcCommodity === preset.item
                                      ? 'bg-[#135bec] text-white'
                                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                  }`}
                                >
                                  {preset.label}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Quantity & UOM */}
                        <div className="col-span-2">
                          <input
                            type="text"
                            inputMode="decimal"
                            value={newLcQtyInput}
                            onChange={(e) => {
                              const val = sanitizeDecimalInput(e.target.value);
                              setNewLcQtyInput(val);
                              const num = parseFloat(val) || 0;
                              setNewLcQuantity(num);
                              setNewLcCfr(num * newLcOfficialRate);
                            }}
                            className={`${softInputClass} w-full px-3 py-2.5 text-sm font-mono font-bold text-slate-800 mb-2`}
                            placeholder="1000"
                          />
                          <select
                            value={newLcUom}
                            onChange={(e) => setNewLcUom(e.target.value)}
                            className={`${softInputClass} w-full px-2.5 py-1 text-xs font-semibold text-slate-600 cursor-pointer`}
                          >
                            <option value="">Select UOM...</option>
                            <option value="MT">MT (Metric Ton)</option>
                            <option value="TON">TON</option>
                            <option value="CFT">CFT</option>
                            <option value="PCS">PCS</option>
                          </select>
                        </div>

                        {/* Bank LC Rate ($14.00) */}
                        <div className="col-span-2">
                          <div className={`flex items-center ${softInputClass} px-3 py-2.5`}>
                            <span className="text-slate-400 font-mono text-xs mr-1.5">{sym}</span>
                            <input
                              type="text"
                              inputMode="decimal"
                              value={newLcOfficialRateInput}
                              onChange={(e) => {
                                const val = sanitizeDecimalInput(e.target.value);
                                setNewLcOfficialRateInput(val);
                                const num = parseFloat(val) || 0;
                                setNewLcOfficialRate(num);
                                setNewLcCfr(newLcQuantity * num);
                              }}
                              className="bg-transparent border-none outline-none w-full font-mono font-bold text-slate-800 text-sm"
                              placeholder="14.00"
                            />
                          </div>
                        </div>

                        {/* Actual Contract Rate ($18.00) */}
                        <div className="col-span-2">
                          <div className={`flex items-center ${softInputClass} px-3 py-2.5`}>
                            <span className="text-slate-400 font-mono text-xs mr-1.5">{sym}</span>
                            <input
                              type="text"
                              inputMode="decimal"
                              value={newLcActualRateInput}
                              onChange={(e) => {
                                const val = sanitizeDecimalInput(e.target.value);
                                setNewLcActualRateInput(val);
                                setNewLcActualRate(parseFloat(val) || 0);
                              }}
                              className="bg-transparent border-none outline-none w-full font-mono font-bold text-emerald-700 text-sm"
                              placeholder="18.00"
                            />
                          </div>
                        </div>

                        {/* Rate Difference Badge */}
                        <div className="col-span-1 text-right pt-2.5">
                          <span className="font-mono font-bold text-amber-600 text-xs bg-amber-50 px-2 py-1 rounded-md border border-amber-200/60">
                            +{sym}{diffPerUnit.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Below Line Action & Totals Section */}
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pt-2">
                      {/* Left: Margin Bank Account & Opening Charges (6 cols) */}
                      <div className="md:col-span-6 space-y-4">
                        <div className="bg-[#f8fafc] rounded-xl p-4 border border-slate-100 space-y-3">
                          <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
                            <Landmark className="w-3.5 h-3.5 text-[#135bec]" />
                            Margin Debit Source Account
                          </label>
                          <select
                            value={newLcMarginPaidFromAccountId}
                            onChange={(e) => setNewLcMarginPaidFromAccountId(e.target.value)}
                            className={`${softInputClass} !bg-white !border-slate-200 w-full px-3 py-2 text-xs font-semibold text-slate-800 cursor-pointer`}
                          >
                            <option value="">Select bank or cash account...</option>
                            {accessibleAccounts.map(acc => (
                              <option key={acc.id} value={acc.id}>
                                {acc.bankName} ({acc.accountNumber}) — ৳ {(acc.ledgerBalance || 0).toLocaleString('en-US')}
                              </option>
                            ))}
                          </select>

                          <div className="flex items-center justify-between pt-1">
                            <span className="text-[11px] font-medium text-slate-400">Payment Date:</span>
                            <input
                              type="date"
                              value={newLcMarginPaymentDate}
                              onChange={(e) => setNewLcMarginPaymentDate(e.target.value)}
                              className={`${softInputClass} !bg-white !border-slate-200 px-2.5 py-1 text-xs font-mono font-semibold text-slate-700`}
                            />
                          </div>
                        </div>

                        {/* Optional Opening Charges Box */}
                        {showLcOpeningChargesBox && (
                          <div className="bg-[#f8fafc] rounded-xl p-4 border border-slate-100 space-y-2.5">
                            <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
                              <Receipt className="w-3.5 h-3.5 text-amber-500" />
                              LC Opening Charges (BDT - Optional)
                            </label>
                            <div className="grid grid-cols-2 gap-2.5">
                              <div className={`flex items-center ${softInputClass} !bg-white !border-slate-200 px-3 py-1.5`}>
                                <span className="text-slate-400 font-mono text-xs mr-1.5">৳</span>
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  value={newLcOpeningCharges}
                                  onChange={(e) => setNewLcOpeningCharges(sanitizeDecimalInput(e.target.value))}
                                  placeholder="0"
                                  className="bg-transparent border-none outline-none w-full font-mono font-bold text-slate-800 text-xs"
                                />
                              </div>
                              <select
                                value={newLcOpeningChargeHeadName}
                                onChange={(e) => setNewLcOpeningChargeHeadName(e.target.value)}
                                className={`${softInputClass} !bg-white !border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-600 cursor-pointer`}
                              >
                                <option value="">Select Charge Head...</option>
                                <option value="Bank Charges & LC Commission">Bank Charges &amp; LC Comm.</option>
                                {expenseHeads
                                  .filter(h => h.name !== 'Bank Charges & LC Commission')
                                  .map(h => (
                                    <option key={h.id} value={h.name}>
                                      {h.name}
                                    </option>
                                  ))}
                              </select>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Right: Clean Invoice Summary Totals (6 cols) */}
                      <div className="md:col-span-6 space-y-2.5 text-sm">
                        {/* 1. Bank LC Total */}
                        <div className="flex justify-between items-center py-1">
                          <span className="text-slate-500 font-medium text-xs">1. Bank LC Total</span>
                          <div className="text-right">
                            <span className="font-mono font-bold text-slate-800">
                              {sym} {bankTotalForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                            <span className="block font-mono text-[11px] text-slate-400">
                              ৳ {Math.round(bankTotalBdt).toLocaleString('en-US')} BDT
                            </span>
                          </div>
                        </div>

                        {/* 2. Actual Contract Total */}
                        <div className="flex justify-between items-center py-1">
                          <span className="text-slate-500 font-medium text-xs">2. Actual Contract Total</span>
                          <div className="text-right">
                            <span className="font-mono font-bold text-emerald-700">
                              {sym} {actualTotalForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                            <span className="block font-mono text-[11px] text-emerald-600/80">
                              ৳ {Math.round(actualTotalBdt).toLocaleString('en-US')} BDT
                            </span>
                          </div>
                        </div>

                        {/* 3. Unofficial / Differential (Hundi) */}
                        <div className="flex justify-between items-center py-1.5 bg-amber-50/70 px-3 rounded-lg border border-amber-200/60">
                          <div>
                            <span className="text-amber-900 font-bold text-xs block">3. Unofficial / Diff. Due</span>
                            <span className="text-[10px] font-mono text-amber-700 font-semibold">
                              ≈ ₹ {Math.round(diffInr).toLocaleString('en-US')} INR
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="font-mono font-bold text-amber-800">
                              {sym} {diffTotalForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                            <span className="block font-mono text-[11px] text-amber-700">
                              ৳ {Math.round(diffTotalBdt).toLocaleString('en-US')} BDT
                            </span>
                          </div>
                        </div>

                        <hr className="border-slate-100 my-2" />

                        {/* Margin Deposit Row */}
                        <div className="flex justify-between items-center py-1">
                          <div className="flex items-center gap-2">
                            <span className="text-slate-600 font-semibold text-xs">Margin Deposit (%)</span>
                            <input
                              type="text"
                              inputMode="decimal"
                              value={newLcMargin}
                              onChange={(e) => {
                                const val = sanitizeDecimalInput(e.target.value);
                                const num = parseFloat(val);
                                if (!isNaN(num) && num > 100) {
                                  setNewLcMargin('100');
                                } else {
                                  setNewLcMargin(val);
                                }
                              }}
                              className={`${softInputClass} w-14 px-2 py-1 text-center font-mono font-bold text-xs text-[#135bec]`}
                            />
                          </div>
                          <span className="font-mono font-bold text-[#135bec]">
                            ৳ {marginBdt.toLocaleString('en-US')}
                          </span>
                        </div>

                        {/* Total Deduction & Deferred Bank Liability */}
                        <div className="pt-2 border-t border-slate-200/80 flex justify-between items-baseline">
                          <div>
                            <span className="text-sm font-bold text-slate-900 block">Total Deduction</span>
                            <span className="text-[11px] text-slate-400">
                              Deferred LC Due:{' '}
                              <strong className="font-mono text-slate-600">
                                ৳ {deferredLcDueBdt.toLocaleString('en-US')}
                              </strong>
                            </span>
                          </div>
                          <span className="font-mono font-bold text-lg text-slate-900">
                            ৳ {totalDeductionBdt.toLocaleString('en-US')}
                          </span>
                        </div>

                        {/* Remaining Account Balance */}
                        <div className="flex justify-between items-center text-[11px] pt-1">
                          <span className="text-slate-400">Remaining Bank Balance:</span>
                          <span
                            className={`font-mono font-bold ${
                              remainingBalance < 0 ? 'text-rose-600' : 'text-emerald-600'
                            }`}
                          >
                            ৳ {remainingBalance.toLocaleString('en-US')}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Validation & Overdraft Alerts */}
                    {(isOverdraft || newLcError) && (
                      <div className="mt-6 space-y-2">
                        {selectedAcc && isOverdraft && isCash && (
                          <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-900 text-xs flex items-start gap-2">
                            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                            <div>
                              <strong className="block font-bold">Insufficient Cash Balance</strong>
                              <span className="text-[11px] text-rose-700">
                                Required: ৳{totalDeductionBdt.toLocaleString()}, Current Cash Balance: ৳{accountBalance.toLocaleString()}. Negative cash balance is prohibited.
                              </span>
                            </div>
                          </div>
                        )}

                        {selectedAcc && isOverdraft && !isCash && (
                          <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs space-y-2">
                            <div className="flex items-start gap-2">
                              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                              <div>
                                <strong className="block font-bold">Bank Overdraft Warning</strong>
                                <span className="text-[11px] text-amber-800">
                                  Current Balance: ৳{accountBalance.toLocaleString()}. Deficit: ৳{(totalDeductionBdt - accountBalance).toLocaleString()}.
                                  {!isAdmin && ' Overdraft requires Administrator authorization.'}
                                </span>
                              </div>
                            </div>
                            {isAdmin ? (
                              <label className="flex items-center gap-2 pt-1 border-t border-amber-200 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={newLcOverdraftApproved}
                                  onChange={(e) => setNewLcOverdraftApproved(e.target.checked)}
                                  className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500"
                                />
                                <span className="text-xs font-bold text-amber-950">
                                  Authorize Bank Overdraft (Admin Override)
                                </span>
                              </label>
                            ) : (
                              <div className="text-[11px] font-bold text-rose-700">
                                Manager account cannot authorize overdraft. Please select an account with sufficient balance.
                              </div>
                            )}
                          </div>
                        )}

                        {newLcError && (
                          <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-900 text-xs flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                            <span className="font-bold">{newLcError}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Bottom Notes Section */}
                    {showLcNotesBox && (
                      <div className="mt-8 pt-6 border-t border-slate-100">
                        <label className="block text-xs font-semibold text-slate-400 mb-2">
                          Notes / LC Settlement Remarks
                        </label>
                        <input
                          type="text"
                          value={newLcNotes}
                          onChange={(e) => setNewLcNotes(e.target.value)}
                          placeholder="Add PI reference, port instructions, or custom remarks..."
                          className={`${softInputClass} w-full px-4 py-3 text-xs text-slate-600`}
                        />
                      </div>
                    )}
                  </div>

                  {/* RIGHT SIDEBAR ACTION & SETTINGS PANEL (4 COLUMNS) */}
                  <div className="lg:col-span-4 space-y-6 mt-4">
                    {/* Top Primary Action Buttons */}
                    <div className="space-y-3">
                      <button
                        type="submit"
                        disabled={isSubmitDisabled}
                        className="w-full bg-[#135bec] hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold py-3.5 px-6 rounded-xl shadow-[0_8px_20px_rgba(19,91,236,0.25)] transition flex items-center justify-center gap-2 text-sm cursor-pointer"
                      >
                        {isSavingNewLc ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Establishing LC...</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Establish Letter of Credit</span>
                          </>
                        )}
                      </button>

                      <div className="grid grid-cols-2 gap-3">
                        <button
                          type="button"
                          onClick={() => applyMarginPreset(100)}
                          className="bg-[#e8edf5] hover:bg-[#dce4f0] text-slate-700 font-semibold py-2.5 px-4 rounded-xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Zap className="w-3.5 h-3.5 text-[#135bec]" />
                          100% Paid LC
                        </button>
                        <button
                          type="button"
                          onClick={resetNewLcForm}
                          className="bg-[#e8edf5] hover:bg-[#dce4f0] text-slate-700 font-semibold py-2.5 px-4 rounded-xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                          Reset
                        </button>
                      </div>
                    </div>

                    {/* Currency & Exchange Settings Card */}
                    <div className="bg-white rounded-2xl shadow-[0_4px_25px_rgba(0,0,0,0.03)] p-6 space-y-5">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-2">
                          Currency &amp; Exchange Rates
                        </label>
                        <select
                          value={newLcCurrency}
                          onChange={(e) => setNewLcCurrency(e.target.value as 'USD' | 'INR')}
                          className={`${softInputClass} w-full px-3.5 py-2.5 text-sm font-semibold text-slate-800 mb-3 cursor-pointer`}
                        >
                          <option value="">Select Currency...</option>
                          <option value="USD">USD ($ - US Dollar)</option>
                          <option value="INR">INR (₹ - Indian Rupee)</option>
                        </select>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <span className="block text-[11px] font-medium text-slate-400 mb-1">LC Rate (BDT)</span>
                            <div className={`flex items-center ${softInputClass} px-3 py-2`}>
                              <span className="text-slate-400 font-mono text-xs mr-1">৳</span>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={newLcExchangeRateInput}
                                onChange={(e) => {
                                  const val = sanitizeDecimalInput(e.target.value);
                                  setNewLcExchangeRateInput(val);
                                  setNewLcExchangeRate(parseFloat(val) || 0);
                                }}
                                className="bg-transparent border-none outline-none w-full font-mono font-bold text-slate-800 text-xs"
                              />
                            </div>
                          </div>
                          <div>
                            <span className="block text-[11px] font-medium text-slate-400 mb-1">INR Rate (BDT)</span>
                            <div className={`flex items-center ${softInputClass} px-3 py-2`}>
                              <span className="text-slate-400 font-mono text-xs mr-1">৳</span>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={newLcInrRateInput}
                                onChange={(e) => {
                                  const val = sanitizeDecimalInput(e.target.value);
                                  setNewLcInrRateInput(val);
                                  setNewLcInrRate(parseFloat(val) || 0);
                                }}
                                className="bg-transparent border-none outline-none w-full font-mono font-bold text-amber-700 text-xs"
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      <hr className="border-slate-100" />

                      {/* Clean Toggle Switches */}
                      <div className="space-y-3.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-slate-700">100% Margin (Direct Paid)</span>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={marginPct === 100}
                              onChange={(e) => applyMarginPreset(e.target.checked ? 100 : 15)}
                              className="sr-only peer"
                            />
                            <div className="w-9 h-5 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#135bec]" />
                          </label>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-slate-700">LC Opening Charges</span>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={showLcOpeningChargesBox}
                              onChange={(e) => {
                                setShowLcOpeningChargesBox(e.target.checked);
                                if (!e.target.checked) {
                                  setNewLcOpeningCharges('');
                                }
                              }}
                              className="sr-only peer"
                            />
                            <div className="w-9 h-5 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#135bec]" />
                          </label>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-slate-700">Notes</span>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={showLcNotesBox}
                              onChange={(e) => setShowLcNotesBox(e.target.checked)}
                              className="sr-only peer"
                            />
                            <div className="w-9 h-5 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#135bec]" />
                          </label>
                        </div>
                      </div>
                    </div>

                    {/* Quick Margin Presets Card */}
                    <div className="bg-white rounded-2xl shadow-[0_4px_25px_rgba(0,0,0,0.03)] p-6">
                      <label className="block text-xs font-bold text-slate-700 mb-3">Quick Margin Presets</label>
                      <div className="grid grid-cols-5 gap-1.5">
                        {[10, 15, 25, 50, 100].map(pct => (
                          <button
                            key={pct}
                            type="button"
                            onClick={() => applyMarginPreset(pct)}
                            className={`py-2 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                              marginPct === pct
                                ? 'bg-blue-50 text-[#135bec] border border-blue-200'
                                : 'bg-[#f3f5f8] hover:bg-blue-50 hover:text-[#135bec] text-slate-700'
                            }`}
                          >
                            {pct}%
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Desktop Bottom Footer: Cancel / Close Button */}
                <div className="hidden md:flex items-center justify-end gap-3 mt-6 pt-4 border-t border-slate-200/80">
                  <button
                    type="button"
                    disabled={isSavingNewLc}
                    data-modal-close="true"
                    onClick={handleCloseNewLcModal}
                    className="bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-800 border border-slate-200/90 font-semibold py-2.5 px-6 rounded-xl text-xs transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer disabled:opacity-50"
                  >
                    <X className="w-3.5 h-3.5" />
                    Cancel
                  </button>
                </div>

                {/* =====================================================================
                    MOBILE VERSION (Visible ONLY on mobile screens < md)
                ===================================================================== */}
                <div className="block md:hidden space-y-3">
                  {/* Mobile Top Bar */}
                  <div className="flex items-center justify-between px-1 pt-1">
                    <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                      <FileSpreadsheet className="w-4 h-4 text-[#135bec]" />
                      Establish Import LC
                    </span>
                    <button
                      type="button"
                      disabled={isSavingNewLc}
                      data-modal-close="true"
                      onClick={handleCloseNewLcModal}
                      className="w-7 h-7 rounded-full bg-white shadow-2xs border border-slate-200 flex items-center justify-center text-slate-500 text-xs font-bold"
                    >
                      ✕
                    </button>
                  </div>

                  {/* Mobile White Invoice Card */}
                  <div className="bg-white rounded-2xl shadow-xs p-5 mt-3 relative space-y-4">
                    {/* Floating Circle Icon */}
                    <div className="absolute -top-5 left-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-white shadow-md border border-slate-100 flex items-center justify-center text-[#135bec]">
                      <FileSpreadsheet className="w-4 h-4" />
                    </div>

                    {/* LC Number */}
                    <div className="pt-2">
                      <label className="block text-[11px] font-semibold text-slate-400 mb-1">LC Number *</label>
                      <div className={`flex items-center ${softInputClass} px-3 py-2`}>
                        <span className="text-slate-400 font-semibold text-xs mr-1.5">LC#</span>
                        <input
                          type="text"
                          value={newLcNumber}
                          onChange={(e) => setNewLcNumber(e.target.value)}
                          required
                          className="bg-transparent border-none outline-none w-full font-mono font-bold text-slate-800 text-xs"
                        />
                      </div>
                    </div>

                    {/* Dates 2-Col */}
                    <div className="grid grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[10px] font-semibold text-slate-400 mb-1">Opening Date</label>
                        <input
                          type="date"
                          value={newLcOpeningDate}
                          onChange={(e) => setNewLcOpeningDate(e.target.value)}
                          required
                          className={`${softInputClass} w-full px-2.5 py-2 text-[11px] font-mono font-semibold text-slate-700`}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-semibold text-slate-400 mb-1">Expiry Date</label>
                        <input
                          type="date"
                          value={newLcMaturityDate}
                          onChange={(e) => setNewLcMaturityDate(e.target.value)}
                          required
                          className={`${softInputClass} w-full px-2.5 py-2 text-[11px] font-mono font-semibold text-slate-700`}
                        />
                      </div>
                    </div>

                    <hr className="border-slate-100" />

                    {/* Beneficiary & Owner */}
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-bold text-slate-700">Beneficiary Company</label>
                        <button
                          type="button"
                          onClick={() => {
                            setSupplierToEdit(null);
                            setShowAddSupplierModal(true);
                          }}
                          className="text-[10px] font-bold text-[#135bec]"
                        >
                          + Add
                        </button>
                      </div>
                      <select
                        value={newLcSupplier}
                        onChange={(e) => handleLcSupplierSelect(e.target.value)}
                        className={`${softInputClass} w-full px-3 py-2 text-xs font-semibold text-slate-800`}
                      >
                        <option value="">Select Supplier / Beneficiary...</option>
                        {suppliers.map(s => (
                          <option key={s.id} value={s.name}>
                            {s.name} ({s.country})
                          </option>
                        ))}
                        {!suppliers.some(s => s.name === 'Pelden Enterprise Limited') && (
                          <option value="Pelden Enterprise Limited">Pelden Enterprise Limited (Bhutan)</option>
                        )}
                        {!suppliers.some(s => s.name === 'Druk Mining & Minerals Co.') && (
                          <option value="Druk Mining & Minerals Co.">Druk Mining &amp; Minerals Co. (Bhutan)</option>
                        )}
                        {!suppliers.some(s => s.name === 'Jaigaon Boulder Exports (India)') && (
                          <option value="Jaigaon Boulder Exports (India)">Jaigaon Boulder Exports (India)</option>
                        )}
                      </select>

                      <div className="flex items-center justify-between bg-[#f8fafc] px-3 py-2 rounded-lg border border-slate-100">
                        <span className="text-[11px] text-slate-500">Owner Ledger:</span>
                        <input
                          type="text"
                          value={newLcCompanyOwner}
                          onChange={(e) => setNewLcCompanyOwner(e.target.value)}
                          className="text-xs font-bold text-[#135bec] bg-transparent border-none outline-none text-right w-36"
                          placeholder="Owner Name"
                        />
                      </div>
                    </div>

                    {/* Issuing Bank & Port */}
                    <div className="grid grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[10px] font-semibold text-slate-400 mb-1">Issuing Bank</label>
                        <input
                          type="text"
                          value={newLcBank}
                          onChange={(e) => setNewLcBank(e.target.value)}
                          className={`${softInputClass} w-full px-2.5 py-2 text-xs font-semibold text-slate-800`}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-semibold text-slate-400 mb-1">Border / Land Port</label>
                        <select
                          value={newLcBorderLandPort}
                          onChange={(e) => setNewLcBorderLandPort(e.target.value)}
                          className={`${softInputClass} w-full px-2.5 py-2 text-xs font-semibold text-slate-700`}
                        >
                          <option value="">Select Port...</option>
                          <option value="Burimari">Burimari Port</option>
                          <option value="Sonahat">Sonahat Port</option>
                          <option value="Tamabil">Tamabil Port</option>
                          <option value="Bhomra">Bhomra Port</option>
                          <option value="Hili">Hili Port</option>
                          <option value="Benapole">Benapole Port</option>
                        </select>
                      </div>
                    </div>

                    <hr className="border-slate-100" />

                    {/* Commodity & Rates */}
                    <div className="space-y-2.5">
                      <label className="block text-[11px] font-bold text-slate-700">Commodity &amp; Dual Rates</label>
                      <input
                        type="text"
                        list="lc-commodity-presets"
                        value={newLcCommodity}
                        onChange={(e) => setNewLcCommodity(e.target.value)}
                        className={`${softInputClass} w-full px-3 py-2 text-xs font-semibold text-slate-800`}
                      />

                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <span className="block text-[10px] text-slate-400 mb-1">Qty ({newLcUom})</span>
                          <input
                            type="text"
                            inputMode="decimal"
                            value={newLcQtyInput}
                            onChange={(e) => {
                              const val = sanitizeDecimalInput(e.target.value);
                              setNewLcQtyInput(val);
                              const num = parseFloat(val) || 0;
                              setNewLcQuantity(num);
                              setNewLcCfr(num * newLcOfficialRate);
                            }}
                            className={`${softInputClass} w-full px-2.5 py-2 text-xs font-mono font-bold text-slate-800`}
                          />
                        </div>
                        <div>
                          <span className="block text-[10px] text-blue-600 mb-1">Bank Rate ({sym})</span>
                          <input
                            type="text"
                            inputMode="decimal"
                            value={newLcOfficialRateInput}
                            onChange={(e) => {
                              const val = sanitizeDecimalInput(e.target.value);
                              setNewLcOfficialRateInput(val);
                              const num = parseFloat(val) || 0;
                              setNewLcOfficialRate(num);
                              setNewLcCfr(newLcQuantity * num);
                            }}
                            className={`${softInputClass} w-full px-2.5 py-2 text-xs font-mono font-bold text-slate-800`}
                          />
                        </div>
                        <div>
                          <span className="block text-[10px] text-emerald-600 mb-1">Actual Rate ({sym})</span>
                          <input
                            type="text"
                            inputMode="decimal"
                            value={newLcActualRateInput}
                            onChange={(e) => {
                              const val = sanitizeDecimalInput(e.target.value);
                              setNewLcActualRateInput(val);
                              setNewLcActualRate(parseFloat(val) || 0);
                            }}
                            className={`${softInputClass} w-full px-2.5 py-2 text-xs font-mono font-bold text-emerald-700`}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div>
                          <span className="block text-[10px] text-slate-400 mb-1">LC Ex. Rate (BDT)</span>
                          <input
                            type="text"
                            inputMode="decimal"
                            value={newLcExchangeRateInput}
                            onChange={(e) => {
                              const val = sanitizeDecimalInput(e.target.value);
                              setNewLcExchangeRateInput(val);
                              setNewLcExchangeRate(parseFloat(val) || 0);
                            }}
                            className={`${softInputClass} w-full px-2.5 py-1.5 text-xs font-mono font-bold text-slate-800`}
                          />
                        </div>
                        <div>
                          <span className="block text-[10px] text-amber-600 mb-1">INR Rate (BDT)</span>
                          <input
                            type="text"
                            inputMode="decimal"
                            value={newLcInrRateInput}
                            onChange={(e) => {
                              const val = sanitizeDecimalInput(e.target.value);
                              setNewLcInrRateInput(val);
                              setNewLcInrRate(parseFloat(val) || 0);
                            }}
                            className={`${softInputClass} w-full px-2.5 py-1.5 text-xs font-mono font-bold text-amber-700`}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Margin Debit Source Account on Mobile */}
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-400 mb-1">Margin Debit Source Account</label>
                      <select
                        value={newLcMarginPaidFromAccountId}
                        onChange={(e) => setNewLcMarginPaidFromAccountId(e.target.value)}
                        className={`${softInputClass} w-full px-2.5 py-2 text-xs font-semibold text-slate-800`}
                      >
                        <option value="">Select bank or cash account...</option>
                        {accessibleAccounts.map(acc => (
                          <option key={acc.id} value={acc.id}>
                            {acc.bankName} ({acc.accountNumber}) — ৳ {(acc.ledgerBalance || 0).toLocaleString('en-US')}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Clean Mobile Summary Totals */}
                    <div className="bg-[#f8fafc] p-3.5 rounded-xl border border-slate-100 space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-500">1. Bank LC Total</span>
                        <div className="text-right">
                          <span className="font-mono font-bold text-slate-800">
                            {sym} {bankTotalForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                          <span className="block font-mono text-[10px] text-slate-400">
                            ৳ {Math.round(bankTotalBdt).toLocaleString('en-US')} BDT
                          </span>
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">2. Actual Total</span>
                        <div className="text-right">
                          <span className="font-mono font-bold text-emerald-700">
                            {sym} {actualTotalForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                          <span className="block font-mono text-[10px] text-emerald-600/80">
                            ৳ {Math.round(actualTotalBdt).toLocaleString('en-US')} BDT
                          </span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center bg-amber-50/80 px-2.5 py-1.5 rounded-lg border border-amber-200/60">
                        <div>
                          <span className="text-amber-900 font-semibold block">3. Diff / Hundi</span>
                          <span className="font-mono text-[10px] text-amber-700">
                            ≈ ₹ {Math.round(diffInr).toLocaleString('en-US')} INR
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="font-mono font-bold text-amber-800">
                            {sym} {diffTotalForeign.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                          <span className="block font-mono text-[10px] text-amber-700">
                            ৳ {Math.round(diffTotalBdt).toLocaleString('en-US')} BDT
                          </span>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-200/70 flex justify-between items-center">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-600 font-semibold">Margin (%)</span>
                          <input
                            type="text"
                            inputMode="decimal"
                            value={newLcMargin}
                            onChange={(e) => {
                              const val = sanitizeDecimalInput(e.target.value);
                              const num = parseFloat(val);
                              if (!isNaN(num) && num > 100) {
                                setNewLcMargin('100');
                              } else {
                                setNewLcMargin(val);
                              }
                            }}
                            className={`${softInputClass} !bg-white !border-slate-200 w-12 py-0.5 text-center font-mono font-bold text-xs text-[#135bec]`}
                          />
                        </div>
                        <span className="font-mono font-bold text-[#135bec]">
                          ৳ {marginBdt.toLocaleString('en-US')}
                        </span>
                      </div>

                      <div className="pt-1.5 border-t border-slate-200/70 flex justify-between items-baseline">
                        <div>
                          <span className="font-bold text-slate-900 block">Total Deduction</span>
                          <span className="text-[10px] text-slate-400">
                            Due: <strong className="font-mono text-slate-600">৳ {deferredLcDueBdt.toLocaleString('en-US')}</strong>
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="font-mono font-bold text-sm text-slate-900 block">
                            ৳ {totalDeductionBdt.toLocaleString('en-US')}
                          </span>
                          <span
                            className={`font-mono text-[10px] font-semibold ${
                              remainingBalance < 0 ? 'text-rose-600' : 'text-emerald-600'
                            }`}
                          >
                            Bal: ৳ {remainingBalance.toLocaleString('en-US')}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Mobile Validation & Overdraft Alerts */}
                    {(isOverdraft || newLcError) && (
                      <div className="space-y-2">
                        {selectedAcc && isOverdraft && !isCash && isAdmin && (
                          <label className="flex items-center gap-2 p-2.5 bg-amber-50 border border-amber-300 rounded-xl cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newLcOverdraftApproved}
                              onChange={(e) => setNewLcOverdraftApproved(e.target.checked)}
                              className="w-4 h-4 text-amber-600 rounded"
                            />
                            <span className="text-[11px] font-bold text-amber-950">
                              Authorize Bank Overdraft (Deficit: ৳{(totalDeductionBdt - accountBalance).toLocaleString()})
                            </span>
                          </label>
                        )}
                        {newLcError && (
                          <div className="p-2.5 bg-rose-50 border border-rose-300 rounded-xl text-rose-900 text-[11px] font-bold">
                            {newLcError}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Mobile Submit & Cancel Actions */}
                    <div className="space-y-2 pt-1">
                      <button
                        type="submit"
                        disabled={isSubmitDisabled}
                        className="w-full bg-[#135bec] hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold py-3 rounded-xl shadow-md text-xs flex items-center justify-center gap-1.5"
                      >
                        {isSavingNewLc ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            <span>Establishing LC...</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Establish Letter of Credit</span>
                          </>
                        )}
                      </button>
                      <button
                        type="button"
                        disabled={isSavingNewLc}
                        data-modal-close="true"
                        onClick={handleCloseNewLcModal}
                        className="w-full bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-800 border border-slate-200 font-semibold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5"
                      >
                        <X className="w-3.5 h-3.5" />
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </ModalWrapper>
        );
      })()}

      {/* LC Expiry & Maturity Alert Center Modal */}
      <LCExpiryAlertModal
        isOpen={showExpiryModal}
        onClose={() => setShowExpiryModal(false)}
        alerts={lcExpiryAlerts}
        lcs={lcs}
        onAcknowledgeAlert={handleAcknowledgeAlert}
        onApplyAmendment={handleApplyAmendment}
        onNavigateToLC={(lcId, view) => {
          const target = lcs.find(l => l.id === lcId);
          if (target) {
            setSelectedLc(target);
            if (view === 'register') setActiveTab('lc_register');
            else if (view === 'expenses') setActiveTab('lc_expenses');
            else if (view === 'bills') setActiveTab('lc_exporter_bills');
          }
        }}
      />

      {/* Modal: Printable Purchase Invoice (Executive Modern Design matching Sales Invoice) */}
      {selectedPrintInvoice && (
        <PrintablePurchaseInvoiceModal
          invoice={selectedPrintInvoice}
          supplier={suppliers.find(s => s.id === selectedPrintInvoice.supplierId || s.name === selectedPrintInvoice.supplierName)}
          onClose={() => setSelectedPrintInvoice(null)}
          onPaymentCollect={(inv) => {
            setSelectedSupplierForKhata(inv.supplierId);
            setPreselectedInvoiceForPayment(inv);
            setIsPaymentModalOpen(true);
            setActiveTab('supplier_payments');
            setSelectedPrintInvoice(null);
          }}
        />
      )}

      {/* Modal: Add & Edit Supplier / Exporter (Windows & Mobile Dual View with Live Voucher Inspector) */}
      <AddSupplierModal
        isOpen={showAddSupplierModal}
        supplierToEdit={supplierToEdit}
        onClose={() => {
          setShowAddSupplierModal(false);
          setSupplierToEdit(null);
        }}
        onSupplierSaved={(savedSupp) => {
          if (supplierToEdit) {
            const updated = updateSupplier(savedSupp);
            setSuppliers(updated);
            triggerToast(`✓ Supplier "${savedSupp.name}" profile updated successfully!`);
          } else {
            const created = addSupplier(savedSupp);
            setSuppliers(getSuppliers());
            setSelectedSupplierForKhata(created.id);
            setSelectedSupplier(created.id);
            setNewLcSupplier(created.name);
            if (created.companyOwner) {
              setNewLcCompanyOwner(created.companyOwner);
            }
            triggerToast(`✓ New Supplier "${created.name}" successfully added!`);
          }
          setShowAddSupplierModal(false);
          setSupplierToEdit(null);
        }}
      />

      {/* Requirement 4: Post Margin Now Modal for Existing LCs */}
      {marginModalLc && (
        <ModalWrapper
          isOpen={Boolean(marginModalLc)}
          onClose={handleCloseMarginModal}
          isDirty={
            postMarginMode !== 'post_voucher' ||
            postMarginExternalReason.trim() !== '' ||
            (postMarginAccountId !== '' && postMarginAccountId !== (accessibleAccounts[0]?.id || ''))
          }
          isSaving={isSavingPostMargin}
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
        >
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 my-auto">
            <div className="bg-slate-900 text-white px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Landmark className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-sm font-bold">Post LC Cash Margin</h3>
                  <p className="text-[11px] text-slate-400">
                    LC: {marginModalLc.lcNumber} • {marginModalLc.issuingBank}
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={isSavingPostMargin}
                data-modal-close="true"
                onClick={handleCloseMarginModal}
                className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer disabled:opacity-50 shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Calculated Margin Info */}
              {(() => {
                const marginPercent = marginModalLc.marginPercent !== undefined ? marginModalLc.marginPercent : (marginModalLc.marginDepositPercent ?? 15);
                const expectedAmt = computeExpectedLcMarginBDT({ ...marginModalLc, marginPercent });
                const marginAmt = marginModalLc.marginAmountBDT !== undefined ? marginModalLc.marginAmountBDT : (marginModalLc.marginAmountLocal || expectedAmt);

                return (
                  <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-amber-800 uppercase block">Margin Amount ({marginPercent}%)</span>
                      <span className="text-lg font-black font-mono text-amber-950">৳{marginAmt.toLocaleString()} BDT</span>
                    </div>
                    <div className="text-right text-[11px] text-amber-800 font-mono">
                      <span>CFR: ${marginModalLc.cfrAmount?.toLocaleString()}</span>
                      <span className="block text-[10px] text-amber-700">@ ৳{marginModalLc.exchangeRate || 122.50}</span>
                    </div>
                  </div>
                );
              })()}

              {/* Mode Selection */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setPostMarginMode('post_voucher')}
                  className={`py-2 rounded-lg transition-all cursor-pointer ${
                    postMarginMode === 'post_voucher' 
                      ? 'bg-white text-blue-700 shadow-xs' 
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  1. Post Payment Voucher
                </button>
                <button
                  type="button"
                  onClick={() => setPostMarginMode('mark_external')}
                  className={`py-2 rounded-lg transition-all cursor-pointer ${
                    postMarginMode === 'mark_external' 
                      ? 'bg-white text-amber-700 shadow-xs' 
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  2. External / Prior to System
                </button>
              </div>

              {postMarginMode === 'post_voucher' ? (
                <div className="space-y-3">
                  {/* Account Dropdown */}
                  <div className="relative" ref={postMarginDropdownRef}>
                    <label className="block font-semibold text-slate-700 text-xs mb-1">
                      Margin Paid From Account <span className="text-rose-500">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsPostMarginDropdownOpen(prev => !prev)}
                      className="w-full p-2.5 border border-slate-300 rounded-xl text-left bg-white flex items-center justify-between text-xs cursor-pointer"
                    >
                      {(() => {
                        const acc = bankAccounts.find(a => a.id === postMarginAccountId);
                        if (!acc) return <span className="text-slate-400">Select bank or cash account...</span>;
                        return (
                          <div className="truncate pr-2">
                            <span className="font-bold text-slate-900 block truncate">{acc.bankName}</span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {acc.accountNumber} • Balance: ৳{(acc.ledgerBalance || 0).toLocaleString()}
                            </span>
                          </div>
                        );
                      })()}
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    </button>

                    {isPostMarginDropdownOpen && (
                      <div className="absolute z-30 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden max-h-52 flex flex-col">
                        <div className="p-2 border-b border-slate-100 bg-slate-50">
                          <input
                            type="text"
                            value={postMarginAccountSearch}
                            onChange={(e) => setPostMarginAccountSearch(e.target.value)}
                            placeholder="Search account..."
                            className="w-full px-2.5 py-1 text-xs border border-slate-200 rounded-lg outline-none"
                            onClick={(e) => e.stopPropagation()}
                          />
                        </div>
                        <div className="overflow-y-auto divide-y divide-slate-100">
                          {accessibleAccounts
                            .filter(acc => {
                              const q = postMarginAccountSearch.toLowerCase();
                              return acc.bankName.toLowerCase().includes(q) || acc.accountNumber.toLowerCase().includes(q);
                            })
                            .map(acc => (
                              <button
                                key={acc.id}
                                type="button"
                                onClick={() => {
                                  setPostMarginAccountId(acc.id);
                                  setIsPostMarginDropdownOpen(false);
                                  setPostMarginAccountSearch('');
                                }}
                                className="w-full p-2.5 text-left hover:bg-blue-50/50 flex items-center justify-between text-xs cursor-pointer"
                              >
                                <div>
                                  <span className="font-bold text-slate-900 block">{acc.bankName}</span>
                                  <span className="text-[10px] text-slate-500 font-mono">{acc.accountNumber}</span>
                                </div>
                                <span className="font-mono font-bold text-emerald-700">
                                  ৳{(acc.ledgerBalance || 0).toLocaleString()}
                                </span>
                              </button>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 text-xs mb-1">
                      Payment Date <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={postMarginDate}
                      onChange={(e) => setPostMarginDate(e.target.value)}
                      required
                      className="w-full border border-slate-300 rounded-xl p-2 font-mono text-xs text-slate-900 outline-none"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="block font-semibold text-slate-700 text-xs">
                    Mark as paid externally / before system start (no voucher)
                  </label>
                  <p className="text-[11px] text-slate-500">
                    No General Ledger voucher will be created and bank ledger balance will not be deducted.
                  </p>
                  <input
                    type="text"
                    value={postMarginExternalReason}
                    onChange={(e) => setPostMarginExternalReason(e.target.value)}
                    placeholder="e.g. Paid before ERP migration / Opening balance margin"
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 outline-none"
                    required
                  />
                </div>
              )}

              {postMarginError && (
                <div className="p-2.5 bg-rose-50 border border-rose-300 rounded-xl text-rose-900 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{postMarginError}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  disabled={isSavingPostMargin}
                  data-modal-close="true"
                  onClick={handleCloseMarginModal}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50 transition-colors disabled:opacity-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isSavingPostMargin}
                  onClick={handlePostExistingMargin}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  {isSavingPostMargin ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Posting...</span>
                    </>
                  ) : (
                    <span>Confirm Posting</span>
                  )}
                </button>
              </div>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* Requirement 3: Admin Cancel LC Modal */}
      {cancelModalLc && (
        <ModalWrapper
          isOpen={Boolean(cancelModalLc)}
          onClose={handleCloseCancelLcModal}
          isDirty={cancelLcReason.trim() !== ''}
          isSaving={isCancellingLc}
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
        >
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 my-auto">
            <div className="bg-rose-950 text-white px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 text-rose-400" />
                <div>
                  <h3 className="text-sm font-bold">Cancel Letter of Credit</h3>
                  <p className="text-[11px] text-rose-300">
                    LC: {cancelModalLc.lcNumber} • {cancelModalLc.supplierName}
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={isCancellingLc}
                data-modal-close="true"
                onClick={handleCloseCancelLcModal}
                className="p-1 text-rose-300 hover:text-white rounded-lg transition-colors cursor-pointer disabled:opacity-50 shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Validation Check */}
              {(() => {
                const hasSettlements = (cancelModalLc.bankSettlements || []).some(b => b.status !== 'Voided');
                const hasHundi = (cancelModalLc.hundiPayments || []).some(h => h.status !== 'Voided');
                const hasReceivings = (cancelModalLc.receivings && cancelModalLc.receivings.length > 0) || (cancelModalLc.receivedQuantity && cancelModalLc.receivedQuantity > 0) || (cancelModalLc.receivedQtyMt && cancelModalLc.receivedQtyMt > 0);
                const otherPaidExpenses = (cancelModalLc.expenses || []).filter(e => e.status === 'Paid' && e.voucherNo !== cancelModalLc.marginVoucherNo);
                const isBlocked = hasSettlements || hasHundi || hasReceivings || otherPaidExpenses.length > 0;

                return (
                  <div className="space-y-3">
                    {isBlocked ? (
                      <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-900 text-xs space-y-1">
                        <strong className="block font-bold">Cannot cancel Letter of Credit:</strong>
                        <ul className="list-disc list-inside text-[11px] text-rose-700 space-y-0.5">
                          {hasSettlements && <li>Bank settlement exists</li>}
                          {hasHundi && <li>Hundi payment records exist</li>}
                          {hasReceivings && <li>Goods receiving records exist</li>}
                          {otherPaidExpenses.length > 0 && <li>Paid expense records exist</li>}
                        </ul>
                      </div>
                    ) : (
                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs space-y-1">
                        <strong className="block font-bold">Warning: Administrator Authorization Required</strong>
                        <p className="text-[11px] text-amber-800">
                          {cancelModalLc.marginVoucherNo ? (
                            <>
                              Cancelling this LC will reverse margin voucher <strong>{cancelModalLc.marginVoucherNo}</strong> and refund the margin deposit (৳{Math.round(cancelModalLc.marginAmountLocal || 0).toLocaleString()} BDT) to the account.
                            </>
                          ) : (
                            'No margin voucher exists for this LC. The LC will be marked as Cancelled and excluded from active totals.'
                          )}
                        </p>
                      </div>
                    )}

                    {!isBlocked && (
                      <div>
                        <label className="block font-bold text-slate-700 text-xs mb-1">
                          Cancellation Reason <span className="text-rose-500">*</span>
                        </label>
                        <textarea
                          rows={2}
                          value={cancelLcReason}
                          onChange={(e) => setCancelLcReason(e.target.value)}
                          placeholder="State reason (e.g. Supplier contract terminated / LC non-operative)..."
                          className="w-full border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-rose-500"
                          required
                        />
                      </div>
                    )}

                    {cancelLcError && (
                      <div className="p-2.5 bg-rose-50 border border-rose-300 rounded-xl text-rose-900 text-xs flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span>{cancelLcError}</span>
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                      <button
                        type="button"
                        disabled={isCancellingLc}
                        data-modal-close="true"
                        onClick={handleCloseCancelLcModal}
                        className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50 transition-colors disabled:opacity-50 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        disabled={isCancellingLc || isBlocked || !cancelLcReason.trim()}
                        onClick={handleConfirmCancelLc}
                        className="px-4 py-2 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-300 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        {isCancellingLc ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            <span>Cancelling LC...</span>
                          </>
                        ) : (
                          <span>Confirm LC Cancellation</span>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* Voucher Print / View Modal */}
      {selectedTxnForView && (
        <VoucherPrintModal
          isOpen={Boolean(selectedTxnForView)}
          onClose={() => setSelectedTxnForView(null)}
          transaction={selectedTxnForView}
        />
      )}
    </div>
  );
};
